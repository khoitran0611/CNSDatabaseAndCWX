using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace AgriMore.Logistics.Domain.Repository.MySql
{
    /// <summary>
    /// Builds queries
    /// </summary>
    public class QueryBuilder
    {
        private readonly ICollection<string> columnNames;
        private readonly string tableName;

        /// <summary>
        /// Initializes a new instance of the <see cref="QueryBuilder"/> class.
        /// </summary>
        /// <param name="columnNames">The column names.</param>
        /// <param name="tableName">Name of the table.</param>
        public QueryBuilder(ICollection<string> columnNames, string tableName)
        {
            if (tableName == null)
            {
                throw new ArgumentNullException("tableName");
            }
            if (columnNames == null)
            {
                throw new ArgumentNullException("columnNames");
            }

            if (tableName.Trim() == string.Empty)
            {
                throw new ArgumentException("tableName is empty");
            }
            if (columnNames.Count == 0)
            {
                throw new ArgumentException("columnNames is empty");
            }
            this.columnNames = columnNames;
            this.tableName = tableName;
        }

        /// <summary>
        /// Gets the count query.
        /// </summary>
        /// <returns></returns>
        public string GetCountQuery()
        {
            StringBuilder queryBuilder = new StringBuilder();

            queryBuilder.Append("SELECT");
            queryBuilder.Append(" ");
            queryBuilder.Append("COUNT(*)");
            queryBuilder.Append(" ");
            queryBuilder.Append("FROM");
            queryBuilder.Append(" ");
            queryBuilder.Append(tableName);

            return queryBuilder.ToString();
        }

        ///// <summary>
        ///// Gets the count query.
        ///// </summary>
        ///// <returns></returns>
        //public string GetCountQuery(string query)
        //{
        //    StringBuilder queryBuilder = new StringBuilder();

        //    queryBuilder.Append("SELECT");
        //    queryBuilder.Append(" ");
        //    queryBuilder.Append("COUNT(*)");
        //    queryBuilder.Append(" ");
        //    queryBuilder.Append("FROM");
        //    queryBuilder.Append(tableName);

        //    return queryBuilder.ToString();
        //}

        /// <summary>
        /// Gets the query by parameter.
        /// </summary>
        /// <param name="parName">Name of the par.</param>
        /// <param name="parHolder">The par holder.</param>
        /// <returns></returns>
        public string GetQueryByParameter(string parName, string parHolder)
        {
            StringBuilder queryBuilder = new StringBuilder();
            queryBuilder.Append("SELECT");
            queryBuilder.Append(" ");
            int i = 0;
            foreach (string column in columnNames)
            {
                queryBuilder.Append(column);
                if (i < columnNames.Count - 1)
                {
                    queryBuilder.Append(",");
                }
                i++;
            }
            queryBuilder.Append(" ");
            queryBuilder.Append("FROM");
            queryBuilder.Append(" ");
            queryBuilder.Append(tableName);
            queryBuilder.Append(" ");
            queryBuilder.Append("WHERE");
            queryBuilder.Append(" ");
            queryBuilder.Append(parName);
            queryBuilder.Append(" = ");
            queryBuilder.Append(parHolder);

            return queryBuilder.ToString();
        }

        

        /// <summary>
        /// Gets the query all.
        /// </summary>
        /// <returns></returns>
        public string GetQueryAll()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("SELECT");
            stringBuilder.Append(" ");
            int i = 0;
            foreach (string column in columnNames)
            {
                stringBuilder.Append(column);
                if (i < columnNames.Count - 1)
                {
                    stringBuilder.Append(",");
                }
                i++;
            }
            stringBuilder.Append(" ");
            stringBuilder.Append("FROM");
            stringBuilder.Append(" ");
            stringBuilder.Append(tableName);
            return stringBuilder.ToString();
        }

        /// <summary>
        /// Gets the insert query.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public string GetInsertQuery(ICollection<IDbDataParameter> parameters)
        {
            if (parameters == null)
            {
                throw new ArgumentNullException("parameters");
            }
            if (parameters.Count == 0)
            {
                throw new ArgumentException("parameters collection is empty");
            }
            StringBuilder queryBuilder = new StringBuilder();
            queryBuilder.Append("INSERT INTO ");
            queryBuilder.Append(tableName);
            queryBuilder.Append("(");
            int i = 0;
            foreach (IDbDataParameter parameter in parameters)
            {
                //column names as parameter names
                queryBuilder.Append(parameter.ParameterName.Substring(1));
                if (i < parameters.Count - 1)
                {
                    queryBuilder.Append(",");
                }
                i++;
            }
            queryBuilder.Append(")");
            queryBuilder.Append(" ");
            queryBuilder.Append("VALUES(");
            i = 0;
            foreach (IDbDataParameter parameter in parameters)
            {
                //column names as parameter names
                queryBuilder.Append(parameter.ParameterName);
                if (i < parameters.Count - 1)
                {
                    queryBuilder.Append(",");
                }
                i++;
            }
            queryBuilder.Append(")");
            return queryBuilder.ToString();
        }

        /// <summary>
        /// Gets the delete query by id.
        /// </summary>
        /// <returns></returns>
        public string GetDeleteQueryById()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("DELETE FROM ");
            builder.Append(tableName);
            builder.Append(" ");
            builder.Append("WHERE");
            builder.Append(" ");
            builder.Append("uid = ?uid");
            return builder.ToString();
        }

        /// <summary>
        /// Gets the update query by id.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public string GetUpdateQueryById(ICollection<IDbDataParameter> parameters)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("UPDATE ");
            builder.Append(tableName);
            builder.Append(" SET ");
            int i = 0;
            foreach (IDbDataParameter parameter in parameters)
            {
                builder.Append(parameter.ParameterName.Substring(1));
                builder.Append(" = ");
                builder.Append(parameter.ParameterName);
                if (i < parameters.Count - 1)
                {
                    builder.Append(",");
                }
                i++;              
            }
            builder.Append(" ");
            builder.Append("WHERE ");
            builder.Append("uid = ?uid");
            return builder.ToString();
        }
    }
}
