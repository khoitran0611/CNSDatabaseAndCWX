using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Data.MySql
{
    /// <summary>
    /// 
    /// </summary>
    public interface IRepositorySession : IDisposable
    {
        /// <summary>
        /// Gets the context set by the last call to BeginContext.
        /// </summary>
        /// <value>The owner.</value>
        RepositorySessionContext CurrentContext { get; }

        /// <summary>
        /// Begins a context.
        /// </summary>
        /// <param name="objects">The objects.</param>
        void BeginContext(params IIdentifyable[] objects);

        /// <summary>
        /// Ends a context.
        /// </summary>
        void EndContext();

        /// <summary>
        /// Adds the specified obj.
        /// </summary>
        /// <param name="obj">The obj.</param>
        void Add(IIdentifyable obj);

        /// <summary>
        /// Removes the specified obj.
        /// </summary>
        /// <param name="obj">The obj.</param>
        void Remove(IIdentifyable obj);

        /// <summary>
        /// Removes the specified object.
        /// </summary>
        /// <param name="t">The type.</param>
        /// <param name="uid">The uid.</param>
        void Remove(Type t, long uid);

        /// <summary>
        /// Clears the cache for the specified type.
        /// </summary>
        /// <param name="t">The t.</param>
        void Clear(Type t);

        /// <summary>
        /// Clears the cache.
        /// </summary>
        void Clear();

        /// <summary>
        /// Determines whether the cache contains the specified object.
        /// </summary>
        /// <param name="t">The type.</param>
        /// <param name="uid">The uid.</param>
        /// <returns>
        /// 	<c>true</c> if the cache contains the specified object; otherwise, <c>false</c>.
        /// </returns>
        bool Contains(Type t, long uid);

        /// <summary>
        /// Determines whether the cache contains the specified object.
        /// </summary>
        /// <typeparam name="TElement">The type of the element.</typeparam>
        /// <param name="uid">The uid.</param>
        /// <returns>
        /// 	<c>true</c> if the cache contains the specified object; otherwise, <c>false</c>.
        /// </returns>
        bool Contains<TElement>(long uid) where TElement : class, IIdentifyable;

        /// <summary>
        /// Gets the specified object.
        /// </summary>
        /// <param name="t">The type.</param>
        /// <param name="uid">The uid.</param>
        /// <returns></returns>
        IIdentifyable GetObject(Type t, long uid);

        /// <summary>
        /// Gets the specified object.
        /// </summary>
        /// <typeparam name="TElement">The type of the element.</typeparam>
        /// <param name="uid">The uid.</param>
        /// <returns></returns>
        TElement GetObject<TElement>(long uid) where TElement : class, IIdentifyable;
    }
}