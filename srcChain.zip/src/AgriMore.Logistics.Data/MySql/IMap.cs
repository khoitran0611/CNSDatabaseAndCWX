using System.Collections.Generic;

namespace AgriMore.Logistics.Data.MySql
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TElement">The type of the element.</typeparam>
    /// <typeparam name="TDto">The type of the dto.</typeparam>
    public interface IMap<TElement, TDto>
    {
        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        TElement Create(TDto dto, IRepositorySession session);

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        string GetUniqueNameColumn();

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        bool SupportsUniqueNameLookup();

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        void WriteDto(TDto dto, TElement element, IRepositorySession session);

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        IEnumerable<TElement> Convert(IEnumerable<TDto> dtoValues, IRepositorySession session);
    }
}