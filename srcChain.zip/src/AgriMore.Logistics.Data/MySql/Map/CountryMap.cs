using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using DtoCountry = AgriMore.Logistics.Data.MySql.DTO.Country;

namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class CountryMap : IMap<Country, DtoCountry>
    {
        #region IMap<Country,Country> Members

        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public Country Create(DtoCountry dto, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");

            if (session.Contains<Country>(dto.Uid))
                return session.GetObject<Country>(dto.Uid);

            Country country = new Country(dto.Name);

            country.Uid = dto.Uid;
            session.Add(country);

            return country;
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            return "name";
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            return true;
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(DtoCountry dto, Country element, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");
            if (element == null)
                throw new ArgumentNullException("element");

            dto.Name = element.Name;
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<Country> Convert(IEnumerable<DtoCountry> dtoValues, IRepositorySession session)
        {
            if (dtoValues == null)
                throw new ArgumentNullException("dtoValues");

            foreach (DtoCountry dto in dtoValues)
                yield return Create(dto, session);
        }

        #endregion
    }
}