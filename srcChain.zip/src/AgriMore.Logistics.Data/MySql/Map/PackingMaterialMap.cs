using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using DtoPackingMaterial = AgriMore.Logistics.Data.MySql.DTO.Packingmaterial;

namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class PackingMaterialMap : IMap<PackingMaterial, DtoPackingMaterial>
    {
        #region IMap<PackingMaterial,Packingmaterial> Members

        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public PackingMaterial Create(DtoPackingMaterial dto, IRepositorySession session)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(DtoPackingMaterial dto, PackingMaterial element, IRepositorySession session)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<PackingMaterial> Convert(IEnumerable<DtoPackingMaterial> dtoValues, IRepositorySession session)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}