//using System;
//using System.Collections.Generic;
//using AgriMore.Logistics.Domain;
//using DtoPackageType = AgriMore.Logistics.Data.MySql.DTO.Packagetype;
//using DtoPackingMaterial = AgriMore.Logistics.Data.MySql.DTO.Packingmaterial;
//using DtoPackageTypeCategory = AgriMore.Logistics.Data.MySql.DTO.Packagetypecategory;

//namespace AgriMore.Logistics.Data.MySql.Map
//{
//    /// <summary>
//    /// 
//    /// </summary>
//    public class PackageTypeMap : IMap<PackageType, DtoPackageType>
//    {
//        #region IMap<PackageType,Packagetype> Members

//        /// <summary>
//        /// Creates the element using data from the specified dto.
//        /// </summary>
//        /// <param name="dto">The dto.</param>
//        /// <param name="session">The session.</param>
//        /// <returns></returns>
//        public PackageType Create(DtoPackageType dto, IRepositorySession session)
//        {
//            if (dto == null)
//                throw new ArgumentNullException("dto");

//            if (session.Contains<PackageType>(dto.Uid))
//                return session.GetObject<PackageType>(dto.Uid);

//            IMap<PackingMaterial, DtoPackingMaterial> packingMaterialMap = new PackingMaterialMap();
//            PackingMaterial packingMaterial = packingMaterialMap.Create(dto.Packingmaterial, session);

//            IMap<PackageTypeCategory, DtoPackageTypeCategory> packageTypeCategoryMap = new PackageTypeCategoryMap();
//            PackageTypeCategory packageTypeCategory = packageTypeCategoryMap.Create(dto.Packagetypecategory, session);

//            PackageType packageType = new PackageType(dto.Name, packingMaterial, packageTypeCategory);

//            packageType.Uid = dto.Uid;
//            session.Add(packageType);
            
//            return packageType;
//        }

//        /// <summary>
//        /// Indicates whether or not the type supports unique name lookup.
//        /// </summary>
//        /// <returns></returns>
//        public bool SupportsUniqueNameLookup()
//        {
//            return true;
//        }

//        /// <summary>
//        /// Gets the unique name column.
//        /// </summary>
//        /// <returns></returns>
//        public string GetUniqueNameColumn()
//        {
//            return "name";
//        }

//        /// <summary>
//        /// Writes the dto using data from the element.
//        /// </summary>
//        /// <param name="dto">The dto.</param>
//        /// <param name="element">The element.</param>
//        /// <param name="session">The session.</param>
//        public void WriteDto(DtoPackageType dto, PackageType element, IRepositorySession session)
//        {
//            if (dto == null)
//                throw new ArgumentNullException("dto");
//            if (element == null)
//                throw new ArgumentNullException("element");

//            dto.Name = element.Name;
//            //TODO: not in element yet:
//            dto.PackingMaterialId = 0;
//            dto.PackageTypeCategoryId = 0;
//            dto.UomWidthId = 0;
//            dto.UomHeightId = 0;
//            dto.UomLengthId = 0;
//            dto.UomWeightId = 0;
//            dto.Width = 0;
//            dto.Height = 0;
//            dto.Length = 0;
//            dto.Weight = 0;
//            dto.IsSealed = false;
//            dto.Ventilation = false;
//        }

//        /// <summary>
//        /// Converts the specified dto's to elements.
//        /// </summary>
//        /// <param name="dtoValues">The dto values.</param>
//        /// <param name="session">The session.</param>
//        /// <returns></returns>
//        public IEnumerable<PackageType> Convert(IEnumerable<DtoPackageType> dtoValues, IRepositorySession session)
//        {
//            foreach (DtoPackageType dto in dtoValues)
//                yield return Create(dto, session);
//        }

//        #endregion
//    }
//}