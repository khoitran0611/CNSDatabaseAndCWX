//using System;
//using System.Collections.Generic;
//using AgriMore.Logistics.Domain;
//using DtoIdentification = AgriMore.Logistics.Data.MySql.DTO.Packageidentification;
//using DtoChainEntity = AgriMore.Logistics.Data.MySql.DTO.Chainentity;

//namespace AgriMore.Logistics.Data.MySql.Map
//{
//    /// <summary>
//    /// 
//    /// </summary>
//    public class IdentificationMap : IMap<Identification, DtoIdentification>
//    {
//        #region IMap<Identification,Packageidentification> Members

//        /// <summary>
//        /// Creates the element using data from the specified dto.
//        /// </summary>
//        /// <param name="dto">The dto.</param>
//        /// <param name="session">The session.</param>
//        /// <returns></returns>
//        public Identification Create(DtoIdentification dto, IRepositorySession session)
//        {
//            if (dto == null)
//                throw new ArgumentNullException("dto");

//            if (session.Contains<Identification>(dto.Uid))
//                return session.GetObject<Identification>(dto.Uid);

//            IMap<ChainEntity, DtoChainEntity> chainEntityMap = new ChainEntityMap();
//            ChainEntity chainEntity = chainEntityMap.Create(dto.Chainentity, session);

//            Identification identification = new Identification(dto.Code, chainEntity);

//            identification.Uid = dto.Uid;
//            session.Add(identification);

//            return identification;
//        }

//        /// <summary>
//        /// Indicates whether or not the type supports unique name lookup.
//        /// </summary>
//        /// <returns></returns>
//        public bool SupportsUniqueNameLookup()
//        {
//            return true;
//        }

//        /// <summary>
//        /// Gets the unique name column.
//        /// </summary>
//        /// <returns></returns>
//        public string GetUniqueNameColumn()
//        {
//            return "code";
//        }

//        /// <summary>
//        /// Writes the dto using data from the element.
//        /// </summary>
//        /// <param name="dto">The dto.</param>
//        /// <param name="element">The element.</param>
//        /// <param name="session">The session.</param>
//        public void WriteDto(DtoIdentification dto, Identification element, IRepositorySession session)
//        {
//            dto.Code = element.Id;
//            dto.ChainEntityId = element.ChainEntity.Uid;
//            //TODO: not in Identification yet:
//            dto.PackageId = 0;
//        }

//        /// <summary>
//        /// Converts the specified dto's to elements.
//        /// </summary>
//        /// <param name="dtoValues">The dto values.</param>
//        /// <param name="session">The session.</param>
//        /// <returns></returns>
//        public IEnumerable<Identification> Convert(IEnumerable<DtoIdentification> dtoValues, IRepositorySession session)
//        {
//            foreach (DtoIdentification dto in dtoValues)
//                yield return Create(dto, session);
//        }

//        #endregion
//    }
//}