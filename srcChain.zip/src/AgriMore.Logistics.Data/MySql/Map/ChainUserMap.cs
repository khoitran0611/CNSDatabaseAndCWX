using System;
using System.Collections.Generic;
using AgriMore.Logistics.Data.MySql.DTO;
using AgriMore.Logistics.Domain;

using Role = AgriMore.Logistics.Domain.Role;
using DtoRole = AgriMore.Logistics.Data.MySql.DTO.Chainrole;

namespace AgriMore.Logistics.Data.MySql.Map
{
    /// <summary>
    /// 
    /// </summary>
    public class ChainUserMap : IMap<User, Chainuser>
    {
        #region IMap<User,Chainuser> Members

        /// <summary>
        /// Creates the element using data from the specified dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public User Create(Chainuser dto, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");

            if (session.Contains<User>(dto.Uid))
                return session.GetObject<User>(dto.Uid);

            IEnumerable<Role> roles = GetRoles(dto, session);
            User user = new User(dto.Username, dto.Password, dto.Firstname, dto.Lastname, roles);

            user.Uid = dto.Uid;
            session.Add(user);

            return user;
        }

        /// <summary>
        /// Indicates whether or not the type supports unique name lookup.
        /// </summary>
        /// <returns></returns>
        public bool SupportsUniqueNameLookup()
        {
            return true;
        }

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        public string GetUniqueNameColumn()
        {
            return "username";
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        public void WriteDto(Chainuser dto, User element, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");
            if (element == null)
                throw new ArgumentNullException("element");

            dto.Username = element.Username;
            dto.Password = element.Password;
            dto.Firstname = element.FirstName;
            dto.Lastname = element.LastName;
        }

        /// <summary>
        /// Converts the specified dto's to elements.
        /// </summary>
        /// <param name="dtoValues">The dto values.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        public IEnumerable<User> Convert(IEnumerable<Chainuser> dtoValues, IRepositorySession session)
        {
            foreach (Chainuser dto in dtoValues)
                yield return Create(dto, session);
        }

        #endregion

        /// <summary>
        /// Gets the roles.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <param name="session">The session.</param>
        /// <returns></returns>
        private IEnumerable<Role> GetRoles(Chainuser user, IRepositorySession session)
        {
            IList<DtoRole> dtoRoles = new List<DtoRole>();
            foreach(Chainuserrole userRole in user.ChainuserroleRecords())
                if(!dtoRoles.Contains(userRole.Chainrole))
                    dtoRoles.Add(userRole.Chainrole);
            return new ChainRoleMap().Convert(dtoRoles, session);
        }
    }
}