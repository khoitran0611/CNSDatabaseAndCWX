using AgriMore.Logistics.Data.MySql.Map;
using AgriMore.Logistics.Domain.Repository;

using ChainEntity = AgriMore.Logistics.Domain.ChainEntity;
using DtoChainEntity = AgriMore.Logistics.Data.MySql.DTO.Chainentity;

using Address = AgriMore.Logistics.Domain.Address;
using DtoAddress = AgriMore.Logistics.Data.MySql.DTO.Address;

namespace AgriMore.Logistics.Data.MySql.Repository
{
    /// <summary>
    /// 
    /// </summary>
    public class MySqlChainEntityRepository : AbstractMySqlRepository<ChainEntity, DtoChainEntity, ChainEntityMap>
    {
        /// <summary>
        /// Called after the record is added.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        protected override void OnAfterAdd(ChainEntity element, DtoChainEntity dto, IRepositorySession session)
        {
            MySqlAddressRepository repAddress = new MySqlAddressRepository();
            foreach (Address address in element.Addresses)
                repAddress.StoreInternalTM(address, session);
            //base.OnAfterAdd(element, dto);
        }

        /// <summary>
        /// Called after the record is updated.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        protected override void OnAfterUpdate(ChainEntity element, DtoChainEntity dto, IRepositorySession session)
        {
            MySqlAddressRepository repAddress = new MySqlAddressRepository();
            foreach (Address address in element.Addresses)
                repAddress.StoreInternalTM(address, session);
            //base.OnAfterUpdate(element, dto);
        }

        /// <summary>
        /// Called after the record is removed.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        protected override void OnAfterRemove(ChainEntity element, IRepositorySession session)
        {
            MySqlAddressRepository repAddress = new MySqlAddressRepository();
            foreach (Address address in element.Addresses)
                repAddress.RemoveInternalTM(address, session);
            //base.OnAfterRemove(element);
        }
        
    }
}