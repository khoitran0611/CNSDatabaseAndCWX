using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using AgriMore.Logistics.Domain.Repository;
using SubSonic;

namespace AgriMore.Logistics.Data.MySql.Repository
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TElement">The type of the element.</typeparam>
    /// <typeparam name="TDto">The type of the dto.</typeparam>
    /// <typeparam name="TMap">The type of the map.</typeparam>
    public abstract class AbstractMySqlRepository<TElement, TDto, TMap> : IRepository<TElement>
        where TElement : class, IIdentifyable
        where TDto : class, IActiveRecord
        where TMap : class, IMap<TElement, TDto>
    {
        private readonly MethodInfo delete;
        private readonly MethodInfo fetchAll;
        private readonly MethodInfo fetchById;
        private readonly IMap<TElement, TDto> map;
        private readonly MethodInfo query;

        /// <summary>
        /// Initializes a new instance of the <see cref="AbstractMySqlRepository&lt;TElement, TDto, TMap&gt;"/> class.
        /// </summary>
        public AbstractMySqlRepository()
        {
            map = (IMap<TElement, TDto>) Activator.CreateInstance(typeof (TMap));
            BindingFlags bf = BindingFlags.Static | BindingFlags.Public | BindingFlags.FlattenHierarchy;
            fetchById =
                typeof (TDto).GetMethod("FetchByID", bf, null, CallingConventions.Standard, new Type[] {typeof (long)},
                                        null);
            fetchAll = typeof (TDto).GetMethod("FetchAll", bf, null, CallingConventions.Standard, new Type[0], null);
            delete =
                typeof (TDto).GetMethod("Delete", bf, null, CallingConventions.Standard, new Type[] {typeof (object)},
                                        null);
            query = typeof (TDto).GetMethod("Query", bf);
        }

        #region IRepository<TElement> Members

        /// <summary>
        /// Gets the Element by a unique string id. the id is the same value as the return value of <code>ToString()</code>
        /// on the object.
        /// </summary>
        /// <param name="uniqueName">Name of the unique.</param>
        /// <returns></returns>
        public virtual TElement GetOne(string uniqueName)
        {
            if (!map.SupportsUniqueNameLookup())
                throw new InvalidOperationException(
                    "The element type does not support this type of lookup. Use GetOne(long) or GetOne(ISpecification<TElement>) instead.");
            if (uniqueName == null)
                throw new ArgumentNullException("uniqueName");
            if (uniqueName.Trim() == string.Empty)
                throw new ArgumentException("uniqueName cannot be empty");

            TDto dto = (TDto) Activator.CreateInstance(typeof (TDto), GetUniqueNameColumn(), uniqueName);

            if (dto == null)
                throw new Exception("Record not found");

            long uid = dto.GetColumnValue<long>("uid");
            if (uid == 0)
                throw new Exception("Record not found");

            TElement element = CreateElement(dto);

            //AssignUID(element, dto);

            return element;
        }

        /// <summary>
        /// Gets the Element by unique id. This Id is returned by the <code>Add(TElement element)</code> method.
        /// </summary>
        /// <param name="uid">The uid.</param>
        /// <returns></returns>
        public virtual TElement GetOne(long uid)
        {
            if (uid == 0)
                throw new ArgumentException("uid cannot be 0");

            TDto dto = (TDto) Activator.CreateInstance(typeof (TDto), uid);

            if (dto == null)
                throw new Exception("Record not found");

            TElement element = CreateElement(dto);

            //AssignUID(element, dto);

            return element;
        }

        /// <summary>
        /// Gets One element using the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>The element, or null if the element could not be found.</returns>
        public virtual TElement GetOne(ISpecification<TElement> criteria)
        {
            if (criteria == null)
                throw new ArgumentNullException("criteria");

            foreach (TElement element in this)
                if (criteria.IsSatisfiedBy(element))
                    return element;

            return null;
        }

        /// <summary>
        /// Adds the specified element. returns the uid assigned internally in the repository.
        /// This method assigns the id to the element. The uid of the element is not allowed to be != 0,
        /// since then it would have been added already.
        /// <example>
        ///   Shipment shipment = new Shipment();
        ///   ...
        ///   long uid = repository.Add(shipment);
        /// </example>
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>the unique internal id. this id can be used in <code>GetOne(long uid)</code></returns>
        public virtual long Add(TElement element)
        {
            if (element == null)
                throw new ArgumentNullException("element");
            if (element.Uid != 0)
                throw new ArgumentException("uid of element is already assigned, cannot add element");

            //using (SharedDbConnectionScope s = new SharedDbConnectionScope())
            //{
            //    using (TransactionScope ts = new TransactionScope())
            //    {
            using (RepositorySession session = new RepositorySession())
            {
                AddInternalTM(element, session);
            }

            //ts.Complete();
            //    }
            //}
            return element.Uid;
        }

        internal void AddInternalTM(TElement element, IRepositorySession session)
        {
            session.BeginContext(element);

            OnBeforeAdd(element, session);

            // create a new dto and copy the data from the element
            TDto dto = (TDto)Activator.CreateInstance(typeof(TDto));

            // copy state from element to dto
            WriteDto(dto, element, session);

            // save the dto
            dto.Save();

            // assign UID
            AssignUID(element, dto);

            OnAfterAdd(element, dto, session);

            session.EndContext();
        }

        /// <summary>
        /// Returns all elements as a collection
        /// </summary>
        /// <returns></returns>
        public virtual ICollection<TElement> AsCollection()
        {
            // this uses the GetEnumerator<TElement> method to enumerate all objects 
            // in the collection and add them to the list.
            return new List<TElement>(this);
        }

        /// <summary>
        /// Determines whether this repository contains the element. 
        /// <code>TElement.Equals(object obj)</code> can be used to determine this. You need to implement <code>Equals(object obj)</code>
        ///  on the TElement type.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this repository contains the element; otherwise, <c>false</c>.
        /// </returns>
        public virtual bool Contains(TElement element)
        {
            if (element == null)
                throw new ArgumentNullException("element");

            //TODO: test this!
            TDto dto = (TDto) fetchById.Invoke(typeof (TDto), new object[] {element.Uid});
            return (dto != null);
        }


        /// <summary>
        /// Finds elements of TElement by specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>A collection of elements, or an empty collection if no elements where found for the criteria</returns>
        public virtual ICollection<TElement> Find(ISpecification<TElement> criteria)
        {
            if (criteria == null)
                throw new ArgumentNullException("criteria");

            IList<TElement> result = new List<TElement>();
            foreach (TElement element in this)
                if (criteria.IsSatisfiedBy(element))
                    result.Add(element);

            return result;
        }

        /// <summary>
        /// Stores the specified element. Equals needs to be implemented on the element.
        /// Equals is used to see if the element needs to be updated or added.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>The UID of the element.</returns>
        public void Store(TElement element)
        {
            if (element == null)
                throw new ArgumentNullException("element");

            using (RepositorySession session = new RepositorySession())
            {
                StoreInternalTM(element, session);
            }
        }

        internal void StoreInternalTM(TElement element, IRepositorySession session)
        {
            if (element.Uid == 0)
            {
                AddInternalTM(element, session);
            }
            else
            {
                Update(element, session);
            }
        }

        /// <summary>
        /// Removes the specified element. Equals needs to be implemented on the element.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>true if the element could be removed, false if not</returns>
        public bool Remove(TElement element)
        {
            if (element == null)
                throw new ArgumentNullException("element");
            if (element.Uid == 0)
                throw new InvalidOperationException("The element is not persisted.");

            bool result;

            //using (SharedDbConnectionScope s = new SharedDbConnectionScope())
            //{
            //    using (TransactionScope ts = new TransactionScope())
            //    {
            using (RepositorySession session = new RepositorySession())
            {
                result = RemoveInternalTM(element, session);
            }

            //ts.Complete();
            //    }
            //}
            return result;
        }

        internal bool RemoveInternalTM(TElement element, IRepositorySession session)
        {
            session.BeginContext(element);

            bool result = false;

            OnBeforeRemove(element, session);

            // delete record
            //TODO: test this!
            int rowsAffected = (int) delete.Invoke(typeof (TDto), new object[] {element.Uid});

            if (rowsAffected != 0)
            {
                // revoke UID
                RevokeUID(element);

                result = true;
            }

            OnAfterRemove(element, session);

            session.EndContext();

            return result;
        }

        /// <summary>
        /// Removes the elements using the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>collection if uids of the items removed</returns>
        public void Remove(ISpecification<TElement> criteria)
        {
            if (criteria == null)
                throw new ArgumentNullException("criteria");

            //using (SharedDbConnectionScope s = new SharedDbConnectionScope())
            //{
            //    using (TransactionScope ts = new TransactionScope())
            //    {
            using (RepositorySession session = new RepositorySession())
            {
                foreach (TElement element in this)
                {
                    if (criteria.IsSatisfiedBy(element))
                    {
                        RemoveInternalTM(element, session);
                    }
                }
            }
            //ts.Complete();
            //    }
            //}
        }

        /// <summary>
        /// Counts the elements using the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>the amount of elements that match the criteria</returns>
        public long Count(ISpecification<TElement> criteria)
        {
            long count = 0;
            foreach (TElement element in this)
                if (criteria.IsSatisfiedBy(element))
                    count++;
            return count;
        }

        /// <summary>
        /// Counts the elements.
        /// </summary>
        /// <returns>The number of elements</returns>
        public long Count()
        {
            //TODO: test this!
            Query q = (Query) query.Invoke(typeof (TDto), new object[0]);
            return q.GetCount("uid");
        }

        ///<summary>
        ///Returns an enumerator that iterates through the collection.
        ///</summary>
        ///
        ///<returns>
        ///A <see cref="T:System.Collections.Generic.IEnumerator`1"></see> that can be used to iterate through the collection.
        ///</returns>
        ///<filterpriority>1</filterpriority>
        public IEnumerator<TElement> GetEnumerator()
        {
            //TODO: test this!
            IDataReader reader = (IDataReader) fetchAll.Invoke(typeof (TDto), new object[0]);
            while (reader.Read())
            {
                TDto dto = (TDto) Activator.CreateInstance(typeof (TDto));
                dto.Load(reader);
                TElement element = CreateElement(dto);
                //AssignUID(element, dto);
                yield return element;
            }
        }

        ///<summary>
        ///Returns an enumerator that iterates through a collection.
        ///</summary>
        ///
        ///<returns>
        ///An <see cref="T:System.Collections.IEnumerator"></see> object that can be used to iterate through the collection.
        ///</returns>
        ///<filterpriority>2</filterpriority>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        #endregion

        /// <summary>
        /// Gets the unique name column.
        /// </summary>
        /// <returns></returns>
        protected virtual string GetUniqueNameColumn()
        {
            return map.GetUniqueNameColumn();
        }

        /// <summary>
        /// Creates the element using data from the dto.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <returns></returns>
        protected virtual TElement CreateElement(TDto dto)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");

            using (RepositorySession session = new RepositorySession())
            {
                TElement element = this.map.Create(dto, session);
                return element;
            }
        }

        /// <summary>
        /// Writes the dto using data from the element.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        protected virtual void WriteDto(TDto dto, TElement element, IRepositorySession session)
        {
            if (dto == null)
                throw new ArgumentNullException("dto");
            if (element == null)
                throw new ArgumentNullException("element");
            if (session == null)
                throw new ArgumentNullException("session");

            map.WriteDto(dto, element, session);
        }

        /// <summary>
        /// Assigns the UID to the element.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="dto">The dto.</param>
        protected virtual void AssignUID(TElement element, TDto dto)
        {
            if (element == null)
                throw new ArgumentNullException("element");
            if (dto == null)
                throw new ArgumentNullException("dto");

            element.Uid = dto.GetColumnValue<long>("uid");
        }

        /// <summary>
        /// Revokes the UID.
        /// </summary>
        /// <param name="element">The element.</param>
        protected virtual void RevokeUID(TElement element)
        {
            if (element == null)
                throw new ArgumentNullException("element");

            element.Uid = 0;
        }


        /// <summary>
        /// Called before the record is added.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        protected virtual void OnBeforeAdd(TElement element, IRepositorySession session)
        {
            //
        }

        /// <summary>
        /// Called after the record is added.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        protected virtual void OnAfterAdd(TElement element, TDto dto, IRepositorySession session)
        {
            //
        }

        /// <summary>
        /// Called before the record is removed.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        protected virtual void OnBeforeRemove(TElement element, IRepositorySession session)
        {
            //
        }

        /// <summary>
        /// Called after the record is removed.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        protected virtual void OnAfterRemove(TElement element, IRepositorySession session)
        {
            //
        }

        /// <summary>
        /// Called before the record is updated.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        protected virtual void OnBeforeUpdate(TElement element, IRepositorySession session)
        {
            //
        }

        /// <summary>
        /// Called after the record is updated.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="dto">The dto.</param>
        /// <param name="session">The session.</param>
        protected virtual void OnAfterUpdate(TElement element, TDto dto, IRepositorySession session)
        {
            //
        }


        /// <summary>
        /// Updates the record that corresponds with the
        /// specified element with data from the specified element.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="session">The session.</param>
        protected virtual void Update(TElement element, IRepositorySession session)
        {
            if (element == null)
                throw new ArgumentNullException("element");
            if (element.Uid == 0)
                throw new ArgumentException("uid of element is not assigned, cannot update element.");
            if (session == null)
                throw new ArgumentNullException("session");

            //using (SharedDbConnectionScope s = new SharedDbConnectionScope())
            //{
            //    using (TransactionScope ts = new TransactionScope())
            //    {

            session.BeginContext(element);

            OnBeforeUpdate(element, session);

            // fetch the element
            TDto dto = (TDto) Activator.CreateInstance(typeof (TDto), "uid", element.Uid);

            // copy data from the element to the dto
            WriteDto(dto, element, session);

            // update the record
            dto.Save();

            OnAfterUpdate(element, dto, session);

            session.EndContext();

            //ts.Complete();
            //    }
            //}
        }
    }
}