using AgriMore.Logistics.Data.MySql.Map;
using AgriMore.Logistics.Domain;
using DtoRole = AgriMore.Logistics.Data.MySql.DTO.Chainrole;

namespace AgriMore.Logistics.Data.MySql.Repository
{
    /// <summary>
    /// 
    /// </summary>
    public class MySqlChainRoleRepository : AbstractMySqlRepository<Role, DtoRole, ChainRoleMap>
    {
    }
}