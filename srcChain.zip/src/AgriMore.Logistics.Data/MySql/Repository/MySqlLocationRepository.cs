using AgriMore.Logistics.Data.MySql.Map;

using Address = AgriMore.Logistics.Domain.Address;
using DtoAddress = AgriMore.Logistics.Data.MySql.DTO.Address;

using Location = AgriMore.Logistics.Domain.Location;
using DtoLocation = AgriMore.Logistics.Data.MySql.DTO.Location;

namespace AgriMore.Logistics.Data.MySql.Repository
{
    /// <summary>
    /// 
    /// </summary>
    public class MySqlLocationRepository : AbstractMySqlRepository<Location, DtoLocation, LocationMap>
    {
    }
}
