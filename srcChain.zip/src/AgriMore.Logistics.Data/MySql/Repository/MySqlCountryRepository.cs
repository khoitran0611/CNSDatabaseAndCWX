using AgriMore.Logistics.Data.MySql.Map;
using AgriMore.Logistics.Domain;
using DtoCountry = AgriMore.Logistics.Data.MySql.DTO.Country;

namespace AgriMore.Logistics.Data.MySql.Repository
{
    /// <summary>
    /// 
    /// </summary>
    public class MySqlCountryRepository : AbstractMySqlRepository<Country, DtoCountry, CountryMap>
    {
    }
}