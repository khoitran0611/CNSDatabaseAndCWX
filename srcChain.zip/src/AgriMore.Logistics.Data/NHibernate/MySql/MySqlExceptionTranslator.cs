using System;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Common.Exception;
using MySql.Data.MySqlClient;
using NHibernate;

namespace AgriMore.Logistics.Data.NHibernate.MySql
{
    /// <summary>
    /// Represents the MySqlExceptionTranslator class.
    /// </summary>
    public class MySqlExceptionTranslator : IDatabaseExceptionTranslator
    {
        private const string NO_TRANSLATION_POSSIBLE =
            "The exception could not be translated. Inspect the innerexception";

        //private const string LOGGER = "AgriMore.Logistics.Common.Log";

        #region IDatabaseExceptionTranslator Members

        /// <summary>
        /// Translates the specified hibernate exception.
        /// </summary>
        /// <param name="hibernateException">The hibernate exception.</param>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId = "AgriMore.Logistics.Common.Exception.UnknownObjectException.#ctor(System.String,System.Exception)")]
        public ObjectException Translate(HibernateException hibernateException)
        {
            MySqlException mySqlException;

            if (hibernateException == null)
            {
                throw new ArgumentNullException("hibernateException");
            }
            else
            {
                mySqlException = hibernateException.InnerException as MySqlException;
            }

            ObjectException objectException = null;


            if (mySqlException != null)
            {
                switch (mySqlException.Number)
                {
                    case 17:
                    // 	SQL Server does not exist or access denied.
                    case 4060:
                    // Invalid Database
                    case 18456:
                        // Login Failed
                        objectException = new ObjectLoginException(mySqlException.Message, mySqlException);
                        break;
                    case 1451:
                        // ForeignKey Violation
                        objectException = new ObjectInUseException(mySqlException);
                        break;
                    case 1205:
                        // DeadLock Victim
                        objectException = new ObjectDeadLockException(mySqlException.Message, mySqlException);
                        break;
                    case 2627:
                    case 2601:
                        // Unique Index/Constriant Violation
                        objectException = new ObjectInUseException(mySqlException.Message, mySqlException);
                        break;
                    default:
                        objectException = new UnknownObjectException(NO_TRANSLATION_POSSIBLE, mySqlException);
                        break;
                }
            }

            // return the error
            return objectException;
        }

        #endregion
    }
}