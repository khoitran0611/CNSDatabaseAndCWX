using System;
using AgriMore.Logistics.Common.Exception;
using NHibernate;
using ObjectNotFoundException=NHibernate.ObjectNotFoundException;

namespace AgriMore.Logistics.Data.NHibernate
{
    /// <summary>
    /// Represents the NHibernateExceptionTranslator class.
    /// </summary>
    public class NHibernateExceptionTranslator : IDatabaseExceptionTranslator
    {
        private const string NO_TRANSLATION_POSSIBLE =
            "The exception could not be translated. Inspect the innerexception";

        #region IDatabaseExceptionTranslator Members

        /// <summary>
        /// Translates the specified hibernate exception.
        /// </summary>
        /// <param name="hibernateException">The hibernate exception.</param>
        /// <returns></returns>
        public ObjectException Translate(HibernateException hibernateException)
        {
            if (hibernateException == null)
            {
                throw new ArgumentNullException("hibernateException");
            }

            ObjectException objectException;
            if (hibernateException.GetType() == typeof(ObjectNotFoundException))
            {
                objectException = new Common.Exception.ObjectNotFoundException(hibernateException);
            }

            else
            {
                objectException = new UnknownObjectException(NO_TRANSLATION_POSSIBLE, hibernateException);
            }

            return objectException;
        }

        #endregion
    }
}
