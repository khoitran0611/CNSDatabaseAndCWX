using AgriMore.Logistics.Common.Exception;
using NHibernate;

namespace AgriMore.Logistics.Data.NHibernate
{
    /// <summary>
    /// Represents the IDatabaseExceptionTranslator interface.
    /// </summary>
    public interface IDatabaseExceptionTranslator
    {
        /// <summary>
        /// Translates the specified hibernate exception.
        /// </summary>
        /// <param name="hibernateException">The hibernate exception.</param>
        /// <returns></returns>
        ObjectException Translate(HibernateException hibernateException);
    }
}
