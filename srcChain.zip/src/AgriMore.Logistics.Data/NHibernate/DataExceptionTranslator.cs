using System;
using AgriMore.Logistics.Common.Exception;
using AgriMore.Logistics.Data.NHibernate.MySql;
using NHibernate;

namespace AgriMore.Logistics.Data.NHibernate
{
    /// <summary>
    /// Represents the DataExceptionTranslator class.
    /// </summary>
    public static class DataExceptionTranslator
    {
        private static IDatabaseExceptionTranslator databaseTranslator = new MySqlExceptionTranslator();
        private static IDatabaseExceptionTranslator nhibernateTranslator = new NHibernateExceptionTranslator();

        /// <summary>
        /// Gets the exception.
        /// </summary>
        /// <param name="hibernateException">The hibernate exception.</param>
        /// <returns></returns>
        public static ObjectException GetException(HibernateException hibernateException)
        {
            ObjectException de;

            if (hibernateException == null)
            {
                throw new ArgumentNullException("hibernateException");
            }
            if (hibernateException.GetType() == typeof (ADOException))
            {
                de = databaseTranslator.Translate(hibernateException);
            }
            else
            {
                de = nhibernateTranslator.Translate(hibernateException);
            }
            return de;
        }
    }
}