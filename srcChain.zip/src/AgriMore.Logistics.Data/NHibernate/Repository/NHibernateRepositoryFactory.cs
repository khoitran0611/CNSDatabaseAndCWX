using AgriMore.Logistics.Data.NHibernate.Transaction;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Data.NHibernate.Repository
{
    /// <summary>
    /// Represents the NHibernateRepositoryFactory class.
    /// </summary>
    public class NHibernateRepositoryFactory : IRepositoryFactory
    {
        #region IRepositoryFactory Members

        /// <summary>
        /// Gets the treatment repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Treatment> GetTreatmentRepository()
        {
            return CreateRepository<Treatment>();
        }

        #endregion

        /// <summary>
        /// Gets the identification repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Identification> GetIdentificationRepository()
        {
            return CreateRepository<Identification>();
        }


        /// <summary>
        /// Gets the exposure document repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ExposureDocument> GetExposureDocumentRepository()
        {
            return CreateRepository<ExposureDocument>();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<PackageType> GetPackageTypeRepository()
        {
            return CreateRepository<PackageType>();
        }

        /// <summary>
        /// Gets the treatment type repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<TreatmentType> GetTreatmentTypeRepository()
        {
            return CreateRepository<TreatmentType>();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<TreatmentTypeCategory> GetTreatmentTypeCategoryRepository()
        {
            return CreateRepository<TreatmentTypeCategory>();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<User> GetUserRepository()
        {
            return CreateRepository<User>();
        }

        /// <summary>
        /// Gets the exposure repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Exposure> GetExposureRepository()
        {
            return CreateRepository<Exposure>();
        }

        /// <summary>
        /// Gets the exposure type repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ExposureType> GetExposureTypeRepository()
        {
            return CreateRepository<ExposureType>();
        }

        /// <summary>
        /// retrieve a ChainEntity repository
        ///</summary>
        /// <returns></returns>
        public IRepository<ChainEntity> GetChainEntityRepository()
        {
            return CreateRepository<ChainEntity>();
        }


        /// <summary>
        /// Gets the role repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Role> GetRoleRepository()
        {
            return CreateRepository<Role>();
        }

        /// <summary>
        /// retrieve a Location repository
        /// </summary>
        /// <returns></returns>
        public IRepository<Location> GetLocationRepository()
        {
            return CreateRepository<Location>();
        }

        /// <summary>
        /// Gets the address repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Address> GetAddressRepository()
        {
            return CreateRepository<Address>();
        }

        /// <summary>
        /// Gets the shipment repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Shipment> GetShipmentRepository()
        {
            return CreateRepository<Shipment>();
        }

        /// <summary>
        /// Gets the package repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Package> GetPackageRepository()
        {
            return CreateRepository<Package>();
        }

        /// <summary>
        /// Gets the disposal package repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<DisposalPackage> GetDisposalPackageRepository()
        {
            return CreateRepository<DisposalPackage>();
        }

        /// <summary>
        /// Gets the processing step repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ProcessingStep> GetProcessingStepRepository()
        {
            return CreateRepository<ProcessingStep>();
        }

        /// <summary>
        /// Creates the repository.
        /// </summary>
        /// <typeparam name="TElement">The type of the element.</typeparam>
        /// <returns></returns>
        public IRepository<TElement> CreateRepository<TElement>() where TElement : class, IIdentifyable
        {
            return new NHibernateRepository<TElement>();
        }


        /// <summary>
        /// Gets the cash register repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<CashRegister> GetCashRegisterRepository()
        {
            return new NHibernateRepository<CashRegister>();
        }

        #region IRepositoryFactory Members

        /// <summary>
        /// Gets the repack package relationship repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<RepackPackageRelationship> GetRepackPackageRelationshipRepository()
        {
            return new NHibernateRepository<RepackPackageRelationship>();
        }

        #endregion

        /// <summary>
        /// Creates the transaction manager.
        /// </summary>
        /// <returns></returns>
        public ITransactionManager CreateTransactionManager()
        {
            return new NHibernateTransactionManager();
        }

        /// <summary>
        /// Initializes the test data.
        /// </summary>
        public void InitializeTestData()
        {
            InitializeStaticMembersOfDomain();

            //ClearAll();

            new DataFiller().Fill();
        }

        private static void InitializeStaticMembersOfDomain()
        {
            Role.Initialize();
        }

        #region IRepositoryFactory Members


        /// <summary>
        /// Gets the transport equipment repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<TransportEquipment> GetTransportEquipmentRepository()
        {
            return CreateRepository<TransportEquipment>();
        }


        #endregion

        #region IRepositoryFactory Members


        /// <summary>
        /// Gets the agri more time zone repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<AgriMoreTimeZone> GetAgriMoreTimeZoneRepository()
        {
            return CreateRepository<AgriMoreTimeZone>();
        }

        #endregion

        #region IRepositoryFactory Members

        /// <summary>
        /// Gets the country repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Country> GetCountryRepository()
        {
            return CreateRepository<Country>();
        }


        /// <summary>
        /// Gets the package type category repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<PackageTypeCategory> GetPackageTypeCategoryRepository()
        {
            return CreateRepository<PackageTypeCategory>();
        }

        /// <summary>
        /// Gets the packing material repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<PackingMaterial> GetPackingMaterialRepository()
        {
            return CreateRepository<PackingMaterial>();
        }

        /// <summary>
        /// Gets the unit of measurement repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<UnitOfMeasurement> GetUnitOfMeasurementRepository()
        {
            return CreateRepository<UnitOfMeasurement>();
        }

        #endregion


        public IRepository<PackagePackagingWasteInfo> GetPackagePackagingWasteInfoRepository()
        {
            return CreateRepository<PackagePackagingWasteInfo>();
        }

        public IRepository<ExposureDefine> GetExposureDefineRepository()
        {
            return CreateRepository<ExposureDefine>();
        }


        public IRepository<WasteDisposalPackageTracing> GetWasteDisposalPackageTracingRepository()
        {
            return CreateRepository<WasteDisposalPackageTracing>();
        }

        public IRepository<WasteDisposalDisposalPackage> GetWasteDisposalDisposalPackageRepository()
        {
            return CreateRepository<WasteDisposalDisposalPackage>();
        }

        public IRepository<WasteDisposalExpirePackage> GetWasteDisposalExpirePackageRepository()
        {
            return CreateRepository<WasteDisposalExpirePackage>();
        }


        public IRepository<Decomposition> GetDecompositionRepository()
        {
            return CreateRepository<Decomposition>();
        }

        public IRepository<DecompositionInfo> GetDecompositionInfoRepository()
        {
            return CreateRepository<DecompositionInfo>();
        }
    }
}