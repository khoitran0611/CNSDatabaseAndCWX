using System.Collections;
using System.Diagnostics.CodeAnalysis;
using NHibernate;
using NHibernateObjectNotFoundException = NHibernate.ObjectNotFoundException;
using NHibernateAdoException = NHibernate.ADOException;

namespace AgriMore.Logistics.Data.NHibernate
{
    /// <summary>
    /// Represents the NHibernateDao class.
    /// </summary>
    public class NHibernateDao
    {
        private bool initiatedTransaction;

        /// <summary>
        /// Represents the Action enumeration.
        /// </summary>
        protected enum Action
        {
            /// <summary>
            /// Save
            /// </summary>
            Save,
            /// <summary>
            /// Update
            /// </summary>
            Update
        }

        /// <summary>
        /// Gets the N hibernate session.
        /// </summary>
        /// <value>Get access to the NHibernate session in the NHibernateHttpModule class.</value>
        public ISession NHibernateSession
        {
            get
            {
                return NHibernateHttpModule.GetSession;
            }
        }

        /// <summary>
        /// Gets the object of type T with the id.
        /// If the item cannot be found. Translate the exception to one the caller can work with.
        /// </summary>
        /// <param name="id">The id.</param>
        /// <returns></returns>
        [SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
        public T Get<T>(long id)
        {
            try
            {
                return (T) NHibernateSession.Load(typeof (T), id);
            }
            catch (HibernateException e)
            {
                throw DataExceptionTranslator.GetException(e);
            }
        }

        /// <summary>
        /// Gets all objects of type T.
        /// </summary>
        /// <returns></returns>
        [
            SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate"),
                SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
        public ICollection GetAll<T>()
        {
            return NHibernateSession.CreateCriteria(typeof (T)).SetCacheable(true).List();
        }

        /// <summary>
        /// Save the specified object.
        /// </summary>
        /// <param name="transient">The transient.</param>
        public void Save<T>(T transient)
        {
            try
            {
                if (!NHibernateHttpModule.TransactionPresent)
                {
                    NHibernateHttpModule.BeginTransaction();
                    initiatedTransaction = true;
                }

                NHibernateSession.SaveOrUpdate(transient);

                if (NHibernateHttpModule.TransactionPresent)
                {
                    if (initiatedTransaction)
                    {
                        NHibernateHttpModule.CommitTransaction();
                        initiatedTransaction = false;
                    }
                }
            }
            catch (HibernateException e)
            {
                if (NHibernateHttpModule.SessionPresent)
                {
                    if (NHibernateHttpModule.TransactionPresent)
                    {
                        NHibernateHttpModule.RollbackTransaction();
                    }
                }
                throw DataExceptionTranslator.GetException(e);
            }
        }

        /// <summary>
        /// Deletes the specified entity.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity">The entity.</param>
        public void Delete<T>(T entity)
        {
            try
            {
                NHibernateHttpModule.BeginTransaction();

                NHibernateSession.Delete(entity);

                NHibernateHttpModule.CommitTransaction();
            }

            catch (HibernateException e)
            {
                if (NHibernateHttpModule.SessionPresent)
                {
                    NHibernateHttpModule.RollbackTransaction();
                }

                throw DataExceptionTranslator.GetException(e);
            }
        }
    }
}