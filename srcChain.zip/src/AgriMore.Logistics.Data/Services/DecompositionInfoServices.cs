﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.ThirdPartyEntities;

namespace AgriMore.Logistics.Data.Services
{
    public class DecompositionInfoServices
    {
        private static readonly IRepositoryFactory Factory = new NHibernateRepositoryFactory();

        public static IList<string> GetYear(long chainId)
        {
            IList<string> lstYears = new List<string>();
            string queryString = string.Format("select distinct year(DecomposedDate) as yr from decomposition_keyfigureinfo where DecomposedByChainId = {0} order by yr", chainId);
            System.Data.IDbCommand cmd = NHibernateHttpModule.GetSession.Connection.CreateCommand();
            cmd.CommandText = queryString;

            using (System.Data.IDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    var year = Convert.ToString(reader[0]);
                    if (!string.IsNullOrEmpty(year)) lstYears.Add(year);
                }
            }

            return lstYears;
        }

        public static IList<DecompositionInfo> GetDecompositionInfo(long rootProdId, long chainId, int year)
        {
            var queryString = "SELECT {dinf.*} FROM `decomposition_keyfigureinfo` {dinf} WHERE {dinf}.DecomposedByChainId = " + chainId +
                " AND {dinf}.RootProdId = " + rootProdId + " AND YEAR({dinf}.DecomposedDate) = " + year;

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateSQLQuery(queryString, "dinf", typeof(DecompositionInfo));
            return iQuery.List().Cast<DecompositionInfo>().ToList();
        }

        public static IList<DecompositionInfo> GetDecompositionInfo(long rootProdId, long chainId, DateTime fromDate, DateTime toDate, string selOrgId = "")
        {
            var queryString = "SELECT {dinf.*} FROM `decomposition_keyfigureinfo` {dinf} WHERE {dinf}.DecomposedByChainId = " + chainId +
                " AND {dinf}.RootProdId = " + rootProdId + " AND DATE({dinf}.DecomposedDate) >= :fromDate AND DATE({dinf}.DecomposedDate) <= :todate";
            if (!string.IsNullOrEmpty(selOrgId)) queryString += " AND {dinf}.KeyFigure4OrgId = '" + selOrgId + "'";

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateSQLQuery(queryString, "dinf", typeof(DecompositionInfo));
            iQuery.SetParameter("fromDate", fromDate.Date);
            iQuery.SetParameter("todate", toDate);
            return iQuery.List().Cast<DecompositionInfo>().ToList();
        }

        public static IList<DecompositionInfo> GetDecompositionInfo(long rootProdId, DateTime fromDate, DateTime toDate, string[] selOrgIds)
        {
            var queryString = "SELECT {dinf.*} FROM `decomposition_keyfigureinfo` {dinf} WHERE " +
                " {dinf}.RootProdId = " + rootProdId + " AND DATE({dinf}.DecomposedDate) >= :fromDate AND DATE({dinf}.DecomposedDate) <= :todate";
            if (selOrgIds.Length > 0)
            {
                string strOrgIds = string.Format("'{0}'", string.Join("','", selOrgIds));
                queryString += " AND {dinf}.KeyFigure4OrgId IN (" + strOrgIds + ")";
            }

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateSQLQuery(queryString, "dinf", typeof(DecompositionInfo));
            iQuery.SetParameter("fromDate", fromDate.Date);
            iQuery.SetParameter("todate", toDate);
            return iQuery.List().Cast<DecompositionInfo>().ToList();
        }

        public static IList<DecompositionInfo> GetDecompositionInfoFromProd(long frmProdId, DateTime fromDate, DateTime toDate, string[] selOrgIds)
        {
            bool isSelectedAllChild = false;
            string fromProdIds = frmProdId.ToString();
            var lstDecompositionInfo = new List<DecompositionInfo>();

            while (!isSelectedAllChild)
            {
                var queryString = "SELECT {dinf.*} FROM `decomposition_keyfigureinfo` {dinf} WHERE " +
                " {dinf}.FromProdId in (" + fromProdIds + ") AND DATE({dinf}.DecomposedDate) >= :fromDate AND DATE({dinf}.DecomposedDate) <= :todate";
                if (selOrgIds.Length > 0)
                {
                    string strOrgIds = string.Format("'{0}'", string.Join("','", selOrgIds));
                    queryString += " AND {dinf}.KeyFigure4OrgId IN (" + strOrgIds + ")";
                }

                var session = NHibernateHttpModule.GetSession;
                var iQuery = session.CreateSQLQuery(queryString, "dinf", typeof(DecompositionInfo));
                iQuery.SetParameter("fromDate", fromDate.Date);
                iQuery.SetParameter("todate", toDate);
                var result = iQuery.List().Cast<DecompositionInfo>().ToList();

                if (result.Count > 0)
                {
                    lstDecompositionInfo.AddRange(result);
                    fromProdIds = string.Join(",", result.Select(it => it.ToProdId.ToString()).Distinct().ToArray());
                }
                else
                    isSelectedAllChild = true;
            }
            return lstDecompositionInfo;
        }

        public static IDictionary<string, IDictionary<int, decimal>> BuildWasteStreamGraphInfo(long chainId, long prodId, DateTime fromDate, DateTime toDate,
            string selOrgId = "", string curLangCode = "en-US")
        {
            IDictionary<long, string> dicProdIdName = new Dictionary<long, string>();
            IDictionary<string, IDictionary<int, decimal>> dicCharts = new Dictionary<string, IDictionary<int, decimal>>();

            var lstDecmpInfoInYears = GetDecompositionInfo(prodId, chainId, fromDate, toDate, selOrgId);
            var fromProdIds = lstDecmpInfoInYears.Where(it => it.FromProdId != prodId).Select(it => it.FromProdId).Distinct().ToList();
            var fromProds = ProductServices.GetByIds(string.Join(",", Array.ConvertAll(fromProdIds.ToArray(), Convert.ToString)));

            var firstChildIds = lstDecmpInfoInYears.Where(it => it.FromProdId == prodId).Select(it => it.ToProdId).Distinct().ToList();
            var firstChilds = ProductServices.GetByIds(string.Join(",", Array.ConvertAll(firstChildIds.ToArray(), Convert.ToString)));

            foreach (var product in firstChilds)
            {
                var prodName = product.GetName(curLangCode);
                dicProdIdName.Add(product.Uid, prodName);
            }

            foreach (var prod in fromProds)
            {
                var nextChildIds = lstDecmpInfoInYears.Where(it => it.FromProdId == prod.Uid).Select(it => it.ToProdId).Distinct().ToList();
                var nextChilds = ProductServices.GetByIds(string.Join(",", Array.ConvertAll(nextChildIds.ToArray(), Convert.ToString)));
                if (!nextChilds.Any()) continue;

                foreach (var product in nextChilds)
                {
                    var prodName = product.GetName(curLangCode);
                    dicProdIdName.Add(product.Uid, prodName);
                }
            }

            var lstMonths = lstDecmpInfoInYears.Select(it => it.DecomposedDate.Month).Distinct().OrderBy(it => it).ToList();
            foreach (var key in dicProdIdName.Keys)
            {
                IDictionary<int, decimal> dicChartItem = new Dictionary<int, decimal>();
                foreach (var month in lstMonths)
                {
                    //var monthName = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(month);
                    var lstTotalInfo = lstDecmpInfoInYears.Where(it => it.ToProdId == key && it.DecomposedDate.Month == month).ToList();
                    decimal valTotal = lstTotalInfo.Sum(info => (info.ActualWeight > 0 ? info.ActualWeight : info.FigureWeight));
                    dicChartItem.Add(month, valTotal);
                }
                dicCharts.Add(dicProdIdName[key], dicChartItem);
            }

            return dicCharts;
        }

        public static IDictionary<string, IDictionary<DateTime, IList<DecompositionInfo>>> BuildWasteStreamGraphInfo(long chainId, long prodId, DateTime fromDate, DateTime toDate,
            string[] selOrgIds, string curLangCode = "en-US")
        {
            IDictionary<long, string> dicProdIdName = new Dictionary<long, string>();
            IDictionary<string, IDictionary<DateTime, IList<DecompositionInfo>>> dicCharts = new Dictionary<string, IDictionary<DateTime, IList<DecompositionInfo>>>();

            var lstDecmpInfoInYears = GetDecompositionInfoFromProd(prodId, fromDate, toDate, selOrgIds); //GetDecompositionInfo(prodId, fromDate, toDate, selOrgIds);
            var fromProdIds = lstDecmpInfoInYears.Where(it => it.FromProdId != prodId).Select(it => it.FromProdId).Distinct().ToList();
            var fromProds = ProductServices.GetByIds(string.Join(",", Array.ConvertAll(fromProdIds.ToArray(), Convert.ToString)));

            var firstChildIds = lstDecmpInfoInYears.Where(it => it.FromProdId == prodId).Select(it => it.ToProdId).Distinct().ToList();
            var firstChilds = ProductServices.GetByIds(string.Join(",", Array.ConvertAll(firstChildIds.ToArray(), Convert.ToString)));

            foreach (var product in firstChilds)
            {
                var prodName = product.GetName(curLangCode);
                dicProdIdName.Add(product.Uid, prodName);
            }

            foreach (var prod in fromProds)
            {
                var nextChildIds = lstDecmpInfoInYears.Where(it => it.FromProdId == prod.Uid).Select(it => it.ToProdId).Distinct().ToList();
                var nextChilds = ProductServices.GetByIds(string.Join(",", Array.ConvertAll(nextChildIds.ToArray(), Convert.ToString)));
                if (!nextChilds.Any()) continue;

                foreach (var product in nextChilds)
                {
                    var prodName = product.GetName(curLangCode);
                    dicProdIdName.Add(product.Uid, prodName);
                }
            }

            //var lstMonths = lstDecmpInfoInYears.Select(it => it.DecomposedDate.Month).Distinct().OrderBy(it => it).ToList();
            var lstDates = lstDecmpInfoInYears.Select(it => it.DecomposedDate.Date).Distinct().OrderBy(it => it).ToList();
            foreach (var key in dicProdIdName.Keys)
            {
                IDictionary<DateTime, IList<DecompositionInfo>> dicChartItem = new Dictionary<DateTime, IList<DecompositionInfo>>();
                //foreach (var month in lstMonths)
                foreach (var date in lstDates)
                {
                    //var monthName = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(month);
                    var lstTotalInfo = lstDecmpInfoInYears.Where(it => it.ToProdId == key && it.DecomposedDate.Date == date).ToList();
                    //decimal valTotal = lstTotalInfo.Sum(info => (info.ActualWeight > 0 ? info.ActualWeight : info.FigureWeight));
                    //dicChartItem.Add(month, valTotal);
                    dicChartItem.Add(date, lstTotalInfo);
                }
                dicCharts.Add(dicProdIdName[key], dicChartItem);
            }

            return dicCharts;
        }

        public static string BuildWasteStreamRptInfo(long chainId, long prodId, DateTime fromDate, DateTime toDate,
            string selOrgIds = "", string curLangCode = "en-US", bool forDownload = false)
        {
            var strReport = new StringBuilder();
            var strCols = new StringBuilder("<Cols>");
            var strGroups = new StringBuilder("<Groups>");
            var chainEntity = Factory.GetChainEntityRepository().GetOne(chainId);

            int numberCol = 0;
            var lstProdInChain = new List<Product>();
            var lstDecmpInfoInYears = GetDecompositionInfo(prodId, fromDate, toDate, selOrgIds.Split(','));
            if (lstDecmpInfoInYears == null || lstDecmpInfoInYears.Count <= 0) return string.Empty;

            var fromProdIds = lstDecmpInfoInYears.Where(it => it.FromProdId != prodId).Select(it => it.FromProdId).Distinct().ToList();
            var fromProds = ProductServices.GetByIds(string.Join(",", Array.ConvertAll(fromProdIds.ToArray(), Convert.ToString)));

            var firstChildIds = lstDecmpInfoInYears.Where(it => it.FromProdId == prodId).Select(it => it.ToProdId).Distinct().ToList();
            var firstChilds = ProductServices.GetByIds(string.Join(",", Array.ConvertAll(firstChildIds.ToArray(), Convert.ToString)));

            var firstPart = firstChilds.Count() * 2 + 1;
            if (!forDownload)
                strGroups.Append(string.Format("<group name=\"QuantityPackagingTEXT\" colspan=\"{0}\"/>", firstChilds.Count() * 2 + 1));
            else
            {
                for (int i = 1; i <= firstPart; i++)
                    strGroups.Append("<group name=\"QuantityPackagingTEXT\" colspan=\"1\"/>");
            }
            numberCol += firstPart;

            strCols.Append("<col name=\"Total\" colspan=\"1\" val4=\"\" />");
            foreach (var product in firstChilds)
            {
                if (!forDownload)
                    strCols.Append(string.Format("<col name=\"{0}\" colspan=\"2\" />", product.GetName(curLangCode)));
                else
                {
                    strCols.Append(string.Format("<col name=\"{0}\" colspan=\"1\" val4=\"fg\" />", product.GetName(curLangCode)));
                    strCols.Append(string.Format("<col name=\"{0}\" colspan=\"1\" val4=\"act\" />", product.GetName(curLangCode)));
                }
                lstProdInChain.Add(product);
            }

            foreach (var prod in fromProds)
            {
                var nextChildIds = lstDecmpInfoInYears.Where(it => it.FromProdId == prod.Uid).Select(it => it.ToProdId).Distinct().ToList();
                var nextChilds = ProductServices.GetByIds(string.Join(",", Array.ConvertAll(nextChildIds.ToArray(), Convert.ToString)));
                if (!nextChilds.Any()) continue;

                var nextChildCol = nextChilds.Count * 2;
                numberCol += nextChildCol;
                if (!forDownload)
                    strGroups.Append(string.Format("<group name=\"SubstreamsTEXT {0}\" colspan=\"{1}\"/>", prod.GetName(curLangCode), nextChilds.Count() * 2));
                else
                {
                    for (int i = 1; i <= nextChildCol; i++)
                        strGroups.Append(string.Format("<group name=\"SubstreamsTEXT {0}\" colspan=\"1\"/>", prod.GetName(curLangCode)));
                }
                foreach (var product in nextChilds)
                {
                    if (!forDownload)
                        strCols.Append(string.Format("<col name=\"{0}\" colspan=\"2\"/>", product.GetName(curLangCode)));
                    else
                    {
                        strCols.Append(string.Format("<col name=\"{0}\" colspan=\"1\" val4=\"fg\" />", product.GetName(curLangCode)));
                        strCols.Append(string.Format("<col name=\"{0}\" colspan=\"1\" val4=\"act\" />", product.GetName(curLangCode)));
                    }
                    lstProdInChain.Add(product);
                }
            }
            strCols.Append("</Cols>");
            strGroups.Append("</Groups>");

            var strHeader = new StringBuilder(string.Format("<Header number-col=\"{0}\" fordownload=\"{1}\">", numberCol + 1, (forDownload ? "1" : "0")));
            strHeader.Append(string.Format("<DecomposedOrg><![CDATA[{0}]]></DecomposedOrg>", chainEntity.Name));
            strHeader.Append("<ActualWeightText>TEXT_ActualWeight</ActualWeightText>");
            strHeader.Append("<FigureWeightText>TEXT_FigureWeight</FigureWeightText>");
            strHeader.Append(strGroups).Append(strCols);
            strHeader.Append("</Header>");

            strReport.Append("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            strReport.Append(string.Format("<WasteStreamRpt download=\"{0}\">", forDownload ? 1 : 0));

            var strMonths = new StringBuilder("<Months>");
            var lstOrgIds = lstDecmpInfoInYears.Select(it => it.KeyFigure4OrgId).Distinct().ToList();
            var lstOrgs = OrganizationServices.GetByListOrgId(lstOrgIds.ToArray());
            if (!forDownload)
            {
                var lstMonths = lstDecmpInfoInYears.Select(it => it.DecomposedDate.Month).Distinct().OrderBy(it => it).ToList();
                foreach (var month in lstMonths)
                {
                    decimal valTotalMonth = 0;
                    var iDicTotal = new Dictionary<long, decimal>();
                    var iDicTotalActual = new Dictionary<long, decimal>();
                    var monthName = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(month);
                    strMonths.Append(string.Format("<Month name=\"{0}\" val=\"{1}\">", monthName, month));
                    strMonths.Append("<Organizations>");
                    foreach (var orgId in lstOrgIds)
                    {
                        var matchOrg = lstOrgs.SingleOrDefault(it => it.Uid.Equals(orgId));
                        if (matchOrg == null) continue;

                        strMonths.Append(string.Format("<Org name=\"{0}\">", matchOrg.Name));
                        strMonths.Append("<Cols>");

                        var lstTotalInfo = lstDecmpInfoInYears.Where(it => it.KeyFigure4OrgId.Equals(orgId)
                            && firstChilds.Any(fch => fch.Uid == it.ToProdId) && it.DecomposedDate.Month == month).ToList();

                        decimal valTotal = lstTotalInfo.Sum(info => (info.ActualWeight > 0 ? info.ActualWeight : info.FigureWeight));
                        strMonths.Append(string.Format("<col val=\"{0}\"/>", valTotal));
                        valTotalMonth += valTotal;

                        foreach (var prod in lstProdInChain)
                        {
                            var lstMatchInfo = lstDecmpInfoInYears.Where(it => it.ToProdId == prod.Uid && it.KeyFigure4OrgId.Equals(orgId) && it.DecomposedDate.Month == month).ToList();
                            decimal val = lstMatchInfo.Sum(info => info.FigureWeight);
                            decimal actualVal = lstMatchInfo.Sum(info => info.ActualWeight);

                            strMonths.Append(string.Format("<col val=\"{0}\"/>", val));
                            strMonths.Append(string.Format("<col val=\"{0}\"/>", actualVal));

                            if (iDicTotal.ContainsKey(prod.Uid))
                            {
                                iDicTotal[prod.Uid] += val;
                                iDicTotalActual[prod.Uid] += actualVal;
                            }
                            else
                            {
                                iDicTotal.Add(prod.Uid, val);
                                iDicTotalActual.Add(prod.Uid, actualVal);
                            }
                        }
                        strMonths.Append("</Cols>");
                        strMonths.Append("</Org>");
                    }
                    strMonths.Append("</Organizations>");
                    strMonths.Append("<Total><Cols>");

                    strMonths.Append(string.Format("<col val=\"{0}\"/>", valTotalMonth));
                    foreach (var key in iDicTotal.Keys)
                    {
                        strMonths.Append(string.Format("<col val=\"{0}\"/>", iDicTotal[key]));
                        strMonths.Append(string.Format("<col val=\"{0}\"/>", iDicTotalActual[key]));
                    }
                    strMonths.Append("</Cols></Total>");
                    strMonths.Append("</Month>");
                }
            }
            else
            {
                decimal valTotalMonth = 0;
                var iDicTotal = new Dictionary<long, decimal>();
                var iDicTotalActual = new Dictionary<long, decimal>();
                strMonths.Append(string.Format("<Month name=\"{0}\" val=\"\">", string.Format("{0:dd-MM-yyyy} - {1:dd-MM-yyyy}", fromDate, toDate)));
                strMonths.Append("<Organizations>");
                foreach (var orgId in lstOrgIds)
                {
                    var matchOrg = lstOrgs.SingleOrDefault(it => it.Uid.Equals(orgId));
                    if (matchOrg == null) continue;

                    strMonths.Append(string.Format("<Org name=\"{0}\">", matchOrg.Name));
                    strMonths.Append("<Cols>");

                    var lstTotalInfo = lstDecmpInfoInYears.Where(it => it.KeyFigure4OrgId.Equals(orgId) && firstChilds.Any(fch => fch.Uid == it.ToProdId)).ToList();

                    decimal valTotal = lstTotalInfo.Sum(info => (info.ActualWeight > 0 ? info.ActualWeight : info.FigureWeight));
                    strMonths.Append(string.Format("<col val=\"{0}\"/>", valTotal));
                    valTotalMonth += valTotal;

                    foreach (var prod in lstProdInChain)
                    {
                        var lstMatchInfo = lstDecmpInfoInYears.Where(it => it.ToProdId == prod.Uid && it.KeyFigure4OrgId.Equals(orgId)).ToList();
                        decimal val = lstMatchInfo.Sum(info => info.FigureWeight);
                        decimal actualVal = lstMatchInfo.Sum(info => info.ActualWeight);

                        strMonths.Append(string.Format("<col val=\"{0}\"/>", val));
                        strMonths.Append(string.Format("<col val=\"{0}\"/>", actualVal));

                        if (iDicTotal.ContainsKey(prod.Uid))
                        {
                            iDicTotal[prod.Uid] += val;
                            iDicTotalActual[prod.Uid] += actualVal;
                        }
                        else
                        {
                            iDicTotal.Add(prod.Uid, val);
                            iDicTotalActual.Add(prod.Uid, actualVal);
                        }
                    }
                    strMonths.Append("</Cols>");
                    strMonths.Append("</Org>");
                }
                strMonths.Append("</Organizations>");
                strMonths.Append("<Total><Cols>");

                strMonths.Append(string.Format("<col val=\"{0}\"/>", valTotalMonth));
                foreach (var key in iDicTotal.Keys)
                {
                    strMonths.Append(string.Format("<col val=\"{0}\"/>", iDicTotal[key]));
                    strMonths.Append(string.Format("<col val=\"{0}\"/>", iDicTotalActual[key]));
                }
                strMonths.Append("</Cols></Total>");
                strMonths.Append("</Month>");
            }
            strMonths.Append("</Months>");

            strReport.Append(strHeader).Append(strMonths);
            strReport.Append("</WasteStreamRpt>");
            return strReport.ToString();
        }
    }
}
