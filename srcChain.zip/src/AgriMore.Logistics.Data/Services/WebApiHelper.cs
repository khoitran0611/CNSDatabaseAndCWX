﻿using Newtonsoft.Json;
using System.Configuration;
using System.Text;

namespace AgriMore.Logistics.Data.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class WebApiHelper
    {
        /// <summary>
        /// The Matching API URL
        /// </summary>
        public static string MatchingApiUrl = ConfigurationManager.AppSettings["MatchingApiUrl"];

        /// <summary>
        /// Gets the asynchronous.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="url">The URL.</param>
        /// <returns></returns>
        public static T Get<T>(string url)
        {
            using (var client = new System.Net.WebClient())
            {
                client.Headers.Add("content-type", "application/json");
                var result = Encoding.ASCII.GetString(client.DownloadData(url));
                return JsonConvert.DeserializeObject<T>(result);
            }
        }

        /// <summary>
        /// Posts the and get resp.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="url">The URL.</param>
        /// <param name="reqParam">The req parameter.</param>
        /// <returns></returns>
        public static T PostAndGetResp<T>(string url, object reqParam)
        {
            using (var client = new System.Net.WebClient())
            {
                var sz = JsonConvert.SerializeObject(reqParam);
                client.Headers.Add("content-type", "application/json");
                var result = Encoding.ASCII.GetString(client.UploadData(url, "POST", Encoding.Default.GetBytes(sz)));
                return JsonConvert.DeserializeObject<T>(result);
            }
        }

        /// <summary>
        /// Posts the specified URL.
        /// </summary>
        /// <param name="url">The URL.</param>
        /// <param name="reqParam">The req parameter.</param>
        public static void Post(string url, object reqParam)
        {
            using (var client = new System.Net.WebClient())
            {
                var sz = JsonConvert.SerializeObject(reqParam);
                client.Headers.Add("content-type", "application/json");
                var result = Encoding.ASCII.GetString(client.UploadData(url, "POST", Encoding.Default.GetBytes(sz)));
            }
        }
    }
}
