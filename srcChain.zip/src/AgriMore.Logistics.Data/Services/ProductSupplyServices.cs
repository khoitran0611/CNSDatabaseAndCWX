﻿using System.Collections.Generic;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Data.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class ProductSupplyServices
    {
        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="prodId">The product identifier.</param>
        /// <returns></returns>
        public static ProductSupply GetById(long prodId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "ProductSupply/Get", prodId);
            return WebApiHelper.Get<ProductSupply>(requestUrl);
        }

        /// <summary>
        /// Gets the root product supply.
        /// </summary>
        /// <param name="childId">The child identifier.</param>
        /// <returns></returns>
        public static ProductSupply GetRootProductSupply(long childId)
        {
            var requestUrl = string.Format("{0}/{1}/?childId={2}", WebApiHelper.MatchingApiUrl, "ProductSupply/GetRootProductSupply", childId);
            return WebApiHelper.Get<ProductSupply>(requestUrl);
        }

        /// <summary>
        /// Gets the by ids.
        /// </summary>
        /// <param name="ids">The ids.</param>
        /// <returns></returns>
        public static IList<ProductSupply> GetByIds(string ids)
        {
            var requestUrl = string.Format("{0}/{1}/?ids={2}", WebApiHelper.MatchingApiUrl, "ProductSupply/GetByIds", ids);
            return WebApiHelper.Get<IList<ProductSupply>>(requestUrl);
        }
        
        /// <summary>
        /// Gets the unpacked products.
        /// </summary>
        /// <returns></returns>
        public static IList<ProductSupply> GetUnpackedProducts(long chainEntityId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "ProductSupply/GetUnpackedProducts", chainEntityId);
            return WebApiHelper.Get<IList<ProductSupply>>(requestUrl);
        }

        /// <summary>
        /// Creates the or update.
        /// </summary>
        /// <param name="prodSupply">The product supply.</param>
        /// <returns></returns>
        public static ProductSupply CreateOrUpdate(ProductSupply prodSupply)
        {
            var requestUrl = string.Format("{0}/{1}", WebApiHelper.MatchingApiUrl, "ProductSupply/Post");
            return WebApiHelper.PostAndGetResp<ProductSupply>(requestUrl, prodSupply);
        }

        public static void ResetGenerationInv(ProductSupply prodSupply)
        {
            var requestUrl = string.Format("{0}/{1}", WebApiHelper.MatchingApiUrl, "ProductSupply/ResetGenerationDecomposeInv");
            WebApiHelper.Post(requestUrl, prodSupply);
        }
        
        /// <summary>
        /// Generates the shipment.
        /// </summary>
        /// <param name="shipmentInfo">The shipment information.</param>
        public static void GenerateShipment(ShipmentInfo shipmentInfo)
        {
            var requestUrl = string.Format("{0}/{1}", WebApiHelper.MatchingApiUrl, "ProductSupply/GenerateShipment4Products");
            WebApiHelper.Post(requestUrl, shipmentInfo);
        }

        public static void AddProductTreatmentInvoices(string treatmentInvoiceDatas)
        {
            var requestUrl = string.Format("{0}/{1}", WebApiHelper.MatchingApiUrl, "ProductSupply/AddProductTreatmentInvoices");
            WebApiHelper.Post(requestUrl, treatmentInvoiceDatas);
        }

        /// <summary>
        /// packagingInvoiceInfo = "packageType_id|packagetype_name|#OfPackages"
        /// </summary>
        /// <param name="packagingInvoiceInfo"></param>
        public static void UpdateDataForPackagingInvoiceInMatching(string packagingInvoiceInfo)
        {
            var requestUrl = string.Format("{0}/{1}", WebApiHelper.MatchingApiUrl, "ProductSupply/UpdateDataForPackagingInvoiceInMatching");
            WebApiHelper.Post(requestUrl, packagingInvoiceInfo);
        }

        public static List<AgriMore.Logistics.Domain.ThirdPartyEntities.ChainEntity1> GetByChainEntitiesInGoOs(string chainEntityId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "ProductSupply/GetByChainEntitiesInGoOs", chainEntityId);
            return WebApiHelper.Get<List<AgriMore.Logistics.Domain.ThirdPartyEntities.ChainEntity1>>(requestUrl);
        }
    }
}
