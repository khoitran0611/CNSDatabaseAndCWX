﻿using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using System.Collections.Generic;
using System.Linq;

namespace AgriMore.Logistics.Data.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class PackageServices
    {
        /// <summary>
        /// Gets the package in location.
        /// </summary>
        /// <param name="lctId">The LCT identifier.</param>
        /// <returns></returns>
        public static IList<Package> GetPackageInLocation(long lctId)
        {
            string queryString = "SELECT DISTINCT {p.*} FROM `package` {p} " +
                                "INNER JOIN `locationpackage` ON {p}.Uid = `locationpackage`.`PackageId` " +
                                "INNER JOIN `packageprimaryproduct` ON `packageprimaryproduct`.PackageId = {p}.Uid " +
                                "INNER JOIN `primaryproduct` ON `primaryproduct`.Uid = `packageprimaryproduct`.PrimaryProductId " +
                                "WHERE (`primaryproduct`.Decomposed IS NULL OR `primaryproduct`.Decomposed = 0) AND `locationpackage`.LocationId = " + lctId + " order by {p}.Uid desc";

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateSQLQuery(queryString, "p", typeof(Package));
            return iQuery.List().Cast<Package>().ToList();
        }
    }
}
