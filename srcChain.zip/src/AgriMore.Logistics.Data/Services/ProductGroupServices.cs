﻿using AgriMore.Logistics.Domain.ThirdPartyEntities;

namespace AgriMore.Logistics.Data.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class ProductGroupServices
    {
        /// <summary>
        /// Gets the product group of product.
        /// </summary>
        /// <param name="prodId">The product identifier.</param>
        /// <returns></returns>
        public static ProductGroup GetProductGroupOfProduct(long prodId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "Products/GetProductGroupByProductId", prodId);
            return WebApiHelper.Get<ProductGroup>(requestUrl);
        }
    }
}
