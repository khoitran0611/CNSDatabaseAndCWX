﻿using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using System.Collections.Generic;
using System.Linq;

namespace AgriMore.Logistics.Data.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class PrimaryProductServices
    {
        /// <summary>
        /// Gets the primary product by identifier.
        /// </summary>
        /// <param name="priProdId">The pri product identifier.</param>
        /// <returns></returns>
        public static PrimaryProduct GetPrimaryProductById(long priProdId)
        {
            string queryString = "SELECT DISTINCT {p.*} FROM `primaryproduct` {p} WHERE {p}.Uid = " + priProdId;

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateSQLQuery(queryString, "p", typeof(PrimaryProduct));
            return iQuery.List().Cast<PrimaryProduct>().FirstOrDefault();
        }

        /// <summary>
        /// Gets the primary product by location identifier.
        /// </summary>
        /// <param name="lctId">The LCT identifier.</param>
        /// <returns></returns>
        public static IList<PrimaryProduct> GetPrimaryProdByLocationId(long lctId)
        {
            string queryString = "SELECT DISTINCT {p.*} FROM `primaryproduct` {p} " +
                                       "INNER JOIN `packageprimaryproduct` ON {p}.Uid = `packageprimaryproduct`.PrimaryProductId " +
                                       "INNER JOIN `locationpackage` ON `packageprimaryproduct`.PackageId = `locationpackage`.PackageId " +
                                       "WHERE ({p}.Decomposed IS NULL OR {p}.Decomposed = 0) AND `locationpackage`.LocationId = " + lctId;

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateSQLQuery(queryString, "p", typeof(PrimaryProduct));
            return iQuery.List().Cast<PrimaryProduct>().ToList();
        }

        /// <summary>
        /// Gets the package by primary product identifier.
        /// </summary>
        /// <param name="priProdId">The pri product identifier.</param>
        /// <returns></returns>
        public static Package GetPackageByPrimaryProdId(long priProdId)
        {
            string queryString = "SELECT DISTINCT {p.*} FROM `package` {p} " +
                                 "INNER JOIN `packageprimaryproduct` ON {p}.Uid = `packageprimaryproduct`.PackageId " +
                                 "WHERE `packageprimaryproduct`.PrimaryProductId = " + priProdId;

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateSQLQuery(queryString, "p", typeof(Package));
            return iQuery.List().Cast<Package>().FirstOrDefault();
        }

        /// <summary>
        /// Sets the decomposed.
        /// </summary>
        /// <param name="primaryProdId">The primary product identifier.</param>
        public static void SetDecomposed(long primaryProdId)
        {
            string queryString = "UPDATE `primaryproduct` SET Decomposed = 1 WHERE Uid = " + primaryProdId;

            using (var cmd = NHibernateHttpModule.GetSession.Connection.CreateCommand())
            {
                cmd.CommandText = queryString;

                cmd.ExecuteNonQuery();
            }
        }
    }
}
