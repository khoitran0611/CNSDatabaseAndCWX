﻿using System.Collections.Generic;
using System.Linq;
using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using AgriMore.Logistics.Data.NHibernate;

namespace AgriMore.Logistics.Data.Services
{
    public class OrganizationServices
    {
        private static readonly IRepositoryFactory Factory = new NHibernateRepositoryFactory();

        /// <summary>
        /// Gets the by list org identifier.
        /// </summary>
        /// <param name="orgIds">The org ids.</param>
        /// <returns></returns>
        public static IList<OrganizationInfo> GetByListOrgId(string[] orgIds)
        {
            var obj = new ArrayIds { Ids = orgIds };
            string reqUrl = string.Format("{0}/Organization/PostListOrgId2GetOrganization/", WebApiHelper.MatchingApiUrl);
            return WebApiHelper.PostAndGetResp<IList<OrganizationInfo>>(reqUrl, obj);
        }

        /// <summary>
        /// Gets the organization by org identifier.
        /// </summary>
        /// <param name="orgId">The org identifier.</param>
        /// <returns></returns>
        public static List<OrganizationInfo> GetOrganizationByOrgId(string orgId)
        {
            string reqUrl = string.Format("{0}/Organization/GetOrganizationByOrgId/{1}", WebApiHelper.MatchingApiUrl, orgId);
            return WebApiHelper.Get<List<OrganizationInfo>>(reqUrl);
        }

        public static IList<OrganizationInfo> GetVisibleOrganizationInfos(long chainId)
        {
            string reqUrl = string.Format("{0}/Organization/GetVisibleOrganization/{1}", WebApiHelper.MatchingApiUrl, chainId);
            return WebApiHelper.Get<List<OrganizationInfo>>(reqUrl);
        }

        public static OrganizationInfo GetOneOrganizationByOrgId(string orgId)
        {
            string reqUrl = string.Format("{0}/Organization/GetOneOrganizationByOrgId/{1}", WebApiHelper.MatchingApiUrl, orgId);
            return WebApiHelper.Get<OrganizationInfo>(reqUrl);
        }

        /// <summary>
        /// Gets the decomposed organization infos.
        /// </summary>
        /// <param name="chainId">The chain identifier.</param>
        /// <returns></returns>
        public static IList<OrganizationInfo> GetDecomposedOrganizationInfos(long chainId)
        {
            const string queryString = "select distinct dcmpif.KeyFigure4OrgId from DecompositionInfo dcmpif where dcmpif.DecomposedByChainId = :chainId";
            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateQuery(queryString);
            iQuery.SetInt64("chainId", chainId);

            var orgIds = iQuery.List().Cast<string>().ToArray();
            return orgIds.Length <= 0 ? null : GetByListOrgId(orgIds);
        }

        public static IList<OrganizationInfo> GetDecomposedOrganizationInfos()
        {
            const string queryString = "select distinct dcmpif.KeyFigure4OrgId from DecompositionInfo dcmpif";
            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateQuery(queryString);

            var orgIds = iQuery.List().Cast<string>().ToArray();
            return orgIds.Length <= 0 ? null : GetByListOrgId(orgIds);
        }


        /// <summary>
        /// Gets the sub admin identifier of chain entity.
        /// </summary>
        /// <param name="chainId">The chain identifier.</param>
        /// <returns></returns>
        public static IList<string> GetSubAdminIdOfChainEntity(long chainId)
        {
            string reqUrl = string.Format("{0}/Organization/GetSubAdminIds/{1}", WebApiHelper.MatchingApiUrl, chainId);
            return WebApiHelper.Get<List<string>>(reqUrl);
        }
    }
}
