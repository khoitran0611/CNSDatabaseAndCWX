﻿using System.Collections.Generic;
using AgriMore.Logistics.Domain.ThirdPartyEntities;

namespace AgriMore.Logistics.Data.Services
{
    public class DecompositionServices
    {
        /// <summary>
        /// Gets all by root.
        /// </summary>
        /// <param name="rootProdId">The root product identifier.</param>
        /// <returns></returns>
        public static IList<DecompositionKeyFigure> GetAllByRoot(long rootProdId)
        {
            var requestUrl = string.Format("{0}/{1}/?rootId={2}", WebApiHelper.MatchingApiUrl, "Decomposition/GetAllByRoot/", rootProdId);
            return WebApiHelper.Get<IList<DecompositionKeyFigure>>(requestUrl);
        }

        /// <summary>
        /// Gets the key figures.
        /// </summary>
        /// <param name="orgId">The org identifier.</param>
        /// <param name="rootProdId">The root product identifier.</param>
        /// <returns></returns>
        public static IList<DecompositionKeyFigure> GetKeyFigures(string orgId, long rootProdId)
        {
            var requestUrl = string.Format("{0}/{1}/?orgId={2}&rootId={3}", WebApiHelper.MatchingApiUrl,
                "Decomposition/Get/", orgId, rootProdId);
            return WebApiHelper.Get<IList<DecompositionKeyFigure>>(requestUrl);
        }

        /// <summary>
        /// Gets the key figure.
        /// </summary>
        /// <param name="orgId">The org identifier.</param>
        /// <param name="rootProdId">The root product identifier.</param>
        /// <param name="fromProdId">From product identifier.</param>
        /// <param name="toProdId">To product identifier.</param>
        /// <returns></returns>
        public static DecompositionKeyFigure GetKeyFigure(string orgId, long rootProdId, long fromProdId, long toProdId)
        {
            var requestUrl = string.Format("{0}/{1}/?orgId={2}&rootProdId={3}&fromProdId={4}&toProdId={5}",
                WebApiHelper.MatchingApiUrl, "Decomposition/GetKeyFigure/", orgId, rootProdId, fromProdId, toProdId);
            return WebApiHelper.Get<DecompositionKeyFigure>(requestUrl);
        }
    }
}
