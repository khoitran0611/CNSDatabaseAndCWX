﻿using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using AgriMore.Logistics.Domain.Transaction;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace AgriMore.Logistics.Data.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class ProductServices
    {
        private static readonly IRepositoryFactory Factory = new NHibernateRepositoryFactory();
        private const long wholesalePackage = 0;
        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="prodId">The product identifier.</param>
        /// <returns></returns>
        public static Product GetById(long prodId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "Products/GetProductById", prodId);
            return WebApiHelper.Get<Product>(requestUrl);
        }

        /// <summary>
        /// Gets the by ids.
        /// </summary>
        /// <param name="prodIds">The product ids.</param>
        /// <returns></returns>
        public static IList<Product> GetByIds(string prodIds)
        {
            var requestUrl = string.Format("{0}/{1}/?prodIds={2}", WebApiHelper.MatchingApiUrl, "Products/GetProductsByIds", prodIds);
            return WebApiHelper.Get<IList<Product>>(requestUrl);
        }

        /// <summary>
        /// Gets the product list.
        /// </summary>
        /// <returns></returns>
        public static IList<Product> GetProductList()
        {
            var requestUrl = string.Format("{0}/{1}", WebApiHelper.MatchingApiUrl, "Products/GetAllProducts");
            return WebApiHelper.Get<IList<Product>>(requestUrl);
        }

        /// <summary>
        /// Gets the root products.
        /// </summary>
        /// <param name="chainId">The chain identifier.</param>
        /// <returns></returns>
        public static IList<Product> GetRootProducts(long chainId)
        {
            const string queryString = "select distinct dcmpif.RootProdId from DecompositionInfo dcmpif where dcmpif.DecomposedByChainId = :chainId";
            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateQuery(queryString);
            iQuery.SetInt64("chainId", chainId);

            var prodIds = iQuery.List().Cast<long>().ToArray();
            return prodIds.Length <= 0 ? null : GetByIds(string.Join(",", Array.ConvertAll(prodIds, Convert.ToString)));
        }

        /// <summary>
        /// Gets the root products.
        /// </summary>
        /// <param name="sourceOrgIds">The source org ids.</param>
        /// <returns></returns>
        public static IList<Product> GetRootProducts(string[] sourceOrgIds)
        {
            string strScrOrgIds = string.Format("'{0}'", string.Join("','", sourceOrgIds));
            string queryString = "select distinct dcmpif.RootProdId from DecompositionInfo dcmpif where dcmpif.KeyFigure4OrgId in (" + strScrOrgIds + ")";
            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateQuery(queryString);
            
            var prodIds = iQuery.List().Cast<long>().ToArray();
            return prodIds.Length <= 0 ? null : GetByIds(string.Join(",", Array.ConvertAll(prodIds, Convert.ToString)));
        }

        /// <summary>
        /// Gets from products.
        /// </summary>
        /// <param name="sourceOrgIds">The source org ids.</param>
        /// <returns></returns>
        public static IList<Product> GetFromProducts(string[] sourceOrgIds)
        {
            string strScrOrgIds = string.Format("'{0}'", string.Join("','", sourceOrgIds));
            string queryString = "select distinct dcmpif.FromProdId from DecompositionInfo dcmpif where dcmpif.KeyFigure4OrgId in (" + strScrOrgIds + ")";
            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateQuery(queryString);

            var prodIds = iQuery.List().Cast<long>().ToArray();
            return prodIds.Length <= 0 ? null : GetByIds(string.Join(",", Array.ConvertAll(prodIds, Convert.ToString)));
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="chainEntityId"></param>
        /// <returns></returns>
        public static List<ProductSupply> GetUnpackedProductList(long chainEntityId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "ProductSupply/GetUnpackedProducts", chainEntityId);
            return WebApiHelper.Get<List<ProductSupply>>(requestUrl);
        }

        /// <summary>
        /// Gets the child products.
        /// </summary>
        /// <param name="prodId">The product identifier.</param>
        /// <returns></returns>
        public static IList<Product> GetChildProducts(long prodId)
        {
            var prodGroup = ProductGroupServices.GetProductGroupOfProduct(prodId);
            if (prodGroup == null) return new List<Product>();

            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "Products/GetAllProductsByParentProductGroup", prodGroup.Uid);
            return WebApiHelper.Get<IList<Product>>(requestUrl);
        }

        /// <summary>
        /// Decomposes the product.
        /// </summary>
        /// <param name="decomposeProducts">The decompose products.</param>
        /// <param name="deCmpProduct">The Primary product need to decompose</param>
        /// <param name="location">The location.</param>
        /// <param name="chainEntity">The chain entity.</param>
        /// <param name="user">The user.</param>
        public static void DecomposeProduct(IEnumerable<DecomposeProduct> decomposeProducts, PrimaryProduct deCmpProduct, Location location, ChainEntity chainEntity, User user)
        {
            var transactionManager = new TransactionManager();
            try
            {
                var lstProducts = GetProductList();
                var parentPack = PrimaryProductServices.GetPackageByPrimaryProdId(deCmpProduct.Uid);
                foreach (var cmpProd in decomposeProducts)
                {
                    DateTime dateTimeOfPacking = DateTime.Now;
                    IList<PackagingDefine> packageTypes = GetAllPackageTypes(user.UsingLang, wholesalePackage, cmpProd.PrimaryProd.Uid, chainEntity.Uid);

                    PackagingDefine packageType = null;
                    if (packageTypes.Any())
                        packageType = packageTypes.FirstOrDefault(p => p.Uid == cmpProd.Package.Uid);

                    var primaryProd = cmpProd.PrimaryProd;
                    ICollection<PrimaryProduct> primaryProducts = new Collection<PrimaryProduct>() { primaryProd };

                    //Call service to insert to matching and get the Uid for Matching Id in chain                    
                    var productSupply = new ProductSupply()
                    {
                        ParentId = deCmpProduct.MatchingProdId,
                        Amount = primaryProd.ProductAmount > 0 ? primaryProd.ProductAmount : cmpProd.KeyFigureWeight,
                        AvailableDate = DateTime.Now,
                        IsPackedByChain = true,
                        OrganizationId = chainEntity.Uid,
                        Product = lstProducts.SingleOrDefault(it => it.Uid == primaryProd.ProductUid),
                        UoM = new UoM() { Name = primaryProd.Uom.Name, Uid = primaryProd.Uom.Uid },
                        AddressId = location.Address.Uid,
                        LocationId = location.Uid,
                        Quantity = primaryProd.Quantity,
                    };

                    var prodSupply = ProductSupplyServices.CreateOrUpdate(productSupply);
                    foreach (var priProduct in primaryProducts)
                    {
                        priProduct.MatchingProdId = prodSupply.Uid;
                        if (priProduct.ProductAmount <= 0) priProduct.ProductAmount = cmpProd.KeyFigureWeight;
                    }

                    var decompositionInfo = new DecompositionInfo
                                            {
                                                KeyFigure4OrgId = cmpProd.ForOrgId,
                                                RootProdId = cmpProd.RootProdId,
                                                FromProdId = cmpProd.FromProdId,
                                                ToProdId = cmpProd.PrimaryProd.ProductUid,
                                                KeyFigureVal = cmpProd.KeyFigureVal,
                                                FigureWeight = cmpProd.KeyFigureWeight,
                                                ActualWeight = primaryProd.ProductAmount,
                                                ProdSupplyId = prodSupply.Uid,
                                                DecomposedDate = DateTime.Now,
                                                DecomposedByChainId = chainEntity.Uid
                                            };
                    Factory.GetDecompositionInfoRepository().Add(decompositionInfo);

                    var identification = new Identification(string.Empty, chainEntity, cmpProd.FromIdentifier, cmpProd.ToIdentifier);
                    var packageIdentifications = new List<Identification>() { identification };
                    var pack = new Package(packageType.Uid, primaryProducts, dateTimeOfPacking, packageIdentifications, string.Empty, cmpProd.FromIdentifier, cmpProd.ToIdentifier, packageType.PackTypeCategory.Uid, packageType.Name);
                    Factory.GetPackageRepository().Add(pack);

                    Factory.GetPackageRepository().Refresh(pack);
                    Factory.GetLocationRepository().Refresh(location);
                    IEnumerable<Exposure> exposures = new List<Exposure>();

                    Factory.GetPackageRepository().Refresh(parentPack);
                    location.Put(pack, parentPack, exposures, DateTime.Now);

                    Factory.GetLocationRepository().Store(location);
                    Factory.GetPackageRepository().Store(pack);
                    Factory.GetPackageRepository().Flush();

                    Factory.GetPackageRepository().Refresh(pack);
                    Factory.GetPackageRepository().Refresh(parentPack);

                    var stepDocument = new ProcessingStepDocument(pack, parentPack.Uid, parentPack.CurrentExposureDocument, ProcessingStepType.Exposures, user,
                        String.Format(ProcessingStepDocument.DecomposeProduct, DateTime.Now.ToString(ProcessingStepDocument.DateTimeFormat)));

                    foreach (ProcessingStep step in stepDocument.Steps) Factory.GetProcessingStepRepository().Add(step);
                }

                //Set decomposed for parent product suply
                var prodSuply = ProductSupplyServices.GetById(deCmpProduct.MatchingProdId);
                prodSuply.IsDecomposed = true;
                prodSuply.SalesOrgId = -1;
                prodSuply.PurchaseChainEntityId = chainEntity.Uid;
                ProductSupplyServices.CreateOrUpdate(prodSuply);

                PrimaryProductServices.SetDecomposed(deCmpProduct.Uid);

                transactionManager.CommitTransaction();
            }
            catch (Exception)
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="langCode"></param>
        /// <param name="packageTypeCategoryId"></param>
        /// <param name="productId"></param>
        /// <param name="chainEntityId"></param>
        /// <returns></returns>
        public static IList<PackagingDefine> GetAllPackageTypes(string langCode, long packageTypeCategoryId, long productId, long chainEntityId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "Products/GetAllPackageTypes", langCode + "," + packageTypeCategoryId.ToString() + "," + productId.ToString() + "," + chainEntityId.ToString());
            return WebApiHelper.Get<IList<PackagingDefine>>(requestUrl);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="packageTypeId"></param>
        /// <param name="langCode"></param>
        /// <returns></returns>
        public static PackagingDefine GetAllPackageTypesGetPackagingDefineByLangCode(long packageTypeId, string langCode)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "Products/GetPackagingDefineByLangCode", packageTypeId.ToString() + "," + langCode);
            return WebApiHelper.Get<PackagingDefine>(requestUrl);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static IList<AgriMore.Logistics.Domain.ThirdPartyEntities.TreatmentType> GetTreatmentTypeList()
        {
            var requestUrl = string.Format("{0}/{1}", WebApiHelper.MatchingApiUrl, "Products/GetAllTreatmentTypes");
            return WebApiHelper.Get<IList<AgriMore.Logistics.Domain.ThirdPartyEntities.TreatmentType>>(requestUrl);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="treatmentTypeId"></param>
        /// <returns></returns>
        public static AgriMore.Logistics.Domain.ThirdPartyEntities.TreatmentType GetTreatmentTypeById(long treatmentTypeId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "Products/GetTreatmentTypeById", treatmentTypeId);
            return WebApiHelper.Get<AgriMore.Logistics.Domain.ThirdPartyEntities.TreatmentType>(requestUrl);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static IList<AgriMore.Logistics.Domain.ThirdPartyEntities.TreatmentTypeCategory> GetTreatmentTypeCategoryList()
        {
            var requestUrl = string.Format("{0}/{1}", WebApiHelper.MatchingApiUrl, "Products/GetAllTreatmentTypeCategory");
            return WebApiHelper.Get<IList<AgriMore.Logistics.Domain.ThirdPartyEntities.TreatmentTypeCategory>>(requestUrl);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="treatmentTypeId"></param>
        /// <returns></returns>
        public static AgriMore.Logistics.Domain.ThirdPartyEntities.TreatmentTypeCategory GetTreatmentTypeCategoryById(long treatmentTypeId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "Products/GetTreatmentTypeCategoryById", treatmentTypeId);
            return WebApiHelper.Get<AgriMore.Logistics.Domain.ThirdPartyEntities.TreatmentTypeCategory>(requestUrl);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="treatmentTypeId"></param>
        /// <returns></returns>
        public static AgriMore.Logistics.Domain.TreatmentType GetDomainTreatmentTypeById(long treatmentTypeId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "Products/GetDomainTreatmentTypeById", treatmentTypeId);
            return WebApiHelper.Get<AgriMore.Logistics.Domain.TreatmentType>(requestUrl);
        }

        /// <summary>
        /// Gets the product list.
        /// </summary>
        /// <returns></returns>
        public static IList<ExposureDefine> GetExposureDefineList()
        {
            var requestUrl = string.Format("{0}/{1}", WebApiHelper.MatchingApiUrl, "Products/GetAllExposureDefine");
            return WebApiHelper.Get<IList<ExposureDefine>>(requestUrl);
        }

        public static AgriMore.Logistics.Domain.ExposureDefine GetExposureDefineById(long treatmentTypeId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "Products/GetExposureDefineById", treatmentTypeId);
            return WebApiHelper.Get<AgriMore.Logistics.Domain.ExposureDefine>(requestUrl);
        }


        public static IList<ExposureType> GetExposureTypeList()
        {
            var requestUrl = string.Format("{0}/{1}", WebApiHelper.MatchingApiUrl, "Products/GetAllExposureTypes");
            return WebApiHelper.Get<IList<ExposureType>>(requestUrl);
        }

        public static AgriMore.Logistics.Domain.ExposureType GetExposureTypeById(long treatmentTypeId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "Products/GetExposureTypeById", treatmentTypeId);
            return WebApiHelper.Get<AgriMore.Logistics.Domain.ExposureType>(requestUrl);
        }

        public static IList<DecompositionCategory> GetDecompositionCategoryList()
        {
            var requestUrl = string.Format("{0}/{1}", WebApiHelper.MatchingApiUrl, "Products/GetAllDecompositionCategory");
            return WebApiHelper.Get<IList<DecompositionCategory>>(requestUrl);
        }

        public static IEnumerable<AgriMore.Logistics.Domain.DecompositionType> GetDecompositionTypeById(long treatmentTypeId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "Products/GetDecompositionTypeById", treatmentTypeId);
            return WebApiHelper.Get<IEnumerable<AgriMore.Logistics.Domain.DecompositionType>>(requestUrl);
        }

        public static IList<DecompositionType> GetDecompositionTypeList()
        {
            var requestUrl = string.Format("{0}/{1}", WebApiHelper.MatchingApiUrl, "Products/GetAllDecompositionType");
            return WebApiHelper.Get<IList<DecompositionType>>(requestUrl);
        }

        public static List<ProductSupply> GetUnpackedProductByOrgIdList(string orgId)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "ProductSupply/GetUnpackedProductsByOrgId", orgId);
            return WebApiHelper.Get<List<ProductSupply>>(requestUrl);
        }

        public static List<ProductSupply> GetPackedProductByOrgIds(string orgIds)
        {
            var requestUrl = string.Format("{0}/{1}/{2}", WebApiHelper.MatchingApiUrl, "ProductSupply/GetPackedProductsByOrgIds", orgIds);
            return WebApiHelper.Get<List<ProductSupply>>(requestUrl);
        }
    }
}

