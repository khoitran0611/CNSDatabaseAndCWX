﻿using System;
using System.Collections.Generic;
using System.Linq;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Data.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class DisposalPackageServices
    {
        /// <summary>
        /// Gets the by location and status.
        /// </summary>
        /// <param name="lctId">The LCT identifier.</param>
        /// <param name="disposalPackingStatus">The disposal packing status.</param>
        /// <returns></returns>
        public static IEnumerable<DisposalPackage> GetByLocationAndStatus(long lctId, DisposalPackingStatus disposalPackingStatus)
        {
            string queryString = "SELECT DISTINCT {p.*} FROM `disposalpackages` {p} " +
                                "WHERE {p}.UnpackLocationId = " + lctId + " AND {p}.Status = " + Convert.ToInt32(disposalPackingStatus);

            var session = NHibernateHttpModule.GetSession;
            var iQuery = session.CreateSQLQuery(queryString, "p", typeof(DisposalPackage));
            return iQuery.List().Cast<DisposalPackage>().ToList();
        }
    }
}
