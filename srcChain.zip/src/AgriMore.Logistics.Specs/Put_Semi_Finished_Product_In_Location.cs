using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 	<userstory>
    ///         <no>4</no>
    ///   		<role>All</role>
    ///   		<feature>
    ///                 Place a semi finished product in a location
    ///         </feature>
    ///   		<benefit>
    ///                  I have a sfp in location under prescribed exposure so that 
    ///                  later I can compare the actual exposure of the semi finished 
    ///                  product to the prescribed exposure.
    ///         </benefit>
    /// 	</userstory>
    /// </summary>
    [TestFixture]
    public class Put_Semi_Finished_Product_In_Location
    {
        #region Setup/Teardown

        /// <summary>
        /// Setups this instance.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            plasticFlowBox = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            PrimaryProduct primaryProduct2 = new PrimaryProduct(validProductionAreaId2, validLifeCycleId2);

            ICollection<PrimaryProduct> primaryProducts1 = new List<PrimaryProduct>();
            primaryProducts1.Add(primaryProduct);
            ICollection<PrimaryProduct> primaryProducts2 = new List<PrimaryProduct>();
            primaryProducts2.Add(primaryProduct2);

            //mocks = new MockRepository();
            //chainEntity = mocks.Stub<ChainEntity>();
            chainEntity = new ChainEntity("name");

            identifications1 = new List<Identification>();
            identification1 = new Identification("1", chainEntity);
            identifications1.Add(identification1);

            identifications2 = new List<Identification>();
            identification2 = new Identification("2", chainEntity);
            identifications2.Add(identification2);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

            identifications3 = new List<Identification>();
            identification3 = new Identification("3", chainEntity);
            identifications3.Add(identification3);

            package1 = new Package(plasticFlowBox, primaryProducts1, dateTimeOfPacking, identifications1);
            package2 = new Package(plasticFlowBox, primaryProducts2, dateTimeOfPacking, identifications2);
        }

        #endregion

        private Package package1;
        private Package package2;
        private readonly PackingMaterial Plastic = new PackingMaterial("Plastic");


        private ChainEntity chainEntity;

        private PackageType plasticFlowBox;
        private ICollection<Identification> identifications1;
        private ICollection<Identification> identifications2;
        private ICollection<Identification> identifications3;
        private Identification identification1;
        private Identification identification2;
        private Identification identification3;

        private const string validProductionAreaId2 = "AAAPA0800002";
        private const string validLifeCycleId2 = "AAAPC0800002";
        private const string validProductionAreaId = "AAAPA0800001";
        private const string validLifeCycleId = "AAAPC0800001";

        /// <summary>
        ///  <scenario>
        ///    <no>11</no>
        ///    <given>
        ///         The package is present 
        ///         <and>the location is present</and>
        ///         <and>the prescibed exposure is present</and>
        ///         <and>the actual exposure is present</and>
        ///    </given>
        ///    <ensure>
        ///         exposure document exists for package in location 
        ///    </ensure>
        ///  </scenario>
        /// </summary>
        [Test]
        public void Get_The_ExposuresDocument_Of_A_Present_Package()
        {
            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            //ExposureDocument script = new ExposureDocument(exposure);
            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);
            Location location = new Location("description");
            location.Put(package1, exposures1, DateTime.Now);
            ExposureDocument retrievedExposureDocument = location.GetExposureDocument(package1);
            Assert.IsNotNull(retrievedExposureDocument);
        }

        /// <summary>
        ///  <scenario>
        ///    <no>9</no>
        ///    <given>
        ///         The package is present 
        ///         <and>the location is present</and>
        ///         <and>the prescibed exposure is present</and>
        ///         <and>the actual exposure is present</and>
        ///         <and>the package is already in location</and>
        ///    </given>
        ///    <ensure>the package cannot be put, because it is already in location</ensure> 
        ///  </scenario>
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentException))]
        public void
            Put_A_Package_In_A_Location_With_A_Known_Prescription_And_Actuals_And_The_Package_Is_Already_In_Stock()
        {
            MeasuredValue value = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed =
                new Range<MeasuredValue>(value);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            //ExposureDocument script = new ExposureDocument(exposure);
            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);
            Location location = new Location("description");
            location.Put(package1, exposures1, DateTime.Now);
            Assert.IsTrue(location.Contains(package1), "Package1 should be in stock");
            location.Put(package1, exposures1, DateTime.Now);
        }

        /// <summary>
        ///  <scenario>
        ///    <no>7</no>
        ///    <given>
        ///         The package is present
        ///         <and>the location is present</and>
        ///         <and> prescribed exposure is not present</and>
        ///         <and> actual is present</and>
        ///    </given>
        ///    <ensure>a package without prescribed exposure cannot be put</ensure> 
        ///  </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Put_A_Present_Package_In_A_Present_Location_And_Without_Prescription_And_With_Actuals()
        {
            // you need an exposure to put in location. it will fail here immediately.
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure =
                new Exposure(null, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            // Added the code that would put in location, for when implementation might change
            //ExposureDocument script = new ExposureDocument(exposure);
            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);
            Location location = new Location("description");
            location.Put(package1, exposures1, DateTime.Now);
        }

        /// <summary>
        ///  <scenario>
        ///    <no>8</no>
        ///    <given>
        ///         The package is present 
        ///         <and>the location is present</and>
        ///         <and>the prescibed exposure is present</and>
        ///         <and>the actual exposure is present</and>
        ///    </given>
        ///    <ensure>Package should be put in location.</ensure> 
        ///  </scenario>
        /// </summary>
        [Test]
        public void Put_A_Present_Package_In_Present_Location_And_With_Prescription_And_With_Actuals()
        {
            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            //ExposureDocument script = new ExposureDocument(exposure);
            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);
            Location location = new Location("description");
            location.Put(package1, exposures1, DateTime.Now);
            Assert.IsTrue(location.Contains(package1), "The package1 should be in stock.");
        }

        /// <summary>
        ///  <scenario>
        ///    <no>10</no>
        ///    <given>
        ///         The packages are present 
        ///         <and>the location is present</and>
        ///         <and>the prescibed exposure is present</and>
        ///         <and>the actual exposure is present</and>
        ///    </given>
        ///    <ensure>Many Packages should be put to a location.</ensure> 
        ///  </scenario>
        /// </summary>
        [Test]
        public void Put_Many_Packages_In_A_Location_With_A_Known_Prescription_And_Location()
        {
            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed =
                new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            //ExposureDocument script = new ExposureDocument(exposure);
            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);
            Location location = new Location("description");
            location.Put(package1, exposures1, DateTime.Now);
            Assert.IsTrue(location.Contains(package1), "Package1 should be in stock");
            location.Put(package2, exposures1, DateTime.Now);
            Assert.IsTrue(location.Contains(package2), "Package2 should be in stock");
        }

        /// <summary>
        ///  <scenario>
        ///    <no>14</no>
        ///    <given>
        ///         The package is present 
        ///         <and>the location is present</and>
        ///         <and>the prescibed exposure is present</and>
        ///         <and>the actual exposure is present</and>
        ///         <and>the date of inserting is on future </and>
        ///    </given>
        ///    <ensure>
        ///         package is not in location
        ///         <and>there is no exposure document for package in location</and> 
        ///    </ensure>
        ///  </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Put_Package_With_Date_In_The_Future_To_A_Location()
        {
            MeasuredValue value = new MeasuredValue(5, DateTime.Now.Add(new TimeSpan(1, 1, 1)));
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(value);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now.Add(new TimeSpan(1, 1, 1))));
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            //ExposureDocument exposureDocument = new ExposureDocument(exposure);
            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);
            Location location = new Location("description");
            location.Put(package1, exposures1, DateTime.Now);
        }

        /// <summary>
        ///  <scenario>
        ///    <no>5</no>
        ///    <given>
        ///         The package is present
        ///         <and>the location is present</and> 
        ///         <and>the prescription is not present</and>
        ///         <and>the actual exposure is not present</and>
        ///    </given>
        ///    <ensure>a present package without prescribed exposure en actuals exposures cannot be put</ensure> 
        ///  </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Put_Present_Package_In_Present_Location_And_Without_Prescription_And_Without_Actuals()
        {
            Location location = new Location("description");
            location.Put(package1, null, DateTime.Now);
        }

        /// <summary>
        /// Technical_s the test_ check_ if_ empty_ package_ is_ in_ empty_ stock.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_Check_If_Empty_Package_Is_In_Empty_Stock()
        {
            Location location = new Location("description");
            Assert.IsFalse(location.Contains(null), "Package1 should not be in stock.");
        }

        /// <summary>
        /// Technical_s the test_ check_ if_ valid_ package_ not_ put_ is_ not_ in_ location.
        /// </summary>
        [Test]
        public void Technical_Test_Check_If_Valid_Package_Not_Put_Is_Not_In_Location()
        {
            Location location = new Location("description");
            Assert.IsFalse(location.Contains(package1), "Package1 should not be in location.");
        }

        /// <summary>
        /// Technical_s the test_ get_ the_ exposures document_ of_ a_ not_ present_ package.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_Get_The_ExposuresDocument_Of_A_Not_Present_Package()
        {
            Location location = new Location("description");
            location.GetExposureDocument(null);
        }

        // 

        /// <summary>
        /// Technical_s the test exposure document does not exist for a package that not-existing in the location.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_Get_The_ExposuresDocument_Of_A_Package_That_Not_Exist_In_The_Location()
        {
            Location location = new Location("description");
            location.GetExposureDocument(package1);
        }

        /// <summary>
        /// Technical_s the name of the test_ location_ constructor_ with_ empty_.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_Location_Constructor_With_Empty_Name()
        {
            new Location(string.Empty);
        }

        /// <summary>
        /// Technical_s the name of the test_ location_ constructor_ with_ spaced_.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_Location_Constructor_With_Spaced_Name()
        {
            new Location("   ");
        }

        /// <summary>
        /// Technical_s the name of the test_ location_ constructor_ without_name.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_Location_Constructor_Without_Name()
        {
            new Location(null);
        }

        /// <summary>
        /// Technical_s the test_ location_ getters.
        /// </summary>
        [Test]
        public void Technical_Test_Location_Getters()
        {
            Location location = new Location("name");
            Assert.AreEqual("name", location.ToString());
            Assert.AreEqual("name".GetHashCode(), location.GetHashCode());
            Assert.IsFalse(location.Equals(null));
        }

        /// <summary>
        /// Technical_s the test_ location repository.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_LocationRepository_Add_Invalid_Location()
        {
            Location ll = new Location("description");
            IRepository<Location> locationRep = new RepositoryFactory().CreateRepository<Location>();
            locationRep.Add(ll);
            locationRep.Add(null);
        }

        /// <summary>
        /// Technical_s the test_ put_ a_ not_ present_ package_ in_ a_ present_ location_ and_ with_ prescription_ and_ with_ actuals.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void
            Technical_Test_Put_A_Not_Present_Package_In_A_Present_Location_And_With_Prescription_And_With_Actuals()
        {
            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed =
                new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            //ExposureDocument script = new ExposureDocument(exposure);
            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);
            Location location = new Location("description");
            location.Put(null, exposures1, DateTime.Now);
        }

        /// <summary>
        /// Technical_s the test_ put_ a_ not_ present_ package_ in_ a_ present_ location_ and_ without_ prescription_ and_ without_ actuals.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void
            Technical_Test_Put_A_Not_Present_Package_In_A_Present_Location_And_Without_Prescription_And_Without_Actuals()
        {
            Location location = new Location("description");
            location.Put(null, null, DateTime.Now);
        }

        /// <summary>
        /// Setups the values.
        /// </summary>
        [Test]
        public void TechnicalTest_Temperature()
        {
            DateTime dateTimeOfExposurePrescription = new DateTime(2008, 1, 12, 14, 1, 1);
            double preTemperature = 5;
            double actualTemperature = 5;
            Range<MeasuredValue> r =
                new Range<MeasuredValue>(new MeasuredValue(preTemperature, dateTimeOfExposurePrescription),
                                         new MeasuredValue(preTemperature, dateTimeOfExposurePrescription));
            MeasuredValue mv = new MeasuredValue(actualTemperature, dateTimeOfExposurePrescription);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(mv);
            Exposure prescribedExposure =
                new Exposure(r, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            //Exposure prescribedExposure =
            //  new Exposure(dateTimeOfExposurePrescription, preTemperature, actualTemperature, package1, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            Assert.AreEqual(5, prescribedExposure.PrescribedRange.Start.Value);
            Assert.AreEqual(new DateTime(2008, 1, 12, 14, 1, 1), prescribedExposure.Start);
        }

        /// <summary>
        /// Remove_s the package_ from_ location.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Delete_Package_From_Location()
        {
            //MeasuredValue value = new MeasuredValue(5, DateTime.Now.Add(new TimeSpan(1, 1, 1)));
            MeasuredValue value = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(value);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            //list.Add(new MeasuredValue(5, DateTime.Now.Add(new TimeSpan(1, 1, 1))));
            list.Add(new MeasuredValue(5, DateTime.Now));
            
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);
            Location location = new Location("description");
            location.Put(package1, exposures1, DateTime.Now);

            Assert.AreEqual(1, new List<Package>(location.Packages).Count);

            location.Delete(package1);
            Assert.AreEqual(0, new List<Package>(location.Packages).Count);

            location.Delete(package1);
        }

        /// <summary>
        /// Remove_s the package_ from_ location_ not_ in_ the_ current_ location.
        /// </summary>
        [ExpectedException(typeof(ArgumentException))]
        [Test]
        public void Remove_Package_From_Location_Not_In_The_Current_Location()
        {
            MeasuredValue value = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(value);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);
            Location location = new Location("description");
            location.Put(package1, exposures1, DateTime.Now);

            Assert.AreEqual(1, new List<Package>(location.Packages).Count);

            location.Remove(package1,DateTime.Now);
            Assert.AreEqual(0, new List<Package>(location.Packages).Count);

            location.Remove(package1, DateTime.Now);
        }

        /// <summary>
        /// Get_s the exposure documents_ for_ packages_ in_ location.
        /// </summary>
        [Test]
        public void Get_ExposureDocuments_For_Packages_In_Location()
        {
            MeasuredValue value = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(value);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);
            Location location = new Location("description");
            location.Put(package1, exposures1, DateTime.Now);

            Assert.AreEqual(1, new List<Package>(location.Packages).Count);
            Assert.AreEqual(1, new List<ExposureDocument>(location.ExposureDocuments).Count);
        }
    }
}