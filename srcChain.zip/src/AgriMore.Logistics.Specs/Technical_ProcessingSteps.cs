using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Repository.Memory;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// </summary>
    [TestFixture]
    public class Technical_ProcessingSteps
    {
        //private ProcessingStepDocument processingStepDocument = null;
        private readonly IRepository<ExposureType> exposureTypeRepository = new MemoryMapRepository<ExposureType>();
        private readonly IRepository<Role> roleRepository = new MemoryMapRepository<Role>();
        private readonly IRepository<User> userRepository = new MemoryMapRepository<User>();
        private readonly IRepository<Address> addressRepository = new MemoryMapRepository<Address>();
        private readonly IRepository<Location> locationRepository = new MemoryMapRepository<Location>();
        private readonly IRepository<ChainEntity> chainEntityRepository = new MemoryMapRepository<ChainEntity>();
        private readonly IRepository<Package> packageRepository = new MemoryMapRepository<Package>();

        private readonly PackingMaterial Plastic = new PackingMaterial("Plastic");

        private Package packWithNoChildren = null;

        private ExposureType tempInCelsius = null;
        private ExposureType tempInFahrenheit = null;
        private ExposureType licht = null;
        private ExposureType gdh = null;
        private User user1;

        /// <summary>
        /// Fills the with dumy data.
        /// </summary>
        private void FillWithDumyData()
        {
            tempInCelsius = new ExposureType("Temperature in Celsius", new UnitOfMeasurement("Celsius"));
            tempInFahrenheit =new ExposureType("Temperature in Fahrenheit", new UnitOfMeasurement("Fahrenheit"));
            licht = new ExposureType("LightInJoulsPerMeter", new UnitOfMeasurement("Jouls per meter"));
            gdh = new ExposureType("Growth Degree Hours (GDH)", new UnitOfMeasurement("Umol/cm2"));

            exposureTypeRepository.Add(tempInCelsius);
            exposureTypeRepository.Add(tempInFahrenheit);
            exposureTypeRepository.Add(licht);
            exposureTypeRepository.Add(gdh);

            Role growerRole = new Role("Grower");
            Role shipperRole = new Role("Shipper");
            Role forwarderRole = new Role("Forwarder");
            Role receiverRole = new Role("Receiver");

            roleRepository.Add(growerRole);
            roleRepository.Add(shipperRole);
            roleRepository.Add(forwarderRole);
            roleRepository.Add(receiverRole);

            user1 =
            new User("allRoles", "allRoles", "agrimore", "agrimore",
             new Role[] { roleRepository.GetOne("Shipper"), roleRepository.GetOne("Grower"), roleRepository.GetOne("Forwarder"), roleRepository.GetOne("Receiver") });

            User user2 = new User("Shipper", "Shipper", "agrimore", "agrimore",
                new Role[] { roleRepository.GetOne("Shipper") });

            User user3 = new User("ShipperGrower", "ShipperGrower", "agrimore", "agrimore",
                new Role[] { roleRepository.GetOne("Shipper"), roleRepository.GetOne("Grower") });

            User user4 = new User("Grower", "Grower", "agrimore", "agrimore",
                new Role[] { roleRepository.GetOne("Grower") });

            User user5 = new User("Forwarder", "Forwarder", "agrimore", "agrimore",
                new Role[] { roleRepository.GetOne("Forwarder") });

            User user6 = new User("Receiver", "Receiver", "agrimore", "agrimore",
                new Role[] { roleRepository.GetOne("Receiver") });

            userRepository.Add(user1);
            userRepository.Add(user2);
            userRepository.Add(user3);
            userRepository.Add(user4);
            userRepository.Add(user5);
            userRepository.Add(user6);

            //SUPER DE BOER
            Address superDeBoerAddress1 =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "1111 SD");
            Address superDeBoerAddress2 =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "2222 SD");

            addressRepository.Add(superDeBoerAddress1);
            addressRepository.Add(superDeBoerAddress2);

            Location superDeBoerDockA = new Location("10");
            Location superDeBoerDockB = new Location("20");
            Location superDeBoerDockC = new Location("30");

            locationRepository.Add(superDeBoerDockA);
            locationRepository.Add(superDeBoerDockB);
            locationRepository.Add(superDeBoerDockC);

            ChainEntity superDeBoer = new ChainEntity("Super de Boer");

            superDeBoerAddress1.AddLocation(superDeBoerDockA);
            superDeBoerAddress1.AddLocation(superDeBoerDockB);
            superDeBoerAddress2.AddLocation(superDeBoerDockC);

            superDeBoer.AddAddress(superDeBoerAddress1);
            superDeBoer.AddAddress(superDeBoerAddress2);


            //ALBERT HEIN
            Address albertHeinAddress1 =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "3333 AH");
            Address albertHeinAddress2 =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "4444 AH");

            addressRepository.Add(albertHeinAddress1);
            addressRepository.Add(albertHeinAddress2);

            ICollection<Address> addressesAH = new Collection<Address>();
            addressesAH.Add(albertHeinAddress1);
            addressesAH.Add(albertHeinAddress2);

            Location albertHeinDockA = new Location("40");
            Location albertHeinDockB = new Location("50");
            Location albertHeinDockC = new Location("60");
            Location albertHeinDockD = new Location("70");

            locationRepository.Add(albertHeinDockA);
            locationRepository.Add(albertHeinDockB);
            locationRepository.Add(albertHeinDockC);
            locationRepository.Add(albertHeinDockD);

            ChainEntity albertHein = new ChainEntity("Albert Hein");

            albertHeinAddress1.AddLocation(albertHeinDockA);
            albertHeinAddress1.AddLocation(albertHeinDockB);
            albertHeinAddress2.AddLocation(albertHeinDockC);
            albertHeinAddress2.AddLocation(albertHeinDockD);

            albertHein.AddAddress(albertHeinAddress1);
            albertHein.AddAddress(albertHeinAddress2);

            //DHL
            Address dhlAddress1 =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "9999 DH");

            addressRepository.Add(dhlAddress1);

            Location dhlDockA = new Location("80");
            Location dhlDockB = new Location("81");

            locationRepository.Add(dhlDockA);
            locationRepository.Add(dhlDockB);

            ChainEntity dhl = new ChainEntity("DHL");
            dhlAddress1.AddLocation(dhlDockA);
            dhlAddress1.AddLocation(dhlDockB);
            dhl.AddAddress(dhlAddress1);

            //TNT
            Address tntAddress1 =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "5555 TN");

            Location tntDockA = new Location("90");
            Location tntDockB = new Location("100");
            Location tntDockC = new Location("110");

            locationRepository.Add(tntDockA);
            locationRepository.Add(tntDockB);
            locationRepository.Add(tntDockC);

            ChainEntity tnt = new ChainEntity("TNT");
            tntAddress1.AddLocation(tntDockA);
            tntAddress1.AddLocation(tntDockB);
            tntAddress1.AddLocation(tntDockC);
            tnt.AddAddress(tntAddress1);


            //Aardappel grower
            Address growerAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "6666 GA");

            Location growerLocation120 = new Location("120");
            Location growerLocation121 = new Location("121");

            locationRepository.Add(growerLocation120);
            locationRepository.Add(growerLocation121);

            ChainEntity grower1 = new ChainEntity("Aardappel Grower");
            growerAddress.AddLocation(growerLocation120);
            growerAddress.AddLocation(growerLocation121);
            grower1.AddAddress(growerAddress);


            ChainEntity grower2 = new ChainEntity("Paprika Grower");
            Address growerAddress2 =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "7777 GB");
            Location growerLocation2 = new Location("130");
            growerAddress2.AddLocation(growerLocation2);
            grower2.AddAddress(growerAddress2);

            ChainEntity grower3 = new ChainEntity("Tomaat Grower");
            Address growerAddress3 =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "8888 GB");
            Location growerLocation3 = new Location("140");
            growerAddress3.AddLocation(growerLocation3);
            grower3.AddAddress(growerAddress3);

            locationRepository.Add(growerLocation3);


            superDeBoer.AddUser(user1);
            albertHein.AddUser(user2);
            dhl.AddUser(user3);
            dhl.AddUser(user4);
            tnt.AddUser(user5);
            grower1.AddUser(user4);

            chainEntityRepository.Add(superDeBoer);
            chainEntityRepository.Add(albertHein);
            chainEntityRepository.Add(dhl);
            chainEntityRepository.Add(tnt);
            chainEntityRepository.Add(grower1);
            chainEntityRepository.Add(grower2);
            chainEntityRepository.Add(grower3);
        }

        /// <summary>
        /// Sets the up.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            FillWithDumyData();

            PrimaryProduct primaryProduct = new PrimaryProduct("1", "2", "Product Description");
            Identification id1 = new Identification("SuperDeBoer1", chainEntityRepository.GetOne("Super de Boer"));
            Identification id2 = new Identification("SuperDeBoer2", chainEntityRepository.GetOne("Super de Boer"));
            Identification id3 = new Identification("AlbertHein1", chainEntityRepository.GetOne("Albert Hein"));
            Identification id4 = new Identification("AlbertHein2", chainEntityRepository.GetOne("Albert Hein"));

            IList<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            IList<Identification> ids = new List<Identification>();
            
            primaryProducts.Add(primaryProduct);
            ids.Add(id1);
            ids.Add(id2);
            ids.Add(id3);
            ids.Add(id4);

            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            PackageType flowPack = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            packWithNoChildren = new Package(flowPack, primaryProducts, DateTime.Now, ids, "productCode");
            packageRepository.Add(packWithNoChildren);
            IList<MeasuredValue> actuals = new List<MeasuredValue>();
            actuals.Add(new MeasuredValue(10, DateTime.Now));

            Exposure e1 =
                new Exposure(0, 10, DateTime.Now, actuals, tempInCelsius);
            Exposure e2 =
                new Exposure(20, 30, DateTime.Now, actuals, tempInFahrenheit);

            IList<Exposure> exposures = new List<Exposure>();
            exposures.Add(e1);
            exposures.Add(e2);

            locationRepository.GetOne("10").Put(packWithNoChildren, exposures, DateTime.Now);

            

        }

        /// <summary>
        /// Tears the down.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            
        }

        /// <summary>
        /// [ERROR: Unknown property access] the test with single package.
        /// </summary>
        /// <value>The test with single package.</value>
        [Test]
        public void TestWithSinglePackage()
        {

            //processingStepDocument = new ProcessingStepDocument(packWithNoChildren, ProcessingStepActionType.PutInLocation, user1);
            ////processingStepDocument.CreateProcessingSteps();

            //Assert.AreEqual(8, processingStepDocument.NumberOfSteps);

            //int numberOfPrescribed = 0;
            //int numberOfDocumented = 0;
            //int numberOfChainEntityIdentification = 0;


            //foreach (ProcessingStep processingStep in processingStepDocument.Steps)
            //{
            //    //Assert.AreEqual(groupId, processingStepDocument.GroupId);
            //    Assert.AreEqual(packWithNoChildren.Uid, processingStep.PackageUID);
            //    Assert.AreEqual(-1, processingStep.PackageParentUID);

            //    if(processingStep.ProcessingStepType == ProcessingStepType.Prescribed)
            //    {
            //        numberOfPrescribed++;
            //    }

            //    if (processingStep.ProcessingStepType == ProcessingStepType.Documented)
            //    {
            //        numberOfDocumented++;
            //    }

            //    if (processingStep.ProcessingStepType == ProcessingStepType.ChainEntityIdentification)
            //    {
            //        numberOfChainEntityIdentification++;
            //    }
            //}

            //Assert.AreEqual(2, numberOfPrescribed);
            //Assert.AreEqual(2, numberOfDocumented);
            //Assert.AreEqual(4, numberOfChainEntityIdentification);
        }

        ///// <summary>
        ///// Tests the new constructor.
        ///// </summary>
        //[Test]
        //public void TestNewConstructor()
        //{
        //    string groupId = "1";
        //    IProcessingStepAction action = new PutInLocationStep(packWithNoChildren);
        //    IEnumerable<IProcessingStep> steps = action.CreateProcessingSteps(groupId, false);
            
        //    int numberOfPreSteps = 0;
        //    int numberOfDocSteps = 0;
        //    int numberOfPutinLocationSteps = 0;
            
        //    foreach (IProcessingStep step in steps)
        //    {
        //        if(step.ProcessingStepActionType == ProcessingStepActionType.AddPrescribed)
        //        {
        //            numberOfPreSteps++;
        //            Assert.AreEqual(groupId, step.GroupId);
        //        }

        //        if (step.ProcessingStepActionType == ProcessingStepActionType.AddDocumented)
        //        {
        //            numberOfDocSteps++;
        //            Assert.AreEqual(groupId, step.GroupId);

        //        }

        //        if (step.ProcessingStepActionType == ProcessingStepActionType.PutInLocation)
        //        {
        //            numberOfPutinLocationSteps++; 
        //            Assert.AreEqual(groupId, step.GroupId);

        //        }

        //    }

        //    Assert.AreEqual(2, numberOfPreSteps);
        //    Assert.AreEqual(2, numberOfDocSteps);
        //    Assert.AreEqual(1, numberOfPutinLocationSteps);
            
        //    //processingStepDocument psd = new processingStepDocument(action);
        //}
        ///// <summary>
        ///// Technicals this instance.
        ///// </summary>
        //[Test]
        //public void Technical()
        //{
        //    string groupId = Guid.NewGuid().ToString();
        //    DateTime dateTimeOfEntry = DateTime.Now;

        //    ProcessingDocument processingDocument = new ProcessingDocument();
        //    processingDocument.CreateProcessingSteps(package);
            
        //    foreach (ProcessingStep processingStep in processingDocument.StepsInChronologicalOrder)
        //    {
        //       Assert.AreEqual(groupId, processingDocument.GroupId);
        //       Assert.AreEqual(processingStep.PackageParentUID
        //        //processingStep.PackageUId,
        //       processingStep.PackageParentUId,
        //       processingStep.PrescribedStartValue
        //       processingStep.PrescribedEndValue

        //       foreach(ProcessingStep childStep in processingStep.Children)
        //       {

        //       }

        //        //foreach(ProcessingStepprocessingStep.Documented

        //    }


        //    ProcessingStep step1 = new ProcessingStep(groupId, 1, null, ProcessingStepType.PrescribedRangeStartValue, 0, ProcessingStepObjectType.ExposureTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step2 = new ProcessingStep(groupId, 1, null, ProcessingStepType.PrescribedRangeEndValue, 5, ProcessingStepObjectType.ExposureTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step3 = new ProcessingStep(groupId, 1, null, ProcessingStepType.Documented, 20, ProcessingStepObjectType.ExposureTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step4 = new ProcessingStep(groupId, 1, null, ProcessingStepType.Documented, 30, ProcessingStepObjectType.ExposureTypeID, 2, 100, DateTime.Now, 200);
        //    ProcessingStep step5 = new ProcessingStep(groupId, 1, null, ProcessingStepType.TreatmentRangeStartDate, DateTime.Now.AddDays(-2), ProcessingStepObjectType.TreatmentTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step6 = new ProcessingStep(groupId, 1, null, ProcessingStepType.TreatmentRangeEndDate, DateTime.Now.AddDays(-1), ProcessingStepObjectType.TreatmentTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step7 = new ProcessingStep(groupId, 1, null, ProcessingStepType.TreatmentValue, 30, ProcessingStepObjectType.TreatmentTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step8 = new ProcessingStep(groupId, 1, null, ProcessingStepType.ChainEntityIdentification, "someNumber", ProcessingStepObjectType.ChainEntityID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step9 = new ProcessingStep(groupId, 1, null, ProcessingStepType.ChainEntityIdentification, "Apples2007", ProcessingStepObjectType.ChainEntityID, 2, 100, DateTime.Now, 200);

        //    ProcessingStep step10 = new ProcessingStep(groupId, 2, 1, ProcessingStepType.PrescribedRangeStartValue, 0, ProcessingStepObjectType.ExposureTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step11 = new ProcessingStep(groupId, 2, 1, ProcessingStepType.PrescribedRangeEndValue, 5, ProcessingStepObjectType.ExposureTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step12 = new ProcessingStep(groupId, 2, 1, ProcessingStepType.Documented, 20, ProcessingStepObjectType.ExposureTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step13 = new ProcessingStep(groupId, 2, 1, ProcessingStepType.Documented, 30, ProcessingStepObjectType.ExposureTypeID, 2, 100, DateTime.Now, 200);
        //    ProcessingStep step14 = new ProcessingStep(groupId, 2, 1, ProcessingStepType.TreatmentRangeStartDate, DateTime.Now.AddDays(-2), ProcessingStepObjectType.TreatmentTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step15 = new ProcessingStep(groupId, 2, 1, ProcessingStepType.TreatmentRangeEndDate, DateTime.Now.AddDays(-1), ProcessingStepObjectType.TreatmentTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step16 = new ProcessingStep(groupId, 2, 1, ProcessingStepType.TreatmentValue, 30, ProcessingStepObjectType.TreatmentTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step17 = new ProcessingStep(groupId, 2, 1, ProcessingStepType.ChainEntityIdentification, "someNumber", ProcessingStepObjectType.ChainEntityID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step18 = new ProcessingStep(groupId, 2, 1, ProcessingStepType.ChainEntityIdentification, "Apples2007", ProcessingStepObjectType.ChainEntityID, 2, 100, DateTime.Now, 200);

        //    ProcessingStep step19 = new ProcessingStep(groupId, 3, 2, ProcessingStepType.PrescribedRangeStartValue, 0, ProcessingStepObjectType.ExposureTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step20 = new ProcessingStep(groupId, 3, 2, ProcessingStepType.PrescribedRangeEndValue, 5, ProcessingStepObjectType.ExposureTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step21 = new ProcessingStep(groupId, 3, 2, ProcessingStepType.Documented, 20, ProcessingStepObjectType.ExposureTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step22 = new ProcessingStep(groupId, 3, 2, ProcessingStepType.Documented, 30, ProcessingStepObjectType.ExposureTypeID, 2, 100, DateTime.Now, 200);
        //    ProcessingStep step23 = new ProcessingStep(groupId, 3, 2, ProcessingStepType.TreatmentRangeStartDate, DateTime.Now.AddDays(-2), ProcessingStepObjectType.TreatmentTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step24 = new ProcessingStep(groupId, 3, 2, ProcessingStepType.TreatmentRangeEndDate, DateTime.Now.AddDays(-1), ProcessingStepObjectType.TreatmentTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step25 = new ProcessingStep(groupId, 3, 2, ProcessingStepType.TreatmentValue, 30, ProcessingStepObjectType.TreatmentTypeID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step26 = new ProcessingStep(groupId, 3, 2, ProcessingStepType.ChainEntityIdentification, "someNumber", ProcessingStepObjectType.ChainEntityID, 1, 100, DateTime.Now, 200);
        //    ProcessingStep step27 = new ProcessingStep(groupId, 3, 2, ProcessingStepType.ChainEntityIdentification, "Apples2007", ProcessingStepObjectType.ChainEntityID, 2, 100, DateTime.Now, 200);



        //}

        ///// <summary>
        ///// Create a valid instance of Processing Steps
        ///// </summary>
        //[Test]
        //public void Technical_Valid_Contructor()
        //{
        //    DateTime time = DateTime.Now;
        //    int chainEntityId = 1;
        //    int locationId = 2;
        //    bool isPrescibed = true;
        //    string parentIdentification = "parentIdentification";
        //    string childIdentification = "childIdentification";
        //    double prescribedStartValue = 10;
        //    double prescribedEndValue = 20;
        //    double documentedValue = 30;
            
        //    ProcessingStep ps =
        //        new ProcessingStep(ProcessingStepType.Exposure, PackageType.Container, chainEntityId, locationId, isPrescibed, parentIdentification, childIdentification,
        //                           time, prescribedStartValue, prescribedEndValue, documentedValue);

        //    Assert.AreEqual(chainEntityId, ps.ChainEntityId);
        //    Assert.AreEqual(locationId, ps.LocationId);
        //    Assert.AreEqual(isPrescibed, ps.IsPrescibed);
        //    Assert.AreEqual(parentIdentification, ps.ParentIdentification);
        //    Assert.AreEqual(childIdentification, ps.ChildIdentification);
        //    Assert.AreEqual(time, ps.DateTime);
        //    Assert.AreEqual(prescribedStartValue, ps.PrescribedStartValue);
        //    Assert.AreEqual(prescribedEndValue, ps.PrescribedEndValue);
        //    Assert.AreEqual(documentedValue, ps.DocumentedValue);
        //}

        ///// <summary>
        ///// Create a invalid instance of Processing Steps
        ///// </summary>
        //[Test]
        //public void Technical_Invalid_Contructor()
        //{
        //    DateTime time = DateTime.Now;
        //    int chainEntityId = 1;
        //    int locationId = 2;
        //    bool isPrescibed = true;
        //    string parentIdentification = "parentIdentification";
        //    string childIdentification = "childIdentification";
        //    double prescribedStartValue = 10;
        //    double prescribedEndValue = 20;
        //    double documentedValue = 30;



        //    //range of prescribed is wrong
        //    try
        //    {
        //        ProcessingStep ps =
        //        new ProcessingStep(ProcessingStepType.Exposure, PackageType.Container, chainEntityId, locationId, isPrescibed, parentIdentification, childIdentification,
        //                           time, prescribedEndValue,prescribedStartValue, documentedValue);
        //        Assert.Fail();
        //    }
        //    catch(ArgumentException ae)
        //    {
        //        Assert.AreEqual(ae.Message, "prescribed start range must be lower or equal than the end value");
                
        //    }


        //    //parentIdentification is null
        //    try
        //    {
        //        ProcessingStep ps =
        //        new ProcessingStep(ProcessingStepType.Exposure, PackageType.Container, chainEntityId, locationId, isPrescibed, null, childIdentification,
        //                           time, prescribedStartValue,prescribedEndValue, documentedValue);
        //        Assert.Fail();
        //    }
        //    catch (ArgumentNullException e)
        //    {
        //        Assert.AreEqual(e.ParamName, "parentIdentification");

        //    }

        //    //parentIdentification is empty string
        //    try
        //    {
        //        ProcessingStep ps =
        //        new ProcessingStep(ProcessingStepType.Exposure, PackageType.Container, chainEntityId, locationId, isPrescibed, String.Empty, childIdentification,
        //                           time, prescribedStartValue, prescribedEndValue, documentedValue);
        //        Assert.Fail();
        //    }
        //    catch (ArgumentException e)
        //    {
        //        Assert.AreEqual(e.Message, "parentIdentification");

        //    }

        //    //parentIdentification is empty space
        //    try
        //    {
        //        ProcessingStep ps =
        //        new ProcessingStep(ProcessingStepType.Exposure, PackageType.Container, chainEntityId, locationId, isPrescibed, " ", childIdentification,
        //                           time, prescribedStartValue, prescribedEndValue, documentedValue);
        //        Assert.Fail();
        //    }
        //    catch (ArgumentException e)
        //    {
        //        Assert.AreEqual(e.Message, "parentIdentification");

        //    }


        //    //childIdentification is null
        //    try
        //    {
        //        ProcessingStep ps =
        //        new ProcessingStep(ProcessingStepType.Exposure, PackageType.Container, chainEntityId, locationId, isPrescibed, parentIdentification, null,
        //                           time, prescribedStartValue, prescribedEndValue, documentedValue);
        //        Assert.Fail();
        //    }
        //    catch (ArgumentNullException e)
        //    {
        //        Assert.AreEqual(e.ParamName, "childIdentification");

        //    }

        //    //childIdentification is empty string
        //    try
        //    {
        //        ProcessingStep ps =
        //        new ProcessingStep(ProcessingStepType.Exposure, PackageType.Container, chainEntityId, locationId, isPrescibed, parentIdentification, String.Empty,
        //                           time, prescribedStartValue, prescribedEndValue, documentedValue);
        //        Assert.Fail();
        //    }
        //    catch (ArgumentException e)
        //    {
        //        Assert.AreEqual(e.Message, "childIdentification");

        //    }

        //    //childIdentification is empty space
        //    try
        //    {
        //        ProcessingStep ps =
        //        new ProcessingStep(ProcessingStepType.Exposure, PackageType.Container, chainEntityId, locationId, isPrescibed, parentIdentification, " ",
        //                           time, prescribedStartValue, prescribedEndValue, documentedValue);
        //        Assert.Fail();
        //    }
        //    catch (ArgumentException e)
        //    {
        //        Assert.AreEqual(e.Message, "childIdentification");

        //    }

        //    //datetime is DateTime.MinValue
        //    try
        //    {
        //        ProcessingStep ps =
        //        new ProcessingStep(ProcessingStepType.Exposure, PackageType.Container, chainEntityId, locationId, isPrescibed, parentIdentification, childIdentification,
        //                           DateTime.MinValue, prescribedStartValue, prescribedEndValue, documentedValue);
        //        Assert.Fail();
        //    }
        //    catch (ArgumentException e)
        //    {
        //        Assert.AreEqual(e.Message, "invalid Datetime");

        //    }

        //    //datetime > DateTime.Now
        //    try
        //    {
        //        ProcessingStep ps =
        //        new ProcessingStep(ProcessingStepType.Exposure, PackageType.Container, chainEntityId, locationId, isPrescibed, parentIdentification, childIdentification,
        //                           DateTime.Now.AddDays(1), prescribedStartValue, prescribedEndValue, documentedValue);
        //        Assert.Fail();
        //    }
        //    catch (ArgumentException e)
        //    {
        //        Assert.AreEqual(e.Message, "invalid Datetime");

        //    }
        //}
    }


}
