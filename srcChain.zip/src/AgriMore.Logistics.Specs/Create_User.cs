using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    ///     <userstory>
    ///         <no>7</no>
    ///         <role>all</role>
    ///         <feature>login agrimore.Logistics</feature>
    ///         <benefit>I can use the agrimore system</benefit>
    ///     </userstory>
    /// </summary>
    [TestFixture]
    public class Create_User
    {
        #region Setup/Teardown

        /// <summary>
        /// Setups this instance.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            shipper = repositoryFactory.GetRoleRepository().GetOne("Shipper");
            grower = repositoryFactory.GetRoleRepository().GetOne("Grower");
            receiver = repositoryFactory.GetRoleRepository().GetOne("Receiver");

            transactionManager = new TransactionManager();
            transactionManager.BeginTransaction();

            new RepositoryFactory().InitializeTestData();
        }

        /// <summary>
        /// Tears the down.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            transactionManager.RollbackTransaction();
        }

        #endregion

        private TransactionManager transactionManager;
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();
        private Role shipper;
        private Role grower;
        private Role receiver;

        /// <summary>
        /// Add_s the empty_ role_ to_ user.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Add_Empty_Role_To_User()
        {
            User user = new User("username1", "password", "firstname1", "lastname1", new Role[] {shipper, grower});
            user.AddRole(null);
        }

        /// <summary>
        /// Add_s the empty_ role_ to_ user.
        /// </summary>
        [Test]
        public void Add_Role_To_User()
        {
            User user = new User("username1", "password", "firstname1", "lastname1", new Role[] {shipper});

            user.AddRole(grower);

            bool foundShipperRole = false;
            bool foundGrowerRole = false;

            foreach (Role role in user.Roles)
            {
                if (role.Name.Equals("Shipper"))
                {
                    foundShipperRole = true;
                }
                if (role.Name.Equals("Grower"))
                {
                    foundGrowerRole = true;
                }
            }

            Assert.IsTrue(foundShipperRole);
            Assert.IsTrue(foundGrowerRole);
        }

        /// <summary>
        ///     <scenario>
        ///         <no>7</no>
        ///         <given>
        ///             Shipment is already in shipper location
        ///         </given>
        ///         <when>create a shipment</when>
        ///         <ensure>shipment can not be created</ensure>
        ///     </scenario>
        /// </summary>
        [Test]
        public void Create_Valid_User()
        {
            User u1 = new User("username1", "password", "firstname1", "lastname1", new Role[] {shipper, grower});
            User u2 = new User("username2", "password", "firstname2", "lastname2", new Role[] {shipper, grower});

            Assert.AreEqual("username1", u1.Username);
            Assert.AreEqual("password", u1.Password);
            Assert.AreEqual("firstname1", u1.FirstName);
            Assert.AreEqual("lastname1", u1.LastName);

            int roleCounter = 0;

            foreach (Role role in u1.Roles)
            {
                if (role.Name.Equals("Shipper"))
                {
                    roleCounter++;
                }
                if (role.Name.Equals("Grower"))
                {
                    roleCounter++;
                }
            }
            Assert.AreEqual(2, roleCounter);
            Assert.AreEqual(0, u1.Uid);

            Assert.AreEqual(u1, u1);
            Assert.AreNotEqual(u1, u2);
        }

        /// <summary>
        /// Find No User With UserIsknownSpecification
        /// </summary>
        [Test]
        public void Find_No_User_With_UserIsknownSpecification()
        {
            IRepository<User> rep = new RepositoryFactory().CreateRepository<User>();
            User u1 = new User("username1", "password", "firstname1", "lastname1", new Role[] {shipper, grower});
            User u2 = new User("username2", "password", "firstname2", "lastname2", new Role[] {shipper, grower});

            rep.Add(u1);
            rep.Add(u2);

            ICollection<User> foundUsers = rep.Find(new UserIsAuthenticatedSpecification("username3", "password"));
            Assert.AreEqual(0, foundUsers.Count);
        }

        /// <summary>
        /// Find User With Specific Role
        /// </summary>
        [Test]
        public void Find_User_With_Specific_Role()
        {
            IRepository<User> rep = new RepositoryFactory().CreateRepository<User>();
            User u1 = new User("username1", "password", "firstname1", "lastname1", new Role[] {shipper, grower});
            User u2 =
                new User("username2", "password", "firstname2", "lastname2", new Role[] {shipper, grower, receiver});

            rep.Add(u1);
            rep.Add(u2);

            ICollection<User> foundSingleUser = rep.Find(new UserByUserNameSpecification("username2"));
            Assert.AreEqual(1, foundSingleUser.Count);
            foreach (User user in foundSingleUser)
            {
                Assert.AreEqual(u2, user);
            }
        }

        /// <summary>
        /// Find User With UserIsAuthenticatedSpecification
        /// </summary>
        [Test]
        public void Find_User_With_UserIsknownSpecification()
        {
            IRepository<User> rep = new RepositoryFactory().CreateRepository<User>();
            User u1 = new User("username1", "password", "firstname1", "lastname1", new Role[] {shipper, grower});
            User u2 = new User("username2", "password", "firstname2", "lastname2", new Role[] {shipper, grower});

            rep.Add(u1);
            rep.Add(u2);

            ICollection<User> foundSingleUser = rep.Find(new UserIsAuthenticatedSpecification("username1", "password"));
            Assert.AreEqual(1, foundSingleUser.Count);
            foreach (User user in foundSingleUser)
            {
                Assert.AreEqual(u1, user);
            }
        }

        /// <summary>
        /// Technical_s the name of the test_ user_ constructor_ with_ empty_ first.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_User_Constructor_With_Empty_FirstName()
        {
            new User("1", "2", string.Empty, "4", new Role[] {shipper, grower});
        }

        /// <summary>
        /// Technical_s the name of the test_ user_ constructor_ with_ empty_ last.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_User_Constructor_With_Empty_LastName()
        {
            new User("1", "2", "3", string.Empty, new Role[] {shipper, grower});
        }

        /// <summary>
        /// Technical_s the test_ user_ constructor_ with_ empty_ password.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_User_Constructor_With_Empty_Password()
        {
            new User("1", string.Empty, "firstname1", "4", new Role[] {shipper, grower});
        }

        /// <summary>
        /// Technical_s the name of the test_ user_ constructor_ with_ empty_ user.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_User_Constructor_With_Empty_UserName()
        {
            new User(string.Empty, "password", "firstname1", "4", new Role[] {shipper, grower});
        }

        /// <summary>
        /// Technical_s the name of the test_ user_ constructor_ with_ spaced_ first.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_User_Constructor_With_Spaced_FirstName()
        {
            new User("1", "2", "   ", "4", new Role[] {shipper, grower});
        }

        /// <summary>
        /// Technical_s the name of the test_ user_ constructor_ with_ spaced_ last.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_User_Constructor_With_Spaced_LastName()
        {
            new User("1", "2", "3", "   ", new Role[] {shipper, grower});
        }

        /// <summary>
        /// Technical_s the test_ user_ constructor_ with_ spaced_ password.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_User_Constructor_With_Spaced_Password()
        {
            new User("1", "   ", "firstname1", "4", new Role[] {shipper, grower});
        }

        /// <summary>
        /// Technical_s the name of the test_ user_ constructor_ with_ spaced_ user.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_User_Constructor_With_Spaced_UserName()
        {
            new User("   ", "password", "firstname1", "4", new Role[] {shipper, grower});
        }

        /// <summary>
        /// Technical_s the name of the test_ user_ constructor_ without_ first.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_User_Constructor_Without_FirstName()
        {
            new User("username", "password", null, "lastname1", new Role[] {shipper, grower});
        }

        /// <summary>
        /// Technical_s the name of the test_ user_ constructor_ without_ last.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_User_Constructor_Without_LastName()
        {
            new User("username", "password", "firstname1", null, new Role[] {shipper, grower});
        }

        /// <summary>
        /// Technical_s the test_ user_ constructor_ without_ password.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_User_Constructor_Without_Password()
        {
            new User("username", null, "firstname1", "lastname1", new Role[] {shipper, grower});
        }

        /// <summary>
        /// Technical_s the test_ user_ constructor_ without_ username.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_User_Constructor_Without_Username()
        {
            new User(null, "password", "firstname1", "lastname1", new Role[] {shipper, grower});
        }

        /// <summary>
        /// Technical_s the test_ user_ getters.
        /// </summary>
        [Test]
        public void Technical_Test_User_Getters()
        {
            User user = new User("1", "2", "3", "4", new Role[] {shipper, grower});

            Assert.IsFalse(user.Equals(null));
            Assert.AreEqual("1".GetHashCode(), user.GetHashCode());
            Assert.AreEqual("3 4", user.ToString());
        }
    }
}