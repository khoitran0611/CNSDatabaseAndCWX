using System;
using AgriMore.Logistics.Domain;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
	/// <summary>
	/// 
	/// </summary>
	[TestFixture]
	public class Technical_Range
	{
		/// <summary>
		/// technical test
		/// </summary>
		[Test]
		public void Technical_Test_String_Range()
		{
			Range<string> range = new Range<string>("b", "d");
			Assert.AreEqual("b", range.Start);
			Assert.AreEqual("d", range.End);
			Assert.IsTrue(range.Contains("b"));
			Assert.IsTrue(range.Contains("c"));
			Assert.IsTrue(range.Contains("d"));
			Assert.IsTrue(range.Contains("bb"));
			Assert.IsFalse(range.Contains("e"));

			range.Extend("e");
			Assert.AreEqual("b", range.Start);
			Assert.AreEqual("e", range.End);
			Assert.IsTrue(range.Contains("b"));
			Assert.IsTrue(range.Contains("d"));
			Assert.IsTrue(range.Contains("e"));
		}
		/// <summary>
		/// Technical test
		/// </summary>
		[Test]
		public void Technical_Test_Int_Range()
		{
			Range<int> range = new Range<int>(0, 5);
			Assert.AreEqual(0, range.Start);
			Assert.AreEqual(5, range.End);
			Assert.IsTrue(range.Contains(0));
			Assert.IsTrue(range.Contains(3));
			Assert.IsTrue(range.Contains(5));

			Assert.IsFalse(range.Contains(-1));
			Assert.IsFalse(range.Contains(6));

			range.Extend(10);
			Assert.AreEqual(0, range.Start);
			Assert.AreEqual(10, range.End);
			Assert.IsTrue(range.Contains(0));
			Assert.IsTrue(range.Contains(5));
			Assert.IsTrue(range.Contains(10));

			Assert.IsFalse(range.Contains(-1));
			Assert.IsFalse(range.Contains(11));
		}

        /// <summary>
        /// Technical_s the test_ date time_ range.
        /// </summary>
        [Test]
        public void Technical_Test_DateTime_Range()
        {
            //yyyy:mm:dd
            DateTime start=new DateTime(2008,1,1,12,12,12);
            DateTime end=new DateTime(2008,2,1,12,12,12);


            Range<DateTime> range = new Range<DateTime>(start, end);

            Assert.AreEqual(new DateTime(2008,1,1,12,12,12), range.Start);
            Assert.AreEqual(new DateTime(2008, 2, 1, 12, 12, 12), range.End);

            Assert.IsTrue(range.Contains(new DateTime(2008, 1, 1, 12, 12, 12)));
            Assert.IsTrue(range.Contains(new DateTime(2008, 1, 1, 12, 12, 13)));
            Assert.IsTrue(range.Contains(new DateTime(2008, 2, 1, 12, 12, 12)));

            Assert.IsFalse(range.Contains(new DateTime(2008, 1, 1, 12, 12, 11)));
            Assert.IsFalse(range.Contains(new DateTime(2008, 2, 1, 12, 12, 13)));
            
            // Extend the range to the 1st of march.
            range.Extend(new DateTime(2008, 3, 1, 12, 12, 12));
            Assert.AreEqual(new DateTime(2008, 1, 1, 12, 12, 12), range.Start);
            Assert.AreEqual(new DateTime(2008, 3, 1, 12, 12, 12), range.End);
            Assert.IsTrue(range.Contains(new DateTime(2008, 1, 15, 12, 12, 11)));
            Assert.IsTrue(range.Contains(new DateTime(2008, 1, 31, 12, 12, 11)));

            Assert.IsFalse(range.Contains(new DateTime(2007, 1, 31, 12, 12, 11)));
        }

        /// <summary>
        /// Technical_s the test_ int_ range_ end_ higher_ as_ begin.
        /// </summary>
        [ExpectedException(typeof(ArgumentException))]
	    [Test]
        public void Technical_Test_Int_Range_End_Higher_As_Begin()
	    {
            new Range<int>(5, 0);
	    }
	}
}