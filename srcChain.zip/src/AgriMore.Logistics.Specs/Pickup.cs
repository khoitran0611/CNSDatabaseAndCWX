using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Repository.Memory;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    ///<summary>
    ///    <userstory>
    ///        <no>5.2</no>
    ///        <role>TransportEquipment</role>
    ///        <feature>Pickup a sfp acording to the details in the shipment</feature>
    ///        <benefit>I can deliver the sfp</benefit>
    ///    </userstory>
    ///</summary>
    [TestFixture]
    public class Pickup
    {
        private readonly PackingMaterial Plastic = new PackingMaterial("Plastic");
        #region Setup/Teardown

        /// <summary>
        /// Sets the test up.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            //plasticFlowBox = PackageType.FlowPack;
            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            plasticFlowBox = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            PrimaryProduct primaryProduct2 = new PrimaryProduct(validProductionAreaId2, validLifeCycleId2);

            ICollection<PrimaryProduct> primaryProducts1 = new List<PrimaryProduct>();
            primaryProducts1.Add(primaryProduct);
            ICollection<PrimaryProduct> primaryProducts2 = new List<PrimaryProduct>();
            primaryProducts2.Add(primaryProduct2);

            chainEntity = new ChainEntity("name");

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);
            Identification[] identifications1 = {new Identification("1", chainEntity)};
            Identification[] identifications2 = {new Identification("2", chainEntity)};
            Identification[] identifications3 = {new Identification("3", chainEntity)};
            package1 = new Package(plasticFlowBox, primaryProducts1, dateTimeOfPacking, identifications1);
            package2 = new Package(plasticFlowBox, primaryProducts2, dateTimeOfPacking, identifications2);
            package3 = new Package(plasticFlowBox, primaryProducts2, dateTimeOfPacking, identifications3);
        }

        /// <summary>
        /// Tears the down.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        #endregion

        private Package package1;
        private Package package2;
        private Package package3;

        private ChainEntity chainEntity;
        private PackageType plasticFlowBox;
        private const string validProductionAreaId2 = "AAAPA0800002";
        private const string validLifeCycleId2 = "AAAPC0800002";
        private const string validProductionAreaId = "AAAPA0800001";
        private const string validLifeCycleId = "AAAPC0800001";

        /// <summary>
        ///     <scenario>
        ///         <no>2</no>
        ///         <given>There is a shipment for the forwarder
        ///             <and>the shipment is already pickuped</and>
        ///         </given>
        ///         <when>the forwarder picks up the shipment</when>
        ///         <ensure> that trying to pickup a shipment two times, the second time no pickup takes place.</ensure> 
        ///     </scenario>
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentException))]
        public void Pickup_The_Same_Shipment_Twice()
        {
            Address shipperAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address forwarderAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address receiverAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");


            Location shipperLocation = new Location("21");
            shipperAddress.AddLocation(shipperLocation);
            Location forwarderLocation = new Location("41");
            forwarderAddress.AddLocation(forwarderLocation);
            Location receiverLocation = new Location("51");
            receiverAddress.AddLocation(receiverLocation);


            IRepository<Location> memoryLocationRepository = new RepositoryFactory().CreateRepository<Location>();
            memoryLocationRepository.Add(shipperLocation);
            memoryLocationRepository.Add(receiverLocation);
            memoryLocationRepository.Add(forwarderLocation);

            ICollection<Package> newPackages = new Collection<Package>();
            newPackages.Add(package3);
            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(prescribed.Start);
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            //ExposureDocument exposureDocument = new ExposureDocument(exposure);
            IList<Exposure> exposures = new List<Exposure>();
            exposures.Add(exposure);

            shipperLocation.Put(package3, exposures, DateTime.Now);

            ChainEntity shipper = new ChainEntity("Shipper");
            shipper.AddAddress(shipperAddress);
            ChainEntity receiver = new ChainEntity("Receiver");
            receiver.AddAddress(receiverAddress);
            ChainEntity forwarder = new ChainEntity("Forwarder");
            forwarder.AddAddress(forwarderAddress);

            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;
            IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            shipmentExposures.Add(shipmentExposure);

            Shipment shipment =
                new Shipment(shipper, receiver, forwarder, string.Empty, string.Empty, string.Empty, newPackages,
                             shipperLocation, new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl",
                             "receiver@cc.nl", shipmentExposures);
            Assert.IsTrue(shipperLocation.Contains(package3));
            Assert.IsTrue(shipperLocation.Contains(package3));

            TransportEquipment transportEquipment = new TransportEquipment(shipper, forwarderLocation);
            DateTime pickupTime = DateTime.Now;
            try
            {
                //should work the first time
                transportEquipment.Pickup(shipment, pickupTime, shipperLocation, exposures);
            }
            catch (ArgumentException)
            {
                Assert.Fail("Should pickup the first time");
            }
            //should fail second time, throw exception.
            transportEquipment.Pickup(shipment, pickupTime, shipperLocation, exposures);
        }

        /// <summary>
        /// 	<scenario>
        /// 		<no>1</no>
        /// 		<given>There is a shipment for the forwarder</given>
        /// 		<when>the forwarder picks up the shipment</when>
        /// 		<ensure>the shipment is picked up
        /// <and>the location of the shipment and included
        /// packages is changed to the location of the forwarder</and>
        /// 		</ensure>
        /// 	</scenario>
        /// </summary>
        [Test]
        public void Pickup_The_Shipment()
        {
            ICollection<Package> packages = new Collection<Package>();

            Address shipperAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address forwarderAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address receiverAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address testAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");


            Location shipperLocation = new Location("20");
            shipperAddress.AddLocation(shipperLocation);

            Location forwarderLocation = new Location("4");
            forwarderAddress.AddLocation(forwarderLocation);

            Location receiverLocation = new Location("5");
            receiverAddress.AddLocation(receiverLocation);

            Location testLocation = new Location("6");
            testAddress.AddLocation(testLocation);

            IRepository<Location> memoryLocationRepository = new RepositoryFactory().CreateRepository<Location>();
            memoryLocationRepository.Add(shipperLocation);
            memoryLocationRepository.Add(receiverLocation);
            memoryLocationRepository.Add(forwarderLocation);

            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure = new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            Exposure exposure2 = new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            //ExposureDocument exposureDocument1 = new ExposureDocument(exposure);
            //ExposureDocument exposureDocument2 = new ExposureDocument(exposure2);
            IList<Exposure> exposures1 = new List<Exposure>();
            IList<Exposure> exposures2 = new List<Exposure>();
            exposures1.Add(exposure);
            exposures2.Add(exposure2);

            packages.Add(package1);
            packages.Add(package2);

            shipperLocation.Put(package1, exposures1, DateTime.Now);
            shipperLocation.Put(package2, exposures2, DateTime.Now);

            ChainEntity shipper = new ChainEntity("Shipper");
            shipper.AddAddress(shipperAddress);

            ChainEntity forwarder = new ChainEntity("Forwarder");
            forwarder.AddAddress(forwarderAddress);

            ChainEntity receiver = new ChainEntity("Receiver");
            receiver.AddAddress(receiverAddress);

            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;
            IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            shipmentExposures.Add(shipmentExposure);


            Shipment shipment =
                new Shipment(shipper, receiver, forwarder, string.Empty, string.Empty, string.Empty, packages,
                             shipperLocation, new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl",
                             "receiver@cc.nl", shipmentExposures);

            // check of the shipper have the shipment.
            // this can be done by checking if the location has the shipment

            Assert.IsTrue(shipperLocation.Contains(package1));
            Assert.IsTrue(shipperLocation.Contains(package2));

            DateTime pickupTime = DateTime.Now;
            shipment.Pickup(pickupTime);
            Assert.AreEqual(shipment.RealDateTimeOfPickup, pickupTime);

            TransportEquipment transportEquipment = new TransportEquipment(forwarder, forwarderLocation);

            //realPickUpLocation argument test
            try
            {
                transportEquipment.Pickup(shipment, pickupTime, null, exposures2);
                Assert.Fail();
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("realPickUpLocation", e.ParamName);
            }
            //exposureDocument argument test
            try
            {
                transportEquipment.Pickup(shipment, pickupTime, shipperLocation, null);
                Assert.Fail();
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("exposures", e.ParamName);
            }

            transportEquipment.Pickup(shipment, pickupTime, shipperLocation, exposures2);

            Assert.IsFalse(shipperLocation.Contains(package1));
            Assert.IsFalse(shipperLocation.Contains(package2));
            Assert.IsTrue(transportEquipment.Contains(shipment));

            foreach (Package package in shipment.Packages)
            {
                // check if all packages have been moved to the location of the transportEquipment
                Assert.IsFalse(shipperLocation.Contains(package), "The package should not be in shipper stock.");
                Assert.IsTrue(forwarderLocation.Contains(package),
                              "The package should be in transportEquipment location.");
            }

            try
            {
                transportEquipment.Pickup(shipment, pickupTime, shipperLocation, exposures2);
                Assert.Fail();
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual("Cannot pickup this shipment, the shipment is already in the shipments list", e.Message);
            }
            
        }

        /// <summary>
        ///     <scenario>
        ///         <no>1</no>
        ///         <given>There is a shipment for the forwarder
        ///             <and>the packages of the shipment are in different locations</and>
        ///         </given>
        ///         <when>the forwarder picks up the shipment</when>
        ///         <ensure>the shipment could not be picked up 
        ///         
        ///         </ensure>
        ///     </scenario>
        /// </summary>
        [Test]
        public void Pickup_A_Shipment_With_Packages_In_Different_Locations()
        {
            ICollection<Package> packagesToShip = new Collection<Package>();

            Address shipperAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address forwarderAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address receiverAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address testAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");


            Location shipperLocation = new Location("20");
            shipperAddress.AddLocation(shipperLocation);

            Location forwarderLocation = new Location("4");
            forwarderAddress.AddLocation(forwarderLocation);

            Location receiverLocation = new Location("5");
            receiverAddress.AddLocation(receiverLocation);

            Location testLocation = new Location("6");
            testAddress.AddLocation(testLocation);

            IRepository<Location> memoryLocationRepository = new RepositoryFactory().CreateRepository<Location>();
            memoryLocationRepository.Add(shipperLocation);
            memoryLocationRepository.Add(receiverLocation);
            memoryLocationRepository.Add(forwarderLocation);

            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure = new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            Exposure exposure2 = new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            //ExposureDocument exposureDocument1 = new ExposureDocument(exposure);
            //ExposureDocument exposureDocument2 = new ExposureDocument(exposure2);
            IList<Exposure> exposures1 = new List<Exposure>();
            IList<Exposure> exposures2 = new List<Exposure>();
            exposures1.Add(exposure);
            exposures2.Add(exposure2);

            packagesToShip.Add(package1);
            packagesToShip.Add(package2);

            shipperLocation.Put(package1, exposures1, DateTime.Now);
            receiverLocation.Put(package2, exposures2, DateTime.Now);

            ChainEntity shipper = new ChainEntity("Shipper");
            shipper.AddAddress(shipperAddress);

            ChainEntity forwarder = new ChainEntity("Forwarder");
            forwarder.AddAddress(forwarderAddress);

            ChainEntity receiver = new ChainEntity("Receiver");
            receiver.AddAddress(receiverAddress);

            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;
            IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            shipmentExposures.Add(shipmentExposure);

            Shipment shipment =
                new Shipment(shipper, receiver, forwarder, string.Empty, string.Empty, string.Empty, packagesToShip,
                             shipperLocation, new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl",
                             "receiver@cc.nl", shipmentExposures);

            DateTime pickupTime = DateTime.Now;
            shipment.Pickup(pickupTime);

            TransportEquipment transportEquipment = new TransportEquipment(forwarder, forwarderLocation);

            //ArePackagesInPickupLocation test
            try
            {
                transportEquipment.Pickup(shipment, pickupTime, shipperLocation, exposures2);
                Assert.Fail();
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual("Cannot pickup shipment, not all packages have arrived at the pickup location", e.Message);
            }
        }


        /// <summary>
        /// Technical_s the test_ transport equipment.
        /// </summary>
        [Test]
        public void Technical_Test_TransportEquipment()
        {
            Address forwarderAddress1 =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Location forwarderLocation = new Location("4");
            forwarderAddress1.AddLocation(forwarderLocation);
            ChainEntity forwarder = new ChainEntity("Forwarder");
            forwarder.AddAddress(forwarderAddress1);

            //forwarder argument test
            try
            {
                new TransportEquipment(null, forwarderLocation);
                //Assert.Fail();
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("forwarder", e.ParamName);
            }

            //location argument test
            try
            {
                new TransportEquipment(forwarder, null);
                //Assert.Fail();
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("location", e.ParamName);
            }
            TransportEquipment transportEquipment2 = new TransportEquipment(forwarder, forwarderLocation);
            Assert.IsFalse(transportEquipment2.Contains(null));

            DateTime pickupTime = DateTime.Now;

            //shipment argument test
            try
            {
                TransportEquipment transportEquipment3 = new TransportEquipment(forwarder, forwarderLocation);
                transportEquipment3.Pickup(null, pickupTime, forwarderLocation, null);
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("shipment", e.ParamName);
            }
            
            TransportEquipment transportEquipment4 = new TransportEquipment(forwarder, forwarderLocation);
            transportEquipment4.Uid = 4;
            Assert.AreEqual(4, transportEquipment4.Uid);
         
        }
    }
}