using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    ///     <userstory>
    ///         <no>5.1</no>
    ///         <role>Grower/grower association</role>
    ///         <feature>Move semi finished product</feature>
    ///         <benefit>I can make a shipment</benefit>
    ///     </userstory>
    /// </summary>
    [TestFixture]
    public class Create_Shipment
    {
        #region Setup/Teardown

        /// <summary>
        /// Setups this instance.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            transactionManager.BeginTransaction();

            new RepositoryFactory().InitializeTestData();


            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            plasticFlowBox = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );


            chainEntity = new ChainEntity("name");

            identifications1 = new Identification[] {new Identification("1", chainEntity)};
            identifications2 = new Identification[] {new Identification("2", chainEntity)};
            identifications3 = new Identification[] {new Identification("3", chainEntity)};

            PrimaryProduct primaryProduct1 = new PrimaryProduct("AAAPA0800001", "AAAPC0800001");
            primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct1);
            dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

            validDateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);
            PrimaryProduct primaryProduct3 = new PrimaryProduct(validProductionAreaId3, validLifeCycleId3);

            ICollection<PrimaryProduct> primaryProducts1 = new List<PrimaryProduct>();
            primaryProducts1.Add(primaryProduct1);

            ICollection<PrimaryProduct> primaryProducts2 = new List<PrimaryProduct>();
            primaryProducts2.Add(primaryProduct1);

            ICollection<PrimaryProduct> primaryProducts3 = new List<PrimaryProduct>();
            primaryProducts3.Add(primaryProduct3);

            shipper = new ChainEntity("shipper name");
            package1 = new Package(plasticFlowBox, primaryProducts1, validDateTimeOfPacking, identifications2);

            packages.Add(package1);

            package2 = new Package(plasticFlowBox, primaryProducts1, validDateTimeOfPacking, identifications3);
            packages.Add(package2);


            IRepository<Location> memoryLocationRepository = new RepositoryFactory().CreateRepository<Location>();

            Location package1Location = new Location("1");
            Location package2Location = new Location("2");

            memoryLocationRepository.Add(package1Location);
            memoryLocationRepository.Add(package2Location);


            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));

            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            //ExposureDocument exposureDocument = new ExposureDocument(exposure);
            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);

            package1Location.Put(package1, exposures1, DateTime.Now);
            package2Location.Put(package2, exposures1, DateTime.Now);
        }

        /// <summary>
        /// Tears the down.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            transactionManager.RollbackTransaction();
        }

        #endregion

        private readonly PackingMaterial Plastic = new PackingMaterial("Plastic");

        private readonly TransactionManager transactionManager = new TransactionManager();

        private Package package;
        private ChainEntity shipper;
        private Package package1;
        private Package package2;
        private readonly ICollection<Package> packages = new Collection<Package>();
        private DateTime validDateTimeOfPacking;
        private const string validProductionAreaId3 = "AAAPA0800003";
        private const string validLifeCycleId3 = "AAAPC0800003";
        private Identification[] identifications1;
        private Identification[] identifications2;
        private Identification[] identifications3;
        private ICollection<PrimaryProduct> primaryProducts;
        private DateTime dateTimeOfPacking;

        private ChainEntity chainEntity;
        private PackageType plasticFlowBox;


        /// <summary>
        ///     <scenario>
        ///         <no>2</no>
        ///         <given>
        ///             Shipment is already in shipper location
        ///         </given>
        ///         <when>create a shipment</when>
        ///         <ensure>shipment can not be created</ensure>
        ///     </scenario>
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentException))]
        public void Create_Same_Shipment_With_Identical_Locations()
        {
            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            IRepository<Shipment> memoryShipmentRepository = new RepositoryFactory().CreateRepository<Shipment>();

            ChainEntity receiver = new ChainEntity("Receiver");
            ChainEntity forwarder = new ChainEntity("Forwarder");
            ChainEntity shippertje = new ChainEntity("Shipper");

            Address receiverAddress1 =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address forwarderAddress2 =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address shippertjeAddress3 =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");

            Location shipperLocation = new Location("3");
            Location receiverLocation = new Location("1");
            Location forwarderLocation = new Location("1");

            receiverAddress1.AddLocation(shipperLocation);
            forwarderAddress2.AddLocation(receiverLocation);
            shippertjeAddress3.AddLocation(forwarderLocation);

            receiver.AddAddress(receiverAddress1);
            forwarder.AddAddress(forwarderAddress2);
            shippertje.AddAddress(shippertjeAddress3);

            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;
            IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            shipmentExposures.Add(shipmentExposure);

            Shipment shipment =
                new Shipment(shipper, receiver, forwarder, "", "", "", packages, shipperLocation, receiverLocation,
                             pickUpRange, deliverRange, "forwarder@bb.nl", "receiver@cc.nl", shipmentExposures);
            memoryShipmentRepository.Add(shipment);
            memoryShipmentRepository.Add(shipment);
        }

        /// <summary>
        /// Create_s the shipment_ without_ forwarder.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void Create_Shipment_Without_Forwarder()
        {
            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            Location shipperLocation = new Location("1");
            Location receiverLocation = new Location("2");

            ChainEntity dummyChainEntity = new ChainEntity("dummyChainEntity");
            new Shipment(dummyChainEntity, dummyChainEntity, null, "", "", "", new Package[] {package1}, shipperLocation, receiverLocation,
                         pickUpRange, deliverRange, "forwarder@bb.nl", "receiver@cc.nl", null);
        }


        ///// <summary>
        ///// Create a chainEntity with no locations
        ///// </summary>
        //[Test]
        //[ExpectedException(typeof(ArgumentException))]
        //public void Create_Shipment_With_No_Locations()
        //{
        //    new ChainEntity("shipper name", new Location[] { });
        //}

        /// <summary>
        /// Create_s the shipment_ without_ package.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void Create_Shipment_Without_Package()
        {
            new Shipment(null, null, null, null, null, null, null, null, null, null, null, null, null, null);
        }

        /// <summary>
        /// Tests the shipment without the receiver.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void Create_Shipment_Without_Receiver()
        {
            ChainEntity dummyChainEntity = new ChainEntity("dummyChainEntity");
            new Shipment(dummyChainEntity, null, null, null, null, null, null, null, null, null, null, null, null, null);
        }

        /// <summary>
        /// Creates the shipment without shipper.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void Create_Shipment_Without_Shipper()
        {
            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            Location shipperLocation = new Location("1");
            Location receiverLocation = new Location("2");
            ChainEntity dummyChainEntity = new ChainEntity("dummyChainEntity");
            new Shipment(null, dummyChainEntity, null, "", "", "", new Package[] {package1}, shipperLocation, receiverLocation,
                         pickUpRange, deliverRange, "forwarder@bb.nl", "receiver@cc.nl", null);
        }


        /// <summary>
        ///     <scenario>
        ///         <no>1</no>
        ///         <given>a semi finished product in it's own location
        ///         <and>i have my ChainEntity information</and>
        ///         <and>i have my receiver information</and>
        ///         <and>i have my shipment information</and>
        ///         <and>i know the forwarder</and>
        ///         </given>
        ///         <when>create a shipment</when>
        ///         <ensure>sfp is in created shipment 
        ///         <and>sfp is in location</and> 
        ///         <and>sfp is not already in a shipment</and>
        ///         </ensure>
        ///     </scenario>
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentException))]
        public void Create_Valid_Shipment()
        {
            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            package = new Package(plasticFlowBox, primaryProducts, dateTimeOfPacking, identifications1);

            IRepository<Shipment> memoryShipmentRepository = new RepositoryFactory().CreateRepository<Shipment>();

            ICollection<Package> shipmentPackages = new Package[] {package};

            //Receiver
            Address receiverAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Location receiverLocation = new Location("1");
            receiverAddress.AddLocation(receiverLocation);
            ChainEntity receiver = new ChainEntity("Receiver");
            receiver.AddAddress(receiverAddress);

            Assert.IsTrue(receiver.Contains(receiverAddress));

            //Shipper
            Address shipper1Address =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Location shipper1Location = new Location("1");
            shipper1Address.AddLocation(shipper1Location);
            ChainEntity shipper1 = new ChainEntity("shipper1");
            shipper1.AddAddress(receiverAddress);

            //Forwarder
            Address forwarderAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Location forwarderLocation = new Location("1");
            forwarderAddress.AddLocation(forwarderLocation);
            ChainEntity forwarder = new ChainEntity("Forwarder");
            forwarder.AddAddress(forwarderAddress);

            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;
            IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            shipmentExposures.Add(shipmentExposure);


            Shipment shipment =
                new Shipment(shipper1, receiver, forwarder, "", "", "", shipmentPackages, new Location("1"),
                             new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl", "receiver@cc.nl",
                             shipmentExposures);
            memoryShipmentRepository.Add(shipment);


            Assert.IsNotNull(shipment, "Shipment is null but should be created");
            Assert.IsNotNull(shipment.Contains(package), "Shipment does not contain the Package");

            Assert.IsFalse(shipment.IsDelivered, "Shipment is not yet shipped");
            Assert.IsFalse(shipment.IsShipped, "Shipment is shipped");

            //expect an ArgumentException because sfp already has a shipment
            memoryShipmentRepository.Add(shipment);
        }

        /// <summary>
        /// Technical_s the test_ create_ shipment_ without_ a_ location.
        /// </summary>
        [Test]
        public void Technical_Test_Create_Shipment_Without_A_Location()
        {
            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 2, 2, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 3, 15, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            package = new Package(plasticFlowBox, primaryProducts, dateTimeOfPacking, identifications1);

            ICollection<Package> shipmentPackages = new Package[] {package};
            new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                        "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                        "zipcode");


            //Shipper
            ChainEntity shipper1 = new ChainEntity("shipper1");
            Address shipper1Address =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Location shipper1Location = new Location("1");
            shipper1Address.AddLocation(shipper1Location);
            shipper1.AddAddress(shipper1Address);


            Assert.AreEqual("Holland", shipper1Address.Country.Name);
            Assert.AreEqual("shipper1", shipper1.Name);

            ChainEntity receiver = new ChainEntity("Receiver");
            ChainEntity forwarder = new ChainEntity("Forwarder");

            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;
            IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            shipmentExposures.Add(shipmentExposure);

            //pickupLocation argument test
            try
            {
                new Shipment(shipper1, receiver, forwarder, "11111", "22222", "3333333", shipmentPackages, null,
                                 new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl", "receiver@cc.nl",
                                 shipmentExposures);
                Assert.Fail();
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("pickupLocation", e.ParamName);
            }

            //deliveryLocation argument test
            try
            {
                new Shipment(shipper1, receiver, forwarder, "11111", "22222", "3333333", shipmentPackages,
                                 new Location("1"), null, pickUpRange, deliverRange, "forwarder@bb.nl", "receiver@cc.nl",
                                 shipmentExposures);
                Assert.Fail();
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("deliveryLocation", e.ParamName);
            }

            //packages argument test
            try
            {
                    new Shipment(shipper1, receiver, forwarder, "11111", "22222", "3333333", null, new Location("1"),
                                 new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl", "receiver@cc.nl",
                                 shipmentExposures);
                Assert.Fail();
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("packages", e.ParamName);
            }

            //forwarderMailaddress argument test
            try
            {
                    new Shipment(shipper1, receiver, forwarder, "11111", "22222", "3333333", shipmentPackages,
                                 new Location("1"), new Location("2"), pickUpRange, deliverRange, null, "receiver@cc.nl",
                                 shipmentExposures);
                Assert.Fail();
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("forwarderMailaddress", e.ParamName);
            }

            //receiverMailaddress argument test
            try
            {
                    new Shipment(shipper1, receiver, forwarder, "11111", "22222", "3333333", shipmentPackages,
                                 new Location("1"), new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl",
                                 null, shipmentExposures);
                Assert.Fail();
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("receiverMailaddress", e.ParamName);
            }

            //receiverMailaddress argument test
            try
            {
                ICollection<Package> shipmentPackages2 = new Package[] {};
                    new Shipment(shipper1, receiver, forwarder, "11111", "22222", "3333333", shipmentPackages2,
                                 new Location("1"), new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl",
                                 "receiver@cc.nl", shipmentExposures);
                Assert.Fail();
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual("A shipment must contain at least one package", e.Message);
            }
        }

        /// <summary>
        /// Technical_s the test_ create_ shipment_ without_ exposures.
        /// </summary>
        [Test]
        //[ExpectedException(typeof(ArgumentNullException))]
        public void Technical_Test_Create_Shipment_Without_Exposures()
        {
            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            package = new Package(plasticFlowBox, primaryProducts, dateTimeOfPacking, identifications1);

            ICollection<Package> shipmentPackages = new Package[] {package};

            //Receiver
            Address receiverAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Location receiverLocation = new Location("1");
            receiverAddress.AddLocation(receiverLocation);
            ChainEntity receiver = new ChainEntity("Receiver");
            receiver.AddAddress(receiverAddress);

            Assert.IsTrue(receiver.Contains(receiverAddress));

            //Shipper
            Address shipper1Address =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Location shipper1Location = new Location("1");
            shipper1Address.AddLocation(shipper1Location);
            ChainEntity shipper1 = new ChainEntity("shipper1");
            shipper1.AddAddress(receiverAddress);

            //Forwarder
            Address forwarderAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Location forwarderLocation = new Location("1");
            forwarderAddress.AddLocation(forwarderLocation);
            ChainEntity forwarder = new ChainEntity("Forwarder");
            forwarder.AddAddress(forwarderAddress);

            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;
            IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            shipmentExposures.Add(shipmentExposure);


            //shipmentExposures argument test
            try
            {
                    new Shipment(shipper1, receiver, forwarder, "11111", "22222", "3333333", shipmentPackages,
                                 new Location("1"), receiverLocation, pickUpRange, deliverRange, "forwarder@bb.nl",
                                 "receiver@cc.nl", null);
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("shipmentExposures", e.ParamName);
            }
        }

        /// <summary>
        /// Create_s the shipment_ without_ shipper location.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void Technical_Test_Create_Shipment_Without_ShipperLocation()
        {
            new Shipment(null, null, null, "", "", "", packages, null, null, null, null, "", "", null);
        }

        /// <summary>
        /// <scenario>
        ///    <no></no>
        /// 	<given></given>
        /// 	<ensure></ensure>
        /// </scenario>
        /// </summary>
        [Test]
        public void technical_Test_MeasuredValue()
        {
            MeasuredValue measuredValue = new MeasuredValue(1, new DateTime(2008, 1, 1));
            measuredValue.Uid = 1;
            Assert.AreEqual(1, measuredValue.Uid);
            Assert.AreEqual("1 �C at 1-1-2008 0:00:00", measuredValue.ToString());
        }

        /// <summary>
        /// Technical_s the test_ shipment_ getters.
        /// </summary>
        [Test]
        public void Technical_Test_Shipment_Getters()
        {
            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 2, 2, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 3, 15, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            package = new Package(plasticFlowBox, primaryProducts, dateTimeOfPacking, identifications1);

            ICollection<Package> shipmentPackages = new Package[] {package};


            //Shipper
            ChainEntity shipper1 = new ChainEntity("shipper1");
            Address shipper1Address =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Location shipper1Location = new Location("1");
            shipper1Address.AddLocation(shipper1Location);
            shipper1.AddAddress(shipper1Address);


            Assert.AreEqual("Holland", shipper1Address.Country.Name);
            Assert.AreEqual("shipper1", shipper1.Name);

            ChainEntity receiver = new ChainEntity("Receiver");
            //Assert.IsTrue(receiver.Contains(receiverAddress));

            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;
            IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            shipmentExposures.Add(shipmentExposure);

            ChainEntity forwarder = new ChainEntity("Forwarder");
            Shipment shipment =
                new Shipment(shipper1, receiver, forwarder, "11111", "22222", "3333333", shipmentPackages,
                             new Location("1"), new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl",
                             "receiver@cc.nl", shipmentExposures);

            Assert.AreEqual(pickUpRange.Start, shipment.PickUpDateTimeRange.Start);
            Assert.AreEqual(pickUpRange.End, shipment.PickUpDateTimeRange.End);

            Assert.AreEqual(deliverRange.Start, shipment.DeliverDateTimeRange.Start);
            Assert.AreEqual(deliverRange.End, shipment.DeliverDateTimeRange.End);

            Assert.AreEqual(new Location("2"), shipment.DeliveryLocation);
            Assert.AreEqual(new Location("1"), shipment.PickupLocation);

            Assert.AreEqual(shipper1, shipment.Shipper);
            Assert.AreEqual(receiver, shipment.Receiver);
            Assert.AreEqual(forwarder, shipment.Forwarder);

            Assert.AreEqual("11111", shipment.ShipperReferenceId);
            Assert.AreEqual("3333333", shipment.ReceiverReferenceId);
            Assert.AreEqual("22222", shipment.ForwarderReferenceId);

            Assert.AreEqual("receiver@cc.nl", shipment.ReceiverMailaddress);
            Assert.AreEqual("forwarder@bb.nl", shipment.ForwarderMailaddress);

            Assert.IsFalse(shipment.Equals(null));

            ICollection<Package> shipmentPackages2 = new Package[] {package1, package2};
            Shipment shipment2 =
                new Shipment(shipper1, receiver, forwarder, "11111", "22222", "3333333", shipmentPackages2,
                             new Location("1"), new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl",
                             "receiver@cc.nl", shipmentExposures);

            Assert.IsFalse(shipment.Equals(shipment2));

                new Shipment(shipper1, receiver, forwarder, "11111", "22222", "3333333", shipmentPackages,
                             new Location("1"), new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl",
                             "receiver@cc.nl", shipmentExposures);

            shipment.Deliver(beginDeliverDateTime, "", new Location("2"));
            int p = shipment.GetHashCode();
            Assert.AreEqual(new Location("1").GetHashCode(), p);
            bool IsValidReceiverLoc = shipment.IsDeliveryLocationValid(new Location("2"));
            Assert.IsFalse(IsValidReceiverLoc);
            bool ArePackagesInPickupLocation = shipment2.ArePackagesInPickupLocation();
            Assert.IsFalse(ArePackagesInPickupLocation);

            ICollection<Package> shipmentPackages4 = new Package[] {package1};
                
            new Shipment(shipper1, receiver, forwarder, "11111", "22222", "3333333", shipmentPackages4,
                             new Location("1"), new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl",
                             "receiver@cc.nl", shipmentExposures);
            
            ChainEntity forwarder5 = new ChainEntity("Forwarder5");
            Shipment shipment5 =
                new Shipment(shipper1, receiver, forwarder5, "11111", "22222", "3333333", shipmentPackages,
                             new Location("1"), new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl",
                             "receiver@cc.nl", shipmentExposures);
            Assert.IsFalse(shipment.Equals(shipment5));

            Assert.AreEqual(shipmentExposures, shipment.ShipmentExposures);
        }

        /// <summary>
        /// Technicals the test_ shipment exposure.
        /// </summary>
        [Test]
        public void TechnicalTest_ShipmentExposure()
        {
            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            Assert.AreEqual(5, shipmentExposure.PrescribedStartValue);
            Assert.AreEqual(10, shipmentExposure.PrescribedEndValue);
            Assert.AreEqual(6, shipmentExposure.DocumentedValue);
            Assert.AreEqual("exposureTypeName", shipmentExposure.ExposureType.Name);
            shipmentExposure.Uid = 1;
            Assert.AreEqual(1, shipmentExposure.Uid);


            try
            {
                preStartValue = 20;
                preEndValue = 10;
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual("Prescribed start value must be great than Prescribed end value", e.Message);
            }

            try
            {
                preStartValue = 20;
                preEndValue = 30;
                new ShipmentExposure(preStartValue, preEndValue, documentedValue, null);
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("exposureType", e.ParamName);
            }
        }
    }
}