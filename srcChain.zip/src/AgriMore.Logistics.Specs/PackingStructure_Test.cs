//using AgriMore.Logistics.Domain.Packing;
//using NUnit.Framework;

//namespace AgriMore.Logistics.Specs
//{
//    /// <summary>
//    /// 
//    /// </summary>
//    [TestFixture]
//    public class PackingStructure_Test
//    {

//        /// <summary>
//        /// Tests Add, Remove, Clear and Count of the PackingStructure class.
//        /// </summary>
//        [Test]
//        public void PackingStructure_AddRemoveClearCount_Test()
//        {
//            PackingStructure ps = new PackingStructure();

//            Assert.IsTrue(ps.Count == 0, "new PackingStructure is expected to have count=0");

//            // add the root node
//            ps.Add(0, 1);
//            Assert.IsTrue(ps.Count == 1, "Added root, expected count=1");
//            Assert.IsTrue(ps.Contains(1), "Contains failed");

//            ps.Add(1, 2);
//            ps.Add(1, 3);
//            ps.Add(1, 4);

//            Assert.IsTrue(ps.Count == 4, "Added 3 children to root, expected count = 4");
//            PackingStructureNode rootNode = ps[1];
//            Assert.IsTrue(rootNode.Value == 1, "Rootnode value incorrect.");
//            Assert.IsTrue(rootNode.IsRootNode, "Rootnode is not marked as root incorrectly.");
//            Assert.IsFalse(rootNode.IsEmpty, "Rootnode is marked empty incorrectly.");

//            ps.Remove(4);
//            Assert.IsTrue(ps.Count == 3, "Removed 1 child from root, expected count = 3");
//            Assert.IsFalse(ps.Contains(4), "PackingStructure says it contains value=4 but is removed.");

//            ps.Clear();
//            Assert.IsTrue(ps.Count == 0, "called Clear, expected count = 0");
//        }

//        /// <summary>
//        /// Tests the PackingStructureFormatter class.
//        /// </summary>
//        [Test]
//        public void PackingStructureFormatter_Serialization_Test()
//        {
//            PackingStructure ps = new PackingStructure();
//            PackingStructureFormatter f = new PackingStructureFormatter();

//            ps.Add(0, 1);
            
//            ps.Add(1, 2);
//            ps.Add(1, 3);
//            ps.Add(1, 4);

//            ps.Add(2, 5);
//            ps.Add(2, 6);
//            ps.Add(2, 7);

//            ps.Add(6, 8);
//            ps.Add(6, 9);
//            ps.Add(6, 10);

//            string expected = "[0;1][1;2][2;5][2;6][6;8][6;9][6;10][2;7][1;3][1;4]";
//            string text = f.Serialize(ps);
//            Assert.AreEqual(text, expected, "Serialize did not return the expected value.");

//            ps = f.Deserialize(text);
//            Assert.IsTrue(ps.Count == 10, "After deserialization, the count was not 10.");
//            text = f.Serialize(ps);
//            Assert.AreEqual(text, expected, "Serialize did not return the expected value on the second pass.");
//        }
//    }
//}
