using System;
using System.Reflection;
using AgriMore.Logistics.Domain;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class Technical_Protected_Constructors
    {

        /// <summary>
        /// Technical_s the type of the test_ protected_ constructor_ package.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_PackageType()
        {
            Type type = typeof(PackageType);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            PackageType packageType = constructorInfo[0].Invoke(null) as PackageType;
            Assert.IsNotNull(packageType);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ country.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_Country()
        {
            Type type = typeof(Country);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            Country country = constructorInfo[0].Invoke(null) as Country;
            Assert.IsNotNull(country);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ Package.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_Package()
        {
            Type type = typeof(Package);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            Package package = constructorInfo[0].Invoke(null) as Package;
            Assert.IsNotNull(package);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ PackageTypeCategory.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_PackageTypeCategory()
        {
            Type type = typeof(PackageTypeCategory);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            PackageTypeCategory packageTypeCategory = constructorInfo[0].Invoke(null) as PackageTypeCategory;
            Assert.IsNotNull(packageTypeCategory);
        }

                /// <summary>
        /// Technical_s the test_ protected_ constructor_ PackingMaterial.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_PackingMaterial()
        {
            Type type = typeof(PackingMaterial);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            PackingMaterial packingMaterial = constructorInfo[0].Invoke(null) as PackingMaterial;
            Assert.IsNotNull(packingMaterial );
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ Role.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_Role()
        {
            Type type = typeof(Role);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            Role role = constructorInfo[0].Invoke(null) as Role;
            Assert.IsNotNull(role);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ agri more time zone.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_AgriMoreTimeZone()
        {
            Type type = typeof(AgriMoreTimeZone);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            AgriMoreTimeZone agriMoreTimeZone = constructorInfo[0].Invoke(null) as AgriMoreTimeZone;
            Assert.IsNotNull(agriMoreTimeZone);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ chain entity.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_ChainEntity()
        {
            Type type = typeof(ChainEntity);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            ChainEntity chainEntity = constructorInfo[0].Invoke(null) as ChainEntity;
            Assert.IsNotNull(chainEntity);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ exposure document.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_ExposureDocument()
        {
            Type type = typeof(ExposureDocument);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            ExposureDocument exposureDocument = constructorInfo[0].Invoke(null) as ExposureDocument;
            Assert.IsNotNull(exposureDocument);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ user.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_User()
        {
            Type type = typeof(User);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            User user = constructorInfo[0].Invoke(null) as User;
            Assert.IsNotNull(user);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ identification.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_Identification()
        {
            Type type = typeof(Identification);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            Identification identification = constructorInfo[0].Invoke(null) as Identification;
            Assert.IsNotNull(identification);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ measurement.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_Measurement()
        {
            Type type = typeof(Measurement);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            Measurement measurement = constructorInfo[0].Invoke(null) as Measurement;
            Assert.IsNotNull(measurement);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ unit of measurement.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_UnitOfMeasurement()
        {
            Type type = typeof(UnitOfMeasurement);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            UnitOfMeasurement unitOfMeasurement = constructorInfo[0].Invoke(null) as UnitOfMeasurement;
            Assert.IsNotNull(unitOfMeasurement);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ primary product.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_PrimaryProduct()
        {
            Type type = typeof(PrimaryProduct);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            PrimaryProduct primaryProduct = constructorInfo[0].Invoke(null) as PrimaryProduct;
            Assert.IsNotNull(primaryProduct);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ treatment type category.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_TreatmentTypeCategory()
        {
            Type type = typeof(TreatmentTypeCategory);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            TreatmentTypeCategory treatmentTypeCategory = constructorInfo[0].Invoke(null) as TreatmentTypeCategory;
            Assert.IsNotNull(treatmentTypeCategory);
        }

        /// <summary>
        /// Technical_s the type of the test_ protected_ constructor_ treatment.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_TreatmentType()
        {
            Type type = typeof(TreatmentType);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            TreatmentType treatmentType = constructorInfo[0].Invoke(null) as TreatmentType;
            Assert.IsNotNull(treatmentType);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ treatment.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_Treatment()
        {
            Type type = typeof(Treatment);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            Treatment treatment = constructorInfo[0].Invoke(null) as Treatment;
            Assert.IsNotNull(treatment);
        }


        /// <summary>
        /// Technical_s the test_ protected_ constructor_ shipment.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_Shipment()
        {
            Type type = typeof(Shipment);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            Shipment shipment = constructorInfo[0].Invoke(null) as Shipment;
            Assert.IsNotNull(shipment);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ shipment exposure.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_ShipmentExposure()
        {
            Type type = typeof(ShipmentExposure);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            ShipmentExposure shipmentExposure = constructorInfo[0].Invoke(null) as ShipmentExposure;
            Assert.IsNotNull(shipmentExposure);
        }


        /// <summary>
        /// Technical_s the test_ protected_ constructor_ transport equipment.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_TransportEquipment()
        {
            Type type = typeof(TransportEquipment);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            TransportEquipment transportEquipment = constructorInfo[0].Invoke(null) as TransportEquipment;
            Assert.IsNotNull(transportEquipment);
        }

        /// <summary>
        /// Technical_s the test_ protected_ constructor_ location.
        /// </summary>
        [Test]
        public void Technical_Test_Protected_Constructor_Location()
        {
            Type type = typeof(Location);
            ConstructorInfo[] constructorInfo = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            Location location = constructorInfo[0].Invoke(null) as Location;
            Assert.IsNotNull(location);
        }
    }
}