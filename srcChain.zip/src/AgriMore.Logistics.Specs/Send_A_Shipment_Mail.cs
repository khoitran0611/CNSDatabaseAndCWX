using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Net.Mail;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Repository.Memory;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    ///    <userstory>
    ///        <no>..</no>
    ///        <role>Shipper</role>
    ///        <feature>Notify the next chainEntity of a addition</feature>
    ///        <benefit>Know what shipper did and what may have to do</benefit>
    ///    </userstory>
    /// </summary>
    [TestFixture]
    public class Send_A_Shipment_Mail
    {
        private readonly PackingMaterial Plastic = new PackingMaterial("Plastic");
        #region Setup/Teardown

        /// <summary>
        /// Sets the test up.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            plasticFlowBox = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            PrimaryProduct primaryProduct2 = new PrimaryProduct(validProductionAreaId2, validLifeCycleId2);

            ICollection<PrimaryProduct> primaryProducts1 = new List<PrimaryProduct>();
            primaryProducts1.Add(primaryProduct);
            ICollection<PrimaryProduct> primaryProducts2 = new List<PrimaryProduct>();
            primaryProducts2.Add(primaryProduct2);

            chainEntity = new ChainEntity("name");

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);
            Identification[] identifications1 = {new Identification("1", chainEntity)};
            Identification[] identifications2 = {new Identification("2", chainEntity)};
            package1 = new Package(plasticFlowBox, primaryProducts1, dateTimeOfPacking, identifications1);
            package2 = new Package(plasticFlowBox, primaryProducts2, dateTimeOfPacking, identifications2);
        }

        /// <summary>
        /// Tears the down.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        #endregion

        private Package package1;
        private Package package2;

        private ChainEntity chainEntity;
        private PackageType plasticFlowBox;
        private const string validProductionAreaId2 = "AAAPA0800002";
        private const string validLifeCycleId2 = "AAAPC0800002";
        private const string validProductionAreaId = "AAAPA0800001";
        private const string validLifeCycleId = "AAAPC0800001";

        /// <summary>
        ///    <userstory>
        ///        <no>1</no>
        ///        <role>Shipper</role>
        ///        <feature>Send a mail to the forwarder en receiver when a shipment has been created</feature>
        ///        <benefit>the forwarder and receiver could be informed about the shipment</benefit>
        ///    </userstory>
        /// </summary>
        [Test]
        public void Notify_Shipment()
        {
            string senderMail = "thisisnotatestbutatest@gmail.com";
            string ForwarderMailaddress = "thisisnotatestbutatest@gmail.com";
            string ReceiverMailAddress = "thisisnotatestbutatest@gmail.com";
            string Subject = "Shipment created/changed";
            string BodyTemplate = "There has been made a shipment for you, to see below for more details";

            ICollection<Package> packages = new Collection<Package>();
            Address shipperAddress = new Address(Guid.NewGuid().ToString(), new Country("Holland"), "thisisnotatestbutatest@gmail.com", "fax", "numberextension", "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            Address receiverAddress = new Address(Guid.NewGuid().ToString(), new Country("Holland"), "thisisnotatestbutatest@gmail.com", "fax", "numberextension", "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            Location shipperLocation = new Location("20");
            Location forwarderLocation = new Location("4");
            Location receiverLocation = new Location("5");

            shipperAddress.AddLocation(shipperLocation);
            receiverAddress.AddLocation(receiverLocation);


            IRepository<Location> memoryLocationRepository = new MemoryMapRepository<Location>();
            memoryLocationRepository.Add(shipperLocation);
            memoryLocationRepository.Add(receiverLocation);
            memoryLocationRepository.Add(forwarderLocation);

            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            MeasuredValue value = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(value);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(prescribed.Start);

            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            Exposure exposure2 =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));


            IList<Exposure> exposures1 = new List<Exposure>();
            IList<Exposure> exposures2 = new List<Exposure>();
            exposures1.Add(exposure);
            exposures2.Add(exposure2);

            packages.Add(package1);
            packages.Add(package2);

            shipperLocation.Put(package1, exposures1, DateTime.Now);
            shipperLocation.Put(package2, exposures2, DateTime.Now); ;

            ChainEntity shipper = new ChainEntity("Shipper");
            shipper.AddAddress(shipperAddress);
            ChainEntity forwarder = new ChainEntity("Forwarder");
            ChainEntity receiver = new ChainEntity("Receiver");
            receiver.AddAddress(receiverAddress);

            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;
            IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            shipmentExposures.Add(shipmentExposure);

            Shipment shipment =
                new Shipment(shipper, receiver, forwarder, "", "", "", packages, shipperLocation, new Location("2"), pickUpRange, deliverRange, ForwarderMailaddress,
                             ReceiverMailAddress, shipmentExposures);
            shipment.Pickup(DateTime.Now);

            //ShipmentMailer mailer = new ShipmentMailer(senderMail, Subject, BodyTemplate);
            //Assert.IsTrue(mailer.Send(shipment, shipperAddress, receiverAddress));

            try
            {
                ShipmentMailer mailer = new ShipmentMailer(senderMail, Subject, BodyTemplate);
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual("Mail message could not be send, invalid mail parameter(s).", e.Message);
            }
        }

        /// <summary>
        /// Technical_s the test_ shipment mailer_ constructor_ with_ empty_ body temple.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_ShipmentMailer_Constructor_With_Empty_BodyTemple()
        {
            new ShipmentMailer("test", "test", string.Empty);
        }


        /// <summary>
        /// Technical_s the name of the test_ shipment mailer_ constructor_ with_ empty_.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_ShipmentMailer_Constructor_With_Empty_Name()
        {
            new ShipmentMailer(string.Empty, "test", "test");
        }

        /// <summary>
        /// Technical_s the test_ shipment mailer_ constructor_ with_ empty_ subject.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_ShipmentMailer_Constructor_With_Empty_Subject()
        {
            new ShipmentMailer("test", string.Empty, "test");
        }

        /// <summary>
        /// Technical_s the test_ shipment mailer_ constructor_ with_ spaced_ body temple.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_ShipmentMailer_Constructor_With_Spaced_BodyTemple()
        {
            new ShipmentMailer("test", "test", "  ");
        }

        /// <summary>
        /// Technical_s the name of the test_ shipment mailer_ constructor_ with_ spaced_.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_ShipmentMailer_Constructor_With_Spaced_Name()
        {
            new ShipmentMailer("  ", "test", "test");
        }

        /// <summary>
        /// Technical_s the test_ shipment mailer_ constructor_ with_ spaced_ subject.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_ShipmentMailer_Constructor_With_Spaced_Subject()
        {
            new ShipmentMailer("test", "  ", "test");
        }

        /// <summary>
        /// Technical_s the test_ shipment mailer_ constructor_ without_ body template.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_ShipmentMailer_Constructor_Without_BodyTemplate()
        {
            new ShipmentMailer("test", "test", null);
        }

        /// <summary>
        /// Technical_s the test_ shipment mailer_ constructor_ without_ sender mail.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_ShipmentMailer_Constructor_Without_SenderMail()
        {
            new ShipmentMailer(null, "test", "test");
        }

        /// <summary>
        /// Technical_s the test_ shipment mailer_ constructor_ without_ subject.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_ShipmentMailer_Constructor_Without_Subject()
        {
            new ShipmentMailer("test", null, "test");
        }

        /// <summary>
        /// Technicals the test_ notify_ shipment_ without_ shipment.
        /// </summary>
        [Test]
        public void TechnicalTest_Notify_Shipment_Without_Shipment()
        {
            string senderMail = "thisisnotatestbutatest@gmail.com";
            string Subject = "Shipment created/changed";
            string BodyTemlate = "There has been made a shipment for you, to see below for more details";
            Shipment shipment = null;
            ShipmentMailer mailer = new ShipmentMailer(senderMail, Subject, BodyTemlate);

            Address testAddress =
                new Address("a", new Country("test"), "a", "a", "a", "a", "a", "a", "a", new AgriMoreTimeZone("test"), "a");

            
            try
            {
                mailer.Send(shipment, testAddress, testAddress);
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("shipment", e.ParamName);
            }
        }

        /// <summary>
        /// Technicals the test_ notify_ shipment_ without_ subject.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void TechnicalTest_Notify_Shipment_Without_Subject()
        {
            string senderMail = "mnaim2@csc.com";
            string ForwarderMailaddress = "mnaim114@gmail.com";
            string ReceiverMailAddress = "mnaim2@csc.com";
            string Subject = null;
            string BodyTemlate = "There has been made a shipment for you, to see below for more details";

            ICollection<Package> packages = new Collection<Package>();
            Address shipperAddress = new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension", "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            Address forwarderAddress = new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension", "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"), "zipcode");
            Address receiverAddress = new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension", "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            Location shipperLocation = new Location("20");
            Location forwarderLocation = new Location("4");
            Location receiverLocation = new Location("5");

            IRepository<Location> memoryLocationRepository = new RepositoryFactory().CreateRepository<Location>();
            memoryLocationRepository.Add(shipperLocation);
            memoryLocationRepository.Add(receiverLocation);
            memoryLocationRepository.Add(forwarderLocation);

            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            Exposure exposure2 =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            IList<Exposure> exposures1 = new List<Exposure>();
            IList<Exposure> exposures2 = new List<Exposure>();
            exposures1.Add(exposure);
            exposures2.Add(exposure2);

            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            packages.Add(package1);
            packages.Add(package2);

            shipperLocation.Put(package1, exposures1, DateTime.Now);
            shipperLocation.Put(package2, exposures2, DateTime.Now);

            ChainEntity shipper = new ChainEntity("Shipper");
            shipperAddress.AddLocation(shipperLocation);
            shipper.AddAddress(shipperAddress);


            ChainEntity forwarder = new ChainEntity("Forwarder");
            forwarderAddress.AddLocation(forwarderLocation);
            forwarder.AddAddress(forwarderAddress);

            ChainEntity receiver = new ChainEntity("Receiver");
            receiverAddress.AddLocation(receiverLocation);
            receiver.AddAddress(receiverAddress);

            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;
            IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            shipmentExposures.Add(shipmentExposure);


            Shipment shipment =
                new Shipment(shipper, receiver, forwarder, "", "", "", packages, shipperLocation, new Location("2"), pickUpRange, deliverRange, ForwarderMailaddress,
                             ReceiverMailAddress, shipmentExposures);

            ShipmentMailer mailer = new ShipmentMailer(senderMail, Subject, BodyTemlate);
            mailer.Send(shipment,shipperAddress,receiverAddress);
        }

        /// <summary>
        /// Technical_s the test_ shipment mailer_ getters.
        /// </summary>
        [Test]
        public void Technical_Test_ShipmentMailer_Getters()
        {
            ShipmentMailer shipmentMailer = new ShipmentMailer("a", "b", "c");
            Assert.AreEqual("a", shipmentMailer.SenderEmailAddress);
            Assert.AreEqual("b", shipmentMailer.Subject);
            Assert.AreEqual("c", shipmentMailer.BodyTemplate);
        }

        //// Just a mail tester. Do not remove.
        ///// <summary>
        /////
        ///// </summary>
        //[Test]
        //public void Test_Mail()
        //{
        //    MailMessage m = new MailMessage();
        //    m.From = new MailAddress("thisisnotatestbutatest@gmail.com");
        //    m.Subject = "Test";
        //    m.Body = "This is an email test run";
        //    m.To.Add(new MailAddress("thisisnotatestbutatest@gmail.com"));

        //    SmtpClient smtpcli = new SmtpClient();

        //    try
        //    {
        //        String enableSSL = ConfigurationManager.AppSettings["EnableSSL"];

        //        smtpcli.EnableSsl = enableSSL == "true";
        //        smtpcli.Send(m);
        //        Console.Write("Your Email has been sent sucessfully ");
        //    }
        //    catch (Exception exception)
        //    {
        //        Console.Write("Send failure: " + exception);
        //    }
        //}
    }
}
