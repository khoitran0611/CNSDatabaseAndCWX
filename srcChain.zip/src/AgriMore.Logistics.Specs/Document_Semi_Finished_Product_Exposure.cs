using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using NUnit.Framework;


namespace AgriMore.Logistics.Specs
{
    /// <summary>
    ///   <userstory>
    ///     <no>6</no>
    ///     <role>'any Chain ChainEntity'</role>
    ///     <feature>document the actual exposure of the semi finished product to 
    ///     the environmental factors of a location</feature>
    ///     <benefit>I can determine the difference with the prescribed conditions and 
    ///     make claims about the quality of the semi finished product</benefit>
    ///   </userstory>
    /// </summary>
    [TestFixture]
    public class Document_Semi_Finished_Product_Exposure
    {
        //private readonly Address address = new Address("street", "postalcode", "city", "country", "ChainEntity 1");
        private const string validProductionAreaId = "AAAPA0800001";
        private const string validLifeCycleId = "AAAPC0800001";

        private readonly PackingMaterial Plastic = new PackingMaterial("Plastic");
        private ChainEntity chainEntity;
        private ICollection<Identification> identifications1;
        private Identification identification1;

        
        /// <summary>
        /// Creates the package.
        /// <param name="id">the id</param>
        /// </summary>
        /// <returns></returns>
        private Package CreatePackage(string id)
        {
            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            PackageType plasticFlowBox = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );
            chainEntity = new ChainEntity("name");

            identifications1 = new List<Identification>();

            identification1 = new Identification(id, chainEntity);
            identifications1.Add(identification1);

            // create primary product
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(new PrimaryProduct(validProductionAreaId, validLifeCycleId));
            // create package
            DateTime packTime = DateTime.Now;

            return new Package(plasticFlowBox, primaryProducts, packTime, identifications1);
        }

        /// <summary>
        /// <scenario>
        ///   <no>5</no>
        ///   <given>
        ///      <and>A new exposuredocument with a prescribed and actual exposure</and>
        ///      <and>The actual exposure is in the future</and>
        ///   </given>
        ///   <when> the exposure is created
        ///   </when>
        ///   <ensure>
        ///      the exposure cannot be created
        ///   </ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Create_Actual_Exposure_In_Future()
        {
            Package package = CreatePackage("1");
            //create prescribed and actual exposure
            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5.1, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(measuredValue1, measuredValue2);
            MeasuredValue actual = new MeasuredValue(5, DateTime.Now.Add(new TimeSpan(1, 0, 0)));
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(actual);
            new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
        }

        /// <summary>
        /// <scenario>
        ///   <no>6</no>
        ///   <given>
        ///      <and>A new exposuredocument with a prescribed and actual exposure</and>
        ///      <and>The prescribed range exposure is in the future</and>
        ///   </given>
        ///   <when> the exposure is created
        ///   </when>
        ///   <ensure>
        ///      the exposure cannot be created
        ///   </ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Create_Prescribed_Range_Exposure_In_Future()
        {
            Package package = CreatePackage("1");
            //create prescribed and actual exposure
            MeasuredValue temp = new MeasuredValue(5, DateTime.Now.Add(new TimeSpan(1, 0, 0)));
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(temp, temp);
            MeasuredValue actual = new MeasuredValue(5, DateTime.Now);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(actual);
            new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
        }

        /// <summary>
        /// <scenario>
        ///   <no>3</no>
        ///   <given>
        ///      A location that contains two packages with 2 dfferent prescribeds and an actual value
        ///      <and>the exposuredocument for the packages exists in the location</and>
        ///      <and> the exposure to be documented is for a dateTimeOfMeasurement before the fisrt package and acfter the second package prescribed dateTime </and>
        ///   </given>
        ///   <when> document the actual value exposure
        ///   </when>
        ///   <ensure>
        ///      only the actual value exposure will be documented for the package where the presbride datetime is  before dateTimeOfMeasurement.
        ///   </ensure>
        /// </scenario>
        /// </summary>
        [Test]
        public void Document_Actual_Exposure_Before_Prescribed_DateTime()
        {
            Package package = CreatePackage("1");
            Package package2 = CreatePackage("2");

            //create prescribed and actual exposure
            DateTime prescribedTime = DateTime.Now;
            DateTime prescribedTime2 = prescribedTime.AddHours(-1);

            Range<MeasuredValue> r = new Range<MeasuredValue>(new MeasuredValue(5, prescribedTime), new MeasuredValue(5, prescribedTime));
            Range<MeasuredValue> r2 = new Range<MeasuredValue>(new MeasuredValue(5, prescribedTime2), new MeasuredValue(5, prescribedTime2));
                
            MeasuredValue mv = new MeasuredValue(5, prescribedTime);
            MeasuredValue mv2 = new MeasuredValue(5, prescribedTime2);
            
            IList<MeasuredValue> list = new List<MeasuredValue>();
            IList<MeasuredValue> list2 = new List<MeasuredValue>();
            list.Add(mv);
            list2.Add(mv);
            
            //creating exposures
            Exposure exposure = new Exposure(r, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            Exposure exposure2 = new Exposure(r2, list2, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            // add to document
            //ExposureDocument exposureDocument = new ExposureDocument(exposure);
            IList<Exposure> exposures1 = new List<Exposure>();
            IList<Exposure> exposures2 = new List<Exposure>();
            exposures1.Add(exposure);
            exposures2.Add(exposure2);

            //put package in location
            Location location = new Location("1");

            DateTime dateofPlacement = DateTime.Now;
            location.Put(package, exposures1, dateofPlacement);
            location.Put(package2, exposures2, dateofPlacement);

            // add an actual temparature 5 minutes later.
            DateTime actualTimeBeforePrescribedTime = prescribedTime.AddMinutes(-30);// .Subtract(new TimeSpan(0, 5, 0));
            
            location.DocumentActualValue(package, new MeasuredValue(6, actualTimeBeforePrescribedTime), new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            location.DocumentActualValue(package2, new MeasuredValue(6, actualTimeBeforePrescribedTime), new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            int expectedNumberOfExposure = 1;
            int expectedNumberOfActualValues = 1;

            int receivedNumberOfExposure = 0;
            int receivedNumberOfActualValues = 0;
 
            foreach (Exposure exposure1 in package.CurrentExposureDocument.Exposures)
            {
                receivedNumberOfExposure++;

                foreach (MeasuredValue measuredValue in exposure1.Values)
                {
                    receivedNumberOfActualValues++;
                    Assert.AreEqual(5, measuredValue.Value);
                }
            }

            Assert.AreEqual(expectedNumberOfExposure, receivedNumberOfExposure);
            Assert.AreEqual(expectedNumberOfActualValues, receivedNumberOfActualValues);

            expectedNumberOfExposure = 1;
            expectedNumberOfActualValues = 2;

            receivedNumberOfExposure = 0;
            receivedNumberOfActualValues = 0;
            bool expectedValuesReceived = false;

            foreach (Exposure exposure1 in package2.CurrentExposureDocument.Exposures)
            {
                receivedNumberOfExposure++;

                foreach (MeasuredValue measuredValue in exposure1.Values)
                {
                    receivedNumberOfActualValues++;
                    if (measuredValue.Value == 5 || measuredValue.Value == 6)
                    {
                        expectedValuesReceived = true;
                    }
                }
            }

            Assert.IsTrue(expectedValuesReceived);
            Assert.AreEqual(expectedNumberOfExposure, receivedNumberOfExposure);
            Assert.AreEqual(expectedNumberOfActualValues, receivedNumberOfActualValues);
            
            
            //location.DocumentActualValue(new MeasuredValue(6, actualTimeBeforePrescribedTime), new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
        }

        /// <summary>
        /// <scenario>
        ///   <no>4</no>
        ///   <given>
        ///      A location that contains a package that has a prescribed and an actual value
        ///      <and>the exposuredocument for the package exists in the location</and>
        ///      <and> the exposure to be documented is for a dateTimeOfMeasurement is in the future</and>
        ///   </given>
        ///   <when> document the actual value exposure
        ///   </when>
        ///   <ensure>
        ///      the actual value exposure cannot be documented
        ///   </ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Document_Actual_Exposure_In_Future()
        {
            Package package = CreatePackage("1");
            //create prescribed and actual exposure
            DateTime prescribedTime = DateTime.Now;

            Range<MeasuredValue> r =
                            new Range<MeasuredValue>(new MeasuredValue(5, prescribedTime), new MeasuredValue(5, prescribedTime));
            MeasuredValue mv = new MeasuredValue(5, prescribedTime);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(mv);
            Exposure exposure = new Exposure(r, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            // add to document
            //ExposureDocument exposureDocument = new ExposureDocument(exposure);
            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);

            //put package in location
            Location location = new Location("1");
            location.Put(package, exposures1, DateTime.Now);
            // add an actual temparature 5 minutes later.
            DateTime actualTimeBeforePrescribedTime = prescribedTime.Add(new TimeSpan(0, 5, 0));
            location.DocumentActualValue(package, new MeasuredValue(6, actualTimeBeforePrescribedTime), new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            //location.DocumentActualValue( new MeasuredValue(6, actualTimeBeforePrescribedTime), new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
        }

        /// <summary>
        /// <scenario>
        ///   <no>1</no>
        ///   <given>
        ///      A location that contains a package that has a prescribed and an actual value
        ///      <and>the exposuredocument for the package exists in the location</and>
        ///      <and> the actual value to be added is after or same time of the existing prescribed and actual</and>
        ///   </given>
        ///   <when> document the actual exposure
        ///   </when>
        ///   <ensure>
        ///      the exposure contains 2 actual values
        ///      <and> the prescribed value has not changed</and>
        ///      <and> the first actual temperature is the actual exposure that already existed</and>
        ///      <and> the last value is the actual exposure added</and>
        ///      <and> the exposure range is extended to the last actual exposure</and>
        ///      <and> the exposure document range is extended to the last actual exposure</and>
        ///   </ensure>
        /// </scenario>
        /// </summary>
        [Test]
        public void Document_Actual_Exposure_Package_In_Location()
        {
            Package package = CreatePackage("1");
            //create prescribed and actual exposure
            DateTime prescribedTime = DateTime.Now.Subtract(new TimeSpan(1, 0, 0));
            Range<MeasuredValue> r =
                            new Range<MeasuredValue>(new MeasuredValue(5, prescribedTime), new MeasuredValue(5, prescribedTime));
            MeasuredValue mv = new MeasuredValue(5, prescribedTime);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(mv);
            Exposure exposure = new Exposure(r, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            //Exposure exposure = new Exposure(prescribedTime, 5, 5, package, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            // add to document
            //ExposureDocument exposureDocument = new ExposureDocument(exposure);
            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);

            //put package in location
            Location location = new Location("1");
            location.Put(package, exposures1, DateTime.Now);
            // add an actual temparature 5 minutes later.
            DateTime actualTime1 = prescribedTime.Add(new TimeSpan(1, 0, 0));
            location.DocumentActualValue(package, new MeasuredValue(6, actualTime1), new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            //location.DocumentActualValue(new MeasuredValue(6, actualTime1), new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            ExposureDocument documentOnLocation = location.GetExposureDocument(package);
            // the exposure document range is extended to the last actual exposure
            Assert.AreEqual(documentOnLocation.End, actualTime1);

            // the exposure range is extended to the last actual exposure
            Assert.AreEqual(exposure.End, actualTime1);

            // the prescribed value has not changed
            Assert.AreEqual(exposure.PrescribedRange.Start.Value, 5);
            Assert.AreEqual(exposure.PrescribedRange.End.Value, 5);
            Assert.AreEqual(exposure.PrescribedRange.Start.DateTimeOfMeasurement, prescribedTime);
            Assert.AreEqual(exposure.PrescribedRange.End.DateTimeOfMeasurement, prescribedTime);

            //bool first = true;
            //int i = 0;
            //foreach (MeasuredValue value in exposure.Values)
            //{
            //    i++;
            //    if (first)
            //    {
            //        // first value is value existing
            //        Assert.AreEqual(value.DateTimeOfMeasurement, prescribedTime);
            //        Assert.AreEqual(value.Value, 5);
            //        first = false;
            //    }
            //    else
            //    {
            //        // last value is valued added
            //        Assert.AreEqual(value.DateTimeOfMeasurement, actualTime1);
            //        Assert.AreEqual(value.Value, 6);
            //    }
            //}

            Assert.AreEqual(2, new List<MeasuredValue>(exposure.Values).Count);
            foreach (MeasuredValue value in exposure.Values)
            {
                if (value.Value == 6)
                {
                    Assert.AreEqual(actualTime1, value.DateTimeOfMeasurement);
                }
                else if (value.Value== 5)
                {
                    Assert.AreEqual(prescribedTime, value.DateTimeOfMeasurement);
                }
                else
                {
                    Assert.Fail("Unexpected value: " + value.Value);
                }
            }
        }

        /// <summary>
        /// <scenario>
        ///   <no>2</no>
        ///   <given>
        ///      A location that contains a package that has a prescribed and an actual value
        ///      <and>the exposuredocument for the package exists in the location</and>
        ///      <and> the exposure to be described is for a package that is not in the location</and>
        ///   </given>
        ///   <when> document the actual value exposure
        ///   </when>
        ///   <ensure>
        ///      the actual value exposure cannot be documented
        ///   </ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Document_Actual_Exposure_Package_Not_In_Location()
        {
            Package package = CreatePackage("1");
            Package package2 = CreatePackage("2");
            //create prescribed and actual exposure
            DateTime prescribedTime = DateTime.Now;
            Range<MeasuredValue> r =
                            new Range<MeasuredValue>(new MeasuredValue(5, prescribedTime), new MeasuredValue(5, prescribedTime));
            MeasuredValue mv = new MeasuredValue(5, prescribedTime);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(mv);
            Exposure exposure = new Exposure(r, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            //Exposure exposure = new Exposure(prescribedTime, 5, 5, package, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            // add to document
            //ExposureDocument exposureDocument = new ExposureDocument(exposure);
            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);

            //put package in location
            Location location = new Location("1");
            location.Put(package, exposures1, DateTime.Now);
            // add an actual temparature 5 minutes later.
            DateTime actualTime1 = prescribedTime.Add(new TimeSpan(0, 5, 0));
            location.DocumentActualValue(package2, new MeasuredValue(6, actualTime1), new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            //location.DocumentActualValue(new MeasuredValue(6, actualTime1), new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
        }

        /// <summary>
        /// Technical_s the name of the test_ exposure type_ constructor_ without_.
        /// </summary>
        [ExpectedException(typeof(ArgumentNullException))]
        [Test]
        public void Technical_Test_ExposureType_Constructor_Without_Name()
        {
            new ExposureType(null, new UnitOfMeasurement("name"));
        }

        /// <summary>
        /// Technical_s the name of the test_ exposure type_ constructor_ with_ empty_.
        /// </summary>
        [ExpectedException(typeof(ArgumentException))]
        [Test]
        public void Technical_Test_ExposureType_Constructor_With_Empty_Name()
        {
            new ExposureType(string.Empty, new UnitOfMeasurement("name"));
        }

        /// <summary>
        /// Technical_s the name of the test_ exposure type_ constructor_ with_ spaced_.
        /// </summary>
        [ExpectedException(typeof(ArgumentException))]
        [Test]
        public void Technical_Test_ExposureType_Constructor_With_Spaced_Name()
        {
            new ExposureType(" ", new UnitOfMeasurement("name"));
        }

        /// <summary>
        /// Technical_s the test_ exposure type_ constructor_ without_ unit of measurement.
        /// </summary>
        [ExpectedException(typeof(ArgumentNullException))]
        [Test]
        public void Technical_Test_ExposureType_Constructor_Without_UnitOfMeasurement()
        {
            new ExposureType("name", null);
        }


        /// <summary>
        /// Technical_s the test_ exposure type_ getters.
        /// </summary>
        [Test]
        public void Technical_Test_ExposureType_Getters()
        {
            ExposureType exposureType=  new ExposureType("name", new UnitOfMeasurement("name"));
            ExposureType otherExposureType=  new ExposureType("othername", new UnitOfMeasurement("name"));
            exposureType.Uid = 1;

            Assert.IsNotNull(exposureType.UnitOfMeasurement);
            Assert.AreEqual("name", exposureType.UnitOfMeasurement.Name);
            Assert.AreEqual(1, exposureType.Uid);

            Assert.IsFalse(exposureType.Equals(null));
            Assert.IsFalse(exposureType.Equals(otherExposureType));

            Assert.AreEqual("name".GetHashCode(), exposureType.GetHashCode());
            Assert.AreEqual("name in name", exposureType.ToString());
        }
    }
}