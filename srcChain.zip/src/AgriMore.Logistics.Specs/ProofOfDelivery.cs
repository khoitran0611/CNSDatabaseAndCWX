using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Repository.Memory;
using AgriMore.Logistics.Domain.Specification;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 	<userstory>
    ///         <no>5.3</no>
    ///   		<role>TransportEquipment</role>
    ///   		<feature>
    ///                 Deliver the shipment 
    ///         </feature>
    ///   		<benefit>
    ///                 The shipment and included semi finished product is delivered.
    ///         </benefit>
    /// 	</userstory>
    /// </summary>
    [TestFixture]
    public class Proof_Of_Delivery
    {
        #region Setup/Teardown

        /// <summary>
        /// Setups this instance.
        /// </summary>
        [SetUp]
        public void Setup()
        {
         PackingMaterial Plastic = new PackingMaterial("Plastic");
            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            plasticFlowBox = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            PrimaryProduct primaryProduct2 = new PrimaryProduct(validProductionAreaId2, validLifeCycleId2);
            PrimaryProduct primaryProduct3 = new PrimaryProduct(validProductionAreaId3, validLifeCycleId3);

            ICollection<PrimaryProduct> primaryProducts1 = new List<PrimaryProduct>();
            primaryProducts1.Add(primaryProduct);
            ICollection<PrimaryProduct> primaryProducts2 = new List<PrimaryProduct>();
            primaryProducts2.Add(primaryProduct2);

            ICollection<PrimaryProduct> primaryProducts3 = new List<PrimaryProduct>();
            primaryProducts3.Add(primaryProduct3);

            chainEntity = new ChainEntity("name");

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);
            Identification[] identifications1 = {new Identification("1", chainEntity)};
            Identification[] identifications2 = {new Identification("2", chainEntity)};
            Identification[] identifications3 = { new Identification("3", chainEntity) };
            package1 = new Package(plasticFlowBox, primaryProducts1, dateTimeOfPacking, identifications1);
            package2 = new Package(plasticFlowBox, primaryProducts2, dateTimeOfPacking, identifications2);
            package3 = new Package(plasticFlowBox, primaryProducts3, dateTimeOfPacking, identifications3);

            packages = new Collection<Package>();
            packages1 = new Collection<Package>();

            Address shipperAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address forwarderAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address receiverAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            Address testAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");


            shipperLocation = new Location("20");
            shipperAddress.AddLocation(shipperLocation);

            forwarderLocation = new Location("4");
            forwarderAddress.AddLocation(forwarderLocation);

            receiverLocation = new Location("5");
            receiverAddress.AddLocation(receiverLocation);

            Location testLocation = new Location("6");
            testAddress.AddLocation(testLocation);

            IRepository<Location> memoryLocationRepository = new RepositoryFactory().CreateRepository<Location>();
            memoryLocationRepository.Add(shipperLocation);
            memoryLocationRepository.Add(receiverLocation);
            memoryLocationRepository.Add(forwarderLocation);

            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            Exposure exposure2 =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            Exposure exposure3 =
              new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            IList<Exposure> exposures1 = new List<Exposure>();
            IList<Exposure> exposures2 = new List<Exposure>();
            IList<Exposure> exposures3 = new List<Exposure>();
            exposures1.Add(exposure);
            exposures2.Add(exposure2);
            exposures3.Add(exposure3);

            packages.Add(package1);
            packages.Add(package2);
            packages1.Add(package3);

            DateTime dateOfPlacement = DateTime.Now;

            shipperLocation.Put(package1, exposures1, dateOfPlacement);
            shipperLocation.Put(package2, exposures2, dateOfPlacement);
            shipperLocation.Put(package3, exposures3, dateOfPlacement);

            ChainEntity shipper = new ChainEntity("Shipper");
            shipper.AddAddress(shipperAddress);

            ChainEntity forwarder = new ChainEntity("Forwarder");
            forwarder.AddAddress(forwarderAddress);

            ChainEntity receiver = new ChainEntity("Receiver");
            receiver.AddAddress(receiverAddress);

            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

            DateTime beginDeliverDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            Range<DateTime> deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);

            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;
            IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            shipmentExposures.Add(shipmentExposure);


            shipment =
                new Shipment(shipper, receiver, forwarder, string.Empty, string.Empty, string.Empty, packages,
                             shipperLocation, new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl",
                             "receiver@cc.nl", shipmentExposures);

            RepositoryFactory factoryRepository = new RepositoryFactory();
            if (!factoryRepository.GetShipmentRepository().Contains(shipment))
                factoryRepository.GetShipmentRepository().Add(shipment);
            // check of the shipper have the shipment.
            // this can be done by checking if the location has the shipment

            Assert.IsTrue(shipperLocation.Contains(package1));
            Assert.IsTrue(shipperLocation.Contains(package2));

            pickupTime = DateTime.Now;
            transportEquipment = new TransportEquipment(forwarder, forwarderLocation);
            transportEquipment.Pickup(shipment, pickupTime, shipperLocation, exposures1);

            new RepositoryFactory().GetTransportEquipmentRepository().Store(transportEquipment);
            shipment.Pickup(pickupTime);

        }

        #endregion

        private Shipment shipment;
        //private Shipment shipment1;
        private ICollection<Package> packages = new Collection<Package>();
        private ICollection<Package> packages1 = new Collection<Package>();
        private Location shipperLocation;
        private Location forwarderLocation;
        private Location receiverLocation;
        private TransportEquipment transportEquipment;
        private DateTime pickupTime;

        private Package package1;
        private Package package2;
        private Package package3;

        private ChainEntity chainEntity;
        private PackageType plasticFlowBox;
        private const string validProductionAreaId2 = "AAAPA0800002";
        private const string validLifeCycleId2 = "AAAPC0800002";
        private const string validProductionAreaId = "AAAPA0800001";
        private const string validLifeCycleId = "AAAPC0800001";
        private const string validProductionAreaId3 = "AAAPA0800002";
        private const string validLifeCycleId3= "AAAPC0800001";


        /// <summary>
        ///     <scenario>
        ///         <no>1</no>
        ///         <given>There is a shipment on transport
        ///             <and>There is a customer location</and>
        ///         </given>
        ///         <when>TransportEquipment delivers the semi finished product</when>
        ///         <ensure>A Proof Of Delivery for the shipment is created
        ///         <and>The location of the semi finished product is changed to the customer location.</and> 
        ///         </ensure>
        ///     </scenario>
        /// </summary>
        [Test]
        public void Deliver_The_Sfp()
        {
            transportEquipment = new RepositoryFactory().GetTransportEquipmentRepository().GetOne(new TransportEquipmentByShipment(shipment));
            //DateTime dateTimeOfDelivery = new DateTime(2008, 3, 14, 15, 1, 1);
            DateTime dateTimeOfDelivery = DateTime.Now;
            //toDeliveryShipment argument test
            try
            {
                transportEquipment.Deliver(null, DateTime.Now, "", receiverLocation);
                Assert.Fail();
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("toDeliveryShipment", e.ParamName);
            }

            try
            {
                transportEquipment.Deliver(shipment, DateTime.Now.Add(new TimeSpan(1, 0, 0)), "", receiverLocation);
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual("Date of delivery needs to be in the past", e.Message);
            }

            try
            {
                transportEquipment.Deliver(shipment, dateTimeOfDelivery, "test data", receiverLocation);
                Assert.IsTrue(shipment.IsDelivered);
                foreach (Package package in shipment.Packages)
                {
                    Assert.IsFalse(forwarderLocation.Contains(package),
                                   "The package should not be in transportEquipment location.");
                }
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual("Cannot deliver shipment, no shipment available", e.Message);
            }
            Assert.AreEqual(shipment.Remarks, "test data");
            Assert.AreEqual(shipment.RealDateTimeOfDelivery, dateTimeOfDelivery);
            
        }



        ///// <summary>
        ///// Technical_s the test_ deliver_ a_ not_ pickup_ shipment.
        ///// </summary>
        //[Test]
        //public void Technical_Test_Deliver_A_Not_Pickup_Shipment()
        //{
        //    DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
        //    DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
        //    Range<DateTime> pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);

        //    double preStartValue = 5;
        //    double preEndValue = 10;
        //    double documentedValue = 6;
        //    IList<ShipmentExposure> shipmentExposures1 = new List<ShipmentExposure>();

        //    ShipmentExposure shipmentExposure1 =
        //        new ShipmentExposure(preStartValue, preEndValue, documentedValue,
        //                             new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
        //    shipmentExposures1.Add(shipmentExposure1);

        //    shipment1 =
        //        new Shipment(new ChainEntity("Shipper"), new ChainEntity("Receiver"), new ChainEntity("Forwarder"), string.Empty, string.Empty, string.Empty, packages1,
        //                     shipperLocation, new Location("2"), pickUpRange, pickUpRange, "forwarder@bb.nl",
        //                     "receiver@cc.nl", shipmentExposures1);
        //    try
        //    {
        //        transportEquipment.Deliver(shipment1, DateTime.Now, "", receiverLocation);
        //    }
        //    catch (ArgumentException e)
        //    {
        //        Assert.AreEqual("Date of delivery needs to be in the past", e.Message);
        //    }
        //}
    }
}