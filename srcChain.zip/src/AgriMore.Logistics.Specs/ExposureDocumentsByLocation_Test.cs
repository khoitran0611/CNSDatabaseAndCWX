using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class ExposureDocumentsByLocation_Test
    {
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        /// <summary>
        /// Gets the exposures.
        /// </summary>
        /// <returns></returns>
        private static IList<Exposure> GetExposures()
        {
            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);
            return exposures1;
        }

        /// <summary>
        /// Creates the package.
        /// </summary>
        /// <returns></returns>
        private static Package CreateUniquePackage()
        {
            ChainEntity chainEntity = new ChainEntity("test");

            ICollection<Identification> identifications1 = new List<Identification>();
            Identification identification1 = new Identification(Guid.NewGuid().ToString(), chainEntity);
            identifications1.Add(identification1);

            PrimaryProduct primaryProduct = new PrimaryProduct(Guid.NewGuid().ToString(), Guid.NewGuid().ToString());
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");

            PackageType flowPack = new PackageType(
                "FlowPack",
                retailPackaging,
                new PackingMaterial("Plastic"),
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            //1st
            Package package = new Package(flowPack,
                                          primaryProducts, dateTimeOfPacking, identifications1);

            return package;
        }

        /// <summary>
        /// 
        /// </summary>               
        [Test]
        public void ExposureDocumentsByLocation()
        {
            Package package = CreateUniquePackage();

            Location location = new Location("ExposureDocumentsByLocation");
            Location otherLocation = new Location("ExposureDocumentsByLocation_otherLocation");

            ExposureDocument exposureDocument = new ExposureDocument(location, package, GetExposures(),new DateTime(2008,4,1,1,1,1,1));

            repositoryFactory.GetExposureDocumentRepository().Store(exposureDocument);

            Assert.AreEqual(1, repositoryFactory.GetExposureDocumentRepository().Count());

            ICollection<ExposureDocument> exposureDocuments =
                repositoryFactory.GetExposureDocumentRepository().Find(new ExposureDocumentsByLocation(location));

            Assert.AreEqual(1, exposureDocuments.Count);

            exposureDocuments =
                repositoryFactory.GetExposureDocumentRepository().Find(new ExposureDocumentsByLocation(otherLocation));

            Assert.AreEqual(0, exposureDocuments.Count);
        }

        /// <summary>
        /// 
        /// </summary>               
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void ExposureDocumentsByLocation_With_Null_Argument_Constructor()
        {
            new ExposureDocumentsByLocation(null);
        }
    }
}