using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class CreateChainEntity
    {
        private const string chainentity = "chainentity";
        private List<Address> addresses;
        private List<User> users;
        private Address addressNotBelongingToChainEntity;

        /// <summary>
        /// Setups this instance.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();

            Role shipper = repositoryFactory.GetRoleRepository().GetOne("Shipper");

            addresses = new List<Address>();
            users = new List<User>();

            Address address1 = new Address("City1", new Country("Holland"), "email", "fax",
                               "numberextension", "stateprovence", "streetname", "streetnumber",
                               "telephone", new AgriMoreTimeZone("CET"), "zipcode");
            
            addressNotBelongingToChainEntity = new Address("OtherCity", new Country("Holland"), "email", "fax",
                   "numberextension", "stateprovence", "streetname", "streetnumber",
                   "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            User user = new User("username1", "password", "firstname1", "lastname1", new Role[] { shipper});

            addresses.Add(address1);
            users.Add(user);
        }
        /// <summary>
        /// Technical_s the test_ create_ chain entity_ constructor.
        /// </summary>
        [Test]
        public void Technical_Test_Create_ChainEntity_Constructor()
        {
            ChainEntity chainEntity=new ChainEntity(chainentity,addresses,users);

            Assert.IsNotNull(chainEntity);

        }

        /// <summary>
        /// Technical_s the test_ chain entity_ add_ null_ user.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void Technical_Test_ChainEntity_Add_Null_User()
        {
            ChainEntity chainEntity = new ChainEntity(chainentity, addresses, users);
            chainEntity.AddUser(null);
        }

        /// <summary>
        /// Technical_s the test_ chain entity_ add_ null_ address.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void Technical_Test_ChainEntity_Add_Null_Address()
        {
            ChainEntity chainEntity = new ChainEntity(chainentity, addresses, users);
            chainEntity.AddAddress(null);
        }

        /// <summary>
        /// Technical_s the test_ chain entity_ contain_ address.
        /// </summary>
        [Test]
        public void Technical_Test_ChainEntity_Contain_Address()
        {
            ChainEntity chainEntity = new ChainEntity(chainentity, addresses, users);
            Assert.IsFalse(chainEntity.Contains(addressNotBelongingToChainEntity));
        }

        /// <summary>
        /// Technical_s the test_ chain entity_ get_ added_ roles.
        /// </summary>
        [Test]
        public void Technical_Test_ChainEntity_Get_Added_Roles()
        {
            ChainEntity chainEntity = new ChainEntity(chainentity, addresses, users);

            foreach (Role role in chainEntity.Roles)
            {
                Assert.AreEqual("Shipper", role.Name);
            }
        }
    }
}