using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Repository.Memory;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs.MemoryMap.Repository
{
    /// <summary>
    /// Tests the NHibernateRepository
    /// </summary>
    [TestFixture]
    public class MemoryMapRepository_Test
    {
        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        /// <summary>
        /// Test_s the memory map repository can instantiate MemoryMap repository factory.
        /// </summary>
        [Test]
        public void Test_MemoryMapRepository_CanInstantiateMemoryMapRepositoryFactory()
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();

            Assert.IsNotNull(repositoryFactory.ConcreteRepositoryFactory as MemoryMapRepositoryFactory);
        }
    }
}
