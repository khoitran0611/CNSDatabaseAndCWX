using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Domain.Transaction.Memory;
using NUnit.Framework;

namespace AgriMore.Logistics.Data.Specs.MemoryMap.Transaction
{
    /// <summary>
    /// Tests the MemoryMapTransactionManager
    /// </summary>
    [TestFixture]
    public class MemoryMapTransactionManager_Test
    {
        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        /// <summary>
        /// Tests if the memory map transaction manager is instantiated.
        /// </summary>
        [Test]
        public void Test_MemoryMapTransactionManager_CanInstantiateMemoryMapTransactionManager()
        {
            TransactionManager transactionManager = new TransactionManager();
            
            Assert.IsNotNull(transactionManager.ConcreteTransactionManager as MemoryMapTransactionManager);
        }
    }
}
