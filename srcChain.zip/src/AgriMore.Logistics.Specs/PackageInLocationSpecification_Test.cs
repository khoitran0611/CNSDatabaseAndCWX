using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class PackageInLocationSpecification_Test
    {
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        /// <summary>
        /// Gets the exposures.
        /// </summary>
        /// <returns></returns>
        private static IList<Exposure> GetExposures()
        {
            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> list = new List<MeasuredValue>();
            list.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure =
                new Exposure(prescribed, list, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            IList<Exposure> exposures1 = new List<Exposure>();
            exposures1.Add(exposure);
            return exposures1;
        }

        /// <summary>
        /// Creates the package.
        /// </summary>
        /// <returns></returns>
        private Package CreateUniquePackage()
        {
            ChainEntity chainEntity = new ChainEntity("test");

            ICollection<Identification> identifications1 = new List<Identification>();
            Identification identification1 = new Identification(Guid.NewGuid().ToString(), chainEntity);
            identifications1.Add(identification1);

            PrimaryProduct primaryProduct = new PrimaryProduct(Guid.NewGuid().ToString(), Guid.NewGuid().ToString());
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");

            PackageType flowPack = new PackageType(
                "FlowPack",
                retailPackaging,
                new PackingMaterial("Plastic"),
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            //1st
            Package  package = new Package(flowPack,
                                  primaryProducts, dateTimeOfPacking, identifications1);

            return package;

        }

        /// <summary>
        ///
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void PackageInLocationSpecification_Constructor_Null_Argument_Test()
        {
            new PackageInLocationSpecification(null);
        }

        /// <summary>
        /// Packages the in location specification test.
        /// </summary>
        [Test]
        public void PackageInLocationSpecificationTest()
        {
            Package package = CreateUniquePackage();
            Package otherPackage = CreateUniquePackage();

            repositoryFactory.GetPackageRepository().Store(package);
            repositoryFactory.GetPackageRepository().Store(otherPackage);

            IList<Exposure> exposures1 = GetExposures();

            Location location = new Location("description");
            location.Put(package, exposures1, DateTime.Now);
            repositoryFactory.GetLocationRepository().Add(location);
            
            Assert.IsTrue(location.Contains(package), "The package1 should be in stock.");

            Assert.AreEqual(2, repositoryFactory.GetPackageRepository().AsCollection().Count);

            ICollection<Package> packages =
                repositoryFactory.GetPackageRepository().Find(new PackageInLocationSpecification(location));

            Assert.AreEqual(1, packages.Count);
        }

        /// <summary>
        /// Packages the in location specification test.
        /// </summary>
        [Test]
        public void PackageInLocationSpecification_And_No_Packages_In_Location()
        {
            Location location = new Location("PackageInLocationSpecification_AndNotFoundTest");

            repositoryFactory.GetLocationRepository().Add(location);

            ICollection<Package> packages =
                repositoryFactory.GetPackageRepository().Find(new PackageInLocationSpecification(location));

            Assert.AreEqual(0, packages.Count);
        }
    }
}