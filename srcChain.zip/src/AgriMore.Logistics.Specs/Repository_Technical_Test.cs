using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Repository.Memory;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// Technical test for the Repository
    /// </summary>
    [TestFixture]
    public class Repository_Technical_Test
    {

        /// <summary>
        /// Tests the add get remove.
        /// </summary>
        [Test]
        public void TestAddGetRemove()
        {
            IRepository<Address> rep = new RepositoryFactory().CreateRepository<Address>();
            //Address address = new Address("street 1", "8000VV", "Stad", "Nederland", "ChainEntity 1");
            Address address = new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension", "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            long uid = rep.Add(address);
            address.Uid = uid;
            Address result = rep.GetOne(uid);
            Assert.IsNotNull(result);
            Assert.AreEqual(result, address);
            Assert.IsTrue(rep.Remove(result));
            Assert.IsNull(rep.GetOne(uid));
        }

        /// <summary>
        /// Tests the store.
        /// </summary>
        [Test]
        public void TestStore()
        {
            TransactionManager transactionManager = new TransactionManager();
            transactionManager.BeginTransaction();

            new RepositoryFactory().InitializeTestData();

            transactionManager.CommitTransaction();

            IRepository<Address> rep = new RepositoryFactory().CreateRepository<Address>();
            //Address address = new Address("street 1", "8000VV", "Stad", "Nederland", "ChainEntity 1");
            Address address = new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension", "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            long uid = rep.Add(address);
            //Address address2 = new Address("street 2", "8000VV", "Stad", "Nederland", "ChainEntity 1");
            Address address2 = new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension", "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            address2.Uid = uid;
            rep.Store(address);
            Assert.AreEqual(1,rep.Count(new AllSpecification<Address>()));
        }

        /// <summary>
        /// Tests the add already added.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestAddAlreadyAdded()
        {
            IRepository<Address> rep = new RepositoryFactory().CreateRepository<Address>();
            //Address address = new Address("street 1", "8000VV", "Stad", "Nederland", "ChainEntity 1");
            Address address = new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension", "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            long uid = rep.Add(address);
            address.Uid = uid;
            Address result = rep.GetOne(uid);
            Assert.IsNotNull(result);
            Assert.AreEqual(result, address);
            Assert.IsTrue(rep.Remove(result));
            Assert.IsNull(rep.GetOne(uid));
            rep.Add(address);
        }
        /// <summary>
        /// Tests the location of package specification.
        /// </summary>
        [Test]
        public void TestLocationOfPackageSpecification()
        {
            //Location location = new Location("id");
            //Location location2 = new Location("id2");
            //ChainEntity Ah = new ChainEntity("AH"
            //                                 ,
            //                                 new Location[]
            //                                     {
            //                                         location
            //                                     });
            //Package p = new Package(PackageType.FlowPack
            //                        , new PrimaryProduct[] {new PrimaryProduct(validProductionAreaId, validLifeCycleId)}
            //                        , DateTime.Now
            //                        , new Identification[] {new Identification("124", Ah)});
            //IRepository<Location> rep = new MemoryMapRepository<Location>();
            //location.Put(p, new ExposureDocument(new Exposure(DateTime.Now, 2, 2, p, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")))));

            //rep.Add(location);
            //rep.Add(location2);
            //LocationOfPackageSpecification spec = new LocationOfPackageSpecification(p);
            //Assert.AreEqual(location,rep.GetOne(spec));
            //Assert.AreEqual(1,rep.Count(spec));
            //ICollection<Location> found = rep.Find(spec);
            //Assert.AreEqual(1,found.Count);
            //foreach (Location foundLocation in found)
            //{
            //    Assert.AreEqual(foundLocation, location);
            //}
        }

        /// <summary>
        /// Tests the remove null.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void TestRemoveNull()
        {
            IRepository<Address> rep = new RepositoryFactory().CreateRepository<Address>();
            Address a = null;
            rep.Remove(a);
        }

        /// <summary>
        /// Tests the remove null spec.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void TestRemoveNullSpec()
        {
            IRepository<Address> rep = new RepositoryFactory().CreateRepository<Address>();
            ISpecification<Address> aspec = null;
            rep.Remove(aspec);
        }

        /// <summary>
        /// Tests the add null.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void TestAddNull()
        {
            IRepository<Address> rep = new RepositoryFactory().CreateRepository<Address>();
            rep.Add(null);
        }

        /// <summary>
        /// Tests the store null.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void TestStoreNull()
        {
            IRepository<Address> rep = new RepositoryFactory().CreateRepository<Address>();
            rep.Store(null);
        }

        /// <summary>
        /// Tests the count null.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void TestCountNull()
        {
            IRepository<Address> rep = new RepositoryFactory().CreateRepository<Address>();
            rep.Count(null);
        }

        /// <summary>
        /// Tests the contains null.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void TestContainsNull()
        {
            IRepository<Address> rep = new RepositoryFactory().CreateRepository<Address>();
            rep.Contains(null);
        }

        /// <summary>
        /// Tests the find null.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void TestFindNull()
        {
            IRepository<Address> rep = new RepositoryFactory().CreateRepository<Address>();
            rep.Find(null);
        }

        /// <summary>
        /// Tests the get one string null.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void TestGetOneStringNull()
        {
            IRepository<Address> rep = new RepositoryFactory().CreateRepository<Address>();
            string s = null;
            rep.GetOne(s);
        }

        /// <summary>
        /// Tests the get one string empty.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentException))]
        public void TestGetOneStringEmpty()
        {
            IRepository<Address> rep = new RepositoryFactory().CreateRepository<Address>();
            string s = " ";
            rep.GetOne(s);
        }
    }
}