using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// Test the specifications in the system
    /// </summary>
    [TestFixture]
    public class ChainEntiyByRoleSpecification_Test
    {
        /// <summary>
        /// Locations for chain entity specification.
        /// This test assumes the DataFiller to have run.
        /// </summary>
        [Test]
        public void Can_Get_ChainEntiyByRole()
        {
            ChainEntity chainEntity = null;

            Role role=new Role("Receiver");
            ISpecification<ChainEntity> specification = new ChainEntiyByRoleSpecification(role);
            ICollection<ChainEntity> receivers =
                new RepositoryFactory().GetChainEntityRepository().Find(specification);

            foreach (ChainEntity entity in receivers)
            {
                if (entity.Name == "Plus Supermarket")
                {
                    chainEntity = entity;
                }
            }

            Assert.IsNotNull(chainEntity);

        }

        /// <summary>
        /// Locations for address specification_ null_ argument_ constructor_ test.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Can_Create_ChainEntiyByRoleSpecification_With_Null_Argument()
        {
            new ChainEntiyByRoleSpecification(null);
        }
    }
}