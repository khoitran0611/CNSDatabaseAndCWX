using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    ///   <userstory>
    ///     <no></no>
    ///     <role>Administrator</role>
    ///     <feature>Manage an Address</feature>
    ///     <benefit>I can allocate an address to chain entity and location</benefit>
    ///   </userstory>
    /// </summary>
    [TestFixture]
    public class Create_Address
    {
        /// <summary>
        /// Create_s the invalid_ address.
        /// </summary>
        [Test]
        public void Create_Invalid_Address()
        {
            try
            {
                new Address(null, new Country("Holland"), "email", "fax",
                            "numberextension", "stateprovence", "streetname", "streetnumber",
                            "telephone", new AgriMoreTimeZone("CET"), "zipcode");
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("city", e.ParamName);
            }

            try
            {
                new Address("City", null, "email", "fax",
                            "numberextension", "stateprovence", "streetname", "streetnumber",
                            "telephone", new AgriMoreTimeZone("CET"), "zipcode");
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("country", e.ParamName);
            }

            try
            {
                new Address("City", new Country("Holland"), null, "fax",
                            "numberextension", "stateprovence", "streetname", "streetnumber",
                            "telephone", new AgriMoreTimeZone("CET"), "zipcode");
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("email", e.ParamName);
            }

            try
            {
                new Address("City", new Country("Holland"), "email", null,
                            "numberextension", "stateprovence", "streetname", "streetnumber",
                            "telephone", new AgriMoreTimeZone("CET"), "zipcode");
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("fax", e.ParamName);
            }

            try
            {
                new Address("City", new Country("Holland"), "email", "fax",
                            null, "stateprovence", "streetname", "streetnumber",
                            "telephone", new AgriMoreTimeZone("CET"), "zipcode");
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("numberExtension", e.ParamName);
            }

            try
            {
                new Address("City", new Country("Holland"), "email", "fax",
                            "numberextension", null, "streetname", "streetnumber",
                            "telephone", new AgriMoreTimeZone("CET"), "zipcode");
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("stateProvence", e.ParamName);
            }

            try
            {
                new Address("City", new Country("Holland"), "email", "fax",
                            "numberextension", "stateprovence", null, "streetnumber",
                            "telephone", new AgriMoreTimeZone("CET"), "zipcode");
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("streetName", e.ParamName);
            }

            try
            {
                new Address("City", new Country("Holland"), "email", "fax",
                            "numberextension", "stateprovence", "streetname", null,
                            "telephone", new AgriMoreTimeZone("CET"), "zipcode");
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("streetNumber", e.ParamName);
            }

            try
            {
                new Address("City", new Country("Holland"), "email", "fax",
                            "numberextension", "stateprovence", "streetname", "streetnumber",
                            null, new AgriMoreTimeZone("CET"), "zipcode");
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("telephone", e.ParamName);
            }

            try
            {
                new Address("City", new Country("Holland"), "email", "fax",
                            "numberextension", "stateprovence", "streetname", "streetnumber",
                            "telephone", null, "zipcode");
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("timeZone", e.ParamName);
            }

            try
            {
                new Address("City", new Country("Holland"), "email", "fax",
                            "numberextension", "stateprovence", "streetname", "streetnumber",
                            "telephone", new AgriMoreTimeZone("CET"), null);
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("zipCode", e.ParamName);
            }
        }

        /// <summary>
        /// <scenario>
        ///   <no>1</no>
        ///   <given>
        ///      <and>A valid street, postal code, city and country</and>
        ///   </given>
        ///   <when> 
        ///       The addess is created
        ///   </when>
        ///   <ensure>
        ///      the address contains the correct street, postal code, city and country
        ///   </ensure>
        /// </scenario>
        /// </summary>
        [Test]
        public void Create_Valid_Address()
        {
            Address address1 = new Address("City1", new Country("Holland"), "email", "fax",
                                           "numberextension", "stateprovence", "streetname", "streetnumber",
                                           "telephone", new AgriMoreTimeZone("CET"), "zipcode");
            Address address2 =
                new Address("City2", new Country("Holland"), "email", "fax", "numberextension", "stateprovence",
                            "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            Assert.AreEqual("City1", address1.City);
            Assert.AreEqual("Holland", address1.Country.Name);
            Assert.AreEqual("email", address1.Email);
            Assert.AreEqual("fax", address1.Fax);
            Assert.AreEqual("numberextension", address1.NumberExtension);
            Assert.AreEqual("stateprovence", address1.StateProvence);
            Assert.AreEqual("streetname", address1.StreetName);
            Assert.AreEqual("streetnumber", address1.StreetNumber);
            Assert.AreEqual("telephone", address1.Telephone);
            Assert.AreEqual("zipcode", address1.ZipCode);
            Assert.AreEqual("CET", address1.TimeZone.Name);


            Assert.AreEqual(0, address1.CompareTo(address1));
            Assert.AreEqual(-1, address1.CompareTo(address2));
            Assert.AreEqual(1, address1.CompareTo(null));
        }

        /// <summary>
        /// Test_s the technical_ null_ test9.
        /// </summary>
        [Test]
        public void Test_Technical_Equals()
        {
            Address address1 = new Address("City1", new Country("Holland"), "email", "fax",
                                           "numberextension", "stateprovence", "streetname", "streetnumber",
                                           "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            Assert.IsFalse(address1.Equals(null));
        }

        /// <summary>
        /// Test_s the adding of a null location.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Test_Technical_Add_Null_Location()
        {
            Address address1 = new Address("City1", new Country("Holland"), "email", "fax",
                                           "numberextension", "stateprovence", "streetname", "streetnumber",
                                           "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            address1.AddLocation(null);
        }

        /// <summary>
        /// Test_s the technical_ add_ null_ cash register.
        /// </summary>
        [ExpectedException(typeof(ArgumentNullException))]
        [Test]
        public void Test_Technical_Add_Null_CashRegister()
        {
            Address address1 = new Address("City1", new Country("Holland"), "email", "fax",
                                           "numberextension", "stateprovence", "streetname", "streetnumber",
                                           "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            address1.AddCashRegister(null);
        }
        /// <summary>
        /// Test_s the technical_ add_ null_ cash register.
        /// </summary>
        public void Test_Technical_Add_CashRegiste_To_Address_Constructorr()
        {
            CashRegister cr = new CashRegister("Name");

            Address address1 = new Address("City1", new Country("Holland"), "email", "fax",
                                           "numberextension", "stateprovence", "streetname", "streetnumber",
                                           "telephone", new AgriMoreTimeZone("CET"), "zipcode");
            address1.AddCashRegister(cr);

            int numberOfCashRegisters = 0;

            foreach (CashRegister register in address1.CashRegisters)
            {
                numberOfCashRegisters++;
                Assert.AreEqual(cr, register);
            }

            Assert.AreEqual(1, numberOfCashRegisters);
        }

        /// <summary>
        /// Test_s the technical_ add_ null_ cash register.
        /// </summary>
        public void Test_Technical_Add_CashRegister()
        {
            Address address1 = new Address("City1", new Country("Holland"), "email", "fax",
                                           "numberextension", "stateprovence", "streetname", "streetnumber",
                                           "telephone", new AgriMoreTimeZone("CET"), "zipcode");

            Assert.AreEqual(0, new List<CashRegister>(address1.CashRegisters).Count);
            
            CashRegister cashRegister = new CashRegister("Kassa 109201");
            address1.AddCashRegister(cashRegister);

            foreach (CashRegister register in address1.CashRegisters)
            {
                Assert.AreEqual("Kassa 109201", register.Name);
            }
            
            Assert.AreEqual(1, new List<CashRegister>(address1.CashRegisters).Count);

            try
            {
                address1.AddCashRegister(cashRegister);
                Assert.Fail("allowed the same cash register to be added");
            }
            catch(ArgumentException ex)
            {
                Assert.AreEqual("cashRegister", ex.ParamName);
            }
        }
    }
}