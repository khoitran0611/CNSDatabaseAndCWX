using AgriMore.Logistics.Domain;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class Technical_AbstractKeyNameType
    {
        /// <summary>
        /// 
        /// </summary>               
        [Test]
        public void Technical_Test_Equals()
        {
            Country country=new Country("name");
            Assert.IsFalse(country.Equals(new object()));
        }
    }
}