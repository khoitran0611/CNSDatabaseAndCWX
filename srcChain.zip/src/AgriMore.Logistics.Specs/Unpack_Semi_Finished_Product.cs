using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using NUnit.Framework;


namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class Unpack_Semi_Finished_Product
    {
        private readonly PackingMaterial Plastic = new PackingMaterial("Plastic");
        #region Setup/Teardown

        /// <summary>
        /// Setup for the tests.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            //plasticFlowBox = PackageType.FlowPack;
            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            plasticFlowBox = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            chainEntity = new ChainEntity("name");

            identifications1 = new List<Identification>();
            identification1 = new Identification("1", chainEntity);
            identifications1.Add(identification1);

            identifications2 = new List<Identification>();
            identification2 = new Identification("2", chainEntity);
            identifications2.Add(identification2);

            identifications3 = new List<Identification>();
            identification3 = new Identification("3", chainEntity);
            identifications3.Add(identification3);
        }

        #endregion

        private ChainEntity chainEntity;
        private ICollection<Identification> identifications1;
        private ICollection<Identification> identifications2;
        private ICollection<Identification> identifications3;
        private Identification identification1;
        private Identification identification2;
        private Identification identification3;

        private PackageType plasticFlowBox;

        private const string validProductionAreaId = "AAAPA0800001";
        private const string validLifeCycleId = "AAAPC0800001";

        /// <summary>
        /// <scenario>
        ///    <no>33</no>
        /// 	<given>A semi finished product is packed twice</given>
        /// 	<ensure>the main package is removed
        /// <and>the previous package becomes the main package</and>
        /// 		<and>the history of package is kept.</and>
        /// 		<and>ensure the datetime of the removal is recorded</and>
        /// 	</ensure>
        /// </scenario>
        /// </summary>
        [Test]
        public void Unpack_Semi_Finished_Product_Once()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            //1st
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            ////2nd
            Package secondPack =
                package.Pack(plasticFlowBox,
                             new DateTime(2008, 2, 2, 2, 2, 2), identifications2);

            IEnumerable<Package> unPacked = secondPack.Unpack(new DateTime(2008, 2, 2, 2, 2, 2));
            List<Package> listForCount = new List<Package>(unPacked);
            Assert.AreEqual(1, listForCount.Count);
        }

        /// <summary>
        /// <scenario>
        ///    <no>32</no>
        /// 	<given>A primary product product packed one time</given>
        /// 	<ensure>that removing the first form of package is not allowed
        /// 	</ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof(InvalidOperationException))]
        [Test]
        public void Unpack_Semi_Finished_Product_Packed_Once()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);

            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            List<Package> unpackedPackages = new List<Package>();
            unpackedPackages.AddRange(package.Unpack(new DateTime(2008, 2, 2, 2, 2, 2)));
        }
    }
}