using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 	<userstory>
    ///     <no>2</no>
    /// 	<role>All</role>
    /// 	<feature>Pack a product in a specific material</feature>
    /// 	<benefit>I have a packed product and tracibility through a identification on the package material</benefit>
    ///     </userstory>
    /// </summary>
    /// 
    [TestFixture]
    public class Pack_Primary_Product
    {
        #region Setup/Teardown

        /// <summary>
        /// Setup for the tests.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            //plasticFlowBox = PackageType.FlowPack;
            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            plasticFlowBox = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            chainEntity = new ChainEntity("name");

            identifications1 = new List<Identification>();
            identification1 = new Identification("1", chainEntity);
            identifications1.Add(identification1);

            identifications2 = new List<Identification>();
            identification2 = new Identification("2", chainEntity);
            identifications2.Add(identification2);

            identifications3 = new List<Identification>();
            identification3 = new Identification("3", chainEntity);
            identifications3.Add(identification3);
        }

        #endregion

        private readonly PackingMaterial Plastic = new PackingMaterial("Plastic");
        private readonly PackingMaterial BubbleRap = new PackingMaterial("BubbleRap");

        private ChainEntity chainEntity;
        private ICollection<Identification> identifications1;
        private ICollection<Identification> identifications2;
        private ICollection<Identification> identifications3;
        private Identification identification1;
        private Identification identification2;
        private Identification identification3;

        private PackageType plasticFlowBox;

        private const string validProductionAreaId = "AAAPA0800001";
        private const string validLifeCycleId = "AAAPC0800001";

        private const string validProductionAreaId2 = "AAAPA0800002";
        private const string validLifeCycleId2 = "AAAPC0800002";


        private const string invalidProductionAreaId = "aaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbc";
        private const string invalidLifeCycleId = "aaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbcaaaaaaaaaabbbbbbbbbbc";


        /// <summary>
        /// 	<scenario>
        ///         <no>1</no>
        /// 		<given>2 primary product
        ///             <and>a valid packagetype</and>
        /// 			<and>two identifications for the packaging</and>
        /// 		</given>
        /// 		<ensure>the primary product is packed
        ///             <and>the primary product is traceble in the package</and>
        /// 			<and>the packagetype is traceable</and>
        /// 			<and>the number of identifications is correct</and>
        /// 		</ensure>
        /// 	</scenario>
        /// </summary>
        [Test]
        public void Pack_Primary_Product_With_N_Identifications()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            PrimaryProduct primaryProduct2 = new PrimaryProduct(validProductionAreaId2, validLifeCycleId2);

            ICollection<PrimaryProduct> primaryProducts2 = new List<PrimaryProduct>();
            primaryProducts2.Add(primaryProduct);

            identifications1.Add(identification2);
            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

            Package package = new Package(plasticFlowBox, primaryProducts2, dateTimeOfPacking, identifications1);

            Assert.IsTrue(package.IsIdentifiedBy(identification1));
            Assert.IsTrue(package.IsIdentifiedBy(identification2));

            Assert.IsTrue(package.ContainsPrimaryProduct(primaryProduct));
            Assert.IsFalse(package.ContainsPrimaryProduct(primaryProduct2));
            Assert.AreEqual(0, DateTime.Compare(new DateTime(2008, 1, 1, 15, 1, 1), package.PackingDateTime),
                            "DateTime of removal is not correct.");
        }

        /// <summary>
        /// 	<scenario>
        ///         <no>2</no>
        /// 		<given>a valid primary product
        ///             <and>a valid packagetype</and>
        /// 			<and>one identification for packaging</and>
        ///             <and>a valid packing date</and>
        /// 		</given>
        /// 		<ensure>a new package is created
        ///             <and>the primary product is traceable in the package</and>
        /// 			<and>the package is traceable</and>
        /// 		</ensure>
        /// 	</scenario>
        /// </summary>
        [Test]
        public void Pack_Primary_Product_With_One_Identification()
        {
            TransactionManager transactionManager = new TransactionManager();
            transactionManager.BeginTransaction();

            int oldPackageCount =
                new List<Package>(new RepositoryFactory().CreateRepository<Package>().AsCollection()).Count;

            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

            Package package = new Package(plasticFlowBox, primaryProducts, dateTimeOfPacking, identifications1);
            Assert.IsTrue(package.IsIdentifiedBy(identification1));

            Assert.IsTrue(package.ContainsPrimaryProduct(primaryProduct));
            Assert.AreEqual(0, DateTime.Compare(new DateTime(2008, 1, 1, 15, 1, 1), package.PackingDateTime),
                            "DateTime of removal is not correct.");

            Assert.AreEqual("FlowPack", package.PackageType.Name);

            Assert.AreEqual(1, package.PrimaryProducts.Count);
            //Ther should only be 1 at this moment in the test so this is save
            foreach (PrimaryProduct p in package.PrimaryProducts)
            {
                Assert.IsTrue(p.Equals(primaryProduct));
            }


            IRepository<Package> allPackagesInRepository = new RepositoryFactory().CreateRepository<Package>();
            allPackagesInRepository.Add(package);
            transactionManager.CommitTransaction();

            transactionManager.BeginTransaction();

            if (identification1.Uid != 0)
            {
                identification1 = new RepositoryFactory().CreateRepository<Identification>().GetOne(identification1.Uid);
            }

            package = allPackagesInRepository.GetOne(new PackageIdentificationSpecification(identification1));

            Assert.IsTrue(package.IsIdentifiedBy(identification1));

            Assert.IsTrue(package.ContainsPrimaryProduct(primaryProduct));

            Assert.AreEqual(0, DateTime.Compare(new DateTime(2008, 1, 1, 15, 1, 1), package.PackingDateTime),
                            "DateTime of removal is not correct.");

            IList<Package> list = new List<Package>(allPackagesInRepository.AsCollection());
            Assert.AreEqual(oldPackageCount + 1, list.Count);

            // Just 2 test the other constructor
            Package packageWithProductCode =
                new Package(plasticFlowBox, primaryProducts, dateTimeOfPacking, identifications1, "productcode");
            Assert.AreEqual("productcode", packageWithProductCode.ProductCode);

            transactionManager.CommitTransaction();
        }

        /// <summary>
        /// <scenario>
        ///         <no>3</no>
        /// 	<given>a valid PaId for the primary product
        ///         <and>an invalid LcId for the primary product</and>
        /// 	</given>
        /// 	<ensure>the primary product cannot be packed</ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Pack_Primary_Product_With_PaId_And_With_Wrong_LcId_For_Primary_Product()
        {
            new PrimaryProduct(validProductionAreaId, "This is not valid because the length exceeds 255 This is not valid because the length exceeds 255 This is not valid because the length exceeds 255 This is not valid because the length exceeds 255 This is not valid because the length exceeds 255 This is not valid because the length exceeds 255 This is not valid because the length exceeds 255 This is not valid because the length exceeds 255 This is not valid because the length exceeds 255 ");}

        /// <summary>
        ///  <scenario>
        ///         <no>4</no>
        /// 	<given>a valid PaId for the primary product
        ///         <and>an invalid LcId for the primary product is supplied</and>
        /// 	</given>
        /// 	<ensure>the primary product cannot be packed</ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Pack_Primary_Product_With_PaId_And_Without_LcId_For_Primary_Product()
        {
            new PrimaryProduct(validProductionAreaId, null);
        }

        /// <summary>
        /// 	<scenario>
        ///         <no>5</no>
        /// 		<given>a valid primary product 
        ///             <and>an invalid identification for packaging</and>
        ///             <and>a valid packing date</and>
        ///             <and>a valid packagetype</and></given>
        /// 	    <ensure>the primary product cannot be packed</ensure>
        /// 	</scenario>
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentException), ExpectedMessage = "One of the packids is null.")]
        public void Pack_Primary_Product_With_Wrong_Identification()
        {
            identification2 = null;
            identifications1.Add(identification2);

            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);
            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);

            new Package(plasticFlowBox, primaryProducts, dateTimeOfPacking, identifications1);
        }

        /// <summary>
        /// 	<scenario>
        ///         <no>6</no>
        /// 		<given>a valid primary product 
        ///             <and>an empty (no) identification for packaging</and>
        ///             <and>a valid packing date</and>
        ///             <and>a valid packagetype</and></given>
        /// 	    <ensure>the primary product cannot be packed</ensure>
        /// 	</scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Pack_Primary_Product_With_Wrong_Identifications()
        {
            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            PackageType flowBox = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

            new Package(flowBox,
                        primaryProducts, dateTimeOfPacking, new List<Identification>());
        }

        /// <summary>
        /// <scenario>
        ///         <no>7</no>
        /// 	<given>an invalid PaId format for the primary product
        ///         <and>an invalid LcId format for the primary product</and>
        /// 	</given>
        /// 	    <ensure>the primary product cannot be created for packing</ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Pack_Primary_Product_With_Wrong_PaId_And_LcId_For_Primary_Product()
        {
            new PrimaryProduct(invalidProductionAreaId, invalidLifeCycleId);
        }

        /// <summary>
        /// 	<scenario>
        ///         <no>8</no>
        /// 		<given>a valid primary product 
        ///             <and>no identifications are supplied for packaging</and>
        ///             <and>an valid packing date</and>
        ///             <and>an valid packagetype</and></given>
        /// 	    <ensure>the primary product cannot be packed</ensure>
        /// 	</scenario>
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void Pack_Primary_Product_Without_Identifications()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);

            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            PackageType packageType = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            new Package(packageType,
                        primaryProducts, dateTimeOfPacking, null);
        }

        /// <summary>
        /// 	<scenario>
        ///         <no>9</no>
        /// 		<given>a valid primary product 
        ///             <and>valid identifications</and>
        ///             <and>an valid packing date</and>
        ///             <and>an no packagetype</and></given>
        ///             <and>an valid packing datetime</and>
        /// 	    <ensure>the primary product cannot be packed</ensure>
        /// 	</scenario>
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void Pack_Primary_Product_Without_PackageType()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            new Package(null, primaryProducts, dateTimeOfPacking, identifications1);
        }

        /// <summary>
        ///  <scenario>
        ///         <no>10</no>
        /// 	<given>there is no PaId for the primary product
        ///         <and>there is no LcId for the primary product</and>
        /// 	</given>
        /// 	<ensure>the primary product cannot be created</ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Pack_Primary_Product_Without_PaId_And_LcId_For_Primary_Product()
        {
            new PrimaryProduct(null, null);
        }

        /// <summary>
        /// <scenario>
        ///         <no>11</no>
        /// 	<given>an valid LcId for the primary product
        ///         <and>no PaId for the primary product</and></given>
        /// 	<ensure>that the primary product cannot be created</ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Pack_Primary_Product_Without_PaId_And_With_Valid_LcId_For_Primary_Product()
        {
            new PrimaryProduct(null, validLifeCycleId);
        }

        /// <summary>
        /// <scenario>
        ///    <no>22</no>
        /// 	<given>No primary product
        /// <and>a valid id</and>
        /// <and>a valid package type.</and>
        /// 	</given>
        /// 	<ensure>A semi finished cannot be created.</ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Pack_With_Valid_Identification_And_PackageType_But_Without_Valid_Primary_Product()
        {
            new Package(plasticFlowBox, null,
                        new DateTime(2008, 1, 1, 15, 1, 1), identifications1);
        }

        /// <summary>
        /// <scenario>
        ///    <no>23</no>
        /// 	<given>A primary product
        /// <and>a valid identification</and>
        /// <and>no package</and>
        /// 	</given>
        /// 	<ensure>A semi finished cannot be created.</ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Pack_With_Valid_Identification_And_Primary_Product_But_Without_Package()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            new Package(null, primaryProducts,
                        new DateTime(2008, 1, 1, 15, 1, 1), identifications1);
        }

        /// <summary>
        /// <scenario>
        ///    <no>24</no>
        /// 	<given>No primary product.
        /// 	</given>
        /// 	<ensure>A semi finished cannot be created.</ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Pack_With_Valid_Identification_But_Without_Primary_Product_And_Without_Package()
        {
            new Package(null, null, new DateTime(2008, 1, 1, 15, 1, 1), identifications1);
        }

        /// <summary>
        /// <scenario>
        ///    <no>30</no>
        /// 	<given>Two equal semi finished product by identifications</given>
        /// 	<ensure>that they are the same.
        /// 	</ensure>
        /// </scenario>
        /// </summary>
        [Test]
        public void Technical_Test_Equals()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);

            identifications1 = new List<Identification>();
            identification1 = new Identification("1", chainEntity);
            identifications1.Add(identification1);

            identifications2 = new List<Identification>();
            identification2 = new Identification("1", chainEntity);
            identifications2.Add(identification2);

            Package package1 =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            Package package2 =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications2);

            Assert.IsTrue(package1.Equals(package2));
        }


        /// <summary>
        /// <scenario>
        ///    <no>31</no>
        /// 	<given>A semi finished product</given>
        /// 	<ensure>that it is not equal to an empty package.
        /// </ensure>
        /// </scenario>
        /// </summary>
        [Test]
        public void Technical_Test_Equals_Without_Argument()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            Package package =
                new Package(plasticFlowBox, primaryProducts,
                            dateTimeOfPacking, identifications1);
            Assert.AreEqual(false, package.Equals(null));
        }

        /// <summary>
        /// Technical_s the test_ identificaion.
        /// </summary>
        [Test]
        public void Technical_Test_Identificaion()
        {
            Identification id = new Identification("1", new ChainEntity("name"));

            id.Uid = 1;
            Assert.AreEqual(1, id.Uid);
            Assert.IsFalse(id.Equals(null));
        }

        /// <summary>
        /// Technical_s the test_ identificaion_ constructor_ without_ id.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_Identification_Constructor_Without_ChainEntity()
        {
            new Identification("1", null);
        }

        /// <summary>
        /// Technical_s the test_ identificaion_ constructor_ without_ id.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_Identification_Constructor_Without_Id()
        {
            new Identification(null, new ChainEntity("name"));
        }

        ///// <summary>
        ///// Technical_s the test_ identification_ get hashcode.
        ///// </summary>
        //[Test]
        //public void Technical_Test_Identification_GetHashcode()
        //{
        //    Identification i = new Identification("1", chainEntity);
        //    Assert.AreEqual("1".GetHashCode(), i.GetHashCode());
        //}

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void Technical_Test_Measurement()
        {
            Measurement measurement = new Measurement(new UnitOfMeasurement("cm"), 11);

            Assert.AreEqual("cm", measurement.UnitOfMeasurement.Name);
            Assert.AreEqual(11, measurement.Value);
        }


        /// <summary>
        /// <scenario>
        ///    <no>2</no>
        /// 	<given>A semi finished product</given>
        /// 	<ensure>that it is not equal to another package.
        /// </ensure>
        /// </scenario>
        /// </summary>
        [Test]
        public void Technical_Test_NotEquals()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);


            Package package1 = new Package(plasticFlowBox, primaryProducts, dateTimeOfPacking, identifications1);

            Package package2 = new Package(plasticFlowBox, primaryProducts, dateTimeOfPacking, identifications2);

            Assert.IsFalse(package1.Equals(package2));
        }

        /// <summary>
        /// Technical_s the test_ package_ constructor_ with_ product code_ but_ with_ empty_ product code argument.
        /// </summary>
        [Test]
        public void Technical_Test_Package_Constructor_With_ProductCode_But_With_Empty_ProductCodeArgument()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);

            ICollection<PrimaryProduct> primaryProducts2 = new List<PrimaryProduct>();
            primaryProducts2.Add(primaryProduct);

            identifications1.Add(identification2);
            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

            new Package(plasticFlowBox, primaryProducts2, dateTimeOfPacking, identifications1, string.Empty);
        }

        ///// <summary>
        ///// Technical_s the test_ package_ constructor_ with_ product code_ but_ with_ spaced_ product code argument.
        ///// </summary>
        //[ExpectedException(typeof (ArgumentException))]
        //[Test]
        //public void Technical_Test_Package_Constructor_With_ProductCode_But_With_Spaced_ProductCodeArgument()
        //{
        //    PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);

        //    ICollection<PrimaryProduct> primaryProducts2 = new List<PrimaryProduct>();
        //    primaryProducts2.Add(primaryProduct);

        //    identifications1.Add(identification2);
        //    DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

        //    new Package(plasticFlowBox, primaryProducts2, dateTimeOfPacking, identifications1, "  ");
        //}

        ///// <summary>
        ///// Technical_s the test_ package_ constructor_ with_ product code_ but_ without_ the_ argument.
        ///// </summary>
        //[ExpectedException(typeof (ArgumentNullException))]
        //[Test]
        //public void Technical_Test_Package_Constructor_With_ProductCode_But_Without_The_ProductCodeArgument()
        //{
        //    PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);

        //    ICollection<PrimaryProduct> primaryProducts2 = new List<PrimaryProduct>();
        //    primaryProducts2.Add(primaryProduct);

        //    identifications1.Add(identification2);
        //    DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

        //    new Package(plasticFlowBox, primaryProducts2, dateTimeOfPacking, identifications1, null);
        //}

        /// <summary>
        /// Technical_s the test_ package_ contains_ primary_ product_ without_ argument.
        /// </summary>
        [Test]
        public void Technical_Test_Package_Contains_Primary_Product_Without_Argument()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);

            ICollection<PrimaryProduct> primaryProducts2 = new List<PrimaryProduct>();
            primaryProducts2.Add(primaryProduct);

            identifications1.Add(identification2);
            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

            Package package = new Package(plasticFlowBox, primaryProducts2, dateTimeOfPacking, identifications1);

            Assert.IsFalse(package.ContainsPrimaryProduct(null));
        }


        /// <summary>
        /// Technical_s the test_ package type_ constructor_ without_ valid_ package type category.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_PackageType_Constructor_With_Empty_Name()
        {
            PackageTypeCategory packageTypeCategory = new PackageTypeCategory("wholesalePackaging");
            new PackageType(string.Empty, packageTypeCategory, BubbleRap,
                            new Measurement(new UnitOfMeasurement("cm"), 1),
                            new Measurement(new UnitOfMeasurement("cm"), 1)
                            , new Measurement(new UnitOfMeasurement("cm"), 1),
                            new Measurement(new UnitOfMeasurement("cm"), 1), true, true);
        }

        /// <summary>
        /// Technical_s the name of the test_ package type_ constructor_ with_ spaces_.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_PackageType_Constructor_With_Spaces_Name()
        {
            PackageTypeCategory packageTypeCategory = new PackageTypeCategory("wholesalePackaging");
            new PackageType("   ", packageTypeCategory, BubbleRap,
                            new Measurement(new UnitOfMeasurement("cm"), 1),
                            new Measurement(new UnitOfMeasurement("cm"), 1)
                            , new Measurement(new UnitOfMeasurement("cm"), 1),
                            new Measurement(new UnitOfMeasurement("cm"), 1), true, true);
        }

        /// <summary>
        /// Technical_s the name of the test_ package type_ constructor_ without_ valid_.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_PackageType_Constructor_Without_Valid_Name()
        {
            PackageTypeCategory packageTypeCategory = new PackageTypeCategory("wholesalePackaging");
            new PackageType(null, packageTypeCategory, BubbleRap,
                            new Measurement(new UnitOfMeasurement("cm"), 1),
                            new Measurement(new UnitOfMeasurement("cm"), 1)
                            , new Measurement(new UnitOfMeasurement("cm"), 1),
                            new Measurement(new UnitOfMeasurement("cm"), 1), true, true);
        }

        /// <summary>
        /// Technical_s the test_ package type_ constructor_ without_ valid_ package type category.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_PackageType_Constructor_Without_Valid_PackageTypeCategory()
        {
            new PackageType(string.Empty, null, BubbleRap,
                            new Measurement(new UnitOfMeasurement("cm"), 1),
                            new Measurement(new UnitOfMeasurement("cm"), 1)
                            , new Measurement(new UnitOfMeasurement("cm"), 1),
                            new Measurement(new UnitOfMeasurement("cm"), 1), true, true);
        }

        /// <summary>
        /// Technical_s the test_ package type_ constructor_ without_ valid_ packing material.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_PackageType_Constructor_Without_Valid_PackingMaterial()
        {
            PackageTypeCategory packageTypeCategory = new PackageTypeCategory("wholesalePackaging");
            new PackageType(string.Empty, packageTypeCategory, null,
                            new Measurement(new UnitOfMeasurement("cm"), 1),
                            new Measurement(new UnitOfMeasurement("cm"), 1)
                            , new Measurement(new UnitOfMeasurement("cm"), 1),
                            new Measurement(new UnitOfMeasurement("cm"), 1), true, true);
        }

        /// <summary>
        /// Technical_s the test_ package type_ constructor_ without_ valid_ package type category.
        /// </summary>
        [Test]
        public void Technical_Test_PackageType_Equals()
        {
            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");

            PackageType packageType = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            PackageType samePackageType = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            Assert.IsFalse(packageType.Equals(new object()));
            Assert.IsTrue(packageType.Equals(samePackageType));
        }

        /// <summary>
        /// Technical_s the test_ package type_ constructor_ without_ valid_ package type category.
        /// </summary>
        [Test]
        public void Technical_Test_PackageType_Getters()
        {
            PackageTypeCategory packageTypeCategory = new PackageTypeCategory("wholesalePackaging");
            PackageType packageType =
                new PackageType("Container", packageTypeCategory, BubbleRap,
                                new Measurement(new UnitOfMeasurement("cm"), 1),
                                new Measurement(new UnitOfMeasurement("cm"), 1)
                                , new Measurement(new UnitOfMeasurement("cm"), 1),
                                new Measurement(new UnitOfMeasurement("cm"), 1), true, true);

            Assert.AreEqual(BubbleRap.Name, packageType.PackingMaterial.Name);
            Assert.AreEqual("wholesalePackaging", packageType.PackageTypeCategory.Name);
            Assert.AreEqual("Container", packageType.Name);
            //Assert.AreEqual("Container".GetHashCode(), packageType.GetHashCode());
            Assert.AreEqual(true, packageType.IsSealed);
            Assert.AreEqual(true, packageType.IsVentilated);

            Assert.AreEqual(1, packageType.Height.Value);
            Assert.AreEqual("cm", packageType.Height.UnitOfMeasurement.Name);

            Assert.AreEqual(1, packageType.Lenght.Value);
            Assert.AreEqual("cm", packageType.Lenght.UnitOfMeasurement.Name);

            Assert.AreEqual(1, packageType.Width.Value);
            Assert.AreEqual("cm", packageType.Width.UnitOfMeasurement.Name);

            Assert.AreEqual(1, packageType.Weight.Value);
            Assert.AreEqual("cm", packageType.Weight.UnitOfMeasurement.Name);
        }

        /// <summary>
        /// Technical_s the name of the test_ package type category_ constructor_ with_ empty_.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_PackageTypeCategory_Constructor_With_Empty_Name()
        {
            new PackageTypeCategory(string.Empty);
        }

        /// <summary>
        /// Technical_s the name of the test_ package type category_ constructor_ with_ spaces_.
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Technical_Test_PackageTypeCategory_Constructor_With_Spaces_Name()
        {
            new PackageTypeCategory("    ");
        }

        /// <summary>
        /// Technical_s the name of the test_ package type category_ constructor_ without_ valid_.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_PackageTypeCategory_Constructor_Without_Valid_Name()
        {
            new PackageTypeCategory(null);
        }

        /// <summary>
        /// Technical_s the test_ package type category_ uid.
        /// </summary>
        [Test]
        public void Technical_Test_PackageTypeCategory_Uid()
        {
            PackageTypeCategory packageTypeCategory1 = new PackageTypeCategory("name");
            PackageTypeCategory packageTypeCategory2 = new PackageTypeCategory("name");
            PackageTypeCategory packageTypeCategory3 = new PackageTypeCategory("noname");
            packageTypeCategory1.Uid = 1;

            Assert.AreEqual(1, packageTypeCategory1.Uid);
            Assert.IsFalse(packageTypeCategory1.Equals(new object()));
            Assert.IsFalse(packageTypeCategory1.Equals(null));
            Assert.IsTrue(packageTypeCategory1.Equals(packageTypeCategory2));
            Assert.IsFalse(packageTypeCategory1.Equals(packageTypeCategory3));
            Assert.AreEqual("1", packageTypeCategory1.ToString());
            Assert.AreEqual("name".GetHashCode(), packageTypeCategory1.GetHashCode());
        }

        /// <summary>
        /// Technical test package type repository.
        /// </summary>
        [Test]
        public void Technical_Test_PackageTypeRepository()
        {
            IRepository<PackageType> memoryPackageTypeRepository =
                new RepositoryFactory().CreateRepository<PackageType>();

            int oldCount = new List<PackageType>(memoryPackageTypeRepository).Count;

            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");

            PackageType flowPack = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            PackageType openDoos = new PackageType(
                "OpenDoos",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );


            memoryPackageTypeRepository.Add(flowPack);
            memoryPackageTypeRepository.Add(openDoos);
            IList<PackageType> packageTypes = new List<PackageType>(memoryPackageTypeRepository);
            Assert.AreEqual(oldCount + 2, packageTypes.Count);
        }

        /// <summary>
        /// Ask for an PackageType without a key.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_PackageTypeRepository_PackageType_No_Valid_Key()
        {
            IRepository<PackageType> memoryPackageTypeRepository =
                new RepositoryFactory().CreateRepository<PackageType>();

            int oldCount = new List<PackageType>(memoryPackageTypeRepository).Count;

            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            PackageType flowPack = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            PackageType openDoos = new PackageType(
                "OpenDoos",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            memoryPackageTypeRepository.Add(flowPack);
            memoryPackageTypeRepository.Add(openDoos);

            IList<PackageType> packageTypes = new List<PackageType>(memoryPackageTypeRepository);
            Assert.AreEqual(oldCount + 2, packageTypes.Count);
            string p = null;
            memoryPackageTypeRepository.GetOne(p);
        }

        /// <summary>
        /// Ask for an PackageType without an existing key.
        /// </summary>
        [Test]
        public void Technical_Test_PackageTypeRepository_PackageType_Not_Found()
        {
            IRepository<PackageType> memoryPackageTypeRepository =
                new RepositoryFactory().CreateRepository<PackageType>();

            int oldCount = new List<PackageType>(memoryPackageTypeRepository).Count;

            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            PackageType flowPack = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            PackageType openDoos = new PackageType(
                "OpenDoos",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            memoryPackageTypeRepository.Add(flowPack);
            memoryPackageTypeRepository.Add(openDoos);

            IList<PackageType> packageTypes = new List<PackageType>(memoryPackageTypeRepository);
            Assert.AreEqual(oldCount + 2, packageTypes.Count);

            PackageType found = memoryPackageTypeRepository.GetOne("NonExistingKey");
            Assert.IsNull(found);
        }

        /// <summary>
        /// Technical_s the test_ primary product.
        /// </summary>
        [Test]
        public void Technical_Test_PrimaryProduct()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId, "paprika");
            PrimaryProduct primaryProductOther =
                new PrimaryProduct(validProductionAreaId2, validLifeCycleId2, "paprika");
            primaryProduct.Uid = 1;

            Assert.AreEqual(validProductionAreaId, primaryProduct.ProductionAreaId);
            Assert.AreEqual(validLifeCycleId, primaryProduct.LifeCycleId);
            Assert.AreEqual("paprika", primaryProduct.HarvestedProductDescription);
            Assert.AreEqual(1, primaryProduct.Uid);
            Assert.AreEqual(validProductionAreaId.GetHashCode(), primaryProduct.GetHashCode());
            Assert.AreEqual(validProductionAreaId + "," + validLifeCycleId, primaryProduct.ToString());

            Assert.IsFalse(primaryProduct.Equals(null));
            Assert.IsFalse(primaryProduct.Equals(primaryProductOther));
        }
    }
}