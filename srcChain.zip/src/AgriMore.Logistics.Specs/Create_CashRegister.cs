using System;
using AgriMore.Logistics.Domain;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    ///   <userstory>
    ///     <no></no>
    ///     <role>Administrator</role>
    ///     <feature>Manage an CashRegister</feature>
    ///     <benefit>I can allocate an CashRegister to a location</benefit>
    ///   </userstory>
    /// </summary>
    [TestFixture]
    public class Create_CashRegister
    {
        /// <summary>
        /// Create invalid CashRegister.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void Create_Invalid_CashRegister()
        {
            new CashRegister(null);
        }

        /// <summary>
        /// Create invalid CashRegister.
        /// </summary>
        [Test]
        public void Create_valid_CashRegister()
        {
            string name = "Kassa 109201";
            CashRegister cashRegister = new CashRegister("Kassa 109201");
            Assert.AreEqual(name, cashRegister.Name);
            Assert.AreEqual(0, cashRegister.Uid);
            Assert.AreEqual(name, cashRegister.ToString());
            Assert.AreEqual(name.GetHashCode(), cashRegister.GetHashCode());
            Assert.AreEqual(0, cashRegister.CompareTo(cashRegister));
            Assert.IsTrue(cashRegister.Equals(cashRegister));
        }

        /// <summary>
        /// Create invalid CashRegister.
        /// </summary>
        [Test]
        public void Create_valid_CashRegister_Compare_With_Other_CashRegister()
        {
            string nameCashRegister = "Kassa 109201";
            string nameCashRegister2 = "Kassa";

            CashRegister cashRegister = new CashRegister(nameCashRegister);
            CashRegister cashRegister2 = new CashRegister(nameCashRegister2);

            Assert.AreNotEqual(cashRegister.GetHashCode(), cashRegister2.GetHashCode());
            Assert.AreEqual(-1, cashRegister.CompareTo(cashRegister2));
            Assert.IsFalse(cashRegister.Equals(cashRegister2));
        }

        /// <summary>
        /// 
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void Create_valid_CashRegister_Compare_With_Spaced_Name_In_Constructor()
        {
            new CashRegister(" ");
        }

        /// <summary>
        /// Technical_s the test_ compare.
        /// </summary>
        [Test]
        public void Technical_Test_Compare()
        {
            string nameCashRegister = "Kassa 109201";

            CashRegister cashRegister = new CashRegister(nameCashRegister);
            Assert.AreEqual(1,cashRegister.CompareTo(null));
        }

        /// <summary>
        /// Technical_s the test_ equals.
        /// </summary>
        [Test]
        public void Technical_Test_Equals_Null_Argument()
        {
            string nameCashRegister = "Kassa 109201";

            CashRegister cashRegister = new CashRegister(nameCashRegister);
            Assert.IsFalse(cashRegister.Equals(null));
        }
    }
}