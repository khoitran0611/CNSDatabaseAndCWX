using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Repository.Memory;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class Pack_Semi_Finished_Product
    {
        private static readonly PackingMaterial Plastic = new PackingMaterial("Plastic");
        #region Setup/Teardown

        /// <summary>
        /// Setup for the tests.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            plasticFlowBox = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            chainEntity = new ChainEntity("name");

            identifications1 = new List<Identification>();
            identification1 = new Identification("1", chainEntity);
            identifications1.Add(identification1);

            identifications2 = new List<Identification>();
            identification2 = new Identification("2", chainEntity);
            identifications2.Add(identification2);

            identifications3 = new List<Identification>();
            identification3 = new Identification("3", chainEntity);
            identifications3.Add(identification3);

            identifications4 = new List<Identification>();
            identification4 = new Identification("4", chainEntity);
            identifications4.Add(identification4);
        }

        #endregion

        private ChainEntity chainEntity;
        private ICollection<Identification> identifications1;
        private ICollection<Identification> identifications2;
        private ICollection<Identification> identifications3;
        private ICollection<Identification> identifications4;
        private Identification identification1;
        private Identification identification2;
        private Identification identification3;
        private Identification identification4;

        private PackageType plasticFlowBox;

        private const string validProductionAreaId = "AAAPA0800001";
        private const string validLifeCycleId = "AAAPC0800001";

        /// <summary>
        /// Pack_s the two_ semi_ finished_ product_ into_ one_ new_ package_ wihout_ valid_ package argument.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Pack_Semi_Finished_Product_Into_One_New_Package_Wihout_Valid_PackageArgument()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);

            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            package.Pack(null);
        }


        /// <summary>
        /// <scenario>
        ///         <no>12</no>
        /// 	<given>a valid primary product.</given>
        /// 	<ensure>when packing it 3 times the last package form is the last one added.</ensure>
        /// </scenario>
        /// </summary>
        [Test]
        public void Pack_Semi_Finished_Product_Three_Times()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            //1st
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);
            package.Uid = 1;

            //2nd
            Package secondPack =
                package.Pack(plasticFlowBox,
                             new DateTime(2008, 2, 2, 2, 2, 2), identifications2);
            secondPack.Uid = 2;
            Assert.AreEqual(2, package.ParentPackage.Uid);

            //3rd
            Package thirdPack =
                secondPack.Pack(plasticFlowBox,
                                new DateTime(2008, 3, 3, 3, 3, 3), identifications3, "productcode");

            Assert.IsTrue(thirdPack.IsIdentifiedBy(identification3));
            Assert.AreEqual(0, DateTime.Compare(new DateTime(2008, 3, 3, 3, 3, 3), thirdPack.PackingDateTime));
            Assert.IsTrue(thirdPack.ContainsPrimaryProduct(primaryProduct));
            Assert.IsTrue(thirdPack.Contains(secondPack));
            Assert.AreEqual("productcode", thirdPack.ProductCode);
            Assert.AreEqual(1, new List<Package>(secondPack.Children).Count);
        }

        /// <summary>
        /// <scenario>
        ///         <no>13</no>
        /// 	<given>a semi finished product that it is packed twice with the same id's.</given>
        /// 	<ensure>It is packed right.</ensure>
        /// </scenario>
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "The identification is already present.")]
        public void Pack_Semi_Finished_Product_Two_Times_With_One_Identification()
        {
            IRepository<Package> set = new MemoryMapRepository<Package>();

            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);
            // 1st pack
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);
            set.Add(package);

            package.AddIdentification(identification1);

        }

        /// <summary>
        /// <scenario>
        ///    <no>17</no>
        /// 	<given>A existing semi finished product</given>
        /// 	<ensure>After packing adding an empty identification in not allowed.</ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Pack_Semi_Finished_Product_With_One_Identification_And_Add_Null_Identification()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            PackageType flowPack = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            Package package =
                new Package(flowPack,
                            primaryProducts, dateTimeOfPacking, identifications1);

            package.AddIdentification(null);
        }

        /// <summary>
        /// <scenario>
        ///         <no>14</no>
        /// 	<given>A existing semi finished product.</given>
        /// 	<ensure>After packing adding an invalid identification in not allowed.</ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Pack_Semi_Finished_Product_With_One_Identification_And_Later_Add_Empty_Identification()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            PackageType flowPack = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            Package package =
                new Package(flowPack,
                            primaryProducts, dateTimeOfPacking, identifications1);

            package.AddIdentification(null);
        }

        /// <summary>
        /// <scenario>
        ///         <no>15</no>
        /// 	<given>A existing semi finished product.</given>
        /// 	<ensure>After packing adding an invalid identification in not allowed.</ensure>
        /// </scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentException), ExpectedMessage = "The identification is already present.")]
        [Test]
        public void Pack_Semi_Finished_Product_With_One_Identification_And_Later_Add_The_Same_Identification()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            package.AddIdentification(identification2);
            Assert.IsTrue(package.IsIdentifiedBy(identification2));

            package.AddIdentification(identification1);
        }

        /// <summary>
        /// 	<scenario>
        /// 		<no>19</no>
        /// 		<given>a existing semi finished product</given>
        /// 		<ensure> that trying to pack the second time and the date is before the paccking date of the previous package no packing takes place.</ensure>
        /// 	</scenario>
        /// </summary>
        [ExpectedException(typeof (ArgumentException))]
        [Test]
        public void
            Pack_Semi_Finished_Product_With_One_Identification_And_PackDateTime_Before_PackDateTime_Previous_Packing()
        {
            PrimaryProduct primaryProduct;
            DateTime dateTimeOfPacking;
            Package package;

            primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

            package =
                new Package(plasticFlowBox, primaryProducts, dateTimeOfPacking, identifications1);

            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            PackageType flowPack = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            package.Pack(flowPack,
                         new DateTime(2005, 1, 1, 15, 1, 1), identifications2);
        }

        /// <summary>
        /// <scenario>
        ///    <no>20</no>
        /// 	<given>an existing packed semi finished product
        ///     <and>the same identifications are used for the next pack</and>
        ///     <and>the same date time is used for the next pack</and>
        ///     </given>
        ///     <when>pack an already packed sfp</when>
        /// 	<ensure>the second pack is identified by the same identifications as the first
        ///     <and> the packing datetime is the same for both packages</and>
        ///     </ensure>
        /// </scenario>
        /// </summary>
        [Test]
        public void
            Pack_Semi_Finished_Product_With_One_Identification_And_PackDateTime_Same_PackDateTime_As_Previous_Packing()
        {
            // 1st Pack
            PrimaryProduct pp;
            DateTime dateTimeOfPacking;
            Package package;

            pp = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(pp);

            dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);

            package =
                new Package(plasticFlowBox, primaryProducts, dateTimeOfPacking, identifications1);

            // 2nd Pack
            Package secondPack =
                package.Pack(plasticFlowBox,
                             new DateTime(2008, 1, 1, 15, 1, 1), identifications1);

            Assert.IsTrue(secondPack.IsIdentifiedBy(identification1));
            Assert.AreEqual(0, DateTime.Compare(new DateTime(2008, 1, 1, 15, 1, 1), secondPack.PackingDateTime),
                            "DateTime of removal is not correct.");
        }

        /// <summary>
        /// <scenario>
        ///    <no>21</no>
        /// 	<given>Two semi finished products</given>
        /// 	<ensure>they are both packed into a third package.
        /// </ensure>
        /// </scenario>
        /// </summary>
        [Test]
        public void Pack_Two_Semi_Finished_Product_Into_One_New_Package()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            //1st
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            //2nd
            Package secondPack =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications2);

            //Create a new package which wraps number one
            Package thirdPack =
                package.Pack(plasticFlowBox,
                             new DateTime(2008, 3, 3, 3, 3, 3), identifications3);
            //Add number 2 to number 3
            secondPack.Pack(thirdPack);
        }

        /// <summary>
        /// Technical_s the test_ identification for chain entity.
        /// </summary>
        [Test]
        public void Technical_Test_IdentificationForChainEntity()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            //1st
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);
            Assert.AreEqual("1", package.IdentificationForChainEntity(chainEntity));

            ChainEntity ce = new ChainEntity("1");
            ce.Uid = 1;

            Assert.AreEqual(string.Empty, package.IdentificationForChainEntity(ce));
        }

        /// <summary>
        /// Technical_s the test_ identification for chain entity_ without_ valid_ chain entity.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Technical_Test_IdentificationForChainEntity_With_Null_Argument()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            //1st
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            package.IdentificationForChainEntity(null);
        }

        /// <summary>
        /// Technical_s the test_ package_ add_ treatments.
        /// </summary>
        [Test]
        public void Technical_Test_Package_Add_Treatments()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            //1st
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            DateTime startDateTimeTreatment = new DateTime(2008, 1, 1, 1, 1, 1);
            DateTime endDateTimeTreatment = new DateTime(2008, 2, 1, 1, 1, 1);

            IRange<DateTime> treatmentDuration = new Range<DateTime>(startDateTimeTreatment, endDateTimeTreatment);

            TreatmentType treatmentType =
                new TreatmentType("water", new TreatmentTypeCategory("wash"), new UnitOfMeasurement("pH"));

            Treatment treatment = new Treatment(treatmentType, treatmentDuration, 1.1);
            Treatment sameTreatment = new Treatment(treatmentType, treatmentDuration, 1.1);
            Treatment otherTreatment = new Treatment(treatmentType, treatmentDuration, 2.2);

            List<Treatment> treatments = new List<Treatment>();
            treatments.Add(treatment);
            treatments.Add(otherTreatment);

            package.AddTreatments(treatments);
            Assert.AreEqual(2, package.Treatments.Count);

            treatments = new List<Treatment>();
            treatments.Add(sameTreatment);

            Assert.AreEqual(2, package.Treatments.Count);

            Treatment thirdTreatment = new Treatment(treatmentType, treatmentDuration, 3.3);
            package.AddTreatment(thirdTreatment);
            Assert.AreEqual(3, package.Treatments.Count);

        }

        /// <summary>
        /// Technical_s the test_ package_ clear parent.
        /// </summary>
        [Test]
        public void Technical_Test_Package_ClearParent()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            //1st
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            //2nd
            Package secondPack =
                package.Pack(plasticFlowBox,
                             new DateTime(2008, 2, 2, 2, 2, 2), identifications2);

            Assert.AreEqual(package.ParentPackage, secondPack);
            package.ClearParent();
            Assert.AreEqual(package.ParentPackage, null);
        }

        /// <summary>
        /// Technical_s the test_ package_ contains.
        /// </summary>
        [Test]
        public void Technical_Test_Package_Contains()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            //1st
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);
            //2nd
            Package secondPack =
                package.Pack(plasticFlowBox,
                             new DateTime(2008, 2, 2, 2, 2, 2), identifications2);

            Assert.IsTrue(secondPack.Contains(package));
            Assert.IsFalse(secondPack.Contains(null));
        }

        /// <summary>
        /// Technical_s the test_ package_ equals.
        /// </summary>
        [Test]
        public void Technical_Test_Package_Equals()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            //1st
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            //2nd
            ICollection<Identification> identifications = new List<Identification>();
            identifications.Add(new Identification("11", chainEntity));
            identifications.Add(new Identification("12", chainEntity));

            Package secondPack =
                package.Pack(plasticFlowBox,
                             new DateTime(2008, 2, 2, 2, 2, 2), identifications);
            // Should fbe false because of the number of indentifications.
            Assert.IsFalse(package.Equals(secondPack));
        }

        /// <summary>
        /// Technical_s the test_ package_ to string.
        /// </summary>
        [Test]
        public void Technical_Test_Package_ToString()
        {
            ICollection<Identification> identifications = new List<Identification>();
            identifications.Add(new Identification("11", chainEntity));

            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications);

            Assert.AreEqual("11", package.ToString());

        }

        /// <summary>
        /// Technical_s the test_ package_ get_ null_ exposure document.
        /// </summary>
        [Test]
        public void Technical_Test_Package_Get_Null_CurrentExposureDocument()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);

            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            Assert.IsNull(package.CurrentExposureDocument);
        }

        /// <summary>
        /// Technical_s the test_ package_ get_ null_ exposure documents.
        /// </summary>
        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void Technical_Test_Package_Get_Null_RetrieveExposureDocument()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);

            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            Location location=new Location("test");
            Assert.IsNull(package.RetrieveExposureDocument(location));

            package.RetrieveExposureDocument(null);
        }

        /// <summary>
        /// Technical_s the test_ package_ repack.
        /// </summary>
        [Test]
        public void Technical_Test_Package_Repack()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            //1st
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);


            package.Repack(new DateTime(2008, 1, 1, 1, 1, 1));

            Assert.IsTrue(package.IsUnpacked);
            Assert.IsFalse(package.IsInLocation);
            Assert.IsFalse(package.IsCheckedOut);
        }

        /// <summary>
        /// Technical_s the test_ package_ exposure documents.
        /// </summary>
        [Test]
        public void Technical_Test_Package_ExposureDocuments()
        {
            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            ICollection<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(primaryProduct);

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 1, 1, 1);
            //1st
            Package package =
                new Package(plasticFlowBox,
                            primaryProducts, dateTimeOfPacking, identifications1);

            Location location=new Location("location");

            ExposureDocument exposureDocument = new ExposureDocument(location,package);
            package.AddExposureDocument(exposureDocument);

            List<ExposureDocument> listForCount = new List<ExposureDocument>(package.ExposureDocuments);

            Assert.AreEqual(1, listForCount.Count);
        }
    }
}