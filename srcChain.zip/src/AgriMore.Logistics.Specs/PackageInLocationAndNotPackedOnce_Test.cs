using System;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class PackageInLocationAndNotPackedOnce_Test
    {
        /// <summary>
        ///
        /// </summary>
        [ExpectedException(typeof(ArgumentNullException))]
        [Test]
        public void PackageInLocationAndNotPackedOnce_Constructor_Null_Argument_Test()
        {
            new PackageInLocationAndNotPackedOnce(null);
        }

        /// <summary>
        /// Packages the in location and not packed once test.
        /// </summary>
        [Test]
        public void PackageInLocationAndNotPackedOnceTest()
        {
            Location location = new Location("PackageInLocationAndNotPackedOnce_Test");
            PackageInLocationAndNotPackedOnce packageInLocationAndNotPackedOnce=new PackageInLocationAndNotPackedOnce(location);

            //Assert.AreEqual(location, packageInLocationAndNotPackedOnce.Location);
        }
    }
}