using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class DeliveredShipmentForChainEntityNotInLocationSpecificationTest
    {
        private TransactionManager transactionManager;

        private Package package1;
        private Package package2;

        private ChainEntity chainEntity;
        private PackageType plasticFlowBox;
        private const string validProductionAreaId2 = "AAAPA0800002";
        private const string validLifeCycleId2 = "AAAPC0800002";
        private const string validProductionAreaId = "AAAPA0800001";
        private const string validLifeCycleId = "AAAPC0800001";

        private readonly PackingMaterial Plastic = new PackingMaterial("Plastic");

        /// <summary>
        /// Setups this instance.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            transactionManager = new TransactionManager();
            transactionManager.BeginTransaction();

            new RepositoryFactory().InitializeTestData();

            PackageTypeCategory retailPackaging;
            retailPackaging = new PackageTypeCategory("retailPackaging");
            plasticFlowBox = new PackageType(
                "FlowPack",
                retailPackaging,
                Plastic,
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );

            //plasticFlowBox = PackageType.FlowPack;

            PrimaryProduct primaryProduct = new PrimaryProduct(validProductionAreaId, validLifeCycleId);
            PrimaryProduct primaryProduct2 = new PrimaryProduct(validProductionAreaId2, validLifeCycleId2);

            ICollection<PrimaryProduct> primaryProducts1 = new List<PrimaryProduct>();
            primaryProducts1.Add(primaryProduct);
            ICollection<PrimaryProduct> primaryProducts2 = new List<PrimaryProduct>();
            primaryProducts2.Add(primaryProduct2);

            chainEntity = new ChainEntity("name");

            DateTime dateTimeOfPacking = new DateTime(2008, 1, 1, 15, 1, 1);
            Identification[] identifications1 = { new Identification("1", chainEntity) };
            Identification[] identifications2 = { new Identification("2", chainEntity) };
            package1 = new Package(plasticFlowBox, primaryProducts1, dateTimeOfPacking, identifications1);
            package2 = new Package(plasticFlowBox, primaryProducts2, dateTimeOfPacking, identifications2);
        }

        /// <summary>
        /// Tears the down.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            transactionManager.RollbackTransaction();
        }

        /// <summary>
        /// Delivereds the shipment for chain entity not in locatoin specification test.
        /// </summary>
        [Test]
        public void DeliveredShipmentForChainEntityNotInLocatoinSpecification_Test()
        {
            ICollection<Package> packages = new Collection<Package>();

            Address forwarderAddress;
            Address receiverAddress;
            Address testAddress;
            Address shipperAddress = CreateAddresses(out forwarderAddress, out receiverAddress, out testAddress);
            
            Location forwarderLocation;
            Location receiverLocation;
            Location shipperLocation = AddLocationsToAddresses(shipperAddress, forwarderAddress, out forwarderLocation, receiverAddress, out receiverLocation, testAddress);

            AddLocationsToLocationRepository(shipperLocation, receiverLocation, forwarderLocation);

            IList<Exposure> exposures1;
            IList<Exposure> exposures2;

            CreateExposures(out exposures1, out exposures2);

            packages.Add(package1);
            packages.Add(package2);

            shipperLocation.Put(package1, exposures1, DateTime.Now);
            shipperLocation.Put(package2, exposures2, DateTime.Now);

            ChainEntity shipper;
            ChainEntity forwarder;
            ChainEntity receiver;
            AddAddressesToChainEntities(shipperAddress, forwarderAddress, receiverAddress, out shipper, out forwarder, out receiver);

            Range<DateTime> pickUpRange = GetPickupRange();
            Range<DateTime> deliverRange = GetDeliverRange();

            IList<ShipmentExposure> shipmentExposures = GetShipmentExposures();

            Shipment shipment = CreateShipment(shipperLocation, packages, shipper, receiver, forwarder, pickUpRange, deliverRange, shipmentExposures);
            new RepositoryFactory().GetShipmentRepository().Add(shipment);

            DateTime pickupTime = DateTime.Now;
            shipment.Pickup(pickupTime);

            TransportEquipment transportEquipment = new TransportEquipment(forwarder, forwarderLocation);
            transportEquipment.Pickup(shipment, pickupTime, shipperLocation, exposures2);

            Assert.IsFalse(shipperLocation.Contains(package1));
            Assert.IsFalse(shipperLocation.Contains(package2));
            Assert.IsTrue(transportEquipment.Contains(shipment));

            foreach (Package package in shipment.Packages)
            {
                // check if all packages have been moved to the location of the transportEquipment
                Assert.IsFalse(shipperLocation.Contains(package), "The package should not be in shipper stock.");
                Assert.IsTrue(forwarderLocation.Contains(package),
                              "The package should be in transportEquipment location.");
            }

            // Finally 
            DeliveredShipmentForChainEntityNotInLocatoinSpecification spec =
                new DeliveredShipmentForChainEntityNotInLocatoinSpecification(receiver, receiverLocation);
            ICollection<Shipment> shipments = new RepositoryFactory().ConcreteRepositoryFactory.GetShipmentRepository().Find(spec);

            Assert.AreEqual(0, shipments.Count);

            transportEquipment.Deliver(shipment,DateTime.Now,"no remarks",receiverLocation);
            Assert.IsTrue(shipment.IsDelivered);

            // Finally 
            spec =
                new DeliveredShipmentForChainEntityNotInLocatoinSpecification(receiver,receiverLocation);
            shipments=new RepositoryFactory().ConcreteRepositoryFactory.GetShipmentRepository().Find(spec);

            Assert.AreEqual(1, shipments.Count);


        }

        /// <summary>
        /// Creates the shipment.
        /// </summary>
        /// <param name="shipperLocation">The shipper location.</param>
        /// <param name="packages">The packages.</param>
        /// <param name="shipper">The shipper.</param>
        /// <param name="receiver">The receiver.</param>
        /// <param name="forwarder">The forwarder.</param>
        /// <param name="pickUpRange">The pick up range.</param>
        /// <param name="deliverRange">The deliver range.</param>
        /// <param name="shipmentExposures">The shipment exposures.</param>
        /// <returns></returns>
        private static Shipment CreateShipment(Location shipperLocation, IEnumerable<Package> packages, ChainEntity shipper, ChainEntity receiver, ChainEntity forwarder, IRange<DateTime> pickUpRange, IRange<DateTime> deliverRange, IList<ShipmentExposure> shipmentExposures)
        {
            return new Shipment(shipper, receiver, forwarder, string.Empty, string.Empty, string.Empty, packages,
                                shipperLocation, new Location("2"), pickUpRange, deliverRange, "forwarder@bb.nl",
                                "receiver@cc.nl", shipmentExposures);
        }

        /// <summary>
        /// Gets the shipment exposures.
        /// </summary>
        /// <returns></returns>
        private static IList<ShipmentExposure> GetShipmentExposures()
        {
            double preStartValue = 5;
            double preEndValue = 10;
            double documentedValue = 6;
            IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

            ShipmentExposure shipmentExposure =
                new ShipmentExposure(preStartValue, preEndValue, documentedValue,
                                     new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            shipmentExposures.Add(shipmentExposure);
            return shipmentExposures;
        }

        /// <summary>
        /// Gets the deliver range.
        /// </summary>
        /// <returns></returns>
        private static Range<DateTime> GetDeliverRange()
        {
            DateTime beginDeliverDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endDeliverDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            return new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);
        }

        /// <summary>
        /// Gets the pickup range.
        /// </summary>
        /// <returns></returns>
        private static Range<DateTime> GetPickupRange()
        {
            DateTime beginPickUpDateTime = new DateTime(2008, 1, 1, 12, 12, 12);
            DateTime endPickUpDateTime = new DateTime(2008, 2, 1, 12, 12, 12);
            return new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);
        }

        /// <summary>
        /// Creates the exposures.
        /// </summary>
        /// <param name="exposures1">The exposures1.</param>
        /// <param name="exposures2">The exposures2.</param>
        private static void CreateExposures(out IList<Exposure> exposures1, out IList<Exposure> exposures2)
        {
            MeasuredValue measuredValue1 = new MeasuredValue(5, DateTime.Now);
            MeasuredValue measuredValue2 = new MeasuredValue(5, DateTime.Now);
            IRange<MeasuredValue> prescribedRange1 = new Range<MeasuredValue>(measuredValue1, measuredValue2);
            IList<MeasuredValue> measuredValues1 = new List<MeasuredValue>();

            MeasuredValue measuredValue3 = new MeasuredValue(3, DateTime.Now);
            MeasuredValue measuredValue4 = new MeasuredValue(3, DateTime.Now);
            IRange<MeasuredValue> prescribedRange2 = new Range<MeasuredValue>(measuredValue3, measuredValue4);
            IList<MeasuredValue> measuredValues2 = new List<MeasuredValue>();

            measuredValues1.Add(new MeasuredValue(5, DateTime.Now));
            Exposure exposure = new Exposure(prescribedRange1, measuredValues1, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));
            Exposure exposure2 = new Exposure(prescribedRange2, measuredValues2, new ExposureType("exposureTypeName", new UnitOfMeasurement("uof")));

            exposures1 = new List<Exposure>();
            exposures2 = new List<Exposure>();
            exposures1.Add(exposure);
            exposures2.Add(exposure2);
        }

        /// <summary>
        /// Adds the addresses to chain entities.
        /// </summary>
        /// <param name="shipperAddress">The shipper address.</param>
        /// <param name="forwarderAddress">The forwarder address.</param>
        /// <param name="receiverAddress">The receiver address.</param>
        /// <param name="shipper">The shipper.</param>
        /// <param name="forwarder">The forwarder.</param>
        /// <param name="receiver">The receiver.</param>
        private static void AddAddressesToChainEntities(Address shipperAddress, Address forwarderAddress, Address receiverAddress, out ChainEntity shipper, out ChainEntity forwarder, out ChainEntity receiver)
        {
            shipper = new ChainEntity("Shipper");
            shipper.AddAddress(shipperAddress);

            forwarder = new ChainEntity("Forwarder");
            forwarder.AddAddress(forwarderAddress);

            receiver = new ChainEntity("Receiver");
            receiver.AddAddress(receiverAddress);
        }

        /// <summary>
        /// Adds the locations to location repository.
        /// </summary>
        /// <param name="shipperLocation">The shipper location.</param>
        /// <param name="receiverLocation">The receiver location.</param>
        /// <param name="forwarderLocation">The forwarder location.</param>
        private static void AddLocationsToLocationRepository(Location shipperLocation, Location receiverLocation, Location forwarderLocation)
        {
            IRepository<Location> memoryLocationRepository = new RepositoryFactory().CreateRepository<Location>();
            memoryLocationRepository.Add(shipperLocation);
            memoryLocationRepository.Add(receiverLocation);
            memoryLocationRepository.Add(forwarderLocation);
        }

        /// <summary>
        /// Adds the locations to addresses.
        /// </summary>
        /// <param name="shipperAddress">The shipper address.</param>
        /// <param name="forwarderAddress">The forwarder address.</param>
        /// <param name="forwarderLocation">The forwarder location.</param>
        /// <param name="receiverAddress">The receiver address.</param>
        /// <param name="receiverLocation">The receiver location.</param>
        /// <param name="testAddress">The test address.</param>
        /// <returns></returns>
        private static Location AddLocationsToAddresses(Address shipperAddress, Address forwarderAddress, out Location forwarderLocation, Address receiverAddress, out Location receiverLocation, Address testAddress)
        {
            Location shipperLocation = new Location("20");
            shipperAddress.AddLocation(shipperLocation);

            forwarderLocation = new Location("4");
            forwarderAddress.AddLocation(forwarderLocation);

            receiverLocation = new Location("5");
            receiverAddress.AddLocation(receiverLocation);

            Location testLocation = new Location("6");
            testAddress.AddLocation(testLocation);
            return shipperLocation;
        }

        /// <summary>
        /// Creates the addresses.
        /// </summary>
        /// <param name="forwarderAddress">The forwarder address.</param>
        /// <param name="receiverAddress">The receiver address.</param>
        /// <param name="testAddress">The test address.</param>
        /// <returns></returns>
        private static Address CreateAddresses(out Address forwarderAddress, out Address receiverAddress, out Address testAddress)
        {
            Address shipperAddress =
                new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                            "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                            "zipcode");
            forwarderAddress = new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                                           "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                                           "zipcode");
            receiverAddress = new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                                          "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                                          "zipcode");
            testAddress = new Address(Guid.NewGuid().ToString(), new Country("Holland"), "email", "fax", "numberextension",
                                      "stateprovence", "streetname", "streetnumber", "telephone", new AgriMoreTimeZone("CET"),
                                      "zipcode");
            return shipperAddress;
        }
    }
}