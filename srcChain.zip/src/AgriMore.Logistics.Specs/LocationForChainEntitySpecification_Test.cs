using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class LocationForChainEntitySpecification_Test
    {
        /// <summary>
        /// Locations for chain entity specification.
        /// This test assumes the DataFiller to have run.
        /// </summary>
        [Test]
        public void Can_Get_LocationForChainEntitySpecification()
        {
            ICollection<ChainEntity> chainEntities;
            ChainEntity chainEntity = null;

            chainEntities = new RepositoryFactory().GetChainEntityRepository().AsCollection();

            foreach (ChainEntity entity in chainEntities)
            {
                if (entity.Name == "Plus Supermarket")
                {
                    chainEntity = entity;
                }
            }

            Assert.IsNotNull(chainEntity);
        }

        /// <summary>
        /// Can_s the create_ location for chain entity specification_ with_ null_ argument.
        /// </summary>
        [ExpectedException(typeof(ArgumentNullException))]
        [Test]
        public void Can_Create_LocationForChainEntitySpecification_With_Null_Argument()
        {
            //new LocationForChainEntitySpecification(null);
        }
    }
}