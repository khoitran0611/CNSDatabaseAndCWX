using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// Test the specifications in the system
    /// </summary>
    [TestFixture]
    public class ChainEntiyByLocationSpecification_Test
    {
        /// <summary>
        /// Locations for chain entity specification.
        /// This test assumes the DataFiller to have run.
        /// </summary>
        [Test]
        public void Can_Get_ChainEntiyByLocation()
        {
            ICollection<ChainEntity> chainEntities;
            ChainEntity chainEntity=null;

            chainEntities = new RepositoryFactory().GetChainEntityRepository().AsCollection();

            foreach (ChainEntity entity in chainEntities)
            {
                if(entity.Name=="Plus Supermarket")
                {
                    chainEntity = entity;
                }
            }

            Assert.IsNotNull(chainEntity);
            Location chainEntityLocation = null;

            foreach (Location location in chainEntity.Locations)
            {
                chainEntityLocation = location;
            }

            ISpecification<ChainEntity> specification = new ChainEntiyByLocationSpecification(chainEntityLocation);

            ChainEntity foundChainEntity =
                new RepositoryFactory().GetChainEntityRepository().GetOne(specification);

            Assert.AreEqual(chainEntity.Name, foundChainEntity.Name);
        }

        /// <summary>
        /// Locations for address specification_ null_ argument_ constructor_ test.
        /// </summary>
        [ExpectedException(typeof (ArgumentNullException))]
        [Test]
        public void Can_Create_ChainEntiyByLocationSpecification_With_Null_Argument()
        {
            new ChainEntiyByLocationSpecification(null);
        }
    }
}