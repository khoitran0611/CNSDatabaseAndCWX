using System;
using AgriMore.Logistics.Domain;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class Treat_Product
    {
        #region Setup/Teardown

        /// <summary>
        /// Setup for the tests.
        /// </summary>
        [SetUp]
        public void Setup()
        {
        }

        #endregion

        private const string wash = "Wash";
        private const string name = "name";
        private const string nameCannotBeEmpty = "Name cannot be empty.";
        private const string dry = "Dry";
        private const string uid = "15";
        private const string water = "Water";
        private const string pH = "pH";
        private const string blanks = "  ";


        /// <summary>
        /// Toes the do.
        /// </summary>
        [Test]
        public void Create_Treatment()
        {
            DateTime startDateTimeTreatment = new DateTime(2008, 1, 1, 1, 1, 1);
            DateTime endDateTimeTreatment = new DateTime(2008, 2, 1, 1, 1, 1);

            IRange<DateTime> treatmentDuration = new Range<DateTime>(startDateTimeTreatment, endDateTimeTreatment);

            TreatmentType treatmentType =
                new TreatmentType(water, new TreatmentTypeCategory(wash), new UnitOfMeasurement(pH));

            Treatment treatment = new Treatment(treatmentType, treatmentDuration, 1.1);

            Treatment sameTreatment = new Treatment(treatmentType, treatmentDuration, 1.1);
            Treatment otherTreatment = new Treatment(treatmentType, treatmentDuration, 2.2);

            treatment.Uid = 15;

            Assert.AreEqual(15, treatment.Uid);
            Assert.AreEqual(uid, treatment.ToString());
            Assert.AreEqual(water, treatment.Name);
            Assert.AreEqual(treatmentDuration.Start, treatment.Duration.Start);
            Assert.AreEqual(treatmentDuration.End, treatment.Duration.End);
            Assert.AreEqual(1.1, treatment.Value);
            Assert.AreEqual(treatmentType, treatment.TreatmentType);

            try
            {
                new Treatment(null, treatmentDuration, 1.1);
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("treatmentType", e.ParamName);
            }

            try
            {
                new Treatment(treatmentType, null, 1.1);
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("duration", e.ParamName);
            }

            treatment.Uid = 0;
            Assert.IsFalse(treatment.Equals(null));
            Assert.IsFalse(treatment.Equals(otherTreatment));
            Assert.IsFalse(treatment.Equals(sameTreatment));
            Assert.IsTrue(treatment.Equals(treatment));
        }

        /// <summary>
        /// Create_s the type of the treatment.
        /// </summary>
        [Test]
        public void Create_TreatmentType()
        {
            TreatmentType treatmentType =
                new TreatmentType(water, new TreatmentTypeCategory(wash), new UnitOfMeasurement(pH));
            TreatmentType otherTreatmentType =
                new TreatmentType("nonexisting", new TreatmentTypeCategory(wash), new UnitOfMeasurement(pH));

            treatmentType.Uid = 15;
            Assert.AreEqual(uid, treatmentType.ToString());
            Assert.AreEqual(15, treatmentType.Uid);
            Assert.IsNotNull(treatmentType);
            Assert.AreEqual(water, treatmentType.Name);
            Assert.AreEqual(new TreatmentTypeCategory(wash), treatmentType.TreatmentTypeCategory);
            Assert.AreEqual(new UnitOfMeasurement(pH), treatmentType.UnitOfMeasurement);

            Assert.IsFalse(treatmentType.Equals(null));
            Assert.IsFalse(treatmentType.Equals(otherTreatmentType));
            Assert.IsTrue(
                treatmentType.Equals(
                    new TreatmentType(water, new TreatmentTypeCategory(wash), new UnitOfMeasurement(pH))));

            try
            {
                new TreatmentType(null, new TreatmentTypeCategory(wash), new UnitOfMeasurement(pH));
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual(name, e.ParamName);
            }

            try
            {
                new TreatmentType(blanks, new TreatmentTypeCategory(wash), new UnitOfMeasurement(pH));
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual(nameCannotBeEmpty, e.Message);
            }

            try
            {
                new TreatmentType(water, null, new UnitOfMeasurement(pH));
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("treatmentTypeCategory", e.ParamName);
            }

            try
            {
                new TreatmentType(water, new TreatmentTypeCategory(wash), null);
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual("unitOfMeasurement", e.ParamName);
            }
        }

        /// <summary>
        /// <scenario>
        ///    <no></no>
        /// 	<given></given>
        /// 	<ensure></ensure>
        /// </scenario>
        /// </summary>
        [Test]
        public void Create_TreatmentType_Category()
        {
            TreatmentTypeCategory treatmentTypeCategory = new TreatmentTypeCategory(wash);

            Assert.AreEqual(wash, treatmentTypeCategory.Name);
            Assert.AreEqual(wash.GetHashCode(), treatmentTypeCategory.GetHashCode());

            treatmentTypeCategory.Uid = 15;
            Assert.AreEqual(15, treatmentTypeCategory.Uid);
            Assert.AreEqual(uid, treatmentTypeCategory.ToString());

            Assert.IsFalse(treatmentTypeCategory.Equals(null));
            Assert.IsFalse(treatmentTypeCategory.Equals(new TreatmentTypeCategory(dry)));
            Assert.IsTrue(treatmentTypeCategory.Equals(new TreatmentTypeCategory(wash)));

            try
            {
                new TreatmentTypeCategory(null);
            }
            catch (ArgumentNullException e)
            {
                Assert.AreEqual(name, e.ParamName);
            }

            try
            {
                new TreatmentTypeCategory(blanks);
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual(nameCannotBeEmpty, e.Message);
            }
        }


        /// <summary>
        /// Technical_s the test_ treatment type category_ get_ treamnet types.
        /// </summary>
        [Test]
        public void Technical_Test_TreatmentTypeCategory_Get_TreatmentTypes()
        {
            TreatmentTypeCategory treatmentTypeCategory = new TreatmentTypeCategory(wash);

            TreatmentType treatmentType =
                new TreatmentType(water, new TreatmentTypeCategory(wash), new UnitOfMeasurement(pH));

            treatmentTypeCategory.AddTreatmentType(treatmentType);

            foreach (TreatmentType type in treatmentTypeCategory.TreatmentTypes)
            {
                Assert.AreEqual(water, type.Name);
            }
        }
    }
}