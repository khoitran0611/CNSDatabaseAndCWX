using System.Text.RegularExpressions;
using NUnit.Framework;

namespace AgriMore.Logistics.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class DoubleRegexTest
    {
        /// <summary>
        /// 
        /// </summary>               
        [Test]
        public void Can_Create_Double()
        {
            string stringNumber1 = "1.1";
            string stringNumber2 = "1,1";
            string stringNumber3 = "1";
            string stringNumber4 = "1.";
            string stringNumber5 = "1.1.1";
            string stringNumber6 = "1.0";
            string stringNumber7 = "1.00";
            string stringNumber8 = "1.001";
            string stringNumber9 = "+1.001";
            string stringNumber10 = "-1.001";
            string stringNumber11 = "test";
            string stringNumber12 = "0,1";
            string stringNumber13 = "1.1.1";
            string stringNumber14 = "1.1,1";

            string strRegex = @"^[-+]?\d+(\.\d+)?$";

            Assert.IsTrue(new Regex(strRegex).IsMatch(stringNumber1));
            Assert.IsFalse(new Regex(strRegex).IsMatch(stringNumber2));
            Assert.IsTrue(new Regex(strRegex).IsMatch(stringNumber3));
            Assert.IsFalse(new Regex(strRegex).IsMatch(stringNumber4));
            Assert.IsFalse(new Regex(strRegex).IsMatch(stringNumber5));
            Assert.IsTrue(new Regex(strRegex).IsMatch(stringNumber6));
            Assert.IsTrue(new Regex(strRegex).IsMatch(stringNumber7));
            Assert.IsTrue(new Regex(strRegex).IsMatch(stringNumber8));
            Assert.IsTrue(new Regex(strRegex).IsMatch(stringNumber9));
            Assert.IsTrue(new Regex(strRegex).IsMatch(stringNumber10));
            Assert.IsFalse(new Regex(strRegex).IsMatch(stringNumber11));
            Assert.IsFalse(new Regex(strRegex).IsMatch(stringNumber12));
            Assert.IsFalse(new Regex(strRegex).IsMatch(stringNumber13));
            Assert.IsFalse(new Regex(strRegex).IsMatch(stringNumber14));
        }
    }
}