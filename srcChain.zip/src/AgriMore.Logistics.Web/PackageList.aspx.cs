using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Repository.Memory;
using AgriMore.Logistics.Domain.Specification;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PackageList : Page
    {
        private const string packageRepository = "MemoryPackageRepository";
        private const string urlPackageDetail = "PackPrimaryProduct.aspx";


        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            IChainEntity chainEntity = ChainEntityHelper.GetChainEntityThroughUser(User);
            GridViewLocationsChainEntity.DataSource = chainEntity.Locations;
            GridViewLocationsChainEntity.DataKeyNames = new string[] {"Uid"};
            GridViewLocationsChainEntity.DataBind();
        }

        /// <summary>
        /// Gets the package repository from session.
        /// </summary>
        /// <returns></returns>
        private IRepository<Package> GetPackagesForEntity()
        {
            IRepository<Package> repository = GetPackagesFromSession();

            if (repository == null)
            {
                repository = new MemoryPackageRepository();

                RepositoryFactory repositoryFactory = new RepositoryFactory();

                IChainEntity chainEntity = ChainEntityHelper.GetChainEntityThroughUser(User);

                IList<Location> filteredLocs = new List<Location>();
                IList<Package> filteredPacks = new List<Package>();

                IEnumerable<Package> packages = repositoryFactory.GetPackageRepository();

                // Get locations for ChainEntity
                foreach (Location location in repositoryFactory.GetLocationRepository())
                {
                    if (chainEntity.Contains(location))
                    {
                        filteredLocs.Add(location);
                        foreach (Package package in packages)
                        {
                            if (location.Contains(package))
                            {
                                filteredPacks.Add(package);
                                repository.Add(package);
                            }
                        }
                    }
                }

                Session.Add(packageRepository, repository);
            }

            return repository;
        }

        /// <summary>
        /// Gets the packages from session.
        /// </summary>
        /// <returns></returns>
        private IRepository<Package> GetPackagesFromSession()
        {
            return Session[packageRepository] as MemoryPackageRepository;
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonAddNew control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonAddNew_Click(object sender, EventArgs e)
        {
            Response.Redirect(urlPackageDetail);
        }

        /// <summary>
        /// Handles the ObjectCreating event of the ObjectDataSource1 control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.ObjectDataSourceEventArgs"/> instance containing the event data.</param>
        protected void ObjectDataSource1_ObjectCreating(object sender, ObjectDataSourceEventArgs e)
        {
            e.ObjectInstance = GetPackagesForEntity();
        }

        /// <summary>
        /// Handles the RowCommand event of the GridViewLocationsChainEntity control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewCommandEventArgs"/> instance containing the event data.</param>
        protected void GridViewLocationsChainEntity_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName.ToLower().Equals("selectlocation"))
            {
                int index = Convert.ToInt32(e.CommandArgument);
                int locationId = Convert.ToInt32(GridViewLocationsChainEntity.DataKeys[index].Value);
                RepositoryFactory repositoryFactory = new RepositoryFactory();

                Location location = repositoryFactory.GetLocationRepository().GetOne(locationId);

                ICollection<Package> packagesInLocation =
                    repositoryFactory.GetPackageRepository().Find(new PackageInLocationSpecificationAndPackedOnce(location));

                GridViewPackagesInLocation.DataSource = packagesInLocation;
                GridViewPackagesInLocation.DataKeyNames = new string[] {"Uid"};
                GridViewPackagesInLocation.DataBind();
            }
        }

        /// <summary>
        /// Handles the RowCommand event of the GridViewPackagesInLocation control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewCommandEventArgs"/> instance containing the event data.</param>
        protected void GridViewPackagesInLocation_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName.ToLower().Equals("selectpackage"))
            {
                int index = Convert.ToInt32(e.CommandArgument);
                int packageId = Convert.ToInt32(GridViewPackagesInLocation.DataKeys[index].Value);

                Session.Add("packageid", packageId.ToString());

                Response.Redirect(urlPackageDetail);
            }
        }
    }
}