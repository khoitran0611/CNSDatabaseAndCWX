using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using log4net;
using System.Linq;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using AgriMore.Logistics.Data.Services;
using System.Text;
using System.Globalization;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PackSemiFinishedProductDetail : BasePage
    {
        private const string blank = " ";
        private const string dataTextFieldName = "Name";
        private string invalidinputtext = Resources.Localization.Thereisaninvaliditem;
        private const string locationid = "locationid";
        private string novalidaction = Resources.Localization.Novalidactionfromthemenu;
        private const string packageid = "packageid";
        private const string packsfp = "packsfp";
        private const string packsfpnotinlocation = "packsfpnotinlocation";
        private string packsfpnotinlocationTitle = Resources.Localization.Packsemifinishedproductnotinlocation;
        private string packsfpTitle = Resources.Localization.Packsemifinishedproduct;
        private string receivers = Resources.Localization.LabelReceiver;
        private const string repacksfp = "repacksfp";
        private string repacksfpTitle = Resources.Localization.PackSFPfrombulk;
        private const string retailpackaging = "retailPackaging";
        private const string space = " ";
        private const string uid = "Uid";
        private const string urlDefault = "Default.aspx";
        private const long wholesalePackage = 1;
        private const string referenceIdentification = "referenceIdentification";

        private readonly List<Package> packagesToRepack = new List<Package>();
        private readonly List<Package> packagesToCreate = new List<Package>();

        private readonly ILog log = LogManager.GetLogger(typeof(PackSemiFinishedProductDetail));

        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        private ChainEntity chainEntityForCurrentUser;
        private ChainEntity GetChainEntityForCurrentUser()
        {
            if (chainEntityForCurrentUser == null)
            {
                chainEntityForCurrentUser = RepositoryHelper.GetChainEntityForCurrentUser();
            }
            return chainEntityForCurrentUser;
        }

        private User currentUser;
        private User GetCurrentUser()
        {
            if (currentUser == null)
            {
                currentUser = RepositoryHelper.GetCurrentUser();
            }
            return currentUser;
        }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            ErrorHelper.SetErrorLabel(false, string.Empty, LabelError, false);

            try
            {
                if (!IsPostBack)
                {
                    hdfCurrentOrgId.Value = RepositoryHelper.GetChainEntityForCurrentUser().Uid.ToString();
                    SetInitialPageValues();
                    BindDataFor3rdPartyDropdown();
                    RouteLoadAction(GetQueryString());
                }

                //show hide the messages if no package found   
                if (ListBoxPackages.Items.Count <= 0)
                {
                    lblNoPackageFoundMessage.Visible = true;

                }
                else
                {
                    lblNoPackageFoundMessage.Visible = false;
                }

            }
            catch (Exception e1)
            {
                ErrorHelper.SetErrorLabel(true, e1.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Adds the receiver identifications.
        /// </summary>
        /// <returns></returns>
        private bool AddReceiverIdentifications()
        {
            return DropDownListReceivers.Visible && TextBoxReceiverIdFrom.Text.Trim().Length > 0;
        }

        /// <summary>
        /// Validates the receiver identifications.
        /// </summary>
        /// <param name="from">From.</param>
        /// <param name="to">To.</param>
        /// <param name="receiver">The receiver.</param>
        private void ValidateReceiverIdentifications(long from, long to, ChainEntity receiver)
        {
            long receiverFrom;
            long receiverTo;

            bool fromIsNumeric = Int64.TryParse(TextBoxReceiverIdFrom.Text, out receiverFrom);
            bool toIsNumeric = Int64.TryParse(TextBoxReceiverIdTo.Text, out receiverTo);

            if (fromIsNumeric == false)
            {
                throw new ArgumentException(Resources.Localization.Thefromidentificationisnotnumeric);
            }

            if (TextBoxReceiverIdTo.Text == string.Empty)
            {
                receiverTo = receiverFrom;
            }
            else
            {
                if (toIsNumeric == false)
                {
                    throw new ArgumentException(Resources.Localization.Thetoidentificationisnotnumeric);
                }
            }

            if (TextBoxReceiverIdTo.Text == string.Empty)
            {
                receiverTo = receiverFrom;
            }

            if (receiverFrom > receiverTo)
            {
                throw new ArgumentException(Resources.Localization.Thefromidcannotbegreaterthanthetoidentification);
            }

            if (to - from != receiverTo - receiverFrom)
            {
                throw new ArgumentException(Resources.Localization.Thenumberofidentificationsarenotequal);
            }

            if (receiverFrom < 0 || receiverTo < 0)
            {
                throw new ArgumentException(Resources.Localization.Identificationscannotbenegative);
            }

            ValidateIdentificationsExistance(receiverFrom, receiverTo, receiver);

        }

        /// <summary>
        /// Routes the action.
        /// </summary>
        private void RouteLoadAction(string userAction)
        {
            if (userAction != null)
            {
                if (userAction == packsfp)
                {
                    BindReceivers();
                    LabelTitle.ForeColor = Color.White;
                    LabelTitle.Text = packsfpTitle;
                    PackSemiFinishedProductAction(GetLocationIdFromSession());
                }
                else if (userAction == packsfpnotinlocation)
                {
                    BindReceivers();
                    LabelTitle.ForeColor = Color.White;
                    LabelTitle.Text = packsfpnotinlocationTitle;
                    PackSemiFinishedProductNotInLocationAction();
                }
                else if (userAction == repacksfp)
                {
                    LabelTitle.ForeColor = Color.White;
                    LabelTitle.Text = repacksfpTitle;
                    RepackSemiFinishedProductAction(GetLocationIdFromSession());
                    BindReceivers();
                    HandleDropdownPackageTypeChange();
                }
                else
                {
                    throw new ArgumentException(novalidaction);
                }
            }
        }

        /// <summary>
        /// Stores the repack relationship.
        /// </summary>
        private void StoreRepackRelationship()
        {
            RepositoryFactory rf = new RepositoryFactory();
            IRepository<RepackPackageRelationship> repository = rf.GetRepackPackageRelationshipRepository();

            List<RepackPackageRelationship> relationship = new List<RepackPackageRelationship>();

            foreach (Package newPackageFromRepack in packagesToCreate)
            {
                foreach (Package repackedPackage in packagesToRepack)
                {
                    relationship.Add(new RepackPackageRelationship(repackedPackage.Uid, newPackageFromRepack.Uid));
                }
            }

            foreach (RepackPackageRelationship packageRelationship in relationship)
            {
                repository.Store(packageRelationship);
            }
        }

        /// <summary>
        /// Gets the location id from session.
        /// </summary>
        /// <returns></returns>
        private long GetLocationIdFromSession()
        {
            string locIdFromSession = Session[locationid] as string;
            if (locIdFromSession != null)
            {
                return long.Parse(locIdFromSession);
            }

            return 0; 
        }

        /// <summary>
        /// Repacks the semi finished product action.
        /// </summary>
        /// <param name="locId">The loc id.</param>
        private void RepackSemiFinishedProductAction(long locId)
        {
            SetRangeControls(true);
            List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];
            PackagingDefine packageType = null;
            if (packageTypes.Any())
            {
                packageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
            }

            SetReceiverIdentificationControls(packageType.PackTypeCategory.Uid == 2 || packageType.PackTypeCategory.Uid == 3 || packageType.PackTypeCategory.Uid == 1 || packageType.PackTypeCategory.Uid == 4); //retailPackaging or Consumer

            Location location = repositoryFactory.GetLocationRepository().GetOne(locId);

            List<Package> packagesOnlyPackedOnce = new List<Package>();
            // Get all packages only packed once.
            foreach (Package p in location.Packages)
            {
                List<Package> childPackages = new List<Package>(p.Children);
                //if (childPackages.Count == 0 &&
                //    p.PackageType.PackageTypeCategory == PackageTypeCategory.wholesalePackaging)
                if (childPackages.Count == 0)
                {
                    packagesOnlyPackedOnce.Add(p);
                }
            }

            BindPackagesOnlyPackedOnceToList(packagesOnlyPackedOnce);
        }

        /// <summary>
        /// Packs the primary product action.
        /// </summary>
        private void PackSemiFinishedProductNotInLocationAction()
        {
            SetRangeControls(true);
            List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];
            PackagingDefine packageType = null;
            if (packageTypes.Any())
            {
                packageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
            }

            SetReceiverIdentificationControls(packageType.PackTypeCategory.Uid == 2 || packageType.PackTypeCategory.Uid == 3 || packageType.PackTypeCategory.Uid == 1 || packageType.PackTypeCategory.Uid == 4); //retailPackaging or Consumer


            ExposuresControl.Visible = false;           

            BindPackagesWithNoLocation();
        }

        /// <summary>
        /// Packs the semi finished product action.
        /// </summary>
        /// <param name="locId">The loc id.</param>
        private void PackSemiFinishedProductAction(long locId)
        {
            ExposuresControl.Visible = true;

            SetRangeControls(false);

            BindPackagesWithSpecificLocation(locId);
        }

        /// <summary>
        /// Binds the packages only packed once to list.
        /// </summary>
        /// <param name="packagesOnlyPackedOnce">The packages only packed once.</param>
        private void BindPackagesOnlyPackedOnceToList(IEnumerable<Package> packagesOnlyPackedOnce)
        {

            ListBoxPackages.Items.Clear();
            
            ChainEntity chainEntity = GetChainEntityForCurrentUser();

            foreach (Package package in packagesOnlyPackedOnce)
            {
                string name = RepositoryHelper.CreatePackageName(package, chainEntity);
                var numPack = ((package.ToUid - package.FromUid) + 1).ToString();
                var listItem = new ListItem(name, package.Uid.ToString());
                listItem.Attributes.Add("data-npackage", numPack);
                ListBoxPackages.Items.Add(listItem);
            }
        }

        /// <summary>
        /// Sets the initial values.
        /// </summary>
        private void SetInitialPageValues()
        {
            LabelError.Visible = false;
            DateTimeControlPacking.SetStartDateTime(DateTime.Now);

            BindPackageTypes();

            //SetPackageTypeInfo();
        }

        /// <summary>
        /// Binds the package types.
        /// </summary>
        private void BindPackageTypes()
        {
            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

            var currentUser = RepositoryHelper.GetCurrentUser();
            IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(currentUser.UsingLang, 0, 0, chainEntity.Uid);

            Session["packageTypes"] = packageTypes;
            DropDownListPackageType.DataSource = packageTypes; //repositoryFactory.GetPackageTypeRepository();            
            DropDownListPackageType.DataTextField = dataTextFieldName;
            DropDownListPackageType.DataValueField = uid;
            DropDownListPackageType.DataBind();

            FillDataForSelectedPackageTypes();
        }

        /// <summary>
        /// Binds the data.
        /// </summary>
        private void BindPackagesWithNoLocation()
        {
            ChainEntity chainEntity = GetChainEntityForCurrentUser();

            ICollection<Package> packages = GetPackagesWithNoLocation();
            ListBoxPackages.Items.Clear();
            foreach (Package package in packages)
            {
                string name = RepositoryHelper.CreatePackageName(package, chainEntity);
                var numPack = ((package.ToUid - package.FromUid) + 1).ToString();
                var listItem = new ListItem(name, package.Uid.ToString());
                listItem.Attributes.Add("data-npackage", numPack);
                ListBoxPackages.Items.Add(listItem);
            }
        }

        /// <summary>
        /// Binds the data.
        /// </summary>
        private void BindPackagesWithSpecificLocation(long locationId)
        {
            SetRangeControls(true);
            List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];
            PackagingDefine packageType = null;
            if (packageTypes.Any())
            {
                packageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
            }

            SetReceiverIdentificationControls(packageType.PackTypeCategory.Uid == 2 || packageType.PackTypeCategory.Uid == 3 || packageType.PackTypeCategory.Uid == 1 || packageType.PackTypeCategory.Uid == 4); //retailPackaging or Consumer

            Location location = repositoryFactory.GetLocationRepository().GetOne(locationId);

            ICollection<Package> packages =
                repositoryFactory.GetPackageRepository().Find(new PackageInLocationSpecification(location));            

            ChainEntity chainEntity = GetChainEntityForCurrentUser();

            ListBoxPackages.Items.Clear();
            foreach (Package package in packages)
            {
                string name = RepositoryHelper.CreatePackageName(package, chainEntity);
                var numPack = ((package.ToUid - package.FromUid) + 1).ToString();
                var listItem = new ListItem(name, package.Uid.ToString());
                listItem.Attributes.Add("data-npackage", numPack);
                ListBoxPackages.Items.Add(listItem);
            }            
        }

        /// <summary>
        /// Gets the packages with no location.
        /// </summary>
        /// <returns></returns>
        private ICollection<Package> GetPackagesWithNoLocation()
        {
            ChainEntity chainEntity = ChainEntityHelper.GetChainEntityThroughUser(User);
            ICollection<Package> packagesOfChainEntityNotinLocation =
                repositoryFactory.GetPackageRepository().Find(
                    new PackageNotInLocationAndKleinVerpakkingForChainEntity(chainEntity));

            return packagesOfChainEntityNotinLocation;
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonCancel_Click(object sender, EventArgs e)
        {
            try
            {
                Session.Remove(locationid);
                Response.Redirect(urlDefault, false);
            }
            catch (Exception e1)
            {
                ErrorHelper.SetErrorLabel(true, e1.ToString(), LabelError, true);
            }
        }


        /// <summary>
        /// Handles the Click event of the LinkButtonOK control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonOK_Click(object sender, EventArgs e)
        {

            try
            {
                if (Page.IsValid)
                {
                    //if ((Int32.Parse(TextBoxTo.Text) - Int32.Parse(TextBoxPackageIdentification.Text)) != (TextBoxReceiverIdTo.Text.Trim() != string.Empty ? Int32.Parse(TextBoxReceiverIdTo.Text) : 0
                    //    - (TextBoxReceiverIdFrom.Text.Trim() != string.Empty ? Int32.Parse(TextBoxReceiverIdFrom.Text) : 0)))
                    //{
                    //    throw new ArgumentException(Resources.Localization.Thenumberofidentificationsarenotequal);
                    //}

                    TransactionManager transactionManager = new TransactionManager();

                    Package newPackage = null;
                    List<Package> newPackages = new List<Package>();

                    ClearErrorLabel();

                    IRepository<Package> packageRepository = repositoryFactory.GetPackageRepository();

                    if (TextBoxTo.Visible)
                    {
                        try
                        {
                            transactionManager.BeginTransaction();
                            newPackage = Pack(newPackage);
                            packageRepository.Store(newPackage);

                            packageRepository.Flush();

                            CreateProcessingStep(newPackage, newPackage.CurrentExposureDocument, GetDateTimeOfPacking());
                            StoreRepackRelationship();

                            //Update the package to Matching to use in Package invoice
                            updataDataForPackagingInvoiceInMatching(newPackage);
                            transactionManager.CommitTransaction();
                        }
                        catch (Exception exception)
                        {
                            Session.Remove(referenceIdentification);
                            ErrorHelper.HandleException(exception, transactionManager, LabelError);
                            return;
                        }
                    }
                    else
                    {
                        try
                        {
                            transactionManager.BeginTransaction();
                            Repack(newPackages);
                            
                            packageRepository.Flush();

                            DateTime dateTimeOfPacking = GetDateTimeOfPacking();
                            foreach (Package package in newPackages)
                            {
                                CreateProcessingStep(package, package.CurrentExposureDocument, dateTimeOfPacking);
                                //Update the package to Matching to use in Package invoice
                                updataDataForPackagingInvoiceInMatching(package);
                            }
                            StoreRepackRelationship();                            

                            transactionManager.CommitTransaction();
                        }
                        catch (Exception exception)
                        {
                            Session.Remove(referenceIdentification);
                            ErrorHelper.HandleException(exception, transactionManager, LabelError);
                            return;
                        }
                    }

                    Session.Remove(packageid);
                    Session.Remove(referenceIdentification);
                    Response.Redirect(urlDefault, false);
                }
            }

            catch (ArgumentNullException exception)
            {
                LabelError.Text = exception.Message;
            }
            catch (ArgumentException exception)
            {
                LabelError.Visible = true;
                LabelError.Text = invalidinputtext + blank + exception.Message;
            }
            catch (Exception exception)
            {
                LabelError.Visible = true;
                LabelError.Text = invalidinputtext + blank + exception.Message;
            }
        }

        /// <summary>
        /// Repacks the specified new packages.
        /// </summary>
        /// <param name="newPackages">The new packages.</param>
        private void Repack(ICollection<Package> newPackages)
        {
            int numberOfSelectedPackages = 0;

            if (ListBoxPackages.Items.Count == 0)
            {
                throw new ArgumentException(Resources.Localization.Therearenopackagesavailable);
            }

            foreach (ListItem item in ListBoxPackages.Items)
            {
                if (item.Selected)
                {
                    numberOfSelectedPackages++;
                }
            }

            if (numberOfSelectedPackages == 0)
            {
                throw new ArgumentException(Resources.Localization.Therearenopackagesselected);
            }

            DateTime dateTimeOfPacking = GetDateTimeOfPacking();
            Location currentLocation = GetLocation();
            ChainEntity chainEntity = GetChainEntity();
            long packageIdentificationFrom = GetPackageIdentification(TextBoxPackageIdentification);
            long packageIdentificationTo = GetPackageIdentification(TextBoxTo);
            List<Package> packagesToBeRepacked = new List<Package>();
            List<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();

            ValidateIdentifications(chainEntity);

            long fromNumeric;
            ChainEntity receiver;
            GetRepackReceiverInfo(packageIdentificationFrom, packageIdentificationTo, out fromNumeric, out receiver);

            RemovePackagesToBeRepackedFromLocation(packagesToBeRepacked, currentLocation, primaryProducts);

            CreateNewPackages(packageIdentificationFrom, packageIdentificationTo, primaryProducts, chainEntity,
                              newPackages, dateTimeOfPacking, fromNumeric, receiver);

            PutNewPackagesInLocation(currentLocation, newPackages);

            repositoryFactory.GetLocationRepository().Store(currentLocation);
        }

        /// <summary>
        /// Puts the new packages in location.
        /// </summary>
        /// <param name="currentLocation">The current location.</param>
        /// <param name="newPackages">The new packages.</param>
        private void PutNewPackagesInLocation(Location currentLocation, IEnumerable<Package> newPackages)
        {
            foreach (Package package in newPackages)
            {
                PutNewlyFormedPackageInLocation(package, currentLocation);
            }
        }

        /// <summary>
        /// Creates the new packages.
        /// </summary>
        /// <param name="packageIdentificationFrom">The package identification from.</param>
        /// <param name="packageIdentificationTo">The package identification to.</param>
        /// <param name="primaryProducts">The primary products.</param>
        /// <param name="chainEntity">The chain entity.</param>
        /// <param name="newPackages">The new packages.</param>
        /// <param name="dateTimeOfPacking">The date time of packing.</param>
        /// <param name="receiverFromIdentification">The receiver from identification.</param>
        /// <param name="receiver">The receiver.</param>
        private void CreateNewPackages(long packageIdentificationFrom, long packageIdentificationTo,
                                       IEnumerable<PrimaryProduct> primaryProducts, ChainEntity chainEntity,
                                       ICollection<Package> newPackages, DateTime dateTimeOfPacking,
                                       long receiverFromIdentification,
                                       ChainEntity receiver)
        {
            //for (int fromId = packageIdentificationFrom; fromId <= packageIdentificationTo; fromId++)
            //{
            //    List<Identification> packageIdentifications = GetPackageIdentifications(fromId, chainEntity);

            //    if (AddReceiverIdentifications())
            //    {
            //        ICollection<Identification> receiverPackageIdentifications =
            //            GetPackageIdentifications(receiverFromIdentification, receiver);
            //        packageIdentifications.AddRange(receiverPackageIdentifications);
            //        receiverFromIdentification++;
            //    }

            //    newPackages.Add(
            //        new Package(GetSelectedPackageType(), primaryProducts, dateTimeOfPacking,
            //                    packageIdentifications,
            //                    TextBoxArticleCode.Text));
            //}
        }

        /// <summary>
        /// Binds the receivers.
        /// </summary>
        private void BindReceivers()
        {
            Role receiverRole = repositoryFactory.GetRoleRepository().GetOne(receivers);

            DropDownListReceivers.DataSource =
                repositoryFactory.GetChainEntityRepository().Find(new ChainEntiyByRoleSpecification(receiverRole));
            DropDownListReceivers.DataTextField = dataTextFieldName;
            DropDownListReceivers.DataValueField = uid;
            DropDownListReceivers.DataBind();
        }

        /// <summary>
        /// Removes the packages to be repacked from location.
        /// </summary>
        /// <param name="packagesToBeRepacked">The packages to be repacked.</param>
        /// <param name="currentLocation">The current location.</param>
        /// <param name="primaryProducts">The primary products.</param>
        private void RemovePackagesToBeRepackedFromLocation(ICollection<Package> packagesToBeRepacked,
                                                            Location currentLocation,
                                                            ICollection<PrimaryProduct> primaryProducts)
        {
            foreach (ListItem item in ListBoxPackages.Items)
            {
                if (item.Selected)
                {
                    Package selectedPackage = GetSelectedPackage(repositoryFactory, item);

                    selectedPackage.Repack(GetDateTimeOfPacking());

                    packagesToBeRepacked.Add(selectedPackage);

                    currentLocation.Remove(selectedPackage, GetDateTimeOfPacking());

                    foreach (PrimaryProduct primaryProduct in selectedPackage.PrimaryProducts)
                    {
                        if (primaryProducts.Contains(primaryProduct) == false)
                        {
                            primaryProducts.Add(primaryProduct);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Gets the repack receiver info.
        /// </summary>
        /// <param name="packageIdentificationFrom">The package identification from.</param>
        /// <param name="packageIdentificationTo">The package identification to.</param>
        /// <param name="fromNumeric">From numeric.</param>
        /// <param name="receiver">The receiver.</param>
        private void GetRepackReceiverInfo(long packageIdentificationFrom, long packageIdentificationTo,
                                           out long fromNumeric, out ChainEntity receiver)
        {
            fromNumeric = 0;
            receiver = null;

            if (AddReceiverIdentifications())
            {
                ValidateReceiverIdentifications(packageIdentificationFrom, packageIdentificationTo, receiver);

                fromNumeric = Int64.Parse(TextBoxReceiverIdFrom.Text);
                receiver =
                    repositoryFactory.GetChainEntityRepository().GetOne(
                        long.Parse(DropDownListReceivers.SelectedValue));
            }
        }

        /// <summary>
        /// Packs the specified new package.
        /// </summary>
        /// <param name="newPackage">The new package.</param>
        /// <returns></returns>
        private Package Pack(Package newPackage)
        {
            int numberOfSelectedPackages=0;

            if (ListBoxPackages.Items.Count==0)
            {
                throw new ArgumentException(Resources.Localization.Therearenopackagesselected);
            }

            foreach (ListItem item in ListBoxPackages.Items)
            {
                if (item.Selected)
                {
                    numberOfSelectedPackages++;
                }
            }

            if(numberOfSelectedPackages==0)
            {
                throw new ArgumentException(Resources.Localization.Therearenopackagesselected);
            }

            long packageIdentification = GetPackageIdentification(TextBoxPackageIdentification);
            ChainEntity chainEntity = GetChainEntity();
            //Refactor
            //PackageType packageType = GetSelectedPackageType();
            PackagingDefine packageType = GetSelectedPackageType();
            DateTime dateTimeOfPacking = GetDateTimeOfPacking();
            ICollection<Identification> packageIdentifications =
                GetPackageIdentifications(packageIdentification, chainEntity, GetPackageIdentification(TextBoxTo));

            Location location = GetLocation();

            bool first = false;

            newPackage =
                PackSelectedPackages(first, packageType, dateTimeOfPacking,
                                     packageIdentifications, newPackage, location);

            PutNewlyFormedPackageInLocation(newPackage, location);

            if (location != null)
            {
                repositoryFactory.GetLocationRepository().Store(location);
            }

            return newPackage;
        }

        /// <summary>
        /// Gets the selected package.
        /// </summary>
        /// <param name="repositoryFactory">The repository factory.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        private static Package GetSelectedPackage(RepositoryFactory repositoryFactory, ListItem item)
        {
            Package selectedPackage;
            selectedPackage = repositoryFactory.GetPackageRepository().GetOne(long.Parse(item.Value));
            return selectedPackage;
        }

        /// <summary>
        /// Gets the location.
        /// </summary>
        /// <returns></returns>
        private Location GetLocation()
        {
            Location location = null;

            if (ExposuresControl.Visible)
            {
                location = repositoryFactory.GetLocationRepository().GetOne(GetLocationId());
                location.RemoveFromlocation += location_RemoveFromlocation;
            }

            return location;
        }


        /// <summary>
        /// Handles the RemoveFromlocation event of the location control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="AgriMore.Logistics.Domain.LocationEventArgs"/> instance containing the event data.</param>
        private void location_RemoveFromlocation(object sender, LocationEventArgs e)
        {
            string userAction = GetQueryString();

            if (userAction != null)
            {
                if (userAction == repacksfp)
                {
                    packagesToRepack.Add(e.Package);
                }
            }
            if (e.ExposureDocument.Uid == 0)
            {
                try
                {
                    repositoryFactory.GetPackageRepository().Store(e.Package);
                }
                catch (Exception exception)
                {
                    log.Debug(exception.ToString());
                }
            }
        }

        private void CreateProcessingStep(Package package, ExposureDocument exposureDocument, DateTime dateOfPlacement)
        {
            string userAction = GetQueryString();
            string remark = String.Empty;

            try
            {
                if (userAction != null)
                {
                    if (userAction == repacksfp)
                    {
                        packagesToCreate.Add(package);
                        remark = ProcessingStepDocument.RepackSfp;
                    }
                    else if (userAction == packsfp)
                    {
                        remark =
                            String.Format(ProcessingStepDocument.PackSfp,
                                          dateOfPlacement.ToString(ProcessingStepDocument.DateTimeFormat),
                                          package.IdentificationForChainEntity(
                                              GetChainEntityForCurrentUser()),
                                          package.PackageTypeName);
                    }
                }

                RepositoryHelper.CreateProcessingSteps(package, exposureDocument, ProcessingStepType.Exposures, GetCurrentUser(),
                                                       remark);

            }
            catch(Exception exception)
            {
                log.Debug(exception.ToString());
            }
        }

        /// <summary>
        /// Gets the date time of packing.
        /// </summary>
        /// <returns></returns>
        private DateTime GetDateTimeOfPacking()
        {
            return DateTimeControlPacking.GetDatetime();
        }

        /// <summary>
        /// Gets the package identification.
        /// </summary>
        /// <param name="textBox">The text box.</param>
        /// <returns></returns>
        private static long GetPackageIdentification(ITextControl textBox)
        {
            long packageIdentification;

            bool fromIsNumeric = Int64.TryParse(textBox.Text, out packageIdentification);

            if (!fromIsNumeric)
            {
                throw new ArgumentException(Resources.Localization.Theidentificationisnotnumeric);
            }
            return packageIdentification;
        }

        /// <summary>
        /// Packs the selected packages.
        /// </summary>
        /// <param name="first">if set to <c>true</c> [first].</param>
        /// <param name="packageType">Type of the package.</param>
        /// <param name="dateTimeOfPacking">The date time of packing.</param>
        /// <param name="packageIdentifications">The package identifications.</param>
        /// <param name="newPackage">The new package.</param>
        /// <param name="location">The location.</param>
        /// <returns></returns>
        private Package PackSelectedPackages(bool first, PackagingDefine packageType,
                                             DateTime dateTimeOfPacking,
                                             IEnumerable<Identification> packageIdentifications, Package newPackage,
                                             Location location)
        {
            foreach (ListItem item in ListBoxPackages.Items)
            {
                if (item.Selected)
                {
                    Package package;

                    if (!first)
                    {
                        first =
                            PackFirstPackage(item, out package, packageType, dateTimeOfPacking,
                                             packageIdentifications, out newPackage);
                    }
                    else
                    {
                        package = PackOtherPackages(repositoryFactory, item, newPackage, expiredDatetrlStart.GetDatetime(),
                            expiredDateCtrlEnd.GetDatetime(), bestBeforeDateCtrl.GetDatetime(), packageType);
                    }

                    if (location != null)
                    {
                        RemovePreviousPackageFromLocation(location, package);
                    }
                }
            }
            return newPackage;
        }

        /// <summary>
        /// Puts the newly formed package in location.
        /// </summary>
        /// <param name="newPackage">The new package.</param>
        /// <param name="location">The location.</param>
        private void PutNewlyFormedPackageInLocation(Package newPackage, Location location)
        {
            if (ExposuresControl.Visible)
            {
                location.Put(newPackage, ExposuresControl.GetExposureDocument(), GetDateTimeOfPacking());
            }
        }

        /// <summary>
        /// Removes the previous package from location.
        /// </summary>
        /// <param name="location">The location.</param>
        /// <param name="package">The package.</param>
        private void RemovePreviousPackageFromLocation(Location location, Package package)
        {
            if (ExposuresControl.Visible)
            {
                if (location != null)
                {
                    DateTime dateTimeOfPacking = DateTimeControlPacking.GetDatetime();
                    location.Remove(package, dateTimeOfPacking);
                }
                else
                {
                    throw new NullReferenceException(Resources.Localization.Thecurrentlocationisnull);
                }
            }
        }

        /// <summary>
        /// Packs the other packages.
        /// </summary>
        /// </summary>
        /// <param name="repositoryFactory">The repository factory.</param>
        /// <param name="item">The item.</param>
        /// <param name="newPackage">The new package.</param>
        /// <returns></returns>
        private static Package PackOtherPackages(RepositoryFactory repositoryFactory, ListItem item, Package newPackage,
            DateTime shelfLifeStartDateTime, DateTime shelfLifeEndDateTime, DateTime bestBeforeEndDateTime, PackagingDefine packageType)
        {
            Package package = repositoryFactory.GetPackageRepository().GetOne(long.Parse(item.Value));

            package.ShelfLifeStartDateTime = shelfLifeStartDateTime;
            package.ShelfLifeEndDateTime =  shelfLifeEndDateTime;
            package.BestBeforeEndDateTime = bestBeforeEndDateTime;

            newPackage.Pack(package);

            package.FromUid = newPackage.FromUid;
            package.ToUid = newPackage.ToUid;
            package.PackageTypeId = packageType.Uid;

            return package;
        }

        /// <summary>
        /// Packs the first package.
        /// </summary>
        /// <param name="item">The item.</param>
        /// <param name="package">The package.</param>
        /// <param name="packageType">Type of the package.</param>
        /// <param name="dateTimeOfPacking">The date time of packing.</param>
        /// <param name="packageIdentifications">The package identifications.</param>
        /// <param name="newPackage">The new package.</param>
        /// <returns></returns>
        private bool PackFirstPackage(ListItem item, out Package package,
                                      PackagingDefine packageType, DateTime dateTimeOfPacking,
                                      IEnumerable<Identification> packageIdentifications, out Package newPackage)
        {
            package = repositoryFactory.GetPackageRepository().GetOne(long.Parse(item.Value));

            string productCode = TextBoxArticleCode.Text.Trim();

            if (productCode == String.Empty)
            {
                productCode = TextBoxPackageIdentification.Text;
            }

            //Add new properties for package
            newPackage =
                package.Pack(packageType, dateTimeOfPacking, packageIdentifications,
                             productCode, expiredDatetrlStart.GetDatetime(), 
                             expiredDateCtrlEnd.GetDatetime(), bestBeforeDateCtrl.GetDatetime());            
            return true;
        }

        /// <summary>
        /// Gets the package identifications.
        /// </summary>
        /// <param name="packageIdentification">The package identification.</param>
        /// <param name="chainEntity">The chain entity.</param>
        /// <returns></returns>
        private static List<Identification> GetPackageIdentifications(int packageIdentification,
                                                               ChainEntity chainEntity)
        {
            if (RepositoryHelper.IdentificationExists(packageIdentification.ToString(), chainEntity))
            {
                throw new ArgumentException(Resources.Localization.Theidentificationisalreadyused);
            }

            List<Identification> packageIdentifications = new List<Identification>();
            Identification identification = new Identification(packageIdentification.ToString(), chainEntity);
            packageIdentifications.Add(identification);
            return packageIdentifications;
        }

        /// <summary>
        /// 
        /// </summary>
        private static void ValidateIdentificationsExistance(long from, long to, ChainEntity chainEntity)
        {
            for (long counter = from; counter <= to; counter++)
            {
                if (RepositoryHelper.IdentificationExists(counter.ToString(), chainEntity))
                {
                    throw new ArgumentException(Resources.Localization.Theidentificationisalreadyused);
                }
            }
        }

        /// <summary>
        /// Validates the identifications.
        /// </summary>
        private void ValidateIdentifications(ChainEntity chainEntity)
        {
            long from;
            long to;

            bool fromIsNumeric = Int64.TryParse(TextBoxPackageIdentification.Text, out from);
            bool toIsNumeric = Int64.TryParse(TextBoxTo.Text, out to);

            if (fromIsNumeric==false)
            {
                throw new ArgumentException(Resources.Localization.Thefromidentificationisnotnumeric);
            }

            if (TextBoxTo.Text == string.Empty)
            {
                to = from;
            }
            else
            {
                if (toIsNumeric == false)
                {
                    throw new ArgumentException(Resources.Localization.Thetoidentificationisnotnumeric);
                }
            }

            if (from > to)
            {
                throw new ArgumentException(Resources.Localization.Thefromidcannotbegreaterthanthetoidentification);
            }

            if (from < 0 || to < 0)
            {
                throw new ArgumentException(Resources.Localization.Identificationscannotbenegative);
            }

            ValidateIdentificationsExistance(from, to, chainEntity);
        }

        /// <summary>
        /// Gets the type of the selected package.
        /// </summary>
        /// <returns></returns>
        /// Refactor
        //private PackageType GetSelectedPackageType()
        //{
        //    return
        //        repositoryFactory.GetPackageTypeRepository().GetOne(long.Parse(DropDownListPackageType.SelectedValue));
        //}

        private PackagingDefine GetSelectedPackageType()
        {
            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

            var currentUser = RepositoryHelper.GetCurrentUser();
            IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(currentUser.UsingLang, 0, 0, chainEntity.Uid);

            PackagingDefine selectedPackageType = null;

            if (DropDownListPackageType.SelectedValue != "")
            {
               selectedPackageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
            }

            return selectedPackageType;
        }

        /// <summary>
        /// Gets the chain entity.
        /// </summary>
        /// <returns></returns>
        private ChainEntity GetChainEntity()
        {
            return ChainEntityHelper.GetChainEntityThroughUser(User);
        }

        /// <summary>
        /// Gets the location id from session.
        /// </summary>
        /// <returns></returns>
        private long GetLocationId()
        {
            return long.Parse(Session[locationid] as string);
        }


        /// <summary>
        /// Clears the error label.
        /// </summary>
        private void ClearErrorLabel()
        {
            LabelError.Text = string.Empty;
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonBack control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonBack_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect(urlDefault, false);
            }
            catch (Exception e1)
            {
                ErrorHelper.SetErrorLabel(true, e1.Message, LabelError, true);
            }
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the DropDownListPackageType control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void DropDownListPackageType_SelectedIndexChanged(object sender, EventArgs e)
        {
            HandleDropdownPackageTypeChange();            
        }

        protected void ListBoxPackages_SelectedIndexChanged(object sender, EventArgs e)
        {
            //First Rebind the producers listbox
            if (hdnOrgIds.Value.Length > 0)
            {
                //Reload the package list with products of the selected producers
                lbxSelectedProducers.Items.Clear();
                foreach (var orgId in hdnOrgIds.Value.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    var orgInfo = OrganizationServices.GetOneOrganizationByOrgId(orgId);
                    if (orgInfo != null)
                    {
                        var item = new ListItem(orgInfo.Name, orgInfo.Uid);
                        lbxSelectedProducers.Items.Add(item);
                    }
                }

                lbtnFilterPackage.Visible = lbxSelectedProducers.Items.Count > 0;
            }

            var selectedPackages = new List<Package>();
            var selectedItems = new List<ListItem>();
            var hasSelectedItem = false;

            foreach (var listItem in ListBoxPackages.Items)
            {
                var item = (ListItem)listItem;
                if (item.Selected)
                {
                    hasSelectedItem = true;
                    selectedItems.Add(item);
                    //break;
                }
            }

            if (!hasSelectedItem) return;

            foreach (var selectedItem in selectedItems)
            {
                var package = RepFactory.GetPackageRepository().GetOne(Int64.Parse(selectedItem.Value));
                selectedPackages.Add(package);
            }

            if (selectedPackages.Count == 1)
            {
                expiredDatetrlStart.SetStartDateTime(selectedPackages[0].ShelfLifeStartDateTime == DateTime.MinValue
                    ? DateTime.Now : selectedPackages[0].ShelfLifeStartDateTime);
                expiredDateCtrlEnd.SetStartDateTime(selectedPackages[0].ShelfLifeEndDateTime == DateTime.MinValue
                    ? DateTime.Now : selectedPackages[0].ShelfLifeEndDateTime);
                bestBeforeDateCtrl.SetStartDateTime(selectedPackages[0].BestBeforeEndDateTime == DateTime.MinValue
                    ? DateTime.Now : selectedPackages[0].BestBeforeEndDateTime);
            }
            else
            {
                var minExpiredStartDate = selectedPackages[0].ShelfLifeStartDateTime;
                var minExpiredEndDate = selectedPackages[0].ShelfLifeEndDateTime;
                var minBestBeforeEndDate = selectedPackages[0].BestBeforeEndDateTime;
                //Set the date with the first expired date in the selected packages
                foreach (var package in selectedPackages)
                {
                    if (package.ShelfLifeStartDateTime <= minExpiredStartDate)
                    {
                        minExpiredStartDate = package.ShelfLifeStartDateTime;
                    }

                    if (package.ShelfLifeEndDateTime <= minExpiredEndDate)
                    {
                        minExpiredEndDate = package.ShelfLifeEndDateTime;
                    }

                    if (package.BestBeforeEndDateTime <= minBestBeforeEndDate)
                    {
                        minBestBeforeEndDate = package.BestBeforeEndDateTime;
                    }
                }

                expiredDatetrlStart.SetStartDateTime(minExpiredStartDate == DateTime.MinValue ? DateTime.Now : minExpiredStartDate);
                expiredDateCtrlEnd.SetStartDateTime(minExpiredEndDate == DateTime.MinValue ? DateTime.Now : minExpiredEndDate);
                bestBeforeDateCtrl.SetStartDateTime(minBestBeforeEndDate == DateTime.MinValue ? DateTime.Now : minBestBeforeEndDate);
            }
        }
        
        
        /// <summary>
        /// Handles the dropdown package type change.
        /// </summary>
        private void HandleDropdownPackageTypeChange()
        {
            try
            {
                //RouteLoadAction(GetQueryString());
                FillDataForSelectedPackageTypes();

                if (TextBoxTo.Visible)
                {
                    //SetPackageTypeInfo();                    

                    //Refactor
                    //PackageType packageType =
                    //    repositoryFactory.GetPackageTypeRepository().GetOne(
                    //        long.Parse(DropDownListPackageType.SelectedValue));

                    //SetReceiverIdentificationControls(packageType.PackageTypeCategory.Name == retailpackaging);

                    List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];
                    PackagingDefine packageType = null;
                    if (packageTypes.Any())
                    {
                        packageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
                    }

                    SetReceiverIdentificationControls(packageType.PackTypeCategory.Uid == 2 || packageType.PackTypeCategory.Uid == 3 || packageType.PackTypeCategory.Uid == 1 || packageType.PackTypeCategory.Uid == 4); //retailPackaging or Consumer
                }
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }       

        /// <summary>
        /// Sets the receiver identification controls.
        /// </summary>
        private void SetReceiverIdentificationControls(bool isVisible)
        {
            if (!isVisible)
            {
                TextBoxReceiverIdFrom.Text = string.Empty;
                TextBoxReceiverIdTo.Text = string.Empty;
                txtReceiverReferenceFrom.Text = string.Empty;
                txtReceiverReferenceTo.Text = string.Empty;
            }

            TextBoxReceiverIdFrom.Visible = isVisible;
            TextBoxReceiverIdTo.Visible = isVisible;

            LabelReceiverIdFrom.Visible = isVisible;
            LabelRecieverIdTo.Visible = isVisible;

            LabelReceiver.Visible = isVisible;
            LabelIdentificationReceiver.Visible = isVisible;

            DropDownListReceivers.Visible = isVisible;
            DropDownListReceivers.Enabled = isVisible;

            txtReceiverReferenceFrom.Visible = isVisible;
            txtReceiverReferenceTo.Visible = isVisible;

            lblReceiverReferenceFrom.Visible = isVisible;
            lblReceiverReferenceTo.Visible = isVisible;
            lblReceiverReference.Visible = isVisible;
        }

        /// <summary>
        /// Sets the package type info.
        /// </summary>
        /// Refactor, no need of this method, fill data for package type from matching api
        //private void SetPackageTypeInfo()
        //{
        //    PackageType packageType =
        //        repositoryFactory.GetPackageTypeRepository().GetOne(long.Parse(DropDownListPackageType.SelectedValue));

        //    LabelSealed.Text = packageType.IsSealed.ToString();
        //    LabelVentilated.Text = packageType.IsVentilated.ToString();
        //    LabelMaterial.Text = packageType.PackingMaterial.Name;
        //    LabelWidth.Text = packageType.Width.Value + space + packageType.Width.UnitOfMeasurement.Name;
        //    LabelHeight.Text = packageType.Height.Value + space + packageType.Height.UnitOfMeasurement.Name;
        //    LabelLenght.Text = packageType.Lenght.Value + space + packageType.Lenght.UnitOfMeasurement.Name;
        //    LabelWeight.Text = packageType.Weight.Value + space + packageType.Weight.UnitOfMeasurement.Name;
        //}

        /// <summary>
        /// Disables the range controls.
        /// </summary>
        /// <param name="isVisible">if set to <c>true</c> [is visible].</param>
        private void SetRangeControls(bool isVisible)
        {
            LabelFrom.Visible = isVisible;
            LabelTo.Visible = isVisible;
            TextBoxTo.Visible = isVisible;
            TextBoxTo.Text = string.Empty;
            TextBoxTo.Enabled = isVisible;

            ListBoxPackages.SelectionMode = ListSelectionMode.Multiple;

            SetReceiverIdentificationControls(isVisible);
        }

        /// <summary>
        /// Gets the query string.
        /// </summary>
        private string GetQueryString()
        {
            int loop1;
            string act = string.Empty;

            //// Load NameValueCollection object.
            NameValueCollection coll = Request.QueryString;
            //// Get names of all keys into a string array.
            String[] arr1 = coll.AllKeys;

            for (loop1 = 0; loop1 < arr1.Length; loop1++)
            {
                String[] arr2 = coll.GetValues(arr1[loop1]);

                int loop2;
                for (loop2 = 0; loop2 < arr2.Length; loop2++)
                {
                    act = arr2[0];
                }
            }
            return act;
        }

        protected void LbtSplitClick(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtIdtSplit.Text)) return;
            var hasSelectedItem = false;
            var selectedItem = new ListItem();

            foreach (var listItem in ListBoxPackages.Items)
            {
                var item = (ListItem)listItem;
                if (item.Selected)
                {
                    hasSelectedItem = true;
                    selectedItem = item;
                    break;
                }
            }

            if (!hasSelectedItem) return;

            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

            var selPack = repositoryFactory.GetPackageRepository().GetOne(Int64.Parse(selectedItem.Value.Split(':')[0]));
            var splitPart = Array.ConvertAll<string, int>(txtIdtSplit.Text.Split(','), it => int.Parse(it.Trim()));

            Location location = repositoryFactory.GetLocationRepository().GetOne(GetLocationIdFromSession());
            RepositoryHelper.SplitPackageGroup(selPack, splitPart, chainEntity, location);
            var userAction = GetQueryString();
            if (userAction != null)
            {
                if (userAction == packsfp)
                {
                    BindPackagesWithSpecificLocation(GetLocationIdFromSession());
                }
                else if (userAction == packsfpnotinlocation)
                {
                    BindPackagesWithNoLocation();
                }
                else if (userAction == repacksfp)
                {
                    
                    RepackSemiFinishedProductAction(GetLocationIdFromSession());                    
                }                
            }
            
            txtIdtSplit.Text = string.Empty;            
        }

        private void FillDataForSelectedPackageTypes()
        {
            List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];

            if (packageTypes.Count > 0)
            {
                var selectedPackageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
                LabelLenght.Text = selectedPackageType.LenghtValue + " " + selectedPackageType.LengthUoM.Name;
                LabelWidth.Text = selectedPackageType.WidthValue + " " + selectedPackageType.WidthUoM.Name;
                LabelWeight.Text = selectedPackageType.WeightValue + " " + selectedPackageType.WeightUoM.Name;
                LabelHeight.Text = selectedPackageType.HeightValue + " " + selectedPackageType.HeightUoM.Name;
                LabelMaterial.Text = selectedPackageType.PackagingMaterial.Name;
                LabelSealed.Text = selectedPackageType.IsSealed.ToString();
                LabelVentilated.Text = selectedPackageType.IsVantilated.ToString();

            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            Session["selectedItems"] = null;
        }

        void updataDataForPackagingInvoiceInMatching(Package package)
        {
            List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];
            var seperator = "|";
            StringBuilder packagingInfo = new StringBuilder();
            PackagingDefine packageType = null;
            //Append Packaging name
            packageType = (package != null && packageTypes.Any()) ? packageTypes.Where(pt => pt.Uid == package.PackageTypeId).FirstOrDefault() : null;

            if (packageType != null)
            {
                packagingInfo.Append(packageType.Uid.ToString());
                packagingInfo.Append(seperator);
                packagingInfo.Append(packageType.Name);
                packagingInfo.Append(seperator);
            }
            else
            {
                packagingInfo.Append("");
            }

            if (package != null)
            {
                //Append the number of packages
                packagingInfo.Append((package.ToUid - package.FromUid + 1).ToString());
                packagingInfo.Append(seperator);

                //Append the matching product id
                if (package.PrimaryProducts.Any())
                {
                    string prodIds = string.Join(",", Array.ConvertAll(package.PrimaryProducts.Select(it => it.MatchingProdId).ToArray(), Convert.ToString));
                    IList<ProductSupply> listProdSupplies = ProductSupplyServices.GetByIds(prodIds);
                    foreach (var item in listProdSupplies)
                    {
                        packagingInfo.Append(item.Uid.ToString());
                        packagingInfo.Append(seperator);
                    }
                }
            }
            else
            {
                //Append the number of packages
                packagingInfo.Append("0");
                packagingInfo.Append(seperator);
            }

            ProductSupplyServices.UpdateDataForPackagingInvoiceInMatching(packagingInfo.ToString());
        }

        protected void btnAddRefAndIdentification_Click(Object sender, EventArgs e)
        {
            try
            {
                var chainEntity = repositoryFactory.GetChainEntityRepository().GetOne(long.Parse(ddlChainEntity.SelectedValue));
                if (!(txtIdenFrom.Text == string.Empty && txtIdenTo.Text == string.Empty))
                {
                    ValidateIdentifications(chainEntity, txtIdenFrom, txtIdenTo);
                }

                List<ReferenceIdentificationInfo> refIdenInfo = GetReferenceAndIdentificationFromSession();
                if (Page.IsValid)
                {
                    var id = refIdenInfo != null && refIdenInfo.Any() ? refIdenInfo.Count + 1 : 1;

                    var identificationReference = new ReferenceIdentificationInfo()
                    {
                        Id = id,

                        ChainEntityId = Int64.Parse(ddlChainEntity.SelectedValue),

                        IdentificationFrom = txtIdenFrom.Text,

                        IdentificationTo = txtIdenTo.Text,

                        ReferenceFrom = txtRefFrom.Text,

                        ReferenceTo = txtRefTo.Text
                    };

                    AddRefAndIdentificationInfoToSession(identificationReference);

                    BindDataForReferenceAndIdentification();

                    ClearData();
                }

            }
            catch (ArgumentException exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.Message, LabelError, false);
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }

        private List<ReferenceIdentificationInfo> GetReferenceAndIdentificationFromSession()
        {
            if (Session[referenceIdentification] == null) return new List<ReferenceIdentificationInfo>();

            return (List<ReferenceIdentificationInfo>)Session[referenceIdentification];
        }

        private List<ReferenceIdentificationInfo> AddRefAndIdentificationInfoToSession(ReferenceIdentificationInfo info)
        {
            List<ReferenceIdentificationInfo> refIdentificationList = new List<ReferenceIdentificationInfo>();

            if (Session[referenceIdentification] == null)
            {
                refIdentificationList.Add(info);
                Session[referenceIdentification] = refIdentificationList;
            }
            else
            {
                refIdentificationList = (List<ReferenceIdentificationInfo>)Session[referenceIdentification];
                refIdentificationList.Add(info);
                Session[referenceIdentification] = refIdentificationList;
            }

            return refIdentificationList;
        }

        protected void grdChainEntityRefAndIdentificationInfo_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToLower().Equals("deleteri"))
                {
                    long id = GetSelectedReferenceIdentificationId(e);

                    List<ReferenceIdentificationInfo> refIdenList = GetReferenceAndIdentificationFromSession();

                    var refIden = refIdenList != null ? refIdenList.Where(rI => rI.Id == id).FirstOrDefault() : null;

                    if (refIden != null)
                    {
                        refIdenList.Remove(refIden);
                        Session[referenceIdentification] = refIdenList;
                    }
                }

                BindDataForReferenceAndIdentification();

            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }

        private long GetSelectedReferenceIdentificationId(CommandEventArgs e)
        {
            return (long)int.Parse((string)e.CommandArgument, CultureInfo.CurrentCulture);
        }

        protected void grdChainEntityRefAndIdentificationInfo_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var refIden = e.Row.DataItem as ReferenceIdentificationInfo;
                var chainEnties = RepFactory.GetChainEntityRepository().AsCollection();
                var chainEntity = chainEnties.Where(ce => ce.Uid == refIden.ChainEntityId).FirstOrDefault();
                (e.Row.FindControl("lblChainEntity") as Label).Text = refIden != null ? (chainEntity != null ? chainEntity.Name : "") : "";
            }
        }

        private void BindDataForReferenceAndIdentification()
        {
            grdChainEntityRefAndIdentificationInfo.Visible = false;

            List<ReferenceIdentificationInfo> refIdentificationList = new List<ReferenceIdentificationInfo>();

            refIdentificationList = GetReferenceAndIdentificationFromSession();

            //Bind data for grid
            if (refIdentificationList.Any())
            {
                grdChainEntityRefAndIdentificationInfo.Visible = true;
                grdChainEntityRefAndIdentificationInfo.DataSource = refIdentificationList;
                grdChainEntityRefAndIdentificationInfo.DataBind();
            }
        }

        private void ClearData()
        {
            txtIdenFrom.Text = "";
            txtIdenTo.Text = "";
            txtRefFrom.Text = "";
            txtRefTo.Text = "";
            ddlChainEntity.SelectedIndex = 0;
        }

        private int ValidateIdentifications(ChainEntity chainEntity, TextBox txtFrom, TextBox txtTo)
        {
            int from;
            int to;

            bool fromIsNumeric = int.TryParse(txtFrom.Text, out from);
            bool toIsNumeric = int.TryParse(txtTo.Text, out to);

            if (fromIsNumeric == false)
            {
                throw new ArgumentException(Resources.Localization.Thefromidentificationisnotnumeric);
            }

            if (txtTo.Text == string.Empty)
            {
                to = from;
            }
            else
            {
                if (toIsNumeric == false)
                {
                    throw new ArgumentException(Resources.Localization.Thetoidentificationisnotnumeric);
                }
            }

            if (from > to)
            {
                throw new ArgumentException(Resources.Localization.Thefromidcannotbegreaterthanthetoidentification);
            }

            if (from < 0 || to < 0)
            {
                throw new ArgumentException(Resources.Localization.Identificationscannotbenegative);
            }

            int tempId = from;

            for (int counter = tempId; counter <= to; counter++)
            {
                if (RepositoryHelper.IdentificationExists(tempId.ToString(), chainEntity))
                {
                    throw new ArgumentException(Resources.Localization.Theidentificationisalreadyused);
                }

                tempId++;
            }

            return from;
        }

        private void BindDataFor3rdPartyDropdown()
        {
            var chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

            var chainEntityId = chainEntity != null ? chainEntity.Uid.ToString() : "";

            List<AgriMore.Logistics.Domain.ThirdPartyEntities.ChainEntity1> listChainEntities = ProductSupplyServices.GetByChainEntitiesInGoOs(chainEntityId);

            ddlChainEntity.DataSource = listChainEntities;
            ddlChainEntity.DataTextField = "Name";
            ddlChainEntity.DataValueField = "Uid";
            ddlChainEntity.DataBind();         
        }

        private List<Identification> GetPackageIdentifications(long packageIdentificationFrom,
                                                               ChainEntity chainEntity, long packageIdentificationTo)
        {
            ChainEntity receiverChainEntity = repositoryFactory.GetChainEntityRepository().GetOne(long.Parse(DropDownListReceivers.SelectedValue));            

            for (long i = packageIdentificationFrom; i < packageIdentificationTo; i++)
            {
                if (RepositoryHelper.IdentificationExists(i.ToString(), chainEntity))
                {
                    throw new ArgumentException(Resources.Localization.Theidentificationisalreadyused);
                }
            }

            List<Identification> packageIdentifications = new List<Identification>();

            //Set identifications for shipper identification (1st range)
            Identification identification = new Identification(packageIdentificationFrom.ToString(), chainEntity, 0, 0, txtShipperReferenceFrom.Text,txtShipperReferenceTo.Text);
            identification.FromUid = packageIdentificationFrom;
            identification.ToUid = packageIdentificationTo;

            packageIdentifications.Add(identification);

            //Set identifications for receiver identifications (2nd range)
            if (AddReceiverIdentifications())
            {
                ValidateIdentifications(receiverChainEntity, TextBoxReceiverIdFrom, TextBoxReceiverIdTo);

            }
            if (AddReceiverIdentifications())
            {                
                Identification receiverIdentification = new Identification(TextBoxReceiverIdFrom.Text, receiverChainEntity, 0, 0, txtReceiverReferenceFrom.Text, txtReceiverReferenceTo.Text);
                receiverIdentification.FromUid = TextBoxReceiverIdFrom.Text.Trim() != string.Empty ? Int32.Parse(TextBoxReceiverIdFrom.Text) : 0;
                receiverIdentification.ToUid = TextBoxReceiverIdTo.Text.Trim() != string.Empty ? Int32.Parse(TextBoxReceiverIdTo.Text): 0;
                packageIdentifications.Add(receiverIdentification);
            }

            //Validate the Identification in dynamic block
            List<ReferenceIdentificationInfo> rIdenList = GetReferenceAndIdentificationFromSession();
            if (rIdenList != null && rIdenList.Any())
            {
                foreach (var rIden in rIdenList)
                {
                    var chainEnt = repositoryFactory.GetChainEntityRepository().GetOne(rIden.ChainEntityId);
                    //Set identification range
                    Identification iden = new Identification(rIden.IdentificationFrom, chainEnt, rIden.IdentificationFrom == "" ? 0 : Int32.Parse(rIden.IdentificationFrom),
                                rIden.IdentificationTo == "" ? 0 : Int32.Parse(rIden.IdentificationTo), rIden.ReferenceFrom, rIden.ReferenceTo);
                    //iden.FromUid = Int32.Parse(rIden.IdentificationFrom);
                    //iden.ToUid = Int32.Parse(rIden.IdentificationTo);

                    packageIdentifications.Add(iden);
                }
            }

            return packageIdentifications;
        }

        protected void lbtnFilterPackage_Click(Object sender, EventArgs e)
        {            
            //First Rebind the producers listbox
            if (hdnSelectedOrgIds.Value.Length > 0)
            {                
                //Reload the package list with products of the selected producers
                lbxSelectedProducers.Items.Clear();
                foreach (var orgId in hdnOrgIds.Value.Split(new char[] {','}, StringSplitOptions.RemoveEmptyEntries))
                {
                    var orgInfo = OrganizationServices.GetOneOrganizationByOrgId(orgId);
                    if (orgInfo != null)
                    {
                        var item = new ListItem(orgInfo.Name, orgInfo.Uid);                                                
                        lbxSelectedProducers.Items.Add(item);
                    }
                }    
            
                //ReSelect the listbox
                foreach (var orgId in hdnSelectedOrgIds.Value.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    foreach (ListItem item in lbxSelectedProducers.Items)
                    {
                        if (orgId == item.Value)
                        {
                            item.Selected = true;
                        }
                    }
                }
            }
            else if (hdnOrgIds.Value.Length > 0)
            {
                //Reload the package list with products of the selected producers
                lbxSelectedProducers.Items.Clear();
                foreach (var orgId in hdnOrgIds.Value.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    var orgInfo = OrganizationServices.GetOneOrganizationByOrgId(orgId);
                    if (orgInfo != null)
                    {
                        var item = new ListItem(orgInfo.Name, orgInfo.Uid);
                        lbxSelectedProducers.Items.Add(item);
                    }
                }

                //ReSelect the listbox
                foreach (var orgId in hdnOrgIds.Value.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    foreach (ListItem item in lbxSelectedProducers.Items)
                    {
                        if (orgId == item.Value)
                        {
                            item.Selected = true;
                        }
                    }
                }

            }

            if (hdnSelectedOrgIds.Value.Length == 0 && hdnOrgIds.Value.Length == 0)
            {
                lbxSelectedProducers.Items.Clear();
            }

            var userAction = GetQueryString();            

            if (userAction != null)
            {
                List<Package> filterPackages = new List<Package>();
                if (userAction == packsfp)
                {
                    BindReceivers();
                    LabelTitle.ForeColor = Color.White;
                    LabelTitle.Text = packsfpTitle;                    

                    Location location = repositoryFactory.GetLocationRepository().GetOne(GetLocationIdFromSession());

                    ICollection<Package> packages =
                        repositoryFactory.GetPackageRepository().Find(new PackageInLocationSpecification(location));

                    filterPackages = packages.ToList();

                    ChainEntity chainEntity = GetChainEntityForCurrentUser();
                    
                    IList<ProductSupply> listProdSupplies = new List<ProductSupply>();
                    //Filter the packages to just get the producers in the selected listbox 
                    foreach (Package package in packages)
                    {
                        bool mustFilterOut = true;

                        if (package.PrimaryProducts.Any())
                        {
                            string prodIds = string.Join(",", Array.ConvertAll(package.PrimaryProducts.Select(it => it.MatchingProdId).ToArray(), Convert.ToString));
                            listProdSupplies = ProductSupplyServices.GetByIds(prodIds);
                            var productSuppliesByOrgs = ProductServices.GetPackedProductByOrgIds(hdnSelectedOrgIds.Value == string.Empty ? (hdnOrgIds.Value == string.Empty ? chainEntity.Uid.ToString() + ";" + "0" : chainEntity.Uid.ToString() + ";" + hdnOrgIds.Value) : chainEntity.Uid.ToString() + ";" + hdnSelectedOrgIds.Value);
                            foreach(var prod in listProdSupplies) 
                            {
                                if (productSuppliesByOrgs.Count > 0 && productSuppliesByOrgs.Select(ps => ps.Uid).Contains(prod.Uid))
                                {
                                    mustFilterOut = false;
                                    break;
                                }
                            }

                            //if (productSuppliesByOrgs.Count == 0)
                            //{
                            //    mustFilterOut = false;
                            //}

                            if (mustFilterOut)
                            {
                                filterPackages.Remove(package);
                            }
                        }                        
                    }

                    ListBoxPackages.Items.Clear();
                    if (txtProducer.Text == string.Empty && hdnOrgIds.Value == string.Empty && hdnSelectedOrgIds.Value == string.Empty)
                    {
                        filterPackages = packages.ToList();
                    }
                    foreach (Package package in filterPackages)
                    {
                        string name = RepositoryHelper.CreatePackageName(package, chainEntity);
                        var numPack = ((package.ToUid - package.FromUid) + 1).ToString();
                        var listItem = new ListItem(name, package.Uid.ToString());
                        listItem.Attributes.Add("data-npackage", numPack);                        
                        ListBoxPackages.Items.Add(listItem);
                    }                         
                }
                else if (userAction == packsfpnotinlocation)
                {
                    BindReceivers();
                    LabelTitle.ForeColor = Color.White;
                    LabelTitle.Text = packsfpnotinlocationTitle;

                    ChainEntity chainEntity = GetChainEntityForCurrentUser();

                    ICollection<Package> packages = GetPackagesWithNoLocation();

                    filterPackages = packages.ToList();
                    
                    IList<ProductSupply> listProdSupplies = new List<ProductSupply>();
                    //Filter the packages to just get the producers in the selected listbox 
                    foreach (Package package in packages)
                    {

                        bool mustFilterOut = true;

                        if (package.PrimaryProducts.Any())
                        {
                            string prodIds = string.Join(",", Array.ConvertAll(package.PrimaryProducts.Select(it => it.MatchingProdId).ToArray(), Convert.ToString));
                            listProdSupplies = ProductSupplyServices.GetByIds(prodIds);

                            var productSuppliesByOrgs = ProductServices.GetPackedProductByOrgIds(hdnSelectedOrgIds.Value == string.Empty ? (hdnOrgIds.Value == string.Empty ? chainEntity.Uid.ToString() + ";" + "0" : chainEntity.Uid.ToString() + ";" + hdnOrgIds.Value) : chainEntity.Uid.ToString() + ";" + hdnSelectedOrgIds.Value);
                            foreach (var prod in listProdSupplies)
                            {
                                if (productSuppliesByOrgs.Count > 0 && productSuppliesByOrgs.Select(ps => ps.Uid).Contains(prod.Uid))
                                {
                                    mustFilterOut = false;
                                    break;
                                }
                            }

                            //if (productSuppliesByOrgs.Count == 0)
                            //{
                            //    mustFilterOut = false;
                            //}

                            if (mustFilterOut)
                            {
                                filterPackages.Remove(package);
                            }
                        }
                        
                    }

                    ListBoxPackages.Items.Clear();
                    if (txtProducer.Text == string.Empty && hdnOrgIds.Value == string.Empty && hdnSelectedOrgIds.Value == string.Empty)
                    {
                        filterPackages = packages.ToList();
                    }

                    foreach (Package package in filterPackages)
                    {
                        string name = RepositoryHelper.CreatePackageName(package, chainEntity);
                        var numPack = ((package.ToUid - package.FromUid) + 1).ToString();
                        var listItem = new ListItem(name, package.Uid.ToString());
                        listItem.Attributes.Add("data-npackage", numPack);                        
                        ListBoxPackages.Items.Add(listItem);                       
                    }


                }
                else if (userAction == repacksfp)
                {
                    ChainEntity chainEntity = GetChainEntityForCurrentUser();

                    LabelTitle.ForeColor = Color.White;
                    LabelTitle.Text = repacksfpTitle;
                    //RepackSemiFinishedProductAction(GetLocationIdFromSession());

                    Location location = repositoryFactory.GetLocationRepository().GetOne(GetLocationIdFromSession());

                    List<Package> packagesOnlyPackedOnce = new List<Package>();
                    // Get all packages only packed once.
                    foreach (Package p in location.Packages)
                    {
                        List<Package> childPackages = new List<Package>(p.Children);
                        //if (childPackages.Count == 0 &&
                        //    p.PackageType.PackageTypeCategory == PackageTypeCategory.wholesalePackaging)
                        if (childPackages.Count == 0)
                        {
                            packagesOnlyPackedOnce.Add(p);
                        }
                    }


                    filterPackages = packagesOnlyPackedOnce;
                    
                    IList<ProductSupply> listProdSupplies = new List<ProductSupply>();
                    //Filter the packages to just get the producers in the selected listbox 
                    foreach (Package package in packagesOnlyPackedOnce)
                    {
                        bool mustFilterOut = true;

                        if (package.PrimaryProducts.Any())
                        {
                            string prodIds = string.Join(",", Array.ConvertAll(package.PrimaryProducts.Select(it => it.MatchingProdId).ToArray(), Convert.ToString));
                            listProdSupplies = ProductSupplyServices.GetByIds(prodIds);
                            var productSuppliesByOrgs = ProductServices.GetPackedProductByOrgIds(hdnSelectedOrgIds.Value == string.Empty ? (hdnOrgIds.Value == string.Empty ? chainEntity.Uid.ToString() + ";" + "0" : chainEntity.Uid.ToString() + ";" + hdnOrgIds.Value) : chainEntity.Uid.ToString() + ";" + hdnSelectedOrgIds.Value);
                            foreach (var prod in listProdSupplies)
                            {
                                if (productSuppliesByOrgs.Count > 0 && productSuppliesByOrgs.Select(ps => ps.Uid).Contains(prod.Uid))
                                {
                                    mustFilterOut = false;
                                    break;
                                }
                            }

                            //if (productSuppliesByOrgs.Count == 0)
                            //{
                            //    mustFilterOut = false;
                            //}

                            if (mustFilterOut)
                            {
                                filterPackages.Remove(package);
                            }
                        }
                        
                    }


                    ListBoxPackages.Items.Clear();

                    //ChainEntity chainEntity = GetChainEntityForCurrentUser();

                    if (txtProducer.Text == string.Empty && hdnOrgIds.Value == string.Empty && hdnSelectedOrgIds.Value == string.Empty)
                    {
                        filterPackages = packagesOnlyPackedOnce;
                    }

                    foreach (Package package in filterPackages)
                    {
                        string name = RepositoryHelper.CreatePackageName(package, chainEntity);
                        var numPack = ((package.ToUid - package.FromUid) + 1).ToString();
                        var listItem = new ListItem(name, package.Uid.ToString());                        
                        listItem.Attributes.Add("data-npackage", numPack);
                        ListBoxPackages.Items.Add(listItem);
                    }

                    BindReceivers();                    
                }
                else
                {
                    throw new ArgumentException(novalidaction);
                }
            }

            //show hide the messages if no package found   
            if (ListBoxPackages.Items.Count <= 0)
            {
                lblNoPackageFoundMessage.Visible = true;

            }
            else
            {
                lblNoPackageFoundMessage.Visible = false;
            }
        }
    }
}