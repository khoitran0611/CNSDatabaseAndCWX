using System;
using System.Globalization;
using System.Threading;
using System.Web;
//using Common.Logging;
using log4net;
using log4net.Config;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public class Global : HttpApplication
    {
        private const string urlDefaultError = "DefaultErrorPage.aspx";
        private readonly ILog log = LogManager.GetLogger(typeof (HttpApplication));

        /// <summary>
        /// Handles the Start event of the Application control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Application_Start(object sender, EventArgs e)
        {
            XmlConfigurator.Configure();                       
        }

        /// <summary>
        /// Handles the Error event of the Application control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Application_Error(object sender, EventArgs e)
        {
            // Code that runs when an unhandled error occurs
            // Give the user some information, but
            // stay on the default page
            Exception exception = Server.GetLastError();
            // Log the exception and notify system operators
            log.Error(exception.ToString());
            // Clear the error from the server
            //Server.ClearError();
            //Response.Redirect(urlDefaultError, false);
        }

        /// <summary>
        /// Handles the BeginRequest event of the Application control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Application_BeginRequest(Object sender, EventArgs e)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture("en-GB");
            Thread.CurrentThread.CurrentUICulture = Thread.CurrentThread.CurrentCulture;                                   
        }

        //protected void Application_AuthenticateRequest(object sender, EventArgs e)
        //{
        //    if (HttpContext.Current.User != null)
        //    {
        //        var currentUser = RepositoryHelper.GetCurrentUser();
        //        ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

        //        IList<PackagingDefine> allPackageTypes = new List<PackagingDefine>();
        //        if (HttpContext.Current.Cache["AllPackageTypes_" + currentUser.UsingLang] == null)
        //        {
        //            allPackageTypes = ProductServices.GetAllPackageTypes(currentUser.UsingLang, 0, 0, chainEntity.Uid);
        //            HttpContext.Current.Cache.Insert("AllPackageTypes_" + currentUser.UsingLang, allPackageTypes, null, DateTime.Now.AddMinutes(60), System.Web.Caching.Cache.NoSlidingExpiration);                    
        //        }
        //    }
        //}        
    }
}