﻿using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;

namespace AgriMore.Logistics.Web
{
    public class BasePage : Page
    {
        #region Properties
        protected readonly RepositoryFactory RepFactory = new RepositoryFactory();

        #endregion

        public static string CurUserName
        {
            get { return HttpContext.Current.User.Identity.Name; }
        }

        public static string CurLangCode
        {
            get
            {
                string langCulture;
                User curUser = RepositoryHelper.GetCurrentUser();
                langCulture = (curUser != null && !string.IsNullOrEmpty(curUser.UsingLang)) ? curUser.UsingLang : "en-GB";

                return langCulture;
            }
        }

        protected override void InitializeCulture()
        {
            Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = new CultureInfo(CurLangCode);
            //base.InitializeCulture();
        }

        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);
            this.InitializeCulture();
        }

    }
}