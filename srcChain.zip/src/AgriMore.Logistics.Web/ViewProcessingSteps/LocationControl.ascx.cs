using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using System.Linq;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Web
{
    public delegate void LocationControlEventHandler(Object sender, LocationControlEventArgs e);
    /// <summary>
    /// </summary>
    public class LocationControlEventArgs : EventArgs
    {
        private readonly string chainEntityId;
        private readonly string indentificationText;        

        /// <summary>
        /// Initializes a new instance of the <see cref="LocationEventArgs"/> class.
        /// </summary>
        /// <param name="chainEntityId">The chain entity id.</param>
        /// <param name="indentificationText">The indentification text.</param>
        public LocationControlEventArgs(string chainEntityId, string indentificationText)
        {
            if (chainEntityId == null)
            {
                throw new ArgumentNullException("chainEntityId");
            }
            if (indentificationText == null)
            {
                throw new ArgumentNullException("indentificationText");
            }

            this.chainEntityId = chainEntityId;
            this.indentificationText = indentificationText;
        }

        /// <summary>
        /// Gets the chain entity id.
        /// </summary>
        /// <value>The chain entity id.</value>
        public string ChainEntityId
        {
            get { return chainEntityId; }
        }

        /// <summary>
        /// Gets the indentification text.
        /// </summary>
        /// <value>The indentification text.</value>
        public string IndentificationText
        {
            get { return indentificationText; }
        }
    }

    /// <summary>
    /// </summary>
    public class LocationControlView
    {
        private readonly ExposureDocument exposureDocument;
        private readonly Package package;
        private readonly User user;        

        /// <summary>
        /// Initializes a new instance of the <see cref="LocationView"/> class.
        /// </summary>
        /// <param name="exposureDocument">The exposure document.</param>
        /// <param name="user">The user.</param>
        /// <param name="package">The package.</param>
        public LocationControlView(ExposureDocument exposureDocument, User user, Package package)
        {
            this.exposureDocument = exposureDocument;
            this.user = user;
            this.package = package;
        }

        /// <summary>
        /// Gets the exposure document.
        /// </summary>
        /// <value>The exposure document.</value>
        public ExposureDocument ExposureDocument
        {
            get { return exposureDocument; }
        }

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <value>The user.</value>
        public User User
        {
            get { return user; }
        }

        /// <summary>
        /// Gets the package.
        /// </summary>
        /// <value>The package.</value>
        public Package Package
        {
            get { return package; }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public partial class LocationControl : UserControl
    {
        public event LocationControlEventHandler PackageToView;
        private RepositoryFactory repFactory = new RepositoryFactory();

        private Dictionary<long, Treatment> treatments = new Dictionary<long, Treatment>();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //wasteAdditinalInfo.Visible = false;
                //wasteAdditinalInfoDetail.Visible = false;
            }
        }

        protected virtual void OnPackageToView(LocationControlEventArgs e)
        {
            if (PackageToView != null)
            {
                PackageToView(this, e);
            }
        }

        /// <summary>
        /// Creates the duration.
        /// </summary>
        /// <param name="ed">The ed.</param>
        /// <returns></returns>
        private static string CreateDuration(ExposureDocument ed)
        {
            DateTime dateOfRemoval = ed.DateOfRemoval;

            if (ed.IsActive)
            {
                dateOfRemoval = DateTime.Now;
            }

            TimeSpan ts = (dateOfRemoval - ed.DateOfPlacement);




            return CreateDurationString(ts);// String.Format("{0}:{1}:{2}", totalHours, ts.Minutes, ts.Seconds);

        }

        /// <summary>
        /// Creates the duration string.
        /// </summary>
        /// <param name="ts">The ts.</param>
        /// <returns></returns>
        private static string CreateDurationString(TimeSpan ts)
        {
            long totalHours = ts.Days * 24;
            totalHours += ts.Hours;

            string hours = (totalHours.ToString().Length == 1) ? "0" + totalHours : totalHours.ToString();
            string minutes = (ts.Minutes.ToString().Length == 1) ? "0" + ts.Minutes : ts.Minutes.ToString();
            string seconds = (ts.Seconds.ToString().Length == 1) ? "0" + ts.Seconds : ts.Seconds.ToString();

            return String.Format("{0}:{1}:{2}", hours, minutes, seconds);
        }

        private string CreatePackageToViewId(string chainEntityid, string identificationText)
        {
            return String.Format("{0}:{1}", chainEntityid, identificationText);
        }

        /// <summary>
        /// Binds the containing packages.
        /// </summary>
        /// <param name="processingView">The processing view.</param>
        private void BindContainingPackages(ProcessingView processingView)
        {
            ChildrenContainer.Visible = false;

            DropDownListChildren.Items.Add(new ListItem("-- select package --", "-1"));

            foreach (Package package in processingView.ChildPackages)
            {
                string identificationForChainEntity = package.IdentificationForChainEntity(processingView.ChainEntity);
                string identificationId = package.IdentificationForChainEntity(processingView.ChainEntity);//.IdentificationIdForChainEntity(processingView.ChainEntity);
                if (identificationForChainEntity != String.Empty)
                {
                    string id = CreatePackageToViewId(processingView.ChainEntity.Uid.ToString(), identificationId);
                    DropDownListChildren.Items.Add(
                        new ListItem(RepositoryHelper.CreatePackageName(package, processingView.ChainEntity), id));
                }
            }

            ChildrenContainer.Visible = DropDownListChildren.Items.Count > 1;
        }

        /// <summary>
        /// Binds the bulk packages.
        /// </summary>
        /// <param name="processingView">The processing view.</param>
        private void BindBulkPackages(ProcessingView processingView)
        {
            BulkContainer.Visible = false;

            DropDownListBulk.Items.Add(new ListItem("-- select package --", "-1"));

            foreach (Package package in processingView.BulkPackages)
            {
                string identificationForChainEntity = package.IdentificationForChainEntity(processingView.ChainEntity);
                string identificationIdForChainEntity = package.IdentificationForChainEntity(processingView.ChainEntity);//.IdentificationIdForChainEntity(processingView.ChainEntity);
                if (package.IdentificationForChainEntity(processingView.ChainEntity) != String.Empty)
                {
                    string id = CreatePackageToViewId(processingView.ChainEntity.Uid.ToString(), identificationIdForChainEntity);
                    DropDownListBulk.Items.Add(
                        new ListItem(RepositoryHelper.CreatePackageName(package, processingView.ChainEntity), id));
                }
            }

            BulkContainer.Visible = DropDownListBulk.Items.Count > 1;

        }


        private Package RetrieveParent(ProcessingView processingView)
        {
            Package parent = null;
            if (processingView.Step.PackageParentId == processingView.ExposureDocument.Package.Uid)
            {
                parent = processingView.ExposureDocument.Package;
            }

            return parent;
        }

        /// <summary>
        /// Binds the parent package.
        /// </summary>
        /// <param name="processingView">The processing view.</param>
        private void BindParentPackage(ProcessingView processingView)
        {
            ParentContainer.Visible = false;
            //return;
            Package parent = RetrieveParent(processingView);

            if (parent != null)
            {
                ParentContainer.Visible = true;
                //Package parent = processingView.ExposureDocument.Package;

                LinkButtonParent.Text = RepositoryHelper.CreatePackageName(parent, processingView.ChainEntity);
                LinkButtonParent.CommandArgument =
                    String.Format("{0}:{1}", processingView.ChainEntity.Uid, parent.IdentificationForChainEntity(processingView.ChainEntity));//.IdentificationIdForChainEntity(processingView.ChainEntity));
            }

        }

        /// <summary>
        /// Initializes the specified processing view.
        /// </summary>
        /// <param name="processingView">The processing view.</param>
        public void Initialize(ProcessingView processingView)
        {
            IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(RepositoryHelper.GetCurrentUser().UsingLang, 0, 0, RepositoryHelper.GetChainEntityForCurrentUser().Uid).ToList();
            Session["ProcessingView"] = processingView;
            BindParentPackage(processingView);

            string packageIdentification = processingView.Package.IdentificationForChainEntity(processingView.ChainEntity);

            TreatMeantContainer.Visible = false;
            LabelRemarks.Text = processingView.Step.Remarks.Replace(Environment.NewLine, "<br/>");
            LabelTimeInStorage.Text = CreateDuration(processingView.ExposureDocument);

            LabelPackageidentification.Text = packageIdentification;
            LabelName.Text = processingView.ExposureDocument.Location.Name;
            LabelDateOfPlacement.Text = processingView.ExposureDocument.DateOfPlacement.ToString();
            LabelUser.Text = processingView.User.ToString();
            //Refactor
            //LabelPackageType.Text = processingView.Package.PackageType.Name;
            LabelPackageType.Text = processingView.Package.PackageTypeName;

            List<Decomposition> decomposes = repFactory.GetDecompositionRepository().AsCollection()
            .Where(d => d.PackageId == processingView.Package.Uid).ToList();

            GridViewDetailsExposures.DataSource = processingView.ExposureDocument.Exposures;
            GridViewDetailsExposures.DataBind();

            grdDecomposition.DataSource = decomposes;
            grdDecomposition.DataBind();

            LabelDateOfRemoval.Text = processingView.ExposureDocument.IsActive
                                          ? "in storage"
                                          : processingView.ExposureDocument.DateOfRemoval.ToString();

            var packageDescription = "";
            var packt = packageTypes.Where(pt => pt.Uid == processingView.Package.PackageTypeId).FirstOrDefault();
            if (packt != null)
            {
                packageDescription += packt.PackagingMaterial.Name;
            }

            if (processingView.Package.PrimaryProducts != null && processingView.Package.PrimaryProducts.Any())
            {
                foreach (var priProduct in processingView.Package.PrimaryProducts)
                {
                    var product = ProductServices.GetById(priProduct.ProductUid);

                    if (product != null)
                    {
                        packageDescription += " with ";
                        packageDescription += product.Name;
                    }
                }
            }

            lblPackageMaterial.Text = packageDescription;

            if (processingView.Package.PackageTypeCategoryId == 4)
            {
                wasteLinkDetail.Text = processingView.WasteLinkDetail;
            }

            BindBulkPackages(processingView);
            BindContainingPackages(processingView);
        }

        /// <summary>
        /// Retrieves the documented.
        /// </summary>
        /// <param name="exposure">The exposure.</param>
        /// <returns></returns>
        protected string RetrieveDocumented(object exposure)
        {
            Exposure es = (Exposure)exposure;
            StringBuilder documented = new StringBuilder();

            List<MeasuredValue> values = new List<MeasuredValue>();
            values.AddRange(es.Values);
            values.Sort(
                delegate(MeasuredValue p1, MeasuredValue p2) { return p2.DateTimeOfMeasurement.CompareTo(p1.DateTimeOfMeasurement); });

            string id = Guid.NewGuid().ToString().Replace("-", "");

            documented.Append("<a href='javascript:void(0)' onclick='javascript:switchMenu(this,\"" + id +
                              "\")'>View</a>");

            documented.Append("<div>");
            documented.Append("<table id='" + id +
                              "' border='0'cellpadding='3' cellspacing='2' width='100%' style='display:none'><tr><td style='font-weight:bold;background-color:#E3EAEB;'>Value</td<td style='font-weight:bold;background-color:#E3EAEB;'>Date</td</tr>");
            foreach (MeasuredValue actual in values)
            {
                //if (!es.PrescribedRange.Contains(actual))
                //{
                documented.Append("<tr>");
                if (es.PrescribedRange.Contains(actual))
                {
                    documented.Append("<td>");
                }
                else
                {
                    documented.Append("<td style='color:red;font-weight:bold;' >");
                }

                //if (actual.Value > es.PrescribedRange.Start.Value)
                //{
                //    documented.Append("<td style='color:red;font-weight:bold;' >");
                //}
                //else
                //{
                //    documented.Append("<td>");
                //}

                documented.Append(actual.Value);
                documented.Append("</td>");
                documented.Append("<td>");
                documented.Append(actual.DateTimeOfMeasurement.ToString());
                documented.Append("</td>");
                documented.Append("</tr>");
                //}
            }
            documented.Append("</table></div>");
            string result = documented.ToString();

            return result;
        }

        /// <summary>
        /// Adds the treatment.
        /// </summary>
        /// <param name="treatment">The treatment.</param>
        public void AddTreatment(Treatment treatment)
        {
            if (!treatments.ContainsKey(treatment.Uid))
            {

                treatments.Add(treatment.Uid, treatment);
            }
        }


        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.PreRender"></see> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
            TreatMeantContainer.Visible = false;
            ExposuresContainer.Visible = false;
            DecompositionContainer.Visible = false;

            if (treatments.Count > 0)
            {
                TreatMeantContainer.Visible = true;
                List<Treatment> sortedTreatments = new List<Treatment>();
                sortedTreatments.AddRange(treatments.Values);
                sortedTreatments.Sort(delegate(Treatment p1, Treatment p2) { return p2.Duration.Start.CompareTo(p1.Duration.Start); });

                foreach (Treatment treatmentToLoad in sortedTreatments)
                {

                    TreatmentControl treatmentControl =
                        (TreatmentControl)Page.LoadControl("ViewProcessingSteps/TreatmentControl.ascx");

                    treatmentControl.Initialize(treatmentToLoad);
                    PlaceHolderTreatment.Controls.Add(treatmentControl);                   
                }
            }

            if (GridViewDetailsExposures.Rows.Count > 0)
            {
                ExposuresContainer.Visible = true;
            }

            if (grdDecomposition.Rows.Count > 0)
            {
                DecompositionContainer.Visible = true;
            }

            base.OnPreRender(e);
        }

        protected void LinkButtonParent_Click(object sender, EventArgs e)
        {
            string arguments = LinkButtonParent.CommandArgument;
            string chainEntityId = arguments.Split(':')[0];
            string indentificationText = arguments.Split(':')[1];

            OnPackageToView(new LocationControlEventArgs(chainEntityId, indentificationText));
        }

        protected void DropDownListChildren_SelectedIndexChanged(object sender, EventArgs e)
        {
            string arguments = DropDownListChildren.SelectedValue;
            string chainEntityId = arguments.Split(':')[0];
            string indentificationText = arguments.Split(':')[1];

            OnPackageToView(new LocationControlEventArgs(chainEntityId, indentificationText));
        }

        protected void DropDownListBulk_SelectedIndexChanged(object sender, EventArgs e)
        {
            string arguments = DropDownListBulk.SelectedValue;
            string chainEntityId = arguments.Split(':')[0];
            string indentificationText = arguments.Split(':')[1];

            OnPackageToView(new LocationControlEventArgs(chainEntityId, indentificationText));
        }

        public string ProcessDecompositionType(object quantity)
        {
            var myQuantity = (long)quantity;
            List<DecompositionType> types = ProductServices.GetDecompositionTypeList().ToList();

            if (types.Any())
            {
                var decType = types.Where(t => t.Uid == myQuantity).FirstOrDefault();
                if (decType != null)
                {
                    return decType.Name + " (" + decType.UnitOfMeasurement.Name + ")";
                }
            }

            return string.Empty;
        }
        
    }
}