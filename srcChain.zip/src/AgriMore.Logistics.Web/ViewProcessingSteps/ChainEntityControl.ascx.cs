using System;
using System.Web.UI;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public partial class ChainEntityControl : UserControl
    {
        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        /// <summary>
        /// Adds the location control.
        /// </summary>
        /// <param name="control">The control.</param>
        public void AddLocationControl(LocationControl control)
        {
            control.ID = this.ID + "LOC" + control.ID;
            LocationPlaceHolder.Controls.Add(control);
            //control.ParentClick += new EventHandler(locationControl_ParentClick);
        }

        //void locationControl_ParentClick(object sender, EventArgs e)
        //{
            
        //}

        /// <summary>
        /// Initializes the specified chain entity.
        /// </summary>
        /// <param name="chainEntity">The chain entity.</param>
        public void Initialize(ChainEntity chainEntity)
        {
            LabelName.Text = chainEntity.Name;
        }

    }
}