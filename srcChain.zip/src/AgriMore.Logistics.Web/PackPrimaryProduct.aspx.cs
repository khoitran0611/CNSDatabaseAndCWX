using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Web.Helpers;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using System.Text;
using System.Web.Services;
using Newtonsoft.Json;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PackageDetail : BasePage
    {
        private const long wholesalePackage = 1;
        private const string dataTextField = "Name";
        private const string deletepp = "deletepp";
        private string invalidinputtext = Resources.Localization.Thereisaninvaliditem;
        private const string packageid = "packageid";
        private const string primaryproducts = "primaryproducts";
        private const string referenceIdentification = "referenceIdentification";
        private const string space = " ";
        private const string uid = "Uid";
        private const string urlDefault = "Default.aspx";
        private const string name = "Name";
        private const string receivers = "Receiver";
        private string InvalidAmountMessage = "";
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            ErrorHelper.SetErrorLabel(false, string.Empty, LabelError, false);

            try
            {
                if (!IsPostBack)
                {
                    hdfCurrentOrgId.Value = RepositoryHelper.GetChainEntityForCurrentUser().Uid.ToString();
                    ClearData();
                    Session.Remove(primaryproducts);
                    Session.Remove(packageid);
                    Session.Remove(referenceIdentification);

                    SetInitialPageValues();

                    //BindingProduct();

                    BindReceivers();
                    BindingUnpackedProducts(RepositoryHelper.GetChainEntityForCurrentUser().Uid);
                    BindPackageTypes();
                    BindDataFor3rdPartyDropdown();
                    HandleDropdownPackageTypeChange();
                }
                FillDataForSelectedUnPackedProduct(ddlUnpackedProduct.SelectedValue != "" ? Int64.Parse(ddlUnpackedProduct.SelectedValue) : 0);
                lblAmountErrorMessage.Visible = false;
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Binds the receivers.
        /// </summary>
        private void BindReceivers()
        {
            Role receiverRole = repositoryFactory.GetRoleRepository().GetOne(receivers);

            DropDownListReceivers.DataSource = repositoryFactory.GetChainEntityRepository().Find(new ChainEntiyByRoleSpecification(receiverRole));
            DropDownListReceivers.DataTextField = name;
            DropDownListReceivers.DataValueField = uid;
            DropDownListReceivers.DataBind();
        }

        /// <summary>
        /// Sets the initial values.
        /// </summary>
        private void SetInitialPageValues()
        {
            LabelError.Visible = false;

            SetAddPPControlsAfterSave(true);

            DateTimeControlPacking.SetStartDateTime(DateTime.Now);

            GridViewPP.DataKeyNames = new string[] { uid };
        }

        /// <summary>
        /// Binds the package types.
        /// </summary>
        private void BindPackageTypes()
        {
            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

            IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(CurLangCode, 0, ddlProduct.SelectedValue != "" ? Int64.Parse(ddlProduct.SelectedValue) : 0, chainEntity.Uid);

            Session["packageTypes"] = packageTypes;
            DropDownListPackageType.DataSource = packageTypes; //repositoryFactory.GetPackageTypeRepository();
            DropDownListPackageType.DataTextField = "name";
            DropDownListPackageType.DataValueField = "uid";
            DropDownListPackageType.DataBind();

            FillDataForSelectedPackageTypes();
        }

        private void BindingProduct()
        {
            var selectedVal = ddlUnpackedProduct.SelectedValue;
            var chainEntityId = RepositoryHelper.GetChainEntityForCurrentUser().Uid;

            if (hdfProductSupplyId.Value != "0")
            {
                selectedVal = hdfProductSupplyId.Value;
            }

            ddlProduct.Items.Clear();
            var lstproductSupply = new List<ProductSupply>();
            if (txtProducer.Text == string.Empty)
            {
                lstproductSupply = ProductServices.GetUnpackedProductList(chainEntityId);
            }
            else
            {
                lstproductSupply = ProductServices.GetUnpackedProductByOrgIdList(chainEntityId.ToString() + ";" + txtProducer.Text);
            }

            Product product = lstproductSupply.Where(it => it.Uid.ToString() == selectedVal).FirstOrDefault().Product;

            ddlProduct.Items.Add(new ListItem(product.Name, product.Uid.ToString()));

            hdnMatchingAmount.Value = product != null ? lstproductSupply.Where(it => it.Uid.ToString() == selectedVal).FirstOrDefault().Amount.ToString() : "0";

            //ddlProduct.Items.Clear();
            //IList<Product> lstSpecies = ProductServices.GetProductList();
            //var listItems = lstSpecies.Select(it => new ListItem(it.Name, it.Uid.ToString())).ToArray();
            //ddlProduct.Items.AddRange(listItems);
        }

        private void BindingUnpackedProducts(long chainEntityId)
        {
            ddlUnpackedProduct.Items.Clear();
            var lstproductSupply = new List<ProductSupply>();
            if (txtProducer.Text == string.Empty)
            {
                lstproductSupply = ProductServices.GetUnpackedProductList(chainEntityId);
            }
            else
            {
                lstproductSupply = ProductServices.GetUnpackedProductByOrgIdList(chainEntityId.ToString() + ";" +  txtProducer.Text);
            }

            lstproductSupply = lstproductSupply.OrderByDescending(it => it.Uid).ToList();
            if (lstproductSupply.Count > 0)
            {
                var listItems = lstproductSupply.Select(it => new ListItem("ID: " + it.Uid + " " + it.Product.Name + " - " + it.Amount + " " + it.UoM.Name, it.Uid.ToString())).ToArray();
                ddlUnpackedProduct.Items.AddRange(listItems);
                BindingProduct();
            }    
                                
            //BindPackageTypes();

        }

        /// <summary>
        /// Handles the Click event of the LinkButtonCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonCancel_Click(object sender, EventArgs e)
        {
            HandleCancel();
        }

        /// <summary>
        /// Handles the cancel.
        /// </summary>
        private void HandleCancel()
        {
            try
            {
                Session.Remove(primaryproducts);
                Session.Remove(packageid);

                Response.Redirect(urlDefault, false);
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonOK control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonOK_Click(object sender, EventArgs e)
        {
            HandleOk();
        }

        /// <summary>
        /// Handles the ok.
        /// </summary>
        private void HandleOk()
        {
            //Validate the amount of product can't exceed the maximum amount which is get from Matching for that product
            if (!ValidateAmountOfPrimaryProduct() && InvalidAmountMessage != "")
            {
                lblAmountErrorMessage.Visible = true;
                lblAmountErrorMessage.Font.Bold = true;
                lblAmountErrorMessage.ForeColor = System.Drawing.Color.Red;
                lblAmountErrorMessage.Text = InvalidAmountMessage;
                //return;
            }
            else
            {
                Page.Validate();

                if (Page.IsValid)
                {
                    TransactionManager transactionManager = new TransactionManager();

                    try
                    {
                        transactionManager.BeginTransaction();

                        ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

                        long to;
                        long from = ValidateIdentifications(out to, chainEntity);

                        long fromNumeric = 0;
                        ChainEntity receiver = null;

                        if (AddReceiverIdentifications())
                        {
                            receiver = repositoryFactory.GetChainEntityRepository().GetOne(long.Parse(DropDownListReceivers.SelectedValue));

                            ValidateReceiverIdentifications(from, to, receiver);

                            fromNumeric = int.Parse(TextBoxReceiverIdFrom.Text);
                        }

                        List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];
                        PackagingDefine packageType = null;
                        if (packageTypes.Any())
                        {
                            packageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
                        }

                        //PackageType packageType = GetSelectedPackageType();

                        IDictionary<string, PrimaryProduct> ppd = GetPrimaryProductsFromSession();

                        ValidatePresenceOfPrimaryProducts(ppd);

                        ICollection<PrimaryProduct> primaryProducts;

                        primaryProducts = GetPrimaryProducts(ppd);

                        DateTime dateTimeOfPacking = DateTimeControlPacking.GetDatetime();

                        List<Identification> packageIdentifications = new List<Identification>();
                        ICollection<Identification> receiverPackageIdentifications = null;

                        packageIdentifications = GetPackageIdentifications(chainEntity, from, to);
                        List<Identification> packIden = new List<Identification>();

                        //Add data for shipper reference                    
                        foreach (var iden in packageIdentifications)
                        {
                            iden.ReferenceFrom = txtShipperReferenceFrom.Text;
                            iden.ReferenceTo = txtShipperReferenceTo.Text;
                            packIden.Add(iden);
                        }

                        if (AddReceiverIdentifications())
                        {
                            List<Identification> receiverIden = new List<Identification>();
                            receiverPackageIdentifications = GetPackageIdentifications(receiver, fromNumeric, fromNumeric + (to - from));

                            //Add Reference data
                            foreach (var iden in receiverPackageIdentifications)
                            {
                                iden.ReferenceFrom = txtReceiverReferenceFrom.Text;
                                iden.ReferenceTo = txtReceiverReferenceTo.Text;
                                receiverIden.Add(iden);
                            }

                            packIden.AddRange(receiverIden);

                        }

                        //Validate the Identification in dynamic block
                        List<ReferenceIdentificationInfo> rIdenList = GetReferenceAndIdentificationFromSession();
                        if (rIdenList.Any())
                        {
                            foreach (var rIden in rIdenList)
                            {
                                var chainEnt = repositoryFactory.GetChainEntityRepository().GetOne(rIden.ChainEntityId);
                                //Set identification range
                                Identification identification = new Identification(rIden.IdentificationFrom, chainEnt, rIden.IdentificationFrom == "" ? 0 : Int32.Parse(rIden.IdentificationFrom),
                                    rIden.IdentificationTo == "" ? 0 : Int32.Parse(rIden.IdentificationTo), rIden.ReferenceFrom, rIden.ReferenceTo);
                                //identification.FromUid = Int32.Parse(rIden.IdentificationFrom);
                                //identification.ToUid = Int32.Parse(rIden.IdentificationTo);

                                packIden.Add(identification);
                            }
                        }

                        Package pack;

                        if (TextBoxArticleCode.Text.Length == 0)
                        {
                            pack = new Package(packageType.Uid, primaryProducts, dateTimeOfPacking, packIden, string.Empty, from, to, packageType.PackTypeCategory.Uid, packageType.Name,
                                expiredDatetrlStart.GetDatetime(), expiredDateCtrlEnd.GetDatetime(), bestBeforeDateCtrl.GetDatetime());
                        }
                        else
                        {
                            pack = new Package(packageType.Uid, primaryProducts, dateTimeOfPacking, packIden,
                                            TextBoxArticleCode.Text, from, to, packageType.PackTypeCategory.Uid, packageType.Name,
                                            expiredDatetrlStart.GetDatetime(), expiredDateCtrlEnd.GetDatetime(), bestBeforeDateCtrl.GetDatetime());
                        }

                        repositoryFactory.GetPackageRepository().Add(pack);

                        //Update the packed status for primary products in Matching
                        UpdatePackedStatusForProductsInMatching(primaryProducts.ToList());
                        //TODO: Need the api here to update data to Matching, and so the packaging invoice is updated acordingly
                        updataDataForPackagingInvoiceInMatching(pack);
                        transactionManager.CommitTransaction();
                        Session.Remove(primaryproducts);
                        Session.Remove(packageid);
                        Session.Remove(referenceIdentification);
                        //Response.Redirect(urlDefault, false);
                        Response.Redirect(string.Format("{0}?{1}={2}&{3}={4}", urlDefault, WebConstants.InfoMsg, (long)InfoMessage.PackSuccessful,
                        WebConstants.InfoDtl, string.Format("{0},{1},{2},{3}", pack.Uid, packIden[0].Id, pack.FromUid, pack.ToUid)), false);
                    }

                    catch (ArgumentNullException exception)
                    {
                        Session.Remove(referenceIdentification);
                        transactionManager.RollbackTransaction();
                        ErrorHelper.SetErrorLabel(true, invalidinputtext + space + exception.Message, LabelError, false);
                    }
                    catch (ArgumentException exception)
                    {
                        Session.Remove(referenceIdentification);
                        transactionManager.RollbackTransaction();
                        ErrorHelper.SetErrorLabel(true, invalidinputtext + space + exception.Message, LabelError, false);
                    }
                    catch (Exception exception)
                    {
                        Session.Remove(referenceIdentification);
                        ErrorHelper.HandleException(exception, transactionManager, LabelError);
                    }
                }
            }
        }

        /// <summary>
        /// Validates the presence of primary products.
        /// </summary>
        /// <param name="ppd">The PPD.</param>
        private static void ValidatePresenceOfPrimaryProducts(IDictionary<string, PrimaryProduct> ppd)
        {
            if (ppd == null)
            {
                throw new ArgumentException(Resources.Localization.Noprimaryproductsareadded);
            }
        }

        /// <summary>
        /// Adds the receiver identifications.
        /// </summary>
        /// <returns></returns>
        private bool AddReceiverIdentifications()
        {
            return DropDownListReceivers.Visible && TextBoxReceiverIdFrom.Text.Trim().Length > 0;
        }

        /// <summary>
        /// Validates the receiver identifications.
        /// </summary>
        /// <param name="from">From.</param>
        /// <param name="to">To.</param>
        /// <param name="receiver">The receiver.</param>
        private void ValidateReceiverIdentifications(long from, long to, ChainEntity receiver)
        {
            long receiverFrom;
            long receiverTo;

            bool fromIsNumeric = Int64.TryParse(TextBoxReceiverIdFrom.Text, out receiverFrom);
            bool toIsNumeric = Int64.TryParse(TextBoxReceiverIdTo.Text, out receiverTo);

            if (fromIsNumeric == false)
            {
                throw new ArgumentException(Resources.Localization.Thefromidentificationisnotnumeric);
            }

            if (TextBoxReceiverIdTo.Text == string.Empty)
            {
                receiverTo = receiverFrom;
            }
            else
            {
                if (toIsNumeric == false)
                {
                    throw new ArgumentException(Resources.Localization.Thetoidentificationisnotnumeric);
                }
            }

            if (TextBoxReceiverIdTo.Text == string.Empty)
            {
                receiverTo = receiverFrom;
            }

            if (receiverFrom > receiverTo)
            {
                throw new ArgumentException(Resources.Localization.Thefromidcannotbegreaterthanthetoidentification);
            }

            if (to - from != receiverTo - receiverFrom)
            {
                throw new ArgumentException(Resources.Localization.Thenumberofidentificationsarenotequal);
            }

            if (receiverFrom < 0 || receiverTo < 0)
            {
                throw new ArgumentException(Resources.Localization.Identificationscannotbenegative);
            }

            ValidateIdentificationsExistance(receiverFrom, receiverTo, receiver);
        }

        /// <summary>
        /// 
        /// </summary>
        private static void ValidateIdentificationsExistance(long from, long to, ChainEntity chainEntity)
        {
            for (long counter = from; counter <= to; counter++)
            {
                if (RepositoryHelper.IdentificationExists(counter.ToString(), chainEntity))
                {
                    throw new ArgumentException(Resources.Localization.Theidentificationisalreadyused);
                }
            }
        }

        ///// <summary>
        ///// Gets the package identifications.
        ///// </summary>
        ///// <param name="counter">The counter.</param>
        ///// <param name="chainEntity">The chain entity.</param>
        ///// <returns></returns>
        //private static List<Identification> GetPackageIdentifications(int counter, ChainEntity chainEntity, int fromUid, int toUid)
        //{
        //    List<Identification> packageIdentifications = new List<Identification>();
        //    Identification identification = new Identification(counter.ToString(), chainEntity, fromUid, toUid);
        //    packageIdentifications.Add(identification);
        //    return packageIdentifications;
        //}

        /// <summary>
        /// Gets the package identifications.
        /// </summary>
        /// <param name="chainEntity">The chain entity.</param>
        /// <param name="fromUid">From uid.</param>
        /// <param name="toUid">To uid.</param>
        /// <returns></returns>
        private static List<Identification> GetPackageIdentifications(ChainEntity chainEntity, long fromUid, long toUid)
        {
            List<Identification> packageIdentifications = new List<Identification>();
            Identification identification = new Identification(string.Empty, chainEntity, fromUid, toUid);
            packageIdentifications.Add(identification);
            return packageIdentifications;
        }

        /// <summary>
        /// Gets the primary products and removes the uids and puts them in a icollection.
        /// </summary>
        /// <param name="ppd">The PPD.</param>
        /// <returns></returns>
        private static ICollection<PrimaryProduct> GetPrimaryProducts(IEnumerable<KeyValuePair<string, PrimaryProduct>> ppd)
        {
            ICollection<PrimaryProduct> primaryProducts;

            if (ppd != null)
            {
                primaryProducts = new Collection<PrimaryProduct>();

                foreach (KeyValuePair<string, PrimaryProduct> pp in ppd)
                {
                    pp.Value.Uid = 0;
                    primaryProducts.Add(pp.Value);
                }
            }
            else
            {
                throw new ArgumentException(Resources.Localization.NoPrimaryproduct);
            }

            if (primaryProducts.Count == 0)
            {
                throw new ArgumentException(Resources.Localization.NoPrimaryproduct);
            }

            return primaryProducts;
        }

        /// <summary>
        /// Gets the type of the selected package.
        /// </summary>
        /// <returns></returns>
        private PackageType GetSelectedPackageType()
        {
            return repositoryFactory.GetPackageTypeRepository().GetOne(long.Parse(DropDownListPackageType.SelectedValue));
        }

        /// <summary>
        /// Validates the identifications.
        /// </summary>
        /// <param name="to">To.</param>
        /// <param name="chainEntity">The chain entity.</param>
        /// <returns></returns>
        private long ValidateIdentifications(out long to, ChainEntity chainEntity)
        {
            long from;

            bool fromIsNumeric = Int64.TryParse(TextBoxPackageIdentification.Text, out from);
            bool toIsNumeric = Int64.TryParse(TextBoxTot.Text, out to);

            if (fromIsNumeric == false)
            {
                throw new ArgumentException(Resources.Localization.Thefromidentificationisnotnumeric);
            }

            if (TextBoxTot.Text == string.Empty)
            {
                to = from;
            }
            else
            {
                if (toIsNumeric == false)
                {
                    throw new ArgumentException(Resources.Localization.Thetoidentificationisnotnumeric);
                }
            }

            if (from > to)
            {
                throw new ArgumentException(Resources.Localization.Thefromidcannotbegreaterthanthetoidentification);
            }

            if (from < 0 || to < 0)
            {
                throw new ArgumentException(Resources.Localization.Identificationscannotbenegative);
            }

            long tempId = from;

            for (long counter = tempId; counter <= to; counter++)
            {
                if (RepositoryHelper.IdentificationExists(tempId.ToString(), chainEntity))
                {
                    throw new ArgumentException(Resources.Localization.Theidentificationisalreadyused);
                }

                tempId++;
            }

            return from;
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonBack control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonBack_Click(object sender, EventArgs e)
        {
            try
            {
                Session.Remove(primaryproducts);
                Session.Remove(packageid);

                Response.Redirect(urlDefault, false);
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonAddPP control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonAddPP_Click(object sender, EventArgs e)
        {
            try
            {
                SetAddPPControlsAfterSave(false);
                FillDataForSelectedUnPackedProduct(ddlUnpackedProduct.SelectedValue != "" ? Int64.Parse(ddlUnpackedProduct.SelectedValue) : 0);
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonSavePP control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonSavePP_Click(object sender, EventArgs e)
        {
            try
            {
                txtProdAmount.Text = Request["ctl00$MainContent$txtProdAmount"].ToString();
                var maximumAmount = Decimal.Parse(hdnMatchingAmount.Value);
                decimal actualAmount = 0;
                var canParse = Decimal.TryParse(txtProdAmount.Text, out actualAmount);

                if ((actualAmount > maximumAmount || !canParse))
                {
                    lblAmountErrorMessage.Text = "The amount must be numeric and not greater than " + maximumAmount.ToString();
                    lblAmountErrorMessage.ForeColor = System.Drawing.Color.Red;
                    lblAmountErrorMessage.Font.Bold = true;
                    lblAmountErrorMessage.Visible = true;
                    //return;
                }
                else
                {
                    lblAmountErrorMessage.Visible = false;

                    Page.Validate();

                    if (Page.IsValid)
                    {
                        IDictionary<string, PrimaryProduct> primaryProducts = GetPrimaryProductsFromSession();

                        primaryProducts = CreatePrimaryProductsList(primaryProducts);

                        if (InputIsValid())
                        {
                            PrimaryProductPresent(primaryProducts);

                            PrimaryProduct primaryProduct = CreateNewPrimaryProduct();

                            primaryProduct.Uid = GetNewUid(primaryProducts);

                            if (!primaryProducts.ContainsKey(primaryProduct.ToString()))
                            {
                                primaryProducts.Add(primaryProduct.Uid.ToString(), primaryProduct);

                                BindGridViewPP(primaryProducts);

                                SetAddPPControlsAfterSave(true);
                            }

                            txtProdAmount.Text = "";
                        }
                    }
                    else
                    {
                        txtProdAmount.Text = Request["ctl00$MainContent$txtProdAmount"].ToString();
                        return;
                    }
                }
            }
            catch (ArgumentException exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.Message, LabelError, false);
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Sets the add PP controls after save.
        /// </summary>
        /// <param name="isAfterSave">if set to <c>true</c> [is after save].</param>
        private void SetAddPPControlsAfterSave(bool isAfterSave)
        {
            LinkButtonSavePP.Enabled = !isAfterSave;
            LinkButtonAddPP.Enabled = isAfterSave;

            TextBoxProductionAreaId.Text = string.Empty;
            TextBoxProductionAreaId.Enabled = !isAfterSave;
            TextBoxProductionAreaId.Visible = !isAfterSave;
            LabelProductionAreaId.Visible = !isAfterSave;

            TextBoxLifeCycleId.Text = string.Empty;
            TextBoxLifeCycleId.Visible = !isAfterSave;
            TextBoxLifeCycleId.Enabled = !isAfterSave;
            LabelLifeCycleId.Visible = !isAfterSave;

            TextBoxDescription.Text = string.Empty;
            TextBoxDescription.Visible = !isAfterSave;
            TextBoxDescription.Enabled = !isAfterSave;
            LabelDescription.Visible = !isAfterSave;

            txtProdAmount.Text = string.Empty;
            lblProdName.Visible = !isAfterSave;
            ddlProduct.Visible = !isAfterSave;
            lblProdAmount.Visible = !isAfterSave;
            txtProdAmount.Visible = !isAfterSave;
            txtProdAmount.Enabled = !isAfterSave;
            ddlUoM.Visible = !isAfterSave;
            lblUnpackedProducts.Visible = !isAfterSave;
            ddlUnpackedProduct.Visible = !isAfterSave;

            lblProducer.Visible = !isAfterSave;
            txtProducer.Visible = !isAfterSave;

            GridViewPP.Enabled = isAfterSave;
        }

        /// <summary>
        /// Creates the new primary product.
        /// </summary>
        /// <returns></returns>
        private PrimaryProduct CreateNewPrimaryProduct()
        {
            var primaryProduct = new PrimaryProduct(TextBoxProductionAreaId.Text, TextBoxLifeCycleId.Text, TextBoxDescription.Text)
                                 {
                                     ProductUid = Convert.ToInt32(ddlProduct.SelectedValue),
                                     MatchingProdId = Convert.ToInt32(ddlUnpackedProduct.SelectedValue),
                                     ProductName = ddlUnpackedProduct.SelectedItem.Text,
                                     ProductAmount = Convert.ToDecimal(Request["ctl00$MainContent$txtProdAmount"].ToString()),
                                     Uom = repositoryFactory.GetUnitOfMeasurementRepository().GetOne(Convert.ToInt64(ddlUoM.SelectedValue))
                                 };

            return primaryProduct;
        }

        /// <summary>
        /// Creates the primary products list.
        /// </summary>
        /// <param name="primaryProducts">The primary products.</param>
        /// <returns></returns>
        private IDictionary<string, PrimaryProduct> CreatePrimaryProductsList(IDictionary<string, PrimaryProduct> primaryProducts)
        {
            if (primaryProducts == null)
            {
                primaryProducts = new Dictionary<string, PrimaryProduct>();
                Session.Add(primaryproducts, primaryProducts);
            }
            return primaryProducts;
        }

        /// <summary>
        /// Gets the new uid.
        /// </summary>
        /// <param name="primaryProducts">The primary products.</param>
        /// <returns></returns>
        private static long GetNewUid(IEnumerable<KeyValuePair<string, PrimaryProduct>> primaryProducts)
        {
            long id = 0;

            foreach (KeyValuePair<string, PrimaryProduct> pair in primaryProducts)
            {
                if (pair.Value.Uid > id)
                {
                    id = pair.Value.Uid;
                }
            }
            return id + 1;
        }

        /// <summary>
        /// Inputs the is valid.
        /// </summary>
        /// <returns></returns>
        private bool InputIsValid()
        {
            return TextBoxProductionAreaId.Text.Trim().Length != 0 && TextBoxLifeCycleId.Text.Trim().Length != 0;
        }

        /// <summary>
        /// Primaries the product is not present.
        /// </summary>
        /// <returns></returns>
        private void PrimaryProductPresent(IDictionary<string, PrimaryProduct> primaryProducts)
        {
            if (primaryProducts != null)
            {
                foreach (PrimaryProduct product in primaryProducts.Values)
                {
                    if (product.ProductionAreaId == TextBoxProductionAreaId.Text.Trim() &&
                        product.LifeCycleId == TextBoxLifeCycleId.Text.Trim())
                    {
                        throw new ArgumentException(Resources.Localization.Primaryproductisalreadypresent);
                    }
                }
            }
        }

        /// <summary>
        /// Handles the RowCommand event of the GridViewPP control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewCommandEventArgs"/> instance containing the event data.</param>
        protected void GridViewPP_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToLower().Equals(deletepp))
                {
                    long id = GetSelectedId(e);

                    IDictionary<string, PrimaryProduct> primaryProducts = GetPrimaryProductsFromSession();

                    if (primaryProducts != null)
                    {
                        primaryProducts.Remove(id.ToString());

                        BindGridViewPP(primaryProducts);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Gets the selected id.
        /// </summary>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.CommandEventArgs"/> instance containing the event data.</param>
        /// <returns></returns>
        private long GetSelectedId(CommandEventArgs e)
        {
            return (long)
                   GridViewPP.DataKeys[int.Parse((string)e.CommandArgument, CultureInfo.CurrentCulture)].Value;
        }

        /// <summary>
        /// Gets the primary products from session.
        /// </summary>
        /// <returns></returns>
        private IDictionary<string, PrimaryProduct> GetPrimaryProductsFromSession()
        {
            return Session[primaryproducts] as IDictionary<string, PrimaryProduct>;
        }


        /// <summary>
        /// Binds the grid view PP.
        /// </summary>
        /// <param name="primaryProducts">The primary products.</param>
        private void BindGridViewPP(IDictionary<string, PrimaryProduct> primaryProducts)
        {
            GridViewPP.DataSource = primaryProducts.Values;
            GridViewPP.DataBind();
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the DropDownListPackageType control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void DropDownListPackageType_SelectedIndexChanged(object sender, EventArgs e)
        {
            HandleDropdownPackageTypeChange();
        }

        /// <summary>
        /// Handles the dropdown package type change.
        /// </summary>
        private void HandleDropdownPackageTypeChange()
        {
            try
            {
                //Refactor
                //SetPackageTypeInfo();
                BindingUnpackedProducts(RepositoryHelper.GetChainEntityForCurrentUser().Uid);
                FillDataForSelectedUnPackedProduct(ddlUnpackedProduct.SelectedValue != "" ? Int64.Parse(ddlUnpackedProduct.SelectedValue) : 0);
                FillDataForSelectedPackageTypes();

                //Refactor
                //PackageType packageType =
                //    repositoryFactory.GetPackageTypeRepository().GetOne(long.Parse(DropDownListPackageType.SelectedValue));

                //SetReceiverIdentificationControls(packageType.PackageTypeCategory.Name == "retailPackaging");

                List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];
                PackagingDefine packageType = null;
                if (packageTypes.Any())
                {
                    if (DropDownListPackageType.SelectedValue != "")
                    {
                        packageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
                    }
                }

                if (packageType != null)
                {
                    SetReceiverIdentificationControls(packageType.PackTypeCategory.Uid == 2 || packageType.PackTypeCategory.Uid == 3 
                        || packageType.PackTypeCategory.Uid == 1 || packageType.PackTypeCategory.Uid == 4); //retailpackaging or Consumer
                }
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Sets the receiver identification controls.
        /// </summary>
        private void SetReceiverIdentificationControls(bool isVisible)
        {
            if (!isVisible)
            {
                TextBoxReceiverIdFrom.Text = string.Empty;
                TextBoxReceiverIdTo.Text = string.Empty;
                txtReceiverReferenceFrom.Text = string.Empty;
                txtReceiverReferenceTo.Text = string.Empty;
            }

            TextBoxReceiverIdFrom.Visible = isVisible;
            TextBoxReceiverIdTo.Visible = isVisible;

            LabelReceiverIdFrom.Visible = isVisible;
            LabelRecieverIdTo.Visible = isVisible;

            LabelReceiver.Visible = isVisible;
            LabelIdentificationReceiver.Visible = isVisible;

            DropDownListReceivers.Visible = isVisible;
            DropDownListReceivers.Enabled = isVisible;

            txtReceiverReferenceFrom.Visible = isVisible;
            txtReceiverReferenceTo.Visible = isVisible;

            lblReceiverReferenceFrom.Visible = isVisible;
            lblReceiverReferenceTo.Visible = isVisible;
            lblReceiverReference.Visible = isVisible;
        }

        /// <summary>
        /// Sets the package type info.
        /// </summary>
        private void SetPackageTypeInfo()
        {
            PackageType packageType =
                repositoryFactory.GetPackageTypeRepository().GetOne(long.Parse(DropDownListPackageType.SelectedValue));

            LabelSealed.Text = packageType.IsSealed.ToString();
            LabelVentilated.Text = packageType.IsVentilated.ToString();
            LabelMaterial.Text = packageType.PackingMaterial.Name;
            LabelWidth.Text = packageType.Width.Value + space + packageType.Width.UnitOfMeasurement.Name;
            LabelHeight.Text = packageType.Height.Value + space + packageType.Height.UnitOfMeasurement.Name;
            LabelLenght.Text = packageType.Lenght.Value + space + packageType.Lenght.UnitOfMeasurement.Name;
            LabelWeight.Text = packageType.Weight.Value + space + packageType.Weight.UnitOfMeasurement.Name;
        }

        protected void ddlUnpackedProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            long selectedUnpackedProduct = 0;

            if (hdfProductSupplyId.Value != "0")
            {
                selectedUnpackedProduct = Int64.Parse(hdfProductSupplyId.Value);
            }else {
                selectedUnpackedProduct = Int64.Parse(ddlUnpackedProduct.SelectedValue);
            }
                         
            FillDataForSelectedUnPackedProduct(selectedUnpackedProduct);
            BindingProduct();
            BindPackageTypes();
            BindingUnpackedProducts(RepositoryHelper.GetChainEntityForCurrentUser().Uid);
        }

        ///// <summary>
        ///// Handles the RowDataBound event of the GridViewPP control.
        ///// </summary>
        ///// <param name="sender">The source of the event.</param>
        ///// <param name="e">The <see cref="GridViewRowEventArgs"/> instance containing the event data.</param>
        //protected void GridViewPpRowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    var primaryProd = e.Row.DataItem as PrimaryProduct;
        //    if (primaryProd == null) return;

        //    ((Label)e.Row.FindControl("lblAmount")).Text = string.Format("{0} {1}", primaryProd.ProductAmount, primaryProd.Uom.Name);
        //}

        private void FillDataForSelectedUnPackedProduct(long selectedUnpackedProduct)
        {
            if (hdfProductSupplyId.Value != "0")
            {
                selectedUnpackedProduct = Int64.Parse(hdfProductSupplyId.Value);
            }

            var chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();
            var lstproductSupply = new List<ProductSupply>();
            if (txtProducer.Text == string.Empty)
            {
                lstproductSupply = ProductServices.GetUnpackedProductList(chainEntity.Uid);
            }
            else
            {
                lstproductSupply = ProductServices.GetUnpackedProductByOrgIdList(chainEntity.Uid.ToString() + ";" + hdfOrgId.Value);
            }

            var productSupply = lstproductSupply.Where(ps => ps.Uid == selectedUnpackedProduct).FirstOrDefault();

            if (productSupply != null)
            {
                txtProdAmount.Text = productSupply.Amount.ToString();
                ddlUoM.Items.Clear();
                var listItems = productSupply.UoM;
                ddlUoM.Items.Add(new ListItem(listItems.Name, listItems.Uid.ToString()));
                hdnMatchingAmount.Value = productSupply.Amount.ToString();
            }
        }

        private void UpdatePackedStatusForProductsInMatching(List<PrimaryProduct> primaryProducts)
        {
            string prodIds = string.Join(",", Array.ConvertAll(primaryProducts.Select(it => it.MatchingProdId).ToArray(), Convert.ToString));
            IList<ProductSupply> listProdSupplies = ProductSupplyServices.GetByIds(prodIds);
            for (var i = 0;i<listProdSupplies.Count;i++)
            {
                var item = listProdSupplies[i];
                var selectedAmount = primaryProducts[i].ProductAmount;

                //First, need to check if the amount of available in matching enough for update the status
                if (item.Amount >= selectedAmount)
                {
                    //Firstly, update the amount in Matching so that it subtract the current amount with the selected amount
                    item.Amount = item.Amount - selectedAmount;
                    //Update status only if the Amount in Matching is 0
                    if (item.Amount == 0)
                    {
                        item.IsPackedByChain = true;
                    }

                    ProductSupplyServices.CreateOrUpdate(item);
                }
            }

        }

        private void FillDataForSelectedPackageTypes()
        {
            List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];

            if (packageTypes.Any())
            {
                if (DropDownListPackageType.SelectedValue != "")
                {
                    var selectedPackageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
                    LabelLenght.Text = selectedPackageType.LenghtValue + " " + selectedPackageType.LengthUoM.Name;
                    LabelWidth.Text = selectedPackageType.WidthValue + " " + selectedPackageType.WidthUoM.Name;
                    LabelWeight.Text = selectedPackageType.WeightValue + " " + selectedPackageType.WeightUoM.Name;
                    LabelHeight.Text = selectedPackageType.HeightValue + " " + selectedPackageType.HeightUoM.Name;
                    LabelMaterial.Text = selectedPackageType.PackagingMaterial.Name;
                    LabelSealed.Text = selectedPackageType.IsSealed.ToString();
                    LabelVentilated.Text = selectedPackageType.IsVantilated.ToString();
                }

            }
        }

        void updataDataForPackagingInvoiceInMatching(Package package)
        {
            List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];
            var seperator = "|";
            StringBuilder packagingInfo = new StringBuilder();
            PackagingDefine packageType = null;
            //Append Packaging name
            packageType = (package != null && packageTypes.Any()) ? packageTypes.Where(pt => pt.Uid == package.PackageTypeId).FirstOrDefault() : null;

            if (packageType != null)
            {
                packagingInfo.Append(packageType.Uid.ToString());
                packagingInfo.Append(seperator);
                packagingInfo.Append(packageType.Name);
                packagingInfo.Append(seperator);
            }
            else
            {
                packagingInfo.Append("");
            }

            if (package != null)
            {
                //Append the number of packages
                packagingInfo.Append((package.ToUid - package.FromUid + 1).ToString());
                packagingInfo.Append(seperator);

                //Append the matching product id
                if (package.PrimaryProducts.Any())
                {
                    string prodIds = string.Join(",", Array.ConvertAll(package.PrimaryProducts.Select(it => it.MatchingProdId).ToArray(), Convert.ToString));
                    IList<ProductSupply> listProdSupplies = ProductSupplyServices.GetByIds(prodIds);
                    foreach (var item in listProdSupplies)
                    {
                        packagingInfo.Append(item.Uid.ToString());
                        packagingInfo.Append(seperator);
                    }
                }
            }
            else
            {
                //Append the number of packages
                packagingInfo.Append("0");
                packagingInfo.Append(seperator);
            }

            ProductSupplyServices.UpdateDataForPackagingInvoiceInMatching(packagingInfo.ToString());
        }

        private void BindDataFor3rdPartyDropdown()
        {
            var chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

            var chainEntityId = chainEntity != null ? chainEntity.Uid.ToString() : "";

            List<AgriMore.Logistics.Domain.ThirdPartyEntities.ChainEntity1> listChainEntities = ProductSupplyServices.GetByChainEntitiesInGoOs(chainEntityId);

            ddlChainEntity.DataSource = listChainEntities;
            ddlChainEntity.DataTextField = "Name";
            ddlChainEntity.DataValueField = "Uid";
            ddlChainEntity.DataBind();
        }

        protected void btnAddRefAndIdentification_Click(Object sender, EventArgs e)
        {
            try
            {
                var chainEntity = repositoryFactory.GetChainEntityRepository().GetOne(long.Parse(ddlChainEntity.SelectedValue));

                if (!(txtIdenFrom.Text == string.Empty && txtIdenTo.Text == string.Empty))
                {
                    ValidateIdentifications(chainEntity, txtIdenFrom, txtIdenTo);
                }

                List<ReferenceIdentificationInfo> refIdenInfo = GetReferenceAndIdentificationFromSession();
                if (Page.IsValid)
                {
                    var id = refIdenInfo != null && refIdenInfo.Any() ? refIdenInfo.Count + 1 : 1;

                    var identificationReference = new ReferenceIdentificationInfo()
                    {
                        Id = id,

                        ChainEntityId = Int64.Parse(ddlChainEntity.SelectedValue),

                        IdentificationFrom = txtIdenFrom.Text,

                        IdentificationTo = txtIdenTo.Text,

                        ReferenceFrom = txtRefFrom.Text,

                        ReferenceTo = txtRefTo.Text
                    };

                    AddRefAndIdentificationInfoToSession(identificationReference);

                    BindDataForReferenceAndIdentification();

                    ClearData();

                }

            }
            catch (ArgumentException exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.Message, LabelError, false);
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }

        private long ValidateIdentifications(ChainEntity chainEntity, TextBox txtFrom, TextBox txtTo)
        {
            long from;
            long to;

            bool fromIsNumeric = Int64.TryParse(txtFrom.Text, out from);
            bool toIsNumeric = Int64.TryParse(txtTo.Text, out to);

            if (fromIsNumeric == false)
            {
                throw new ArgumentException(Resources.Localization.Thefromidentificationisnotnumeric);
            }

            if (txtTo.Text == string.Empty)
            {
                to = from;
            }
            else
            {
                if (toIsNumeric == false)
                {
                    throw new ArgumentException(Resources.Localization.Thetoidentificationisnotnumeric);
                }
            }

            if (from > to)
            {
                throw new ArgumentException(Resources.Localization.Thefromidcannotbegreaterthanthetoidentification);
            }

            if (from < 0 || to < 0)
            {
                throw new ArgumentException(Resources.Localization.Identificationscannotbenegative);
            }

            long tempId = from;

            for (long counter = tempId; counter <= to; counter++)
            {
                if (RepositoryHelper.IdentificationExists(tempId.ToString(), chainEntity))
                {
                    throw new ArgumentException(Resources.Localization.Theidentificationisalreadyused);
                }

                tempId++;
            }

            return from;
        }

        private List<ReferenceIdentificationInfo> GetReferenceAndIdentificationFromSession()
        {
            if (Session[referenceIdentification] == null) return new List<ReferenceIdentificationInfo>();
 
            return (List<ReferenceIdentificationInfo>)Session[referenceIdentification];
        }

        private List<ReferenceIdentificationInfo> AddRefAndIdentificationInfoToSession(ReferenceIdentificationInfo info)
        {
            List<ReferenceIdentificationInfo> refIdentificationList = new List<ReferenceIdentificationInfo>();

            if (Session[referenceIdentification] == null)
            {
                refIdentificationList.Add(info);
                Session[referenceIdentification] = refIdentificationList;
            }
            else
            {
                refIdentificationList = (List<ReferenceIdentificationInfo>)Session[referenceIdentification];
                refIdentificationList.Add(info);
                Session[referenceIdentification] = refIdentificationList;
            }

            return refIdentificationList;
        }

        protected void grdChainEntityRefAndIdentificationInfo_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToLower().Equals("deleteri"))
                {
                    long id = GetSelectedReferenceIdentificationId(e);

                    List<ReferenceIdentificationInfo> refIdenList = GetReferenceAndIdentificationFromSession();

                    var refIden = refIdenList != null ? refIdenList.Where(rI => rI.Id == id).FirstOrDefault() : null;

                    if (refIden != null)
                    {
                        refIdenList.Remove(refIden);
                        Session[referenceIdentification] = refIdenList;
                    }
                }

                BindDataForReferenceAndIdentification();

            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }

        private long GetSelectedReferenceIdentificationId(CommandEventArgs e)
        {
            return (long)Int64.Parse((string)e.CommandArgument, CultureInfo.CurrentCulture);
        }

        protected void grdChainEntityRefAndIdentificationInfo_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var refIden = e.Row.DataItem as ReferenceIdentificationInfo;
                var chainEnties = RepFactory.GetChainEntityRepository().AsCollection();
                var chainEntity = chainEnties.Where(ce => ce.Uid == refIden.ChainEntityId).FirstOrDefault();
                (e.Row.FindControl("lblChainEntity") as Label).Text = refIden != null ? (chainEntity != null ? chainEntity.Name : "") : "";
            }
        }

        private void BindDataForReferenceAndIdentification()
        {
            grdChainEntityRefAndIdentificationInfo.Visible = false;

            List<ReferenceIdentificationInfo> refIdentificationList = new List<ReferenceIdentificationInfo>();

            refIdentificationList = GetReferenceAndIdentificationFromSession();

            //Bind data for grid
            if (refIdentificationList.Any())
            {
                grdChainEntityRefAndIdentificationInfo.Visible = true;
                grdChainEntityRefAndIdentificationInfo.DataSource = refIdentificationList;
                grdChainEntityRefAndIdentificationInfo.DataBind();
            }
        }

        private void ClearData()
        {
            txtIdenFrom.Text = "";
            txtIdenTo.Text = "";
            txtRefFrom.Text = "";
            txtRefTo.Text = "";
            ddlChainEntity.SelectedIndex = 0;
        }

        protected void ddlChainEntity_SelectedIndexChanged(Object sender, EventArgs e)
        {
            var chainEntity = RepFactory.GetChainEntityRepository().GetOne(Int64.Parse(ddlChainEntity.SelectedValue));
        }

        protected void AmountValidator_ServerValidate(object sender, ServerValidateEventArgs args)
        {

            CustomValidator custom = sender as CustomValidator;

            if (Session[primaryproducts] == null)
            {
                txtProdAmount.Text = Request["ctl00$MainContent$txtProdAmount"].ToString();
                var maximumAmount = Decimal.Parse(hdnMatchingAmount.Value);
                decimal actualAmount = 0;
                var canParseAmount = Decimal.TryParse(txtProdAmount.Text, out actualAmount);

                if (actualAmount <= maximumAmount && canParseAmount)
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;

                    if (!args.IsValid && !lblAmountErrorMessage.Visible)
                    {
                        custom.ErrorMessage = "The amount must be numeric and not greater than " + maximumAmount.ToString();
                        txtProdAmount.Text = actualAmount.ToString();
                    }
                }
            }
            else
            {
                if (ValidateAmountOfPrimaryProduct() && InvalidAmountMessage == string.Empty)
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                }
            }
        }

        private bool ValidateAmountOfPrimaryProduct()
        {
            InvalidAmountMessage = "";
            var isValid = true;
            if (Session[primaryproducts] != null)
            {
                var dictionaryOfProducts = (Session[primaryproducts] as IDictionary<string, PrimaryProduct>);
                var products = (dictionaryOfProducts.Values).ToList();
                var matchingProductIds = products.Select(p => p.MatchingProdId).Distinct().ToList();
                foreach (var prodId in matchingProductIds)
                {
                    var productSupply = ProductSupplyServices.GetById(prodId);

                    var maximumAmount = productSupply.Amount;
                    var totalInputAmout = products.Where(p => p.MatchingProdId == prodId).Sum(p => p.ProductAmount);

                    if (totalInputAmout > maximumAmount)
                    {                        
                        isValid = false;
                        InvalidAmountMessage += "The total amount of package which has matching product id " + prodId.ToString() + " must be numeric and not greater than " + maximumAmount.ToString()
                             + ". It is now has total of " + totalInputAmout.ToString() + "<br/>";
                    }                                       
                }
            }

            return isValid;
        }
    }
}
