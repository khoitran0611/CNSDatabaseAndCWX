using System;
using System.Web.UI;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Web
{
    public partial class LocationPage : Page
    {
        /// <summary>
        /// Creates the package.
        /// </summary>
        /// <returns></returns>
        private Package CreatePackage()
        {
            Location location = new Location("id", "desc",
                                             new Address("street1", "8000BB", "city", "country", "ChainEntity 1"));
            Location location2 = new Location("id2", "desc",
                                              new Address("street1", "8000BB", "city", "country", "ChainEntity 1"));
            ChainEntity Ah = new ChainEntity("AH"
                                             ,
                                             new Location[]
                                                 {
                                                     location
                                                 });
            string validProductionAreaId = "AAAPA0800001";
            string validLifeCycleId = "AAAPC0800001";
            Package p = new Package(PackageType.FlowPack
                                    , new PrimaryProduct[] {new PrimaryProduct(validProductionAreaId, validLifeCycleId)}
                                    , DateTime.Now
                                    , new Identification[] {new Identification("124", Ah)});

            return p;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            RepositoryFactory rp = new RepositoryFactory();
            IRepository<Package> repository = rp.GetPackageRepository();

            Package package = CreatePackage();
            exposureControl.Initialize(package);

            if (Page.IsPostBack)
            {
                Page.Validate();

                if (Page.IsValid)
                {
                    ExposureDocument ed = exposureControl.GetExposureDocument(package);
                }
            }
        }

        protected void dd_Click(object sender, EventArgs e)
        {
        }
    }
}