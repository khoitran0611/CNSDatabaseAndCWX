using System;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public class ExposureView
    {
        private readonly string preStartValue;
        private readonly string preEndValue;
        private readonly string docValue;
        private readonly Exposure exposure;
        private readonly ExposureType exposureType;
        private readonly ExposureDefine exposureDefine;
        private bool isEnabled;

        public ExposureView(string preStartValue, string preEndValue, string docValue, ExposureType exposureType)
        {
            this.preStartValue = preStartValue;
            this.preEndValue = preEndValue;
            this.docValue = docValue;
            this.exposureType = exposureType;
        }

        public ExposureView(string preStartValue, string preEndValue, string docValue, ExposureDefine exposureDefine)
        {
            this.preStartValue = preStartValue;
            this.preEndValue = preEndValue;
            this.docValue = docValue;
            this.exposureDefine = exposureDefine;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ExposureView"/> class.
        /// </summary>
        /// <param name="exposure">The exposure.</param>
        /// <param name="exposureType">Type of the exposure.</param>
        /// <param name="isEnabled">if set to <c>true</c> [is enabled].</param>
        public ExposureView(Exposure exposure, ExposureType exposureType, bool isEnabled)
        {
            if (exposureType == null)
            {
                throw new ArgumentNullException("exposureType");
            }

            this.exposure = exposure;
            this.exposureType = exposureType;
            this.isEnabled = isEnabled;
        }


        public ExposureView(Exposure exposure, ExposureDefine exposureDefine, bool isEnabled)
        {
            if (exposureDefine == null)
            {
                throw new ArgumentNullException("exposureDefine");
            }

            this.exposure = exposure;
            this.exposureDefine = exposureDefine;            
            this.isEnabled = isEnabled;
        }



        /// <summary>
        /// Gets or sets a value indicating whether this instance is enabled.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is enabled; otherwise, <c>false</c>.
        /// </value>
        public bool IsEnabled
        {
            get { return isEnabled; }
            set { isEnabled = value; }
        }

        /// <summary>
        /// Gets the name of the exposure.
        /// </summary>
        /// <value>The name of the exposure.</value>
        public string ExposureName
        {
            get { return exposureType.Name; }
        }

        /// <summary>
        /// Gets the name of the unit of measure.
        /// </summary>
        /// <value>The name of the unit of measure.</value>
        public string UnitOfMeasureName
        {
            get { return exposureType.UnitOfMeasurement.Name; }
        }

        /// <summary>
        /// Gets the exposure.
        /// </summary>
        /// <value>The exposure.</value>
        public Exposure Exposure
        {
            get { return exposure; }
        }

        /// <summary>
        /// Gets the type of the exposure.
        /// </summary>
        /// <value>The type of the exposure.</value>
        public ExposureType ExposureType
        {
            get { return exposureType; }
        }

        public ExposureDefine ExposureDefine
        {
            get { return exposureDefine; }
        }

        public string PreStartValue
        {
            get { return preStartValue; }
        }

        public string PreEndValue
        {
            get { return preEndValue; }
        }

        public string DocValue
        {
            get { return docValue; }
        }
    }
}