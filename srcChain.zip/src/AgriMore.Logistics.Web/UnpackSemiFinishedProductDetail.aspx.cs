using System;
using System.Collections.Generic;
using System.Globalization;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using AgriMore.Logistics.Data.Services;
using System.Linq;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public partial class UnpackSemiFinishedProductDetail : AgriMorePage
    {
        private const string locationid = "locationid";
        private string messageLcationIsNull = Resources.Localization.locationisnull;
        private string messageNoValidLocationIdInSession = Resources.Localization.Nolocationidavailable;
        private const string packageid = "packageid";
        private const string urlDefault = "Default.aspx";
        private const string uid = "uid";
        private const string unpack = "unpack";
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();
        private Location location;

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            ErrorHelper.SetErrorLabel(false, string.Empty, LabelError, false);

            try
            {
                if (!IsPostBack)
                {
                    SetInitialPageValues();

                    if (Session[locationid] == null)
                    {
                        throw new NullReferenceException(messageNoValidLocationIdInSession);
                    }
                    else
                    {
                        MultiView1.SetActiveView(ViewList);

                        ExposuresControl.Visible = true;

                        BindPackagesWithSpecificLocation(GetLocationIdFromSession());
                    }
                }
            }
            catch (Exception exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Gets the location id from session.
        /// </summary>
        /// <returns></returns>
        private long GetLocationIdFromSession()
        {
            return long.Parse(Session[locationid] as string);
        }

        /// <summary>
        /// Sets the initial values.
        /// </summary>
        private void SetInitialPageValues()
        {
            DateTimeControlPacking.SetStartDateTime(DateTime.Now);
        }


        /// <summary>
        /// Binds the packages with specific location.
        /// </summary>
        /// <param name="locationId">The location id.</param>
        private void BindPackagesWithSpecificLocation(long locationId)
        {
            location = repositoryFactory.GetLocationRepository().GetOne(locationId);

            ICollection<Package> packages = GetPackagesInLocation();

            BindGridViewPackages(packages);
        }

        /// <summary>
        /// Binds the grid view packages.
        /// </summary>
        /// <param name="packages">The packages.</param>
        private void BindGridViewPackages(ICollection<Package> packages)
        {
            GridViewPackages.DataSource = packages;
            GridViewPackages.DataKeyNames = new string[] { uid };
            GridViewPackages.DataBind();
        }

        /// <summary>
        /// Gets the packages in location.
        /// </summary>
        /// <returns></returns>
        private ICollection<Package> GetPackagesInLocation()
        {
            return repositoryFactory.GetPackageRepository().Find(new PackageInLocationAndNotPackedOnce(location));
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonCancel_Click(object sender, EventArgs e)
        {
            try
            {
                MultiView1.SetActiveView(ViewList);
            }
            catch (Exception exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonOK control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonOK_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                var chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();
                TransactionManager transactionManager = new TransactionManager();

                ClearErrorLabel();

                DateTime dateTimeOfUnpacking = DateTimeControlPacking.GetDatetime();

                try
                {
                    transactionManager.BeginTransaction();

                    location = repositoryFactory.GetLocationRepository().GetOne(GetLocationIdFromSession());

                    if (location == null)
                    {
                        throw new NullReferenceException(messageLcationIsNull);
                    }

                    List<Package> unpackedPackages = new List<Package>();

                    long id = long.Parse(Session[packageid].ToString());
                    Package package = repositoryFactory.GetPackageRepository().GetOne(id);

                    ValidateFrom(new List<Package>(package.Children).Count);

                    unpackedPackages.AddRange(package.Unpack(dateTimeOfUnpacking));

                    repositoryFactory.GetPackageRepository().Store(package);

                    ExposureDocument ed = location.Remove(package, GetDateTimeOfUnpacking());

                    repositoryFactory.GetLocationRepository().Store(location);

                    PutUnpackedPackagesInLocation(unpackedPackages);

                    //PutUnpackedPackagesInLocation already flushed the repository. So there is no need to flush here.
                    RepositoryHelper.CreateProcessingSteps(package, ed, ProcessingStepType.RemovedFromLocation, RepositoryHelper.GetCurrentUser(), CreateVpsRemark(ed.DateOfRemoval));
                    IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(CurLangCode, 0, 0, chainEntity.Uid);
                    var disposalPack = new DisposalPackage
                                       {
                                           UnPackId = package.Uid,
                                           PackageTypeId = package.PackageTypeId,
                                           PackageTypeCategoryId = package.PackageTypeCategoryId,
                                           UnpackDate = GetDateTimeOfUnpacking(),
                                           UnpackLocationId = GetLocationIdFromSession(),
                                           Amount = (package.ToUid - package.FromUid) + 1,
                                           Status = DisposalPackingStatus.Unpacked,
                                           PackageMaterialId = packageTypes.Where(pt => pt.Uid == package.PackageTypeId).FirstOrDefault().PackagingMaterial.Uid
                                       };
                    
                    repositoryFactory.GetDisposalPackageRepository().Store(disposalPack);

                    //Insert a new row to WasteDisposalPackageTracing table to keep the trace in VPS later

                    if (unpackedPackages != null && unpackedPackages.Count > 0)
                    {
                        foreach (var up in unpackedPackages)
                        {
                            var wasteDisposalPackageTracing = new WasteDisposalPackageTracing()
                            {
                                DisposalPackageId = disposalPack.Uid,
                                ChildUnpackPackageId = up.Uid,
                                ParentUnpackPackageId = package.Uid
                            };

                            //Add to the table WasteDisposalPackageTracing 
                            repositoryFactory.GetWasteDisposalPackageTracingRepository().Store(wasteDisposalPackageTracing);
                        }
                    }
                    

                    transactionManager.CommitTransaction();

                    Session.Remove(packageid);
                    BindPackagesWithSpecificLocation(GetLocationIdFromSession());

                    MultiView1.SetActiveView(ViewList);
                }

                catch (ArgumentException exception)
                {
                    transactionManager.RollbackTransaction();
                    ErrorHelper.SetErrorLabel(true, exception.Message, LabelError, false);
                }

                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    ErrorHelper.HandleException(exception, transactionManager, LabelError);
                }
            }
        }

        /// <summary>
        /// Validates from.
        /// </summary>
        private void ValidateFrom(int numberOfPackages)
        {
            if (TextBoxPackageIdentification.Visible)
            {
                long from;
                bool result = long.TryParse(TextBoxPackageIdentification.Text, out from);

                if (result == false)
                {
                    throw new ArgumentException(Resources.Localization.Fromshouldbenumeric);
                }

                if (from < 0)
                {
                    throw new ArgumentException(Resources.Localization.Fromshouldbepositive);
                }

                ValidateIdentificationsExistance(from, from + numberOfPackages, GetChainEntityForCurrentUser());
            }
        }

        /// <summary>
        /// Creates the VPS remark.
        /// </summary>
        /// <param name="dateTime">The date time.</param>
        /// <returns></returns>
        private static string CreateVpsRemark(DateTime dateTime)
        {
            return
                String.Format(Resources.Localization.formatUnpackedSfpremovedfromlocation,
                              dateTime.ToString(ProcessingStepDocument.DateTimeFormat));
        }

        /// <summary>
        /// Puts the unpacked packages in location.
        /// </summary>
        /// <param name="unpackedPackages">The unpacked packages.</param>
        private void PutUnpackedPackagesInLocation(IEnumerable<Package> unpackedPackages)
        {
            long from = 0;

            if (AddNewIdentifications())
            {
                from = long.Parse(TextBoxPackageIdentification.Text);
            }

            User user = RepositoryHelper.GetCurrentUser();
            IRepository<Package> packageRepository = repositoryFactory.GetPackageRepository();

            foreach (Package package in unpackedPackages)
            {
                location.Put(package, ExposuresControl.GetExposureDocument(), GetDateTimeOfUnpacking());

                repositoryFactory.GetLocationRepository().Store(location);

                if (AddNewIdentifications())
                {
                    Identification identification = new Identification(from.ToString(), GetChainEntityForCurrentUser());
                    package.AddIdentification(identification);
                }

                packageRepository.Store(package);
                from++;
            }

            packageRepository.Flush();

            foreach (Package package in unpackedPackages)
            {
                RepositoryHelper.CreateProcessingSteps(package, package.CurrentExposureDocument, ProcessingStepType.Exposures, user, String.Format(ProcessingStepDocument.UnpackSfp, GetDateTimeOfUnpacking()));
            }

        }

        /// <summary>
        /// Adds the new id.
        /// </summary>
        /// <returns></returns>
        private bool AddNewIdentifications()
        {
            return TextBoxPackageIdentification.Visible;
        }

        /// <summary>
        /// Clears the error label.
        /// </summary>
        private void ClearErrorLabel()
        {
            LabelError.Text = string.Empty;
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonBack control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonBack_Click(object sender, EventArgs e)
        {
            try
            {
                Session.Remove(locationid);
                Response.Redirect(urlDefault, false);
            }
            catch (Exception exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.ToString(), LabelError, true);
            }
        }

        private ChainEntity chainEntityForCurrentUser;
        private ChainEntity GetChainEntityForCurrentUser()
        {
            if (chainEntityForCurrentUser == null)
            {
                chainEntityForCurrentUser = RepositoryHelper.GetChainEntityForCurrentUser();
            }
            return chainEntityForCurrentUser;
        }


        /// <summary>
        /// Gets the package identification for chain entity.
        /// </summary>
        /// <returns></returns>
        protected string GetPackageIdentificationForChainEntity(object packageRow)
        {
            Package package = packageRow as Package;

            return RepositoryHelper.CreatePackageName(package, GetChainEntityForCurrentUser());
        }

        /// <summary>
        /// Gets the date time of packing.
        /// </summary>
        /// <returns></returns>
        private DateTime GetDateTimeOfUnpacking()
        {
            return DateTimeControlPacking.GetDatetime();
        }

        /// <summary>
        /// Handles the RowCommand event of the GridViewPackages control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewCommandEventArgs"/> instance containing the event data.</param>
        protected void GridViewPackages_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToLower().Equals(unpack))
                {
                    // If no identifications are available for the childpackages show the control for new id's
                    long id = (long)
                              GridViewPackages.DataKeys[
                                  int.Parse((string)e.CommandArgument, CultureInfo.CurrentCulture)].Value;

                    Package package = repositoryFactory.GetPackageRepository().GetOne(id);

                    Session.Add(packageid, id.ToString());

                    foreach (Package childPackage in package.Children)
                    {
                        // No id's present on the childpackages for this chainentity.
                        if (childPackage.IdentificationForChainEntity(GetChainEntityForCurrentUser()) == string.Empty)
                        {
                            SetIdentificationRangeControls(true);
                            LabelNumberOfPackages.Text = new List<Package>(package.Children).Count.ToString();
                        }
                        else
                        {
                            SetIdentificationRangeControls(false);
                        }
                        //One loop should be enough to determine the presence of ids.
                        break;
                    }

                    MultiView1.SetActiveView(ViewDetail);
                }
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Sets the identification range controls.
        /// </summary>
        /// <param name="isVisible">if set to <c>true</c> [is visible].</param>
        private void SetIdentificationRangeControls(bool isVisible)
        {
            TextBoxPackageIdentification.Visible = isVisible;
            TextBoxPackageIdentification.Enabled = isVisible;
            Label4.Visible = isVisible;
            Label2.Visible = isVisible;
            LabelNumberOfPackages.Visible = isVisible;
        }


        /// <summary>
        /// Validates the identifications existance.
        /// </summary>
        /// <param name="from">From.</param>
        /// <param name="to">To.</param>
        /// <param name="chainEntity">The chain entity.</param>
        private static void ValidateIdentificationsExistance(long from, long to, ChainEntity chainEntity)
        {
            for (long counter = from; counter < to; counter++)
            {
                if (RepositoryHelper.IdentificationExists(counter.ToString(), chainEntity))
                {
                    throw new ArgumentException(Resources.Localization.Theidentificationisalreadyused);
                }
            }
        }
    }
}