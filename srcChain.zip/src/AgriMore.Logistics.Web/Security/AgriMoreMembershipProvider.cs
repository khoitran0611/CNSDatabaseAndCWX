using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// custom membershipprovider for userlogin
    /// <membership defaultprovider="AgriMoreMembershipProvider">
    ///     <providers>
    ///         <add name="AgriMoreMembershipProvider"
    ///             type="AgriMore.Logistics.Web.AgriMoreMembershipProvider"
    ///             dbProvider="System.Data.SqlClient"
    ///             connectionStringName="connstr"
    ///             requiresUniqueName="true"
    ///             cacheUserInfo="true"/>
    ///     </providers>
    /// </membership>
    /// </summary>
    public class AgriMoreMembershipProvider : MembershipProvider
    {
        private string applicationName;
        private readonly bool enablePasswordReset = false;
        private readonly bool enablePasswordRetrieval = false;
        private readonly int maxInvalidPasswordAttempts = 0;
        private readonly int minRequiredNonAlphanumericCharacters = 0;
        private readonly int minRequiredPasswordLength = 0;
        private string name;
        private readonly int passwordAttemptWindow = 0;
        private readonly MembershipPasswordFormat passwordFormat = new MembershipPasswordFormat();
        private readonly string passwordStrengthRegularExpression = string.Empty;
        private readonly bool requiresQuestionAndAnswer = false;
        private readonly bool requiresUniqueEmail = false;

        private IRepository<User> userRepository;

        ///<summary>
        ///Indicates whether the membership provider is configured to allow users to retrieve their passwords.
        ///</summary>
        ///
        ///<returns>
        ///true if the membership provider is configured to support password retrieval; otherwise, false. The default is false.
        ///</returns>
        ///
        public override bool EnablePasswordRetrieval
        {
            get { return enablePasswordRetrieval; }
        }

        ///<summary>
        ///Indicates whether the membership provider is configured to allow users to reset their passwords.
        ///</summary>
        ///
        ///<returns>
        ///true if the membership provider supports password reset; otherwise, false. The default is true.
        ///</returns>
        ///
        public override bool EnablePasswordReset
        {
            get { return enablePasswordReset; }
        }

        ///<summary>
        ///Gets a value indicating whether the membership provider is configured to require the user to answer a password question for password reset and retrieval.
        ///</summary>
        ///
        ///<returns>
        ///true if a password answer is required for password reset and retrieval; otherwise, false. The default is true.
        ///</returns>
        ///
        public override bool RequiresQuestionAndAnswer
        {
            get { return requiresQuestionAndAnswer; }
        }

        ///<summary>
        ///The name of the application using the custom membership provider.
        ///</summary>
        ///
        ///<returns>
        ///The name of the application using the custom membership provider.
        ///</returns>
        ///
        public override string ApplicationName
        {
            get { return applicationName; }
            set { applicationName = value; }
        }

        ///<summary>
        ///Gets the number of invalid password or password-answer attempts allowed before the membership user is locked out.
        ///</summary>
        ///
        ///<returns>
        ///The number of invalid password or password-answer attempts allowed before the membership user is locked out.
        ///</returns>
        ///
        public override int MaxInvalidPasswordAttempts
        {
            get { return maxInvalidPasswordAttempts; }
        }

        ///<summary>
        ///Gets the number of minutes in which a maximum number of invalid password or password-answer attempts are allowed before the membership user is locked out.
        ///</summary>
        ///
        ///<returns>
        ///The number of minutes in which a maximum number of invalid password or password-answer attempts are allowed before the membership user is locked out.
        ///</returns>
        ///
        public override int PasswordAttemptWindow
        {
            get { return passwordAttemptWindow; }
        }

        ///<summary>
        ///Gets a value indicating whether the membership provider is configured to require a unique e-mail address for each user name.
        ///</summary>
        ///
        ///<returns>
        ///true if the membership provider requires a unique e-mail address; otherwise, false. The default is true.
        ///</returns>
        ///
        public override bool RequiresUniqueEmail
        {
            get { return requiresUniqueEmail; }
        }

        ///<summary>
        ///Gets a value indicating the format for storing passwords in the membership data store.
        ///</summary>
        ///
        ///<returns>
        ///One of the <see cref="T:System.Web.Security.MembershipPasswordFormat"></see> values indicating the format for storing passwords in the data store.
        ///</returns>
        ///
        public override MembershipPasswordFormat PasswordFormat
        {
            get { return passwordFormat; }
        }

        ///<summary>
        ///Gets the minimum length required for a password.
        ///</summary>
        ///
        ///<returns>
        ///The minimum length required for a password. 
        ///</returns>
        ///
        public override int MinRequiredPasswordLength
        {
            get { return minRequiredPasswordLength; }
        }

        ///<summary>
        ///Gets the minimum number of special characters that must be present in a valid password.
        ///</summary>
        ///
        ///<returns>
        ///The minimum number of special characters that must be present in a valid password.
        ///</returns>
        ///
        public override int MinRequiredNonAlphanumericCharacters
        {
            get { return minRequiredNonAlphanumericCharacters; }
        }

        ///<summary>
        ///Gets the regular expression used to evaluate a password.
        ///</summary>
        ///
        ///<returns>
        ///A regular expression used to evaluate a password.
        ///</returns>
        ///
        public override string PasswordStrengthRegularExpression
        {
            get { return passwordStrengthRegularExpression; }
        }

        /// <summary>
        /// Initializes the provider.
        /// </summary>
        /// <param name="name">The friendly name of the provider.</param>
        /// <param name="config">A collection of the name/value pairs representing the provider-specific attributes specified in the configuration for this provider.</param>
        /// <exception cref="T:System.ArgumentNullException">The name of the provider is null.</exception>
        /// <exception cref="T:System.InvalidOperationException">An attempt is made to call <see cref="M:System.Configuration.Provider.ProviderBase.Initialize(System.String,System.Collections.Specialized.NameValueCollection)"></see> on a provider after the provider has already been initialized.</exception>
        /// <exception cref="T:System.ArgumentException">The name of the provider has a length of zero.</exception>
        public override void Initialize(string name, NameValueCollection config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            this.name = name;

            if (string.IsNullOrEmpty(name))
            {
                this.name = "AgriMoreMembershipProvider";
            }

            base.Initialize(name, config);

            RepositoryFactory repository = new RepositoryFactory();
            userRepository = repository.GetUserRepository();
        }

        ///<summary>
        ///Adds a new membership user to the data source.
        ///</summary>
        ///
        ///<returns>
        ///A <see cref="T:System.Web.Security.MembershipUser"></see> object populated with the information for the newly created user.
        ///</returns>
        ///
        ///<param name="isApproved">Whether or not the new user is approved to be validated.</param>
        ///<param name="passwordAnswer">The password answer for the new user</param>
        ///<param name="username">The user name for the new user. </param>
        ///<param name="providerUserKey">The unique identifier from the membership data source for the user.</param>
        ///<param name="password">The password for the new user. </param>
        ///<param name="passwordQuestion">The password question for the new user.</param>
        ///<param name="email">The e-mail address for the new user.</param>
        ///<param name="status">A <see cref="T:System.Web.Security.MembershipCreateStatus"></see> enumeration value indicating whether the user was created successfully.</param>
        public override MembershipUser CreateUser(string username, string password, string email,
                                                  string passwordQuestion, string passwordAnswer, bool isApproved,
                                                  object providerUserKey, out MembershipCreateStatus status)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Processes a request to update the password question and answer for a membership user.
        ///</summary>
        ///
        ///<returns>
        ///true if the password question and answer are updated successfully; otherwise, false.
        ///</returns>
        ///
        ///<param name="newPasswordQuestion">The new password question for the specified user. </param>
        ///<param name="newPasswordAnswer">The new password answer for the specified user. </param>
        ///<param name="username">The user to change the password question and answer for. </param>
        ///<param name="password">The password for the specified user. </param>
        public override bool ChangePasswordQuestionAndAnswer(string username, string password,
                                                             string newPasswordQuestion, string newPasswordAnswer)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Gets the password for the specified user name from the data source.
        ///</summary>
        ///
        ///<returns>
        ///The password for the specified user name.
        ///</returns>
        ///
        ///<param name="username">The user to retrieve the password for. </param>
        ///<param name="answer">The password answer for the user. </param>
        public override string GetPassword(string username, string answer)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Processes a request to update the password for a membership user.
        ///</summary>
        ///
        ///<returns>
        ///true if the password was updated successfully; otherwise, false.
        ///</returns>
        ///
        ///<param name="newPassword">The new password for the specified user. </param>
        ///<param name="oldPassword">The current password for the specified user. </param>
        ///<param name="username">The user to update the password for. </param>
        public override bool ChangePassword(string username, string oldPassword, string newPassword)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Resets a user's password to a new, automatically generated password.
        ///</summary>
        ///
        ///<returns>
        ///The new password for the specified user.
        ///</returns>
        ///
        ///<param name="username">The user to reset the password for. </param>
        ///<param name="answer">The password answer for the specified user. </param>
        public override string ResetPassword(string username, string answer)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Updates information about a user in the data source.
        ///</summary>
        ///
        ///<param name="user">A <see cref="T:System.Web.Security.MembershipUser"></see> object that represents the user to update and the updated information for the user. </param>
        public override void UpdateUser(MembershipUser user)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Verifies that the specified user name and password exist in the data source.
        ///</summary>
        ///
        ///<returns>
        ///true if the specified username and password are valid; otherwise, false.
        ///</returns>
        ///
        ///<param name="username">The name of the user to validate. </param>
        ///<param name="password">The password for the specified user. </param>
        public override bool ValidateUser(string username, string password)
        {
            User user = userRepository.GetOne(new UserIsAuthenticatedSpecification(username, password));

            if (user == null)
            {
                return false;
            }

            List<Role> listForCount = new List<Role>(user.Roles);
            string[] roles = new string[listForCount.Count];
            int i = 0;
            foreach (Role role in user.Roles)
                roles[i++] = role.Name;

            GenericIdentity userIdentity = new GenericIdentity(user.Username);
            GenericPrincipal gp = new GenericPrincipal(userIdentity, roles);
            HttpContext.Current.User = gp;

            return true;
        }

        ///<summary>
        ///Clears a lock so that the membership user can be validated.
        ///</summary>
        ///
        ///<returns>
        ///true if the membership user was successfully unlocked; otherwise, false.
        ///</returns>
        ///
        ///<param name="userName">The membership user whose lock status you want to clear.</param>
        public override bool UnlockUser(string userName)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Gets user information from the data source based on the unique identifier for the membership user. Provides an option to update the last-activity date/time stamp for the user.
        ///</summary>
        ///
        ///<returns>
        ///A <see cref="T:System.Web.Security.MembershipUser"></see> object populated with the specified user's information from the data source.
        ///</returns>
        ///
        ///<param name="providerUserKey">The unique identifier for the membership user to get information for.</param>
        ///<param name="userIsOnline">true to update the last-activity date/time stamp for the user; false to return user information without updating the last-activity date/time stamp for the user.</param>
        public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Gets information from the data source for a user. Provides an option to update the last-activity date/time stamp for the user.
        ///</summary>
        ///
        ///<returns>
        ///A <see cref="T:System.Web.Security.MembershipUser"></see> object populated with the specified user's information from the data source.
        ///</returns>
        ///
        ///<param name="username">The name of the user to get information for. </param>
        ///<param name="userIsOnline">true to update the last-activity date/time stamp for the user; false to return user information without updating the last-activity date/time stamp for the user. </param>
        public override MembershipUser GetUser(string username, bool userIsOnline)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Gets the user name associated with the specified e-mail address.
        ///</summary>
        ///
        ///<returns>
        ///The user name associated with the specified e-mail address. If no match is found, return null.
        ///</returns>
        ///
        ///<param name="email">The e-mail address to search for. </param>
        public override string GetUserNameByEmail(string email)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Removes a user from the membership data source. 
        ///</summary>
        ///
        ///<returns>
        ///true if the user was successfully deleted; otherwise, false.
        ///</returns>
        ///
        ///<param name="username">The name of the user to delete.</param>
        ///<param name="deleteAllRelatedData">true to delete data related to the user from the database; false to leave data related to the user in the database.</param>
        public override bool DeleteUser(string username, bool deleteAllRelatedData)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Gets a collection of all the users in the data source in pages of data.
        ///</summary>
        ///
        ///<returns>
        ///A <see cref="T:System.Web.Security.MembershipUserCollection"></see> collection that contains a page of pageSize<see cref="T:System.Web.Security.MembershipUser"></see> objects beginning at the page specified by pageIndex.
        ///</returns>
        ///
        ///<param name="totalRecords">The total number of matched users.</param>
        ///<param name="pageIndex">The index of the page of results to return. pageIndex is zero-based.</param>
        ///<param name="pageSize">The size of the page of results to return.</param>
        public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Gets the number of users currently accessing the application.
        ///</summary>
        ///
        ///<returns>
        ///The number of users currently accessing the application.
        ///</returns>
        ///
        public override int GetNumberOfUsersOnline()
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Gets a collection of membership users where the user name contains the specified user name to match.
        ///</summary>
        ///
        ///<returns>
        ///A <see cref="T:System.Web.Security.MembershipUserCollection"></see> collection that contains a page of pageSize<see cref="T:System.Web.Security.MembershipUser"></see> objects beginning at the page specified by pageIndex.
        ///</returns>
        ///
        ///<param name="totalRecords">The total number of matched users.</param>
        ///<param name="pageIndex">The index of the page of results to return. pageIndex is zero-based.</param>
        ///<param name="usernameToMatch">The user name to search for.</param>
        ///<param name="pageSize">The size of the page of results to return.</param>
        public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize,
                                                                 out int totalRecords)
        {
            throw new NotImplementedException();
        }

        ///<summary>
        ///Gets a collection of membership users where the e-mail address contains the specified e-mail address to match.
        ///</summary>
        ///
        ///<returns>
        ///A <see cref="T:System.Web.Security.MembershipUserCollection"></see> collection that contains a page of pageSize<see cref="T:System.Web.Security.MembershipUser"></see> objects beginning at the page specified by pageIndex.
        ///</returns>
        ///
        ///<param name="totalRecords">The total number of matched users.</param>
        ///<param name="pageIndex">The index of the page of results to return. pageIndex is zero-based.</param>
        ///<param name="emailToMatch">The e-mail address to search for.</param>
        ///<param name="pageSize">The size of the page of results to return.</param>
        public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize,
                                                                  out int totalRecords)
        {
            throw new NotImplementedException();
        }
    }
}