using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using AgriMore.Logistics.Domain.Transaction;

using AgriMore.Logistics.Web.Helpers;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// This class represents the user interface for creating a shipment for Waste Disposal 
    /// packages
    /// </summary>
    public partial class WasteCollection : BasePage
    {
        private const string name = "Name";
        private const string uid = "Uid";
        private const string urlDefault = "Default.aspx";
        private const string forwarder = "Forwarder";
        private const string receiver = "Receiver";
        private const string space = " ";
        private const string comma = ", ";
        //Refactor
        //private const string wholesalepackaging = "wholesalepackaging";
        private const string shipmentCreated = "The shipment has been created/changed.";

        private IRepository<ChainEntity> chainEntityrepository;
        private bool IsValidForwarderEmailaddress = false;
        private bool IsValidReceiverEmailaddress = false;
        private IRepository<Location> locationRepository;
        private IRepository<Package> packageRepository;
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        private ChainEntity chainEntityForCurrentUser;

        private ChainEntity GetChainEntityForCurrentUser()
        {
            if (chainEntityForCurrentUser == null)
            {
                chainEntityForCurrentUser = RepositoryHelper.GetChainEntityForCurrentUser();
            }
            return chainEntityForCurrentUser;
        }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            ltPackageDescription.Text = "";            
            Session.Add("repositorymanager", repositoryFactory);

            chainEntityrepository = repositoryFactory.GetChainEntityRepository();
            locationRepository = repositoryFactory.GetLocationRepository();
            packageRepository = repositoryFactory.GetPackageRepository();

            if (!IsPostBack)
            {
                BindProducts();  
                Session.Clear();
                LoadShipperData();
                LoadReceiverData();
                LoadForwarderData();                          
            }

            if (ListBoxPackages.Items.Count > 0)
            {
                Session["listBoxSelectedValue"] = ListBoxPackages.Items[0].Value;
            }
            else
            {
                Session["listBoxSelectedValue"] = "0";
            }

            //ShowDescription();
        }

        /// <summary>
        /// Loads the forwarder data.
        /// </summary>
        private void LoadForwarderData()
        {
            Role forwaderRole = repositoryFactory.GetRoleRepository().GetOne(forwarder);
            IEnumerable<ChainEntity> forwarders =
                repositoryFactory.GetChainEntityRepository().Find(new ChainEntiyByRoleSpecification(forwaderRole));

            BindDropDownChainEntity(forwarders, DropDownListForwarder);

            GetForwarderAddress(DropDownListForwarder.SelectedValue);

            DropDownListforwarderAddress.Enabled = false;
        }

        /// <summary>
        /// Binds the drop down chain entity.
        /// </summary>
        /// <param name="list">The list.</param>
        /// <param name="dropDownList">The drop down list.</param>
        private static void BindDropDownChainEntity(IEnumerable<ChainEntity> list, ListControl dropDownList)
        {
            dropDownList.DataSource = list;
            dropDownList.DataTextField = name;
            dropDownList.DataValueField = uid;
            dropDownList.DataBind();
        }

        /// <summary>
        /// Binds the drop down chain entity.
        /// </summary>
        /// <param name="list">The list.</param>
        /// <param name="dropDownList">The drop down list.</param>
        private static void BindDropDownAddress(IEnumerable<BindableAddress> list, ListControl dropDownList)
        {
            dropDownList.DataSource = list;
            dropDownList.DataTextField = name;
            dropDownList.DataValueField = uid;
            dropDownList.DataBind();
        }

        /// <summary>
        /// Binds the drop down chain entity.
        /// </summary>
        /// <param name="list">The list.</param>
        /// <param name="dropDownList">The drop down list.</param>
        private static void BindDropDownLocation(IEnumerable<Location> list, ListControl dropDownList)
        {
            dropDownList.DataSource = list;
            dropDownList.DataTextField = name;
            dropDownList.DataValueField = uid;
            dropDownList.DataBind();
        }

        /// <summary>
        /// Loads the receiver data.
        /// </summary>
        private void LoadReceiverData()
        {
            Role receiverRole = repositoryFactory.GetRoleRepository().GetOne(receiver);

            ICollection<ChainEntity> receivers =
                repositoryFactory.GetChainEntityRepository().Find(new ChainEntiyByRoleSpecification(receiverRole));

            BindDropDownChainEntity(receivers, DropDownListDelivery);

            GetDeliveryAddress(DropDownListDelivery.SelectedValue);

            GetDeliveryLocations(DropDownListDeleveryAddress.SelectedValue);
        }

        /// <summary>
        /// Loads the shipper data.
        /// </summary>
        private void LoadShipperData()
        {
            ChainEntity shipper = GetChainEntityForCurrentUser();

            BindDropDownAddress(GetBindableAddresses(shipper), DropDownListShipperPickupAddress);

            GetShipperLocationsAndPackages(DropDownListShipperPickupAddress.SelectedValue);

            GetShipments(shipper);
        }

        /// <summary>
        /// Gets the shipments.
        /// </summary>
        /// <param name="shipper">The shipper.</param>
        private void GetShipments(ChainEntity shipper)
        {
            List<Shipment> shipmentResult = new List<Shipment>();

            IRepository<Shipment> memoryShipmentRepository = repositoryFactory.GetShipmentRepository();

            ShipmentsForShipperSpecification spec = new ShipmentsForShipperSpecification(shipper, false, false);
            if (memoryShipmentRepository != null)
            {
                List<Shipment> shipments = memoryShipmentRepository.Find(spec).ToList();
                foreach (var shipment in shipments)
                {
                    List<Package> packages = shipment.Packages.Where(p => p.PackageTypeCategoryId == 4).ToList();
                    if (packages.Count > 0)
                    {
                        shipmentResult.Add(shipment);
                    }
                }

                GridViewShipments.DataSource = shipmentResult;
                GridViewShipments.DataBind();
            }
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the DropDownListShipperPickupAddress control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void DropDownListShipperPickupAddress_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetShipperLocationsAndPackages(DropDownListShipperPickupAddress.SelectedValue);
        }


        /// <summary>
        /// Gets the shipper locations and packages.
        /// </summary>
        /// <param name="selectedAddressValue">The selected address value.</param>
        private void GetShipperLocationsAndPackages(string selectedAddressValue)
        {
            if (selectedAddressValue == "-1")
            {
                DropDownListShipperPickupLocation.Items.Clear();
                DropDownListShipperPickupLocation.Enabled = false;
                return;
            }
            else
            {
                DropDownListShipperPickupLocation.Enabled = true;
            }

            long addressUid = long.Parse(DropDownListShipperPickupAddress.SelectedItem.Value);

            Address address = repositoryFactory.GetAddressRepository().GetOne(addressUid);

            BindDropDownLocation(address.Locations, DropDownListShipperPickupLocation);

            GetAllNotShippedPackages(address);
        }


        /// <summary>
        /// Gets all not shipped packages.
        /// </summary>
        /// <param name="address">The address.</param>
        private void GetAllNotShippedPackages(Address address)
        {
            ChainEntity shipper = GetChainEntityForCurrentUser();

            var materialId = ddlPackageMaterial.SelectedValue.ToInt64();
            ICollection<Shipment> shipments =
                repositoryFactory.GetShipmentRepository().Find(new ShipmentsByChainEntity(shipper));

            List<Package> packagesInShipment = new List<Package>();
            List<Package> packagesInLocations = new List<Package>();
            List<Package> packagesNotInShipment = new List<Package>();
            List<Package> updatePackagesInLocations = new List<Package>();

            foreach (Shipment shipment in shipments)
            {
                if (shipment.Shipper.Equals(shipper) && shipment.IsShipped == false && shipment.IsDelivered == false)
                {
                    packagesInShipment.AddRange(shipment.Packages);
                }
            }

            // All packages in locations off the shipper.
            foreach (Location location in address.Locations)
            {
                foreach (Package packageInLocation in location.Packages)
                {                    
                    if (packageInLocation.PackageTypeCategoryId == 4) //now show the Waste Disposal category only
                    {
                        packagesInLocations.Add(packageInLocation);
                    }
                }
            }

            IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(CurLangCode, 0, 0, RepositoryHelper.GetChainEntityForCurrentUser().Uid).ToList();

            if (materialId != 0)
            {
                if (packageTypes != null && packageTypes.Any())
                {
                    updatePackagesInLocations.Clear();

                    foreach (var ep in packagesInLocations)
                    {
                        var ptype = packageTypes.Where(pt => pt.Uid == ep.PackageTypeId).FirstOrDefault();
                        if (ptype != null)
                        {
                            if (ptype.PackagingMaterial.Uid == materialId)
                            {
                                updatePackagesInLocations.Add(ep);
                            }
                        }
                    }
                }
            }
            else
            {
                updatePackagesInLocations = packagesInLocations;
            }


            foreach (Package packageInLocation in updatePackagesInLocations)
            {
                bool isInShipment;
                isInShipment = packagesInShipment.Contains(packageInLocation);

                if (!isInShipment && !packageInLocation.PrimaryProducts.Any(it => it.Decomposed))
                {
                    packagesNotInShipment.Add(packageInLocation);
                }
            }

            FillListBoxPackages(packagesNotInShipment, Int32.Parse(ddlWastePackageType.SelectedValue));
        }

        /// <summary>
        /// Fills the list box packages.
        /// </summary>
        /// <param name="packagesNotInShipment">The packages not in shipment.</param>
        private void FillListBoxPackages(IEnumerable<Package> packagesNotInShipment, int typeOfWaste)
        {
            List<long> selectedProducts = new List<long>();

            foreach (ListItem prodItem in lbxProduct.Items)
            {
                if (prodItem.Selected)
                {
                    selectedProducts.Add(Int64.Parse(prodItem.Value));
                }
            }

            List<Package> packages = new List<Package>();

            if (typeOfWaste != -1)
            {
                foreach (Package package in packagesNotInShipment)
                {
                    if (package.TypeOfWaste == Int32.Parse(ddlWastePackageType.SelectedValue))
                    {
                        packages.Add(package);
                    }
                }
            }
            else
            {
                packages = packagesNotInShipment.ToList();
            }            
            
            ListBoxPackages.Items.Clear();

            foreach (Package pack in packages)
            {
                if (selectedProducts.Contains(-1))
                {
                    string packageName = RepositoryHelper.CreatePackageName(pack, GetChainEntityForCurrentUser());
                    ListBoxPackages.Items.Add(new ListItem(packageName, pack.Uid.ToString()));
                }
                else
                {

                    foreach (var prod in selectedProducts)
                    {
                        if (pack.PrimaryProducts.Any(pr => pr.ProductUid == prod))
                        {
                            string packageName = RepositoryHelper.CreatePackageName(pack, GetChainEntityForCurrentUser());
                            ListBoxPackages.Items.Add(new ListItem(packageName, pack.Uid.ToString()));
                        }
                    }
                }
            }

            //foreach (Package pack in packages)
            //{
            //    if (pack.PrimaryProducts != null && pack.PrimaryProducts.Any())
            //    {
            //        foreach (var prod in selectedProducts)
            //        {
            //            if (pack.PrimaryProducts.Any(pr => pr.ProductUid == prod))
            //            {
            //                string packageName = RepositoryHelper.CreatePackageName(pack, GetChainEntityForCurrentUser());
            //                ListBoxPackages.Items.Add(new ListItem(packageName, pack.Uid.ToString()));
            //            }
            //        }                    
            //    }                
            //}

        }

        /// <summary>
        /// Handles the Onclick event of the lnkSelect control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void lnkSelect_Onclick(object sender, EventArgs e)
        {
            foreach (ListItem item in ListBoxPackages.Items)
            {
                if (item.Selected)
                {
                    ListBoxSelectedPackages.Items.Add(item);
                }
            }

            foreach (ListItem item in ListBoxSelectedPackages.Items)
            {
                ListBoxPackages.Items.Remove(item);
            }
        }

        /// <summary>
        /// Handles the Onclick event of the lnkDeselect control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void lnkDeselect_Onclick(object sender, EventArgs e)
        {
            foreach (ListItem item in ListBoxSelectedPackages.Items)
            {
                if (item.Selected)
                {
                    ListBoxPackages.Items.Add(item);
                }
            }

            foreach (ListItem item in ListBoxPackages.Items)
            {
                ListBoxSelectedPackages.Items.Remove(item);
            }
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the DropDownListDelivery control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void DropDownListDelivery_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetDeliveryAddress(DropDownListDelivery.SelectedValue);

            if (DropDownListDeleveryAddress.SelectedValue != null)
            {
                GetDeliveryLocations(DropDownListDeleveryAddress.SelectedValue);
            }
        }

        /// <summary>
        /// Gets the delivery address.
        /// </summary>
        /// <param name="selectedDelivery">The selected delivery.</param>
        private void GetDeliveryAddress(string selectedDelivery)
        {
            if (selectedDelivery == "-1")
            {
                DropDownListDelivery.Items.Clear();
                DropDownListDelivery.Enabled = false;
                return;
            }
            else
            {
                DropDownListDelivery.Enabled = true;
            }

            ChainEntity chainEntity = chainEntityrepository.GetOne(long.Parse(DropDownListDelivery.SelectedValue));

            BindDropDownAddress(GetBindableAddresses(chainEntity), DropDownListDeleveryAddress);
        }

        /// <summary>
        /// Gets the bindable addresses.
        /// </summary>
        /// <param name="chainEntity">The chain entity.</param>
        /// <returns></returns>
        private static List<BindableAddress> GetBindableAddresses(ChainEntity chainEntity)
        {
            List<BindableAddress> bindableAddresses = new List<BindableAddress>();

            foreach (Address address in chainEntity.Addresses)
            {
                bindableAddresses.Add(
                    new BindableAddress(address.Uid,
                                        address.StreetName + space + address.StreetNumber + comma + address.ZipCode));
            }
            return bindableAddresses;
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the DropDownListDeleveryAddress control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void DropDownListDeleveryAddress_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetDeliveryLocations(DropDownListDeleveryAddress.SelectedValue);
        }

        /// <summary>
        /// Gets the delivery locations.
        /// </summary>
        /// <param name="selectedDeliveryAddress">The selected delivery address.</param>
        private void GetDeliveryLocations(string selectedDeliveryAddress)
        {
            if (selectedDeliveryAddress == "-1")
            {
                DropDownListDeliveryLocation.Items.Clear();
                DropDownListDeliveryLocation.Enabled = false;
                return;
            }
            else
            {
                DropDownListDeliveryLocation.Enabled = true;
            }

            long addressUid = long.Parse(DropDownListDeleveryAddress.SelectedItem.Value);

            Address address = repositoryFactory.GetAddressRepository().GetOne(addressUid);

            BindDropDownLocation(address.Locations, DropDownListDeliveryLocation);
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the DropDownListForwarder control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void DropDownListForwarder_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetForwarderAddress(DropDownListForwarder.SelectedValue);
        }

        /// <summary>
        /// Gets the forwarder address.
        /// </summary>
        /// <param name="selectedForwarder">The selected forwarder.</param>
        private void GetForwarderAddress(string selectedForwarder)
        {
            if (selectedForwarder == "-1")
            {
                DropDownListforwarderAddress.Items.Clear();
                DropDownListforwarderAddress.Enabled = false;
                return;
            }
            else
            {
                DropDownListforwarderAddress.Enabled = true;
            }

            ChainEntity theSelectedForwarder =
                chainEntityrepository.GetOne(long.Parse(DropDownListForwarder.SelectedValue));

            BindDropDownAddress(GetBindableAddresses(theSelectedForwarder), DropDownListforwarderAddress);
        }

        /// <summary>
        /// Sets the error message.
        /// </summary>
        /// <param name="message">The message.</param>
        private void SetErrorMessage(string message)
        {
            LabelError.Visible = true;
            LabelError.Text = message;
        }

        /// <summary>
        /// Handles the Click event of the ButtonSave control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void ButtonSave_Click(object sender, EventArgs e)
        {
            Validate();
            if (Page.IsValid)
            {
                if (DropDownListShipperPickupLocation.SelectedValue == string.Empty)
                {
                    SetErrorMessage(Resources.Localization.Therearenolocationsselected);
                    return;
                }

                DateTime beginPickUpDateTime = BeginPickUpDateTime.GetDatetime();
                DateTime endPickUpDateTime = EndPickUpDateTime.GetDatetime();

                Range<DateTime> pickUpRange;
                try
                {
                    pickUpRange = new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime);
                }
                catch (ArgumentException)
                {
                    SetErrorMessage(Resources.Localization.Thebeginpickupdatetimemustbebeforetheendpickupdatetime);
                    return;
                }

                DateTime beginDeliverDateTime = BeginDeliverDateTime.GetDatetime();
                DateTime endDeliverDateTime = EndDeliverDateTime.GetDatetime();

                Range<DateTime> deliverRange;
                try
                {
                    deliverRange = new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime);
                }
                catch (ArgumentException)
                {
                    SetErrorMessage(Resources.Localization.Thebegindeliverdatetimemustbebeforetheenddeliverdatetime);
                    return;
                }

                string shipperReferenceId = txtShipperReferenceId.Text;
                string forwarderReferenceId = txtForwarderReferenceId.Text;
                string receiverReferenceId = txtReceiverReferenceId.Text;

                string receiverEmailaddress = txtReceiverMailAddress.Text;
                IsValidReceiverEmailaddress = IsEmail(receiverEmailaddress);
                if (!IsValidReceiverEmailaddress)
                {
                    SetErrorMessage(Resources.Localization.Invalidreceivermailaddress);
                    return;
                }

                string forwarderEmailaddress = txtForwarderMailaddress.Text;
                IsValidForwarderEmailaddress = IsEmail(forwarderEmailaddress);
                if (!IsValidForwarderEmailaddress)
                {
                    SetErrorMessage(Resources.Localization.Invalidforwardermailaddress);
                    return;
                }


                IList<ShipmentExposure> shipmentExposures = new List<ShipmentExposure>();

                IEnumerable<Exposure> exposures;

                try
                {
                    exposures = ExposuresControl.GetExposureDocument();
                }
                catch (ArgumentNullException ane)
                {
                    ErrorHelper.SetErrorLabel(true, ane.Message, LabelError, false);
                    return;
                }
                catch (ArgumentException ae)
                {
                    ErrorHelper.SetErrorLabel(true, ae.Message, LabelError, false);
                    return;
                }
                catch (Exception exception)
                {
                    ErrorHelper.SetErrorLabel(true, exception.Message, LabelError, true);
                    return;
                }

                if (exposures == null)
                {
                    string message = Resources.Localization.Anullwasreturnedwhiletryingtorerievetheexposures;
                    ErrorHelper.SetErrorLabel(true, message, LabelError, false);
                    return;
                }

                try
                {
                    foreach (Exposure exposure in exposures)
                    {
                        ShipmentExposure shipmentExposure =
                            new ShipmentExposure(exposure.PrescribedStartValue, exposure.PrescribedEndValue, 0,
                                                 exposure.ExposureType);
                        shipmentExposures.Add(shipmentExposure);
                    }
                }
                catch (ArgumentNullException ane)
                {
                    ErrorHelper.SetErrorLabel(true, ane.Message, LabelError, false);
                    return;
                }
                catch (ArgumentException ae)
                {
                    ErrorHelper.SetErrorLabel(true, ae.Message, LabelError, false);
                    return;
                }
                catch (Exception exception)
                {
                    ErrorHelper.SetErrorLabel(true, exception.Message, LabelError, true);
                    return;
                }


                Shipment shipment;

                TransactionManager transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    ChainEntity shipper = GetChainEntityForCurrentUser();

                    Location pickupLocation = GetPickupLocation();

                    ChainEntity selectedForwarder =
                        chainEntityrepository.GetOne(long.Parse(DropDownListForwarder.SelectedValue));

                    Location deliverLocation =
                        locationRepository.GetOne(long.Parse(DropDownListDeliveryLocation.SelectedValue));

                    ChainEntity selectedReceiver =
                        chainEntityrepository.GetOne(long.Parse(DropDownListDelivery.SelectedValue));

                    IList<long> prodIds = new List<long>();
                    IList<Package> packages = new List<Package>();
                    foreach (ListItem item in ListBoxSelectedPackages.Items)
                    {
                        var pack = packageRepository.GetOne(long.Parse(item.Value));
                        foreach (long id in pack.PrimaryProducts.Select(it => it.MatchingProdId).Distinct().Where(id => !prodIds.Contains(id))) prodIds.Add(id);

                        packages.Add(pack);
                    }

                    if (packages.Count == 0)
                    {
                        transactionManager.RollbackTransaction();
                        SetErrorMessage(Resources.Localization.Mustselectoneormorepackages);
                        return;
                    }

                    shipment = new Shipment(shipper, selectedReceiver, selectedForwarder, shipperReferenceId,
                                     forwarderReferenceId,
                                     receiverReferenceId, packages, pickupLocation, deliverLocation,
                                     pickUpRange,
                                     deliverRange, forwarderEmailaddress, receiverEmailaddress,
                                     shipmentExposures);

                    var editedShipmentid = Session["shipmentid"] as string;
                    if (editedShipmentid != null)
                    {
                        shipment.Uid = long.Parse(editedShipmentid);
                        Session.Clear();
                    }

                    repositoryFactory.GetShipmentRepository().Store(shipment);                    

                    transactionManager.CommitTransaction();
                }
                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    ErrorHelper.HandleException(exception, transactionManager, LabelError);
                    return;
                }

                try
                {
                    SendForwarderMail(shipment);
                    Response.Redirect(urlDefault, false);
                }
                catch (Exception exception)
                {
                    LabelError.Visible = true;
                    ErrorHelper.SetErrorLabel(true, shipmentCreated + space + exception.Message, LabelError,
                                              false);
                    ButtonSave.Enabled = false;
                }

            }
        }


        /// <summary>
        /// Gets the pickup location.
        /// </summary>
        /// <returns></returns>
        private
            Location GetPickupLocation()
        {
            return locationRepository.GetOne(long.Parse(DropDownListShipperPickupLocation.SelectedValue));
        }

        /// <summary>
        /// Sends the forwarder mail.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        private
            void SendForwarderMail(Shipment shipment)
        {
            string Subject = Resources.Localization.MessagefromagriMOREsystemShipmentcreatedchanged;
            string BodyTemlate = Resources.Localization.AshipmenthasbeencreatedPleaserefertodetailsbelow;

            long addressUid = long.Parse(DropDownListShipperPickupAddress.SelectedItem.Value);
            Address shipperAddress = repositoryFactory.GetAddressRepository().GetOne(addressUid);

            addressUid = long.Parse(DropDownListDeleveryAddress.SelectedItem.Value);
            Address deliverAddress = repositoryFactory.GetAddressRepository().GetOne(addressUid);

            ShipmentMailer mailer = new ShipmentMailer(shipperAddress.Email, Subject, BodyTemlate);
            mailer.Send(shipment, shipperAddress, deliverAddress);
        }

        /// <summary>
        /// Determines whether the specified email is email.
        /// </summary>
        /// <param name="Email">The email.</param>
        /// <returns>
        /// 	<c>true</c> if the specified email is email; otherwise, <c>false</c>.
        /// </returns>
        public static
            bool IsEmail(string Email)
        {
            string strRegex =
                @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$";

            return new Regex(strRegex).IsMatch(Email);
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected
            void LinkButtonCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(urlDefault, false);
        }

        /// <summary>
        /// Handles the RowEditing1 event of the GridViewShipments control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewEditEventArgs"/> instance containing the event data.</param>
        protected
            void GridViewShipments_RowEditing1(object sender, GridViewEditEventArgs e)
        {
            try
            {
                IRepository<Shipment> memoryShipmentRepository = repositoryFactory.GetShipmentRepository();

                string id = GridViewShipments.DataKeys[e.NewEditIndex].Value.ToString();
                Session.Add("shipmentid", id);
                Shipment shipment = null;

                if (memoryShipmentRepository != null && !String.IsNullOrEmpty(id))
                {
                    shipment = memoryShipmentRepository.GetOne(long.Parse(id));
                }

                if (shipment != null)
                {
                    GetShipperData(shipment);
                    GetReceiverData(shipment);
                    GetForwarderData(shipment);
                    LoadShipmentExposure(shipment);
                }
            }
            catch (Exception)
            {
                LabelError.Visible = true;
                LabelError.Text = ResourceAgriMore.GeneralErrorMessage;
            }
        }

        /// <summary>
        /// <summary>
        /// Gets the receiver data.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        private
            void GetReceiverData(Shipment shipment)
        {
            DropDownListDelivery.SelectedValue = shipment.Receiver.Uid.ToString();
            ChainEntity chainEntity = chainEntityrepository.GetOne(long.Parse(DropDownListDelivery.SelectedValue));
            DropDownListDeleveryAddress.DataSource = GetBindableAddresses(chainEntity);
            DropDownListDeleveryAddress.DataBind();

            Address selectedAddress = GetReceiverAddress(shipment);

            if (selectedAddress != null)
            {
                SelectReceiverSelectedAddress(selectedAddress);
            }

            GetDeliveryLocations(DropDownListDeleveryAddress.SelectedValue);

            if (DropDownListDeliveryLocation != null)
            {
                DropDownListDeliveryLocation.SelectedValue = shipment.DeliveryLocation.Uid.ToString();
            }

            BeginDeliverDateTime.SetStartDateTime(shipment.DeliverDateTimeRange.Start);
            EndDeliverDateTime.SetStartDateTime(shipment.DeliverDateTimeRange.End);

            txtReceiverReferenceId.Text = shipment.ReceiverReferenceId;
            txtReceiverMailAddress.Text = shipment.ReceiverMailaddress;
        }

        /// <summary>
        /// Selects the receiver selected address.
        /// </summary>
        /// <param name="selectedAddress">The selected address.</param>
        private
            void SelectReceiverSelectedAddress(IIdentifyable selectedAddress)
        {
            foreach (ListItem listItem in DropDownListDeleveryAddress.Items)
            {
                listItem.Selected = false;
                if (listItem.Value == selectedAddress.Uid.ToString())
                {
                    listItem.Selected = true;
                }
            }
        }

        /// <summary>
        /// Gets the shipper data.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        private
            void GetShipperData(Shipment shipment)
        {
            ChainEntity shipper = GetChainEntityForCurrentUser();

            BindDropDownAddress(GetBindableAddresses(shipper), DropDownListShipperPickupAddress);

            Address selectedAddress = GetShipperAddress(shipment);

            if (selectedAddress != null)
            {
                SelectShipperSelectedAddress(selectedAddress);
            }

            GetShipperLocationsAndPackages(DropDownListShipperPickupAddress.SelectedValue);

            if (DropDownListShipperPickupLocation != null)
            {
                DropDownListShipperPickupLocation.SelectedValue = shipment.PickupLocation.Uid.ToString();
            }

            BeginPickUpDateTime.SetStartDateTime(shipment.PickUpDateTimeRange.Start);
            EndPickUpDateTime.SetStartDateTime(shipment.PickUpDateTimeRange.End);

            txtShipperReferenceId.Text = shipment.ShipperReferenceId;

            GetShipmentPackages(shipment);
        }

        /// <summary>
        /// Selects the shipper selected address.
        /// </summary>
        /// <param name="selectedAddress">The address.</param>
        private
            void SelectShipperSelectedAddress(IIdentifyable selectedAddress)
        {
            foreach (ListItem listItem in DropDownListShipperPickupAddress.Items)
            {
                listItem.Selected = false;
                if (listItem.Value == selectedAddress.Uid.ToString())
                {
                    listItem.Selected = true;
                }
            }
        }


        /// <summary>
        /// Gets the shipper address.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        /// <returns></returns>
        private static
            Address GetShipperAddress(Shipment shipment)
        {
            foreach (Address address in shipment.Shipper.Addresses)
            {
                foreach (Location location in address.Locations)
                {
                    if (location == shipment.PickupLocation)
                    {
                        return address;
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the shipment packages.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        private
            void GetShipmentPackages(Shipment shipment)
        {
            ListBoxSelectedPackages.Items.Clear();
            foreach (Package shipmentPackage in shipment.Packages)
            {
                if (shipmentPackage.PackageTypeCategoryId == 4)
                {
                    string packageName = RepositoryHelper.CreatePackageName(shipmentPackage, GetChainEntityForCurrentUser());
                    ListBoxSelectedPackages.Items.Add(new ListItem(packageName, shipmentPackage.Uid.ToString()));
                }
            }
        }

        /// Gets the forwarder data.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        private
            void GetForwarderData(Shipment shipment)
        {
            DropDownListForwarder.SelectedValue = shipment.Forwarder.Uid.ToString();
            ChainEntity selectedForwarder =
                chainEntityrepository.GetOne(long.Parse(DropDownListForwarder.SelectedValue));

            BindDropDownAddress(GetBindableAddresses(selectedForwarder), DropDownListforwarderAddress);

            Address selectedAddress = GetShipperAddress(shipment);

            if (selectedAddress != null)
            {
                SelectForwarderSelectedAddress(selectedAddress);
            }

            txtForwarderMailaddress.Text = shipment.ForwarderMailaddress;
            txtForwarderReferenceId.Text = shipment.ForwarderReferenceId;
        }

        /// <summary>
        /// Selects the forwarder selected address.
        /// </summary>
        /// <param name="selectedAddress">The selected address.</param>
        private
            void SelectForwarderSelectedAddress(IIdentifyable selectedAddress)
        {
            foreach (ListItem listItem in DropDownListforwarderAddress.Items)
            {
                listItem.Selected = false;
                if (listItem.Value == selectedAddress.Uid.ToString())
                {
                    listItem.Selected = true;
                }
            }
        }

        /// <summary>
        /// Gets the receiver address.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        /// <returns></returns>
        private static
            Address GetReceiverAddress(Shipment shipment)
        {
            foreach (Address address in shipment.Receiver.Addresses)
            {
                foreach (Location location in address.Locations)
                {
                    if (location == shipment.DeliveryLocation)
                    {
                        return address;
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// Loads the shipment exposure.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        private
            void LoadShipmentExposure(Shipment shipment)
        {
            foreach (ShipmentExposure shipmentExposure in shipment.ShipmentExposures)
            {
                ExposuresControl.PreFillExposureValues(true, shipmentExposure.PrescribedStartValue,
                                                       shipmentExposure.PrescribedEndValue,
                                                       shipmentExposure.DocumentedValue, shipmentExposure.ExposureType);
            }
        }

        protected void ddlWastePackageType_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindPackagesToShip();
        }

        protected void ListBoxPackages_SelectedIndexChanged(object sender, EventArgs e)
        {            
            ShowDescription();            
        }

        protected void ddlPackageMaterial_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindPackagesToShip();
        }

        private void BindPackagesToShip()
        {
            Session["listBoxSelectedValue"] = "";
            Session["listBoxSelectedValue"] = ListBoxPackages.SelectedValue;
            ltPackageDescription.Text = "";
            long id = 0;
            PackagePackagingWasteInfo wasteInfo = null;
            LoadShipperData();
            int selectedTypeOfWaste = Int32.Parse(ddlWastePackageType.SelectedValue);

            if (Int64.TryParse(Session["listBoxSelectedValue"].ToString(), out id))
            {
                wasteInfo = RepFactory.GetPackagePackagingWasteInfoRepository().AsCollection()
                   .Where(winf => winf.PackageId == id - 1).FirstOrDefault();
            }

            if (wasteInfo != null)
            {
                ltPackageDescription.Text = wasteInfo.PackingWasteDescription;
                //
            }            
        }

        void BindProducts()
        {            
            lbxProduct.Items.Clear();
            lbxProduct.Items.Insert(0, new ListItem("All", "-1"));

            IEnumerable<Product> products = ProductServices.GetProductList();
            foreach (var product in products)
            {
                ListItem item = new ListItem(product.Name, product.Uid.ToString());
                lbxProduct.Items.Add(item);
                item.Selected = true;
            }

            lbxProduct.Items[0].Selected = true;
        }

        protected void lbxProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session["listBoxSelectedValue"] = "";
            ltPackageDescription.Text = "";
            IEnumerable<Product> products = ProductServices.GetProductList();
       
            foreach (ListItem item in lbxProduct.Items)
            {
                if (item.Selected && item.Value == "-1")
                {
                    ltPackageDescription.Text = "";
                    lbxProduct.Items.Clear();
                    lbxProduct.Items.Insert(0, new ListItem("All", "-1"));

                    foreach (var product in products)
                    {
                        ListItem item1 = new ListItem(product.Name, product.Uid.ToString());
                        lbxProduct.Items.Add(item1);
                        item1.Selected = true;
                    }
                    lbxProduct.Items[0].Selected = true;
                    break;
                }
            }

            foreach (ListItem item in ListBoxPackages.Items)
            {
                item.Selected = false;
            }
            BindPackagesToShip();
        }

        void ShowDescription()
        {
            Session["listBoxSelectedValue"] = "";
            Session["listBoxSelectedValue"] = ListBoxPackages.SelectedValue;
            ltPackageDescription.Text = "";
            long id = 0;
            PackagePackagingWasteInfo wasteInfo = null;            
            int selectedTypeOfWaste = Int32.Parse(ddlWastePackageType.SelectedValue);

            if (Int64.TryParse(Session["listBoxSelectedValue"].ToString(), out id))
            {
                wasteInfo = RepFactory.GetPackagePackagingWasteInfoRepository().AsCollection()
                   .Where(winf => winf.PackageId == id).FirstOrDefault();
            }

            if (wasteInfo != null)
            {
                ltPackageDescription.Text = wasteInfo.PackingWasteDescription;
                //
            }            
            
        }
    }
}