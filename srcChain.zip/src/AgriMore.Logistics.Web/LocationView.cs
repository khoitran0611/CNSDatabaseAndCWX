using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// </summary>
    public class LocationView
    {
        private readonly Location location;
        private readonly ICollection<Package> packages;
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        /// <summary>
        /// Initializes a new instance of the <see cref="LocationView"/> class.
        /// </summary>
        /// <param name="location">The location.</param>
        public LocationView(Location location)
        {
            //packages = RepositoryHelper.GetPackages(location);
            packages=repositoryFactory.GetPackageRepository().Find(new PackageInLocationSpecification(location));

            this.location = location;
        }

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return location.Name; }
        }

        /// <summary>
        /// Gets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return location.Uid; }
        }

        /// <summary>
        /// Gets the number of packages.
        /// </summary>
        /// <value>The number of packages.</value>
        public long NumberOfPackages
        {
            get { return packages.Count; }
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return (int) Uid;
        }
    }
}