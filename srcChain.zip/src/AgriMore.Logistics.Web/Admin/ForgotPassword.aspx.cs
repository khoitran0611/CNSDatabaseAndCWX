﻿using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Web.Helpers;
using Resources;

namespace AgriMore.Logistics.Web.Admin
{
    public partial class ForgotPassword : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMsg.Visible = false;
        }

        protected void BtnSendClick(object sender, EventArgs e)
        {
            IList<User> users = RepFactory.GetUserRepository().Find(new UserByUserNameSpecification(txtUsername.Text)).ToList();

            if (users.Count <= 0)
            {
                lblMsg.Text = Localization.ForgotPassword_UsernameIsNotExistInSystem;
                lblMsg.CssClass = "ErrorMsg";
                lblMsg.Visible = true;

                return;
            }

            User user = users[0];
            if (string.IsNullOrEmpty(user.Email))
            {
                lblMsg.Text = Localization.ForgotPassword_YourEmailIsNotExist;
                lblMsg.CssClass = "ErrorMsg";
                lblMsg.Visible = true;

                return;
            }

            if (!string.IsNullOrEmpty(txtEmail.Text) && !string.IsNullOrEmpty(user.Email) && user.Email.IndexOf(txtEmail.Text, System.StringComparison.Ordinal) < 0)
            {
                lblMsg.Text = Localization.ForgotPassword_UsernameAndEmailNotExistInSystem;
                lblMsg.CssClass = "ErrorMsg";
                lblMsg.Visible = true;

                return;
            }

            string toEmail = txtEmail.Text;
            if (string.IsNullOrEmpty(toEmail)) toEmail = user.Email;

            string resetPasswordCode = Guid.NewGuid().ToString();
            string domainName = ConfigurationManager.AppSettings["DomainName"];
            string resetPasswordLink = string.Format("{0}/Admin/ResetPassword.aspx?uid={1}&rsc={2}", domainName, user.Uid, resetPasswordCode);
            
            string emailContent = "nl-NL".Equals(user.UsingLang) ? Localization.ResetPassword_EmailContentNL : Localization.ResetPassword_EmailContentEN;
            emailContent = emailContent.Replace("$Username", user.Username).Replace("$ResetPassLink", resetPasswordLink);

            EmailSender.SendMail(toEmail, "Reset password notification", emailContent);
            user.ActiveCode = resetPasswordCode;

            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                RepFactory.GetUserRepository().Store(user);
                transactionManager.CommitTransaction();

                lblMsg.Text = Localization.GlobalLabel_ResetPasswordEmailHasBeenSent;
                lblMsg.CssClass = "SuccMsg";
                lblMsg.Visible = true;
            }
            catch (ArgumentException exception)
            {
                transactionManager.RollbackTransaction();
                throw exception;                
            }
        }
    }
}
