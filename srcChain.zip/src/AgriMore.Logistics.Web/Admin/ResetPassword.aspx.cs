﻿using System;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Transaction;
using Resources;

namespace AgriMore.Logistics.Web.Admin
{
    public partial class ResetPassword : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMsg.Visible = false;
        }

        protected void BtnResetPassClick(object sender, EventArgs e)
        {
            string uid = Request["uid"];
            string resetPassCode = Request["rsc"];

            User user = RepFactory.GetUserRepository().GetOne(Convert.ToInt64(uid));
            if (user == null)
            {
                lblMsg.Text = Localization.GlobalLabel_UserNameIsNotExist;
                lblMsg.CssClass = "ErrorMsg";
                lblMsg.Visible = true;

                return;
            }

            if (!user.ActiveCode.Equals(resetPassCode))
            {
                lblMsg.Text = Localization.GlobalLabel_ResetPasswordCodeIsNotExist;
                lblMsg.CssClass = "ErrorMsg";
                lblMsg.Visible = true;

                return;
            }

            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                user.Password = txtNewPassword.Text;
                RepFactory.GetUserRepository().Store(user);
                transactionManager.CommitTransaction();

                lblMsg.Text = Resources.Localization.GlobalLabel_ChangeSuccessful;
                lblMsg.CssClass = "SuccMsg";
                lblMsg.Visible = true;

            }
            catch
            {
                transactionManager.RollbackTransaction();

                lblMsg.Text = Localization.GlobalLabel_ResetPasswordUnSuccessful;
                lblMsg.CssClass = "ErrorMsg";
                lblMsg.Visible = true;
            }

        }
    }
}
