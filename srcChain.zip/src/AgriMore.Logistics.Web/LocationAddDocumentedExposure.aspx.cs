using System;
using System.Web.UI;

namespace AgriMore.Logistics.Web
{
    public partial class LocationAddDocumentedExposure : Page
    {
        private const string urlDefault = "default.aspx";

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                Page.Validate();
            }
        }

        /// <summary>
        /// Handles the Click event of the ButtonSave control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonSave_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                try
                {
                    DocumentExposures1.AddMeasurementsToLocation(String.Empty);
                }
                catch(Exception exception)
                {
                    CustomValidatorControl.IsValid = false;
                    CustomValidatorControl.ErrorMessage = exception.InnerException.Message;
                    return;
                }
                
                Response.Redirect(urlDefault, false);
            }
        }
    }
}