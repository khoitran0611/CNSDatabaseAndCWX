using System.Web;
using System.Web.Services;
using AgriMore.Logistics.Domain;
using System;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// Summary description for $codebehindclassname$
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class Downloadfile : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            string type = context.Request.QueryString["type"];
            long uid = long.Parse(context.Request.QueryString["uid"]);
            long index = context.Request.QueryString["index"] != null ? long.Parse(context.Request.QueryString["index"]) : 0;

            string fileName = string.Empty, pathFile = string.Empty;
            switch (type)
            {
                case "loadingAdviceDoc":
                {
                    var shipment = RepositoryHelper.GetShipment(uid);

                    fileName = shipment.LoadingAdviceDocName;
                    var fileNames = fileName.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                    var storeLocations = shipment.LoadingAdviceDocPath.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                    for (var i = 0; i < fileNames.Length; i++)
                    {
                        if (i == index)
                        {
                            fileName = fileNames[i];
                            pathFile = context.Server.MapPath(storeLocations[i]);                               
                        }
                    }
                    break;               
                }

                default:
                {
                    fileName = "";
                    pathFile = "";                       
                    break;
               }
            }

            if (System.IO.File.Exists(pathFile))
            {
                context.Response.Clear();
                context.Response.ContentType = GetContentType(fileName);
                context.Response.AddHeader("Cache-Control", "public");
                context.Response.AddHeader("Pragma", "no cache");
                context.Response.AddHeader("Content-Description", "super");
                context.Response.AddHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");

                byte[] bytes = System.IO.File.ReadAllBytes(pathFile);
                context.Response.OutputStream.Write(bytes, 0, bytes.Length);
                context.Response.Flush();
                context.Response.End();
            }
            else
                context.Response.Write("The file does not exist!");
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        private string GetContentType(string fileName)
        {
            string contentType = "application/octetstream";
            string ext = System.IO.Path.GetExtension(fileName).ToLower();
            Microsoft.Win32.RegistryKey registryKey = Microsoft.Win32.Registry.ClassesRoot.OpenSubKey(ext);
            if (registryKey != null && registryKey.GetValue("Content Type") != null)
                contentType = registryKey.GetValue("Content Type").ToString();

            return contentType;
        }
    }
}
