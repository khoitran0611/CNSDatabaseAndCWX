using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Web
{
    public partial class CheckoutSfpFromShelf : Page
    {
        private const string locationid = "locationid";
        private const string name = "Name";
        private const string uid = "Uid";
        private const string urlDefault = "default.aspx";
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();
        private ChainEntity chainEntityForCurrentUser;

        /// <summary>
        /// Gets the chain entity for current user.
        /// </summary>
        /// <returns></returns>
        private ChainEntity GetChainEntityForCurrentUser()
        {
            if (chainEntityForCurrentUser == null)
            {
                chainEntityForCurrentUser = RepositoryHelper.GetChainEntityForCurrentUser();
            }
            return chainEntityForCurrentUser;
        }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            ErrorHelper.SetErrorLabel(false, string.Empty, LabelError, false);

            try
            {
                if (!IsPostBack)
                {
                    string locIdFromSession = Session[locationid] as string;
                    bool errorOccured = false;
                    Location location = null;
                    Address address = null;

                    try
                    {
                        location = repositoryFactory.GetLocationRepository().GetOne(long.Parse(locIdFromSession));
                        if (location == null)
                        {
                            errorOccured = true;
                            ErrorHelper.SetErrorLabel(true, "Can not retrieve Location", LabelError, false);
                        }
                    }
                    catch (Exception)
                    {
                        errorOccured = true;
                        ErrorHelper.SetErrorLabel(true, ResourceAgriMore.GeneralErrorMessage, LabelError, false);
                    }

                    if (!errorOccured)
                    {
                        try
                        {
                            address = GetAddress(location);
                            if (address == null)
                            {
                                errorOccured = true;
                                ErrorHelper.SetErrorLabel(true, "Can not retrieve Address", LabelError, false);
                            }
                        }
                        catch (Exception)
                        {
                            errorOccured = true;
                            ErrorHelper.SetErrorLabel(true, ResourceAgriMore.GeneralErrorMessage, LabelError, false);
                        }
                    }

                    if (!errorOccured)
                    {
                        BindPackagesWithSpecificLocation(location);
                        BindCashRegistersWithSpecificAddress(address);
                    }
                    else
                    {
                        MultiViewPackageList.SetActiveView(ViewErrors);
                    }
                }
                else
                {
                    Page.Validate();
                }
            }
            catch (Exception exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.ToString(), LabelError, true);
            }
        }


        /// <summary>
        /// Gets the address.
        /// </summary>
        /// <param name="loc">The loc.</param>
        /// <returns></returns>
        private Address GetAddress(Location loc)
        {
            foreach (Address address in GetChainEntityForCurrentUser().Addresses)
            {
                foreach (Location location in address.Locations)
                {
                    if (location.Equals(loc))
                    {
                        return address;
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// Handles the Click event of the linkButtonCheckout control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void linkButtonCheckout_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                string locIdFromSession = Session[locationid] as string;

                TransactionManager transactionManager = new TransactionManager();

                try
                {
                    transactionManager.BeginTransaction();

                    Location location = repositoryFactory.GetLocationRepository().GetOne(long.Parse(locIdFromSession));

                    Address address = GetAddress(location);
                    CashRegister cashRegister =
                        GetCashRegister(address, long.Parse(DropDownListCashRegister.SelectedValue));
                    string remarks = TextBoxRemark.Text;
                    string vpsRemarks = CreateVpsRemarks(remarks, cashRegister);

                    User user = RepositoryHelper.GetCurrentUser();
                    
                    List<Package> packagesToCheckout = GetSelectedPackages();

                    IRepository<Package> packageRepository = repositoryFactory.GetPackageRepository();
                    Dictionary<Package,ExposureDocument> packageExporeDocument = new Dictionary<Package, ExposureDocument>();
                    
                    foreach (Package package in packagesToCheckout)
                    {
                        ExposureDocument ed = location.Remove(package, DateTimeOfCheckout.GetDatetime());
                        packageRepository.Store(package);
                        packageExporeDocument.Add(package, ed);
                    }

                    repositoryFactory.GetLocationRepository().Store(location);

                    packageRepository.Flush();

                    foreach (Package package in packageExporeDocument.Keys)
                    {
                        RepositoryHelper.CreateProcessingSteps(package, packageExporeDocument[package], ProcessingStepType.CheckOut,
                                                               user, vpsRemarks);
                    }


                    transactionManager.CommitTransaction();
                    Response.Redirect(urlDefault, false);
                }
                catch(ArgumentNullException ane)
                {
                    domainValidator.IsValid = false;
                    domainValidator.ErrorMessage = ane.Message;
                }
                catch(ArgumentException ae)
                {
                    domainValidator.IsValid = false;
                    domainValidator.ErrorMessage = ae.Message;
                }
                catch (Exception exception)
                {
                    ErrorHelper.HandleException(exception, transactionManager, LabelError);
                    return;
                }

                
            }
        }

        /// <summary>
        /// Creates the VPS remarks.
        /// </summary>
        /// <param name="remarksFromUser">The remarks from user.</param>
        /// <param name="cr">The cr.</param>
        /// <returns></returns>
        private static string CreateVpsRemarks(string remarksFromUser, CashRegister cr)
        {
            if (remarksFromUser == null || remarksFromUser.Trim() == String.Empty)
            {
                remarksFromUser = "Non applied";
            }

            return String.Format(ProcessingStepDocument.CheckoutSfp, DateTime.Now.ToString(ProcessingStepDocument.DateTimeFormat), cr.Name, remarksFromUser);
        }
        /// <summary>
        /// Gets the cash register.
        /// </summary>
        /// <param name="address">The address.</param>
        /// <param name="cashRegisterId">The cash register id.</param>
        /// <returns></returns>
        private static CashRegister GetCashRegister(Address address, long cashRegisterId)
        {
            foreach (CashRegister register in address.CashRegisters)
            {
                if (register.Uid.Equals(cashRegisterId))
                {
                    return register;
                }
            }

            return null;
        }

        /// <summary>
        /// Binds the data.
        /// </summary>
        private void BindPackagesWithSpecificLocation(Location location)
        {
            ChainEntity chainEntity = GetChainEntityForCurrentUser();

            foreach (Package package in location.Packages)
            {
                string packageName = RepositoryHelper.CreatePackageName(package, chainEntity);
                ListBoxPackages.Items.Add(new ListItem(packageName, package.Uid.ToString()));
            }
        }

        /// <summary>
        /// Binds the cash registers with specific address.
        /// </summary>
        /// <param name="address">The address.</param>
        private void BindCashRegistersWithSpecificAddress(Address address)
        {
            DropDownListCashRegister.DataSource = address.CashRegisters;
            DropDownListCashRegister.DataValueField = uid;
            DropDownListCashRegister.DataTextField = name;
            DropDownListCashRegister.DataBind();
        }

        /// <summary>
        /// Gets the selected packages.
        /// </summary>
        /// <returns></returns>
        private List<Package> GetSelectedPackages()
        {
            List<Package> packages = new List<Package>();

            foreach (ListItem item in ListBoxPackages.Items)
            {
                if (item.Selected)
                {
                    Package package = GetSelectedPackage(repositoryFactory, item);

                    if (package != null)
                    {
                        packages.Add(package);
                    }
                }
            }

            return packages;
        }

        /// <summary>
        /// Gets the selected package.
        /// </summary>
        /// <param name="repositoryFactory">The repository factory.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        private static Package GetSelectedPackage(RepositoryFactory repositoryFactory, ListItem item)
        {
            Package selectedPackage;

            selectedPackage = repositoryFactory.GetPackageRepository().GetOne(long.Parse(item.Value));

            return selectedPackage;
        }
    }
}
