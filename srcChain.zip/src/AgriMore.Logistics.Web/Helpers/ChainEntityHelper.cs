using System.Security.Principal;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public static class ChainEntityHelper
    {
        /// <summary>
        /// Gets the chain entity through user from the chainentity repository.
        /// </summary>
        /// <returns></returns>
        public static ChainEntity GetChainEntityThroughUser(IPrincipal pageUser)
        {
            RepositoryFactory repositoryFactory = new RepositoryFactory();

            User user =
                repositoryFactory.GetUserRepository().GetOne(new UserByUserNameSpecification(pageUser.Identity.Name));

            ISpecification<ChainEntity> chainEntityForTheUserSpecification =
                new ChainEntityForTheUserSpecification(user);

            IRepository<ChainEntity> chainEntityRepository = repositoryFactory.GetChainEntityRepository();

            return chainEntityRepository.GetOne(chainEntityForTheUserSpecification);
        }
    }
}