using System;
using System.Drawing;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain.Transaction;
using log4net;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public static class ErrorHelper
    {
        /// <summary>
        /// Disables the error label.
        /// </summary>
        public static void SetErrorLabel(bool enabled, string message, Label errorLabel,bool useDefaultMessage,Exception exception)
        {
            ILog log = LogManager.GetLogger(typeof(ErrorHelper));

            if(useDefaultMessage)
            {
                errorLabel.Text = ResourceAgriMore.GeneralErrorMessage;
                log.Debug(exception.Message + " " + exception.InnerException.Message);
            }
            else
            {
                errorLabel.Text = message;
            }
            errorLabel.Visible = enabled;
            errorLabel.ForeColor = Color.Red;
        }

        /// <summary>
        /// Disables the error label.
        /// </summary>
        public static void SetErrorLabel(bool enabled, string message, Label errorLabel, bool useDefaultMessage)
        {
            ILog log = LogManager.GetLogger(typeof(ErrorHelper));

            if (useDefaultMessage)
            {
                errorLabel.Text = ResourceAgriMore.GeneralErrorMessage;
                log.Debug(message);
            }
            else
            {
                errorLabel.Text = message;
            }
            errorLabel.Visible = enabled;
            errorLabel.ForeColor = Color.Red;
        }

        /// <summary>
        /// Handles the exception.
        /// </summary>
        /// <param name="exception">The exception.</param>
        /// <param name="transactionManager">The transaction manager.</param>
        public static void HandleException(Exception exception, TransactionManager transactionManager)
        {
            HandleException(exception, transactionManager, null);
        }

        /// <summary>
        /// Handles the exception.
        /// </summary>
        /// <param name="exception">The exception.</param>
        /// <param name="transactionManager">The transaction manager.</param>
        /// <param name="labelError">The label error.</param>
        public static void HandleException(Exception exception, TransactionManager transactionManager, Label labelError)
        {
            transactionManager.RollbackTransaction();

            if (labelError != null && (exception is ArgumentNullException || exception is ArgumentException))
            {
                SetErrorLabel(true, exception.Message, labelError, false);
            }
            else
            {
                throw new ApplicationException("An unexpected error has occurred.", exception);
            }
        }
    }
}