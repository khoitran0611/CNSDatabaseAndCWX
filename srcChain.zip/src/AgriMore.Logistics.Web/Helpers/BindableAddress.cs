namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public struct BindableAddress
    {
        public long uid;
        public string name;
        /// <summary>
        /// Gets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
        }

        /// <summary>
        /// Gets the address representation.
        /// </summary>
        /// <value>The address representation.</value>
        public string Name
        {
            get { return name; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BindableAddress"/> struct.
        /// </summary>
        /// <param name="uid">The uid.</param>
        /// <param name="name">The address representation.</param>
        public BindableAddress(long uid, string name)
        {
            this.uid = uid;
            this.name = name;
        }
    }
}