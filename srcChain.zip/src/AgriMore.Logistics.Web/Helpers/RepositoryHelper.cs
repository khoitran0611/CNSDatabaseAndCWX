using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using log4net;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using System.Collections;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public static class RepositoryHelper
    {
        private static readonly RepositoryFactory repositoryFactory = new RepositoryFactory();
        private static readonly ILog log = LogManager.GetLogger(typeof(RepositoryHelper));

        /// <summary>
        /// Gets the current user.
        /// </summary>
        /// <returns></returns>
        public static User GetCurrentUser()
        {
            return repositoryFactory.GetUserRepository().GetOne(
                new UserByUserNameSpecification(HttpContext.Current.User.Identity.Name));
        }
        /// <summary>
        /// Gets the chain entity through user from the chainentity repository.
        /// </summary>
        /// <returns></returns>
        public static ChainEntity GetChainEntityForCurrentUser()
        {
            User user =
                    repositoryFactory.GetUserRepository().GetOne(
                        new UserByUserNameSpecification(HttpContext.Current.User.Identity.Name));

            ISpecification<ChainEntity> chainEntityForTheUserSpecification =
                new ChainEntityForTheUserSpecification(user);

            IRepository<ChainEntity> chainEntityRepository = repositoryFactory.GetChainEntityRepository();


            return chainEntityRepository.GetOne(chainEntityForTheUserSpecification);
        }

        /// <summary>
        /// Creates the name of the package.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="chainEntity">The chain entity.</param>
        /// <returns></returns>
        public static string CreatePackageName(Package package, ChainEntity chainEntity)
        {
            var builder = new StringBuilder();
            var name = string.Empty;
            var currentUser = RepositoryHelper.GetCurrentUser();

            //ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

            IList<PackagingDefine> allPackageTypes = new List<PackagingDefine>();
            if (HttpContext.Current.Cache["AllPackageTypes_" + currentUser.UsingLang] == null)
            {
                allPackageTypes = ProductServices.GetAllPackageTypes(currentUser.UsingLang, 0, 0, chainEntity.Uid);
                HttpContext.Current.Cache.Insert("AllPackageTypes_" + currentUser.UsingLang, allPackageTypes, null, DateTime.Now.AddMinutes(60), System.Web.Caching.Cache.NoSlidingExpiration);
            }

            //List<PackagingDefine> allPackageTypes = new List<PackagingDefine>();
            if (HttpContext.Current.Cache["AllPackageTypes_" + currentUser.UsingLang] != null)
            {
                allPackageTypes = (List<PackagingDefine>)HttpContext.Current.Cache["AllPackageTypes_" + currentUser.UsingLang];
            }


            var packageType = allPackageTypes.Where(p => p.Uid == package.PackageTypeId).FirstOrDefault();

            //var packageType = ProductServices.GetAllPackageTypesGetPackagingDefineByLangCode(package.PackageTypeId, currentUser.UsingLang);

            string chainEntityIdentification = package.IdentificationForChainEntity(chainEntity);
            foreach (var product in package.PrimaryProducts)
            {
                if (!string.IsNullOrEmpty(product.ProductionAreaId))
                {
                    name += product.ProductionAreaId + " | ";
                }
            }

            if (name.Length > 0)
            {
                if (packageType != null)
                {
                    builder.Append(string.Format("ID: {0} [{1}] - {2} ({3})", package.Uid, chainEntityIdentification, packageType.Name, name.Substring(0, name.Length - 3)));
                }
                else
                {
                    builder.Append(string.Format("ID: {0} [{1}] - {2} ({3})", package.Uid, chainEntityIdentification, "", name.Substring(0, name.Length - 3)));
                }
            }
            else
            {
                if (packageType != null)
                {
                    builder.Append(string.Format("ID: {0} [{1}] - {2} ({3})", package.Uid, chainEntityIdentification, packageType.Name, ""));
                }
                else
                {
                    builder.Append(string.Format("ID: {0} [{1}] - {2} ({3})", package.Uid, chainEntityIdentification, "", ""));
                }

            }

            return builder.ToString();

            //example: "Appels (LCID123:PAID321), Peren (123:321, 8372:192), A1"
            //String format = "{0} ({1}:{2}), {5}, {3}, {4}";
            //StringBuilder builder = new StringBuilder();

            //string chainEntityIdentification = package.IdentificationForChainEntity(chainEntity);


            //foreach (PrimaryProduct primaryProduct in package.PrimaryProducts)
            //{
            //    string name =
            //        string.Format(format, primaryProduct.HarvestedProductDescription, primaryProduct.ProductionAreaId,
            //                      primaryProduct.LifeCycleId, package.ProductCode, package.PackageType.Name, "ID: " + chainEntityIdentification);
            //    builder.Append(name);
            //}
            //return builder.ToString();
        }

        public static string GetPackageId(Package package, ChainEntity chainEntity)
        {
            var builder = new StringBuilder();
            string chainEntityIdentification = package.IdentificationForChainEntity(chainEntity);
            builder.Append(string.Format("{0} [{1}]", package.Uid, chainEntityIdentification));

            return builder.ToString();
        }

        public static Shipment GetShipment(long uid)
        {
            return repositoryFactory.GetShipmentRepository().GetOne(uid);
        }

        /// <summary>
        /// Gets the identifications from bulk.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <returns></returns>
        public static List<Identification> GetIdentificationsFromBulk(Package package)
        {
            List<Package> allPackages = new List<Package>();
            ICollection<RepackPackageRelationship> relationships =
                repositoryFactory.GetRepackPackageRelationshipRepository().Find(
                    new RepackedRelationshipByPackage(package));

            foreach (RepackPackageRelationship packageRelationship in relationships)
            {
                long packageToRetrieve = -1;

                if (packageRelationship.NewPackageFromRepackId == package.Uid)
                {
                    packageToRetrieve = packageRelationship.RepackedPackageId;
                }
                else if (packageRelationship.RepackedPackageId == package.Uid)
                {
                    packageToRetrieve = packageRelationship.NewPackageFromRepackId;
                }

                if (packageToRetrieve != -1)
                {
                    Package tmpPackage = repositoryFactory.GetPackageRepository().GetOne(packageToRetrieve);
                    if (tmpPackage != null)
                    {
                        if (!allPackages.Contains(tmpPackage))
                        {
                            allPackages.Add(tmpPackage);
                        }
                    }
                }
            }

            List<Identification> allIdentifications = new List<Identification>();
            foreach (Package packageTmp in allPackages)
            {
                foreach (Identification identification in packageTmp.Identifications)
                {
                    if (!allIdentifications.Contains(identification))
                    {
                        allIdentifications.Add(identification);
                    }
                }
            }

            return allIdentifications;
        }

        /// <summary>
        /// Gets the identification from chain entities done business with.
        /// </summary>
        /// <param name="requester">The requester.</param>
        /// <param name="idents">The idents.</param>
        /// <param name="chains">The chains.</param>
        public static void GetIdentificationFromChainEntitiesDoneBusinessWith(ChainEntity requester, List<Identification> allidents, List<Identification> idents, List<ChainEntity> chains, long packageType)
        {
            ICollection<Package> packagesKnownByRequesterChainEntity =
                            repositoryFactory.GetPackageRepository().Find(new PackageKnownByChainEntity(requester));

            List<long> packageIds = new List<long>();
            List<Identification> identifications = new List<Identification>();
            List<Identification> allIdentifications = new List<Identification>();
            List<ChainEntity> chainEntities = new List<ChainEntity>();
            //Refactor
            //string wholesalePackagingName = "wholesalePackaging";

            foreach (Package package in packagesKnownByRequesterChainEntity)
            {
                ICollection<ProcessingStep> steps = repositoryFactory.GetProcessingStepRepository().Find(
                    new ProcessingStepsByPackage(package));

                foreach (ProcessingStep step in steps)
                {
                    if (!packageIds.Contains(step.PackageId))
                    {
                        if (step.PackageId != -1)
                        {
                            packageIds.Add(step.PackageId);
                        }
                    }

                    if (!packageIds.Contains(step.PackageParentId))
                    {
                        if (step.PackageParentId != -1)
                        {
                            packageIds.Add(step.PackageParentId);
                        }
                    }
                }
            }

            foreach (long packageId in packageIds)
            {
                Package package = repositoryFactory.GetPackageRepository().GetOne(packageId);
                List<Identification> identificationsFromBulk = GetIdentificationsFromBulk(package);
                //ICollection<ProcessingStep> packages = repositoryFactory.GetProcessingStepRepository().Find(
                //    new ProcessingStepsByPackageAndIsParent(repositoryFactory.GetPackageRepository().GetOne(packageId)));

                foreach (Identification identificationFromBulk in identificationsFromBulk)
                {
                    if (!chainEntities.Contains(identificationFromBulk.ChainEntity))
                    {
                        chainEntities.Add(identificationFromBulk.ChainEntity);
                    }

                    if (!allIdentifications.Contains(identificationFromBulk))
                    {
                        allIdentifications.Add(identificationFromBulk);
                    }

                    //Refactor
                    //if (identificationFromBulk.Package.PackageType.PackageTypeCategory.Name == wholesalePackagingName)
                    //{
                    //    if (!identifications.Contains(identificationFromBulk))
                    //    {
                    //        identifications.Add(identificationFromBulk);
                    //    }
                    //}

                    if (identificationFromBulk.Package.PackageTypeCategoryId == packageType) //wholeSale
                    {
                        if (!identifications.Contains(identificationFromBulk))
                        {
                            identifications.Add(identificationFromBulk);
                        }
                    }
                }


                foreach (Identification identification in package.Identifications)
                {

                    if (!chainEntities.Contains(identification.ChainEntity))
                    {
                        chainEntities.Add(identification.ChainEntity);
                    }


                    if (!allIdentifications.Contains(identification))
                    {
                        allIdentifications.Add(identification);
                    }

                    //Refactor
                    //if (package.PackageType.PackageTypeCategory.Name == wholesalePackagingName)
                    //{

                    //    if (!identifications.Contains(identification))
                    //    {
                    //        identifications.Add(identification);
                    //    }
                    //}

                    if (package.PackageTypeCategoryId == packageType) // wholesales
                    {

                        if (!identifications.Contains(identification))
                        {
                            identifications.Add(identification);
                        }
                    }
                }
            }

            allidents.AddRange(allIdentifications);
            idents.AddRange(identifications);
            chains.AddRange(chainEntities);
        }



        //}
        /// <summary>
        /// Creates the processing steps.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="treatments">The treatments.</param>
        /// <param name="processingStepType">Type of the processing step.</param>
        /// <param name="currentUser">The current user.</param>
        /// <returns></returns>
        public static IEnumerable<ProcessingStep> CreateProcessingSteps(Package package, IEnumerable<Treatment> treatments, ProcessingStepType processingStepType, User currentUser)
        {
            ProcessingStepDocument stepDocument = new ProcessingStepDocument(package, treatments, processingStepType, currentUser, String.Empty);

            try
            {
                foreach (ProcessingStep step in stepDocument.Steps)
                {
                    repositoryFactory.GetProcessingStepRepository().Add(step);
                }

            }
            catch (Exception exception)
            {
                log.Debug(exception.ToString());
                throw;
            }

            return stepDocument.Steps;
        }

        /// <summary>
        /// Creates the processing steps.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="exposureDocument">The exposureDocument.</param>
        /// <param name="processingStepType">Type of the action.</param>
        /// <param name="user">The user.</param>
        /// <param name="remarks">The remarks.</param>
        /// <returns></returns>
        public static IEnumerable<ProcessingStep> CreateProcessingSteps(Package package, ExposureDocument exposureDocument, ProcessingStepType processingStepType, User user, string remarks)
        {
            if (processingStepType == ProcessingStepType.CheckOut || processingStepType == ProcessingStepType.RemovedFromLocation || processingStepType == ProcessingStepType.Documented)
            {
                ProcessingStep ps = repositoryFactory.GetProcessingStepRepository().GetOne(
                    new ProcessingStepByPackageAndExposureDocument(package, exposureDocument));

                if (ps != null)
                {
                    ps.AddRemark(remarks);
                    repositoryFactory.GetProcessingStepRepository().Store(ps);
                }

                return null;
            }

            ProcessingStepDocument stepDocument = new ProcessingStepDocument(package, exposureDocument, processingStepType, user, remarks);

            try
            {
                foreach (ProcessingStep step in stepDocument.Steps)
                {
                    repositoryFactory.GetProcessingStepRepository().Add(step);
                }
            }
            catch (Exception exception)
            {
                log.Debug(exception.ToString());
                throw;
            }

            return stepDocument.Steps;
        }

        /// <summary>
        /// Check if the given Identifications for the Chainentity exists.
        /// </summary>
        /// <param name="iden">The iden.</param>
        /// <param name="chainEntity">The chain entity.</param>
        /// <returns></returns>
        public static bool IdentificationExists(string iden, ChainEntity chainEntity)
        {
            IRepository<Identification> identificationRepository = new RepositoryFactory().GetIdentificationRepository();
            Identification identification = identificationRepository.GetOne(new IdentificationByChainEntityAndIdentification(chainEntity, iden));

            return identification != null;
        }

        public static bool IdentificationExists(Identification iden, ChainEntity chainEntity)
        {
            IList<Identification> idenByChain = new RepositoryFactory().GetIdentificationRepository().Find(new IdentificationByChainEntity(chainEntity)).ToList();
            idenByChain = idenByChain.Where(it => it.Id == iden.Id).ToList();
            if (idenByChain.Count <= 0) return false;

            for (long idx = iden.FromUid; idx <= iden.ToUid; idx++)
                if (idenByChain.Any(it => it.FromUid <= idx && it.ToUid >= idx)) return true;

            return false;
        }

        public static int GetNumberPackage(PackageType packType, decimal amount, ref bool isRoundUp)
        {
            var weight = packType.Weight.Value;
            var uomName = packType.Weight.UnitOfMeasurement.Name;
            switch (uomName.ToLower())
            {
                case "kg":
                    {
                        var relAmount = amount * 1000;
                        var nPack = (int)(relAmount / weight);

                        if (relAmount % weight > 0)
                        {
                            nPack++;
                            isRoundUp = true;
                        }
                        //throw new ArgumentException(Resources.Localization.CreatingPackageThatDoesNotHaveItsFullContent);
                        //return (int)(relAmount / weight);
                        return nPack;
                    }
                case "grammes":
                    {
                        var relAmount = amount * 1000000;
                        var nPack = (int)(relAmount / weight);
                        if (relAmount % weight > 0)
                        {
                            nPack++;
                            isRoundUp = true;
                        }
                        //throw new ArgumentException(Resources.Localization.CreatingPackageThatDoesNotHaveItsFullContent);
                        //return (int)(relAmount / weight);
                        return nPack;
                    }
                default:
                    {
                        throw new ArgumentException("Package UOM is invalid");
                    }
            }
        }

        public static void SplitPackageGroup(Package packGroup, int[] splitPart, ChainEntity chainEntity, Location location = null)
        {
            var transactionManager = new TransactionManager();
            var lstPackageIds = new List<long>();
            try
            {
                var numPack = (packGroup.ToUid - packGroup.FromUid) + 1;
                List<long> lstSplitPart = new List<long>();
                foreach (var i in splitPart)
                {
                    if (i > 0)
                    {
                        lstSplitPart.Add(i);
                    }
                }

                long sumSplit = 0;
                foreach (var i in lstSplitPart)
                {
                    sumSplit += i;
                }

                if (lstSplitPart.Count == 1 && sumSplit == numPack) return; //--> Do not split
                if (numPack > sumSplit) lstSplitPart.Add(numPack - sumSplit);

                transactionManager.BeginTransaction();

                long fromUid = packGroup.FromUid;
                IList<Package> lstSplitPacks = new List<Package>();
                //PackageStatus packageStatus = packGroup.GetPackageStatus();
                ExposureDocument exposureDocument = packGroup.CurrentExposureDocument;

                foreach (int nPack in lstSplitPart)
                {
                    long toId = fromUid + (nPack - 1);
                    var identifications = packGroup.Identifications;
                    var listIdtf = new List<Identification>();
                    foreach (var iden in identifications)
                    {
                        listIdtf.Add(new Identification(iden.Id, chainEntity, fromUid, toId));
                    }

                    //Refactor
                    //var splitPack = new Package(packGroup.PackageType, packGroup.PrimaryProducts, packGroup.PackingDateTime, listIdtf, packGroup.ProductCode)
                    var splitPack = new Package(packGroup.PackageTypeId, packGroup.PrimaryProducts, packGroup.PackingDateTime, listIdtf, packGroup.ProductCode, packGroup.PackageTypeCategoryId, packGroup.PackageTypeName)
                    {
                        FromUid = fromUid,
                        ToUid = toId,
                        ParentPackage = packGroup
                    };
                    //Update Exposure document and status for splited package
                    if (location != null)
                    {
                        //splitPack.AddPackageStatus(packageStatus);

                        var newExposureDocument = new ExposureDocument(location, splitPack, exposureDocument.DateOfPlacement);
                        splitPack.AddExposureDocument(newExposureDocument);
                        foreach (Exposure exposure in exposureDocument.Exposures)
                            newExposureDocument.AddExposure(exposure);
                    }

                    repositoryFactory.GetPackageRepository().Add(splitPack);
                    repositoryFactory.GetPackageRepository().Flush();
                    lstSplitPacks.Add(splitPack);

                    fromUid = splitPack.ToUid + 1;
                }

                foreach (var package in lstSplitPacks)
                {
                    lstPackageIds.Add(package.Uid);
                }

                if (location != null)
                    AddPackagesIntoLocation(location, lstPackageIds.ToArray());

                packGroup.HasChild = true;
                packGroup.IsSplitted = true;
                repositoryFactory.GetPackageRepository().Store(packGroup);

                transactionManager.CommitTransaction();
            }
            catch (Exception)
            {
                transactionManager.RollbackTransaction();
                throw;
            }
        }

        public static void AddPackagesIntoLocation(Location location, long[] packageIds)
        {
            var sqlQuery = string.Empty;
            if (packageIds.Length > 0)
            {
                sqlQuery = "insert into locationpackage (LocationId,PackageId) values";
                foreach (var packageId in packageIds)
                {
                    sqlQuery += "(" + location.Uid + ", " + packageId + "),";
                }

                sqlQuery = sqlQuery.Substring(0, sqlQuery.Length - 1);
            }

            if (string.IsNullOrEmpty(sqlQuery)) return;
            using (var cmd = NHibernateHttpModule.GetSession.Connection.CreateCommand())
            {
                cmd.CommandText = sqlQuery;

                cmd.ExecuteNonQuery();
            }
        }
    }
}