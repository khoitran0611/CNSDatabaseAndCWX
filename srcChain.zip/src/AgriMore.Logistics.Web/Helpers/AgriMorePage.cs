using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using System;
using System.Globalization;
using System.Threading;
using System.Web;
using System.Web.UI;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    ///
    /// </summary>
    public class AgriMorePage : Page
    {
        #region Properties
        protected readonly RepositoryFactory RepFactory = new RepositoryFactory();

        #endregion

        //public abstract void CheckViewState();

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Init"></see> event to initialize the page.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> that contains the event data.</param>
        protected override void OnInit(EventArgs e)
        {
            // Allow The Base Class To Intialize First
            base.OnInit(e);

            SetCacheability();

            // Is this still necessary?
            bool isAuthenticated = User.Identity.IsAuthenticated;
            //bool isInRole = User.IsInRole(shipperRole);

            if (!isAuthenticated )//&& !isInRole)
            {

                //http://aspalliance.com/articleViewer.aspx?aId=520&pId=-1

                //It appears from testing that the Request and Response both share the 
                // same cookie collection.  If I set a cookie myself in the Reponse, it is 
                // also immediately visible to the Request collection.  This just means that 
                // since the ASP.Net_SessionID is set in the Session HTTPModule (which 
                // has already run), thatwe can't use our own code to see if the cookie was 
                // actually sent by the agent with the request using the collection. Check if 
                // the given page supports session or not (this tested as reliable indicator 
                // if EnableSessionState is true), should not care about a page that does 
                // not need session
                if (Context.Session != null)
                {
                    //Tested and the IsNewSession is more advanced then simply checking if 
                    // a cookie is present, it does take into account a session timeout, because 
                    // I tested a timeout and it did show as a new session
                    if (Session.IsNewSession)
                    {
                        // If it says it is a new session, but an existing cookie exists, then it must 
                        // have timed out (can't use the cookie collection because even on first 
                        // request it already contains the cookie (request and response
                        // seem to share the collection)
                        string szCookieHeader = Request.Headers["Cookie"];
                        if ((null != szCookieHeader) && (szCookieHeader.IndexOf("ASP.NET_SessionId") >= 0))
                        {
                            Session["timeout"] = true;
                            Response.Redirect("SessionTimeout.aspx", false);
                        }
                        else
                        {
                            Response.Redirect("Default.aspx", false);
                        }
                    }
                    else
                        if (Session["timeout"] != null)
                        {
                            if ((bool)Session["timeout"])
                            {
                                Response.Redirect("SessionTimeout.aspx", false);
                            }
                        }
                        else
                        {
                            Response.Redirect("Default.aspx", false);
                        }
                }
            }
        }

        /// <summary>
        /// Sets the cacheability.
        /// </summary>
        protected virtual void SetCacheability()
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
        }        

        public static string CurUserName
        {
            get { return HttpContext.Current.User.Identity.Name; }
        }

        public static string CurLangCode
        {
            get
            {
                string langCulture;
                User curUser = RepositoryHelper.GetCurrentUser();
                langCulture = (curUser != null && !string.IsNullOrEmpty(curUser.UsingLang)) ? curUser.UsingLang : "en-GB";

                return langCulture;
            }
        }

        protected override void InitializeCulture()
        {
            Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = new CultureInfo(CurLangCode);
            //base.InitializeCulture();
        }
    }
}