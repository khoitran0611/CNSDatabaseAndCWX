﻿using System;

namespace AgriMore.Logistics.Web.Helpers
{
    public static class StringHelper
    {
        public static int ToInt32(this string iStr)
        {
            return string.IsNullOrEmpty(iStr) ? 0 : Convert.ToInt32(iStr);
        }

        public static long ToInt64(this string iStr)
        {
            return string.IsNullOrEmpty(iStr) ? 0 : Convert.ToInt64(iStr);
        }

        public static decimal ToDecimal(this string dStr)
        {
            decimal cDecimal;
            return decimal.TryParse(dStr, out cDecimal) ? cDecimal : 0;
        }

        public static string Decimal2Str(this decimal dDecimal)
        {
            return dDecimal.ToString("0.###");
        }
    }
}