using System.Text.RegularExpressions;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public static class DoubleHelper
    {
        /// <summary>
        /// Determines whether the specified double value is double.
        /// </summary>
        /// <param name="doubleValue">The double value.</param>
        /// <returns>
        /// 	<c>true</c> if the specified double value is double; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsDouble(string doubleValue)
        {
            return new Regex(@"^[-+]?\d+(\.\d+)?$").IsMatch(doubleValue);
        }
    }
}