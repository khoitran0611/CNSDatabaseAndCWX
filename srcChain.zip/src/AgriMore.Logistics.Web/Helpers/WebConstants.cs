﻿using System;
using System.Collections.Generic;
using System.Web;

namespace AgriMore.Logistics.Web.Helpers
{
    public class WebConstants
    {              
        public static readonly string InfoMsg = "infMsg";
        public static readonly string InfoDtl = "infDtl";
    }

    public enum InfoMessage
    {
        PackSuccessful = 1,
        PutLocationSuccessful = 2,
        InternalMoveSuccessful = 3
    }
}