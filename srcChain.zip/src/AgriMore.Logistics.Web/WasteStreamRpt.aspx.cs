﻿using System;
using System.IO;
using System.Xml;
using System.Xml.Xsl;
using AgriMore.Logistics.Data.Services;

namespace AgriMore.Logistics.Web
{
    public partial class WasteStreamRpt : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;

            GenerateReport();
        }

        /// <summary>
        /// Generates the report.
        /// </summary>
        private void GenerateReport()
        {
            if (string.IsNullOrEmpty(Request["selProd"])) return;

            var strAction = Request["act"];
            //var selYear = Convert.ToInt32(Request["selYear"]);

            var selOrg = Session["SS_REPORT_ORGIDS"] != null ? (string)Session["SS_REPORT_ORGIDS"] : Request["selOrg"];
            var selProdId = Convert.ToInt64(Request["selProd"]);
            var chainId = RepositoryHelper.GetChainEntityForCurrentUser().Uid;

            var fromDate = Convert.ToDateTime(Request["frDt"]);
            var toDate = Convert.ToDateTime(Request["toDt"]);

            var doc = new XmlDocument();
            var xslt = new XslCompiledTransform();
            var isDownload = "down".Equals(strAction);

            string xmlReport = DecompositionInfoServices.BuildWasteStreamRptInfo(chainId, selProdId, fromDate, toDate, selOrg, CurLangCode, isDownload);
            if (string.IsNullOrEmpty(xmlReport)) return;

            xmlReport = xmlReport.Replace("QuantityPackagingTEXT", Resources.Localization.QuantityPackagingTon)
                .Replace("SubstreamsTEXT", Resources.Localization.TonnagesSubstreams)
                .Replace("TEXT_ActualWeight", Resources.Localization.Actual)
                .Replace("TEXT_FigureWeight", Resources.Localization.KeyFigure);
            xslt.Load(typeof(WstStreamRpt));
            doc.LoadXml(xmlReport);

            if (!isDownload)
            {
                var stm = new MemoryStream();
                xslt.Transform(doc, null, stm);

                stm.Position = 1;
                var sr = new StreamReader(stm);
                string strOutput = sr.ReadToEnd().Replace("��", "");
                strOutput = Server.HtmlDecode(strOutput);
                var tempFile = Path.GetTempFileName();
                try
                {
                    File.WriteAllText(tempFile, strOutput);

                    Response.Clear();
                    Response.ContentType = "text/html";
                    Response.Buffer = true;
                    Response.WriteFile(tempFile);
                    Response.Flush();
                    Response.End();
                }
                finally
                {
                    try { File.Delete(tempFile); }
                    catch { }
                }
            }
            else
            {
                Response.Clear();
                Response.ContentType = "application/ms-excel";
                Response.AddHeader("Cache-Control", "public");
                Response.AddHeader("Pragma", "no cache");
                Response.AddHeader("Content-Description", "super");
                Response.AddHeader("Content-Disposition", string.Format("attachment;filename=\"{0}\"", string.Format("WasteStreamRpt_{0}.xls", selProdId)));

                xslt.Transform(doc, null, Response.OutputStream);
                Response.Flush();
                Response.End();
            }
        }
    }
}