using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain.Repository;
using System.Web;
using System.Threading;
using System.Globalization;
using NHibernate.Cfg;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// </summary>
    public partial class Site : MasterPage
    {
        protected HtmlGenericControl chainentity;
        protected HtmlGenericControl login;
        protected HtmlGenericControl role;

        #region Properties
        protected readonly RepositoryFactory RepFactory = new RepositoryFactory();

        #endregion

        public static string CurUserName
        {
            get { return HttpContext.Current.User.Identity.Name; }
        }

        public static string CurLangCode
        {
            get
            {
                string langCulture;
                User curUser = RepositoryHelper.GetCurrentUser();
                langCulture = (curUser != null && !string.IsNullOrEmpty(curUser.UsingLang)) ? curUser.UsingLang : "en-GB";

                return langCulture;
            }
        }

        protected void InitializeCulture()
        {
            Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = new CultureInfo(CurLangCode);
        }

        /// <summary>
        /// Gets the role names display.
        /// </summary>
        /// <param name="roles">The roles.</param>
        /// <returns></returns>
        private static string GetRoleNamesDisplay(IEnumerable<Role> roles)
        {
            StringBuilder sb = new StringBuilder();
            foreach (Role role in roles)
            {
                if (role.Uid > 4 && role.Uid != 6) continue;
                sb.Append(role.Name);
                sb.Append(",");
            }
            string result = sb.ToString();

            if (result != String.Empty)
            {
                if (sb[sb.Length - 1].ToString() == ",")
                {
                    result = sb.Remove(sb.Length - 1, 1).ToString();
                }
            }
            return result;
        }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            imgLeftLg.Src = GetDefaultLeftLogo(Page.Theme);
            var curUser = RepositoryHelper.GetCurrentUser();
            if (curUser == null)
            {
                LoginStatus_LoggedOut(sender, e);
                return;
            }

            login.InnerText = RepositoryHelper.GetCurrentUser().ToString();
            role.InnerText = GetRoleNamesDisplay(RepositoryHelper.GetCurrentUser().Roles);

            var chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();
            chainentity.InnerText = chainEntity.Name;
            IList<string> lstSubAdminIds = OrganizationServices.GetSubAdminIdOfChainEntity(chainEntity.Uid);
            if (lstSubAdminIds.Count > 0)
            {
                var subAdminId = lstSubAdminIds[0];
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["ChangeLogoForSubAdmin"]))
                {
                    string[] logo4SubAdmin = ConfigurationManager.AppSettings["ChangeLogoForSubAdmin"].Split(',');
                    if (logo4SubAdmin.Contains(subAdminId))
                        imgLeftLg.Src = GetSubAdminLeftLogo(Page.Theme, subAdminId);
                }

            }

            InitializeCulture();
        }

        protected void mnuTopMenu_DataBound(object sender, EventArgs e)
        {
            if (mnuTopMenu.SelectedItem != null)
            {
                Session.Add("action", mnuTopMenu.SelectedValue);
            }
        }

        /// <summary>
        /// Handles the DataBound event of the TreeView1 control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        //protected void TreeView1_DataBound(object sender, EventArgs e)
        //{
        //    if (TreeView1.SelectedNode != null)
        //    {
        //        Session.Add("action", TreeView1.SelectedNode.Text);
        //    }
        //}

        protected void SiteMapPath1ItemCreated(object sender, SiteMapNodeItemEventArgs e)
        {
            if (e.Item.ItemIndex == 0 | (e.Item.ItemIndex == 1 && e.Item.ItemType == SiteMapNodeItemType.PathSeparator))
                e.Item.Visible = false;
        }

        /// <summary>
        /// Handles the LoggedOut event of the LoginStatus control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LoginStatus_LoggedOut(object sender, EventArgs e)
        {
            Session.Abandon();
            FormsAuthentication.SignOut();
            Roles.DeleteCookie();

            Response.Redirect(FormsAuthentication.LoginUrl, false);
            Response.End();
        }

        public static string GetDefaultLeftLogo(string theme)
        {
            return string.Format("~/App_Themes/{0}/images/logo.gif", theme);
        }

        public static string GetSubAdminLeftLogo(string theme, string subAdminId)
        {
            return string.Format("~/App_Themes/{0}/images/logo{1}.gif", theme, subAdminId.ToLower());
        }
    }
}