using System;
using System.Collections.Generic;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Web.Helpers;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// This class shows a list of shipments not yet pickedup.
    /// </summary>
    public partial class TreatSemiFinishedProduct : Page
    {
        private const string dataTextField = "Name";
        private const string deletetreatment = "deletetreatment";
        private const string locationid = "locationid";
        private const string treatmentlist = "treatmentlist";
        private const string uid = "Uid";
        private const string urlDefault = "default.aspx";
        private string messageValueMandatory = Resources.Localization.Valueismandatory;
        private string messageValueNumeric = Resources.Localization.Valueisamandatorynumericfield;
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        private ChainEntity chainEntityForCurrentUser;
        private ChainEntity GetChainEntityForCurrentUser()
        {
            if (chainEntityForCurrentUser == null)
            {
                chainEntityForCurrentUser = RepositoryHelper.GetChainEntityForCurrentUser();
            }
            return chainEntityForCurrentUser;
        }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            ErrorHelper.SetErrorLabel(false, string.Empty, LabelError, false);
            ErrorHelper.SetErrorLabel(false, string.Empty, LabelErrorDetail, false);

            try
            {
                if (!IsPostBack)
                {
                    RemoveFomSession();

                    BindTreatmentTypeCategory();

                    SetUnitOfMeasurementLabel();

                    string locIdFromSession = Session[locationid] as string;

                    BindPackagesWithSpecificLocation(long.Parse(locIdFromSession));

                    GridViewTreatment.DataKeyNames = new string[] {uid};

                    linkButtonAddTreatment.Enabled = ListBoxPackages.Items.Count > 0;
                    LinkButtonSaveTreatment.Enabled = ListBoxPackages.Items.Count > 0;
                }

                //BindTreatmentTypeList();                
            }
            catch (Exception exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Removes the fom session.
        /// </summary>
        private void RemoveFomSession()
        {
            Session.Remove(treatmentlist);
        }


        /// <summary>
        /// Handles the Click event of the LinkButtonAddPP control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonAddTreatment_Click(object sender, EventArgs e)
        {
            try
            {
                TextBoxValue.Text = string.Empty;
                MultiViewPackageList.SetActiveView(detail);
            }
            catch (Exception exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonCancel_Click(object sender, EventArgs e)
        {
            try
            {
                MultiViewPackageList.SetActiveView(ViewList);
            }
            catch (Exception exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.ToString(), LabelErrorDetail, true);
            }
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonOk control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonOk_Click(object sender, EventArgs e)
        {
            if (IsValid)
            {
                try
                {
                    Domain.ThirdPartyEntities.TreatmentTypeCategory treatmentTypeCategory = GetTreatmentTypeCategory();

                    Domain.TreatmentType selectedtreatmentType = GetSelectedtreatmentType(treatmentTypeCategory);

                    IRange<DateTime> duration = GetDuration();

                    double value = GetTreatmentValue();
                    
                    AddTreatmentToList(selectedtreatmentType, duration, value, decimal.Parse(txtCost.Text), ddlCurrency.SelectedValue, ddlCostUnit.SelectedValue);

                    BindGridView();

                    MultiViewPackageList.SetActiveView(ViewList);
                }
                catch (ArgumentNullException)
                {
                    ErrorHelper.SetErrorLabel(true, messageValueMandatory, LabelErrorDetail, false);
                }
                catch (ArgumentException exception)
                {
                    ErrorHelper.SetErrorLabel(true, exception.Message, LabelErrorDetail, false);
                }
                catch (FormatException ex)
                {
                    System.Console.WriteLine(ex.ToString());
                    ErrorHelper.SetErrorLabel(true, messageValueNumeric, LabelErrorDetail, false);
                }
                catch (Exception ex)
                {
                    ErrorHelper.SetErrorLabel(true, ex.Message, LabelErrorDetail, true);
                }
            }
        }

        /// <summary>
        /// Adds the treatment to list.
        /// </summary>
        /// <param name="selectedtreatmentType">Type of the selectedtreatment.</param>
        /// <param name="duration">The duration.</param>
        /// <param name="value">The value.</param>
        private void AddTreatmentToList(Domain.TreatmentType selectedtreatmentType, IRange<DateTime> duration, 
            double value, decimal cost, string costCurrency, string costUnit)
        {
            List<Treatment> treatments = GetTreatments();

            Treatment treatment = new Treatment(selectedtreatmentType, duration, value, cost, costCurrency, costUnit);

            treatment.Uid = GetNewTempUidForTreatment(treatments);

            treatments.Add(treatment);
        }

        /// <summary>
        /// Gets the new temp uid for treatment.
        /// </summary>
        /// <returns></returns>
        private static long GetNewTempUidForTreatment(IEnumerable<Treatment> treatments)
        {
            long id = 0;

            foreach (Treatment treatment in treatments)
            {
                if (treatment.Uid > id)
                {
                    id = treatment.Uid;
                }
            }

            return id + 1;
        }

        /// <summary>
        /// Gets the treatments.
        /// </summary>
        /// <returns></returns>
        private List<Treatment> GetTreatments()
        {
            List<Treatment> treatments = GetTreatmentsFromSession();

            if (treatments == null)
            {
                treatments = new List<Treatment>();
                Session.Add(treatmentlist, treatments);
            }
            return treatments;
        }


        /// <summary>
        /// Gets the treatments from session.
        /// </summary>
        /// <returns></returns>
        private List<Treatment> GetTreatmentsFromSession()
        {
            return Session[treatmentlist] as List<Treatment>;
        }

        /// <summary>
        /// Gets the treatment value.
        /// </summary>
        /// <returns></returns>
        private double GetTreatmentValue()
        {
            if (DoubleHelper.IsDouble(TextBoxValue.Text)==false)
            {
                throw new ArgumentException(Resources.Localization.ValueisnotavalidnumberDecimalseperatorshouldbeapoint);    
            }

            CultureInfo MyCultureInfo = new CultureInfo(RepositoryHelper.GetCurrentUser().UsingLang);
            return double.Parse(TextBoxValue.Text, MyCultureInfo);
        }

        /// <summary>
        /// Gets the duration.
        /// </summary>
        /// <returns></returns>
        private IRange<DateTime> GetDuration()
        {
            return new Range<DateTime>(DateTimeControlStart.GetDatetime(), DateTimeControlEnd.GetDatetime());
        }

        /// <summary>
        /// Gets the treatment type category.
        /// </summary>
        /// <returns></returns>
        private Domain.ThirdPartyEntities.TreatmentTypeCategory GetTreatmentTypeCategory()
        {
            return
               ProductServices.GetTreatmentTypeCategoryById(
                    long.Parse(DropDownListTreatmentTypeCategory.SelectedValue));
        }

        /// <summary>
        /// Binds the grid.
        /// </summary>
        private void BindGridView()
        {
            GridViewTreatment.DataSource = GetTreatments();
            GridViewTreatment.DataBind();
        }

        /// <summary>
        /// Gets the type of the selectedtreatment.
        /// </summary>
        /// <param name="treatmentTypeCategory">The treatment type category.</param>
        /// <returns></returns>
        private Domain.TreatmentType GetSelectedtreatmentType(Domain.ThirdPartyEntities.TreatmentTypeCategory treatmentTypeCategory)
        {
            Domain.TreatmentType selectedtreatmentType = null;

            foreach (Domain.ThirdPartyEntities.TreatmentType treatmentType in treatmentTypeCategory.TreatmentTypes)
            {
                if (treatmentType.Uid.ToString() == DropDownListTreatmentType.SelectedValue)
                {
                    selectedtreatmentType = repositoryFactory.GetTreatmentTypeRepository().GetOne(Int64.Parse(DropDownListTreatmentType.SelectedValue));
                }
            }
            return selectedtreatmentType;
        }

        /// <summary>
        /// Binds the treatment type category.
        /// </summary>
        private void BindTreatmentTypeCategory()
        {
            DropDownListTreatmentTypeCategory.DataSource = ProductServices.GetTreatmentTypeCategoryList(); //repositoryFactory.GetTreatmentTypeCategoryRepository();
            DropDownListTreatmentTypeCategory.DataTextField = dataTextField;
            DropDownListTreatmentTypeCategory.DataValueField = uid;
            DropDownListTreatmentTypeCategory.DataBind();

            long id = long.Parse(DropDownListTreatmentTypeCategory.SelectedValue);

            Domain.ThirdPartyEntities.TreatmentTypeCategory treatmentTypeCat = ProductServices.GetTreatmentTypeCategoryById(id);

            BindTreatmentType(treatmentTypeCat);
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the DropDownListTreatmentTypeCategory control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void DropDownListTreatmentTypeCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                long id = long.Parse(DropDownListTreatmentTypeCategory.SelectedValue);

                Domain.ThirdPartyEntities.TreatmentTypeCategory treatmentTypeCategory =
                    ProductServices.GetTreatmentTypeCategoryById(id);

                BindTreatmentType(treatmentTypeCategory);

                SetUnitOfMeasurementLabel();
            }
            catch (Exception exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.ToString(), LabelErrorDetail, true);
            }
        }

        /// <summary>
        /// Binds the type of the treatment.
        /// </summary>
        /// <param name="treatmentTypeCategory">The treatment type category.</param>
        private void BindTreatmentType(Domain.ThirdPartyEntities.TreatmentTypeCategory treatmentTypeCategory)
        {
            DropDownListTreatmentType.Items.Clear();
            foreach (Domain.ThirdPartyEntities.TreatmentType treatmentType in treatmentTypeCategory.TreatmentTypes)
            {
                string name = String.Format("{0} ({1})", treatmentType.Name, treatmentType.UnitOfMeasurement.Name);
                DropDownListTreatmentType.Items.Add(new ListItem(name, treatmentType.Uid.ToString()));
            }
        }



        /// <summary>
        /// Binds the data.
        /// </summary>
        private void BindPackagesWithSpecificLocation(long locationId)
        {
            Location location = repositoryFactory.GetLocationRepository().GetOne(locationId);

            ICollection<Package> packages =
                repositoryFactory.GetPackageRepository().Find(new PackageInLocationSpecification(location));

            foreach (Package package in packages)
            {
                string name = RepositoryHelper.CreatePackageName(package, GetChainEntityForCurrentUser());
                ListBoxPackages.Items.Add(new ListItem(name, package.Uid.ToString()));
            }
        }

        /// <summary>
        /// Handles the RowCommand event of the GridViewTreatment control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewCommandEventArgs"/> instance containing the event data.</param>
        protected void GridViewTreatment_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToLower().Equals(deletetreatment))
                {
                    long id = GetTreatmentUidFromGridView(e);

                    List<Treatment> treatments = GetTreatments();

                    for (int count = treatments.Count - 1; count >= 0; count--)
                    {
                        if (treatments[count].Uid == id)
                        {
                            treatments.RemoveAt(count);
                            break;
                        }
                    }

                    GridViewTreatment.DataSource = treatments;
                    GridViewTreatment.DataBind();
                }
            }
            catch (Exception e1)
            {
                ErrorHelper.SetErrorLabel(true, e1.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Gets the treatment uid from grid view.
        /// </summary>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewCommandEventArgs"/> instance containing the event data.</param>
        /// <returns></returns>
        private long GetTreatmentUidFromGridView(CommandEventArgs e)
        {
            return
                (long)
                GridViewTreatment.DataKeys[int.Parse((string) e.CommandArgument, CultureInfo.CurrentCulture)].Value;
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonSaveTreatment control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonSaveTreatment_Click(object sender, EventArgs e)
        {
            List<long> treatmentIds = new List<long>();
            StringBuilder productTreatmentInvoiceBuilder = new StringBuilder();
           
            Page.Validate();

            if (Page.IsValid)
            {
                TransactionManager transactionManager = new TransactionManager();
                List<Treatment> treatments = GetTreatments();
                
                List<Package> selectedPackages = null;

                if (treatments.Count > 0)
                {
                    RemoveTempUidsFromTreatments(treatments);

                    selectedPackages = GetSelectedPackages();
                }

                if (selectedPackages != null && treatments.Count > 0)
                {
                    try
                    {
                        try
                        {
                            transactionManager.BeginTransaction();
                        }
                        catch (Exception)
                        {
                            transactionManager.CommitTransaction();
                            transactionManager.BeginTransaction();
                        }
                        
                        User user = RepositoryHelper.GetCurrentUser();

                        IRepository<Package> packageRepository = repositoryFactory.GetPackageRepository();

                        foreach (var atreatment in treatments)
                        {
                            Domain.TreatmentType treatmentType =
                            repositoryFactory.GetTreatmentTypeRepository().GetOne(atreatment.TreatmentType.Uid);

                            var newTreatment = new Treatment(treatmentType, atreatment.Duration, atreatment.Value,
                                atreatment.Cost, atreatment.CostCurrency, atreatment.CostUnit);

                            if (treatments.Count > 0)
                            {
                                RemoveTempUidsFromTreatments(treatments);

                                selectedPackages = GetSelectedPackages();
                            }


                            foreach (Package package in selectedPackages)
                            {
                                package.AddTreatment(newTreatment);
                                packageRepository.Store(package);                                
                            }
                        }

                        packageRepository.Flush();

                        foreach (Package package in selectedPackages)
                        {
                            RepositoryHelper.CreateProcessingSteps(package, package.Treatments, ProcessingStepType.Treatment, user);
                        }                        

                        transactionManager.CommitTransaction();

                        List<long> productUids = new List<long>();

                        //Need to save data for invoices in Matching
                        //First get all the product uids in the selected packages which we are adding treatment
                        foreach (ListItem item in ListBoxPackages.Items)
                        {
                            if (item.Selected)
                            {
                                var pack = repositoryFactory.GetPackageRepository().GetOne(item.Value.ToInt64());

                                //Firstly, we handle for the case that it is packed in the Pack Primary product page.
                                if (pack != null)
                                {
                                    if (pack.PrimaryProducts.Any())
                                    {
                                        //Get all the product uids for the selected packages
                                        foreach (var priProduct in pack.PrimaryProducts)
                                        {
                                            if (priProduct.MatchingProdId != 0)
                                            {
                                                productUids.Add(priProduct.MatchingProdId);
                                            }
                                        }
                                    }
                                    else //For packages that are packed in the waste disposal packages and originated from disposal packages
                                    {
                                        var wasteDisposalDisposalPack =  repositoryFactory.GetWasteDisposalDisposalPackageRepository().AsCollection()
                                            .Where(wd => wd.WasteDisposalPackageId == pack.Uid).FirstOrDefault();
                                        if (wasteDisposalDisposalPack != null)
                                        {
                                            //Get the parent package to know the primary product need to get primary product info
                                            var wasteDisposalTracing = repositoryFactory.GetWasteDisposalPackageTracingRepository().AsCollection()
                                                .Where(wdt => wdt.DisposalPackageId == wasteDisposalDisposalPack.DisposalPackageId).FirstOrDefault();

                                            if (wasteDisposalTracing != null)
                                            {
                                                var parentPackage = repositoryFactory.GetPackageRepository().GetOne(wasteDisposalTracing.ParentUnpackPackageId);
                                                if (parentPackage != null)
                                                {
                                                    if (parentPackage.PrimaryProducts.Any())
                                                    {
                                                        //Get all the product uids for the selected packages
                                                        foreach (var priProd in parentPackage.PrimaryProducts)
                                                        {
                                                            if (priProd.MatchingProdId != 0)
                                                            {
                                                                productUids.Add(priProd.MatchingProdId);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }                        
                        foreach (Package pack in selectedPackages)
                        {              
                            var item = 0;
                            if (pack.Treatments.Any())
                            {
                               item = pack.Treatments.Count - 1;                                    
                            }
                            for (int i = 0; i < GridViewTreatment.Rows.Count;i++) 
                            {
                                if (item > 0)
                                {
                                    treatmentIds.Add(pack.Treatments[item--].Uid);
                                }
                                else
                                {
                                    treatmentIds.Add(pack.Treatments[item].Uid);
                                }
                            }
                        }

                        // Save the product uids and treatment ids in the Matching to get data for invoice
                        foreach (var proId in productUids)
                        {
                            foreach (var treatId in treatmentIds)
                            {
                                //Add the treatment invoice data
                                productTreatmentInvoiceBuilder.Append(proId.ToString() + "," + treatId.ToString() + "|");
                            }
                        }

                        //Call the Matching Api to insert data to matching table 
                        ProductSupplyServices.AddProductTreatmentInvoices(productTreatmentInvoiceBuilder.ToString());

                    }
                    catch (Exception exception)
                    {
                        ErrorHelper.HandleException(exception, transactionManager, LabelError);
                        return;
                    }
                }

                RemoveFomSession();
                Response.Redirect(urlDefault, false);
            }
        }

        /// <summary>
        /// Removes the temp uids from treatments.
        /// </summary>
        /// <param name="treatments">The treatments.</param>
        private static void RemoveTempUidsFromTreatments(IEnumerable<Treatment> treatments)
        {
            foreach (Treatment treatment in treatments)
            {
                treatment.Uid = 0;
            }
        }

        /// <summary>
        /// Gets the selected packages.
        /// </summary>
        /// <returns></returns>
        private List<Package> GetSelectedPackages()
        {
            List<Package> packages = new List<Package>();

            foreach (ListItem item in ListBoxPackages.Items)
            {
                if (item.Selected)
                {
                    Package package = GetSelectedPackage(repositoryFactory, item);

                    if (package != null)
                    {
                        packages.Add(package);
                    }
                }
            }

            return packages;
        }

        /// <summary>
        /// Gets the selected package.
        /// </summary>
        /// <param name="repositoryFactory">The repository factory.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        private static Package GetSelectedPackage(RepositoryFactory repositoryFactory, ListItem item)
        {
            Package selectedPackage;

            selectedPackage = repositoryFactory.GetPackageRepository().GetOne(long.Parse(item.Value));

            return selectedPackage;
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the DropDownListTreatmentType control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void DropDownListTreatmentType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //BindSelectedTreatmentCategory();
            SetUnitOfMeasurementLabel();
        }

        /// <summary>
        /// Sets the unit of measurement label.
        /// </summary>
        private void SetUnitOfMeasurementLabel()
        {
            try
            {
                long id = long.Parse(DropDownListTreatmentType.SelectedValue);

                Domain.ThirdPartyEntities.TreatmentType treatmentType = ProductServices.GetTreatmentTypeById(id);

                LabelUOM.Text = treatmentType.UnitOfMeasurement.Name;
            }
            catch (Exception exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.ToString(), LabelErrorDetail, true);
            }
        }

        /// <summary>
        /// Handles the ServerValidate event of the GridViewTreatmentValidator control.
        /// </summary>
        /// <param name="source">The source of the event.</param>
        /// <param name="args">The <see cref="System.Web.UI.WebControls.ServerValidateEventArgs"/> instance containing the event data.</param>
        protected void GridViewTreatmentValidator_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int count = 0;

            if (ListBoxPackages.Items.Count==0)
            {
                args.IsValid = false;
                GridViewTreatmentValidator.ErrorMessage = Resources.Localization.Nopackagestotreat;
                return;  
            }

            foreach (ListItem listItem in ListBoxPackages.Items)
            {
               if(listItem.Selected)
               {
                   count++;
                   break;
               }
            }

            if(count==0)
            {
                args.IsValid = false;
                GridViewTreatmentValidator.ErrorMessage = Resources.Localization.Nopackagesareselected;
                return;
            }

            if (GridViewTreatment.Rows.Count == 0)
            {
                args.IsValid = false;
                GridViewTreatmentValidator.ErrorMessage = Resources.Localization.Notreatmentstosave;
                return;
            }
            //args.IsValid = (GridViewTreatment.Rows.Count > 0);

        }

        /// <summary>
        /// Handles the Click event of the LinkButtonBack control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonBack_Click(object sender, EventArgs e)
        {
            RemoveFomSession();
            Response.Redirect(urlDefault,false);

        }

        private void BindTreatmentTypeList()
        {
            DropDownListTreatmentType.DataSource = ProductServices.GetTreatmentTypeList();
            DropDownListTreatmentType.DataTextField = "Name";
            DropDownListTreatmentType.DataValueField = "Uid";
            DropDownListTreatmentType.DataBind();

        }

        private void BindSelectedTreatmentCategory()
        {
            long id = long.Parse(DropDownListTreatmentType.SelectedValue);
            DropDownListTreatmentTypeCategory.DataSource = ProductServices.GetTreatmentTypeCategoryList();
            DropDownListTreatmentTypeCategory.DataTextField = dataTextField;
            DropDownListTreatmentTypeCategory.DataValueField = uid;
            DropDownListTreatmentTypeCategory.DataBind();

            Domain.ThirdPartyEntities.TreatmentType treatmentType = ProductServices.GetTreatmentTypeById(id);

            if (treatmentType != null)
            {
                DropDownListTreatmentTypeCategory.SelectedValue = treatmentType.TreatmentTypeCategory.Uid.ToString();
            }

        }
    }
}