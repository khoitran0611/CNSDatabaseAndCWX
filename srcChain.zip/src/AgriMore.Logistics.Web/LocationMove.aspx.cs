using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Web
{
    public partial class LocationMove : Page
    {
        private const string name = "Name";
        private const string uid = "Uid";
        private const string urlDefault = "Default.aspx";

        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        private ChainEntity chainEntityForCurrentUser;
        private ChainEntity GetChainEntityForCurrentUser()
        {
            if (chainEntityForCurrentUser == null)
            {
                chainEntityForCurrentUser = RepositoryHelper.GetChainEntityForCurrentUser();
            }
            return chainEntityForCurrentUser;
        }

        /// <summary>
        /// Gets the date of placement.
        /// </summary>
        /// <value>The date of placement.</value>
        public DateTime DateOfPlacement
        {
            get { return DateOfPlacementControl.GetDatetime(); }
        }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData("0");
            }
        }

        /// <summary>
        /// Fills the packages.
        /// </summary>
        /// <param name="location">The location.</param>
        private void FillPackages(Location location)
        {
            //retrieve packages
            ICollection<Package> packages = repositoryFactory.GetPackageRepository().Find(new PackageInLocationSpecification(location));
            ListBoxPackages.Items.Clear();
            foreach (Package package in packages)
            {
                if (package.PrimaryProducts.Any(it => it.Decomposed)) continue;

                var numPack = ((package.ToUid - package.FromUid) + 1).ToString();
                var listItem = new ListItem(RepositoryHelper.CreatePackageName(package, GetChainEntityForCurrentUser()), package.Uid.ToString());
                listItem.Attributes.Add("data-npackage", numPack);
                ListBoxPackages.Items.Add(listItem);
            }

            //to Location 
            ICollection<Location> toLocations = new List<Location>(GetChainEntityForCurrentUser().Locations);
            toLocations.Remove(location);

            BindLocations(DropDownLostToLocation, toLocations, "0");

            //LinkButtonMoveToLocation.Enabled = packages.Count > 0;
        }

        /// <summary>
        /// Binds to locations.
        /// </summary>
        /// <param name="dropDownList">The drop down list.</param>
        /// <param name="locations">The locations.</param>
        /// <param name="selectedValue"></param>
        private static void BindLocations(ListControl dropDownList, ICollection<Location> locations, string selectedValue)
        {
            dropDownList.DataSource = locations;
            dropDownList.DataValueField = uid;
            dropDownList.DataTextField = name;
            if (selectedValue != "0")
            {
                dropDownList.SelectedValue = selectedValue;
            }
            dropDownList.DataBind();
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the DropDownLostFromLocation control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void DropDownLostFromLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            Location fromLocation = repositoryFactory.GetLocationRepository().GetOne(long.Parse(DropDownLostFromLocation.SelectedValue));
            FillPackages(fromLocation);
        }

        /// <summary>
        /// Handles the Click event of the ButtonSave control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonSave_Click(object sender, EventArgs e)
        {
            Page.Validate();
            if (Page.IsValid)
            {
                TransactionManager transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    IRepository<Location> locationRepository = repositoryFactory.GetLocationRepository();
                    Location fromLocation = locationRepository.GetOne(long.Parse(DropDownLostFromLocation.SelectedValue));
                    Location toLocation = locationRepository.GetOne(long.Parse(DropDownLostToLocation.SelectedValue));

                    IList<long> prodIds = new List<long>();
                    User user = RepositoryHelper.GetCurrentUser();

                    var packages = (from ListItem item in ListBoxPackages.Items
                                    where item.Selected
                                    select repositoryFactory.GetPackageRepository().GetOne(long.Parse(item.Value))).ToList();

                    IRepository<Package> packageRepository = repositoryFactory.GetPackageRepository();
                    foreach (Package package in packages)
                    {
                        IEnumerable<Exposure> exposures = ExposuresControl.GetExposureDocument();
                        fromLocation.Move(package, toLocation, exposures, DateOfPlacement);
                        packageRepository.Store(package);

                        foreach (long id in package.PrimaryProducts.Select(it => it.MatchingProdId).Distinct().Where(id => !prodIds.Contains(id))) prodIds.Add(id);
                    }

                    locationRepository.Store(fromLocation);
                    locationRepository.Store(toLocation);

                    packageRepository.Flush();

                    foreach (Package package in packages)
                    {
                        string remark = CreateVpsRemark(DateOfPlacement, fromLocation, toLocation);
                        RepositoryHelper.CreateProcessingSteps(package, package.CurrentExposureDocument, ProcessingStepType.Move, user, remark);
                    }

                    //Update Location for Product in Matching module
                    IList<ProductSupply> productSupplies = ProductSupplyServices.GetByIds(string.Join(",", Array.ConvertAll(prodIds.ToArray(), Convert.ToString)));
                    foreach (ProductSupply productSupply in productSupplies)
                    {
                        productSupply.LocationId = toLocation.Uid;
                        ProductSupplyServices.CreateOrUpdate(productSupply);
                    }

                    FillPackages(fromLocation);

                    transactionManager.CommitTransaction();
                    Response.Redirect(urlDefault, false);
                }
                catch (ArgumentNullException ane)
                {
                    DomainValidator.IsValid = false;
                    DomainValidator.ErrorMessage = ane.Message;
                }
                catch (ArgumentException ae)
                {
                    DomainValidator.IsValid = false;
                    DomainValidator.ErrorMessage = ae.Message;
                }
                catch (Exception exception)
                {
                    ErrorHelper.HandleException(exception, transactionManager);
                }
            }
        }

        /// <summary>
        /// Creates the VPS remark.
        /// </summary>
        /// <param name="dateOfPlacement">The date of placement.</param>
        /// <param name="from">From.</param>
        /// <param name="to">To.</param>
        /// <returns></returns>
        private static string CreateVpsRemark(DateTime dateOfPlacement, Location from, Location to)
        {
            return String.Format(ProcessingStepDocument.MovedSfp, dateOfPlacement.ToString(ProcessingStepDocument.DateTimeFormat), from.Name, to.Name);
        }


        private void BindData(string selectedvalue)
        {
            ICollection<Location> fromLocations = new List<Location>(GetChainEntityForCurrentUser().Locations);

            BindLocations(DropDownLostFromLocation, fromLocations, selectedvalue);

            //foreach (Location location in fromLocations)
            //{
            //    FillPackages(location);
            //    break;
            //}

            Location fromLocation = repositoryFactory.GetLocationRepository().GetOne(long.Parse(DropDownLostFromLocation.SelectedValue));
            FillPackages(fromLocation);
        }

        protected void LbtSplitClick(object sender, EventArgs args)
        {
            if (string.IsNullOrEmpty(txtIdtSplit.Text)) return;
            var hasSelectedItem = false;
            var selectedItem = new ListItem();

            foreach (var listItem in ListBoxPackages.Items)
            {
                var item = (ListItem)listItem;
                if (item.Selected)
                {
                    hasSelectedItem = true;
                    selectedItem = item;
                    break;
                }
            }

            if (!hasSelectedItem) return;

            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();
            Location fromLocation = repositoryFactory.GetLocationRepository().GetOne(long.Parse(DropDownLostFromLocation.SelectedItem.Value));

            var selPack = repositoryFactory.GetPackageRepository().GetOne(Int64.Parse(selectedItem.Value.Split(':')[0]));
            var splitPart = Array.ConvertAll<string, int>(txtIdtSplit.Text.Split(','), it => int.Parse(it.Trim()));

            RepositoryHelper.SplitPackageGroup(selPack, splitPart, chainEntity, fromLocation);
            hdnSelectedLocation.Value = DropDownLostFromLocation.SelectedValue;
            BindData(hdnSelectedLocation.Value);
            txtIdtSplit.Text = string.Empty;
        }
    }
}