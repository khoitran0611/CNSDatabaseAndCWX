﻿using AgriMore.Logistics.Web.Helpers;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AgriMore.Logistics.Web
{
    public partial class Default : BasePage
    {
        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            var infoMsg = (string)Request[WebConstants.InfoMsg];
            if (string.IsNullOrEmpty(infoMsg))
            {
                lblInfoMsg.Visible = false;
                return;
            }

            var msgType = (InfoMessage)Enum.Parse(typeof(InfoMessage), infoMsg);
            switch (msgType)
            {
                case InfoMessage.InternalMoveSuccessful:
                    {
                        lblInfoMsg.Text = Resources.Localization.SelectPackWereMoveSuccessfully;
                        break;
                    }
                case InfoMessage.PackSuccessful:
                    {
                        var infoDtl = ((string)Request[WebConstants.InfoDtl]).Split(',');
                        lblInfoMsg.Text = string.Format(Resources.Localization.PackedInfoMsg,
                            infoDtl[0], string.Format("[{0}{1} - {0}{2}]", infoDtl[1], infoDtl[2], infoDtl[3]));
                        break;
                    }
            }
        }
    }
}