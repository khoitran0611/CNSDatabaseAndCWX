using System;
using System.Collections.Generic;
using System.Web.UI;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// This class shows a list of shipments.
    /// </summary>
    public partial class ViewUpcomingShipmentsList : Page
    {
        private const string uid = "Uid";
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();


        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IRepository<Shipment> memoryShipmentRepository = repositoryFactory.GetShipmentRepository();
                ChainEntity receiver = ChainEntityHelper.GetChainEntityThroughUser(Page.User);

                BindGridViewPickupShipments(memoryShipmentRepository, receiver);
            }
        }

        /// <summary>
        /// Binds the grid view pickup shipments.
        /// </summary>
        /// <param name="memoryShipmentRepository">The memory shipment repository.</param>
        /// <param name="receiver">The receiver.</param>
        private void BindGridViewPickupShipments(IRepository<Shipment> memoryShipmentRepository, ChainEntity receiver)
        {
            ICollection<Shipment> shipments =
                memoryShipmentRepository.Find(new UpcomingShipmentsForReceiverSpecification(receiver));

            if (shipments.Count > 0)
            {
                GridViewPickupShipments.DataSource = shipments;
                GridViewPickupShipments.DataKeyNames = new string[] {uid};
                GridViewPickupShipments.DataBind();
            }

            LabelNoUpcomingShipments.Visible = shipments.Count==0;
        }
    }
}