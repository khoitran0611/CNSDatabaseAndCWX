using System;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Web
{
    [Flags]
    public enum LocationItems : short
    {
        LocationName = 1,
        Packages = 2,
        DateOfPlacement = 4,
        DateOfDocumentedExposures = 8,
        Exposures = 16
    }

    public partial class LocationUserControl : System.Web.UI.UserControl
    {
        private static IDictionary<string, HtmlTableRow> ee = new Dictionary<string, HtmlTableRow>();
        private const string locationRepositoryName = "LocationRepository";
        private const string packageRepositoryName = "PackageRepository";
        private LocationRepository locationRepository = new LocationRepository();
        private PackageRepository packageRepository = new PackageRepository();
        private bool showPackages = false;
        private bool isEditable = false;
        private ILocation location;

        private LocationItems showItems = LocationItems.LocationName | LocationItems.Packages |
                                          LocationItems.DateOfPlacement | LocationItems.DateOfDocumentedExposures |
                                          LocationItems.Exposures;


        protected void Page_Load(object sender, EventArgs e)
        {

            GetLocationRepository();
            GetPackageRepositoryFromSession();
            SetVisibility();   
        }

        private void SetVisibility()
        {
            Add.Visible = isEditable;

            TextBoxLocationName.Visible = isEditable;
            DivLocationName.Visible = !isEditable;
        }

        public bool ShowPackages
        {
            get { return showPackages; }
            set { showPackages = value; }
        }

        public bool IsEditable
        {
            get { return isEditable; }
            set { isEditable = value; }
        }

        public LocationItems ShowItems
        {
            get { return showItems; }
            set { showItems = value; }
        }

        public void LoadLocation(string locationId)
        {
            if (ee.Count == 0)
            {
                ee.Add(LocationItems.LocationName.ToString(), BlockLocation);
                ee.Add(LocationItems.Packages.ToString(), BlockPackages);
                ee.Add(LocationItems.DateOfPlacement.ToString(), BlockDateOfPlacement);
                ee.Add(LocationItems.DateOfDocumentedExposures.ToString(), BlockDateOfDocumentedExposures);
                ee.Add(LocationItems.Exposures.ToString(), BlockExposures);
            }

            //BlockLocation.Visible = false;
            //BlockPackages.Visible = false;
            //BlockDateOfPlacement.Visible = false;
            //BlockDateOfDocumentedExposures.Visible = false;
            //BlockExposures.Visible = false;

            location = locationRepository.GetLocation(locationId);

            if (location == null)
            {
                Response.Write("geen location gevonden");
                return;
            }

            TextBoxLocationName.Text = location.Description;
            DivLocationName.InnerText = location.Description;

            string[] itemsToShow = ShowItems.ToString().Split(',');
            string[] allItems = Enum.GetNames(typeof (LocationItems));
            
            foreach (string item in allItems)
            {
                bool itemMustBeShown = false;
                foreach (string itemToShow in itemsToShow)
                {
                    if (item.Equals(itemToShow))
                    {
                        if (ee.ContainsKey(itemToShow))
                        {
                            ee[itemToShow].Visible = true;
                            itemMustBeShown = true;
                            break;
                        }
                    }
                }

                if(!itemMustBeShown)
                {
                    if (ee.ContainsKey(item))
                    {
                        ee[item].Visible = false;
                    }
                }

            }

            if(ShowPackages)
            {
                ListBoxPackages.Items.Add(new ListItem("naam 10", "10"));
                ListBoxPackages.Items.Add(new ListItem("naam 20", "20"));
                ListBoxPackages.Items.Add(new ListItem("naam 30", "30"));
            }
                
                

            //if(ShowPackages)
            //{
            //    LocationRepository locc = Repositories.GetLocationRepository();

            //    foreach (Package package in packageRepository.GetPackages())
            //    {
            //        Location packageLocation = locationRepository.GetPackageLocation(package);

            //        if (packageLocation == null)
            //        {
            //            //Todo JE: single key is going to be replaced.
            //            packagesWithNoLocation.Items.Add(new ListItem(package.Identification, package.Identification));
            //        }
            //    }
            //}
        }

        protected void Add_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Gets the package repository from session.
        /// </summary>
        /// <returns></returns>
        private void GetLocationRepository()
        {
            locationRepository = Session[locationRepositoryName] as LocationRepository;

            if (locationRepository == null)
            {
                locationRepository = new LocationRepository();
                Session.Add(locationRepositoryName, locationRepository);
            }

            locationRepository.AddLocation(new Location("10", "Coolblock A", new Address("street","postal","city","country")));
            locationRepository.AddLocation(new Location("20", "Coolblock B+C", new Address("street", "postal", "city", "country")));
            locationRepository.AddLocation(new Location("30", "Refrigerator", new Address("street", "postal", "city", "country")));
        }

        /// <summary>
        /// Gets the package repository from session.
        /// </summary>
        /// <returns></returns>
        private void GetPackageRepositoryFromSession()
        {
            packageRepository = Session[packageRepositoryName] as PackageRepository;

            if (packageRepository == null)
            {
                packageRepository = new PackageRepository();
                Session.Add(packageRepositoryName, packageRepository);
            }
        }
    }
}