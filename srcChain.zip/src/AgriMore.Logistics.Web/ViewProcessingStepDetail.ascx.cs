using System;
using System.Collections.Generic;
using System.Web.UI;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public partial class ViewProcessingStepDetail : UserControl
    {
        private readonly IEnumerable<ProcessingStep> steps;

        /// <summary>
        /// Initializes a new instance of the <see cref="ViewProcessingStepDetail"/> class.
        /// </summary>
        /// <param name="steps">The steps.</param>
        public ViewProcessingStepDetail(IEnumerable<ProcessingStep> steps)
        {
            this.steps = steps;
        }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            GridViewProcessingSteps.DataSource = steps;
            GridViewProcessingSteps.DataBind();
        }
    }
}