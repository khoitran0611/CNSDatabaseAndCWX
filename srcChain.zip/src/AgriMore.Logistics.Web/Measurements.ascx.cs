using System;
using System.Collections.Generic;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Data.Services;

namespace AgriMore.Logistics.Web
{
    public partial class Measurements : UserControl
    {
        private IRepository<ExposureType> exposureTypesRespository;
        private IRepository<ExposureDefine> exposureDefineRespository;
        private readonly IList<ExposureView> exposureViews = new List<ExposureView>();
        private int numberOfExposureTypes = 0;       
        private Package package;
        private readonly RepositoryFactory repositoryFactory=new RepositoryFactory();

        /// <summary>
        /// Gets or sets the name of the date.
        /// </summary>
        /// <value>The name of the date.</value>
        public string HeaderDate
        {
            get { return DateTimeControl1.HeaderDate; }
            set { DateTimeControl1.HeaderDate = value; }
        }

        /// <summary>
        /// Gets or sets the name of the time.
        /// </summary>
        /// <value>The name of the time.</value>
        public string HeaderTime
        {
            get { return DateTimeControl1.HeaderTime; }
            set { DateTimeControl1.HeaderTime = value; }
        }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            exposureTypesRespository = repositoryFactory.GetExposureTypeRepository();
            exposureDefineRespository = repositoryFactory.GetExposureDefineRepository();

            if (!IsPostBack)
            {
                DateTimeControl1.SetStartDateTime(DateTime.Now);

                foreach (ExposureType exposureType in ProductServices.GetExposureTypeList())
                {
                    exposureViews.Add(new ExposureView(null, exposureType, true));
                    numberOfExposureTypes++;
                }

                GridViewExposures.DataSource = exposureViews;
                GridViewExposures.DataBind();                
            }
            else
            {
                Page.Validate();
            }
        }


        /// <summary>
        /// Initializes the specified package.
        /// </summary>
        /// <param name="package">The package.</param>
        public void Initialize(Package package)
        {
            if (package == null)
            {
                throw new ArgumentNullException(Resources.Localization.Package);
            }

            this.package = package;
        }

        /// <summary>
        /// Handles the ServerValidate event of the CustomValidatorAtLeastOneMeasurement control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="args">The <see cref="System.Web.UI.WebControls.ServerValidateEventArgs"/> instance containing the event data.</param>
        protected void CustomValidatorAtLeastOneMeasurement_ServerValidate(object sender, ServerValidateEventArgs args)
        {
            CustomValidator custom = sender as CustomValidator;
            int numberOfValidMeasurements = 0;

            foreach (GridViewRow row in GridViewExposures.Rows)
            {
                HiddenField canCreateExposure = (HiddenField) row.FindControl("HiddenFieldCanCreateExposure");

                if (canCreateExposure.Value == "1")
                {
                    numberOfValidMeasurements++;
                }
            }

            if (numberOfValidMeasurements == 0)
            {
                args.IsValid = false;
                custom.ErrorMessage = Resources.Localization.atleast1exposuremustbefilled;
            }            
        }


        // Custom validator for check box.
        /// <summary>
        /// Handles the ServerValidate event of the CustomValidator control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="args">The <see cref="System.Web.UI.WebControls.ServerValidateEventArgs"/> instance containing the event data.</param>
        protected void CustomValidator_ServerValidate(object sender, ServerValidateEventArgs args)
        {
            CustomValidator custom = sender as CustomValidator;
            GridViewRow gridViewRow = custom.NamingContainer as GridViewRow;

            TextBox documentedValue = (TextBox) gridViewRow.FindControl("TextBoxDocumentedValue");
            HiddenField canCreateExposure = (HiddenField) gridViewRow.FindControl("HiddenFieldCanCreateExposure");

            if (string.IsNullOrEmpty(documentedValue.Text))
            {
                args.IsValid = true;
            }
            else
            {
                double doc;

                if (double.TryParse(documentedValue.Text, out doc))
                {
                    args.IsValid = true;
                    canCreateExposure.Value = "1";
                }
                else
                {
                    args.IsValid = false;
                    custom.ErrorMessage = Resources.Localization.Allfieldsmustbefilledwithnumericvalues;
                }
            }
        }

        /// <summary>
        /// Gets the measurements.
        /// </summary>
        /// <returns></returns>
        public IDictionary<ExposureType, MeasuredValue> GetMeasurements()
        {
            IDictionary<ExposureType, MeasuredValue> measurements = new Dictionary<ExposureType, MeasuredValue>();

            if (Page.IsValid)
            {
                CultureInfo MyCultureInfo = new CultureInfo("en-GB");

                foreach (GridViewRow row in GridViewExposures.Rows)
                {
                    TextBox documentedValue = (TextBox) row.FindControl("TextBoxDocumentedValue");
                    HiddenField canCreateExposure = (HiddenField) row.FindControl("HiddenFieldCanCreateExposure");
                    HiddenField exposureTypeId = (HiddenField) row.FindControl("HiddenFieldExposured");

                    ExposureType exposureType =
                        ProductServices.GetExposureTypeById(int.Parse(exposureTypeId.Value));

                    if (canCreateExposure.Value == "1")
                    {
                        DateTime datetimePrescibed = DateTimeControl1.GetDatetime();
                        MeasuredValue measuredValue =
                            new MeasuredValue(double.Parse(documentedValue.Text, MyCultureInfo), datetimePrescibed);

                        measurements.Add(exposureType, measuredValue);
                    }
                }
            }

            return measurements;
        }                       
    }
}