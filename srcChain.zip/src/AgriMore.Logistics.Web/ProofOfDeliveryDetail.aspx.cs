using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using System.Linq;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// </summary>
    public partial class ProofOfDeliveryDetail : System.Web.UI.Page
    {
        private const string shipmentid = "shipmentid";
        private IList<Shipment> shipments = new List<Shipment>();
        private const string urlProofOfDeliveryList = "ProofOfDeliveryList.aspx";
        private IRepository<Location> locationRepository;
        private const string urlDefault = "Default.aspx";
        private const string name = "Name";
        private const string uid = "Uid";
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SetInitialValues();
            }
            else
            {
                Validate();
            }
        }


        /// <summary>
        /// Binds the receiver locations.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        private void BindReceiverLocations(Shipment shipment)
        {
            DropDownListReceiverLocation.DataSource = GetReceiverLocations(shipment);
            DropDownListReceiverLocation.DataValueField = uid;
            DropDownListReceiverLocation.DataTextField = name;
            DropDownListReceiverLocation.SelectedValue = shipment.DeliveryLocation.Uid.ToString();
            DropDownListReceiverLocation.DataBind();
        }


        /// <summary>
        /// Gets the shipper locations.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        /// <returns></returns>
        private static IList<Location> GetReceiverLocations(Shipment shipment)
        {
            IList<Location> receiverLocations = new List<Location>();

            foreach (Address address in shipment.Receiver.Addresses)
            {
                foreach (Location location in address.Locations)
                {
                    if (location == shipment.DeliveryLocation)
                    {
                        foreach (Location receiverLocation in address.Locations)
                        {
                            receiverLocations.Add(receiverLocation);
                        }
                    }
                }
            }
            return receiverLocations;
        }

        /// <summary>
        /// Gets the shipper address.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        private static Address GetShipperAddress(Shipment shipment)
        {
            foreach (Address address in shipment.Shipper.Addresses)
            {
                foreach (Location location in address.Locations)
                {
                    if (location == shipment.PickupLocation)
                    {
                        return address;
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the receiver address.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        /// <returns></returns>
        private static Address GetReceiverAddress(Shipment shipment)
        {
            foreach (Address address in shipment.Receiver.Addresses)
            {
                foreach (Location location in address.Locations)
                {
                    if (location == shipment.DeliveryLocation)
                    {
                        return address;
                    }
                }
            }

            throw new ArgumentException(Resources.Localization.Noreceiveraddressfound);
        }

        /// <summary>
        /// Sets the initial values.
        /// </summary>
        private void SetInitialValues()
        {
            LabelError.Visible = false;

            Shipment shipment = GetShipment();

            if (shipment != null)
            {
                shipments.Add(shipment);
                GetShipperAddress(shipment);
                BindReceiverLocations(shipment);
                shipments = shipments.OrderByDescending(s => s.Uid).ToList();
                ToDeliverShipmentDetails.DataSource = shipments;
                ToDeliverShipmentDetails.DataBind();
            }
        }

        /// <summary>
        /// Gets the shipment.
        /// </summary>
        /// <returns></returns>
        public Shipment GetShipment()
        {
            string id = Session[shipmentid] as string;

            Shipment shipment;

            if (!String.IsNullOrEmpty(id))
            {
                shipment = repositoryFactory.GetShipmentRepository().GetOne(long.Parse(id));
            }
            else
            {
                throw new ArgumentException(Resources.Localization.Thereisnoshipmentidinthesession);
            }

            return shipment;
        }

        /// <summary>
        /// Handles the Click event of the ButtonSave control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void ButtonSave_Click(object sender, EventArgs e)
        {
            TransactionManager transactionManager = new TransactionManager();

            try
            {
                transactionManager.BeginTransaction();

                Shipment shipment = GetShipment();

                TransportEquipment transportEquipment =
                    repositoryFactory.GetTransportEquipmentRepository().GetOne(
                        new TransportEquipmentByShipment(shipment));

                if (transportEquipment != null)
                {
                    DateTime DeliveryDateTime = DTCDeliveryDateTime.GetDatetime();
                    Location realDeliveryLocation = GetSelectedDeliveryLocation();
                    string Remarks = txtRemarks.Text;


                    transportEquipment.Deliver(shipment, DeliveryDateTime, Remarks, realDeliveryLocation);

                    repositoryFactory.GetTransportEquipmentRepository().Store(transportEquipment);
                }

                transactionManager.CommitTransaction();
            }
            catch (Exception exception)
            {
                ErrorHelper.HandleException(exception, transactionManager, LabelError);
                return;
            }

            Response.Redirect(urlProofOfDeliveryList, false);
        }

        /// <summary>
        /// Gets the selected delivery location.
        /// </summary>
        /// <returns></returns>
        private Location GetSelectedDeliveryLocation()
        {
            locationRepository = repositoryFactory.GetLocationRepository();
            return locationRepository.GetOne(long.Parse(DropDownListReceiverLocation.SelectedValue));
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(urlDefault, false);
        }

        /// <summary>
        /// Retrieves the shipper address.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        /// <returns></returns>
        protected static Address RetrieveShipperAddress(object shipment)
        {
            Shipment sm = (Shipment) shipment;
            return GetShipperAddress(sm);
        }

        /// <summary>
        /// Retrieves the receiver address.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        /// <returns></returns>
        protected static Address RetrieveReceiverAddress(object shipment)
        {
            Shipment sm = (Shipment) shipment;
            return GetReceiverAddress(sm);
        }
    }
}