using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PackSemiFinishedProductInLocationList : BasePage
    {
        private const string action = "action";
        private const string locationid = "locationid";
        private string messageNoValidAction = Resources.Localization.Novalidactionfromthemenu;
        private string packSFP = Resources.Localization.PackSFP;
        private string putInLocationAfterDelivery = Resources.Localization.Putinlocationafterdelivery;
        private string repackSFP = Resources.Localization.PackSFPfrombulk;
        private const string selectlocation = "selectlocation";
        private string treatSFP = Resources.Localization.TreatSFP;
        private const string uid = "Uid";
        private string unpackSFP = Resources.Localization.UnpackSFP;
        private const string urlPackageDetail = "Default.aspx";
        private const string urlPackSemiFinishedProduct = "PackSemiFinishedProductDetail.aspx?param=repacksfp";
        private const string urlPackSFP = "PackSemiFinishedProductDetail.aspx?param=packsfp";
        private const string urlPutInLocationAfterDelivery = "PutInLocationAfterDelivery.aspx";
        private const string urlTreatSemiFinishedProduct = "TreatSemiFinishedProduct.aspx";
        private const string urlUnpackSFP = "UnpackSemiFinishedProductDetail.aspx?param=unpackpacksfp";

        private string checkoutSFP = Resources.Localization.CheckoutSFPFromShelf;
        private const string urlCheckoutSfpFromShelf = "CheckoutSfpFromShelf.aspx?param=checkoutsfp";

        protected override void OnPreInit(EventArgs e)
        {
            messageNoValidAction = Resources.Localization.Novalidactionfromthemenu;
            packSFP = Resources.Localization.PackSFP;
            putInLocationAfterDelivery = Resources.Localization.Putinlocationafterdelivery;
            repackSFP = Resources.Localization.PackSFPfrombulk;
            treatSFP = Resources.Localization.TreatSFP;
            unpackSFP = Resources.Localization.UnpackSFP;

            base.OnPreInit(e);
        }
        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            ErrorHelper.SetErrorLabel(false, string.Empty, LabelError, false);

            try
            {
                ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser(); //ChainEntityHelper.GetChainEntityThroughUser(User);

                if (chainEntity != null && chainEntity.Locations != null)
                {
                    BindGridViewLocationsChainEntity(chainEntity);
                }
            }
            catch (Exception exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Binds the grid view locations chain entity.
        /// </summary>
        /// <param name="chainEntity">The chain entity.</param>
        private void BindGridViewLocationsChainEntity(ChainEntity chainEntity)
        {
            List<Location> locations = new List<Location>(chainEntity.Locations);
            locations.Sort(delegate(Location l1, Location l2) { return l1.Name.CompareTo(l2.Name); });
            GridViewLocationsChainEntity.DataSource = locations;// chainEntity.Locations;
            GridViewLocationsChainEntity.DataKeyNames = new string[] {uid};
            GridViewLocationsChainEntity.DataBind();
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonAddNew control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonAddNew_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect(urlPackageDetail, false);
            }
            catch (Exception exception)
            {
                ErrorHelper.SetErrorLabel(true, exception.ToString(), LabelError, true);
            }
        }

        /// <summary>
        /// Handles the RowCommand event of the GridViewLocationsChainEntity control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewCommandEventArgs"/> instance containing the event data.</param>
        protected void GridViewLocationsChainEntity_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToLower().Equals(selectlocation))
                {
                    string userAction = (string) Session[action];

                    if (userAction != null)
                    {
                        int index = Convert.ToInt32(e.CommandArgument);
                        long locationId = Convert.ToInt64(GridViewLocationsChainEntity.DataKeys[index].Value);

                        Session.Add(locationid, locationId.ToString());

                        if (userAction == packSFP)
                        {
                            Response.Redirect(urlPackSFP, false);
                        }
                        else if (userAction == unpackSFP)
                        {
                            Response.Redirect(urlUnpackSFP, false);
                        }
                        else if (userAction == repackSFP)
                        {
                            Response.Redirect(urlPackSemiFinishedProduct, false);
                        }
                        else if (userAction == treatSFP)
                        {
                            Response.Redirect(urlTreatSemiFinishedProduct, false);
                        }
                        else if (userAction == putInLocationAfterDelivery)
                        {
                            Response.Redirect(urlPutInLocationAfterDelivery, false);
                        }
                        else if (userAction == checkoutSFP)
                        {
                            Response.Redirect(urlCheckoutSfpFromShelf, false);
                        }
                        else
                        {
                            throw new ArgumentException(messageNoValidAction);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                ErrorHelper.SetErrorLabel(false, exception.ToString(), LabelError, true);
            }
        }
    }
}