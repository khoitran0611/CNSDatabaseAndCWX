using AgriMore.Logistics.Domain;
using System.Globalization;
using System.Threading;
using System.Web;
using System.Web.UI;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// </summary>
    public partial class Login : Page
    {
        public static string CurUserName
        {
            get { return HttpContext.Current.User.Identity.Name; }
        }

        public static string CurLangCode
        {
            get
            {
                string langCulture;
                User curUser = RepositoryHelper.GetCurrentUser();
                langCulture = (curUser != null && !string.IsNullOrEmpty(curUser.UsingLang)) ? curUser.UsingLang : "en-GB";

                return langCulture;
            }
        }

        protected override void InitializeCulture()
        {
            Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = new CultureInfo(CurLangCode);
        }

        protected override void OnPreInit(System.EventArgs e)
        {
            base.OnPreInit(e);
            this.InitializeCulture();
        }

    }
}