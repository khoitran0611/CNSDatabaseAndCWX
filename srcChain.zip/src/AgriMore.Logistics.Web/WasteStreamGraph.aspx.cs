﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain.ThirdPartyEntities;

namespace AgriMore.Logistics.Web
{
    public partial class WasteStreamGraph : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;

            var chainId = RepositoryHelper.GetChainEntityForCurrentUser().Uid;
            BindingRootProdAndSourceOrg(chainId);
            //BindingRootProd(chainId);
            //BindingSourceOrganization(chainId);

            var previousMonday = GetMondayPreviousWeek();
            fromCalendar.SetDateValue(previousMonday);
            toCalendar.SetDateValue(previousMonday.AddDays(6));
        }

        protected void LbtViewGraphClick(object sender, EventArgs e)
        {
            var selProdId = Convert.ToInt64(ddlWasteStr4Prod.SelectedValue);
            var chainId = RepositoryHelper.GetChainEntityForCurrentUser().Uid;

            var fromDate = Convert.ToDateTime(txtFromDate.Text);
            var toDate = Convert.ToDateTime(txtToDate.Text);

            var selOrgIds = ddlWasteStr4Org.SelectedValue;
            if (string.IsNullOrEmpty(selOrgIds))
                selOrgIds = string.Join(",", ddlWasteStr4Org.Items.Cast<ListItem>().Where(it => !string.IsNullOrEmpty(it.Value)).Select(it => it.Value).ToArray());

            var chartItems = DecompositionInfoServices.BuildWasteStreamGraphInfo(chainId, selProdId, fromDate, toDate, selOrgIds.Split(','));
            var chartItem = LoadControl("ChartItem.ascx") as ChartItem;
            chartItem.EndDate = toDate;
            chartItem.StartDate = fromDate;
            chartItem.ChartData = chartItems;
            chartItem.OrgListItems = ddlWasteStr4Org.Items.Cast<ListItem>().ToList();
            chartItem.ChartTitle = string.Format("{0} decomposition", ddlWasteStr4Prod.SelectedItem.Text);
            phdCharts.Controls.Add(chartItem);
        }

        #region Private Methods
        private void BindingRootProdAndSourceOrg(long chainId)
        {
            ddlWasteStr4Org.Items.Clear();
            ddlWasteStr4Prod.Items.Clear();

            IList<OrganizationInfo> listSourceOrgs = OrganizationServices.GetVisibleOrganizationInfos(chainId);
            if (listSourceOrgs == null || listSourceOrgs.Count <= 0) return;

            //From product //ProductServices.GetRootProducts(listSourceOrgs.Select(it => it.Uid).ToArray());
            IList<Product> lstProducts = ProductServices.GetFromProducts(listSourceOrgs.Select(it => it.Uid).ToArray());
            if (lstProducts != null && lstProducts.Count > 0)
                ddlWasteStr4Prod.Items.AddRange(lstProducts.Select(it => new ListItem(it.GetName(CurLangCode), it.Uid.ToString())).ToArray());

            //Source organization
            ddlWasteStr4Org.Items.AddRange(listSourceOrgs.Select(it => new ListItem(it.Name, it.Uid)).OrderBy(it => it.Text).ToArray());
            ddlWasteStr4Org.Items.Insert(0, new ListItem(Resources.Localization.All, ""));
        }

        private void BindingRootProd(long chainId)
        {
            ddlWasteStr4Prod.Items.Clear();
            IList<Product> lsProducts = ProductServices.GetRootProducts(chainId);
            if (lsProducts == null || lsProducts.Count <= 0) return;
            ddlWasteStr4Prod.Items.AddRange(lsProducts.Select(it => new ListItem(it.GetName(CurLangCode), it.Uid.ToString())).ToArray());
        }

        private void BindingSourceOrganization(long chainId)
        {
            ddlWasteStr4Org.Items.Clear();
            IList<OrganizationInfo> lstOrgInfo = OrganizationServices.GetDecomposedOrganizationInfos(chainId);
            if (lstOrgInfo != null && lstOrgInfo.Count > 0)
                ddlWasteStr4Org.Items.AddRange(lstOrgInfo.Select(it => new ListItem(it.Name, it.Uid)).OrderBy(it => it.Text).ToArray());
            ddlWasteStr4Org.Items.Insert(0, new ListItem(Resources.Localization.All, ""));
        }

        private DateTime GetMondayPreviousWeek()
        {
            int curWeek = CultureInfo.CurrentCulture.Calendar.GetWeekOfYear(DateTime.Now, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
            return FirstDateOfWeek(curWeek - 1, DateTime.Now.Year);
        }

        private DateTime FirstDateOfWeek(int weekNum, int year)
        {
            var jan1 = new DateTime(year, 1, 1);
            int daysOffset = DayOfWeek.Monday - jan1.DayOfWeek;
            DateTime firstMonday = jan1.AddDays(daysOffset);
            var cal = CultureInfo.CurrentCulture.Calendar;
            int firstWeek = cal.GetWeekOfYear(jan1, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

            if (firstWeek <= 1) weekNum -= 1;
            DateTime result = firstMonday.AddDays(weekNum * 7);

            return result;
        }
        #endregion
    }
}