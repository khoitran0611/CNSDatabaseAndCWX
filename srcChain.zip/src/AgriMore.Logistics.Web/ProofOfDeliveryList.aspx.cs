using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using System.Linq;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// This class shows a list of shipments not yet pickedup.
    /// </summary>
    public partial class ProofOfDeliveryList : BasePage
    {
        private const string urlProofOfDeliveryDetail = "ProofOfDeliveryDetail.aspx";
        private readonly RepositoryFactory repositoryFactory=new RepositoryFactory();

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IRepository<Shipment> memoryShipmentRepository = repositoryFactory.GetShipmentRepository();
                ChainEntity forwarder = ChainEntityHelper.GetChainEntityThroughUser(Page.User);

                ShipmentsForForwarderSpecification spec = new ShipmentsForForwarderSpecification(forwarder, true, false);
                GridViewPickupShipments.DataSource = memoryShipmentRepository.Find(spec).OrderByDescending(s => s.Uid).ToList();
                GridViewPickupShipments.DataBind();
            }
        }


        /// <summary>
        /// Handles the RowEditing1 event of the GridViewShipments control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewEditEventArgs"/> instance containing the event data.</param>
        protected void GridViewPickupShipments_RowEditing1(object sender, GridViewEditEventArgs e)
        {
            try
            {
                IRepository<Shipment> memoryShipmentRepository = repositoryFactory.GetShipmentRepository();

                string id = GridViewPickupShipments.DataKeys[e.NewEditIndex].Value.ToString();
                Session.Add("shipmentid", id);

                Shipment shipment = null;

                if (memoryShipmentRepository != null && !String.IsNullOrEmpty(id))
                {
                    shipment = memoryShipmentRepository.GetOne(long.Parse(id));
                }

                if (shipment != null)
                {
                    Response.Redirect(urlProofOfDeliveryDetail, false);
                }
            }
            catch (Exception)
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.Text = ResourceAgriMore.GeneralErrorMessage;
            }
        }

        protected void GridViewPickupShipments_PageIndexChanged(object sender, GridViewPageEventArgs e)
        {
            IRepository<Shipment> memoryShipmentRepository = repositoryFactory.GetShipmentRepository();
            ChainEntity forwarder = ChainEntityHelper.GetChainEntityThroughUser(Page.User);

            ShipmentsForForwarderSpecification spec = new ShipmentsForForwarderSpecification(forwarder, true, false);
            GridViewPickupShipments.DataSource = memoryShipmentRepository.Find(spec).OrderByDescending(s => s.Uid).ToList();

            GridViewPickupShipments.PageIndex = e.NewPageIndex;
            GridViewPickupShipments.DataBind();            
        }

        protected void GridViewPickupShipments_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Shipment shipment = e.Row.DataItem as Shipment;
                if (shipment == null) return;

                HyperLink hplViewDetail = (e.Row.FindControl("hplViewDetail") as HyperLink);
                hplViewDetail.Text = shipment.LoadingAdviceDocName;

                hplViewDetail.NavigateUrl = string.Format("~/Downloadfile.ashx?type=loadingAdviceDoc&uid={0}&index={1}", shipment.Uid, e.Row.RowIndex);
            }
        }
    }
}