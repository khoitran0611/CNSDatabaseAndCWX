using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Repository.Memory;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// PickupLocation list is the main user intaeface page that handles all locations 
    /// relevant scenarios
    /// </summary>
    public partial class LocationList : Page
    {
        private const string locationRepository = "MemoryLocationRepository";
        private const string urlLocationDetail = "LocationDetail.aspx";
        private IRepository<Location> repository = new MemoryMapRepository<Location>();

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetLocationRepositoryFromSession();

                RepositoryFactory rm = new RepositoryFactory();
                ChainEntity ce = rm.GetChainEntityRepository().GetOne("Aardappel Grower");

                IList<Location> filteredLocs = new List<Location>();

                foreach (Location location in rm.GetLocationRepository())
                {
                    if (ce.Contains(location))
                    {
                        filteredLocs.Add(location);
                        repository.Add(location);
                    }
                }

                List<Location> ll = new List<Location>(filteredLocs);

                GridView1.DataSource = ll;
                GridView1.DataBind();
            }
        }

        /// <summary>
        /// Gets the package repository from session.
        /// </summary>
        /// <returns></returns>
        private void GetLocationRepositoryFromSession()
        {
            repository = Session[locationRepository] as IRepository<Location>;

            if (repository == null)
            {
                repository = new MemoryMapRepository<Location>();
                Session.Add(locationRepository, repository);
            }
        }

        /// <summary>
        /// Handles the ObjectCreating event of the ObjectDataSource1 control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.ObjectDataSourceEventArgs"/> instance containing the event data.</param>
        protected void ObjectDataSource1_ObjectCreating(object sender, ObjectDataSourceEventArgs e)
        {
            e.ObjectInstance = repository;
        }

        /// <summary>
        /// Handles the Click event of the LinkButton1 control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect(urlLocationDetail);
        }
    }
}