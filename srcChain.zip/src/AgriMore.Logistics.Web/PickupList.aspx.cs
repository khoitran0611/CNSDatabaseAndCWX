using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using System.Collections.Generic;
using System.Linq;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// This class shows a list of shipments not yet pickedup.
    /// </summary>
    public partial class PickupList : BasePage
    {
        private string invalidPickup = Resources.Localization.Cannotpickupshipmentnotallpackageshavearrivedatthepickuplocation;

        private const string urlPickupDetail = "PickupDetail.aspx";
        readonly RepositoryFactory repositoryFactory=new RepositoryFactory();

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            ErrorHelper.SetErrorLabel(false, string.Empty, LabelErrorMessage, false);

            try
            {
                if (!IsPostBack)
                {
                    IRepository<Shipment> shipmentRepository = repositoryFactory.GetShipmentRepository();
                    ChainEntity ceForwarder = ChainEntityHelper.GetChainEntityThroughUser(Page.User);

                    BindGridViewShipments(ceForwarder, shipmentRepository);
                }
            }
            catch (Exception e1)
            {
                ErrorHelper.SetErrorLabel(true, e1.ToString(), LabelErrorMessage, true);
            }
        }

        /// <summary>
        /// Binds the grid view shipments.
        /// </summary>
        /// <param name="forwarder">The ce forwarder.</param>
        /// <param name="shipmentRepository">The shipment repository.</param>
        private void BindGridViewShipments(ChainEntity forwarder, IRepository<Shipment> shipmentRepository)
        {
            List<Shipment> shipments = null;
            ShipmentsForForwarderSpecification spec = new ShipmentsForForwarderSpecification(forwarder, false, false);            
            shipments = shipmentRepository.Find(spec).OrderByDescending(s => s.Uid).ToList();
            GridViewShipments.DataSource = shipments;
            GridViewShipments.DataBind();
        }


        /// <summary>
        /// Handles the RowEditing1 event of the GridViewShipments control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewEditEventArgs"/> instance containing the event data.</param>
        protected void GridViewShipments_RowEditing1(object sender, GridViewEditEventArgs e)
        {
            try
            {
                IRepository<Shipment> memoryShipmentRepository = new RepositoryFactory().GetShipmentRepository();

                string id = GridViewShipments.DataKeys[e.NewEditIndex].Value.ToString();
                Session.Add("shipmentid", id);
                Shipment shipment = null;

                if (memoryShipmentRepository != null && !String.IsNullOrEmpty(id))
                {
                    shipment = memoryShipmentRepository.GetOne(long.Parse(id));
                }

                if (shipment != null)
                {
                    if (shipment.ArePackagesInPickupLocation())
                    {
                        Response.Redirect(urlPickupDetail, false);
                    }
                    else
                    {
                        ErrorHelper.SetErrorLabel(true, invalidPickup, LabelErrorMessage, false);
                    }
                }
            }
            catch (Exception)
            {
                ErrorHelper.SetErrorLabel(true, string.Empty, LabelErrorMessage, true);
            }
        }

        protected void GridViewPickupShipments_PageIndexChanged(object sender, GridViewPageEventArgs e)
        {
            IRepository<Shipment> shipmentRepository = repositoryFactory.GetShipmentRepository();
            ChainEntity ceForwarder = ChainEntityHelper.GetChainEntityThroughUser(Page.User);

            GridViewShipments.PageIndex = e.NewPageIndex;
            BindGridViewShipments(ceForwarder, shipmentRepository);

        }

        protected void GridViewShipments_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Shipment shipment = e.Row.DataItem as Shipment;
                if (shipment == null) return;

                HyperLink hplViewDetail = (e.Row.FindControl("hplViewDetail") as HyperLink);
                hplViewDetail.Text = shipment.LoadingAdviceDocName;

                hplViewDetail.NavigateUrl = string.Format("~/Downloadfile.ashx?type=loadingAdviceDoc&uid={0}&index={1}", shipment.Uid, e.Row.RowIndex);
            }
        }

    }
}