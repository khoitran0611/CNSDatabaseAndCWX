using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PutInLocationAfterDelivery : BasePage
    {
        private const string locationid = "locationid";
        private const string packagesInShipmentNotInLocation = "packagesInShipmentNotYetInLocation";
        private const string selectshipment = "selectshipment";
        private const string shipmentid = "shipmentid";
        private const string uid = "Uid";
        private const string urlPackageDetail = "Default.aspx";
        private readonly string urlPickupList = "PackSemiFinishedProductInLocationList.aspx?param=4";
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        private readonly string vpsRemarkFormat = Resources.Localization.vpsRemarkFormat;

        private readonly string vpsRemark = "vpsRemark";

        /// <summary>
        /// Get the shipments for where this chainentity is receiver.
        /// The shipments must already been delivered.
        /// The shipment must be delivered at the selected location.
        /// The packages in the shipment cannot be in a location.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ChainEntity receiver = GetCurrentChainEntity();

                Location location = GetSelectedLocation();

                BindGridViewPickupShipments(receiver, location);
            }
            else
            {
                Page.Validate();
            }
        }

        /// <summary>
        /// Binds the grid view pickup shipments.
        /// </summary>
        /// <param name="receiver">The receiver.</param>
        /// <param name="location">The location.</param>
        private void BindGridViewPickupShipments(ChainEntity receiver, Location location)
        {
            GridViewPickupShipments.DataSource = GetShipmentsForGridView(receiver, location);
            GridViewPickupShipments.DataKeyNames = new string[] { uid };
            GridViewPickupShipments.DataBind();
        }

        /// <summary>
        /// Gets the shipments for gid view.
        /// </summary>
        /// <param name="receiver">The receiver.</param>
        /// <param name="location">The location.</param>
        /// <returns></returns>
        private ICollection<Shipment> GetShipmentsForGridView(ChainEntity receiver, Location location)
        {
            DeliveredShipmentForChainEntityNotInLocatoinSpecification spec =
                new DeliveredShipmentForChainEntityNotInLocatoinSpecification(receiver, location);
            List<Shipment> shipments = null;
            shipments =  repositoryFactory.ConcreteRepositoryFactory.GetShipmentRepository().Find(spec).OrderByDescending(s => s.Uid).ToList();
            return shipments;
        }

        /// <summary>
        /// Gets the current chain entity.
        /// </summary>
        /// <returns></returns>
        private ChainEntity GetCurrentChainEntity()
        {
            return ChainEntityHelper.GetChainEntityThroughUser(User);
        }

        /// <summary>
        /// Gets the selected location.
        /// </summary>
        /// <returns></returns>
        private Location GetSelectedLocation()
        {
            return repositoryFactory.ConcreteRepositoryFactory.GetLocationRepository().
                GetOne(GetLocationId());
        }

        /// <summary>
        /// Gets the location id from session.
        /// </summary>
        /// <returns></returns>
        private long GetLocationId()
        {
            string locId = Session[locationid] as string;
            return long.Parse(locId);
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonAddNew control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonAddNew_Click(object sender, EventArgs e)
        {
            Response.Redirect(urlPackageDetail, false);
        }

        /// <summary>
        /// Handles the RowCommand event of the GridViewPickupShipments control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewCommandEventArgs"/> instance containing the event data.</param>
        protected void GridViewPickupShipments_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName.ToLower().Equals(selectshipment))
            {
                int index = Convert.ToInt32(e.CommandArgument);
                long shipmentId = Convert.ToInt64(GridViewPickupShipments.DataKeys[index].Value);

                if (shipmentId > 0)
                {
                    Session.Add(shipmentid, shipmentId);

                    Shipment shipment =
                        repositoryFactory.ConcreteRepositoryFactory.GetShipmentRepository().GetOne(shipmentId);

                    ChainEntity chainEntity = ChainEntityHelper.GetChainEntityThroughUser(User);
                    List<Package> packagesInShipmentNotYetInLocation = new List<Package>(shipment.Packages);
                    Session[vpsRemark] =
                        String.Format(vpsRemarkFormat, DateTime.Now.ToString(ProcessingStepDocument.DateTimeFormat),
                                      shipment.Shipper.Name, shipment.Forwarder.Name);

                    foreach (Package package in shipment.Packages)
                    {
                        foreach (Location location in chainEntity.Locations)
                        {
                            if (location.Contains(package) || package.ParentPackage != null)
                            {
                                packagesInShipmentNotYetInLocation.Remove(package);
                            }
                        }
                    }

                    // Move packages to temp list.
                    Session.Add(packagesInShipmentNotInLocation, packagesInShipmentNotYetInLocation);

                    BindPackageList();
                    MultiViewPackageList.SetActiveView(ViewDetail);
                }
            }
        }

        /// <summary>
        /// Binds the data.
        /// </summary>
        private void BindPackageList()
        {
            ICollection<Package> packages = Session[packagesInShipmentNotInLocation] as ICollection<Package>;

            if (packages != null)
            {
                ShowPackagesControl.SetPackages(packages);
            }
        }


        /// <summary>
        /// Handles the Click event of the ButtonSave control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void ButtonSave_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                TransactionManager transactionManager = new TransactionManager();
                try
                {
                    transactionManager.BeginTransaction();

                    List<Package> packages = new List<Package>();

                    IRepository<Package> packageRepository = repositoryFactory.GetPackageRepository();
                    User user = RepositoryHelper.GetCurrentUser();

                    foreach (Package packageFromPackagesControl in ShowPackagesControl.SelectedPackages)
                    {
                        Package package = packageRepository.GetOne(packageFromPackagesControl.Uid);
                        if (package != null)
                        {
                            packages.Add(package);

                            ICollection<Package> packagesInSession =
                                Session[packagesInShipmentNotInLocation] as ICollection<Package>;

                            if (packagesInSession != null)
                            {
                                packagesInSession.Remove(packageFromPackagesControl);
                            }
                        }
                    }

                    foreach (Package package in packages)
                    {
                        Identification id = ShowPackagesControl.GetIdentification(package);

                        if (id != null)
                        {
                            ShowPackagesControl.AddIdentificationToPackage(package);
                        }

                        PutInLocation1.AddPackageToLocation(package, user);
                    }

                    packageRepository.Flush();
                    IList<long> prodIds = new List<long>();
                    foreach (Package package in packages)
                    {
                        PutInLocation1.CreateProcessingSteps(package, user, Session[vpsRemark].ToString());

                        foreach (long id in package.PrimaryProducts.Select(it => it.MatchingProdId).Distinct().Where(id => !prodIds.Contains(id))) prodIds.Add(id);
                    }

                    //Update Location and Buy Status for Product in Matching module
                    var locationId = long.Parse(((DropDownList)PutInLocation1.FindControl("DropDownListLocations")).SelectedValue);
                    IList<ProductSupply> productSupplies = ProductSupplyServices.GetByIds(string.Join(",", Array.ConvertAll(prodIds.ToArray(), Convert.ToString)));
                    foreach (ProductSupply productSupply in productSupplies)
                    {
                        productSupply.LocationId = locationId;
                        productSupply.BuyStatus = BuyerStatus.ActualAmountBoughtAndReceived;
                        ProductSupplyServices.CreateOrUpdate(productSupply);
                    }

                    transactionManager.CommitTransaction();
                    Response.Redirect(urlPickupList, false);
                }
                catch (Exception)
                {
                    transactionManager.RollbackTransaction();
                }
            }
        }

        protected void GridViewPickupShipments_PageIndexChanged(object sender, GridViewPageEventArgs e)
        {
            ChainEntity receiver = GetCurrentChainEntity();

            Location location = GetSelectedLocation();

            GridViewPickupShipments.PageIndex = e.NewPageIndex;
            BindGridViewPickupShipments(receiver, location);

        }

        protected void GridViewPickupShipments_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Shipment shipment = e.Row.DataItem as Shipment;
                if (shipment == null) return;

                HyperLink hplViewDetail = (e.Row.FindControl("hplViewDetail") as HyperLink);
                hplViewDetail.Text = shipment.LoadingAdviceDocName;

                hplViewDetail.NavigateUrl = string.Format("~/Downloadfile.ashx?type=loadingAdviceDoc&uid={0}&index={1}", shipment.Uid, e.Row.RowIndex);
            }
        }
    }
}