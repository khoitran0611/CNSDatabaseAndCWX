using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// </summary>
    public partial class DateTimeControl : UserControl
    {
        private string dateName;
        private DateTime dateTime = DateTime.MinValue;
        private bool startDateHasBeenSet = false;
        private string timeName;
        private bool futureDateAllowed  = false;

        /// <summary>
        /// Gets or sets a value indicating whether [future date not allowed].
        /// </summary>
        /// <value>
        /// 	<c>true</c> if [future date not allowed]; otherwise, <c>false</c>.
        /// </value>
        public bool FutureDateAllowed 
        {
            get { return futureDateAllowed; }
            set { futureDateAllowed = value; }
        }

        /// <summary>
        /// Gets or sets the name of the date.
        /// </summary>
        /// <value>The name of the date.</value>
        public string HeaderDate
        {
            get { return dateName; }
            set { dateName = value; }
        }

        /// <summary>
        /// Gets or sets the name of the time.
        /// </summary>
        /// <value>The name of the time.</value>
        public string HeaderTime
        {
            get { return timeName; }
            set { timeName = value; }
        }

        /// <summary>
        /// Sets the start date time.
        /// </summary>
        /// <param name="dateTime">The date time.</param>
        /// <returns></returns>
        public void SetStartDateTime(DateTime dateTime)
        {
            fromCalendar.SetDateValue(dateTime);
            DropDownListHours.ClearSelection();
            DropDownListMinutes.ClearSelection();
            DropDownListSeconds.ClearSelection();

            DropDownListHours.Items.FindByValue(dateTime.Hour.ToString()).Selected = true;
            DropDownListMinutes.Items.FindByValue(dateTime.Minute.ToString()).Selected = true;
            DropDownListSeconds.Items.FindByValue(dateTime.Second.ToString()).Selected = true;
            startDateHasBeenSet = true;
        }

        /// <summary>
        /// Gets the datetime.
        /// </summary>
        /// <returns></returns>
        public DateTime GetDatetime()
        {
            DateTime tmp = fromCalendar.GetDateValue();
            dateTime = new DateTime(tmp.Year, tmp.Month, tmp.Day, int.Parse(DropDownListHours.SelectedValue),
                                    int.Parse(DropDownListMinutes.SelectedValue),
                                    int.Parse(DropDownListSeconds.SelectedValue));

            return dateTime;
        }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LabelHeaderTime.Text = HeaderTime;
                LabelHeaderDate.Text = HeaderDate;

                if (!startDateHasBeenSet)
                {
                    fromCalendar.SetDateValue(DateTime.Now);
                    DropDownListHours.Items.FindByValue(DateTime.Now.Hour.ToString()).Selected = true;
                    DropDownListMinutes.Items.FindByValue(DateTime.Now.Minute.ToString()).Selected = true;
                    DropDownListSeconds.Items.FindByValue(DateTime.Now.Second.ToString()).Selected = true;
                }
            }
            //else
            //{
            //    Page.Validate();
            //}
        }

        /// <summary>
        /// Handles the ServerValidate event of the DateTimeValidator control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="args">The <see cref="System.Web.UI.WebControls.ServerValidateEventArgs"/> instance containing the event data.</param>
        protected void DateTimeValidator_ServerValidate(object sender, ServerValidateEventArgs args)
        {

            CustomValidator custom = sender as CustomValidator;

            if (FutureDateAllowed)
            {
                args.IsValid = true;
            }
            else
            {
                args.IsValid = !(GetDatetime() > DateTime.Now);
                if (!args.IsValid)
                {
                    custom.ErrorMessage = "Date may not be in the future";
                }
            }

        }
    }
}