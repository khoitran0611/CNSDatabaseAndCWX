﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Web.Helpers;
using AgriMore.Logistics.Domain.Specification;

namespace AgriMore.Logistics.Web
{
    public partial class ExpiredPackagesList : BasePage
    {
        private const string urlDefault = "Default.aspx";
        private string invalidinputtext = Resources.Localization.Thereisaninvaliditem;        

        protected void Page_Load(object sender, EventArgs e)
        {
            ltPackageDescription.Text = "";
            //DisplayDescription();            
            ErrorHelper.SetErrorLabel(false, string.Empty, LabelError, false);
            btnPackExpiredProductWaste.Visible = false;
            if (Page.IsPostBack) return;

            BindingLocation();            
            BindPackageTypes();
            BindProducts();
            BindingExpiredPackages();
        }              

        protected void DdlLocationSelectedIndexChanged(object sender, EventArgs e)
        {
            Location fromLocation = RepFactory.GetLocationRepository().GetOne(long.Parse(ddlLocation.SelectedValue));
            FillPackages(fromLocation);            
        }

        public void BindingExpiredPackages()
        {
            Location fromLocation = RepFactory.GetLocationRepository().GetOne(long.Parse(ddlLocation.SelectedValue));
            FillPackages(fromLocation);           
        }

        private void BindingLocation()
        {
            ICollection<Location> locations = new List<Location>(RepositoryHelper.GetChainEntityForCurrentUser().Locations);
            ddlLocation.DataSource = locations;
            ddlLocation.DataValueField = "Uid";
            ddlLocation.DataTextField = "Name";
            ddlLocation.DataBind();           
        }

        private void FillPackages(Location location)
        {
            IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(CurLangCode, 0, 0, RepositoryHelper.GetChainEntityForCurrentUser().Uid).ToList();
            var expiredPackages = new List<Package>();
            var updateExpiredPackages = new List<Package>();
            var materialId = ddlPackageMaterial.SelectedValue.ToInt64();

            List<long> selectedProducts = new List<long>();

            foreach (ListItem prodItem in lbxProduct.Items)
            {
                if (prodItem.Selected)
                {
                    selectedProducts.Add(Int64.Parse(prodItem.Value));
                }
            }

            //retrieve packages
            ICollection<Package> packages = RepFactory.GetPackageRepository().Find(new PackageInLocationSpecification(location));            
            foreach (Package package in packages)
            {
                if ((package.BestBeforeEndDateTime != DateTime.MinValue && DateTime.Now > package.BestBeforeEndDateTime) || 
                    (package.ShelfLifeEndDateTime != DateTime.MinValue && DateTime.Now > package.ShelfLifeEndDateTime))
                {
                    expiredPackages.Add(package);
                }                
            }
            

            if (materialId != 0 && packageTypes != null && packageTypes.Any())
            {
                updateExpiredPackages.Clear();

                foreach (var ep in expiredPackages)
                {
                    var ptype = packageTypes.Where(pt => pt.Uid == ep.PackageTypeId).FirstOrDefault();
                    if (ptype != null)
                    {
                        if (ptype.PackagingMaterial.Uid == materialId)
                        {
                            updateExpiredPackages.Add(ep);
                        }
                    }
                }
            }
            else
            {
                updateExpiredPackages = expiredPackages;
            }            

            //Fill packages
            lbxExpiredPackages.Items.Clear();
            foreach (Package package in updateExpiredPackages)
            {
                if (package.PrimaryProducts != null && package.PrimaryProducts.Any())
                {
                    foreach (var prod in selectedProducts)
                    {
                        if (package.PrimaryProducts.Any(pr => pr.ProductUid == prod) && package.PackageTypeCategoryId != 4) //Don't get the waste disposal package here
                        {
                            var listItem = new ListItem(RepositoryHelper.CreatePackageName(package, RepositoryHelper.GetChainEntityForCurrentUser()), package.Uid.ToString());
                            lbxExpiredPackages.Items.Add(listItem);
                        }
                    }                    
                }
            }

            //Set the selected index to first item
            if (lbxExpiredPackages.Items.Count > 0)
            {
                lbxExpiredPackages.SelectedIndex = 0;
            }

            //Only show the Package Disposal button if at list 1 item selected
            foreach (ListItem item in lbxExpiredPackages.Items)
            {
                if (item.Selected)
                {
                    btnPackExpiredProductWaste.Visible = true;
                    break;
                }
            }
        }

        protected void btnPackExpiredProductWaste_Click(object sender, EventArgs e)
        {
            Page.Validate();
            if (!Page.IsValid)
            {
                //Enable the button Package only if at least 1 package is selected.
                foreach (ListItem item in lbxExpiredPackages.Items)
                {
                    if (item.Selected)
                    {
                        btnPackExpiredProductWaste.Visible = true;
                        break;
                    }
                }
                return;
            }

            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();
            int packageIdentification;

            bool fromIsNumeric = int.TryParse(txtIdenfication.Text, out packageIdentification);

            if (!fromIsNumeric)
            {
                ErrorHelper.SetErrorLabel(true, Resources.Localization.Theidentificationisnotnumeric, LabelError, false);                                
            }

            ValidateIdentifications(chainEntity);


            TransactionManager transactionManager = new TransactionManager();            
            try
            {
                transactionManager.BeginTransaction();                                

                var selectedLocation = RepFactory.GetLocationRepository().GetOne(Int64.Parse(ddlLocation.SelectedValue));
                List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];
                PackagingDefine packageType = null;
                if (packageTypes.Any())
                {
                    packageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
                }                
                
                DateTime dateTimeOfPacking = DateTime.Now;

                List<Identification> packageIdentifications = null;

                packageIdentifications = GetPackageIdentifications(chainEntity, packageIdentification, packageIdentification);

                Package pack = new Package();

                //Add new properties for package
                pack =
                    pack.Pack(packageType, dateTimeOfPacking, packageIdentifications,
                                 "", DateTime.MinValue,
                                 DateTime.MinValue, DateTime.MinValue);
                pack.FromUid = packageIdentification;
                pack.ToUid = packageIdentification;
                pack.TypeOfWaste = (int)DisposalPackingStatus.Expired;                               
                
                RepFactory.GetPackageRepository().Add(pack);

                foreach (ListItem item in lbxExpiredPackages.Items)
                {
                    //Remove selected package from location
                    if (item.Selected && selectedLocation != null)
                    {
                        var package = RepFactory.GetPackageRepository().GetOne(Int64.Parse(item.Value));

                        if (package.PrimaryProducts != null && package.PrimaryProducts.Any())
                        {
                            pack.primaryProducts.AddAll(package.PrimaryProducts);
                        }

                        package.ParentPackage = pack;

                        RepFactory.GetPackageRepository().Store(package);

                        //Add row to keep track in VPS later
                        var wasteDisposalExpiredPackage = new WasteDisposalExpirePackage()
                        {
                            ExpiredPackageId = package.Uid,
                            WasteDisposalPackageId = pack.Uid
                        };

                        RepFactory.GetWasteDisposalExpirePackageRepository().Add(wasteDisposalExpiredPackage);

                        RemovePreviousPackageFromLocation(selectedLocation, package);
                    }
                }

                //Insert 1 row into the table packagepackagingwasteinfo
                var wasteInfo = new PackagePackagingWasteInfo()
                {
                    PackageId = pack.Uid,
                    PackingWasteDescription = (pack.ToUid - pack.FromUid + 1).ToString() +  " package Waste Disposal",
                    TypeOfWaste = (int)DisposalPackingStatus.Expired
                };
                if (pack.PrimaryProducts.Any())
                {
                    foreach (var priProd in pack.PrimaryProducts)
                    {
                        wasteInfo.PackingWasteDescription += "\n";
                        wasteInfo.PackingWasteDescription += priProd.ProductName + " ";
                    }
                }

                if (packageType != null) wasteInfo.PackingWasteDescription += " - Material: " + packageType.PackagingMaterial.Name;
                long numPackages = 0;
                foreach (ListItem item in lbxExpiredPackages.Items)
                {                    
                    //Remove selected package from location
                    if (item.Selected && selectedLocation != null)
                    {
                        var package = RepFactory.GetPackageRepository().GetOne(Int64.Parse(item.Value));
                        if (package.PrimaryProducts != null && package.PrimaryProducts.Any())
                        {
                            wasteInfo.PackingWasteDescription += " with ";
                            foreach (var priProduct in package.PrimaryProducts)
                            {
                                var product = ProductServices.GetById(priProduct.ProductUid);

                                if (product != null)
                                {                                    
                                    wasteInfo.PackingWasteDescription += product.Name + ", ";
                                }
                            }

                            wasteInfo.PackingWasteDescription = wasteInfo.PackingWasteDescription.Substring(0, wasteInfo.PackingWasteDescription.Length - 2);
                        }

                        wasteInfo.PackageId = pack.Uid;

                        foreach(var pk in RepFactory.GetPackageRepository().AsCollection()) 
                        {
                            Package childPackage = null;

                            if (pk.ParentPackage != null && pk.ParentPackage.Uid == pack.Uid)
                            {
                                childPackage = pack;
                            }

                            if (childPackage != null)
                            {
                                numPackages += (childPackage.ToUid - childPackage.FromUid + 1);
                            }
                        }
                        
                    }
                }

                if (numPackages > 0) wasteInfo.PackingWasteDescription += " " + numPackages.ToString() + " package(s)";

                RepFactory.GetPackagePackagingWasteInfoRepository().Add(wasteInfo);   

                transactionManager.CommitTransaction();
                
                Response.Redirect(string.Format("{0}?{1}={2}&{3}={4}", urlDefault, WebConstants.InfoMsg, (long)InfoMessage.PackSuccessful,
                WebConstants.InfoDtl, string.Format("{0},{1},{2},{3}", pack.Uid, packageIdentifications[0].Id, pack.FromUid, pack.ToUid)), false);
            }

            catch (ArgumentNullException exception)
            {
                transactionManager.RollbackTransaction();
                ErrorHelper.SetErrorLabel(true, invalidinputtext + " " + exception.Message, LabelError, false);               
            }
            catch (ArgumentException exception)
            {
                transactionManager.RollbackTransaction();
                ErrorHelper.SetErrorLabel(true, invalidinputtext + " " + exception.Message, LabelError, false);                
            }
            catch (Exception exception)
            {
                transactionManager.RollbackTransaction();
                ErrorHelper.HandleException(exception, transactionManager, LabelError);                                
            }
        }

        private void BindPackageTypes()
        {
            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

            IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(CurLangCode, 0, 0, chainEntity.Uid).Where(pt => pt.PackTypeCategory.Uid == 4).ToList();

            Session["packageTypes"] = packageTypes;
            DropDownListPackageType.DataSource = packageTypes;
            DropDownListPackageType.DataTextField = "name";
            DropDownListPackageType.DataValueField = "uid";
            DropDownListPackageType.DataBind();

            FillDataForSelectedPackageTypes();
        }

        private void FillDataForSelectedPackageTypes()
        {
            List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];

            if (packageTypes.Any())
            {
                if (DropDownListPackageType.SelectedValue != "")
                {
                    var selectedPackageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
                    LabelLenght.Text = selectedPackageType.LenghtValue + " " + selectedPackageType.LengthUoM.Name;
                    LabelWidth.Text = selectedPackageType.WidthValue + " " + selectedPackageType.WidthUoM.Name;
                    LabelWeight.Text = selectedPackageType.WeightValue + " " + selectedPackageType.WeightUoM.Name;
                    LabelHeight.Text = selectedPackageType.HeightValue + " " + selectedPackageType.HeightUoM.Name;
                    LabelMaterial.Text = selectedPackageType.PackagingMaterial.Name;
                    LabelSealed.Text = selectedPackageType.IsSealed.ToString();
                    LabelVentilated.Text = selectedPackageType.IsVantilated.ToString();
                }

            }
        }

        protected void DropDownListPackageType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {                
                FillDataForSelectedPackageTypes();                
                List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];
                PackagingDefine packageType = null;
                if (packageTypes.Any())
                {
                    if (DropDownListPackageType.SelectedValue != "")
                    {
                        packageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);                
            }
        }

        private void ValidateIdentifications(ChainEntity chainEntity)
        {
            int from;            

            bool fromIsNumeric = int.TryParse(txtIdenfication.Text, out from);            

            if (fromIsNumeric == false)
            {
                ErrorHelper.SetErrorLabel(true, Resources.Localization.Theidentificationisnotnumeric, LabelError, true);                                    
            }

            
            if (from < 0)
            {
                ErrorHelper.SetErrorLabel(true, Resources.Localization.Identificationscannotbenegative, LabelError, true);                
            }

            ValidateIdentificationsExistance(from, from, chainEntity);
        }

        private void ValidateIdentificationsExistance(int from, int to, ChainEntity chainEntity)
        {
            for (int counter = from; counter <= to; counter++)
            {
                if (RepositoryHelper.IdentificationExists(counter.ToString(), chainEntity))
                {
                    ErrorHelper.SetErrorLabel(true, Resources.Localization.Theidentificationisalreadyused, LabelError, true);                    
                }
            }
        }

        private List<Identification> GetPackageIdentifications(ChainEntity chainEntity, int fromUid, int toUid)
        {
            List<Identification> packageIdentifications = new List<Identification>();
            Identification identification = new Identification(string.Empty, chainEntity, fromUid, toUid);
            packageIdentifications.Add(identification);
            return packageIdentifications;
        }        

        private void RemovePreviousPackageFromLocation(Location location, Package package)
        {
            if (ExposuresControl.Visible)
            {
                if (location != null)
                {
                    DateTime dateTimeOfPacking = DateTime.Now;
                    location.Remove(package, dateTimeOfPacking);
                }
                else
                {
                    ErrorHelper.SetErrorLabel(true, Resources.Localization.Thecurrentlocationisnull, LabelError, true);                                        
                }
            }
        }

        protected void lbxExpiredPackages_SelectedIndexChanged(object sender, EventArgs e)
        {
            DisplayDescription();
        }

        protected void ddlPackageMaterial_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindingExpiredPackages();   
        }

        void BindProducts()
        {
            lbxProduct.Items.Clear();

            IEnumerable<Product> products = ProductServices.GetProductList();
            foreach(var product in products) 
            {
                ListItem item = new ListItem(product.Name, product.Uid.ToString());
                lbxProduct.Items.Add(item);
                item.Selected = true;
            }            
        }

        protected void lbxProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindingExpiredPackages();
        }

        void DisplayDescription()
        {
            IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(CurLangCode, 0, 0, RepositoryHelper.GetChainEntityForCurrentUser().Uid).ToList();
            try
            {
                foreach (ListItem item in lbxExpiredPackages.Items)
                {
                    var packageDescription = "";
                    if (item.Selected)
                    {
                        btnPackExpiredProductWaste.Visible = true;

                        //Display info about the 

                        var selectedPackage = RepFactory.GetPackageRepository().GetOne(item.Value.ToInt64());

                        packageDescription += "Material: ";
                        packageDescription +=
                            packageTypes.Where(pt => pt.Uid == selectedPackage.PackageTypeId).FirstOrDefault().PackagingMaterial.Name;

                        if (selectedPackage.PrimaryProducts != null && selectedPackage.PrimaryProducts.Any())
                        {
                            foreach (var priProduct in selectedPackage.PrimaryProducts)
                            {
                                var product = ProductServices.GetById(priProduct.ProductUid);

                                if (product != null)
                                {
                                    packageDescription += " with ";
                                    packageDescription += product.Name;
                                }
                            }
                        }

                        ltPackageDescription.Text = packageDescription;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
        }
    }
}