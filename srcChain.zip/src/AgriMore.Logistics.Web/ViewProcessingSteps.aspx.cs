using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using System.Linq;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain.ThirdPartyEntities;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// </summary>
    public partial class ViewProcessingSteps : BasePage
    {
        private const string IDENTIFICATIONS_NAME = "identifications";
        private const string CHAINENTITIES_NAME = "chainentities";
        private const string name = "Name";
        private const string uid = "Uid";
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();
        private const string PREVIOUS_CHAINENTITY = "PREVIOUS_CHAINENTITY";
        private const string PREVIOUS_IDENTIFICATION = "PREVIOUS_IDENTIFICATION";
        private const string ALL_IDENTIFICATIONS_NAME = "ALL_IDENTIFICATIONS_NAME";

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            MultiViewPackageList.SetActiveView(ViewMainform);

            ChainEntity current = RepositoryHelper.GetChainEntityForCurrentUser();

            List<Identification> allIdentifications = null;
            List<Identification> identifications = null;
            List<ChainEntity> chainEntities = null;

            long chainEntityId = current.Uid;

            if (IsPostBack)
            {
                allIdentifications = Session[ALL_IDENTIFICATIONS_NAME] as List<Identification>;
                identifications = Session[IDENTIFICATIONS_NAME] as List<Identification>;
                chainEntities = Session[CHAINENTITIES_NAME] as List<ChainEntity>;
            }
            else
            {

                allIdentifications = new List<Identification>();
                identifications = new List<Identification>();
                chainEntities = new List<ChainEntity>();
                //identifications = RepositoryHelper.GetIdentificationFromChainEntitiesDoneBusinessWith(current);
                //chainEntities = FilterOnChainEntities(identifications);

                RepositoryHelper.GetIdentificationFromChainEntitiesDoneBusinessWith(current, allIdentifications, 
                    identifications, chainEntities, Int64.Parse(ddlPackageType.SelectedValue));


                Session[ALL_IDENTIFICATIONS_NAME] = allIdentifications;
                Session[IDENTIFICATIONS_NAME] = identifications;
                Session[CHAINENTITIES_NAME] = chainEntities;

                Session[PREVIOUS_CHAINENTITY] = null;
                Session[PREVIOUS_IDENTIFICATION] = null;
                BindChainEntityList(chainEntityId);
                if (DropDownListChainEntity.Items.Count > 0)
                {
                    long selectedChainEntityId = long.Parse(DropDownListChainEntity.SelectedValue);
                    BindIdentificationList(selectedChainEntityId, String.Empty);
                }
                else
                {
                    DropDownListChainEntity.Enabled = false;
                    DropDownListIdentification.Enabled = false;
                    MultiViewPackageList.SetActiveView(ViewNoResultsFound);

                }
            }

            LoadPreviousHistory();
        }

        /// <summary>
        /// Filters the on chain entities.
        /// </summary>
        /// <param name="identifications">The identifications.</param>
        /// <returns></returns>
        private static ICollection<ChainEntity> FilterOnChainEntities(IEnumerable<Identification> identifications)
        {
            List<ChainEntity> chainEntities = new List<ChainEntity>();

            foreach (Identification identification in identifications)
            {
                if (!chainEntities.Contains(identification.ChainEntity))
                {
                    chainEntities.Add(identification.ChainEntity);
                }
            }

            chainEntities.Sort(delegate(ChainEntity p1, ChainEntity p2) { return p1.Name.CompareTo(p2.Name); });

            return chainEntities;
        }


        /// <summary>
        /// Binds the identification list.
        /// </summary>
        /// <param name="chainEntityUid">The chain entity uid.</param>
        /// <param name="iden">The iden.</param>
        private void BindIdentificationList(long chainEntityUid, string iden)
        {
            DropDownListIdentification.Items.Clear();
            IList<Identification> identifications = Session[IDENTIFICATIONS_NAME] as IList<Identification>;
            if (identifications == null)
            {
                DropDownListIdentification.Enabled = false;
                return;
            }

            List<Identification> filter = new List<Identification>();

            foreach (Identification identification in identifications)
            {
                if (identification.ChainEntity.Uid.Equals(chainEntityUid))
                {
                    filter.Add(identification);
                }
            }

            Session["ParentPackageList"] = filter;

            ListItem emptyListItem = new ListItem("-- select package --", "-1");
            DropDownListIdentification.Items.Add(emptyListItem);

            foreach (Identification identification in filter)
            {
                ListItem li = new ListItem(identification.Id + identification.FromUid + " - " + identification.Id + identification.ToUid, identification.Uid.ToString());
                DropDownListIdentification.Items.Add(li);

                //if (identification.Id == iden)
                if (identification.Uid.ToString() == iden)
                {
                    li.Selected = true;
                    Session["SelectedIdenId"] = identification.Uid;
                }
            }
        }

        /// <summary>
        /// Binds the chain entity list.
        /// </summary>
        /// <param name="chainEntityUid">The chain entity uid.</param>
        private void BindChainEntityList(long chainEntityUid)
        {
            ICollection<ChainEntity> chainEntities = Session[CHAINENTITIES_NAME] as ICollection<ChainEntity>;
            if (chainEntities == null)
            {
                DropDownListChainEntity.Enabled = false;
                return;
            }

            DropDownListChainEntity.DataSource = chainEntities;
            DropDownListChainEntity.DataValueField = uid;
            DropDownListChainEntity.DataTextField = name;
            DropDownListChainEntity.DataBind();

            foreach (ListItem item in DropDownListChainEntity.Items)
            {
                if (item.Value.Equals(chainEntityUid.ToString()))
                {
                    item.Selected = true;
                }
            }
        }


        /// <summary>
        /// Gets the packages with repack relation ship.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <returns></returns>
        private IEnumerable<Package> GetPackagesWithRepackRelationShip(Package package)
        {
            List<Package> allPackages = new List<Package>();
            ICollection<RepackPackageRelationship> relationships =
                repositoryFactory.GetRepackPackageRelationshipRepository().Find(
                    new RepackedRelationshipByPackage(package));

            foreach (RepackPackageRelationship packageRelationship in relationships)
            {
                long packageToRetrieve = -1;

                if (packageRelationship.NewPackageFromRepackId == package.Uid)
                {
                    packageToRetrieve = packageRelationship.RepackedPackageId;
                }
                else if (packageRelationship.RepackedPackageId == package.Uid)
                {
                    packageToRetrieve = packageRelationship.NewPackageFromRepackId;
                }

                if (packageToRetrieve != -1)
                {
                    Package tmpPackage = repositoryFactory.GetPackageRepository().GetOne(packageToRetrieve);
                    if (tmpPackage != null)
                    {
                        if (!allPackages.Contains(tmpPackage))
                        {
                            allPackages.Add(tmpPackage);
                        }
                    }
                }
            }

            return allPackages;
        }

        /// <summary>
        /// Gets the processing steps.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <returns></returns>
        private IEnumerable<ProcessingStep> GetProcessingSteps(Package package)
        {
            List<Package> allPackages = new List<Package>();
            List<ProcessingStep> allProcessingSteps = new List<ProcessingStep>();

            if (!allPackages.Contains(package))
            {
                allPackages.Add(package);
            }

            foreach (Package tmpPackage in allPackages)
            {
                ICollection<ProcessingStep> steps =
                    repositoryFactory.GetProcessingStepRepository().Find(
                        new ProcessingStepsByPackageIdentification(tmpPackage, false));

                foreach (ProcessingStep step in steps)
                {
                    bool allreadyExists = false;
                    foreach (ProcessingStep processingStep in allProcessingSteps)
                    {
                        if (step.Uid == processingStep.Uid)
                        {
                            allreadyExists = true;
                            break;
                        }
                    }

                    if (!allreadyExists)
                    {
                        allProcessingSteps.Add(step);
                    }
                }
            }

            return allProcessingSteps;
        }


        /// <summary>
        /// Gets the identification.
        /// </summary>
        /// <param name="chainEntity">The chain entity.</param>
        /// <param name="identification">The identification.</param>
        /// <returns></returns>
        private Identification GetIdentification(long chainEntity, string identification)
        {
            //IList<Identification> identifications = Session[ALL_IDENTIFICATIONS_NAME] as IList<Identification>;
            IList<Identification> identifications = Session[IDENTIFICATIONS_NAME] as IList<Identification>;

            if (identifications != null)
            {
                foreach (Identification identification1 in identifications)
                {
                    var groupIdt = string.Format("{0}{1} - {0}{2}", identification1.Id,
                    identification1.FromUid > 0 ? identification1.FromUid.ToString() : string.Empty,
                    identification1.ToUid > 0 ? identification1.ToUid.ToString() : string.Empty);

                    //if (identification1.ChainEntity.Uid == chainEntity && identification1.Id == identification)
                    if (identification1.ChainEntity.Uid == chainEntity && groupIdt == identification)
                    {
                        return identification1;
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// Adds the chain entity control.
        /// </summary>
        /// <param name="ce">The ce.</param>
        /// <param name="chainEntityControlUniqueID">The chain entity control unique ID.</param>
        /// <returns></returns>
        private ChainEntityControl AddChainEntityControl(ChainEntity ce, int chainEntityControlUniqueID)
        {
            ChainEntityControl chainEntityControl =
                (ChainEntityControl)Page.LoadControl("ViewProcessingSteps/ChainEntityControl.ascx");
            chainEntityControl.ID = chainEntityControlUniqueID.ToString();// String.Format("CE{0}", chainEntityControlUniqueID);
            placeholder.Controls.Add(chainEntityControl);
            chainEntityControl.Initialize(ce);

            return chainEntityControl;
        }

        /// <summary>
        /// Adds the location control.
        /// </summary>
        /// <param name="ce">The ce.</param>
        /// <param name="processingView">The processing view.</param>
        /// <returns></returns>
        private LocationControl AddLocationControl(ChainEntityControl ce, ProcessingView processingView)
        {
            LocationControl locationControl =
                (LocationControl)Page.LoadControl("ViewProcessingSteps/LocationControl.ascx");
            locationControl.ID = String.Format("{0}LC{1}", ce.ID, processingView.Step.Uid);
            locationControl.PackageToView += new LocationControlEventHandler(locationControl_PackageToView);
            locationControl.Initialize(processingView);
            ce.AddLocationControl(locationControl);

            return locationControl;
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the DropDownListChildren control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void DropDownListIdentification_SelectedIndexChanged(object sender, EventArgs e)
        {
            var wasteLinkDetailInfo = string.Empty;            
            var parentPackageList = (List<Identification>)Session["ParentPackageList"];

            if (parentPackageList != null && parentPackageList.Count > 0)
            {
                foreach (var iden in parentPackageList)
                {
                    if (iden.Uid == long.Parse(DropDownListIdentification.SelectedValue))
                    {
                        var groupIdt = string.Format("{0}{1} - {0}{2}", iden.Id,
                            iden.FromUid > 0 ? iden.FromUid.ToString() : string.Empty,
                            iden.ToUid > 0 ? iden.ToUid.ToString() : string.Empty);

                        Session["SelectedIdenId"] = groupIdt; //iden.Id;
                        Session["SelectedIden"] = iden.Uid;
                        break;
                    }
                }
            }

            if (DropDownListIdentification.SelectedValue != "-1")
            {

                Identification identification =
                    RetrieveIdentification(DropDownListChainEntity.SelectedValue,
                                           (string)Session["SelectedIdenId"]);

                Session[PREVIOUS_CHAINENTITY] = DropDownListChainEntity.SelectedValue;
                Session[PREVIOUS_IDENTIFICATION] = (string)Session["SelectedIdenId"];
                TextBoxSearchPackage.Text = String.Empty;

                var detail = string.Empty;
                //Get the tracing for the waste disposal package info
                if (ddlPackageType.SelectedValue == "4") // Waste disposal package
                {
                    detail = GetWasteLinkDetail();
                }

                ShowHistory(identification, detail);
            }
        }

        /// <summary>
        /// Gets the child packages.
        /// </summary>
        /// <param name="parentPackage">The parent package.</param>
        /// <returns></returns>
        private IEnumerable<Package> GetChildPackages(Package parentPackage)
        {
            List<Package> children = new List<Package>();

            ICollection<ProcessingStep> childrenSteps =
                repositoryFactory.GetProcessingStepRepository().Find(
                    new ProcessingStepsByPackageIdentification(parentPackage, true));

            foreach (ProcessingStep childrenStep in childrenSteps)
            {
                Package child = repositoryFactory.GetPackageRepository().GetOne(childrenStep.PackageId);
                if (child != null && !children.Contains(child))
                {
                    children.Add(child);
                }
            }
            return children;
        }


        /// <summary>
        /// Creates the processing views.
        /// </summary>
        /// <param name="steps">The steps.</param>
        /// <returns></returns>
        private IEnumerable<ProcessingView> CreateProcessingViews(IEnumerable<ProcessingStep> steps)
        {
            List<ProcessingView> processingViews = new List<ProcessingView>();

            foreach (ProcessingStep processingStep in steps)
            {
                if (processingStep.ProcessingStepType != ProcessingStepType.Treatment)
                {
                    Package package = repositoryFactory.GetPackageRepository().GetOne(processingStep.PackageId);
                    IEnumerable<Package> bulkPackages = GetPackagesWithRepackRelationShip(package);
                    IEnumerable<Package> childPackages = GetChildPackages(package);

                    User user = repositoryFactory.GetUserRepository().GetOne(processingStep.UserId);
                    ExposureDocument exposureDocument =
                        repositoryFactory.GetExposureDocumentRepository().GetOne(processingStep.ObjectUid);
                    ChainEntity localChainEntity =
                        repositoryFactory.GetChainEntityRepository().GetOne(
                            new ChainEntiyByLocationSpecification(exposureDocument.Location));

                    ProcessingView processingView =
                            new ProcessingView(processingStep, user, exposureDocument, package, localChainEntity,
                                               bulkPackages, childPackages);

                    processingViews.Add(processingView);
                }
            }
            processingViews.Sort(delegate(ProcessingView p1, ProcessingView p2) { return p2.Start.CompareTo(p1.Start); });

            return processingViews;
        }

        /// <summary>
        /// Retrieves the identification.
        /// </summary>
        /// <param name="chainEntity">The chain entity.</param>
        /// <param name="identificationString">The identification string.</param>
        /// <returns></returns>
        public Identification RetrieveIdentification(string chainEntity, string identificationString)
        {
            Identification identification = GetIdentification(long.Parse(chainEntity), identificationString);

            if (identification == null)
            {
                ChainEntity ce = repositoryFactory.GetChainEntityRepository().GetOne(long.Parse(chainEntity));
                ICollection<Identification> ids =
                    repositoryFactory.GetIdentificationRepository().Find(new IdentificationByChainEntity(ce));

                foreach (Identification id in ids)
                {
                    var groupIdt = string.Format("{0}{1} - {0}{2}", id.Id,
                            id.FromUid > 0 ? id.FromUid.ToString() : string.Empty,
                            id.ToUid > 0 ? id.ToUid.ToString() : string.Empty);

                    if (groupIdt == identificationString)
                    {
                        return id;
                    }
                }
            }

            return identification;
        }


        /// <summary>
        /// Shows the history.
        /// </summary>
        private void ShowHistory(Identification identification, string wasteLinkDetail = "")
        {
            if (identification != null)
            {
                placeholder.Controls.Clear();

                Package package =
                    repositoryFactory.GetPackageRepository().GetOne(
                        new PackageIdentificationSpecification(identification));

                if (package != null)
                {
                    IEnumerable<ProcessingStep> steps = GetProcessingSteps(package);
                    IEnumerable<ProcessingView> processingViews = CreateProcessingViews(steps);
                    IEnumerable<Treatment> treatments = RetrieveTreatments(steps);

                    ChainEntity prev = null;
                    ChainEntityControl cec = null;
                    LocationControl locationControl;


                    int chainEntityControlUniqueID = 0;
                    foreach (ProcessingView processingView in processingViews)
                    {
                        if (prev == null)
                        {
                            prev = processingView.ChainEntity;
                            cec = AddChainEntityControl(processingView.ChainEntity, chainEntityControlUniqueID);
                        }
                        else
                        {
                            if (prev.Uid != processingView.ChainEntity.Uid)
                            {
                                cec = AddChainEntityControl(processingView.ChainEntity, chainEntityControlUniqueID);
                                prev = processingView.ChainEntity;
                            }
                        }

                        chainEntityControlUniqueID++;

                        processingView.WasteLinkDetail = wasteLinkDetail;

                        locationControl = AddLocationControl(cec, processingView);

                        foreach (Treatment treatment in treatments)
                        {
                            Range<DateTime> locationRange = new Range<DateTime>(processingView.ExposureDocument.DateOfPlacement, processingView.ExposureDocument.DateOfRemoval);
                            if (locationRange.Contains(treatment.Duration.Start) || locationRange.Contains(treatment.Duration.End))
                            {
                                locationControl.AddTreatment(treatment);
                            }
                        }                        
                    }
                }
            }
        }

        /// <summary>
        /// Fills the data.
        /// </summary>
        private void LoadPreviousHistory()
        {
            var detail = "";
            string chainEntity = Session[PREVIOUS_CHAINENTITY] as string;
            string identificationString = Session[PREVIOUS_IDENTIFICATION] as string;

            if (string.IsNullOrEmpty(chainEntity) && string.IsNullOrEmpty(identificationString))
            {
                return;
            }

            Identification identification = RetrieveIdentification(chainEntity, identificationString);

            if (identification != null)
            {
                detail = GetWasteLinkDetail(identification.Uid);
            }
            else detail = GetWasteLinkDetail();

            ShowHistory(identification, detail);
        }

        /// <summary>
        /// Retrieves the treatments.
        /// </summary>
        /// <param name="steps">The steps.</param>
        /// <returns></returns>
        private IEnumerable<Treatment> RetrieveTreatments(IEnumerable<ProcessingStep> steps)
        {
            List<Treatment> alltTreatments = new List<Treatment>();
            foreach (ProcessingStep step in steps)
            {
                if (step.ProcessingStepType == ProcessingStepType.Treatment)
                {
                    Treatment treatment = repositoryFactory.GetTreatmentRepository().GetOne(step.ObjectUid);
                    alltTreatments.Add(treatment);
                }
            }

            return alltTreatments;
        }

        /// <summary>
        /// Handles the PackageToView event of the locationControl control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="AgriMore.Logistics.Web.LocationControlEventArgs"/> instance containing the event data.</param>
        void locationControl_PackageToView(object sender, LocationControlEventArgs e)
        {
            Identification identification = RetrieveIdentification(e.ChainEntityId, e.IndentificationText);
            if (identification != null)
            {
                Session[PREVIOUS_CHAINENTITY] = identification.ChainEntity.Uid.ToString();
                Session[PREVIOUS_IDENTIFICATION] = e.IndentificationText;//identification.Id;
                BindChainEntityList(identification.ChainEntity.Uid);
                BindIdentificationList(identification.ChainEntity.Uid, e.IndentificationText);
                TextBoxSearchPackage.Text = String.Empty;
                var detail = GetWasteLinkDetail(identification.Uid);
                ShowHistory(identification, detail);
            }
        }

        /// <summary>
        /// Handles the Click event of the ButtonSearch control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonSearch_Click(object sender, EventArgs e)
        {
            //string chainEntity = DropDownListChainEntity.SelectedValue;
            //string identification = DropDownListIdentification.SelectedItem.Text;

            //Session["CHAIN"] = chainEntity;
            //Session["IDEN"] = identification;

            //FillData();

            //if (String.IsNullOrEmpty(chainEntity.Trim()) || String.IsNullOrEmpty(identification.Trim()))
            //{
            //    MultiViewPackageList.SetActiveView(ViewNoResultsFound);
            //    LabelResult.Text = "you must first choose an Identification";
            //}
            //else
            //{
            //    FillData(chainEntity, identification);
            //}
        }

        ///// <summary>
        ///// Handles the Click event of the LinkButtonViewChild control.
        ///// </summary>
        ///// <param name="sender">The source of the event.</param>
        ///// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        //protected void LinkButtonViewChild_Click(object sender, EventArgs e)
        //{
        //    LinkButton button = sender as LinkButton;

        //    if (button != null)
        //    {
        //        //if (button.CommandName == "ViewChild")
        //        //{
        //        //    FillData(button.CommandArgument);
        //        //}
        //    }
        //}



        /// <summary>
        /// Handles the SelectedIndexChanged event of the DropDownListChainEntity control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void DropDownListChainEntity_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindIdentificationList(long.Parse(DropDownListChainEntity.SelectedValue), String.Empty);
            TextBoxSearchPackage.Text = String.Empty;
            placeholder.Controls.Clear();
        }


        /// <summary>
        /// Handles the Click event of the ButtonSearch control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void ButtonSearch_Click(object sender, EventArgs e)
        {
            var detail = "";
            string chainEntityId = DropDownListChainEntity.SelectedValue;
            string identificationToSearchFor = TextBoxSearchPackage.Text;

            if (String.IsNullOrEmpty(identificationToSearchFor)
                || identificationToSearchFor.Trim().Length == 0
                || String.IsNullOrEmpty(chainEntityId)
                || chainEntityId == "-1"
                || chainEntityId.Trim().Length == 0)
            {
                return;
            }

            Session[PREVIOUS_CHAINENTITY] = chainEntityId;
            Session[PREVIOUS_IDENTIFICATION] = identificationToSearchFor;
            DropDownListIdentification.ClearSelection();


            ICollection<Package> packagesKnownByRequesterChainEntity =
                repositoryFactory.GetPackageRepository().Find(
                    new PackageKnownByChainEntity(RepositoryHelper.GetChainEntityForCurrentUser()));

            List<Identification> allIdentifications = Session[ALL_IDENTIFICATIONS_NAME] as List<Identification>;

            Identification identificationTmp =
                RetrieveIdentification(chainEntityId, identificationToSearchFor);

            bool isValidIdentificationToView = false;

            if (identificationTmp == null || allIdentifications == null)
            {
                MultiViewPackageList.SetActiveView(ViewNoResultsFoundWithSearch);
                LabelMessage.Text =
                    String.Format(Resources.Localization.formatNoresultsfoundforIdentificationwithChainEntity,
                                  identificationToSearchFor, DropDownListChainEntity.SelectedItem.Text);
                return;
            }

            foreach (Identification identification in allIdentifications)
            {
                if (identification.Uid == identificationTmp.Uid)
                {
                    isValidIdentificationToView = true;
                    break;
                }
            }


            if (isValidIdentificationToView)
            {
                if (identificationTmp != null)
                {
                    detail = GetWasteLinkDetail(identificationTmp.Uid);
                }
                else GetWasteLinkDetail();

                ShowHistory(identificationTmp,detail);
            }
            else
            {
                MultiViewPackageList.SetActiveView(ViewNoResultsFoundWithSearch);
                LabelMessage.Text =
                    String.Format(Resources.Localization.formatNoresultsfoundforIdentificationwithChainEntity,
                                  identificationToSearchFor, DropDownListChainEntity.SelectedItem.Text);
                return;
            }



            //    if (identification != null)
            //    {
            //        foreach (Package package in packagesKnownByRequesterChainEntity)
            //        {
            //            foreach (Identification tmpIdentification in package.Identifications)
            //            {
            //                if (tmpIdentification.Uid == identification.Uid)
            //                {
            //                    isValidIdentificationToView = true;
            //                }
            //            }
            //        }


            //        if (isValidIdentificationToView)
            //        {
            //            ShowHistory(identification);
            //        }
            //        else
            //        {
            //            MultiViewPackageList.SetActiveView(ViewNoResultsFoundWithSearch);
            //            LabelMessage.Text =
            //                String.Format("No results found for Identification {0} with ChainEntity \"{1}\"",
            //                              identificationToSearchFor, DropDownListChainEntity.SelectedItem.Text);
            //        }
            //    }
            //    else
            //    {
            //        MultiViewPackageList.SetActiveView(ViewNoResultsFoundWithSearch);
            //        LabelMessage.Text =
            //            String.Format("No results found for Identification {0} with ChainEntity \"{1}\"",
            //                          identificationToSearchFor, DropDownListChainEntity.SelectedItem.Text);
            //    }
            //}            
        }

        protected void ddlPackageType_SelectedIndexChanged(object sender, EventArgs e)
        {            
            ChainEntity current = RepositoryHelper.GetChainEntityForCurrentUser();

            List<Identification> allIdentifications = null;
            List<Identification> identifications = null;
            List<ChainEntity> chainEntities = null;

            long chainEntityId = current.Uid;

            allIdentifications = new List<Identification>();
            identifications = new List<Identification>();
            chainEntities = new List<ChainEntity>();

            RepositoryHelper.GetIdentificationFromChainEntitiesDoneBusinessWith(current, allIdentifications,
                identifications, chainEntities, Int64.Parse(ddlPackageType.SelectedValue));


            Session[ALL_IDENTIFICATIONS_NAME] = allIdentifications;
            Session[IDENTIFICATIONS_NAME] = identifications;
            Session[CHAINENTITIES_NAME] = chainEntities;

            Session[PREVIOUS_CHAINENTITY] = null;
            Session[PREVIOUS_IDENTIFICATION] = null;
            BindChainEntityList(chainEntityId);
            if (DropDownListChainEntity.Items.Count > 0)
            {
                long selectedChainEntityId = long.Parse(DropDownListChainEntity.SelectedValue);
                BindIdentificationList(selectedChainEntityId, String.Empty);
            }
            else
            {
                DropDownListChainEntity.Enabled = false;
                DropDownListIdentification.Enabled = false;
                MultiViewPackageList.SetActiveView(ViewNoResultsFound);

            }            
        }

        protected string GetWasteLinkDetail(long idenId = 0)
        {
            var wasteLinkDetailInfo = string.Empty;
            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

            IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(CurLangCode, 0, 0, chainEntity.Uid).ToList();
            Identification iden = null;

            //Fistly check if it is from disposal material package or expired package
            //Expired first
            if(idenId == 0) {
                if (Session["SelectedIden"] != null)
                {
                    iden = RepFactory.GetIdentificationRepository().GetOne(long.Parse(Session["SelectedIden"].ToString()));
                }
                else
                {
                    iden = RepFactory.GetIdentificationRepository().GetOne(idenId);
                }
            }
            else
            {
                iden = RepFactory.GetIdentificationRepository().GetOne(idenId);
            }


            long disposalPackageId = iden != null? iden.Package.Uid : 0;
            var wasteDisposalExpirePackage =
                RepFactory.GetWasteDisposalExpirePackageRepository().AsCollection()
                .Where(wd => wd.WasteDisposalPackageId == disposalPackageId).FirstOrDefault();
            if (wasteDisposalExpirePackage != null) // it is from expired package
            {
                //Show expired package info
                var realPackage = RepFactory.GetPackageRepository().GetOne(wasteDisposalExpirePackage.ExpiredPackageId);
                var disPackage = RepFactory.GetPackageRepository().GetOne(disposalPackageId);

                var groupIdt = string.Format("{0}{1} - {0}{2}", wasteDisposalExpirePackage.ExpiredPackageId,
                    realPackage.FromUid > 0 ? realPackage.FromUid.ToString() : string.Empty,
                    realPackage.ToUid > 0 ? realPackage.ToUid.ToString() : string.Empty);

                wasteLinkDetailInfo += "The waste disposal package " + (idenId == 0 ? DropDownListIdentification.SelectedItem.Text : iden.Package.FromUid.ToString() + " - " + iden.Package.ToUid.ToString());
                wasteLinkDetailInfo += " with material  " +
                        packageTypes.Where(pt => pt.Uid == disPackage.PackageTypeId)
                            .FirstOrDefault().PackagingMaterial.Name;

                wasteLinkDetailInfo += " is from the expired package " + groupIdt;
                wasteLinkDetailInfo += " with material  " +
                        packageTypes.Where(pt => pt.Uid == realPackage.PackageTypeId)
                            .FirstOrDefault().PackagingMaterial.Name;

                //Session["wasteLinkDetailInfo"] = wasteLinkDetailInfo;
            }
            else
            {
                var wasteDisposalDisposalPackage =
                RepFactory.GetWasteDisposalDisposalPackageRepository().AsCollection()
                .Where(wd => wd.WasteDisposalPackageId == disposalPackageId).FirstOrDefault();

                if (wasteDisposalDisposalPackage != null) // it is from material package
                {
                    //First get the trace info
                    var tracingInfo = RepFactory.GetWasteDisposalPackageTracingRepository()
                        .AsCollection().Where(wd => wd.DisposalPackageId == wasteDisposalDisposalPackage.DisposalPackageId).FirstOrDefault();

                    var parentUnpackedPackage = RepFactory.GetPackageRepository().GetOne(tracingInfo.ParentUnpackPackageId);
                    var childUnpackedPackage = RepFactory.GetPackageRepository().GetOne(tracingInfo.ChildUnpackPackageId);

                    //Show expired package info                            
                    var groupChildUnpackedPackage = string.Format("{0}{1} - {0}{2}", childUnpackedPackage.Uid,
                        childUnpackedPackage.FromUid > 0 ? childUnpackedPackage.FromUid.ToString() : string.Empty,
                        childUnpackedPackage.ToUid > 0 ? childUnpackedPackage.ToUid.ToString() : string.Empty);

                    var groupParentUnpackedPackage = string.Format("{0}{1} - {0}{2}", parentUnpackedPackage.Uid,
                        parentUnpackedPackage.FromUid > 0 ? parentUnpackedPackage.FromUid.ToString() : string.Empty,
                        parentUnpackedPackage.ToUid > 0 ? parentUnpackedPackage.ToUid.ToString() : string.Empty);
                    var realPack = RepFactory.GetPackageRepository().GetOne(wasteDisposalDisposalPackage.WasteDisposalPackageId);
                    wasteLinkDetailInfo += "The waste disposal package " + (idenId == 0 ? DropDownListIdentification.SelectedItem.Text : iden.Package.FromUid.ToString() + " - " + iden.Package.ToUid.ToString());
                    wasteLinkDetailInfo += " with material " +
                        packageTypes.Where(pt => pt.Uid == realPack.PackageTypeId)
                            .FirstOrDefault().PackagingMaterial.Name;
                    wasteLinkDetailInfo += " is from the disposal material package id " + tracingInfo.DisposalPackageId + "\n";
                    wasteLinkDetailInfo += "which is first unpack from package " + groupParentUnpackedPackage + "\n";
                    wasteLinkDetailInfo += "to unpacked package " + groupChildUnpackedPackage + "\n";

                    //Session["wasteLinkDetailInfo"] = wasteLinkDetailInfo;
                }
            }

            return wasteLinkDetailInfo;
        }
    }

    public class ProcessingView
    {
        private readonly IEnumerable<Package> bulkPackages;
        private readonly ChainEntity chainEntity;
        private readonly IEnumerable<Package> childPackages;
        private readonly Package package;
        private readonly DateTime end;
        private readonly ExposureDocument exposureDocument;
        private readonly DateTime start;
        private readonly ProcessingStep step;
        private readonly User user;
        private string wasteLinkDetail;        

        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessingView"/> class.
        /// </summary>
        /// <param name="step">The step.</param>
        /// <param name="user">The user.</param>
        /// <param name="exposureDocument">The exposure document.</param>
        /// <param name="package">The package.</param>
        /// <param name="chainEntity">The chain entity.</param>
        /// <param name="bulkPackages">The bulk packages.</param>
        /// <param name="childPackages">The child packages.</param>
        public ProcessingView(ProcessingStep step, User user, ExposureDocument exposureDocument, Package package,
                              ChainEntity chainEntity, IEnumerable<Package> bulkPackages,
                              IEnumerable<Package> childPackages, string wasteLinkDetail = "")
        {
            this.user = user;
            this.exposureDocument = exposureDocument;
            this.package = package;
            this.chainEntity = chainEntity;
            this.bulkPackages = bulkPackages;
            this.childPackages = childPackages;
            this.step = step;
            start = exposureDocument.DateOfPlacement;
            end = exposureDocument.DateOfRemoval;
            this.wasteLinkDetail = wasteLinkDetail;
        }
        

        /// <summary>
        /// Gets the start.
        /// </summary>
        /// <value>The start.</value>
        public DateTime Start
        {
            get { return start; }
        }

        /// <summary>
        /// Gets the end.
        /// </summary>
        /// <value>The end.</value>
        public DateTime End
        {
            get { return end; }
        }

        /// <summary>
        /// Gets the exposure document.
        /// </summary>
        /// <value>The exposure document.</value>
        public ExposureDocument ExposureDocument
        {
            get { return exposureDocument; }
        }

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <value>The user.</value>
        public User User
        {
            get { return user; }
        }

        /// <summary>
        /// Gets the step.
        /// </summary>
        /// <value>The step.</value>
        public ProcessingStep Step
        {
            get { return step; }
        }

        /// <summary>
        /// Gets the package.
        /// </summary>
        /// <value>The package.</value>
        public Package Package
        {
            get { return package; }
        }

        /// <summary>
        /// Gets the chain entity.
        /// </summary>
        /// <value>The chain entity.</value>
        public ChainEntity ChainEntity
        {
            get { return chainEntity; }
        }

        /// <summary>
        /// Gets the bulk packages.
        /// </summary>
        /// <value>The bulk packages.</value>
        public IEnumerable<Package> BulkPackages
        {
            get { return bulkPackages; }
        }

        /// <summary>
        /// Gets the child packages.
        /// </summary>
        /// <value>The child packages.</value>
        public IEnumerable<Package> ChildPackages
        {
            get { return childPackages; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string WasteLinkDetail
        {
            get { return wasteLinkDetail; }
            set { wasteLinkDetail = value; }
        }
    }
}