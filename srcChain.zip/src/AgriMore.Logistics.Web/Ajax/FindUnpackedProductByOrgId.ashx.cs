﻿namespace AgriMore.Logistics.Web.Ajax
{
    using System;
    using System.Linq;
    using System.Web;

    using AgriMore.Logistics.Data.Services;

    using Newtonsoft.Json;
    using System.Collections.Generic;
    using AgriMore.Logistics.Domain.ThirdPartyEntities;

    /// <summary>
    /// Summary description for FindOrganizationByName
    /// </summary>
    public class FindUnpackedProductByOrgId : IHttpHandler
    {

        /// <summary>
        /// Enables processing of HTTP Web requests by a custom HttpHandler that implements the <see cref="T:System.Web.IHttpHandler" /> interface.
        /// </summary>
        /// <param name="context">An <see cref="T:System.Web.HttpContext" /> object that provides references to the intrinsic server objects (for example, Request, Response, Session, and Server) used to service HTTP requests.</param>
        public void ProcessRequest(HttpContext context)
        {
            var responseFromServer = "";
            try
            {
                var orgId = (string)HttpContext.Current.Request["findText"];
                var currentOrgId = (string)HttpContext.Current.Request["currentOrgId"];

                //var result = "";
                List<OrganizationInfo> orgInfos = new List<OrganizationInfo>();
                IList<ProductSupply> lstUnpackedProducts = ProductServices.GetUnpackedProductByOrgIdList(currentOrgId + ";" + orgId).OrderByDescending(it => it.Uid).ToList();
                foreach (var it in lstUnpackedProducts)
                {
                    var data = "ID: " + it.Uid + " " + it.Product.Name + " - " + it.Amount + " " + it.UoM.Name;
                    var OrgInfo = new OrganizationInfo()
                    {
                        Uid = it.Uid.ToString(),
                        Name = data,
                        Amount = it.Amount,
                        UoMName = it.UoM.Name
                    };
                    orgInfos.Add(OrgInfo);
                }
                
                responseFromServer = JsonConvert.SerializeObject(orgInfos);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            context.Response.ContentType = "application/json";
            context.Response.Write(responseFromServer);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}