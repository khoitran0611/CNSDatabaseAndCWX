﻿namespace AgriMore.Logistics.Web.Ajax
{
    using System;
    using System.Linq;
    using System.Web;

    using AgriMore.Logistics.Data.Services;

    using Newtonsoft.Json;
    using System.Collections.Generic;
    using AgriMore.Logistics.Domain.ThirdPartyEntities;

    /// <summary>
    /// Summary description for FindOrganizationByName
    /// </summary>
    public class FindPackagesByOrgIds : IHttpHandler
    {

        /// <summary>
        /// Enables processing of HTTP Web requests by a custom HttpHandler that implements the <see cref="T:System.Web.IHttpHandler" /> interface.
        /// </summary>
        /// <param name="context">An <see cref="T:System.Web.HttpContext" /> object that provides references to the intrinsic server objects (for example, Request, Response, Session, and Server) used to service HTTP requests.</param>
        public void ProcessRequest(HttpContext context)
        {
            var responseFromServer = "";
            try
            {                
                var orgIds = (string)HttpContext.Current.Request["orgIds"];
                var action = (string)HttpContext.Current.Request["action"];

                var lstproductSupply = new List<ProductSupply>();
                if (orgIds.Length == 0)
                {
                    lstproductSupply = ProductServices.GetUnpackedProductList(RepositoryHelper.GetChainEntityForCurrentUser().Uid);
                }
                else
                {
                    lstproductSupply = ProductServices.GetPackedProductByOrgIds(orgIds);
                }               

                responseFromServer = JsonConvert.SerializeObject(lstproductSupply);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            context.Response.ContentType = "application/json";
            context.Response.Write(responseFromServer);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}