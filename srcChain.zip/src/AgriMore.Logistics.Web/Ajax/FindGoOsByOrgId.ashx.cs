﻿namespace AgriMore.Logistics.Web.Ajax
{
    using System;
    using System.Linq;
    using System.Web;

    using AgriMore.Logistics.Data.Services;

    using Newtonsoft.Json;

    /// <summary>
    /// Summary description for FindOrganizationByName
    /// </summary>
    public class FindGoOsByOrgId : IHttpHandler
    {

        /// <summary>
        /// Enables processing of HTTP Web requests by a custom HttpHandler that implements the <see cref="T:System.Web.IHttpHandler" /> interface.
        /// </summary>
        /// <param name="context">An <see cref="T:System.Web.HttpContext" /> object that provides references to the intrinsic server objects (for example, Request, Response, Session, and Server) used to service HTTP requests.</param>
        public void ProcessRequest(HttpContext context)
        {
            var responseFromServer = "";
            try
            {
                var findText = (string)HttpContext.Current.Request["findText"];
                var currentOrgId = (string)HttpContext.Current.Request["currentOrgId"];

                var responseObject = OrganizationServices.GetOrganizationByOrgId(findText + "," + currentOrgId);
                
                responseObject = responseObject.OrderBy(it => it.Name).ToList();
                responseFromServer = JsonConvert.SerializeObject(responseObject);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            context.Response.ContentType = "application/json";
            context.Response.Write(responseFromServer);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}