﻿namespace AgriMore.Logistics.Web.Ajax
{
    using System;
    using System.Linq;
    using System.Web;

    using AgriMore.Logistics.Data.Services;

    using Newtonsoft.Json;
    using System.Collections.Generic;
    using AgriMore.Logistics.Domain.ThirdPartyEntities;

    /// <summary>
    /// Summary description for FindOrganizationByName
    /// </summary>
    public class FindProductInfo : IHttpHandler
    {

        /// <summary>
        /// Enables processing of HTTP Web requests by a custom HttpHandler that implements the <see cref="T:System.Web.IHttpHandler" /> interface.
        /// </summary>
        /// <param name="context">An <see cref="T:System.Web.HttpContext" /> object that provides references to the intrinsic server objects (for example, Request, Response, Session, and Server) used to service HTTP requests.</param>
        public void ProcessRequest(HttpContext context)
        {
            var responseFromServer = "";
            try
            {
                var matchingProductId = (string)HttpContext.Current.Request["findText"];
                var producer = (string)HttpContext.Current.Request["producer"];
                var currentOrgId = (string)HttpContext.Current.Request["currentOrgId"];

                var lstproductSupply = new List<ProductSupply>();
                if (producer == string.Empty)
                {
                    lstproductSupply = ProductServices.GetUnpackedProductList(RepositoryHelper.GetChainEntityForCurrentUser().Uid);
                }
                else
                {
                    lstproductSupply = ProductServices.GetUnpackedProductByOrgIdList(currentOrgId.ToString() + ";" +  producer);
                }

                var productSupply =  lstproductSupply.Where(it => it.Uid.ToString() == matchingProductId).FirstOrDefault();
                Product product = lstproductSupply.Where(it => it.Uid.ToString() == matchingProductId).FirstOrDefault().Product;

                ProductInfo info = new ProductInfo()
                {
                    Amount = productSupply != null ? productSupply.Amount : 0,
                    UoMId = productSupply != null ? productSupply.UoM.Uid : 0,
                    UoMName = productSupply != null ? productSupply.UoM.Name : "",
                    Name = product.Name,
                    Uid = product.Uid.ToString()
                };
                
                responseFromServer = JsonConvert.SerializeObject(info);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            context.Response.ContentType = "application/json";
            context.Response.Write(responseFromServer);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}