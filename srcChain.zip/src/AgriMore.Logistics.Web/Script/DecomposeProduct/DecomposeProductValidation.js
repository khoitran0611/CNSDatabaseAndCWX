﻿/// <reference path="../jquery-1.11.1.min.js" />
function validateDecomposeProducts() {
    var isValid = true;
    var totalAmountDecomposed = 0;
    var errorArea = $("#errorArea");
    var errorMessageArea = $("#errorMessages");
    var quantityInvalidErrorMessage = quantityInvalid;
    var amountInvalidErrorMessage = amountInvalid;

    var errorMessage = totalDecomposeInvalid;

    var parentProductAmount = $("#" + lblProdAmountClientId).text().trim();
    parentProductAmount = parseInt(parentProductAmount);
    var currentQuantity = $("#tblDeComposeProduct tbody tr:nth-child(3) td input.inputQuantity").val().trim();
    var currentAmount = $("#tblDeComposeProduct tbody tr:nth-child(3) td input.inputAmount").val().trim();

    //Check that the input field for amount must be number
    $("#" + grdCmpProdClientId + " tbody tr td span.amount").each(function (e) {
        var amount = $(this).text().trim();
        if (amount != "" && !isNaN(amount)) {
            totalAmountDecomposed += parseInt(amount);
        }

        if (parseInt(amount) <= 0) {
            errorArea.show();
                if (isValid) {
                    errorMessageArea.empty();
                }

                errorMessageArea.append("<li class='ivldText'>" + amountInvalidErrorMessage + "</li>");                
                isValid = false;
        }
    });

    //Check that the input field for quantity must be number
    $("#" + grdCmpProdClientId + " tbody tr td span.quantity").each(function (e) {
        var quantity = $(this).text().trim();        
        if (parseInt(quantity) <= 0) {
            errorArea.show();
            if (isValid) {
                errorMessageArea.empty();
            }

            errorMessageArea.append("<li class='ivldText'>" + quantityInvalidErrorMessage + "</li>");            
            isValid = false;
        }
    });


    //Plus the current ammout to get the total
    //totalAmountDecomposed += currentAmount;    

    //Compare to make sure the total amout of the decomposed 
    //products <= the amout of the parent product
    if (parentProductAmount != totalAmountDecomposed) {        
        
        errorArea.show();
        if (isValid) {
            errorMessageArea.empty();
        }

        errorMessageArea.append("<li class='ivldText'>" + errorMessage + "</li>");
        //show the error textbox to user
        $("#tblDeComposeProduct tbody tr:nth-child(3) td input.amount").each(function (e) {
            $(this).addClass("input-validation-error");           
        });

        isValid = false;
    }

    return isValid;
}

function validateAmount() {
    var isValid = true;    
    var errorArea = $("#errorArea");
    var errorMessageArea = $("#errorMessages");    
    var quantityInvalidErrorMessage = quantityInvalid;
    var amountInvalidErrorMessage = amountInvalid;

    $("#tblDeComposeProduct tbody tr:nth-child(3) td input.inputAmount").each(function () {
        var amount = $(this).val();

        if (amount == "" || (amount != "" && isNaN(amount.trim())) || parseInt(amount.trim()) <= 0) {
            errorArea.show();
            if (isValid) {
                errorMessageArea.empty();
            }

            errorMessageArea.append("<li class='ivldText'>" + amountInvalidErrorMessage + "</li>");            
            isValid = false;
        }            
    });

    $("#tblDeComposeProduct tbody tr:nth-child(3) td input.inputQuantity").each(function () {
        var quantity = $(this).val();

        if ((quantity != "" && isNaN(quantity.trim())) || parseInt(quantity.trim()) <= 0) {
            errorArea.show();
            if (isValid) {
                errorMessageArea.empty();
            }

            errorMessageArea.append("<li class='ivldText'>" + quantityInvalidErrorMessage + "</li>");
            isValid = false;
        }
    });

    return isValid;
}