﻿/// <reference path="../jquery-1.11.1.min.js" />
var splitCondition = false;
function splitPackage(txtIdtSplitClientId, listBoxPackagesClientId, lbtSplitClientId,
    lblSplitInfoMsgClientId, selectPackageWarning, packageValueNotValidWarning,
    andLabel, splitConfirmWaring, packageLabel) {

    $('#' + txtIdtSplitClientId).blur(function () {
        var splitVals = $(this).val();
        var nPackage = $('#' + listBoxPackagesClientId + ' option:selected').attr('data-npackage');

        if (typeof (nPackage) == "undefined") {
            $(this).val('');
            $('#' + lbtSplitClientId).hide();
            $('#' + lblSplitInfoMsgClientId).html(selectPackageWarning);
            $('#' + lblSplitInfoMsgClientId).addClass("ivldText").removeClass("infoText");            
            return;
        }
        $('#' + lblSplitInfoMsgClientId).html("");
        var infoMsg = '';
        var totalPackage = 0;
        splitVals = splitVals.split(',');
        if ($('#' + txtIdtSplitClientId).val() != "" && splitVals.length > 0) {
            for (var idx = 0; idx < splitVals.length; idx++) {
                if (isNaN(splitVals[idx]) || splitVals[idx].trim() == "" || !isPositiveInteger(splitVals[idx])) {
                    $('#' + lbtSplitClientId).hide();
                    $('#' + lblSplitInfoMsgClientId).html(packageValueNotValidWarning);
                    $('#' + lblSplitInfoMsgClientId).addClass("ivldText").removeClass("infoText");
                    return;
                }

                totalPackage += parseInt(splitVals[idx]);
            }
        }

        if (totalPackage > nPackage) {
            $('#' + lbtSplitClientId).hide();
            $('#' + lblSplitInfoMsgClientId).html(packageValueNotValidWarning);
            $('#' + lblSplitInfoMsgClientId).addClass("ivldText").removeClass("infoText");

            return;
        }

        if (totalPackage < nPackage) {
            infoMsg = splitVals.join(' , ') + ' ' + 'and' + ' ' + (nPackage - totalPackage) + ' ';
            splitCondition = true;
        } else {
            var firstArray = splitVals.slice(0, splitVals.length - 1);
            infoMsg = firstArray.join(' , ') + ' ' + 'and' + ' ' + splitVals[splitVals.length - 1] + ' ';
            splitCondition = true;
        }

        if ($('#' + txtIdtSplitClientId).val() != "" && nPackage > 0 && totalPackage <= nPackage) {
            $('#' + lblSplitInfoMsgClientId).html(splitConfirmWaring + infoMsg + packageLabel);
            $('#' + lblSplitInfoMsgClientId).addClass("infoText").removeClass("ivldText");
            $('#' + lbtSplitClientId).show();
            splitCondition = true;
        }

        if ($('#' + txtIdtSplitClientId).val() == "") {
            $('#' + lbtSplitClientId).hide();
        }
    });    
}

function countSelectedItems(txtIdtSplitClientId, lbtSplitClientId, lblExampleClientId, lblTotalSelectedClientId) {       
    var count = 0;
    var textShow = "Selected: # packages";//Use resource later
    var selectedLength = $('#' + listBoxPackagesClientId + ' :selected').length;

    for (var idx = 0; idx < selectedLength; idx++) {
        count += parseInt($($('#' + listBoxPackagesClientId + ' :selected')[idx]).attr('data-npackage'));
    }

    var totalSel = count;
    
    var textShow = textShow.replace('#', totalSel);

    $('#' + lblTotalSelectedClientId).html(textShow);

    //Don't allow to split if the user select more than one item on the package list box
    if (selectedLength != 1 || totalSel == 1) {
        $('#' + txtIdtSplitClientId).val('');
        $('#' + txtIdtSplitClientId).hide();
        $('#' + lbtSplitClientId).hide();
        $('#' + lblExampleClientId).hide();
    } else {
        $('#' + lblExampleClientId).show();
        $('#' + txtIdtSplitClientId).show();
        if ($('#' + txtIdtSplitClientId).val() != '' && splitCondition)
            $('#' + lbtSplitClientId).show();
    }
}

function isPositiveInteger(str) {
    return /^\+?(0|[1-9]\d*)$/.test(str);
}