using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public partial class DocumentExposures : UserControl
    {
        private readonly RepositoryFactory repositoryFactory=new RepositoryFactory();

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                FillInDropDown();
            }
            else
            {
                Page.Validate();
            }
        }

        /// <summary>
        /// Fills the in drop down.
        /// </summary>
        public void FillInDropDown()
        {
            DropDownListLocations.Items.Clear();

            ChainEntity chainEntity = ChainEntityHelper.GetChainEntityThroughUser(Page.User);

            foreach (Location location in chainEntity.Locations)
            {
                DropDownListLocations.Items.Add(new ListItem(location.Name, location.Uid.ToString()));
            }
        }

        /// <summary>
        /// Gets the location.
        /// </summary>
        /// <returns></returns>
        private Location GetLocation()
        {
            Location location =
                repositoryFactory.GetLocationRepository().GetOne(long.Parse(DropDownListLocations.SelectedValue));

            return location;
        }

        /// <summary>
        /// Adds the measurements to location.
        /// </summary>
        public void AddMeasurementsToLocation(string remarks)
        {
            TransactionManager transactionManager = new TransactionManager();

            try
            {
                transactionManager.BeginTransaction();

                Location location = GetLocation();
                
                IDictionary<ExposureType, MeasuredValue> measuredValues = ExposuresControl.GetMeasurements();                

                foreach (ExposureType exposureType in measuredValues.Keys)
                {
                    location.DocumentActualValue(measuredValues[exposureType], exposureType);
                }                

                repositoryFactory.GetLocationRepository().Store(location);
                
                if (remarks == null || remarks.Trim().Length == 0)
                {
                    remarks = CreateVpsRemark();
                }

                User user = RepositoryHelper.GetCurrentUser();

                IRepository<Package> packageRepository = repositoryFactory.GetPackageRepository();

                foreach (Package package in location.Packages)
                {
                    packageRepository.Store(package);
                }

                packageRepository.Flush();

                foreach (Package package in location.Packages)
                {
                    RepositoryHelper.CreateProcessingSteps(package, package.CurrentExposureDocument, ProcessingStepType.Documented, user, remarks);
                }
                

                transactionManager.CommitTransaction();
                
            }
            catch (Exception exception)
            {
                ErrorHelper.HandleException(exception, transactionManager);
            }
        }

        /// <summary>
        /// Creates the VPS remark.
        /// </summary>
        /// <returns></returns>
        private static string CreateVpsRemark()
        {
            return String.Format(ProcessingStepDocument.Documented, DateTime.Now.ToString(ProcessingStepDocument.DateTimeFormat));
        }
    }
}