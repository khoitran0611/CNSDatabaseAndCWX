using System;
using System.Collections.Generic;
using System.Web.UI;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PickupDetail : BasePage
    {
        private string invalidShipperLocation = Resources.Localization.Invalidshipperlocation;
        private string invalidForwarderLocation = Resources.Localization.Invalidforwarderlocation;
        private const string shipmentid = "shipmentid";
        private const string uid = "Uid";
        private const string name = "Name";
        private readonly string urlPickupList = "PickupList.aspx";
        private IRepository<Location> locationRepository;
        private bool isShipmentAvailable;
        private bool isPickupLocationAvailable;
        private bool isExposureDocumentAvailable;
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            locationRepository = repositoryFactory.GetLocationRepository();

            if (!IsPostBack)
            {
                SetInitialValues();
            }
            else
            {
                Validate();
            }
        }


        /// <summary>
        /// Sets the initial values.
        /// </summary>
        private void SetInitialValues()
        {
            LabelError.Visible = false;

            Shipment shipment = GetShipment();

            if (shipment != null)
            {
                if (shipment.ArePackagesInPickupLocation())
                {
                    BindShipperLocations(shipment);
                    BindForwarderLocations(shipment);
                    LoadShipmentExposure(shipment);
                    BindPackages(shipment);
                }
                else
                {
                    Response.Redirect(urlPickupList, false);
                }
            }
        }

        /// <summary>
        /// Binds the packages.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        private void BindPackages(Shipment shipment)
        {
            ShowPackagesControl.SetPackages(shipment.Packages);
        }

        /// <summary>
        /// Loads the shipment exposure.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        private void LoadShipmentExposure(Shipment shipment)
        {
            if (shipment.ShipmentExposures.Count == 0)
            {
                ExposuresControl.Visible = false;
                ExposureHeader.Visible = false;
            }

            foreach (ShipmentExposure shipmentExposure in shipment.ShipmentExposures)
            {
                ExposuresControl.PreFillExposureValues(false, shipmentExposure.PrescribedStartValue,
                                                       shipmentExposure.PrescribedEndValue,
                                                       shipmentExposure.DocumentedValue, shipmentExposure.ExposureType);
            }
        }

        /// <summary>
        /// Binds the forwarder locations.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        private void BindForwarderLocations(Shipment shipment)
        {
            DropDownListForwarderPickupLocation.DataSource = GetForwarderLocations(shipment);
            DropDownListForwarderPickupLocation.DataValueField = uid;
            DropDownListForwarderPickupLocation.DataTextField = name;
            DropDownListForwarderPickupLocation.DataBind();
        }

        /// <summary>
        /// Gets the forwarder locations.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        /// <returns></returns>
        private static List<Location> GetForwarderLocations(Shipment shipment)
        {
            List<Location> forwarderLocations = new List<Location>();
            foreach (Address address in shipment.Forwarder.Addresses)
            {
                forwarderLocations.AddRange(address.Locations);
            }
            return forwarderLocations;
        }

        /// <summary>
        /// Binds the shipper locations.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        private void BindShipperLocations(Shipment shipment)
        {
            DropDownListShipperPickupLocation.DataSource = GetShipperLocations(shipment);
            DropDownListShipperPickupLocation.DataValueField = uid;
            DropDownListShipperPickupLocation.DataTextField = name;
            DropDownListShipperPickupLocation.SelectedValue = shipment.PickupLocation.Uid.ToString();
            DropDownListShipperPickupLocation.DataBind();
        }

        /// <summary>
        /// Gets the shipper locations.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        /// <returns></returns>
        private static IList<Location> GetShipperLocations(Shipment shipment)
        {
            IList<Location> shipperLocations = new List<Location>();

            foreach (Address address in shipment.Shipper.Addresses)
            {
                foreach (Location location in address.Locations)
                {
                    if (location == shipment.PickupLocation)
                    {
                        foreach (Location shipperLocation in address.Locations)
                        {
                            shipperLocations.Add(shipperLocation);
                        }
                    }
                }
            }
            return shipperLocations;
        }

        /// <summary>
        /// Gets the shipment.
        /// </summary>
        /// <returns></returns>
        public Shipment GetShipment()
        {
            IRepository<Shipment> memoryShipmentRepository = repositoryFactory.GetShipmentRepository();

            string shipmentid = Session[PickupDetail.shipmentid] as string;

            Shipment shipment = null;

            if (memoryShipmentRepository != null && !String.IsNullOrEmpty(shipmentid))
            {
                shipment = memoryShipmentRepository.GetOne(long.Parse(shipmentid));
            }
            return shipment;
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonOK control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonOK_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                if (DropDownListForwarderPickupLocation.SelectedValue == string.Empty)
                {
                    SetErrorMessage(invalidForwarderLocation);
                    return;
                }

                if (DropDownListShipperPickupLocation.SelectedValue == string.Empty)
                {
                    SetErrorMessage(invalidShipperLocation);
                    return;
                }

                ChainEntity chainEntity = ChainEntityHelper.GetChainEntityThroughUser(Page.User);

                Location forwarderLocation = GetSelectedForwarderPickupLocation();
                Location realPickupLocation = GetSelectedShipperPickupLocation();

                TransportEquipment transportEquipment = new TransportEquipment(chainEntity, forwarderLocation);

                Shipment shipment = GetShipment();

                DateTime pickupDateTime = PickUpDateTime.GetDatetime();


                isShipmentAvailable = shipment != null;
                isPickupLocationAvailable = realPickupLocation != null;
                isExposureDocumentAvailable = ExposuresControl.GetExposureDocument() != null;

                if (isShipmentAvailable && isPickupLocationAvailable && isExposureDocumentAvailable)
                {
                    TransactionManager transactionManager = new TransactionManager();
                    try
                    {
                        transactionManager.BeginTransaction();


                        transportEquipment.Pickup(shipment, pickupDateTime, realPickupLocation,
                                                  ExposuresControl.GetExposureDocument());

                        User user = RepositoryHelper.GetCurrentUser();

                        IRepository<Package> packageRepository = repositoryFactory.GetPackageRepository();

                        foreach (Package package in shipment.Packages)
                        {
                            ShowPackagesControl.AddIdentificationToPackage(package);
                            packageRepository.Store(package);
                        }

                        repositoryFactory.GetTransportEquipmentRepository().Store(transportEquipment);

                        packageRepository.Flush();

                        foreach (Package package in shipment.Packages)
                        {
                            string remark = String.Format(ProcessingStepDocument.PickUp, DateTime.Now.ToString(ProcessingStepDocument.DateTimeFormat), shipment.Shipper.Name);
                            RepositoryHelper.CreateProcessingSteps(package, package.CurrentExposureDocument, ProcessingStepType.Move, user, remark);
                        }


                        transactionManager.CommitTransaction();

                        Response.Redirect(urlPickupList, false);
                    }
                    catch (ArgumentNullException ane)
                    {
                        DomainValidator.IsValid = false;
                        DomainValidator.ErrorMessage = ane.Message;
                    }
                    catch (ArgumentException ae)
                    {
                        DomainValidator.IsValid = false;
                        DomainValidator.ErrorMessage = ae.Message;
                    }
                    catch (Exception exception)
                    {
                        ErrorHelper.HandleException(exception, transactionManager, LabelError);
                    }
                }
                else
                {
                    SetErrorMessage(Resources.Localization.ShipmentPickuplocationorExposuredocumentisempty);
                }
            }
        }

        /// <summary>
        /// Sets the error message.
        /// </summary>
        /// <param name="message">The message.</param>
        private
            void SetErrorMessage(string message)
        {
            LabelError.Visible = true;
            LabelError.Text = message;
        }

        /// <summary>
        /// Gets the selected location.
        /// </summary>
        /// <returns></returns>
        private
            Location GetSelectedShipperPickupLocation()
        {
            return locationRepository.GetOne(long.Parse(DropDownListShipperPickupLocation.SelectedValue));
        }

        /// <summary>
        /// Gets the selected location.
        /// </summary>
        /// <returns></returns>
        private
            Location GetSelectedForwarderPickupLocation()
        {
            return locationRepository.GetOne(long.Parse(DropDownListForwarderPickupLocation.SelectedValue));
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected
            void LinkButtonCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(urlPickupList, false);
        }
    }
}