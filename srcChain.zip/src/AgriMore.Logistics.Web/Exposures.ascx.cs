using System;
using System.Collections.Generic;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Data.Services;

namespace AgriMore.Logistics.Web
{
    public partial class Exposures : UserControl
    {
        private readonly Dictionary<ExposureType, string[]> preValues = new Dictionary<ExposureType, string[]>();
        private readonly Dictionary<ExposureDefine, string[]> preValuesWithExposureDefine = new Dictionary<ExposureDefine, string[]>();
        private double defaultDocumentedValue = 0;
        private bool defaultDocumentedvalueIsSet = false;
        private bool documentedIsReadonly = false;
        private IRepository<ExposureType> exposureTypesRespository;
        private IList<ExposureView> exposureViews = new List<ExposureView>();
        private bool rangeIsReadonly = false;
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();


        /// <summary>
        /// Gets or sets a value indicating whether [show date control].
        /// </summary>
        /// <value><c>true</c> if [show date control]; otherwise, <c>false</c>.</value>
        public bool ShowDateControl
        {
            get { return DateTimeControl1.Visible; }
            set { DateTimeControl1.Visible = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [range is readonly].
        /// </summary>
        /// <value><c>true</c> if [range is readonly]; otherwise, <c>false</c>.</value>
        public bool RangeIsReadonly
        {
            get { return rangeIsReadonly; }
            set { rangeIsReadonly = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [documented is readonly].
        /// </summary>
        /// <value>
        /// 	<c>true</c> if [documented is readonly]; otherwise, <c>false</c>.
        /// </value>
        public bool DocumentedIsReadonly
        {
            get { return documentedIsReadonly; }
            set { documentedIsReadonly = value; }
        }

        /// <summary>
        /// Gets or sets the default documented value.
        /// </summary>
        /// <value>The default documented value.</value>
        public double DefaultDocumentedValue
        {
            get { return defaultDocumentedValue; }
            set
            {
                defaultDocumentedValue = value;
                defaultDocumentedvalueIsSet = true;
            }
        }

        /// <summary>
        /// Gets or sets the name of the date.
        /// </summary>
        /// <value>The name of the date.</value>
        public string HeaderDate
        {
            get { return DateTimeControl1.HeaderDate; }
            set { DateTimeControl1.HeaderDate = value; }
        }

        /// <summary>
        /// Gets or sets the name of the time.
        /// </summary>
        /// <value>The name of the time.</value>
        public string HeaderTime
        {
            get { return DateTimeControl1.HeaderTime; }
            set { DateTimeControl1.HeaderTime = value; }
        }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            exposureTypesRespository = repositoryFactory.GetExposureTypeRepository();

            if (!IsPostBack)
            {
                DateTimeControl1.SetStartDateTime(DateTime.Now);
                FillExposureViews();                
            }
            //else
            //{
            //    Page.Validate();
            //}
        }

        private void FillExposureViews()
        {
            exposureTypesRespository = repositoryFactory.GetExposureTypeRepository();
            exposureViews = new List<ExposureView>();
            foreach (ExposureType exposureType in exposureTypesRespository.AsCollection())
            {
                if (preValues.Count > 0)
                {
                    foreach (ExposureType key in preValues.Keys)
                    {
                        if (key.Equals(exposureType))
                        {
                            exposureViews.Add(
                                new ExposureView(preValues[key][0].ToString(), preValues[key][1].ToString(),
                                                 preValues[key][2].ToString(),
                                                 exposureType));
                        }
                    }
                }
                else
                {
                    exposureViews.Add(new ExposureView(null, exposureType, true));
                }
            }

            GridViewExposures.DataSource = exposureViews;
            GridViewExposures.RowDataBound += GridViewExposures_RowDataBound;

            GridViewExposures.DataBind();
        }        

        /// <summary>
        /// Handles the RowDataBound event of the GridViewExposures control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewRowEventArgs"/> instance containing the event data.</param>
        private void GridViewExposures_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                TextBox prescibedFromValue = (TextBox) e.Row.FindControl("TextBoxPrescibedFromValue");
                TextBox prescibedToValue = (TextBox) e.Row.FindControl("TextBoxPrescibedToValue");
                TextBox documentedValue = (TextBox) e.Row.FindControl("TextBoxDocumentedValue");

                if (RangeIsReadonly)
                {
                    prescibedFromValue.Attributes.Add("readonly", "readonly");
                    prescibedToValue.Attributes.Add("readonly", "readonly");

                    prescibedFromValue.Enabled = false;
                    prescibedToValue.Enabled = false;
                }
                else
                {
                    prescibedFromValue.Attributes.Remove("readonly");
                    prescibedToValue.Attributes.Remove("readonly");

                    prescibedFromValue.Enabled = true;
                    prescibedToValue.Enabled = true;
                }

                if (DocumentedIsReadonly)
                {
                    documentedValue.Attributes.Add("readonly", "readonly");
                    documentedValue.Enabled = false;
                }
                else
                {
                    documentedValue.Attributes.Remove("readonly");
                    documentedValue.Enabled = true;
                }
            }
        }

        private void grdExposureDefines_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                TextBox prescibedFromValue = (TextBox)e.Row.FindControl("TextBoxPrescibedFromValueExposureDefine");
                TextBox prescibedToValue = (TextBox)e.Row.FindControl("TextBoxPrescibedToValueExposureDefine");
                TextBox documentedValue = (TextBox)e.Row.FindControl("TextBoxDocumentedValueExposureDefine");

                if (RangeIsReadonly)
                {
                    prescibedFromValue.Attributes.Add("readonly", "readonly");
                    prescibedToValue.Attributes.Add("readonly", "readonly");

                    prescibedFromValue.Enabled = false;
                    prescibedToValue.Enabled = false;
                }
                else
                {
                    prescibedFromValue.Attributes.Remove("readonly");
                    prescibedToValue.Attributes.Remove("readonly");

                    prescibedFromValue.Enabled = true;
                    prescibedToValue.Enabled = true;
                }

                if (DocumentedIsReadonly)
                {
                    documentedValue.Attributes.Add("readonly", "readonly");
                    documentedValue.Enabled = false;
                }
                else
                {
                    documentedValue.Attributes.Remove("readonly");
                    documentedValue.Enabled = true;
                }
            }
        }


        /// <summary>
        /// Custom validator for check box.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="args">The <see cref="System.Web.UI.WebControls.ServerValidateEventArgs"/> instance containing the event data.</param>
        protected void CustomValidator_ServerValidate(object sender, ServerValidateEventArgs args)
        {
            CustomValidator custom = sender as CustomValidator;
            GridViewRow gridViewRow = custom.NamingContainer as GridViewRow;

            TextBox prescibedFromValue = (TextBox) gridViewRow.FindControl("TextBoxPrescibedFromValue");
            TextBox prescibedToValue = (TextBox) gridViewRow.FindControl("TextBoxPrescibedToValue");
            TextBox documentedValue = (TextBox) gridViewRow.FindControl("TextBoxDocumentedValue");
            HiddenField canCreateExposure = (HiddenField) gridViewRow.FindControl("HiddenFieldCanCreateExposure");

            if (string.IsNullOrEmpty(prescibedFromValue.Text) &&
                string.IsNullOrEmpty(prescibedToValue.Text) &&
                string.IsNullOrEmpty(documentedValue.Text))
            {
                args.IsValid = true;
            }
            else
            {
                double from ;
                double to;
                double doc;

                string preStartValue = prescibedFromValue.Text;
                string preEndValue = prescibedToValue.Text;
                string docValue = documentedValue.Text;

                if (defaultDocumentedvalueIsSet)
                {
                    if (String.IsNullOrEmpty(docValue.Trim()))
                    {
                        documentedValue.Text = DefaultDocumentedValue.ToString();
                    }
                }

                if (double.TryParse(preStartValue, out from) &&
                    double.TryParse(preEndValue, out to) &&
                    double.TryParse(docValue, out doc))
                {
                    if (from > to)
                    {
                        args.IsValid = false;
                        custom.ErrorMessage = "prescibed start value must be lower than end value";
                    }
                    else
                    {
                        args.IsValid = true;
                        canCreateExposure.Value = "1";
                    }
                }
                else
                {
                    args.IsValid = false;
                    custom.ErrorMessage = "All fields must be filled with numeric values";
                }
            }
        }


        protected void CustomValidator1_ServerValidate(object sender, ServerValidateEventArgs args)
        {
            CustomValidator custom = sender as CustomValidator;
            GridViewRow gridViewRow = custom.NamingContainer as GridViewRow;

            TextBox prescibedFromValue = (TextBox)gridViewRow.FindControl("TextBoxPrescibedFromValueExposureDefine");
            TextBox prescibedToValue = (TextBox)gridViewRow.FindControl("TextBoxPrescibedToValueExposureDefine");
            TextBox documentedValue = (TextBox)gridViewRow.FindControl("TextBoxDocumentedValueExposureDefine");
            HiddenField canCreateExposure = (HiddenField)gridViewRow.FindControl("HiddenFieldCanCreateExposureDefine");

            if (string.IsNullOrEmpty(prescibedFromValue.Text) &&
                string.IsNullOrEmpty(prescibedToValue.Text) &&
                string.IsNullOrEmpty(documentedValue.Text))
            {
                args.IsValid = true;
            }
            else
            {
                double from;
                double to;
                double doc;

                string preStartValue = prescibedFromValue.Text;
                string preEndValue = prescibedToValue.Text;
                string docValue = documentedValue.Text;

                if (defaultDocumentedvalueIsSet)
                {
                    if (String.IsNullOrEmpty(docValue.Trim()))
                    {
                        documentedValue.Text = DefaultDocumentedValue.ToString();
                    }
                }

                if (double.TryParse(preStartValue, out from) &&
                    double.TryParse(preEndValue, out to) &&
                    double.TryParse(docValue, out doc))
                {
                    if (from > to)
                    {
                        args.IsValid = false;
                        custom.ErrorMessage = "prescibed start value must be lower than end value";
                    }
                    else
                    {
                        args.IsValid = true;
                        canCreateExposure.Value = "1";
                    }
                }
                else
                {
                    args.IsValid = false;
                    custom.ErrorMessage = "All fields must be filled with numeric values";
                }
            }
        }

        private Dictionary<long, ExposureType> exposureTypes = new Dictionary<long, ExposureType>();
        private Dictionary<long, ExposureDefine> exposureDefines = new Dictionary<long, ExposureDefine>();

        private ExposureType GetExposureType(long key)
        {
            if (!exposureTypes.ContainsKey(key))
            {
                exposureTypesRespository = repositoryFactory.GetExposureTypeRepository();
                ExposureType exposureType = exposureTypesRespository.GetOne(key);
                exposureTypes.Add(key, exposureType);
            }
            return exposureTypes[key];
        }

        private ExposureDefine GetExposureDefine(long key)
        {
            if (!exposureDefines.ContainsKey(key))
            {                
                ExposureDefine exposureDefine =  ProductServices.GetExposureDefineById(key);
                exposureDefines.Add(key, exposureDefine);
            }
            return exposureDefines[key];
        }



        /// <summary>
        /// Gets the exposures.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Exposure> GetExposureDocument() //Package package)
        {
            IList<Exposure> filledExposures = new List<Exposure>();

            if (Page.IsValid)
            {
                CultureInfo MyCultureInfo = new CultureInfo("en-GB");

                foreach (GridViewRow row in GridViewExposures.Rows)
                {
                    TextBox prescibedFromValue = (TextBox) row.FindControl("TextBoxPrescibedFromValue");
                    TextBox prescibedToValue = (TextBox) row.FindControl("TextBoxPrescibedToValue");
                    TextBox documentedValue = (TextBox) row.FindControl("TextBoxDocumentedValue");
                    HiddenField exposureTypeId = (HiddenField) row.FindControl("ExposureTypeId");
                    HiddenField canCreateExposure = (HiddenField) row.FindControl("HiddenFieldCanCreateExposure");

                    if (canCreateExposure.Value == "1")
                    {
                        ExposureType exposureType = GetExposureType(long.Parse(exposureTypeId.Value));

                        DateTime datetimePrescibed = DateTimeControl1.GetDatetime();

                        MeasuredValue fromMeasurement =
                            new MeasuredValue(double.Parse(prescibedFromValue.Text, MyCultureInfo), datetimePrescibed);
                        MeasuredValue toMeasurement =
                            new MeasuredValue(double.Parse(prescibedToValue.Text, MyCultureInfo), datetimePrescibed);
                        MeasuredValue documented =
                            new MeasuredValue(double.Parse(documentedValue.Text, MyCultureInfo), datetimePrescibed);
                        IList<MeasuredValue> list = new List<MeasuredValue>();
                        list.Add(documented);

                        IRange<MeasuredValue> prescribed = new Range<MeasuredValue>(fromMeasurement, toMeasurement);


                        Exposure exposure = new Exposure(prescribed, list, exposureType);

                        filledExposures.Add(exposure);
                    }
                }                
            }

            return filledExposures; 
        }


        /// <summary>
        /// Pres the fill exposure values.
        /// </summary>
        /// <param name="showAllExposureTypes">if set to <c>true</c> [show all exposure types].</param>
        /// <param name="preStartValue">The pre start value.</param>
        /// <param name="preEndValue">The pre end value.</param>
        /// <param name="docValue">The doc value.</param>
        /// <param name="exposureType">Type of the exposure.</param>
        public void PreFillExposureValues(bool showAllExposureTypes, double preStartValue, double preEndValue,
                                          double docValue, ExposureType exposureType)
        {
            if (showAllExposureTypes)
            {
                foreach (ExposureType exposureType2 in exposureTypesRespository.AsCollection())
                {
                    if (!preValues.ContainsKey(exposureType2))
                    {
                        preValues.Add(exposureType2, new string[3] {string.Empty, string.Empty, string.Empty});
                    }
                }
            }
            if (preValues.ContainsKey(exposureType))
            {
                preValues[exposureType] =
                    new string[3] {preStartValue.ToString(), preEndValue.ToString(), docValue.ToString()};
            }
            else
            {
                preValues.Add(exposureType,
                              new string[3] {preStartValue.ToString(), preEndValue.ToString(), docValue.ToString()});
            }

            FillExposureViews();
        }        
    }
}