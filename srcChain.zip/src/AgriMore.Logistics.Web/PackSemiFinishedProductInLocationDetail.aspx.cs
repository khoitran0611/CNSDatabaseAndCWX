using System;
using System.Collections.Generic;
using System.Web.UI;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Repository.Memory;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// This class makes it possible to pack a package instead of packing a primary product. When a existing package is packed
    /// the former package is removed from the repository.
    /// </summary>
    public partial class PackPackageDetail : Page
    {
        private const string dataTextField = "Name";
        private const string invalidinputtext = "There is an invalid item.";
        private const string packageRepository = "MemoryPackageRepository";
        private const string urlPackPackageList = "PackPackageList.aspx";
        private const string id = "Id";
        private const string packageid = "packageId";
        private IRepository<Package> repository;

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetPackageRepositoryFromSession();

                string packageId = Request[packageid];

                if (packageId != null)
                {
                    Package p;
                    List<Package> list=new List<Package>();
                    p = repository.GetOne(Request[packageid]);

                    GetPackage(p,list);
                    list.Add(p);

                    GridView1.DataSource = list;
                    GridView1.DataBind();
                }

                LabelError.Visible = false;

                BindPackageTypes();
            }
        }

        /// <summary>
        /// Gets the package.
        /// </summary>
        /// <param name="p">The p.</param>
        /// <param name="list">The list.</param>
        private static void GetPackage(Package p,ICollection<Package> list)
        {
            foreach (Package childPackage in p.Children)
            {
                list.Add(childPackage);
                GetPackage(childPackage, list);
            }
        }

        /// <summary>
        /// Gets the package repository from session.
        /// </summary>
        /// <returns></returns>
        private void GetPackageRepositoryFromSession()
        {
            repository = Session[packageRepository] as MemoryPackageRepository;

            if (repository == null)
            {
                throw new NotImplementedException();
            }
        }


        /// <summary>
        /// Handles the Click event of the LinkButtonCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(urlPackPackageList);
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonOK control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonOK_Click(object sender, EventArgs e)
        {
            bool error = false;

            GetPackageRepositoryFromSession();

            ClearErrorLabel();

            DateTime dateTimeOfPacking = CalendarPackingDateTime.SelectedDate;

            try
            {
                Location location = new Location("1", "mylocation", new Address("street", "postal", "city", "country", "ChainEntity 1"));
                IChainEntity chainEntity = new ChainEntity("testname",  location);
                ICollection<Identification> identifications1 = new List<Identification>();
                Identification identification = new Identification(TextBoxPackageIdentification.Text, chainEntity);
                identifications1.Add(identification);
                IRepository<PackageType> memoryPackageTypeRepository = new MemoryMapRepository<PackageType>();

                PackageType packageType = memoryPackageTypeRepository.GetOne(DropDownListPackageType.Text);

                string packageId = Request[packageid];
                Package package=null;
                Package newPackage = null;

                if (packageId != null)
                {
                     package = repository.GetOne(Request[packageid]);
                }

                if (package != null)
                {
                    newPackage=package.Pack(packageType, dateTimeOfPacking, identifications1);
                }

                repository.Add(newPackage);
            }
            catch (Exception)
            {
                error = true;
                LabelError.Visible = error;
                LabelError.Text = invalidinputtext;
            }

            if (!error)
            {
                Response.Redirect(urlPackPackageList);
            }
        }

        /// <summary>
        /// Clears the error label.
        /// </summary>
        private void ClearErrorLabel()
        {
            LabelError.Text = string.Empty;
        }

        /// <summary>
        /// Handles the Click event of the LinkButtonBack control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonBack_Click(object sender, EventArgs e)
        {
            Response.Redirect(urlPackPackageList);
        }

        /// <summary>
        /// Binds the package types.
        /// </summary>
        private void BindPackageTypes()
        {
            IRepository<PackageType> memoryPackageTypeRepository = new MemoryMapRepository<PackageType>();
			RepositoryFactory ra=new RepositoryFactory();
        	ra.CreateRepository<PackageType>();

			DropDownListPackageType.DataSource = memoryPackageTypeRepository;
            DropDownListPackageType.DataTextField = dataTextField;
            DropDownListPackageType.DataValueField = id;
            DropDownListPackageType.DataBind();
        }
    }
}