﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Web
{
    public partial class ChartItem : System.Web.UI.UserControl
    {
        public int ChartIndex { get; set; }
        public string Language { get; set; }
        public string ChartTitle { get; set; }

        public DateTime EndDate { get; set; }
        public DateTime StartDate { get; set; }

        public IList<ListItem> OrgListItems { get; set; }
        public IDictionary<string, IDictionary<DateTime, IList<DecompositionInfo>>> ChartData { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            wasteStreamChart.Titles[0].Text = ChartTitle;
            wasteStreamChart.ChartAreas[0].AxisX.Title = "Date";
            wasteStreamChart.ChartAreas[0].AxisY.Title = "Ton";

            DrawChart(ChartData);
        }

        private void DrawChart(IDictionary<string, IDictionary<DateTime, IList<DecompositionInfo>>> chartData)
        {
            var lstVisibleOrgIds = new List<string>();
            foreach (var key in chartData.Keys)
            {
                var serieChart = chartData[key];
                foreach (var date in serieChart.Keys)
                    lstVisibleOrgIds.AddRange(serieChart[date].Where(it => !lstVisibleOrgIds.Contains(it.KeyFigure4OrgId)).Select(it => it.KeyFigure4OrgId).ToArray());
            }

            foreach (var key in chartData.Keys)
            {
                foreach (var orgId in lstVisibleOrgIds)
                {
                    var serieName = key;
                    var item = OrgListItems.SingleOrDefault(it => it.Value.Equals(orgId));
                    var series = GenerateDefaultSeries(string.Format("{0} - {1}", item.Text, serieName));//GenerateDefaultSeries(serieName);
                    series["StackedGroupName"] = serieName;

                    var serieChart = chartData[key];
                    foreach (var date in serieChart.Keys)
                    {
                        var dp = new DataPoint();
                        var xAxisVal = (date - StartDate).Days;
                        var lstDcmInfo = serieChart[date].Where(it => it.KeyFigure4OrgId.Equals(item.Value)).ToList();
                        decimal valTotal = lstDcmInfo.Sum(info => (info.ActualWeight > 0 ? info.ActualWeight : info.FigureWeight));

                        dp.SetValueXY(xAxisVal, valTotal);
                        dp.AxisLabel = date.ToString("dd/MMM\nyyyy");
                        series.Points.Add(dp);
                    }
                    wasteStreamChart.Series.Add(series);
                }

                //for (int i = 1; i <= 3; i++)
                //{
                //    var serieName = key;
                //    var series = GenerateDefaultSeries(string.Format("{0} {1}", serieName, i));//GenerateDefaultSeries(serieName);
                //    series["StackedGroupName"] = serieName;
                //    wasteStreamChart.Series.Add(series);

                //    var serieChart = chartData[key];
                //    foreach (var date in serieChart.Keys)
                //    {
                //        var dp = new DataPoint();
                //        var xAxisVal = (date - StartDate).Days;
                //        //dp.SetValueXY(xAxisVal, serieChart[date]);
                //        dp.SetValueXY(xAxisVal, i * 10);
                //        dp.AxisLabel = date.ToString("dd/MMM\nyyyy");
                //        series.Points.Add(dp);
                //    }
                //}
            }
        }

        private static Series GenerateDefaultSeries(string name)
        {
            var series = new Series
                            {
                                ChartType = SeriesChartType.StackedColumn,
                                Name = name,
                                IsValueShownAsLabel = false,
                                IsVisibleInLegend = true,
                                IsXValueIndexed = true,
                                AxisLabel = "dd/MMM\nyyyy",
                                XAxisType = AxisType.Primary,
                                XValueType = ChartValueType.Auto,
                                YValuesPerPoint = 1,
                            };
            return series;
        }
    }
}