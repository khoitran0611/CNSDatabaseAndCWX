using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// </summary>
    public partial class LocationAddPackages : Page
    {
        private const string urlDefault = "default.aspx";
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
            else
            {
                Page.Validate();
            }
        }

        /// <summary>
        /// Binds the data.
        /// </summary>
        private void BindData()
        {
            ICollection<Package> packagesWithNoLocation = GetPackagesWithNoLocation();

            if (packagesWithNoLocation.Count == 0)
            {
                MultiViewPackageList.SetActiveView(ViewNoPackagesFound);
            }
            else
            {
                MultiViewPackageList.SetActiveView(ViewMainform);

                ListboxPackages.Items.Clear();

                FillPackagesList(packagesWithNoLocation);
            }
        }

        /// <summary>
        /// Fills the packages list.
        /// </summary>
        /// <param name="packagesWithNoLocation">The packages with no location.</param>
        private void FillPackagesList(IEnumerable<Package> packagesWithNoLocation)
        {
            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();
            foreach (Package package in packagesWithNoLocation)
            {
                var numPack = ((package.ToUid - package.FromUid) + 1).ToString();
                var listItem = new ListItem(RepositoryHelper.CreatePackageName(package, chainEntity), package.Uid.ToString());
                listItem.Attributes.Add("data-npackage", numPack);
                ListboxPackages.Items.Add(listItem);
            }
        }

        /// <summary>
        /// Gets the packages with no location.
        /// </summary>
        /// <returns></returns>
        private ICollection<Package> GetPackagesWithNoLocation()
        {
            ChainEntity chainEntity = ChainEntityHelper.GetChainEntityThroughUser(User);
            //ICollection<Shipment> shipments =
            //    repositoryFactory.GetShipmentRepository().Find(new ShipmentsForShipperSpecification(chainEntity,true,false));

            //return repositoryFactory.GetPackageRepository().Find(
            //    new PackagePutInLocationRequirementSpecification(chainEntity, shipments));
            return new RepositoryFactory().GetPackageRepository().Find(new PackageForPutInLocationSpecification(chainEntity));
        }


        /// <summary>
        /// Handles the Click event of the LinkButtonPutInLocation control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void LinkButtonPutInLocation_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                TransactionManager transactionManager = new TransactionManager();

                try
                {
                    transactionManager.BeginTransaction();
                    User user = RepositoryHelper.GetCurrentUser();

                    IList<long> prodIds = new List<long>();
                    List<Package> packages = new List<Package>();


                    IRepository<Package> packageRepository = repositoryFactory.GetPackageRepository();

                    foreach (ListItem item in ListboxPackages.Items)
                    {
                        if (item.Selected)
                        {
                            Package package = packageRepository.GetOne(long.Parse(item.Value));
                            if (package != null)
                            {
                                packages.Add(package);
                            }
                        }
                    }

                    foreach (Package package in packages)
                    {
                        PutInLocationControl.AddPackageToLocation(package, user);
                    }

                    packageRepository.Flush();

                    foreach (Package package in packages)
                    {
                        PutInLocationControl.CreateProcessingSteps(package, user, null);
                        foreach (long id in package.PrimaryProducts.Select(it => it.MatchingProdId).Distinct().Where(id => !prodIds.Contains(id))) prodIds.Add(id);
                    }

                    //Update Location for Product in Matching module
                    var locationId = long.Parse(((DropDownList)PutInLocationControl.FindControl("DropDownListLocations")).SelectedValue);
                    IList<ProductSupply> productSupplies = ProductSupplyServices.GetByIds(string.Join(",", Array.ConvertAll(prodIds.ToArray(), Convert.ToString)));
                    foreach (ProductSupply productSupply in productSupplies)
                    {
                        productSupply.LocationId = locationId;
                        ProductSupplyServices.CreateOrUpdate(productSupply);
                    }

                    transactionManager.CommitTransaction();
                    Response.Redirect(urlDefault, false);

                }
                catch (Exception exception)
                {
                    ErrorHelper.HandleException(exception, transactionManager);
                    return;
                }
            }
        }

        protected void LbtSplitClick(object sender, EventArgs args)
        {
            if (string.IsNullOrEmpty(txtIdtSplit.Text)) return;
            var hasSelectedItem = false;
            var selectedItem = new ListItem();

            foreach (var listItem in ListboxPackages.Items)
            {
                var item = (ListItem)listItem;
                if (item.Selected)
                {
                    hasSelectedItem = true;
                    selectedItem = item;
                    break;
                }
            }

            if (!hasSelectedItem) return;

            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

            var selPack = repositoryFactory.GetPackageRepository().GetOne(Int64.Parse(selectedItem.Value.Split(':')[0]));
            var splitPart = Array.ConvertAll<string, int>(txtIdtSplit.Text.Split(','), it => int.Parse(it.Trim()));

            RepositoryHelper.SplitPackageGroup(selPack, splitPart, chainEntity);
            BindData();
            txtIdtSplit.Text = string.Empty;
        }
    }
}
