using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;

namespace AgriMore.Logistics.Web
{
    public partial class ShowPackages : UserControl
    {
        private const string PACKAGES = "PACKAGES";
        private bool defaultDisableCheckBox;
        private bool defaultSelectAllPackages;
        private readonly IDictionary<string, Identification> identifications = new Dictionary<string, Identification>();
        private readonly IDictionary<long, Package> packages = new Dictionary<long, Package>();
        private readonly IDictionary<Package, Identification> packageToIdentification = new Dictionary<Package, Identification>();
        private IEnumerable<Package> receivedPackages;

        /// <summary>
        /// Gets or sets a value indicating whether [default select all packages].
        /// </summary>
        /// <value>
        /// 	<c>true</c> if [default select all packages]; otherwise, <c>false</c>.
        /// </value>
        public bool DefaultSelectAllPackages
        {
            get { return defaultSelectAllPackages; }
            set { defaultSelectAllPackages = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [default disable check box].
        /// </summary>
        /// <value>
        /// 	<c>true</c> if [default disable check box]; otherwise, <c>false</c>.
        /// </value>
        public bool DefaultDisableCheckBox
        {
            get { return defaultDisableCheckBox; }
            set
            {
                defaultDisableCheckBox = value;
                if (defaultDisableCheckBox)
                {
                    DefaultSelectAllPackages = value;
                }
            }
        }

        /// <summary>
        /// Gets the packages.
        /// </summary>
        /// <value>The packages.</value>
        public IEnumerable<Package> SelectedPackages
        {
            get
            {
                //IList<Package> packages = new List<Package>();
                //foreach (Package package in packageToIdentification.Keys)
                //{
                //    packages.Add(package);
                //}

                //return packages;
                return new List<Package>(packageToIdentification.Keys);
            }
        }

        /// <summary>
        /// Gets the packages.
        /// </summary>
        /// <value>The packages.</value>
        public IEnumerable<Package> Packages
        {
            get { return (IEnumerable<Package>)Session["PACKAGES"]; }
        }

        /// <summary>
        /// Gets the identifications.
        /// </summary>
        /// <value>The identifications.</value>
        public IEnumerable<Identification> Identifications
        {
            get { return identifications.Values; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                defaultSelectAllPackages = true;
                defaultDisableCheckBox = false;
            }
            else
            {
                Page.Validate();

                if (Page.IsValid)
                {
                    //AddIdentificationsToPackages();
                }
            }
        }

        /// <summary>
        /// Sets the packages.
        /// </summary>
        /// <param name="packages">The packages.</param>
        public void SetPackages(IEnumerable<Package> packages)
        {
            GridViewPackages.DataSource = packages;
            GridViewPackages.DataBind();
            Session["PACKAGES"] = packages;
        }

        /// <summary>
        /// Adds the identifications to packages.
        /// </summary>
        public void SetIdentificationsToPackages()
        {
            foreach (KeyValuePair<Package, Identification> pair in packageToIdentification)
            {
                pair.Key.AddIdentification(pair.Value);
            }
        }

        /// <summary>
        /// Gets the package.
        /// </summary>
        /// <param name="uid">The uid.</param>
        /// <returns></returns>
        private Package GetPackage(long uid)
        {
            receivedPackages = (IEnumerable<Package>)Session["PACKAGES"];
            foreach (Package package in receivedPackages)
            {
                if (package.Uid.Equals(uid))
                {
                    return package;
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the package.
        /// </summary>
        /// <param name="identification">The identification.</param>
        /// <returns></returns>
        public Package GetPackage(Identification identification)
        {
            foreach (Package package in packageToIdentification.Keys)
            {
                if (packageToIdentification[package].Id == identification.Id)
                {
                    return package;
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the identification.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <returns></returns>
        public Identification GetIdentification(Package package)
        {
            foreach (long packageUid in packages.Keys)
            {
                if (packageUid.Equals(package.Uid))
                {
                    return packageToIdentification[package];
                }
            }

            return null;
        }

        /// <summary>
        /// Handles the ServerValidate event of the GridViewValidator control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="args">The <see cref="System.Web.UI.WebControls.ServerValidateEventArgs"/> instance containing the event data.</param>
        protected void GridViewValidator_ServerValidate(object sender, ServerValidateEventArgs args)
        {
            CustomValidator custom = sender as CustomValidator;
            int numberofPackagesSelected = 0;

            identifications.Clear();
            packages.Clear();
            packageToIdentification.Clear();

            foreach (GridViewRow gridViewRow in GridViewPackages.Rows)
            {
                CheckBox checkBox = gridViewRow.FindControl("CheckBoxSelectedPackage") as CheckBox;
                TextBox identification = gridViewRow.FindControl("TextBoxIdentification") as TextBox;
                HiddenField packageIdField = gridViewRow.FindControl("HiddenFieldPackageId") as HiddenField;
                CustomValidator textFieldValidator = gridViewRow.FindControl("TextBoxIdentificationValidator") as CustomValidator;

                string id = identification.Text.Trim();
                if (checkBox.Checked)
                {
                    numberofPackagesSelected++;
                }
                if (id != String.Empty)
                {
                    if (checkBox.Checked)
                    {
                        if (identifications.ContainsKey(id))
                        {
                            args.IsValid = false;
                            custom.ErrorMessage = "package identifications must be unique";
                            return;
                        }
                        else
                        {
                            Package package = GetPackage(long.Parse(packageIdField.Value));
                            Identification iden = new Identification(id, GetChainEntityForCurrentUser(), package.FromUid, package.ToUid);

                            if (identification.Enabled)
                            {
                                if (package.IsIdentifiedBy(iden) || RepositoryHelper.IdentificationExists(iden, GetChainEntityForCurrentUser()))
                                {
                                    args.IsValid = false;
                                    custom.ErrorMessage = "package identification is already used";
                                    return;
                                }

                                identifications.Add(id, iden);
                            }
                            packageToIdentification.Add(package, iden);
                            packages.Add(package.Uid, package);
                        }
                    }
                }
            }

            if (numberofPackagesSelected == 0)
            {
                args.IsValid = false;
                custom.ErrorMessage = "must select at least 1 package";
                return;
            }
        }

        /// <summary>
        /// Handles the ServerValidate event of the TextBoxIdentificationValidator control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="args">The <see cref="System.Web.UI.WebControls.ServerValidateEventArgs"/> instance containing the event data.</param>
        protected void TextBoxIdentificationValidator_ServerValidate(object sender, ServerValidateEventArgs args)
        {
            CustomValidator custom = sender as CustomValidator;
            GridViewRow gridViewRow = custom.NamingContainer as GridViewRow;

            CheckBox checkBox = gridViewRow.FindControl("CheckBoxSelectedPackage") as CheckBox;
            TextBox identification = gridViewRow.FindControl("TextBoxIdentification") as TextBox;
            HiddenField packageIdField = gridViewRow.FindControl("HiddenFieldPackageId") as HiddenField;

            if (checkBox.Checked)
            {
                string id = identification.Text.Trim();
                if (id == String.Empty)
                {
                    args.IsValid = false;
                    custom.ErrorMessage = "Package must have an identification";
                    return;
                }
            }
        }

        /// <summary>
        /// Handles the OnRowDataBound event of the GridViewPackages control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.GridViewRowEventArgs"/> instance containing the event data.</param>
        protected void GridViewPackages_OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                CheckBox checkBox = e.Row.FindControl("CheckBoxSelectedPackage") as CheckBox;
                if (DefaultDisableCheckBox)
                {
                    checkBox.Checked = DefaultSelectAllPackages;
                    checkBox.Enabled = false;
                }
            }
        }

        private ChainEntity chainEntityForCurrentUser;
        private ChainEntity GetChainEntityForCurrentUser()
        {
            if (chainEntityForCurrentUser == null)
            {
                chainEntityForCurrentUser = RepositoryHelper.GetChainEntityForCurrentUser();
            }
            return chainEntityForCurrentUser;
        }

        /// <summary>
        /// Creates the name of the package.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <returns></returns>
        protected string CreatePackageName(object package)
        {
            return RepositoryHelper.CreatePackageName((Package)package, GetChainEntityForCurrentUser());
        }

        /// <summary>
        /// Determines whether this instance is enabled.
        /// </summary>
        /// <returns>
        /// 	<c>true</c> if this instance is enabled; otherwise, <c>false</c>.
        /// </returns>
        protected bool IsEnabled(object package)
        {
            Package selectedPackage = package as Package;

            return selectedPackage.GetIdentification(GetChainEntityForCurrentUser()) == null; // change to == null
        }

        /// <summary>
        /// Creates the name of the package.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <returns></returns>
        protected string GetPackageIdentificationForChainEntity(object package)
        {
            Package selectedPackage = package as Package;

            if (selectedPackage != null)
            {
                Identification identification =
                    selectedPackage.GetIdentification(GetChainEntityForCurrentUser());

                if (identification != null)
                {
                    return identification.Id;
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// Clears this instance.
        /// </summary>
        public void Clear()
        {
            receivedPackages = null;
            Session.Remove(PACKAGES);
            identifications.Clear();
            packages.Clear();
            packageToIdentification.Clear();
        }

        /// <summary>
        /// Adds the identification.
        /// </summary>
        /// <param name="package">The package.</param>
        public void AddIdentificationToPackage(Package package)
        {
            Identification id = GetIdentification(package);

            if (id != null)
            {
                if (package.IsIdentifiedBy(id) == false)
                {
                    package.AddIdentification(id);
                }
            }
        }
    }
}