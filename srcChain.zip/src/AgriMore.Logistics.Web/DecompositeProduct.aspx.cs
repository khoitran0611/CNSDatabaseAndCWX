﻿using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Web.Helpers;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web.UI.WebControls;

namespace AgriMore.Logistics.Web
{
    public partial class DecompositeProduct : BasePage
    {
        private const string DmpPrimaryProd = "DECOMPOSE_PRIMARYPROD";
        private const string DmpProductsList = "DECOMPOSE_PRODLIST_SESSION";
        private const string DmpDecompositionExList = "DECOMPOSE_DECOMPOSITION_SESSION";
        private readonly RepositoryFactory _repositoryFactory = new RepositoryFactory();
        private const long wholesalePackage = 1;

        /// <summary>
        /// Gets or sets the location langdtls.
        /// </summary>
        /// <value>The location langdtls.</value>
        public IList<DecomposeProduct> DecomposeProducts
        {
            get { return Session[DmpProductsList] as IList<DecomposeProduct> ?? new List<DecomposeProduct>(); }
            set { Session[DmpProductsList] = value; }
        }

        public IList<Decomposition> DecompositionExs
        {
            get { return Session[DmpDecompositionExList] as IList<Decomposition> ?? new List<Decomposition>(); }
            set { Session[DmpDecompositionExList] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            lblDeCmpMsg.Visible = false;
            lblDoComposeMsg.Visible = false;

            if (IsPostBack) return;

            mtvDecompose.SetActiveView(vIdtProd);
            BindData();
        }

        /// <summary>
        /// Handles the Click event of the lbtDecompose control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void LbtDecomposeClick(object sender, EventArgs e)
        {
            mtvDecompose.SetActiveView(vDecompose);

            lblIdtProdMsg.Visible = false;
            DecomposeProducts = new List<DecomposeProduct>();
            DecompositionExs = new List<Decomposition>();
            var selProdId = lbxProducts.SelectedValue.ToInt64();
            var priProd = PrimaryProductServices.GetPrimaryProductById(selProdId);
            var prod = ProductServices.GetById(priProd.ProductUid);

            if (priProd.MatchingProdId <= 0)
            {
                ErrorHelper.SetErrorLabel(true, "Your selected product do not exist in Matching!", lblDeCmpMsg, false);
                mtvDecompose.SetActiveView(vIdtProd);
                return;
            }

            BindingDecomposeProds2List();
            BindingProductDetails(priProd, prod);
            BindingProductDropDown(prod.Uid);
            BindPackageTypes(prod);
            BindingDecomposionTemp2List();

            BindingKeyFigureValue();
        }

        /// <summary>
        /// Handles the Click event of the lbtAdd control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void LbtAddClick(object sender, EventArgs e)
        {
            lblIdtProdMsg.Visible = false;
            if (DecomposeProducts.Any(it => it.PrimaryProd.ProductUid == ddlIdtProd.SelectedValue.ToInt64()))
            {
                ErrorHelper.SetErrorLabel(true, string.Format(Resources.Localization.ErrMsg_ProductAlreadyAdded, ddlIdtProd.SelectedItem.Text), lblIdtProdMsg, false);
                return;
            }

            try
            {
                ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();
                ValidateIdentifications(chainEntity);
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.Message, lblIdtProdMsg, false);
                return;
            }

            var parentPP = (PrimaryProduct)Session[DmpPrimaryProd];
            var priProduct = new PrimaryProduct
                             {
                                 ParentUid = parentPP.Uid,
                                 ProductName = ddlIdtProd.SelectedItem.Text,
                                 ProductUid = ddlIdtProd.SelectedValue.ToInt64(),
                                 ProductAmount = txtAmount.Text.ToDecimal(),
                                 Uom = _repositoryFactory.GetUnitOfMeasurementRepository().GetOne(ddlUoM.SelectedValue.ToInt64()),
                                 ProductionAreaId = parentPP.ProductionAreaId,
                                 LifeCycleId = parentPP.LifeCycleId,
                                 Quantity = txtQuantity.Text.ToInt32()
                             };

            var packageTypes = (List<PackagingDefine>)Session["packageTypes"];
            PackagingDefine packType = null;
            if (packageTypes.Any())
                packType = packageTypes.FirstOrDefault(p => p.Uid == Int64.Parse(ddlPackageType.SelectedValue));

            var deCmpProd = new DecomposeProduct
                            {
                                FromIdentifier = txtIdtFrom.Text.ToInt64(),
                                ToIdentifier = txtIdtTo.Text.ToInt64(),
                                ForOrgId = hdfDecomposeForOrgId.Value,
                                RootProdId = hdfRootDecomposeProdId.Value.ToInt64(),
                                FromProdId = hdfDecompositionFromProdId.Value.ToInt64(),
                                KeyFigureVal = txtFigureVal.Text.ToDecimal(),
                                KeyFigureWeight = txtFigureWeight.Text.ToDecimal(),
                                PrimaryProd = priProduct,
                                Package = packType
                            };

            IList<DecomposeProduct> tmpDecomposeProducts = DecomposeProducts;
            tmpDecomposeProducts.Add(deCmpProd);
            DecomposeProducts = tmpDecomposeProducts;
            BindingDecomposeProds2List();
            txtAmount.Text = txtIdtFrom.Text = txtIdtTo.Text = txtQuantity.Text = string.Empty;
        }

        /// <summary>
        /// Handles the Click event of the lbtDoDecompose control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void LbtDoDecomposeClick(object sender, EventArgs e)
        {
            try
            {
                if (DecomposeProducts.Count <= 0)
                {
                    ErrorHelper.SetErrorLabel(true, Resources.Localization.ErrMsg_DefineProductsResult4DecomposeProcess, lblDoComposeMsg, false);
                    return;
                }

                if (!IsValidDecompositionProducts())
                {
                    ErrorHelper.SetErrorLabel(true, Resources.Localization.TotalDecomposeInvalid, lblDoComposeMsg, false);
                    return;
                }

                User user = RepositoryHelper.GetCurrentUser();
                ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();
                var location = _repositoryFactory.GetLocationRepository().GetOne(ddlLocation.SelectedValue.ToInt64());

                var parentPP = (PrimaryProduct)Session[DmpPrimaryProd];
                ProductServices.DecomposeProduct(DecomposeProducts, parentPP, location, chainEntity, user);

                Session[DmpPrimaryProd] = null;
                DecomposeProducts = new List<DecomposeProduct>();

                mtvDecompose.SetActiveView(vIdtProd);

                BindingProduct(ddlLocation.SelectedValue.ToInt32());
                lblDeCmpMsg.Text = Resources.Localization.DecomposeProductSuccessful;
                lblDeCmpMsg.Visible = true;
                lblDeCmpMsg.ForeColor = Color.Blue;
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.Message, lblDoComposeMsg, false);
                return;
            }
        }

        /// <summary>
        /// Handles the Click event of the lbtCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void LbtCancelClick(object sender, EventArgs e)
        {
            Session[DmpPrimaryProd] = null;
            DecomposeProducts = new List<DecomposeProduct>();
            Session[DmpDecompositionExList] = null;
            DecompositionExs = new List<Decomposition>();
            mtvDecompose.SetActiveView(vIdtProd);
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the ddlLocation control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void DdlLocationSelectedIndexChanged(object sender, EventArgs e)
        {
            BindingProduct(ddlLocation.SelectedValue.ToInt32());
        }

        /// <summary>
        /// Handles the RowCommand event of the grdCmpProd control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="GridViewCommandEventArgs"/> instance containing the event data.</param>
        protected void GrdCmpProdRowCommand(object sender, GridViewCommandEventArgs e)
        {
            lblIdtProdMsg.Visible = false;
            if (!"DelDmpProd".Equals(e.CommandName)) return;
            int itIndex = Convert.ToInt32(e.CommandArgument);
            IList<DecomposeProduct> tmpProducts = DecomposeProducts;

            tmpProducts.RemoveAt(itIndex);
            DecomposeProducts = tmpProducts;
            BindingDecomposeProds2List();
        }

        /// <summary>
        /// Binds the data.
        /// </summary>
        private void BindData()
        {
            ICollection<Location> fromLocations = new List<Location>(RepositoryHelper.GetChainEntityForCurrentUser().Locations);
            ddlLocation.DataSource = fromLocations;
            ddlLocation.DataValueField = "Uid";
            ddlLocation.DataTextField = "Name";
            ddlLocation.DataBind();

            BindingProduct(ddlLocation.SelectedValue.ToInt32());
        }

        private void BindingProduct(int lctId)
        {
            lbxProducts.Items.Clear();

            var lstProdItems = new List<ListItem>();
            var lstProducts = ProductServices.GetProductList();
            var curChainEntity = RepositoryHelper.GetChainEntityForCurrentUser();
            IList<Package> lstPackages = PackageServices.GetPackageInLocation(lctId);
            foreach (var package in lstPackages)
            {
                foreach (PrimaryProduct priProd in package.PrimaryProducts)
                {
                    if (priProd.Decomposed || lstProdItems.Any(it => it.Value.Equals(priProd.Uid.ToString()))) continue;
                    var prod = lstProducts.SingleOrDefault(it => it.Uid == priProd.ProductUid);
                    if (prod == null) continue;

                    string itText = string.Format("{0} - {1}{2} --> Package ID: {3}", prod.Name,
                        priProd.ProductAmount, priProd.Uom.Name, RepositoryHelper.GetPackageId(package, curChainEntity));

                    lstProdItems.Add(new ListItem(itText, priProd.Uid.ToString()));
                }
            }

            lbxProducts.Items.AddRange(lstProdItems.ToArray());
        }

        /// <summary>
        /// Binds the package types.
        /// </summary>
        private void BindPackageTypes(Product prod)
        {
            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

            var currentUser = RepositoryHelper.GetCurrentUser();
            IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(currentUser.UsingLang, 0, prod.Uid, chainEntity.Uid);

            Session["packageTypes"] = packageTypes;
            ddlPackageType.DataSource = packageTypes; //_repositoryFactory.GetPackageTypeRepository();
            ddlPackageType.DataTextField = "Name";
            ddlPackageType.DataValueField = "Uid";
            ddlPackageType.DataBind();
        }

        private void BindingProductDetails(PrimaryProduct priProd, Product prod)
        {
            lblProdName.Text = prod.Name;
            lblProdAmount.Text = string.Format("{0}({1})", priProd.ProductAmount, priProd.Uom.Name);
            lblProdDescription.Text = priProd.HarvestedProductDescription;
            lblProdAreaId.Text = priProd.ProductionAreaId;
            lblLifeCycleId.Text = priProd.LifeCycleId;

            var rootProductSupply = priProd.ParentUid <= 0 ? ProductSupplyServices.GetById(priProd.MatchingProdId)
                : ProductSupplyServices.GetRootProductSupply(priProd.MatchingProdId);

            hdfDecomposeForOrgId.Value = rootProductSupply != null ? rootProductSupply.StrOrgId : string.Empty;
            hdfRootDecomposeProdId.Value = rootProductSupply != null ? rootProductSupply.Product.Uid.ToString() : string.Empty;
            hdfDecompositionFromProdId.Value = prod.Uid.ToString();
            hdfDecompositionTotalAmount.Value = priProd.ProductAmount.ToString();
            BindingKeyFigureValue();

            Session[DmpPrimaryProd] = priProd;
        }

        private void BindingProductDropDown(long prodId)
        {
            ddlIdtProd.Items.Clear();
            var lstProds = ProductServices.GetChildProducts(prodId);
            var listItems = lstProds.Select(it => new ListItem(it.Name, it.Uid.ToString())).ToArray();

            ddlIdtProd.Items.AddRange(listItems);
        }

        private void BindingDecomposeProds2List()
        {
            grdCmpProd.DataSource = DecomposeProducts;
            grdCmpProd.DataBind();
        }

        /// <summary>
        /// Validates the identifications.
        /// </summary>
        /// <param name="chainEntity">The chain entity.</param>
        /// <returns></returns>
        private void ValidateIdentifications(ChainEntity chainEntity)
        {
            long from, to;
            bool fromIsNumeric = Int64.TryParse(txtIdtFrom.Text, out from);
            bool toIsNumeric = Int64.TryParse(txtIdtTo.Text, out to);

            if (fromIsNumeric == false)
            {
                throw new ArgumentException(Resources.Localization.Thefromidentificationisnotnumeric);
            }

            if (txtIdtTo.Text == string.Empty)
            {
                to = from;
            }
            else
            {
                if (toIsNumeric == false)
                {
                    throw new ArgumentException(Resources.Localization.Thetoidentificationisnotnumeric);
                }
            }

            if (from > to)
            {
                throw new ArgumentException(Resources.Localization.Thefromidcannotbegreaterthanthetoidentification);
            }

            if (from < 0 || to < 0)
            {
                throw new ArgumentException(Resources.Localization.Identificationscannotbenegative);
            }

            long tempId = from;

            for (long counter = tempId; counter <= to; counter++)
            {
                if (RepositoryHelper.IdentificationExists(tempId.ToString(), chainEntity) ||
                   DecomposeProducts.Any(it => it.FromIdentifier <= counter && it.ToIdentifier >= counter))
                {
                    throw new ArgumentException(Resources.Localization.Theidentificationisalreadyused);
                }

                tempId++;
            }
        }

        public string ProcessMyDataItem(object quantity)
        {
            var myQuantity = (int)quantity;
            return myQuantity == 0 ? "" : myQuantity.ToString();
        }

        protected void lbtAddDecompositionType_Click(object sender, EventArgs args)
        {
            lblDeCmpMsg.Visible = false;
            mtvDecompose.SetActiveView(vAddDecompositionType);

            Session[DmpDecompositionExList] = null;
            DecompositionExs = new List<Decomposition>();

            InitilizeDate();
            //lblIdtProdMsg.Visible = false;            
            var selProdId = lbxProducts.SelectedValue.ToInt64();
            var priProd = PrimaryProductServices.GetPrimaryProductById(selProdId);
            var prod = ProductServices.GetById(priProd.ProductUid);
            hdfDecompositionProdId.Value = priProd.MatchingProdId.ToString();

            BindingProductDetailsForDecomposition(priProd, prod);
            BindDecompositionCategory();
            BindDecompositionType();
            FillDataForDecompositionTypeUom();
            BindingDecomposionTemp2List();
            InitilizeDate();
            txtCost.Text = "";
        }

        private void BindingProductDetailsForDecomposition(PrimaryProduct priProd, Product prod)
        {
            ltrProductName.Text = prod.Name;
            ltrAmount.Text = string.Format("{0}({1})", priProd.ProductAmount, priProd.Uom.Name);
            ltrDescription.Text = priProd.HarvestedProductDescription;
            ltrProductionAreaId.Text = priProd.ProductionAreaId;
            ltrLifeCycleId.Text = priProd.LifeCycleId;

            //Fill package information
            IList<Package> lstPackages = PackageServices.GetPackageInLocation(ddlLocation.SelectedValue.ToInt64());
            if (lstPackages.Any())
            {
                var pack = lstPackages.FirstOrDefault(p => p.PrimaryProducts.Any(prP => prP.Uid == priProd.Uid));
                if (pack != null)
                {
                    ltrPackageDetail.Text = RepositoryHelper.GetPackageId(pack, RepositoryHelper.GetChainEntityForCurrentUser());
                    Session["CurrentPackage"] = pack;
                }
                else ltrPackageDetail.Text = "";
            }
        }

        protected void lbtAddDecomposition_Click(object sender, EventArgs e)
        {
            var from = fromCalendar.GetDateValue();
            var to = toCalendar.GetDateValue();

            var periodFrom = new DateTime(from.Year, from.Month, from.Day, int.Parse(DropDownListHoursFrom.SelectedItem.Text),
                                    int.Parse(DropDownListMinutesFrom.SelectedItem.Text),
                                    int.Parse(DropDownListSecondsFrom.SelectedItem.Text));

            var periodTo = new DateTime(to.Year, to.Month, to.Day, int.Parse(DropDownListHoursTo.SelectedItem.Text),
                                    int.Parse(DropDownListMinutesTo.SelectedItem.Text),
                                    int.Parse(DropDownListSecondsTo.SelectedItem.Text));

            var pack = (Session["CurrentPackage"]) != null ? ((Package)Session["CurrentPackage"]) : null;
            var decomposition = new Decomposition
            {
                PeriodFromDate = periodFrom,
                PeriodToDate = periodTo,
                Cost = decimal.Parse(txtCost.Text),
                CostCurrency = ddlCostCurrency.SelectedValue,
                DecompositionTypeId = ddlDecompositionType.SelectedValue.ToInt64(),
                PackageId = pack != null ? pack.Uid : 0,
                NumberPackage = pack != null ? (pack.ToUid - pack.ToUid) + 1 : 1,
                MatchingProdId = hdfDecompositionProdId.Value.ToInt64(),
                CostUnit = ddlCostUnit.SelectedValue
            };

            IList<Decomposition> tmpDecompositionExs = DecompositionExs;
            tmpDecompositionExs.Add(decomposition);
            DecompositionExs = tmpDecompositionExs;
            BindingDecomposionTemp2List();
            txtFromPeriod.Text = txtToPeriod.Text = string.Empty;
            InitilizeDate();
            txtCost.Text = "0";

        }

        private void BindDecompositionCategory()
        {
            IList<DecompositionCategory> decompoitions = ProductServices.GetDecompositionCategoryList();

            ddlDecompositionCategory.DataSource = decompoitions;
            ddlDecompositionCategory.DataTextField = "Name";
            ddlDecompositionCategory.DataValueField = "Uid";
            ddlDecompositionCategory.DataBind();
        }

        private void BindDecompositionType()
        {
            var selectedCategoryId = ddlDecompositionCategory.SelectedValue.ToInt64();

            List<DecompositionType> decompositionTypes = ProductServices.GetDecompositionTypeById(selectedCategoryId).ToList();

            ddlDecompositionType.Items.Clear();

            if (decompositionTypes.Any())
            {
                foreach (var dec in decompositionTypes)
                {
                    var item = new ListItem(dec.Name, dec.Uid.ToString());

                    ddlDecompositionType.Items.Add(item);

                    //item.Selected = true;
                }
            }

        }

        protected void ddlDecompositionCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindDecompositionType();
        }

        private void BindingDecomposionTemp2List()
        {
            grdDecompositionTmp.DataSource = DecompositionExs;
            grdDecompositionTmp.DataBind();
        }

        protected void GrdCmpDecompositionRowCommand(object sender, GridViewCommandEventArgs e)
        {
            //lblIdtProdMsg.Visible = false;
            if (!"DelDmpDecomposition".Equals(e.CommandName)) return;
            int itIndex = Convert.ToInt32(e.CommandArgument);
            IList<Decomposition> tmpDecompositions = DecompositionExs;

            tmpDecompositions.RemoveAt(itIndex);
            DecompositionExs = tmpDecompositions;
            BindingDecomposionTemp2List();
        }

        public string ProcessDecompositionType(object quantity)
        {
            var myQuantity = (long)quantity;
            List<DecompositionType> types = ProductServices.GetDecompositionTypeList().ToList();

            if (!types.Any()) return string.Empty;
            var decType = types.FirstOrDefault(t => t.Uid == myQuantity);
            if (decType != null)
            {
                return decType.Name + " (" + decType.UnitOfMeasurement.Name + ")";
            }

            return string.Empty;
        }

        protected void LbtSaveClick(object sender, EventArgs e)
        {
            try
            {
                LinkButton2.CausesValidation = false;
                Page.Validate();
                var decompositionList = (List<Decomposition>)Session[DmpDecompositionExList];

                if (!Page.IsValid) return;
                var transactionManager = new TransactionManager();

                try
                {
                    ProductSupply prodSupply = null;
                    if (decompositionList.Any())
                    {
                        transactionManager.BeginTransaction();

                        foreach (var dec in decompositionList)
                        {
                            _repositoryFactory.GetDecompositionRepository().Add(dec);

                            if (prodSupply != null) continue;
                            prodSupply = new ProductSupply { Uid = dec.MatchingProdId };
                        }
                    }

                    transactionManager.CommitTransaction();
                    if (prodSupply != null) ProductSupplyServices.ResetGenerationInv(prodSupply);

                    mtvDecompose.SetActiveView(vIdtProd);

                    BindingProduct(ddlLocation.SelectedValue.ToInt32());
                    lblDeCmpMsg.Text = "Save decomposition sucessfully";
                    lblDeCmpMsg.Visible = true;
                    lblDeCmpMsg.ForeColor = Color.Blue;

                }
                catch (Exception exception)
                {
                    transactionManager.RollbackTransaction();
                    throw exception;
                }

                Session[DmpDecompositionExList] = null;
                DecompositionExs = new List<Decomposition>();
            }

            catch (ArgumentNullException exception)
            {
                throw exception;
            }
        }

        void InitilizeDate()
        {
            DropDownListHoursFrom.ClearSelection();
            DropDownListMinutesFrom.ClearSelection();
            DropDownListSecondsFrom.ClearSelection();

            DropDownListHoursTo.ClearSelection();
            DropDownListMinutesTo.ClearSelection();
            DropDownListSecondsTo.ClearSelection();

            fromCalendar.SetDateValue(DateTime.Now);
            DropDownListHoursFrom.Items.FindByValue(DateTime.Now.Hour.ToString()).Selected = true;
            DropDownListMinutesFrom.Items.FindByValue(DateTime.Now.Minute.ToString()).Selected = true;
            DropDownListSecondsFrom.Items.FindByValue(DateTime.Now.Second.ToString()).Selected = true;

            toCalendar.SetDateValue(DateTime.Now);
            DropDownListHoursTo.Items.FindByValue(DateTime.Now.Hour.ToString()).Selected = true;
            DropDownListMinutesTo.Items.FindByValue(DateTime.Now.Minute.ToString()).Selected = true;
            DropDownListSecondsTo.Items.FindByValue(DateTime.Now.Second.ToString()).Selected = true;
        }

        void FillDataForDecompositionTypeUom()
        {
            var decType = ProductServices.GetDecompositionTypeList().FirstOrDefault(dt => dt.Uid == ddlDecompositionType.SelectedValue.ToInt64());
            if (decType != null)
            {
                lblDecompositionTypeUOM.Text = "(" + decType.UnitOfMeasurement.Name + ")";
            }
            else
            {
                lblDecompositionTypeUOM.Text = " ";
            }
        }

        protected void ddlDecompositionType_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillDataForDecompositionTypeUom();

        }

        protected void DdlIdtProdSelectedIndexChanged(object sender, EventArgs e)
        {
            BindingKeyFigureValue();
        }

        private void BindingKeyFigureValue()
        {
            var keyFigure = DecompositionServices.GetKeyFigure(hdfDecomposeForOrgId.Value, hdfRootDecomposeProdId.Value.ToInt64(),
                hdfDecompositionFromProdId.Value.ToInt64(), ddlIdtProd.SelectedValue.ToInt64());
            if (keyFigure == null)
            {
                txtFigureVal.Text = txtFigureWeight.Text = string.Empty;
                return;
            }

            txtFigureVal.Text = keyFigure.FigureVal.ToString("0.##");
            txtFigureWeight.Text = (keyFigure.FigureVal * hdfDecompositionTotalAmount.Value.ToDecimal() / 100).ToString("0.##");
        }

        private bool IsValidDecompositionProducts()
        {
            var tmpDecompositionProds = DecomposeProducts;

            var totalVal = tmpDecompositionProds.Sum(it => it.PrimaryProd.ProductAmount);
            return (totalVal == 0 || totalVal == hdfDecompositionTotalAmount.Value.ToDecimal());
        }

        protected void GrdCmpProdRowDataBound(object sender, GridViewRowEventArgs e)
        {
            var item = e.Row.DataItem as DecomposeProduct;
            if (item == null) return;

            ((Label)e.Row.FindControl("lblKeyFigureWeight")).Text = string.Format("{0:0.##}({1})", item.KeyFigureWeight, item.PrimaryProd.Uom.Name);
            ((Label)e.Row.FindControl("lblAmount")).Text = item.PrimaryProd.ProductAmount > 0 ?
                string.Format("{0:0.##}({1})", item.PrimaryProd.ProductAmount, item.PrimaryProd.Uom.Name) : string.Empty;
        }
    }
}