﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Data.Services;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.ThirdPartyEntities;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Web.Helpers;

namespace AgriMore.Logistics.Web
{
    public partial class PackagingMaterialDisposal : BasePage
    {
        private const string urlDefault = "Default.aspx";
        private string invalidinputtext = Resources.Localization.Thereisaninvaliditem;
        private readonly RepositoryFactory _repositoryFactory = new RepositoryFactory();

        protected void Page_Load(object sender, EventArgs e)
        {
            ErrorHelper.SetErrorLabel(false, string.Empty, LabelError, false);
            lbtPackPackingWaste.Visible = false;
            if (Page.IsPostBack) return;

            BindingLocation();
            BindingDisposalPackages();
            BindPackageTypes();                     
        }

        protected void LbtSaveClick(object sender, EventArgs e)
        {
            txtIdenfication.CausesValidation = false;
            Page.Validate();
            if (!Page.IsValid) return;

            var transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                var status = (DisposalPackingStatus)Enum.Parse(typeof(DisposalPackingStatus), ddlToStatus.SelectedValue);
                var packages = (from ListItem item in lbxDisposalPackages.Items
                                where item.Selected
                                select _repositoryFactory.GetDisposalPackageRepository().GetOne(long.Parse(item.Value))).ToList();

                IRepository<DisposalPackage> disposalPackRes = _repositoryFactory.GetDisposalPackageRepository();
                foreach (DisposalPackage package in packages)
                {
                    package.Status = status;
                    disposalPackRes.Store(package);
                }

                transactionManager.CommitTransaction();
                BindingDisposalPackages();
            }
            catch (Exception exception)
            {
                transactionManager.RollbackTransaction();
                ErrorHelper.HandleException(exception, transactionManager);
            }
        }

        protected void DdlStatusFilterSelectedIndexChanged(object sender, EventArgs e)
        {
            BindingDisposalPackages();
        }

        protected void DdlLocationSelectedIndexChanged(object sender, EventArgs e)
        {
            BindingDisposalPackages();
        }

        public void BindingDisposalPackages()
        {            
            var materialId = ddlPackageMaterial.SelectedValue.ToInt64();
            var lctId = ddlLocation.SelectedValue.ToInt64();
            var status = (DisposalPackingStatus)Enum.Parse(typeof(DisposalPackingStatus), ddlStatusFilter.SelectedValue);
            IEnumerable<DisposalPackage> disposalPackages = disposalPackages = DisposalPackageServices.GetByLocationAndStatus(lctId, status);
            if (materialId != 0)
            {
                disposalPackages = disposalPackages.Where(pd => pd.PackageMaterialId == materialId);
            }          

            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();
            IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(CurLangCode, 0, 0, chainEntity.Uid);

            lbxDisposalPackages.Items.Clear();
            foreach (var disposalPackage in disposalPackages)
            {
                var selPackType = packageTypes.SingleOrDefault(it => it.Uid == disposalPackage.PackageTypeId);
                if (selPackType == null) continue;

                var item = new ListItem(string.Format(Resources.Localization.DisposalPackageName,
                       selPackType.Name, disposalPackage.Amount, selPackType.PackagingMaterial.Name, disposalPackage.UnPackId), disposalPackage.Uid.ToString());
                lbxDisposalPackages.Items.Add(item);
            }

            //Show the button only if the there is at least 1 package selected
            foreach (ListItem item in lbxDisposalPackages.Items)
            {
                if (item.Selected)
                {
                    lbtPackPackingWaste.Visible = true;
                    break;
                }
            }   
        }

        private void BindingLocation()
        {
            ICollection<Location> locations = new List<Location>(RepositoryHelper.GetChainEntityForCurrentUser().Locations);
            ddlLocation.DataSource = locations;
            ddlLocation.DataValueField = "Uid";
            ddlLocation.DataTextField = "Name";
            ddlLocation.DataBind();
        }

        protected void LbtPackPackingWasteClick(object sender, EventArgs e)
        {
            //txtIdenfication.CausesValidation = true;
            Page.Validate();
            if (!Page.IsValid)
            {
                //Show the button only if the there is at least 1 package selected
                foreach (ListItem item in lbxDisposalPackages.Items)
                {
                    if (item.Selected)
                    {
                        lbtPackPackingWaste.Visible = true;
                        break;
                    }
                } 

                return;
            }

            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();
            int packageIdentification;

            bool fromIsNumeric = int.TryParse(txtIdenfication.Text, out packageIdentification);

            if (!fromIsNumeric)
            {
                ErrorHelper.SetErrorLabel(true, invalidinputtext + " " + Resources.Localization.Theidentificationisnotnumeric, LabelError, false);                
            }

            ValidateIdentifications(chainEntity);


            TransactionManager transactionManager = new TransactionManager();
            try
            {
                transactionManager.BeginTransaction();

                var selectedLocation = RepFactory.GetLocationRepository().GetOne(Int64.Parse(ddlLocation.SelectedValue));
                List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];
                PackagingDefine packageType = null;
                if (packageTypes.Any())
                {
                    packageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
                }

                DateTime dateTimeOfPacking = DateTime.Now;

                List<Identification> packageIdentifications = null;

                packageIdentifications = GetPackageIdentifications(chainEntity, packageIdentification, packageIdentification);

                Package pack = new Package();

                //Add new properties for package
                pack =
                    pack.Pack(packageType, dateTimeOfPacking, packageIdentifications,
                                 "", DateTime.MinValue,
                                 DateTime.MinValue, DateTime.MinValue);
                pack.FromUid = packageIdentification;
                pack.ToUid = packageIdentification;
                pack.TypeOfWaste = Int32.Parse(ddlStatusFilter.SelectedValue);

                RepFactory.GetPackageRepository().Add(pack);

                foreach (ListItem item in lbxDisposalPackages.Items)
                {
                    //Remove selected package from location
                    if (item.Selected)
                    {                        
                        var package = RepFactory.GetDisposalPackageRepository().GetOne(Int64.Parse(item.Value));

                        //Insert 1 row into wastedisposaldisposalpackage table to keep trace later in the VPS
                        var wasteDisposalDisposalPackage = new WasteDisposalDisposalPackage
                        {
                            DisposalPackageId = package.Uid,
                            WasteDisposalPackageId = pack.Uid
                        };

                        RepFactory.GetWasteDisposalDisposalPackageRepository().Add(wasteDisposalDisposalPackage);

                        RepFactory.GetWasteDisposalDisposalPackageRepository().Flush();

                        //Update primary product for the waste disposal package
                        var newPack = RepFactory.GetPackageRepository().GetOne(wasteDisposalDisposalPackage.WasteDisposalPackageId);
                        if (newPack != null)
                        {
                            var tracing = RepFactory.GetWasteDisposalPackageTracingRepository()
                                .AsCollection().Where(t => t.DisposalPackageId == package.Uid).FirstOrDefault();
                            if(tracing != null)
                            {
                                var parentPack = RepFactory.GetPackageRepository().GetOne(tracing.ParentUnpackPackageId);
                                if (parentPack != null)
                                {
                                    newPack.PrimaryProducts.AddRange(parentPack.PrimaryProducts);
                                    RepFactory.GetPackageRepository().Store(newPack);
                                }
                            }
                              
                        }
                        RepFactory.GetDisposalPackageRepository().Remove(package);
                    }
                }

                var status = (DisposalPackingStatus)Enum.Parse(typeof(DisposalPackingStatus), ddlStatusFilter.SelectedValue);                
                //Insert 1 row into the table packagepackagingwasteinfo
                var wasteInfo = new PackagePackagingWasteInfo()
                {
                    PackageId = pack.Uid,
                    PackingWasteDescription = "Waste Disposal - Category:  " + status.ToString(),
                    TypeOfWaste = Int32.Parse(ddlStatusFilter.SelectedValue)
                };

                if (packageType != null) wasteInfo.PackingWasteDescription += " - Material: " + packageType.PackagingMaterial.Name;
                

                RepFactory.GetPackagePackagingWasteInfoRepository().Add(wasteInfo);                

                transactionManager.CommitTransaction();

                Response.Redirect(string.Format("{0}?{1}={2}&{3}={4}", urlDefault, WebConstants.InfoMsg, (long)InfoMessage.PackSuccessful,
                WebConstants.InfoDtl, string.Format("{0},{1},{2},{3}", pack.Uid, packageIdentifications[0].Id, pack.FromUid, pack.ToUid)), false);
            }

            catch (ArgumentNullException exception)
            {
                transactionManager.RollbackTransaction();
                ErrorHelper.SetErrorLabel(true, invalidinputtext + " " + exception.Message, LabelError, false);
            }
            catch (ArgumentException exception)
            {
                transactionManager.RollbackTransaction();
                ErrorHelper.SetErrorLabel(true, invalidinputtext + " " + exception.Message, LabelError, false);
            }
            catch (Exception exception)
            {
                transactionManager.RollbackTransaction();
                ErrorHelper.HandleException(exception, transactionManager, LabelError);
            }
        }

        private void BindPackageTypes()
        {
            ChainEntity chainEntity = RepositoryHelper.GetChainEntityForCurrentUser();

            IList<PackagingDefine> packageTypes = ProductServices.GetAllPackageTypes(CurLangCode, 0, 0, chainEntity.Uid).Where(pt => pt.PackTypeCategory.Uid == 4).ToList();

            Session["packageTypes"] = packageTypes;
            DropDownListPackageType.DataSource = packageTypes;
            DropDownListPackageType.DataTextField = "name";
            DropDownListPackageType.DataValueField = "uid";
            DropDownListPackageType.DataBind();

            FillDataForSelectedPackageTypes();
        }

        private void FillDataForSelectedPackageTypes()
        {
            List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];

            if (packageTypes.Any())
            {
                if (DropDownListPackageType.SelectedValue != "")
                {
                    var selectedPackageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
                    LabelLenght.Text = selectedPackageType.LenghtValue + " " + selectedPackageType.LengthUoM.Name;
                    LabelWidth.Text = selectedPackageType.WidthValue + " " + selectedPackageType.WidthUoM.Name;
                    LabelWeight.Text = selectedPackageType.WeightValue + " " + selectedPackageType.WeightUoM.Name;
                    LabelHeight.Text = selectedPackageType.HeightValue + " " + selectedPackageType.HeightUoM.Name;
                    LabelMaterial.Text = selectedPackageType.PackagingMaterial.Name;
                    LabelSealed.Text = selectedPackageType.IsSealed.ToString();
                    LabelVentilated.Text = selectedPackageType.IsVantilated.ToString();
                }

            }
        }

        protected void DropDownListPackageType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {                
                FillDataForSelectedPackageTypes();
                List<PackagingDefine> packageTypes = (List<PackagingDefine>)Session["packageTypes"];
                PackagingDefine packageType = null;
                if (packageTypes.Any())
                {
                    if (DropDownListPackageType.SelectedValue != "")
                    {
                        packageType = packageTypes.Where(p => p.Uid == Int64.Parse(DropDownListPackageType.SelectedValue)).FirstOrDefault();
                    }
                }                
            }
            catch (Exception ex)
            {
                ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);                
            }
        }

        protected void lbxDisposalPackages_SelectedIndexChanged(object sender, EventArgs e)
        {
          try
            {
              foreach (ListItem item in lbxDisposalPackages.Items)
              {
                if (item.Selected)
                {
                  lbtPackPackingWaste.Visible = true;
                  break;
                }
              } 
            }
            catch(Exception ex)
            {
               ErrorHelper.SetErrorLabel(true, ex.ToString(), LabelError, true);
            }
         }

        private void ValidateIdentifications(ChainEntity chainEntity)
        {
            long from;

            bool fromIsNumeric = Int64.TryParse(txtIdenfication.Text, out from);

            if (fromIsNumeric == false)
            {
                ErrorHelper.SetErrorLabel(true, Resources.Localization.Theidentificationisnotnumeric, LabelError, false);                                   
            }

            if (from < 0)
            {
                ErrorHelper.SetErrorLabel(true, Resources.Localization.Identificationscannotbenegative, LabelError, false);                                   
            }

            ValidateIdentificationsExistance(from, from, chainEntity);
        }

        private void ValidateIdentificationsExistance(long from, long to, ChainEntity chainEntity)
        {
            for (long counter = from; counter <= to; counter++)
            {
                if (RepositoryHelper.IdentificationExists(counter.ToString(), chainEntity))
                {
                    ErrorHelper.SetErrorLabel(true, Resources.Localization.Theidentificationisalreadyused, LabelError, false);                                       
                }
            }
        }

        private List<Identification> GetPackageIdentifications(ChainEntity chainEntity, long fromUid, long toUid)
        {
            List<Identification> packageIdentifications = new List<Identification>();
            Identification identification = new Identification(string.Empty, chainEntity, fromUid, toUid);
            packageIdentifications.Add(identification);
            return packageIdentifications;
        }

        protected void ddlPackageMaterial_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindingDisposalPackages();
        }    
    }
}