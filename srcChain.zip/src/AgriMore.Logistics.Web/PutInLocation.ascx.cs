using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;

namespace AgriMore.Logistics.Web
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PutInLocation : UserControl
    {
        private Package package;
        private readonly RepositoryFactory repositoryFactory = new RepositoryFactory();
        private bool startDateHasBeenSet;

        private Location selectedLocation;
        private Location GetSelectedLocation()
        {
            if (selectedLocation == null)
            {
                selectedLocation =
                    repositoryFactory.GetLocationRepository().GetOne(long.Parse(DropDownListLocations.SelectedValue));
            }
            return selectedLocation;
        }

        /// <summary>
        /// Gets the exposures.
        /// </summary>
        /// <value>The exposures.</value>
        public Exposures ExposureControl
        {
            get { return ExposuresControl; }
        }

        /// <summary>
        /// Gets the date of placement.
        /// </summary>
        /// <value>The date of placement.</value>
        public DateTime DateOfPlacement
        {
            get { return DateOfPlacementControl.GetDatetime(); }
        }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!startDateHasBeenSet)
                {
                    DateOfPlacementControl.SetStartDateTime(DateTime.Now);
                }

                FillInDropDown();
            }
            else
            {
                Page.Validate();
            }
        }

        /// <summary>
        /// Fills the in drop down.
        /// </summary>
        public void FillInDropDown()
        {
            DropDownListLocations.Items.Clear();

            User user =
                repositoryFactory.GetUserRepository().GetOne(new UserByUserNameSpecification(Page.User.Identity.Name));
            ChainEntity ce =
                repositoryFactory.GetChainEntityRepository().GetOne(new ChainEntityForTheUserSpecification(user));
            //ICollection<Location> locations =
            //    repositoryFactory.GetLocationRepository().Find(new LocationForChainEntitySpecification(ce));

            foreach (Location location in ce.Locations)
            {
                if (package == null || !location.Contains(package))
                {
                    DropDownListLocations.Items.Add(new ListItem(location.Name, location.Uid.ToString()));
                }
            }
        }

        /// <summary>
        /// Adds the package to location.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="user">The user.</param>
        public void AddPackageToLocation(Package package, User user)
        {
            Location location = GetSelectedLocation();

            IEnumerable<Exposure> exposures = ExposuresControl.GetExposureDocument();
            location.Put(package, exposures, DateOfPlacement);

            repositoryFactory.GetLocationRepository().Store(location);
            repositoryFactory.GetPackageRepository().Store(package);
        }

        /// <summary>
        /// Creates the processing steps.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="user">The user.</param>
        /// <param name="remark">The remark.</param>
        public void CreateProcessingSteps(Package package, User user, string remark)
        {
            if (remark == null || remark.Trim().Length == 0)
            {
                remark = CreateVpsRemark(DateOfPlacement);
            }

            RepositoryHelper.CreateProcessingSteps(package, package.CurrentExposureDocument, ProcessingStepType.Exposures, user, remark);
        }


        /// <summary>
        /// Creates the VPS remark.
        /// </summary>
        /// <param name="dateOfPlacement">The date of placement.</param>
        /// <returns></returns>
        private string CreateVpsRemark(DateTime dateOfPlacement)
        {
            return
                String.Format(ProcessingStepDocument.PutInLocation,
                              dateOfPlacement.ToString(ProcessingStepDocument.DateTimeFormat));
        }

        /// <summary>
        /// Sets the start date time.
        /// </summary>
        /// <param name="dateTime">The date time.</param>
        /// <returns></returns>
        public void SetStartDateTime(DateTime dateTime)
        {
            DateOfPlacementControl.SetStartDateTime(dateTime);
            startDateHasBeenSet = true;
        }

        /// <summary>
        /// Initializes the specified package.
        /// </summary>
        /// <param name="package">The package.</param>
        public void Initialize(Package package)
        {
            if (package == null)
            {
                throw new ArgumentNullException(Resources.Localization.Package);
            }

            //ExposuresControl.Initialize(package);
            this.package = package;
        }
    }
}