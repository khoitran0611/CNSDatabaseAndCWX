using System;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Web
{
    public partial class TempPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
                RepositoryFactory rf = new RepositoryFactory();

                foreach (ChainEntity chainEntity in rf.GetChainEntityRepository().AsCollection())
                {
                    TempUserControl cec = AddChainEntityControl(chainEntity);
                }

           
            //}
        }

        private TempUserControl AddChainEntityControl(ChainEntity ce)
        {
            TempUserControl chainEntityControl = (TempUserControl)Page.LoadControl("TempUserControl.ascx");
            chainEntityControl.ID = ce.Uid.ToString();
            //chainEntityControl.Initialize(ce);
            
            for (int x = 0; x < 10; x++)
            {
                TempUserControlChild tucc = (TempUserControlChild)Page.LoadControl("TempUserControlChild.ascx");
                tucc.ID = "TUCC" + x;
                chainEntityControl.AddChild(tucc);
               
            }
            PlaceHolderChainEntity.Controls.Add(chainEntityControl);

            return chainEntityControl;
        }


    }
}
