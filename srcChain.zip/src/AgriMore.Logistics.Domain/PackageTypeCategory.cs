using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// This class functions as a umbrella / filter for the PackagTypes
    /// </summary>
    public class PackageTypeCategory : IIdentifyable
    {
        ///// <summary>
        ///// 
        ///// </summary>
        //public static PackageTypeCategory wholesalePackaging;

        ///// <summary>
        ///// 
        ///// </summary>
        //public static PackageTypeCategory retailPackaging;


        private readonly string name;
        private long uid;

        /// <summary>
        /// Initializes a new instance of the <see cref="PackageTypeCategory"/> class.
        /// </summary>
        protected PackageTypeCategory()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PackageTypeCategory"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public PackageTypeCategory(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            if (name.Trim().Length == 0)
            {
                throw new ArgumentException("PackageTypeCategory.name cannot be empty.", "name");
            }

            this.name = name;
        }

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return name; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            PackageTypeCategory other = obj as PackageTypeCategory;
            if (other == null)
            {
                return false;
            }
            if (other.name == name)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return name.GetHashCode();
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return uid.ToString();
        }
    }
}