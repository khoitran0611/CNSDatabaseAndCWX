using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Measured Temparature, at a specific date and time.
    /// </summary>
    public class MeasuredValue : IComparable<MeasuredValue>, ITimeableMeasurement, IIdentifyable, ICloneable
    {
        private long uid;
        private readonly DateTime dateTimeOfMeasurement;
        private readonly double value;

        /// <summary>
        /// Initializes a new instance of the <see cref="MeasuredValue"/> class.
        /// </summary>
        protected MeasuredValue()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MeasuredValue"/> class.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="dateTimeOfMeasurement">The date time of measurement.</param>
        public MeasuredValue(double value, DateTime dateTimeOfMeasurement)
        {
            this.value = value;
            this.dateTimeOfMeasurement = dateTimeOfMeasurement;
        }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        public double Value
        {
            get { return value; }
        }

        #region IComparable<MeasuredValue> Members

        /// <summary>
        /// Compares the current object with another object of the same type.
        /// </summary>
        /// <param name="other">An object to compare with this object.</param>
        /// <returns>
        /// A 32-bit signed integer that indicates the relative order of the objects being compared. The return value has the following meanings: Value Meaning Less than zero This object is less than the other parameter.Zero This object is equal to other. Greater than zero This object is greater than other.
        /// </returns>
        public int CompareTo(MeasuredValue other)
        {
            return value.CompareTo(other.value);
        }

        #endregion

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        #region ITimeableMeasurement Members

        /// <summary>
        /// Gets the date time of measurement.
        /// </summary>
        /// <value>The date time of measurement.</value>
        public DateTime DateTimeOfMeasurement
        {
            get { return dateTimeOfMeasurement; }
        }

        #endregion

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return string.Format("{0} �C at {1}", value, dateTimeOfMeasurement);
        }

        #region ICloneable Members

        ///<summary>
        ///Creates a new object that is a copy of the current instance.
        ///</summary>
        ///
        ///<returns>
        ///A new object that is a copy of this instance.
        ///</returns>
        ///<filterpriority>2</filterpriority>
        public object Clone()
        {
            return new MeasuredValue(this.Value, this.DateTimeOfMeasurement);
        }

        #endregion
    }
}