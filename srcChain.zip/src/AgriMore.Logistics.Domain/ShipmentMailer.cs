using System;
using System.Configuration;
using System.Net.Mail;
using log4net;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Mails created shipments
    /// This class sends a mail to the ChainEntity (Forwarder, Receiver) when the shipper create/change a shipment 
    /// </summary>
    public class ShipmentMailer
    {
        private readonly string bodyTemplate;
        private readonly string senderEmailAddress;
        private readonly string subject;
        private readonly ILog log = LogManager.GetLogger(typeof (ShipmentMailer));

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentMailer"/> class.
        /// </summary>
        /// <param name="senderEmailAddress">The sender mail.</param>
        /// <param name="subject">The subject.</param>
        /// <param name="bodyTemplate">The body template.</param>
        public ShipmentMailer(string senderEmailAddress, string subject, string bodyTemplate)
        {
            if (senderEmailAddress == null)
                throw new ArgumentNullException("senderEmailAddress");
            if (subject == null)
                throw new ArgumentNullException("subject");
            if (bodyTemplate == null)
                throw new ArgumentNullException("bodyTemplate");

            if (senderEmailAddress.Trim().Length == 0)
                throw new ArgumentException("senderEmailAddress cannot be empty", "senderEmailAddress");
            if (subject.Trim().Length == 0)
                throw new ArgumentException("subject cannot be empty", "subject");
            if (bodyTemplate.Trim().Length == 0)
                throw new ArgumentException("bodyTemplate cannot be empty", "bodyTemplate");

            this.senderEmailAddress = senderEmailAddress;
            this.subject = subject;
            this.bodyTemplate = bodyTemplate;
        }


        /// <summary>
        /// Gets the sender mail.
        /// </summary>
        /// <value>The sender mail.</value>
        public string SenderEmailAddress
        {
            get { return senderEmailAddress; }
        }

        /// <summary>
        /// Gets the subject.
        /// </summary>
        /// <value>The subject.</value>
        public string Subject
        {
            get { return subject; }
        }

        /// <summary>
        /// Gets the body template.
        /// </summary>
        /// <value>The body template.</value>
        public string BodyTemplate
        {
            get { return bodyTemplate; }
        }

        /// <summary>
        /// Sends the mail.
        /// </summary>
        public bool Send(Shipment shipment, Address shipperAddress, Address deliverAddress)
        {
            if (shipment == null)
                throw new ArgumentNullException("shipment");

            try
            {
                string shipperAddressData = shipperAddress.StreetName + "\n" + shipperAddress.ZipCode + " " +
                                            shipperAddress.City +
                                            "\n" + shipperAddress.Country.Name;

                MailMessage message = new MailMessage();

                message.From = new MailAddress(senderEmailAddress);

                message.To.Add(shipment.ForwarderMailaddress);
                message.CC.Add(shipment.ReceiverMailaddress);
                message.Subject = subject;
                message.Body = bodyTemplate + " \n" + shipperAddressData + "\n" +
                               "Shipment identification: " + shipment.Uid + "\n" +
                               "Pickup Address: " + shipperAddress.StreetName + "\n" +
                               "Pickup Location: " + shipment.PickupLocation.Name +
                               "Pickup date: " + shipment.PickUpDateTimeRange.Start + "-" +
                               shipment.PickUpDateTimeRange.End + "\n" +
                               "Deliver Address: " + deliverAddress.StreetName + "\n" +
                               "Deliver Location: " + shipment.DeliveryLocation.Name + "\n" +
                               "Deliver date: " + shipment.DeliverDateTimeRange.Start + "-" +
                               shipment.DeliverDateTimeRange.End + "\n";

                SmtpClient smtpClient = new SmtpClient();


                String enableSSL = ConfigurationManager.AppSettings["EnableSSL"];

                smtpClient.EnableSsl = enableSSL == "true";
                smtpClient.Send(message);
            }
            catch (Exception exception)
            {
                log.Error("No mail could be send.", exception);
                throw new ArgumentException("Mail message could not be send, invalid mail parameter(s).");
            }
            return true;
        }
    }
}