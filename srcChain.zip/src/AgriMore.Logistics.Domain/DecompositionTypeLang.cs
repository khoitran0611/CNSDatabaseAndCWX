﻿using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;
using System.Collections.Generic;
using System.Linq;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class DecompositionTypeLang : IIdentifyable
    {
        private long uid;
        private string name;
        private string langCode;
        private DecompositionType decompositionType;
        private ISet decompositionTypeLangs = new HashedSet();

        /// <summary>
        /// 
        /// </summary>
        public DecompositionTypeLang()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="langCode"></param>
        /// <param name="category"></param>
        public DecompositionTypeLang(string name, string langCode, DecompositionType category)
        {
            this.name = name;
            this.langCode = langCode;
            this.decompositionType = category;
        }

        /// <summary>
        /// Gets or sets the Uid
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Gets or sets the LangCode
        /// </summary>
        public string LangCode
        {
            get { return langCode; }
            set { langCode = value; }
        }

        /// <summary>
        /// Gets or sets the CategoryType
        /// </summary>
        public DecompositionType DecompositionType
        {
            get { return decompositionType; }
            set { decompositionType = value; }
        }

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            DecompositionTypeLang categoryLang = CategoryLangs.Where(it => it.LangCode.Equals(langCode)).SingleOrDefault();

            return categoryLang == null ? Name : categoryLang.Name;
        }

        /// <summary>
        /// Gets or sets the CatTypeLangs.
        /// </summary>
        public IList<DecompositionTypeLang> CategoryLangs
        {
            get { return ListHandler.ConvertToGenericList<DecompositionTypeLang>(decompositionTypeLangs); }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="categoryLang"></param>
        public void AddDecompositionTypeLangToList(DecompositionTypeLang categoryLang)
        {
            decompositionTypeLangs.Add(categoryLang);
        }

        /// <summary>
        /// Remove CategoryLangs
        /// </summary>
        public void RemoveDecompositionTypeLangFromList()
        {
            decompositionTypeLangs.Clear();
        }

        /// <summary>
        /// Remove CategoryLangs
        /// </summary>
        public void RemoveDecompositionTypeLangFromList(DecompositionTypeLang categoryLang)
        {
            decompositionTypeLangs.Remove(categoryLang);
        }
    }
}
