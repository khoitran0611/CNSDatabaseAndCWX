using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// The Exposure contains the prescribed and actual temperatures for a primary product
    /// for the time that it is in a specific location.
    /// 
    /// A new exposure needs to be created when the primary product moves to another location.
    /// </summary>
    public class Exposure :  IIdentifyable,ICloneable
    {
        // the actual values
        //RVL: replaced SortedList by HashedSet.
        //private readonly SortedList<DateTime, MeasuredValue> actuals = new SortedList<DateTime, MeasuredValue>();
        private ISet actuals = new HashedSet();

        //RVL: replaced IRange by separate values.
        // the prescribed range
        //private readonly IRange<MeasuredValue> prescribedRange;
        private readonly MeasuredValue prescribedStart;
        private readonly MeasuredValue prescribedEnd;

        //RVL: replaced IRange by separate values.
        // uses a range of dateTime and delegates to be one
        //private readonly IRange<DateTime> range;
        private readonly DateTime startDateTime;
        private DateTime endDateTime;

        private readonly ExposureType exposureType;

        private readonly long exposureDefineId;
        private long uid;

        /// <summary>
        /// Initializes a new instance of the <see cref="Exposure"/> class.
        /// </summary>
        protected Exposure()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Exposure"/> class.
        /// </summary>
        /// <param name="startRange">The start range.</param>
        /// <param name="endRange">The end range.</param>
        /// <param name="prescribeDateTime">The prescribe date time.</param>
        /// <param name="actuals">The actuals.</param>
        /// <param name="exposureType">Type of the exposure.</param>
        public Exposure(double startRange, double endRange, DateTime prescribeDateTime, IEnumerable<MeasuredValue> actuals, ExposureType exposureType)
            : this(new Range<MeasuredValue>(new MeasuredValue(startRange, prescribeDateTime), new MeasuredValue(endRange, prescribeDateTime)), actuals, exposureType)
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startRange"></param>
        /// <param name="endRange"></param>
        /// <param name="prescribeDateTime"></param>
        /// <param name="actuals"></param>
        /// <param name="exposureDefineId"></param>
        public Exposure(double startRange, double endRange, DateTime prescribeDateTime, IEnumerable<MeasuredValue> actuals, long exposureDefineId)
            : this(new Range<MeasuredValue>(new MeasuredValue(startRange, prescribeDateTime), new MeasuredValue(endRange, prescribeDateTime)), actuals, exposureDefineId)
        {

        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Exposure"/> class.
        /// </summary>
        /// <param name="prescribedRange">The prescribed range.</param>
        /// <param name="actuals">The actuals.</param>
        /// <param name="exposureType">Type of the exposure.</param>
        public Exposure(IRange<MeasuredValue> prescribedRange, IEnumerable<MeasuredValue> actuals, ExposureType exposureType)
        {
            if (exposureType == null)
            {
                throw new ArgumentNullException("exposureType");
            }

            if (prescribedRange == null)
            {
                throw new ArgumentNullException("prescribedRange");
            }

            if (prescribedRange.Start.DateTimeOfMeasurement > DateTime.Now)
            {
                throw new ArgumentException("prescribed dateTime cannot be in the future on an exposure");
            }

            IRange<DateTime> range = new Range<DateTime>(prescribedRange.Start.DateTimeOfMeasurement);

            foreach (MeasuredValue actual in actuals)
            {
                if (actual.DateTimeOfMeasurement > DateTime.Now)
                {
                    throw new ArgumentException(
                        "dateTimeOfMeasurement of actual exposure cannot be in the future on an exposure");
                }

                this.actuals.Add(actual);
                range.Extend(actual.DateTimeOfMeasurement);
            }

            startDateTime = range.Start;
            endDateTime = range.End;
           
            prescribedStart = prescribedRange.Start;
            prescribedEnd = prescribedRange.End;

            this.exposureType = exposureType;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="prescribedRange"></param>
        /// <param name="actuals"></param>
        /// <param name="exposureDefineId"></param>
        public Exposure(IRange<MeasuredValue> prescribedRange, IEnumerable<MeasuredValue> actuals, long exposureDefineId)
        {
            //if (exposureDefineId == null)
            //{
            //    throw new ArgumentNullException("exposureDefine");
            //}

            if (prescribedRange == null)
            {
                throw new ArgumentNullException("prescribedRange");
            }

            if (prescribedRange.Start.DateTimeOfMeasurement > DateTime.Now)
            {
                throw new ArgumentException("prescribed dateTime cannot be in the future on an exposure");
            }

            IRange<DateTime> range = new Range<DateTime>(prescribedRange.Start.DateTimeOfMeasurement);

            foreach (MeasuredValue actual in actuals)
            {
                if (actual.DateTimeOfMeasurement > DateTime.Now)
                {
                    throw new ArgumentException(
                        "dateTimeOfMeasurement of actual exposure cannot be in the future on an exposure");
                }

                this.actuals.Add(actual);
                range.Extend(actual.DateTimeOfMeasurement);
            }

            startDateTime = range.Start;
            endDateTime = range.End;

            prescribedStart = prescribedRange.Start;
            prescribedEnd = prescribedRange.End;

            this.exposureDefineId = exposureDefineId;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets the start range value.
        /// </summary>
        /// <value>The start range value.</value>
        public double PrescribedStartValue
        {
            get { return prescribedStart.Value; }
        }

        /// <summary>
        /// Gets the prescribed end value.
        /// </summary>
        /// <value>The prescribed end value.</value>
        public double PrescribedEndValue
        {
            get { return prescribedEnd.Value; }
        }


        /// <summary>
        /// Gets the prescribed date time.
        /// </summary>
        /// <value>The prescribed date time.</value>
        public DateTime PrescribedDateTime
        {
            get { return prescribedStart.DateTimeOfMeasurement; }
        }
        /// <summary>
        /// Gets the start of the range.
        /// </summary>
        /// <value>The start.</value>
        public DateTime Start
        {
            get { return startDateTime; }
        }

        /// <summary>
        /// Gets the end of the range.
        /// </summary>
        /// <value>The end.</value>
        public DateTime End
        {
            get { return endDateTime; }
        }

        /// <summary>
        /// Extends the end time with a specified later end time.
        /// </summary>
        /// <param name="furtherEnd">The later end time.</param>
        public void Extend(DateTime furtherEnd)
        {
            IRange<DateTime> range = new Range<DateTime>(startDateTime, endDateTime);
            range.Extend(furtherEnd);
            endDateTime = range.End;
        }

        /// <summary>
        /// Determines whether this range contains the specified value to find.
        /// </summary>
        /// <param name="valueToFind">The value to find.</param>
        /// <returns>
        /// 	<c>true</c> if this range contains the specified value to find; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(DateTime valueToFind)
        {
            IRange<DateTime> range = new Range<DateTime>(startDateTime, endDateTime);
            return range.Contains(valueToFind);
        }

        /// <summary>
        /// Adds the actual value for the dateTime specified. The dateTime used will be the new End of the interval
        /// </summary>
        /// <param name="actualValue">The actual measurement.</param>
        /// <returns>the previous value</returns>
        public void AddActualValue(MeasuredValue actualValue)
        {
            if (actualValue.DateTimeOfMeasurement > DateTime.Now)
            {
                throw new ArgumentException(
                    "dateTimeOfMeasurement of actual exposure cannot be in the future on an exposure");
            }
            if (actualValue.DateTimeOfMeasurement < Start)
            {
                throw new ArgumentException("dateTimeOfMeasurement cannot be before the start of the exposure");
            }


            //overwrite if dateTimeOfMeasurement already exists.
            foreach(MeasuredValue measuredValue in actuals)
            {
                if (measuredValue.DateTimeOfMeasurement == actualValue.DateTimeOfMeasurement)
                {
                    actuals.Remove(measuredValue);
                    break;
                }
            }
            actuals.Add(actualValue);

            IRange<DateTime> range = new Range<DateTime>(startDateTime, endDateTime);
            range.Extend(actualValue.DateTimeOfMeasurement);
            endDateTime = range.End;
        }

        /// <summary>
        /// 
        /// Returns enumerable to values, so that you can iterate over the actual values.
        /// The values are sorted by dateTime.
        /// </summary>
        /// <value>The values.</value>
        public IEnumerable<MeasuredValue> Values
        {
            get
            {
                foreach (MeasuredValue measuredValue in actuals)
                {
                    yield return measuredValue;
                }
            }
        }

        /// <summary>
        /// Gets the prescribed range.
        /// </summary>
        /// <value>The prescribed range.</value>
        public IRange<MeasuredValue> PrescribedRange
        {
            get
            {
                return new Range<MeasuredValue>(prescribedStart, prescribedEnd);
            }
        }

        /// <summary>
        /// Gets the type of the exposure.
        /// </summary>
        /// <value>The type of the exposure.</value>
        public ExposureType ExposureType
        {
            get { return exposureType; }
        }


        public long ExposureDefineId
        {
            get { return exposureDefineId; }
        }

        #region ICloneable Members

        ///<summary>
        ///Creates a new object that is a copy of the current instance.
        ///</summary>
        ///
        ///<returns>
        ///A new object that is a copy of this instance.
        ///</returns>
        ///<filterpriority>2</filterpriority>
        public object Clone()
        {

            IRange<MeasuredValue> preRange =
                new Range<MeasuredValue>((MeasuredValue)this.PrescribedRange.Start.Clone(),
                                         (MeasuredValue)this.PrescribedRange.End.Clone());

            IList<MeasuredValue> clonedActuals = new List<MeasuredValue>();

            foreach (MeasuredValue value in this.actuals)
            {
                clonedActuals.Add((MeasuredValue)value.Clone());
            }

            return new Exposure(preRange, clonedActuals, this.exposureType);
        }

        #endregion
    }
}