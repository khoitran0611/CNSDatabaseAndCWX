using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

namespace AgriMore.Logistics.Domain.Repository.Memory
{
    /// <summary>
    /// Memory imp of repository, using a elements.
    /// 
    /// the objects in the repository need to implement ToString, GetHashCode and Equals in the following way:
    /// ToString mist return the 'name' of the element, normaly the human readable string of the object.
    /// (a Name property for instance, or some string id on which the user can identify the object)
    /// Equals must check equality of the object, and will be used to see if an object can be added to the repository
    /// or if it already exists. (unique equality, as in a unique constraint)
    /// GetHashCode must return a semi-unique value of the object (the object must reside in a bucket of the elements)
    /// and as unique as possible. the 'name' string is a good candidate.
    /// 
    /// </summary>
    /// <typeparam name="TElement">The type of the element.</typeparam>
    public class MemoryMapRepository<TElement> : IRepository<TElement> where TElement : class, IIdentifyable
    {
        private static long idGen = 0;
        private readonly List<TElement> elements = new List<TElement>();
        private readonly IDictionary<long, TElement> mapIds = new Dictionary<long, TElement>();

        #region IRepository<TElement> Members

        /// <summary>
        /// Gets the Element by idGen.
        /// </summary>
        /// <param name="id">The idGen.</param>
        /// <returns></returns>
        public TElement GetOne(string id)
        {
            if (id == null)
            {
                throw new ArgumentNullException("id");
            }
            if (id.Trim() == string.Empty)
            {
                throw new ArgumentException("id parameter cannot be empty");
            }
            foreach (TElement element in elements)
            {
                if (element.ToString().Equals(id))
                {
                    return element;
                }
            }
            return null;
        }

        /// <summary>
        /// Gets the Element by unique idGen.
        /// </summary>
        /// <param name="uid">The uid.</param>
        /// <returns></returns>
        public TElement GetOne(long uid)
        {
            if (mapIds.ContainsKey(uid))
            {
                return mapIds[uid];
            }
            return null;
        }

        /// <summary>
        /// Adds the specified element. returns the uid.
        /// After the element is added you can assign the returning idGen to the element yourself
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns></returns>
        public long Add(TElement element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }
            if (element.Uid != 0)
            {
                throw new ArgumentException("uid of element is already assigned, cannot add element");
            }
            // check if element already exists
            if (Contains(element))
            {
                throw new ArgumentException("Unique constraint violation");
            }
            long newId = Interlocked.Increment(ref idGen);
            element.Uid = newId;
            mapIds.Add(newId, element);
            elements.Add(element);
            return newId;
        }

        /// <summary>
        /// Returns all elements as a collection
        /// </summary>
        /// <returns></returns>
        public ICollection<TElement> AsCollection()
        {
            return elements;
        }

        /// <summary>
        /// Determines whether [contains] [the specified shipment].
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if [contains] [the specified shipment]; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(TElement element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }
            return elements.Contains(element);
        }

        /// <summary>
        /// Gets the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns></returns>
        public TElement GetOne(ISpecification<TElement> criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException("criteria");
            }
            DictionarySpecificationExecutor<long, TElement> exec =
                new DictionarySpecificationExecutor<long, TElement>(mapIds);
            return exec.GetOne(criteria);
        }

        /// <summary>
        /// Finds the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns></returns>
        public ICollection<TElement> Find(ISpecification<TElement> criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException("criteria");
            }

            DictionarySpecificationExecutor<long, TElement> exec =
                new DictionarySpecificationExecutor<long, TElement>(mapIds);
            return exec.Find(criteria);
        }


        /// <summary>
        /// Removes the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        public void Remove(ISpecification<TElement> criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException("criteria");
            }

            DictionarySpecificationExecutor<long, TElement> exec =
                new DictionarySpecificationExecutor<long, TElement>(mapIds);
            exec.Remove(criteria);
        }

        /// <summary>
        /// Counts the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns></returns>
        public long Count(ISpecification<TElement> criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException("criteria");
            }

            DictionarySpecificationExecutor<long, TElement> exec =
                new DictionarySpecificationExecutor<long, TElement>(mapIds);
            return exec.Count(criteria);
        }

        /// <summary>
        /// Counts the elements.
        /// </summary>
        /// <returns>The number of elements</returns>
        public long Count()
        {
            return mapIds.Count;
        }

        /// <summary>
        /// Stores the specified element. Equals needs to be implemented on the element.
        /// Equals is used to see if the element needs to be updated or added.
        /// </summary>
        /// <param name="element">The element.</param>
        public void Store(TElement element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }
            if (element.Uid == 0)
            {
                Add(element);
            }
            else
            {
                int pos = -1;
                if (-1 != (pos = elements.IndexOf(element)))
                {
                    // found an equal element. Equals implemented as equal when same unique string id.
                    foreach (KeyValuePair<long, TElement> pair in mapIds)
                    {
                        if (pair.Value.Equals(element))
                        {
                            long uid = pair.Key;
                            elements[pos] = element;
                            mapIds[uid] = element;
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Forces the underlying database to reflect the changes in order to get the generated UId's of objects and the
        /// assiated objects.
        /// </summary>
        public void Flush()
        {
        }

        /// <summary>
        /// Forces the underlying database to reflect the changes in order to get the generated UId's of objects and the
        /// assiated objects.
        /// </summary>
        public void Refresh(TElement element)
        {
        }

        /// <summary>
        /// Removes the specified element. Equals needs to be implemented on the element.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// true if the element could be removed, false if not
        /// </returns>
        public bool Remove(TElement element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }
            long foundUid = 0;
            bool found = false;
            foreach (KeyValuePair<long, TElement> pair in mapIds)
            {
                if (pair.Value.Equals(element))
                {
                    foundUid = pair.Key;
                    found = true;
                    break;
                }
            }
            if (found)
            {
                mapIds.Remove(foundUid);
            }
            return elements.Remove(element);
        }


        /// <summary>
        /// Returns an enumerator that iterates through the collection.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.Collections.Generic.IEnumerator`1"></see> that can be used to iterate through the collection.
        /// </returns>
        public IEnumerator<TElement> GetEnumerator()
        {
            return elements.GetEnumerator();
        }

        /// <summary>
        /// Returns an enumerator that iterates through a collection.
        /// </summary>
        /// <returns>
        /// An <see cref="T:System.Collections.IEnumerator"></see> object that can be used to iterate through the collection.
        /// </returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        #endregion
    }
}