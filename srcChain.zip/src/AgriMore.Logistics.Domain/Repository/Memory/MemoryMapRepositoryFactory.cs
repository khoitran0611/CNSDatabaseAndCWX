using System;
using System.Diagnostics;
using AgriMore.Logistics.Domain.Transaction;
using AgriMore.Logistics.Domain.Transaction.Memory;

namespace AgriMore.Logistics.Domain.Repository.Memory
{
    /// <summary>
    /// This class is used for retrieving the domain repositories
    /// </summary>
    public class MemoryMapRepositoryFactory : IRepositoryFactory
    {
        /// <summary>
        /// The ChainEntityRepositoryName.
        /// </summary>
        public const string ChainEntityRepositoryName = "MemoryChainEntityRepository";

        /// <summary>
        /// The packageRepositoryName.
        /// </summary>
        public const string packageRepositoryName = "MemoryPackageRepository";

        private static readonly IRepository<Address> addressRepository = new MemoryMapRepository<Address>();
        private static readonly IRepository<ChainEntity> chainEntityRepository = new MemoryMapRepository<ChainEntity>();
        private static readonly IRepository<Location> locationRepository = new MemoryMapRepository<Location>();

        private static readonly IRepository<AgriMoreTimeZone> memoryAgriMoreTimeZoneRepository =
            new MemoryMapRepository<AgriMoreTimeZone>();

        private static readonly IRepository<Country> memoryCountryRepository =
            new MemoryMapRepository<Country>();

        private static readonly IRepository<ExposureType> memoryExposureTypeRepository =
            new MemoryMapRepository<ExposureType>();

        private static readonly IRepository<PackageTypeCategory> memoryPackageTypeCategoryRepository =
            new MemoryMapRepository<PackageTypeCategory>();

        private static readonly IRepository<PackageType> memoryPackageTypeRepository =
            new MemoryMapRepository<PackageType>();

        private static readonly IRepository<PackingMaterial> memoryPackingMaterialRepository =
            new MemoryMapRepository<PackingMaterial>();

        private static readonly IRepository<TransportEquipment> memoryTransportEquipmentRepository =
            new MemoryMapRepository<TransportEquipment>();

        private static readonly IRepository<TreatmentTypeCategory> memoryTreatmentTypeCategoryRepository =
            new MemoryMapRepository<TreatmentTypeCategory>();

        private static readonly IRepository<UnitOfMeasurement> memoryUnitOfMeasurementRepository =
            new MemoryMapRepository<UnitOfMeasurement>();

        private static readonly IRepository<User> memoryUserRepository = new MemoryMapRepository<User>();
        private static readonly IRepository<Package> packageRepository = new MemoryMapRepository<Package>();
        private static readonly IRepository<DisposalPackage> disposalPackageRepository = new MemoryMapRepository<DisposalPackage>();
        private static readonly IRepository<Role> roleRepository = new MemoryMapRepository<Role>();
        private readonly IRepository<TreatmentType> treatmentTypeRepository = new MemoryMapRepository<TreatmentType>();

        private readonly IRepository<ExposureDocument> exposureDocumentRepository =
            new MemoryMapRepository<ExposureDocument>();

        private readonly IRepository<Identification> identificationRepository =
            new MemoryMapRepository<Identification>();


        private readonly IRepository<Exposure> memoryExposureRepository =
            new MemoryMapRepository<Exposure>();

        private readonly IRepository<Shipment> memoryShipmentRepository = new MemoryMapRepository<Shipment>();

        private readonly IRepository<ProcessingStep> processingStepRepository =
            new MemoryMapRepository<ProcessingStep>();

        private bool isFilled = false;
        private readonly IRepository<CashRegister> cashRegisterRepository =
    new MemoryMapRepository<CashRegister>();

        private readonly IRepository<RepackPackageRelationship> repackPackageRelationshipRepository = new MemoryMapRepository<RepackPackageRelationship>();
        private readonly IRepository<Treatment> treatmentRepository = new MemoryMapRepository<Treatment>();
        private readonly IRepository<PackagePackagingWasteInfo> packagePackagingWasteRepository = new MemoryMapRepository<PackagePackagingWasteInfo>();
        private readonly IRepository<ExposureDefine> exposureDefineRepository = new MemoryMapRepository<ExposureDefine>();

        private readonly IRepository<WasteDisposalPackageTracing> wasteDisposalPackageTracingRepository = new MemoryMapRepository<WasteDisposalPackageTracing>();
        private readonly IRepository<WasteDisposalDisposalPackage> wasteDisposalDisposalPackageRepository = new MemoryMapRepository<WasteDisposalDisposalPackage>();
        private readonly IRepository<WasteDisposalExpirePackage> wasteDisposalExpirePackageRepository = new MemoryMapRepository<WasteDisposalExpirePackage>();

        private readonly IRepository<Decomposition> decompositionRepository = new MemoryMapRepository<Decomposition>();
        private readonly IRepository<DecompositionInfo> decompositionInfoRepository = new MemoryMapRepository<DecompositionInfo>();



        /// <summary>
        /// Initializes the <see cref="RepositoryFactory"/> class.
        /// </summary>
        static MemoryMapRepositoryFactory()
        {
            Debug.WriteLine("MemoryMapRepositoryFactory static constructor.");
        }

        #region IRepositoryFactory Members

        /// <summary>
        /// Gets the treatment repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Treatment> GetTreatmentRepository()
        {
            Fill();
            return treatmentRepository;
        }

        /// <summary>
        /// Gets the identification repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Identification> GetIdentificationRepository()
        {
            Fill();
            return identificationRepository;
        }

        #endregion

        /// <summary>
        /// Gets the exposure document repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ExposureDocument> GetExposureDocumentRepository()
        {
            Fill();
            return exposureDocumentRepository;
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<PackageType> GetPackageTypeRepository()
        {
            Fill();
            return memoryPackageTypeRepository;
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<AgriMoreTimeZone> GetAgriMoreTimeZoneRepository()
        {
            Fill();
            return memoryAgriMoreTimeZoneRepository;
        }

        /// <summary>
        /// Gets the country repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Country> GetCountryRepository()
        {
            Fill();
            return memoryCountryRepository;
        }

        /// <summary>
        /// Gets the packing material repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<PackingMaterial> GetPackingMaterialRepository()
        {
            Fill();
            return memoryPackingMaterialRepository;
        }

        /// <summary>
        /// Gets the package type category repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<PackageTypeCategory> GetPackageTypeCategoryRepository()
        {
            Fill();
            return memoryPackageTypeCategoryRepository;
        }


        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<TreatmentTypeCategory> GetTreatmentTypeCategoryRepository()
        {
            Fill();
            return memoryTreatmentTypeCategoryRepository;
        }

        /// <summary>
        /// Gets the unit of measurement repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<UnitOfMeasurement> GetUnitOfMeasurementRepository()
        {
            Fill();
            return memoryUnitOfMeasurementRepository;
        }

        //memoryAgriMoreTimeZoneRepository


        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<User> GetUserRepository()
        {
            Fill();
            return memoryUserRepository;
        }

        /// <summary>
        /// Gets the exposure repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Exposure> GetExposureRepository()
        {
            Fill();
            return memoryExposureRepository;
        }

        /// <summary>
        /// Gets the exposure type repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ExposureType> GetExposureTypeRepository()
        {
            Fill();
            return memoryExposureTypeRepository;
        }

        /// <summary>
        /// retrieve a ChainEntity repository
        ///</summary>
        /// <returns></returns>
        public IRepository<ChainEntity> GetChainEntityRepository()
        {
            Fill();
            return chainEntityRepository;
        }


        /// <summary>
        /// Gets the role repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Role> GetRoleRepository()
        {
            Fill();
            return roleRepository;
        }

        /// <summary>
        /// retrieve a Location repository
        /// </summary>
        /// <returns></returns>
        public IRepository<Location> GetLocationRepository()
        {
            Fill();
            return locationRepository;
        }

        /// <summary>
        /// Gets the address repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Address> GetAddressRepository()
        {
            Fill();
            return addressRepository;
        }

        /// <summary>
        /// Gets the shipment repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Shipment> GetShipmentRepository()
        {
            Fill();
            return memoryShipmentRepository;
        }

        /// <summary>
        /// Gets the package repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Package> GetPackageRepository()
        {
            Fill();
            return packageRepository;
        }

        public IRepository<DisposalPackage> GetDisposalPackageRepository()
        {
            Fill();
            return disposalPackageRepository;
        }


        /// <summary>
        /// Gets the processing step repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ProcessingStep> GetProcessingStepRepository()
        {
            Fill();
            return processingStepRepository;
        }

        /// <summary>
        /// Gets the processing step repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<CashRegister> GetCashRegisterRepository()
        {
            Fill();
            return cashRegisterRepository;
        }

        /// <summary>
        /// Gets the repack package relationship repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<RepackPackageRelationship> GetRepackPackageRelationshipRepository()
        {
            Fill();
            return repackPackageRelationshipRepository;
        }


        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<TransportEquipment> GetTransportEquipmentRepository()
        {
            return memoryTransportEquipmentRepository;
        }

        /// <summary>
        /// Creates the repository.
        /// Implementation for when the dummy data goes exit.
        /// </summary>
        /// <typeparam name="TElement">The type of the element.</typeparam>
        /// <returns></returns>
        public IRepository<TElement> CreateRepository<TElement>() where TElement : class, IIdentifyable
        {
            Fill();

            return new MemoryMapRepository<TElement>();
        }

        /// <summary>
        /// Creates the transaction manager.
        /// </summary>
        /// <returns></returns>
        public ITransactionManager CreateTransactionManager()
        {
            return new MemoryMapTransactionManager();
        }

        /// <summary>
        /// Initializes the test data.
        /// </summary>
        public void InitializeTestData()
        {
            Debug.WriteLine("InitializeTestData");
        }


        /// <summary>
        /// Gets the treatment type repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<TreatmentType> GetTreatmentTypeRepository()
        {
            Fill();
            return treatmentTypeRepository;
        }



        private void Fill()
        {
            if (!isFilled)
            {
                isFilled = true;
                new DataFiller().Fill();
            }
        }


        public IRepository<PackagePackagingWasteInfo> GetPackagePackagingWasteInfoRepository()
        {
            Fill();
            return packagePackagingWasteRepository;
        }

        public IRepository<ExposureDefine> GetExposureDefineRepository()
        {
            Fill();
            return exposureDefineRepository;
        }


        public IRepository<WasteDisposalPackageTracing> GetWasteDisposalPackageTracingRepository()
        {
            Fill();
            return wasteDisposalPackageTracingRepository;
        }

        public IRepository<WasteDisposalDisposalPackage> GetWasteDisposalDisposalPackageRepository()
        {
            Fill();
            return wasteDisposalDisposalPackageRepository;
        }

        public IRepository<WasteDisposalExpirePackage> GetWasteDisposalExpirePackageRepository()
        {
            Fill();
            return wasteDisposalExpirePackageRepository;
        }

        public IRepository<Decomposition> GetDecompositionRepository()
        {
            Fill();
            return decompositionRepository;
        }

        public IRepository<DecompositionInfo> GetDecompositionInfoRepository()
        {
            Fill();
            return decompositionInfoRepository;
        }
    }
}