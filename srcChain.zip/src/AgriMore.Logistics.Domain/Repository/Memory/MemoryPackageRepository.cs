//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Threading;
//using Common.Logging;

//namespace AgriMore.Logistics.Domain.Repository.Memory
//{
//    /// <summary>
//    /// This class manages the packages in the system.
//    /// Creation of the packages is at this moment not a responsibility. 
//    /// It is the responcibilty of the creator of a package to add it to the repository.
//    /// </summary>
//    public class MemoryPackageRepository : IRepository<Package>
//    {
//        private static long id = 0;
//        private static readonly IDictionary<string, Package> packages = new Dictionary<string, Package>();

//        #region IRepository<Package> Members

//        /// <summary>
//        /// Adds the package to the complete list of packages in the system.
//        /// If a package is packed it's previous package should be removed from the repository
//        /// </summary>
//        /// <param name="package">The package.</param>
//        public long Add(Package package)
//        {
//            if (package == null)
//            {
//                throw new ArgumentNullException("package");
//            }


//            // Remove the childpackages from the packages because for the system these packages
//            // dont exist anymore. If this package is unpacked they can be added again.
//            //foreach (Package p in package.Children)
//            //{
//            //    packages.Remove(p.Uid.ToString());
//            //}

//            long newId = Interlocked.Increment(ref id);
//            package.Uid = newId;
//            packages.Add(package.Uid.ToString(), package);
//            return newId;
//        }

//        /// <summary>
//        /// Returns the package being asked for.
//        /// If the package is not found a keynotfoundexcption is thrown.
//        /// </summary>
//        /// <param name="identification">The identification.</param>
//        /// <returns></returns>
//        public Package GetOne(string identification)
//        {
//            if (identification == null) throw new ArgumentNullException("identification");

//            return packages[identification];
//        }

//        /// <summary>
//        /// Gets the Element by unique id.
//        /// </summary>
//        /// <param name="uid">The uid.</param>
//        /// <returns></returns>
//        public Package GetOne(long uid)
//        {
//            foreach (KeyValuePair<string, Package> pair in packages)
//            {
//                if (pair.Value.Uid == uid)
//                {
//                    return pair.Value;
//                }
//            }
//            return null;
//        }

//        /// <summary>
//        /// Returns all elements as a collection
//        /// </summary>
//        /// <returns></returns>
//        public ICollection<Package> AsCollection()
//        {
//            return packages.Values;
//        }

//        /// <summary>
//        /// Gets the specified criteria.
//        /// </summary>
//        /// <param name="criteria">The criteria.</param>
//        /// <returns></returns>
//        public Package GetOne(ISpecification<Package> criteria)
//        {
//            DictionarySpecificationExecutor<string, Package> exec =
//                new DictionarySpecificationExecutor<string, Package>(packages);
//            return exec.GetOne(criteria);
//        }


//        /// <summary>
//        /// Determines whether [contains] [the specified shipment].
//        /// </summary>
//        /// <param name="element">The element.</param>
//        /// <returns>
//        /// 	<c>true</c> if [contains] [the specified shipment]; otherwise, <c>false</c>.
//        /// </returns>
//        public bool Contains(Package element)
//        {
//            return packages.Values.Contains(element);
//        }

//        /// <summary>
//        /// Finds the specified criteria.
//        /// </summary>
//        /// <param name="criteria">The criteria.</param>
//        /// <returns></returns>
//        public ICollection<Package> Find(ISpecification<Package> criteria)
//        {
//            DictionarySpecificationExecutor<string, Package> exec =
//                new DictionarySpecificationExecutor<string, Package>(packages);
//            return exec.Find(criteria);
//        }


//        /// <summary>
//        /// Removes the specified criteria.
//        /// </summary>
//        /// <param name="criteria">The criteria.</param>
//        public void Remove(ISpecification<Package> criteria)
//        {
//            DictionarySpecificationExecutor<string, Package> exec =
//                new DictionarySpecificationExecutor<string, Package>(packages);
//            exec.Remove(criteria);
//        }

//        /// <summary>
//        /// Counts the specified criteria.
//        /// </summary>
//        /// <param name="criteria">The criteria.</param>
//        /// <returns></returns>
//        public long Count(ISpecification<Package> criteria)
//        {
//            DictionarySpecificationExecutor<string, Package> exec =
//                new DictionarySpecificationExecutor<string, Package>(packages);
//            return exec.Count(criteria);
//        }

//        /// <summary>
//        /// Counts the elements.
//        /// </summary>
//        /// <returns>The number of elements</returns>
//        public long Count()
//        {
//            return packages.Count;
//        }


//        /// <summary>
//        /// Stores the specified element. Equals needs to be implemented on the element.
//        /// Equals is used to see if the element needs to be updated or added.
//        /// </summary>
//        /// <param name="element">The element.</param>
//        public void Store(Package element)
//        {
//            throw new Exception("The method or operation is not implemented.");
//        }

//        /// <summary>
//        /// Removes the specified element. Equals needs to be implemented on the element.
//        /// </summary>
//        /// <param name="element">The element.</param>
//        /// <returns>
//        /// true if the element could be removed, false if not
//        /// </returns>
//        public bool Remove(Package element)
//        {
//            packages.Remove(element.Uid.ToString());
//            return true;
//        }

//        /// <summary>
//        /// Returns an enumerator that iterates through the collection.
//        /// </summary>
//        /// <returns>
//        /// A <see cref="T:System.Collections.Generic.IEnumerator`1"></see> that can be used to iterate through the collection.
//        /// </returns>
//        public IEnumerator<Package> GetEnumerator()
//        {
//            return packages.Values.GetEnumerator();
//        }

//        IEnumerator IEnumerable.GetEnumerator()
//        {
//            return GetEnumerator();
//        }

//        #endregion

//        /// <summary>
//        /// Gets the packages.
//        /// </summary>
//        /// <returns></returns>
//        public IEnumerable<Package> GetEnumerable()
//        {
//            return new List<Package>(packages.Values);
//        }
//    }
//}