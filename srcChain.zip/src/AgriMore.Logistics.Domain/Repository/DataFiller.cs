using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Domain.Repository
{
    /// <summary>
    /// Represents the DataFiller class.
    /// </summary>
    public class DataFiller
    {
        //private const string bubbleRap = "Bubble Rap";
        private const string cardboard = "Carton";
        private const string metal = "Metal";
        private const string plastic = "Plastic";
        //private const string polystyrene = "Poly Styrene";
        private const string wood = "Wood";
        private Dictionary<string, UnitOfMeasurement> unitOfMeasurements = new Dictionary<string, UnitOfMeasurement>();

        /// <summary>
        /// Fills the data.
        /// </summary>
        public void Fill()
        {
            TransactionManager transactionManager = new TransactionManager();
            transactionManager.BeginTransaction();

            IRepository<Role> roleRepository = new RepositoryFactory().GetRoleRepository();
            Role growerRole = new Role("Grower");
            roleRepository.Add(growerRole);
            Role shipperRole = new Role("Shipper");
            roleRepository.Add(shipperRole);
            Role forwarderRole = new Role("Forwarder");
            roleRepository.Add(forwarderRole);
            Role receiverRole = new Role("Receiver");
            roleRepository.Add(receiverRole);

            FillUnitOfMeasurements();

            FillMemoryPackageTypeRepositoryWithDummyData();

            FillMemoryExposureTypeRepositoryWithDummyData();

            FillMemoryTreatmentTypeCategoryRepositoryWithDummyData();

            ReadCountryDataFromTextFile();

            ReadAgriMoreTimeZoneStamDataFromTextFile();

            ReadDataFromTextFile();

            transactionManager.CommitTransaction();
        }

        /// <summary>
        /// Fills the unit of measurements.
        /// </summary>
        private void FillUnitOfMeasurements()
        {
            IRepository<UnitOfMeasurement> unitOfMeasurementRepository =
                new RepositoryFactory().GetUnitOfMeasurementRepository();

            UnitOfMeasurement uom;
            uom = new UnitOfMeasurement("gm/m3");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("%");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("pH");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("EC");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("Litres per kg");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("uLitre / Litre air");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("Degrees Centrigrade");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("nm");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("Fahrenheit");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("Celsius");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("grammes");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("mm");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("kg");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("cm3");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("1m3");
            unitOfMeasurementRepository.Add(uom);
            uom = new UnitOfMeasurement("cm");
            unitOfMeasurementRepository.Add(uom);

            ICollection<UnitOfMeasurement> uoms =
                new RepositoryFactory().GetUnitOfMeasurementRepository().AsCollection();
            unitOfMeasurements = new Dictionary<string, UnitOfMeasurement>();

            foreach (UnitOfMeasurement measurement in uoms)
            {
                unitOfMeasurements.Add(measurement.Name, measurement);
            }
        }

        /// <summary>
        /// Fills the memory exposure type repository with dummy data.
        /// </summary>
        private void FillMemoryExposureTypeRepositoryWithDummyData()
        {
            ExposureType tempInCelsius = new ExposureType("Temperature in Celsius", unitOfMeasurements["Celsius"]);
            ExposureType tempInFahrenheit =
                new ExposureType("Temperature in Fahrenheit", unitOfMeasurements["Fahrenheit"]);
            ExposureType absoluteHumidity = new ExposureType("Absolute Humidity", unitOfMeasurements["gm/m3"]);
            ExposureType relativeHumidity = new ExposureType("Relative Humidity", unitOfMeasurements["%"]);
            IRepository<ExposureType> exposureTypeRepository = new RepositoryFactory().GetExposureTypeRepository();

            exposureTypeRepository.Add(tempInCelsius);
            exposureTypeRepository.Add(tempInFahrenheit);
            exposureTypeRepository.Add(absoluteHumidity);
            exposureTypeRepository.Add(relativeHumidity);
        }

        /// <summary>
        /// Fills the memory package type repository with dummy data.
        /// </summary>
        private void FillMemoryTreatmentTypeCategoryRepositoryWithDummyData()
        {
            TreatmentTypeCategory treatmentTypeCategory;
            IRepository<TreatmentTypeCategory> memoryTreatmentTypeCategoryRepository =
                new RepositoryFactory().GetTreatmentTypeCategoryRepository();


            treatmentTypeCategory = new TreatmentTypeCategory("Wash");
            memoryTreatmentTypeCategoryRepository.Add(treatmentTypeCategory);

            AddTreatmentType("Water", unitOfMeasurements["pH"], treatmentTypeCategory);
            AddTreatmentType("Water Other", unitOfMeasurements["EC"], treatmentTypeCategory);

            treatmentTypeCategory = new TreatmentTypeCategory("Chemical");
            memoryTreatmentTypeCategoryRepository.Add(treatmentTypeCategory);

            AddTreatmentType("SOPP Waxing", unitOfMeasurements["Litres per kg"], treatmentTypeCategory);
            AddTreatmentType("Ethylene", unitOfMeasurements["uLitre / Litre air"], treatmentTypeCategory);

            treatmentTypeCategory = new TreatmentTypeCategory("Dry");
            memoryTreatmentTypeCategoryRepository.Add(treatmentTypeCategory);

            AddTreatmentType("Hot Air drying", unitOfMeasurements["Degrees Centrigrade"], treatmentTypeCategory);
            AddTreatmentType("Freeze drying", unitOfMeasurements["Degrees Centrigrade"], treatmentTypeCategory);

            treatmentTypeCategory = new TreatmentTypeCategory("Light");
            memoryTreatmentTypeCategoryRepository.Add(treatmentTypeCategory);

            AddTreatmentType("UV treatment", unitOfMeasurements["nm"], treatmentTypeCategory);
        }

        /// <summary>
        /// Adds the type of the treatment.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="uom">The uom.</param>
        /// <param name="treatmentTypeCategory">The treatment type category.</param>
        private static void AddTreatmentType(string name, UnitOfMeasurement uom,
                                             TreatmentTypeCategory treatmentTypeCategory)
        {
            TreatmentType treatmentType;

            treatmentType = new TreatmentType(name, treatmentTypeCategory, uom);
            treatmentTypeCategory.AddTreatmentType(treatmentType);
            new RepositoryFactory().GetTreatmentTypeRepository().Add(treatmentType);
        }

        /// <summary>
        /// Reads the data from text file embedded as resource file.
        /// THE TEXT FILE IS A EMBEDDED RESOURCE FILE!
        /// </summary>
        private static void ReadDataFromTextFile()
        {
            Stream resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("AgriMore.Logistics.Domain.Repository.FillData.txt");

            using (StreamReader re = new StreamReader(resourceStream))
            {
                string input;

                while ((input = re.ReadLine()) != null)
                {
                    if (input == "ChainEntity")
                    {
                        string otherInput;

                        re.ReadLine();
                        ChainEntity chainEntity = new ChainEntity(re.ReadLine());
                        new RepositoryFactory().GetChainEntityRepository().Add(chainEntity);

                        re.ReadLine(); //empty line
                        re.ReadLine(); //adress line
                        re.ReadLine(); //header line

                        Country country = null;
                        AgriMoreTimeZone agriMoreTimeZone = null;

                        while ((otherInput = re.ReadLine()) != string.Empty) //otherInput = re.ReadLine();
                        {
                            string[] f = otherInput.Split(new char[] {';'});

                            string countryName = f[7];
                            if (country == null || country.Name != countryName)
                            {
                                country = new RepositoryFactory().GetCountryRepository().GetOne(countryName);
                                if (country == null)
                                {
                                    throw new ApplicationException("Country '" + countryName + "' is not found");
                                }
                            }

                            string agrimoreTimeZoneName = f[10];
                            if (agriMoreTimeZone == null || agriMoreTimeZone.Name != agrimoreTimeZoneName)
                            {
                                agriMoreTimeZone = new RepositoryFactory().GetAgriMoreTimeZoneRepository().GetOne(agrimoreTimeZoneName);
                                if (agriMoreTimeZone == null)
                                {
                                    throw new ApplicationException("AgrimoreTimeZone '" + agrimoreTimeZoneName + "' is not found");
                                }
                            }

                            Address address = new Address(f[5], country, f[9], f[8], f[3], f[4], f[0], f[1], f[6], agriMoreTimeZone, f[2]);
                            
                            chainEntity.AddAddress(address);
                            
                            new RepositoryFactory().GetAddressRepository().Add(address);
                        }

                        otherInput = re.ReadLine(); //empty line before kassa
                        if (otherInput == "Kassa")
                        {
                            while ((otherInput = re.ReadLine()) != string.Empty) //otherInput = re.ReadLine();
                            {
                                string[] l = otherInput.Split(new char[] {';'});

                                foreach (Address address in chainEntity.Addresses)
                                {
                                    if (address.StreetName + address.StreetNumber == l[0])
                                    {
                                        CashRegister cashRegister =
                                            new CashRegister(address.StreetName + " " + l[1]);
                                        address.AddCashRegister(cashRegister);
                                        new RepositoryFactory().GetCashRegisterRepository().Add(cashRegister);
                                    }
                                }
                            }
                        }

                        if (otherInput != "location")
                        {
                            re.ReadLine();
                        } //empty line before location

                        while ((otherInput = re.ReadLine()) != string.Empty) //otherInput = re.ReadLine();
                        {
                            string[] l = otherInput.Split(new char[] {';'});

                            foreach (Address address in chainEntity.Addresses)
                            {
                                if (address.StreetName + address.StreetNumber == l[0])
                                {
                                    Location location = new Location(address.StreetName + " " + l[1]);
                                    address.AddLocation(location);
                                    new RepositoryFactory().GetLocationRepository().Add(location);
                                }
                            }
                        }

                        re.ReadLine(); //empty line before user
                        re.ReadLine(); //Header;

                        while ((otherInput = re.ReadLine()) != string.Empty)
                        {
                            if (otherInput == null)
                            {
                                break;
                            }

                            string[] u = otherInput.Split(new char[] {';'});

                            List<Role> roles = new List<Role>();
                            ICollection<Role> allRoles = new RepositoryFactory().GetRoleRepository().AsCollection();

                            for (int count = 4; count < u.Length; count++)
                            {
                                foreach (Role role in allRoles)
                                {
                                    if (role.Name.ToLower() == u[count].ToLower())
                                    {
                                        //roleRepository.GetOne("Grower")}
                                        roles.Add(role);
                                    }
                                }
                            }

                            User user = new User(u[3], u[2], u[0], u[1], roles,"","");
                            chainEntity.AddUser(user);
                            new RepositoryFactory().GetUserRepository().Add(user);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Reads the agri more time zone stam data from text file.
        /// </summary>
        private static void ReadAgriMoreTimeZoneStamDataFromTextFile()
        {
            Stream resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("AgriMore.Logistics.Domain.Repository.FillAgriMoreTimeZoneStamData.txt");

            using (StreamReader re = new StreamReader(resourceStream))
            {
                string input;
                while ((input = re.ReadLine()) != null)
                {
                    AgriMoreTimeZone agrimZone = new AgriMoreTimeZone(input.TrimEnd());
                    new RepositoryFactory().ConcreteRepositoryFactory.GetAgriMoreTimeZoneRepository().Add(agrimZone);

                    Console.WriteLine(input);
                }
            }
        }

        /// <summary>
        /// Reads the country data from text file.
        /// </summary>
        private static void ReadCountryDataFromTextFile()
        {
            Stream resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("AgriMore.Logistics.Domain.Repository.FillCountryStamData.txt");

            using (StreamReader re = new StreamReader(resourceStream))
            {
                string input;
                while ((input = re.ReadLine()) != null)
                {
                    Country country = new Country(input.TrimEnd());
                    new RepositoryFactory().ConcreteRepositoryFactory.GetCountryRepository().Add(country);
                }
            }
        }

        /// <summary>
        /// Fills the memory package type repository with dummy data.
        /// </summary>
        private void FillMemoryPackageTypeRepositoryWithDummyData()
        {
            PackingMaterial Carton = new PackingMaterial(cardboard);
            PackingMaterial Plastic = new PackingMaterial(plastic);
            //PackingMaterial BubbleRap = new PackingMaterial(bubbleRap);
            PackingMaterial Wood = new PackingMaterial(wood);
            PackingMaterial Metal = new PackingMaterial(metal);
            //PackingMaterial PolyStyrene = new PackingMaterial(polystyrene);

            PackageTypeCategory wholesalePackaging;
            PackageTypeCategory retailPackaging;

            IRepository<PackageTypeCategory> memoryPackageTypeCategoryRepository =
                new RepositoryFactory().GetPackageTypeCategoryRepository();

            IRepository<PackageType> memoryPackageTypeRepository =
                new RepositoryFactory().GetPackageTypeRepository();

            wholesalePackaging = new PackageTypeCategory("wholesalePackaging");
            memoryPackageTypeCategoryRepository.Add(wholesalePackaging);
            retailPackaging = new PackageTypeCategory("retailPackaging");
            memoryPackageTypeCategoryRepository.Add(retailPackaging);
            PackageType packageType;
            packageType = new PackageType
                (
                "Container",
                wholesalePackaging,
                Plastic,
                new Measurement(unitOfMeasurements["cm"], 100),
                new Measurement(unitOfMeasurements["cm"], 100),
                new Measurement(unitOfMeasurements["cm"], 100),
                new Measurement(unitOfMeasurements["1m3"], 1),
                false, false
                );

            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "FlowPack",
                    retailPackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 5),
                    new Measurement(unitOfMeasurements["cm"], 10),
                    new Measurement(unitOfMeasurements["cm"], 15),
                    new Measurement(unitOfMeasurements["cm3"], 5),
                    false, false
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "OpenDoos",
                    wholesalePackaging,
                    Carton,
                    new Measurement(unitOfMeasurements["cm"], 5),
                    new Measurement(unitOfMeasurements["cm"], 10),
                    new Measurement(unitOfMeasurements["cm"], 15),
                    new Measurement(unitOfMeasurements["cm3"], 5),
                    false, false
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Pallet",
                    wholesalePackaging,
                    Wood,
                    new Measurement(unitOfMeasurements["cm"], 5),
                    new Measurement(unitOfMeasurements["cm"], 10),
                    new Measurement(unitOfMeasurements["cm"], 15),
                    new Measurement(unitOfMeasurements["cm3"], 5),
                    false, false
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "PlasticBaal",
                    retailPackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 5),
                    new Measurement(unitOfMeasurements["cm"], 10),
                    new Measurement(unitOfMeasurements["cm"], 15),
                    new Measurement(unitOfMeasurements["cm3"], 5),
                    false, false
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "PuntZak",
                    retailPackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 5),
                    new Measurement(unitOfMeasurements["cm"], 10),
                    new Measurement(unitOfMeasurements["cm"], 15),
                    new Measurement(unitOfMeasurements["cm3"], 5),
                    false, false
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType
                = new PackageType
                    (
                    "Punnet with cover 250",
                    retailPackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 10),
                    new Measurement(unitOfMeasurements["cm"], 20),
                    new Measurement(unitOfMeasurements["mm"], 75),
                    new Measurement(unitOfMeasurements["grammes"], 250),
                    true, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType
                = new PackageType
                    (
                    "Punnet with cover 500",
                    retailPackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 15),
                    new Measurement(unitOfMeasurements["cm"], 20),
                    new Measurement(unitOfMeasurements["cm"], 10),
                    new Measurement(unitOfMeasurements["grammes"], 500),
                    false, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType
                = new PackageType
                    (
                    "Punnet no cover 250",
                    retailPackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 10),
                    new Measurement(unitOfMeasurements["cm"], 20),
                    new Measurement(unitOfMeasurements["mm"], 75),
                    new Measurement(unitOfMeasurements["grammes"], 250),
                    true, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType
                = new PackageType
                    (
                    "Punnet no cover 500",
                    retailPackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 15),
                    new Measurement(unitOfMeasurements["cm"], 20),
                    new Measurement(unitOfMeasurements["cm"], 10),
                    new Measurement(unitOfMeasurements["grammes"], 500),
                    true, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "FlowPack 250",
                    retailPackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 10),
                    new Measurement(unitOfMeasurements["cm"], 20),
                    new Measurement(unitOfMeasurements["mm"], 75),
                    new Measurement(unitOfMeasurements["grammes"], 250),
                    true, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "FlowPack 500",
                    retailPackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 15),
                    new Measurement(unitOfMeasurements["cm"], 20),
                    new Measurement(unitOfMeasurements["mm"], 75),
                    new Measurement(unitOfMeasurements["grammes"], 500),
                    true, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Tray 10",
                    retailPackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 5),
                    new Measurement(unitOfMeasurements["cm"], 20),
                    new Measurement(unitOfMeasurements["mm"], 75),
                    new Measurement(unitOfMeasurements["grammes"], 200),
                    true, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Tray 15",
                    retailPackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 5),
                    new Measurement(unitOfMeasurements["cm"], 30),
                    new Measurement(unitOfMeasurements["cm"], 10),
                    new Measurement(unitOfMeasurements["grammes"], 300),
                    true, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Tray 20",
                    retailPackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 5),
                    new Measurement(unitOfMeasurements["cm"], 50),
                    new Measurement(unitOfMeasurements["mm"], 125),
                    new Measurement(unitOfMeasurements["grammes"], 400),
                    true, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Cube box 1000 kg",
                    wholesalePackaging,
                    Plastic,
                    new Measurement(unitOfMeasurements["cm"], 100),
                    new Measurement(unitOfMeasurements["cm"], 100),
                    new Measurement(unitOfMeasurements["cm"], 100),
                    new Measurement(unitOfMeasurements["kg"], 1000),
                    false, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Box with cover 5 kg",
                    wholesalePackaging,
                    Carton,
                    new Measurement(unitOfMeasurements["cm"], 40),
                    new Measurement(unitOfMeasurements["cm"], 30),
                    new Measurement(unitOfMeasurements["cm"], 14),
                    new Measurement(unitOfMeasurements["kg"], 5),
                    false, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Box 10 kg",
                    wholesalePackaging,
                    Carton,
                    new Measurement(unitOfMeasurements["cm"], 50),
                    new Measurement(unitOfMeasurements["cm"], 40),
                    new Measurement(unitOfMeasurements["mm"], 168),
                    new Measurement(unitOfMeasurements["kg"], 10),
                    false, false
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Euro Pallet",
                    wholesalePackaging,
                    Wood,
                    new Measurement(unitOfMeasurements["cm"], 15),
                    new Measurement(unitOfMeasurements["cm"], 120),
                    new Measurement(unitOfMeasurements["cm"], 80),
                    new Measurement(unitOfMeasurements["kg"], 0),
                    false, false
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Euro Pallet Sealed",
                    wholesalePackaging,
                    Wood,
                    new Measurement(unitOfMeasurements["cm"], 15),
                    new Measurement(unitOfMeasurements["cm"], 120),
                    new Measurement(unitOfMeasurements["cm"], 80),
                    new Measurement(unitOfMeasurements["kg"], 0),
                    true, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Block Pallet",
                    wholesalePackaging,
                    Wood,
                    new Measurement(unitOfMeasurements["cm"], 15),
                    new Measurement(unitOfMeasurements["cm"], 120),
                    new Measurement(unitOfMeasurements["cm"], 100),
                    new Measurement(unitOfMeasurements["kg"], 0),
                    false, false
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Block Pallet Sealed",
                    wholesalePackaging,
                    Wood,
                    new Measurement(unitOfMeasurements["cm"], 15),
                    new Measurement(unitOfMeasurements["cm"], 120),
                    new Measurement(unitOfMeasurements["cm"], 100),
                    new Measurement(unitOfMeasurements["kg"], 0),
                    true, true
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Container Standard 20 Feet",
                    wholesalePackaging,
                    Metal,
                    new Measurement(unitOfMeasurements["mm"], 5935),
                    new Measurement(unitOfMeasurements["mm"], 2335),
                    new Measurement(unitOfMeasurements["mm"], 2383),
                    new Measurement(unitOfMeasurements["kg"], 0),
                    false, false
                    );
            memoryPackageTypeRepository.Add(packageType);

            packageType =
                new PackageType(
                    "Container Standard 40 Feet",
                    wholesalePackaging,
                    Metal,
                    new Measurement(unitOfMeasurements["mm"], 12022),
                    new Measurement(unitOfMeasurements["mm"], 2352),
                    new Measurement(unitOfMeasurements["mm"], 2395),
                    new Measurement(unitOfMeasurements["kg"], 0),
                    false, false
                    );
            memoryPackageTypeRepository.Add(packageType);
        }
    }
}