using System;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.Remoting;
using AgriMore.Logistics.Domain.Repository.Memory;
using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Domain.Repository
{
    /// <summary>
    /// This class is used for retrieving the domain repositories
    /// </summary>
    public class RepositoryFactory
    {
        private static IRepositoryFactory concreteRepositoryFactory;

        /// <summary>
        /// Initializes a new instance of the <see cref="RepositoryFactory"/> class.
        /// </summary>
        static RepositoryFactory()
        {
            if (concreteRepositoryFactory != null)
            {
                return;
            }

            string key = "RepositoryFactory.ConcreteRepositoryFactory";
            string className = ConfigurationManager.AppSettings[key];
            if (string.IsNullOrEmpty(className))
            {
                Debug.WriteLine("No classname supplied for " + key + ". Using MemoryMapRepositoryFactory");
                concreteRepositoryFactory = new MemoryMapRepositoryFactory();
                return;
            }

            string[] split = className.Split(',');
            if (split.Length != 2)
            {
                throw new ConfigurationErrorsException(
                    "Invalid classname supplied for " + key + ": " + className);
            }

            string assemblyName = split[1].Trim();
            string typeName = split[0];
            ObjectHandle objectHandle = Activator.CreateInstance(assemblyName, typeName);
            concreteRepositoryFactory = objectHandle.Unwrap() as IRepositoryFactory;
            if (concreteRepositoryFactory == null)
            {
                throw new ConfigurationErrorsException(
                    "Invalid classname supplied for " + key + ": " + className +
                    ". It is not an IRepositoryFactory");
            }
        }

        /// <summary>
        /// Gets or sets the concrete repository factory.
        /// </summary>
        /// <value>The concrete repository factory.</value>
        public IRepositoryFactory ConcreteRepositoryFactory 
        {
            get
            {
                return concreteRepositoryFactory;
            }
            set
            {
                concreteRepositoryFactory = value;
            }
        }

        /// <summary>
        /// Gets the treatment repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Treatment> GetTreatmentRepository()
        {
            return concreteRepositoryFactory.GetTreatmentRepository();
        }

        /// <summary>
        /// Gets the exposure document repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Identification> GetIdentificationRepository()
        {
            return concreteRepositoryFactory.GetIdentificationRepository();
        }

        /// <summary>
        /// Gets the exposure document repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ExposureDocument> GetExposureDocumentRepository()
        {
            return concreteRepositoryFactory.GetExposureDocumentRepository();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<PackageType> GetPackageTypeRepository()
        {
            return concreteRepositoryFactory.GetPackageTypeRepository();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<PackageTypeCategory> GetPackageTypeCategoryRepository()
        {
            return concreteRepositoryFactory.GetPackageTypeCategoryRepository();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<AgriMoreTimeZone> GetAgriMoreTimeZoneRepository()
        {
            return concreteRepositoryFactory.GetAgriMoreTimeZoneRepository();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<TreatmentType> GetTreatmentTypeRepository()
        {
            return concreteRepositoryFactory.GetTreatmentTypeRepository();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<TreatmentTypeCategory> GetTreatmentTypeCategoryRepository()
        {
            return concreteRepositoryFactory.GetTreatmentTypeCategoryRepository();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<User> GetUserRepository()
        {
            return concreteRepositoryFactory.GetUserRepository();
        }

        /// <summary>
        /// Gets the exposure repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Exposure> GetExposureRepository()
        {
            return concreteRepositoryFactory.GetExposureRepository();
        }

        /// <summary>
        /// Gets the exposure type repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ExposureType> GetExposureTypeRepository()
        {
            return concreteRepositoryFactory.GetExposureTypeRepository();
        }

        /// <summary>
        /// retrieve a ChainEntity repository
        ///</summary>
        /// <returns></returns>
        public IRepository<ChainEntity> GetChainEntityRepository()
        {
            return concreteRepositoryFactory.GetChainEntityRepository();
        }

       
        /// <summary>
        /// Gets the role repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Role> GetRoleRepository()
        {
            return concreteRepositoryFactory.GetRoleRepository();
        }

        /// <summary>
        /// retrieve a Location repository
        /// </summary>
        /// <returns></returns>
        public IRepository<Location> GetLocationRepository()
        {
            return concreteRepositoryFactory.GetLocationRepository();
        }

        /// <summary>
        /// retrieve a Location repository
        /// </summary>
        /// <returns></returns>
        public IRepository<CashRegister> GetCashRegisterRepository()
        {
            return concreteRepositoryFactory.GetCashRegisterRepository();
        }

        /// <summary>
        /// Gets the address repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Address> GetAddressRepository()
        {
            return concreteRepositoryFactory.GetAddressRepository();
        }

        /// <summary>
        /// Gets the shipment repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Shipment> GetShipmentRepository()
        {
            return concreteRepositoryFactory.GetShipmentRepository();
        }

        /// <summary>
        /// Gets the package repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Package> GetPackageRepository()
        {
            return concreteRepositoryFactory.GetPackageRepository();
        }
        
        /// <summary>
        /// Gets the disposal package repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<DisposalPackage> GetDisposalPackageRepository()
        {
            return concreteRepositoryFactory.GetDisposalPackageRepository();
        }

        /// <summary>
        /// Gets the processing step repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<ProcessingStep> GetProcessingStepRepository()
        {
            return concreteRepositoryFactory.GetProcessingStepRepository();
        }

        /// <summary>
        /// Creates the repository.
        /// </summary>
        /// <typeparam name="TElement">The type of the element.</typeparam>
        /// <returns></returns>
        public IRepository<TElement> CreateRepository<TElement>() where TElement : class, IIdentifyable
        {
            return concreteRepositoryFactory.CreateRepository<TElement>();
        }

        /// <summary>
        /// Creates the transaction manager.
        /// </summary>
        /// <returns></returns>
        internal static ITransactionManager CreateTransactionManager()
        {
            return concreteRepositoryFactory.CreateTransactionManager();
        }

        /// <summary>
        /// retrieve a User repository
        ///</summary>
        /// <returns></returns>
        public IRepository<TransportEquipment> GetTransportEquipmentRepository()
        {
            return concreteRepositoryFactory.GetTransportEquipmentRepository();
        }

        /// <summary>
        /// Initializes the test data.
        /// </summary>
        public void InitializeTestData()
        {
            concreteRepositoryFactory.InitializeTestData();
        }

        /// <summary>
        /// Gets the repack package relationship repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<RepackPackageRelationship> GetRepackPackageRelationshipRepository()
        {
            return concreteRepositoryFactory.GetRepackPackageRelationshipRepository();
        }

        /// <summary>
        /// Gets the unit of measurement repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<UnitOfMeasurement> GetUnitOfMeasurementRepository()
        {
            return concreteRepositoryFactory.GetUnitOfMeasurementRepository();
        }

        /// <summary>
        /// Gets the country repository.
        /// </summary>
        /// <returns></returns>
        public IRepository<Country> GetCountryRepository()
        {
            return concreteRepositoryFactory.GetCountryRepository();
        }

        public IRepository<PackagePackagingWasteInfo> GetPackagePackagingWasteInfoRepository()
        {
            return concreteRepositoryFactory.GetPackagePackagingWasteInfoRepository();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IRepository<ExposureDefine> GetExposureDefineRepository()
        {
            return concreteRepositoryFactory.GetExposureDefineRepository();
        }

        public IRepository<WasteDisposalPackageTracing> GetWasteDisposalPackageTracingRepository()
        {
            return concreteRepositoryFactory.GetWasteDisposalPackageTracingRepository();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IRepository<WasteDisposalDisposalPackage> GetWasteDisposalDisposalPackageRepository()
        {
            return concreteRepositoryFactory.GetWasteDisposalDisposalPackageRepository();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IRepository<WasteDisposalExpirePackage> GetWasteDisposalExpirePackageRepository()
        {
            return concreteRepositoryFactory.GetWasteDisposalExpirePackageRepository();
        }

        public IRepository<Decomposition> GetDecompositionRepository()
        {
            return concreteRepositoryFactory.GetDecompositionRepository();
        }

        public IRepository<DecompositionInfo> GetDecompositionInfoRepository()
        {
            return concreteRepositoryFactory.GetDecompositionInfoRepository();
        }
    }
}
