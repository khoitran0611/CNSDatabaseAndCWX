namespace AgriMore.Logistics.Domain.Repository
{
    /// <summary>
    /// identifyable interface, has long uid
    /// </summary>
    public interface IIdentifyable
    {
        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        long Uid { get; set; }
    }
}