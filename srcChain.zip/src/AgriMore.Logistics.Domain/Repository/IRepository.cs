using System.Collections.Generic;

namespace AgriMore.Logistics.Domain.Repository
{
    /// <summary>
    /// <para>Repository Of Elements interface. A Repository provides a collection like interface, and mediates
    /// between domain objects (the elements)
    /// and a form of storage strategy (for instance in memory or relational database).
    /// </para>
    /// <para>
    /// This repository expects the stored elements to be unique in some way within the collection.
    /// Every object should have a human readable unique representation (the string id used in the GetOne method)
    /// and every object should have a unique internal id (the long uid).
    /// </para>
    /// <para>
    /// The elements are expected to override <code>Equals()</code>, <code>ToString()</code> and <code>GetHashCode()</code>.
    /// <code>ToString()</code> should return a unique string representation, this can be for instance the name of the object.
    /// This same value can be used to find the object by using <code>GetOne(string id)</code>.
    /// <code>GetHashCode()</code> needs to be implemented for determining the hash bucket of a dictionary.
    /// This needs to be implemented as defined on object, simply stated it needs to be unique enough to divide
    /// the objects in buckets of similar objects, and as unique as possible. (the unique string of the object could be used).
    /// <code>Equals(object obj)</code> needs to be implemented so that an object cannot be stored if it is already present
    /// in the repository. if there is a unique name, this should be used.
    /// The repository implementation can use Contains(object obj) on collections to see if the item
    /// already exists.
    /// </para>
    /// 
    /// </summary>
    /// <typeparam name="TElement">type of object that is contained by the repository</typeparam>
    public interface IRepository<TElement> : IEnumerable<TElement> //, INonGenericRepository 
        where TElement : IIdentifyable
    {
        /// <summary>
        /// Gets the Element by a unique string id. the id is the same value as the return value of <code>ToString()</code>
        /// on the object.
        /// </summary>
        /// <param name="id">The id.</param>
        /// <returns></returns>
        TElement GetOne(string id);

        /// <summary>
        /// Gets the Element by unique id. This Id is returned by the <code>Add(TElement element)</code> method.
        /// </summary>
        /// <param name="uid">The uid.</param>
        /// <returns></returns>
        TElement GetOne(long uid);

        /// <summary>
        /// Adds the specified element. returns the uid assigned internally in the repository.
        /// This method assigns the id to the element. The uid of the element is not allowed to be != 0,
        /// since then it would have been added already.
        /// <example>
        ///   Shipment shipment = new Shipment();
        ///   ...
        ///   long uid = repository.Add(shipment);
        /// </example>
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>the unique internal id. this id can be used in <code>GetOne(long uid)</code></returns>
        long Add(TElement element);

        /// <summary>
        /// Returns all elements as a collection
        /// </summary>
        /// <returns></returns>
        ICollection<TElement> AsCollection();

        /// <summary>
        /// Determines whether this repository contains the element. 
        /// <code>TElement.Equals(object obj)</code> can be used to determine this. You need to implement <code>Equals(object obj)</code>
        ///  on the TElement type.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this repository contains the element; otherwise, <c>false</c>.
        /// </returns>
        bool Contains(TElement element);

        /// <summary>
        /// Gets One element using the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>The element, or null if the element could not be found.</returns>
        TElement GetOne(ISpecification<TElement> criteria);

        /// <summary>
        /// Finds elements of TElement by specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>A collection of elements, or an empty collection if no elements where found for the criteria</returns>
        ICollection<TElement> Find(ISpecification<TElement> criteria);

        /// <summary>
        /// Stores the specified element. Equals needs to be implemented on the element.
        /// Equals is used to see if the element needs to be updated or added.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>The UID of the element.</returns>
        void Store(TElement element);

        /// <summary>
        /// Forces the underlying database to reflect the changes in order to get the generated UId's of objects and the
        /// assiated objects.
        /// </summary>
        void Flush();

        /// <summary>
        /// Forces the underlying database to reflect the changes in order to get the generated UId's of objects and the
        /// assiated objects.
        /// </summary>
        void Refresh(TElement element);

        /// <summary>
        /// Removes the specified element. Equals needs to be implemented on the element.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>true if the element could be removed, false if not</returns>
        bool Remove(TElement element);

        /// <summary>
        /// Removes the elements using the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>collection if uids of the items removed</returns>
        void Remove(ISpecification<TElement> criteria);

        /// <summary>
        /// Counts the elements using the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>the amount of elements that match the criteria</returns>
        long Count(ISpecification<TElement> criteria);

        /// <summary>
        /// Counts the elements.
        /// </summary>
        /// <returns>The number of elements</returns>
        long Count();
    }
}