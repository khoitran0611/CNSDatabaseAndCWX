using AgriMore.Logistics.Domain.Transaction;

namespace AgriMore.Logistics.Domain.Repository
{
    /// <summary>
    /// Represents the IRepositoryFactory interface.
    /// </summary>
    public interface IRepositoryFactory
    {
        /// <summary>
        /// Gets the treatment repository.
        /// </summary>
        /// <returns></returns>
        IRepository<Treatment> GetTreatmentRepository();

        /// <summary>
        /// Gets the identification repository.
        /// </summary>
        /// <returns></returns>
        IRepository<Identification> GetIdentificationRepository();

        /// <summary>
        /// Gets the exposure document repository.
        /// </summary>
        /// <returns></returns>
        IRepository<ExposureDocument> GetExposureDocumentRepository();

        /// <summary>
        /// Gets the package type repository.
        /// </summary>
        /// <returns></returns>
        IRepository<PackageType> GetPackageTypeRepository();

        /// <summary>
        /// Gets the treatment type repository.
        /// </summary>
        /// <returns></returns>
        IRepository<TreatmentType> GetTreatmentTypeRepository();

        /// <summary>
        /// Gets the treatment type category repository.
        /// </summary>
        /// <returns></returns>
        IRepository<TreatmentTypeCategory> GetTreatmentTypeCategoryRepository();

        /// <summary>
        /// Gets the user repository.
        /// </summary>
        /// <returns></returns>
        IRepository<User> GetUserRepository();

        /// <summary>
        /// Gets the exposure repository.
        /// </summary>
        /// <returns></returns>
        IRepository<Exposure> GetExposureRepository();

        /// <summary>
        /// Gets the exposure type repository.
        /// </summary>
        /// <returns></returns>
        IRepository<ExposureType> GetExposureTypeRepository();

        /// <summary>
        /// Gets the chain entity repository.
        /// </summary>
        /// <returns></returns>
        IRepository<ChainEntity> GetChainEntityRepository();

        /// <summary>
        /// Gets the role repository.
        /// </summary>
        /// <returns></returns>
        IRepository<Role> GetRoleRepository();

        /// <summary>
        /// Gets the location repository.
        /// </summary>
        /// <returns></returns>
        IRepository<Location> GetLocationRepository();

        /// <summary>
        /// Gets the address repository.
        /// </summary>
        /// <returns></returns>
        IRepository<Address> GetAddressRepository();

        /// <summary>
        /// Gets the shipment repository.
        /// </summary>
        /// <returns></returns>
        IRepository<Shipment> GetShipmentRepository();

        /// <summary>
        /// Gets the package repository.
        /// </summary>
        /// <returns></returns>
        IRepository<Package> GetPackageRepository();

        IRepository<DisposalPackage> GetDisposalPackageRepository();

        /// <summary>
        /// Gets the processing step repository.
        /// </summary>
        /// <returns></returns>
        IRepository<ProcessingStep> GetProcessingStepRepository();

        /// <summary>
        /// Gets the transport equipment repository.
        /// </summary>
        /// <returns></returns>
        IRepository<TransportEquipment> GetTransportEquipmentRepository();

        /// <summary>
        /// Gets the agri more time zone repository.
        /// </summary>
        /// <returns></returns>
        IRepository<AgriMoreTimeZone> GetAgriMoreTimeZoneRepository();

        /// <summary>
        /// Creates the repository.
        /// </summary>
        /// <typeparam name="TElement">The type of the element.</typeparam>
        /// <returns></returns>
        IRepository<TElement> CreateRepository<TElement>() where TElement : class, IIdentifyable;

        /// <summary>
        /// Creates the transaction manager.
        /// </summary>
        /// <returns></returns>
        ITransactionManager CreateTransactionManager();

        /// <summary>
        /// Initializes the test data.
        /// </summary>
        void InitializeTestData();

        /// <summary>
        /// Gets the country repository.
        /// </summary>
        /// <returns></returns>
        IRepository<Country> GetCountryRepository();

        /// <summary>
        /// Gets the unit of measurement repository.
        /// </summary>
        /// <returns></returns>
        IRepository<UnitOfMeasurement> GetUnitOfMeasurementRepository();

        /// <summary>
        /// Gets the packing material repository.
        /// </summary>
        /// <returns></returns>
        IRepository<PackingMaterial> GetPackingMaterialRepository();

        /// <summary>
        /// Gets the package type category repository.
        /// </summary>
        /// <returns></returns>
        IRepository<PackageTypeCategory> GetPackageTypeCategoryRepository();

        /// <summary>
        /// Gets the cash register repository.
        /// </summary>
        /// <returns></returns>
        IRepository<CashRegister> GetCashRegisterRepository();

        /// <summary>
        /// Gets the repack package relationship repository.
        /// </summary>
        /// <returns></returns>
        IRepository<RepackPackageRelationship> GetRepackPackageRelationshipRepository();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IRepository<PackagePackagingWasteInfo> GetPackagePackagingWasteInfoRepository();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IRepository<ExposureDefine> GetExposureDefineRepository();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IRepository<WasteDisposalPackageTracing> GetWasteDisposalPackageTracingRepository();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IRepository<WasteDisposalDisposalPackage> GetWasteDisposalDisposalPackageRepository();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IRepository<WasteDisposalExpirePackage> GetWasteDisposalExpirePackageRepository();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IRepository<Decomposition> GetDecompositionRepository();

        IRepository<DecompositionInfo> GetDecompositionInfoRepository();
    }
}
