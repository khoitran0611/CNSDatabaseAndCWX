using System.Collections.Generic;

namespace AgriMore.Logistics.Domain.Repository
{
    /// <summary>
    /// executes specs on dictionaries.
    /// 
    /// </summary>
    /// <typeparam name="TKey">The type of the key.</typeparam>
    /// <typeparam name="TValue">The type of the value.</typeparam>
    public class DictionarySpecificationExecutor<TKey, TValue> where TValue : class
    {
        private IDictionary<TKey, TValue> map;

        /// <summary>
        /// Initializes a new instance of the <see cref="DictionarySpecificationExecutor&lt;TKey, TValue&gt;"/> class.
        /// </summary>
        /// <param name="map">The map.</param>
        public DictionarySpecificationExecutor(IDictionary<TKey, TValue> map)
        {
            this.map = map;
        }

        /// <summary>
        /// Gets the one.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns></returns>
        public TValue GetOne(ISpecification<TValue> criteria)
        {
            foreach (KeyValuePair<TKey, TValue> pair in map)
            {
                if (criteria.IsSatisfiedBy(pair.Value))
                {
                    return pair.Value;
                }
            }
            return null;
        }

        /// <summary>
        /// Finds the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns></returns>
        public ICollection<TValue> Find(ISpecification<TValue> criteria)
        {
            ICollection<TValue> result = new List<TValue>();
            foreach (KeyValuePair<TKey, TValue> pair in map)
            {
                if (criteria.IsSatisfiedBy(pair.Value))
                {
                    result.Add(pair.Value);
                }
            }
            return result;
        }


        /// <summary>
        /// Removes the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        public ICollection<TKey> Remove(ISpecification<TValue> criteria)
        {
            List<TKey> removeKeys = new List<TKey>();
            foreach (KeyValuePair<TKey, TValue> pair in map)
            {
                if (criteria.IsSatisfiedBy(pair.Value))
                {
                    removeKeys.Add(pair.Key);
                }
            }
            foreach (TKey key in removeKeys)
            {
                map.Remove(key);
            }
            return removeKeys;
        }

        /// <summary>
        /// Counts the specified criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns></returns>
        public long Count(ISpecification<TValue> criteria)
        {
            long count = 0;
            foreach (KeyValuePair<TKey, TValue> pair in map)
            {
                if (criteria.IsSatisfiedBy(pair.Value))
                {
                    count++;
                }
            }
            return count;
        }
    }
}