namespace AgriMore.Logistics.Domain.Transaction
{
    /// <summary>
    /// Represents the ITransactionManager interface.
    /// </summary>
    public interface ITransactionManager
    {
        /// <summary>
        /// Begins the transaction.
        /// </summary>
        void BeginTransaction();

        /// <summary>
        /// Commits the transaction.
        /// </summary>
        void CommitTransaction();

        /// <summary>
        /// Rolls the transaction back.
        /// </summary>
        void RollbackTransaction();
    }
}
