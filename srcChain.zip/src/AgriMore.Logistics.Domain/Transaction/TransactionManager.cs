using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Transaction
{
    /// <summary>
    /// Represents the TransactionManager class.
    /// </summary>
    public class TransactionManager
    {
        private ITransactionManager concreteTransactionManager;
        /// <summary>
        /// Initializes a new instance of the <see cref="TransactionManager"/> class.
        /// </summary>
        public TransactionManager()
        {
            concreteTransactionManager = RepositoryFactory.CreateTransactionManager();
        }

        /// <summary>
        /// Gets or sets the concrete transaction manager.
        /// </summary>
        /// <value>The concrete transaction manager.</value>
        public ITransactionManager ConcreteTransactionManager
        {
            get
            {
                return concreteTransactionManager;
            }
            set
            {
                concreteTransactionManager = value;
            }
        }

        #region ITransactionManager Members

        /// <summary>
        /// Begins the transaction.
        /// </summary>
        public void BeginTransaction()
        {
            concreteTransactionManager.BeginTransaction();
        }

        /// <summary>
        /// Commits the transaction.
        /// </summary>
        public void CommitTransaction()
        {
            concreteTransactionManager.CommitTransaction();
        }

        /// <summary>
        /// Rollbacks the transaction.
        /// </summary>
        public void RollbackTransaction()
        {
            concreteTransactionManager.RollbackTransaction();
        }

        #endregion
    }
}