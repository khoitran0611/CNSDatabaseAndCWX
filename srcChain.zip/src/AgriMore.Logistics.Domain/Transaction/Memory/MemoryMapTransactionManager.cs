using System.Diagnostics;

namespace AgriMore.Logistics.Domain.Transaction.Memory
{
    /// <summary>
    /// Represents the MemoryMapTransactionManager class.
    /// </summary>
    public class MemoryMapTransactionManager : ITransactionManager
    {
        /// <summary>
        /// Begins the transaction.
        /// </summary>
        public void BeginTransaction()
        {
            Debug.WriteLine("BeginTransaction");
        }

        /// <summary>
        /// Commits the transaction.
        /// </summary>
        public void CommitTransaction()
        {
            Debug.WriteLine("CommitTransaction");
        }

        /// <summary>
        /// Rolls the transaction back.
        /// </summary>
        public void RollbackTransaction()
        {
            Debug.WriteLine("RollbackTransaction");
        }
    }
}
