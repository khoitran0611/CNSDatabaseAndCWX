using System;
using System.Collections.Generic;
using System.Text;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// The ShipmentExposure contains the prescribed temperatures for a shipment
    /// for the time that it is created.
    /// </summary>
    public class ShipmentExposure : IIdentifyable
    {
        private long uid;
        private readonly double documentedValue;
        private readonly double prescribedStartValue;
        private readonly double prescribedEndValue;
        private readonly ExposureType exposureType;

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentExposure"/> class.
        /// </summary>
        protected ShipmentExposure()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentExposure"/> class.
        /// </summary>
        /// <param name="prescribedStartValue">The prescribed start value.</param>
        /// <param name="prescribedEndValue">The prescribed end value.</param>
        /// <param name="documentedValue">The documented value.</param>
        /// <param name="exposureType">Type of the exposure.</param>
        public ShipmentExposure(double prescribedStartValue, double prescribedEndValue, double documentedValue, ExposureType exposureType)
        {
            if (prescribedEndValue < prescribedStartValue)
            {
                throw new ArgumentException("Prescribed start value must be great than Prescribed end value");
            }

            if (exposureType == null)
            {
                throw new ArgumentNullException("exposureType");
            }

            this.prescribedStartValue = prescribedStartValue;
            this.prescribedEndValue = prescribedEndValue;
            this.documentedValue = documentedValue;
            this.exposureType = exposureType;
        }


        #region IIdentifyable Members


        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Gets the start range value.
        /// </summary>
        /// <value>The start range value.</value>
        public double PrescribedStartValue
        {
            get { return prescribedStartValue; }
        }

        /// <summary>
        /// Gets the prescribed end value.
        /// </summary>
        /// <value>The prescribed end value.</value>
        public double PrescribedEndValue
        {
            get { return prescribedEndValue; }
        }


        /// <summary>
        /// Gets the documented value.
        /// </summary>
        /// <value>The documented value.</value>
        public double DocumentedValue
        {
            get { return documentedValue; }
        }

        /// <summary>
        /// Gets the type of the exposure.
        /// </summary>
        /// <value>The type of the exposure.</value>
        public ExposureType ExposureType
        {
            get { return exposureType; }
        }


        
    }
}
