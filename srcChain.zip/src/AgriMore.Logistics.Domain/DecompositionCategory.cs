using System;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;
using System.Linq;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// This class functions as a umbrella / filter for the PackagTypes
    /// </summary>
    public class DecompositionCategory : IIdentifyable
    {
        private readonly ISet decompositionTypes = new HashedSet();
        private string name;
        private long uid;
        private ISet decompositionCategoryLangs = new HashedSet();

        /// <summary>
        /// 
        /// </summary>
        public DecompositionCategory()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        public DecompositionCategory(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            if (name.Trim().Length == 0)
            {
                throw new ArgumentException("Name cannot be empty.");
            }

            this.name = name;
        }

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            DecompositionCategory other = obj as DecompositionCategory;
            if (other == null)
            {
                return false;
            }
            if (other.name == name)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return name.GetHashCode();
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return uid.ToString();
        }

        /// <summary>
        /// Gets the TreatmentTypes.
        /// </summary>
        /// <value>The treatments.</value>
        public IEnumerable<DecompositionType> DecompositionTypes
        {
            get
            {
                return ListHandler.ConvertToGenericList<DecompositionType>(decompositionTypes);
            }
        }

        /// <summary>
        /// Adds the type of the treatment.
        /// </summary>
        /// <param name="treatmentType">Type of the treatment.</param>
        public void AddDecompositionType(DecompositionType treatmentType)
        {
            decompositionTypes.Add(treatmentType);
        }

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            DecompositionCategoryLang categoryLang = CategoryLangs.Where(it => it.LangCode.Equals(langCode)).SingleOrDefault();

            return categoryLang == null ? Name : categoryLang.Name;
        }

        /// <summary>
        /// Gets or sets the CatTypeLangs.
        /// </summary>
        public IList<DecompositionCategoryLang> CategoryLangs
        {
            get { return ListHandler.ConvertToGenericList<DecompositionCategoryLang>(decompositionCategoryLangs); }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="categoryLang"></param>
        public void AddCategoryLangToList(DecompositionCategoryLang categoryLang)
        {
            decompositionCategoryLangs.Add(categoryLang);
        }

        /// <summary>
        /// Remove CategoryLangs
        /// </summary>
        public void RemoveCategoryLangFromList()
        {
            decompositionCategoryLangs.Clear();
        }

        /// <summary>
        /// Remove CategoryLangs
        /// </summary>
        public void RemoveCategoryLangFromList(DecompositionCategoryLang categoryLang)
        {
            decompositionCategoryLangs.Remove(categoryLang);
        }        
    }
}