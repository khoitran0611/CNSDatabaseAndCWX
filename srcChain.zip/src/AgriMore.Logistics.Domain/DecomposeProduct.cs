﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class DecomposeProduct
    {
        /// <summary>
        /// Gets or sets from identifier.
        /// </summary>
        /// <value>
        /// From identifier.
        /// </value>
        public long FromIdentifier { get; set; }
        /// <summary>
        /// Gets or sets to identifier.
        /// </summary>
        /// <value>
        /// To identifier.
        /// </value>
        public long ToIdentifier { get; set; }
        /// <summary>
        /// Gets or sets the primary product.
        /// </summary>
        /// <value>
        /// The primary product.
        /// </value>
        public PrimaryProduct PrimaryProd { get; set; }

        public string ForOrgId { get; set; }

        public long RootProdId { get; set; }

        public long FromProdId { get; set; }

        public long ToProdId { get; set; }

        public decimal KeyFigureVal { get; set; }

        public decimal KeyFigureWeight { get; set; }

        /// <summary>
        /// Gets or sets the package.
        /// </summary>
        /// <value>
        /// The package.
        /// </value>
        public ThirdPartyEntities.PackagingDefine Package { get; set; }
    }
}
