using System;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;
using log4net;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// A Shipment is a planned delivery of packages from a shipping chain entity to a receiving chain entity. 
    /// A Shipment contains the packages for pickup and delivery. A shipment allows tracking of the packages
    /// in transport from pickup to delivery. A shipment ensures that the 
    /// shipment can only be delivered to the correct receiving chain entity, and that the pickup location needs to be owned by
    /// the shipping chain entity.
    /// 
    /// </summary>
    public class Shipment : IIdentifyable
    {
        private readonly DateTime beginDeliverDateTime;
        private readonly DateTime beginPickUpDateTime;
        private readonly DateTime endDeliverDateTime;
        private readonly DateTime endPickUpDateTime;
        private readonly ChainEntity forwarder;
        private readonly string forwarderMailaddress;
        private readonly string forwarderReferenceId;
        private readonly ILog log = LogManager.GetLogger(typeof (Shipment));
        private readonly ISet packages = new HashedSet();
        private readonly Location pickupLocation;
        private readonly ChainEntity receiver;
        private readonly string receiverMailaddress;
        private readonly string receiverReferenceId;
        private readonly ISet shipmentExposures = new HashedSet();
        private readonly ChainEntity shipper;
        private readonly string shipperReferenceId;
        private Location deliveryLocation;
        private bool isDelivered;
        private bool isShipped;
        private DateTime realDateTimeOfDelivery = DateTime.MinValue;
        private DateTime realDateTimeOfPickup = DateTime.MinValue;
        private string remarks;
        private long uid;
        private string loadingAdviceDocName;        
        private string loadingAdviceDocPath;        

        /// <summary>
        /// Initializes a new instance of the <see cref="Shipment"/> class.
        /// </summary>
        protected Shipment()
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="Shipment"/> class.
        /// </summary>
        /// <param name="shipper">The shipping chain entity.</param>
        /// <param name="receiver">The receiving chain entity.</param>
        /// <param name="forwarder">The forwarder.</param>
        /// <param name="shipperReferenceId">The shipper reference id.</param>
        /// <param name="forwarderReferenceId">The forwarder reference id.</param>
        /// <param name="receiverReferenceId">The receiver reference id.</param>
        /// <param name="packages">The packages.</param>
        /// <param name="pickupLocation">The pickup location.</param>
        /// <param name="deliveryLocation">The delivery location.</param>
        /// <param name="pickUpDateTimeRange">The pick up date time range.</param>
        /// <param name="deliverDateTimeRange">The deliver date time range.</param>
        /// <param name="forwarderMailaddress">The forwarder mailaddress.</param>
        /// <param name="receiverMailaddress">The receiver mailaddress.</param>
        /// <param name="shipmentExposures">The shipment exposures.</param>
        public Shipment(ChainEntity shipper, ChainEntity receiver, ChainEntity forwarder,
                        string shipperReferenceId,
                        string forwarderReferenceId,
                        string receiverReferenceId,
                        IEnumerable<Package> packages,
                    Location pickupLocation,
                        Location deliveryLocation,
                        IRange<DateTime> pickUpDateTimeRange,
                        IRange<DateTime> deliverDateTimeRange,
                        string forwarderMailaddress, string receiverMailaddress,
                        IEnumerable<ShipmentExposure> shipmentExposures
            )
        {
            if (shipper == null)
            {
                log.Debug("shipper is null");
                throw new ArgumentNullException("shipper");
            }

            if (receiver == null)
            {
                log.Debug("receiver is null");
                throw new ArgumentNullException("receiver");
            }
            if (forwarder == null)
            {
                log.Debug("forwarder is null");
                throw new ArgumentNullException("forwarder");
            }

            if (pickupLocation == null)
            {
                log.Debug("pickupLocation is null");
                throw new ArgumentNullException("pickupLocation");
            }

            if (deliveryLocation == null)
            {
                log.Debug("pickupLocation is null");
                throw new ArgumentNullException("deliveryLocation");
            }

            if (packages == null)
            {
                log.Debug("packages is null");
                throw new ArgumentNullException("packages");
            }

            this.packages.AddAll(new List<Package>(packages));
            if (this.packages.Count == 0)
            {
                log.Debug("packages provided to shipment is empty");
                throw new ArgumentException("A shipment must contain at least one package");
            }

            if (shipmentExposures == null)
            {
                log.Debug("shipmentExposures is null");
                throw new ArgumentNullException("shipmentExposures");
            }

            this.shipmentExposures.AddAll(new List<ShipmentExposure>(shipmentExposures));

            if (!shipper.Contains(pickupLocation))
            {
                log.Debug(
                    string.Format("shipping chain entity {0} does not own location {1}.", shipper.Name,
                                  pickupLocation.Name));
                throw new ArgumentException("The pickup location specified is not owned by the shipper specified");
            }

            if (forwarderMailaddress == null)
            {
                throw new ArgumentNullException("forwarderMailaddress");
            }

            if (receiverMailaddress == null)
            {
                throw new ArgumentNullException("receiverMailaddress");
            }

            this.pickupLocation = pickupLocation;
            this.deliveryLocation = deliveryLocation;
            this.shipper = shipper;
            this.receiver = receiver;
            this.forwarder = forwarder;
            this.forwarderMailaddress = forwarderMailaddress;
            this.receiverMailaddress = receiverMailaddress;
            beginPickUpDateTime = pickUpDateTimeRange.Start;
            endPickUpDateTime = pickUpDateTimeRange.End;
            beginDeliverDateTime = deliverDateTimeRange.Start;
            endDeliverDateTime = deliverDateTimeRange.End;
            this.shipperReferenceId = shipperReferenceId;
            this.receiverReferenceId = receiverReferenceId;
            this.forwarderReferenceId = forwarderReferenceId;
        }


        /// <summary>
        /// Gets the pick up date time range.
        /// </summary>
        /// <value>The pick up date time range.</value>
        public IRange<DateTime> PickUpDateTimeRange
        {
            get { return new Range<DateTime>(beginPickUpDateTime, endPickUpDateTime); }
        }

        /// <summary>
        /// Gets the deliver date time range.
        /// </summary>
        /// <value>The deliver date time range.</value>
        public IRange<DateTime> DeliverDateTimeRange
        {
            get { return new Range<DateTime>(beginDeliverDateTime, endDeliverDateTime); }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is shipped.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is shipped; otherwise, <c>false</c>.
        /// </value>
        public bool IsShipped
        {
            get { return isShipped; }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is delivered.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is delivered; otherwise, <c>false</c>.
        /// </value>
        public bool IsDelivered
        {
            get { return isDelivered; }
        }

        /// <summary>
        /// Gets or sets the pickupLocation.
        /// </summary>
        /// <value>The pickupLocation.</value>
        public Location PickupLocation
        {
            get { return pickupLocation; }
        }

        /// <summary>
        /// Gets the deliver location.
        /// </summary>
        /// <value>The deliver location.</value>
        public Location DeliveryLocation
        {
            get { return deliveryLocation; }
        }

        /// <summary>
        /// Gets the packages.
        /// </summary>
        /// <value>The packages.</value>
        public ICollection<Package> Packages
        {
            get { return ListHandler.ConvertToGenericList<Package>(packages); }
        }


        /// <summary>
        /// Gets the shipment exposures.
        /// </summary>
        /// <value>The shipment exposures.</value>
        public ICollection<ShipmentExposure> ShipmentExposures
        {
            get { return ListHandler.ConvertToGenericList<ShipmentExposure>(shipmentExposures); }
        }


        /// <summary>
        /// Gets the forwarder.
        /// </summary>
        /// <value>The forwarder.</value>
        public ChainEntity Forwarder
        {
            get { return forwarder; }
        }

        /// <summary>
        /// Gets the shipper.
        /// </summary>
        /// <value>The shipper.</value>
        public ChainEntity Shipper
        {
            get { return shipper; }
        }


        /// <summary>
        /// Gets the receiver.
        /// </summary>
        /// <value>The receiver.</value>
        public ChainEntity Receiver
        {
            get { return receiver; }
        }

        /// <summary>
        /// Gets the forwarder mailaddress.
        /// </summary>
        /// <value>The forwarder mailaddress.</value>
        public string ForwarderMailaddress
        {
            get { return forwarderMailaddress; }
        }

        /// <summary>
        /// Gets the receiver mailaddress.
        /// </summary>
        /// <value>The receiver mailaddress.</value>
        public string ReceiverMailaddress
        {
            get { return receiverMailaddress; }
        }

        /// <summary>
        /// Gets the shipper reference id.
        /// </summary>
        /// <value>The shipper reference id.</value>
        public string ShipperReferenceId
        {
            get { return shipperReferenceId; }
        }

        /// <summary>
        /// Gets the receiver reference id.
        /// </summary>
        /// <value>The receiver reference id.</value>
        public string ReceiverReferenceId
        {
            get { return receiverReferenceId; }
        }

        /// <summary>
        /// Gets the forwarder reference id.
        /// </summary>
        /// <value>The forwarder reference id.</value>
        public string ForwarderReferenceId
        {
            get { return forwarderReferenceId; }
        }

        /// <summary>
        /// Gets the date time of delivery.
        /// </summary>
        /// <value>The date time of delivery.</value>
        public DateTime RealDateTimeOfDelivery
        {
            get { return realDateTimeOfDelivery; }
        }

        /// <summary>
        /// Gets the remarks.
        /// </summary>
        /// <value>The remarks.</value>
        public string Remarks
        {
            get { return remarks; }
        }

        /// <summary>
        /// Gets the date time of pickup.
        /// </summary>
        /// <value>The date time of pickup.</value>
        public DateTime RealDateTimeOfPickup
        {
            get { return realDateTimeOfPickup; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string LoadingAdviceDocName
        {
            get { return loadingAdviceDocName; }
            set { loadingAdviceDocName = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string LoadingAdviceDocPath
        {
            get { return loadingAdviceDocPath; }
            set { loadingAdviceDocPath = value; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Determines whether [is all packages in pickup location].
        /// </summary>
        /// <returns>
        /// 	<c>true</c> if [is all packages in pickup location]; otherwise, <c>false</c>.
        /// </returns>
        public bool ArePackagesInPickupLocation()
        {
            foreach (Package package in packages)
            {
                if (!pickupLocation.Contains(package))
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Determines whether the specified delivery location is valid
        /// </summary>
        /// <param name="deliveryLocation">The delivery location.</param>
        /// <returns>
        /// 	<c>true</c> if the delivery location is valid according to the shipment]; otherwise, <c>false</c>.
        /// </returns>
        public bool IsDeliveryLocationValid(Location deliveryLocation)
        {
            return receiver.Contains(deliveryLocation);
        }

        /// <summary>
        /// Determines whether this shipment contains the specified package.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <returns>
        /// 	<c>true</c> if this shipment contains the specified package; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(Package package)
        {
            return packages.Contains(package);
        }


        /// <summary>
        /// Delivers the specified actual date time of delivery.
        /// </summary>
        /// <param name="actualDateTimeOfDelivery">The actual date time of delivery.</param>
        /// <param name="remarks">The remarks.</param>
        /// <param name="realDeliveryLocation">The real delivery location.</param>
        public void Deliver(DateTime actualDateTimeOfDelivery, string remarks, Location realDeliveryLocation)
        {
            realDateTimeOfDelivery = actualDateTimeOfDelivery;
            deliveryLocation = realDeliveryLocation;
            this.remarks = remarks;
            isDelivered = true;
            isShipped = false;
        }


        /// <summary>
        /// Pickups the specified actual date time of pickup.
        /// </summary>
        /// <param name="actualDateTimeOfPickup">The actual date time of pickup.</param>
        public void Pickup(DateTime actualDateTimeOfPickup)
        {
            realDateTimeOfPickup = actualDateTimeOfPickup;
            isDelivered = false;
            isShipped = true;
        }


        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return pickupLocation.GetHashCode();
        }

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            Shipment other = obj as Shipment;
            if (other == null)
            {
                return false;
            }

            if (Uid != 0)
            {
                return (Uid == other.Uid);
            }

            if (other.packages.Count != packages.Count)
            {
                return false;
            }
            if (other.pickupLocation.Equals(pickupLocation) &&
                other.shipper.Equals(shipper) &&
                other.forwarder.Equals(forwarder) &&
                other.receiver.Equals(receiver))
            {
                int count = 0;
                foreach (Package otherPackage in other.packages)
                {
                    foreach (Package package in packages)
                    {
                        if (package.Equals(otherPackage))
                        {
                            count++;
                            break;
                        }
                    }
                }
                if (count == packages.Count)
                {
                    return true;
                }
            }
            return false;
        }
    }
}