﻿namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    public class ArrayIds
    {
        public string[] Ids { get; set; }
    }
}
