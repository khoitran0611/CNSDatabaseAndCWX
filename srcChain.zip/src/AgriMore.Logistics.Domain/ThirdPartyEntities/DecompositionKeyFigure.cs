﻿namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    public class DecompositionKeyFigure
    {
        public virtual long Uid { get; set; }

        public virtual string ForOrgId { get; set; }

        public virtual long RootProdId { get; set; }

        public virtual Product FromProduct { get; set; }

        public virtual Product ToProduct { get; set; }

        public virtual decimal FigureVal { get; set; }

        public virtual string CreatedOrgId { get; set; }
    }
}
