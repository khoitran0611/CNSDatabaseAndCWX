﻿using System;

namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    /// <summary>
    /// 
    /// </summary>
    public class ShipmentInfo
    {
        /// <summary>
        /// Gets or sets the product supply ids.
        /// </summary>
        /// <value>
        /// The product supply ids.
        /// </value>
        public string ProductSupplyIds { get; set; }

        /// <summary>
        /// Gets or sets from date.
        /// </summary>
        /// <value>
        /// From date.
        /// </value>
        public DateTime FromDate { get; set; }

        /// <summary>
        /// Gets or sets to date.
        /// </summary>
        /// <value>
        /// To date.
        /// </value>
        public DateTime ToDate { get; set; }

        /// <summary>
        /// Gets or sets the created user identifier.
        /// </summary>
        /// <value>
        /// The created user identifier.
        /// </value>
        public string CreatedUserId { get; set; }

        /// <summary>
        /// Gets or sets the receiver chain entity identifier.
        /// </summary>
        /// <value>
        /// The receiver chain entity identifier.
        /// </value>
        public long ReceiverChainEntityId { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string LoadingAdviceDocName
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string LoadingAdviceDocPath
        {
            get;
            set;
        }
    }
}
