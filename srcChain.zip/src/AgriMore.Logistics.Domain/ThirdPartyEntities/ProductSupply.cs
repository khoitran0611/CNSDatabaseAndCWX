﻿using System;

namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    /// <summary>
    /// 
    /// </summary>
    public class ProductSupply
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductSupply"/> class.
        /// </summary>
        public ProductSupply()
        {
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>
        /// The uid.
        /// </value>
        public long Uid { get; set; }

        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>
        /// The parent identifier.
        /// </value>
        public long ParentId { get; set; }

        /// <summary>
        /// Gets or sets the available date.
        /// </summary>
        /// <value>
        /// The available date.
        /// </value>
        public DateTime AvailableDate { get; set; }

        /// <summary>
        /// Gets or sets the amount.
        /// </summary>
        /// <value>
        /// The amount.
        /// </value>
        public decimal Amount { get; set; }        

        /// <summary>
        /// Gets or sets the uo m.
        /// </summary>
        /// <value>
        /// The uo m.
        /// </value>
        public UoM UoM { get; set; }

        /// <summary>
        /// Gets or sets the product.
        /// </summary>
        /// <value>
        /// The product.
        /// </value>
        public Product Product { get; set; }

        /// <summary>
        /// Gets or sets the address identifier.
        /// </summary>
        /// <value>
        /// The address identifier.
        /// </value>
        public long AddressId { get; set; }

        /// <summary>
        /// Gets or sets the location identifier.
        /// </summary>
        /// <value>
        /// The location identifier.
        /// </value>
        public long LocationId { get; set; }

        public string StrOrgId { get; set; }

        /// <summary>
        /// Gets or sets the organization identifier.
        /// </summary>
        /// <value>
        /// The organization identifier.
        /// </value>
        public long OrganizationId { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public long PurchaseChainEntityId { get; set; }

        /// <summary>
        /// Gets or sets the sales org identifier.
        /// </summary>
        /// <value>
        /// The sales org identifier.
        /// </value>
        public long SalesOrgId { get; set; }

        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>
        /// The quantity.
        /// </value>
        public int Quantity { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is packed by chain.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is packed by chain; otherwise, <c>false</c>.
        /// </value>
        public bool IsPackedByChain { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is decomposed.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is decomposed; otherwise, <c>false</c>.
        /// </value>
        public bool IsDecomposed { get; set; }

        /// <summary>
        /// Gets or sets the sale status.
        /// </summary>
        /// <value>
        /// The seller status.
        /// </value>
        public SellerStatus SaleStatus { get; set; }

        /// <summary>
        /// Gets or sets the buy status.
        /// </summary>
        /// <value>
        /// The buyer status.
        /// </value>
        public BuyerStatus BuyStatus { get; set; }

        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>
        /// The version.
        /// </value>
        public long Version { get; set; }
    }

    /// <summary>
    /// </summary>
    public enum SellerStatus
    {
        ///<summary>
        /// Committed Sold
        ///</summary>
        CommittedSold = 1,

        ///<summary>
        /// Actual Amount Sold and despatched
        ///</summary>
        ActualAmountSoldAndDespatched = 2,

        ///<summary>
        /// The product is already shipped
        ///</summary>
        Shipped = 3
    }

    ///<summary>
    ///</summary>
    public enum BuyerStatus
    {
        ///<summary>
        /// Committed Bought
        ///</summary>
        CommittedBought = 1,

        ///<summary>
        /// Actual Amount Bought and Received
        ///</summary>
        ActualAmountBoughtAndReceived = 2
    }
}
