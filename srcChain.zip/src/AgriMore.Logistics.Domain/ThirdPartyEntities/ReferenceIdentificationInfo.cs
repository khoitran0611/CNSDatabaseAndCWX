﻿namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    /// <summary>
    /// 
    /// </summary>
    public class ReferenceIdentificationInfo
    {
        public int Id { get; set; }

        public long ChainEntityId { get; set; }

        public string IdentificationFrom { get; set; }

        public string IdentificationTo { get; set; }

        public string ReferenceFrom { get; set; }

        public string ReferenceTo { get; set; }
    }
}
