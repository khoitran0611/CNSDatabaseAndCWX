﻿using AgriMore.Logistics.Domain.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    /// <summary>
    /// 
    /// </summary>
    public class PackagingMaterial
    {
        private long uid;
        private string name;        
        
        /// <summary>
        /// 
        /// </summary>
        public PackagingMaterial() 
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        public PackagingMaterial(string name)
        {            
            this.Name = name;
        }

        /// <summary>
        /// 
        /// </summary>
        public long Uid
        { 
            get { return uid; }
            set { this.uid = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Name 
        { 
            get { return name; }
            set { this.name = value; }
        }        
    }
}
