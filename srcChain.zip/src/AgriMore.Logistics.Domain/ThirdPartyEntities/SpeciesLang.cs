﻿namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    /// <summary>
    /// 
    /// </summary>
    public class SpeciesLang
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SpeciesLang"/> class.
        /// </summary>
        public SpeciesLang()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SpeciesLang"/> class.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="langCode"></param>
        public SpeciesLang(string name, string langCode)
        {
            this.Name = name;
            this.LangCode = langCode;
        }

        /// <summary>
        /// Gets or sets the Uid
        /// </summary>
        public long Uid { get; set; }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the LangCode
        /// </summary>
        public string LangCode { get; set; }
    }
}
