﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    /// <summary>
    /// 
    /// </summary>
    public class Product : IEquatable<Product>
    {
        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>
        /// The uid.
        /// </value>
        public long Uid { get; set; }

        ///<summary>
        /// Gets or sets Gs1 code
        ///</summary>
        public string Gs1Code { get; set; }

        ///<summary>
        /// Gets or sets LedgerCode code
        ///</summary>
        public string LedgerCode { get; set; }

        ///<summary>
        /// Gets or sets Other code
        ///</summary>
        public string OtherCode { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            SpeciesLang speciesLang = SpeciesLangs.SingleOrDefault(it => it.LangCode.Equals(langCode));

            return speciesLang == null ? Name : speciesLang.Name;
        }

        /// <summary>
        /// Gets or sets the species langs.
        /// </summary>
        /// <value>
        /// The species langs.
        /// </value>
        public IList<SpeciesLang> SpeciesLangs { get; set; }

        public bool Equals(Product other)
        {
            return Uid == other.Uid;
        }

        public override int GetHashCode()
        {
            return Uid.GetHashCode();
        }
    }
}
