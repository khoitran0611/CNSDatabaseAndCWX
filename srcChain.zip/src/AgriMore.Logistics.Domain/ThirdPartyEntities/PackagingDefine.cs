﻿using System.Collections.Generic;
using System.Linq;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    ///<summary>
    ///</summary>
    public class PackagingDefine
    {
        private long uid;
        private string name;
        private string gs1Code;
        private string ledgerCode;
        private string otherCode;
        private decimal packagingAmount;
        private decimal price;
        private decimal rentPrice;
        private decimal depositPrice;
        private string currency;
        private PackageTypeCategory packTypeCategory;
        private UnitOfMeasurement uom;       
        private PackagingMaterial packagingMaterial;
        private UnitOfMeasurement widthUoM;        
        private UnitOfMeasurement lengthUoM;       
        private UnitOfMeasurement heightUoM;        
        private UnitOfMeasurement weightUoM; 
        private int widthValue;
        private int heightValue;
        private int weightValue;
        private int lengthValue;
        private bool isVantilated;
        private bool isSealed;  

        /// <summary>
        /// Initializes a new instance of the <see cref="PackagingDefine"/> class.
        /// </summary>
        public PackagingDefine()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="packagingAmount"></param>
        /// <param name="price"></param>
        /// <param name="currency"></param>
        /// <param name="uom"></param>
        /// <param name="packagingMaterial"></param>
        /// <param name="widthUoM"></param>
        /// <param name="heightUoM"></param>
        /// <param name="lengthUoM"></param>
        /// <param name="weightUoM"></param>
        /// <param name="widthValue"></param>
        /// <param name="heightValue"></param>
        /// <param name="lengthValue"></param>
        /// <param name="weightValue"></param>
        /// <param name="isVentilated"></param>
        /// <param name="isSealed"></param>
        public PackagingDefine(string name, long packagingAmount, decimal price, string currency, 
            UnitOfMeasurement uom, PackagingMaterial packagingMaterial,
            UnitOfMeasurement widthUoM, UnitOfMeasurement heightUoM, UnitOfMeasurement lengthUoM,
            UnitOfMeasurement weightUoM, int widthValue, int heightValue, int lengthValue, int weightValue, bool isVentilated, bool isSealed)
        {
            this.name = name;
            this.packagingAmount = packagingAmount;
            this.price = price;
            this.currency = currency;
            this.uom = uom;            
            this.packagingMaterial = packagingMaterial;
            this.heightUoM = heightUoM;
            this.widthUoM = widthUoM;
            this.weightUoM = weightUoM;
            this.lengthUoM = lengthUoM;
            this.lengthValue = lengthValue;
            this.heightValue = heightValue;
            this.widthValue = widthValue;
            this.weightValue = weightValue;
            this.isVantilated = isVentilated;
            this.isSealed = isSealed;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Packaging Description.
        /// </summary>
        /// <value>The uid.</value>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        ///<summary>
        /// Gets or sets Gs1 code
        ///</summary>
        public string Gs1Code
        {
            get { return gs1Code; }
            set { gs1Code = value; }
        }

        ///<summary>
        /// Gets or sets LedgerCode code
        ///</summary>
        public string LedgerCode
        {
            get { return ledgerCode; }
            set { ledgerCode = value; }
        }



        ///<summary>
        /// Gets or sets Other code
        ///</summary>
        public string OtherCode
        {
            get { return otherCode; }
            set { otherCode = value; }
        }

        /// <summary>
        /// Gets or sets the Packaging Amount.
        /// </summary>
        /// <value>The uid.</value>
        public decimal PackagingAmount
        {
            get { return packagingAmount; }
            set { packagingAmount = value; }
        }

        /// <summary>
        /// Gets or sets the price.
        /// </summary>
        /// <value>The uid.</value>
        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }

        /// <summary>
        /// Gets or sets the price.
        /// </summary>
        /// <value>The uid.</value>
        public decimal RentPrice
        {
            get { return rentPrice; }
            set { rentPrice = value; }
        }

        /// <summary>
        /// Gets or sets the price.
        /// </summary>
        /// <value>The uid.</value>
        public decimal DepositPrice
        {
            get { return depositPrice; }
            set { depositPrice = value; }
        }

        /// <summary>
        /// Gets or sets the Currency.
        /// </summary>
        /// <value>The uid.</value>
        public string Currency
        {
            get { return currency; }
            set { currency = value; }
        }

        /// <summary>
        /// Gets or sets the Unit Of Measurement.
        /// </summary>
        /// <value>The uid.</value>
        public UnitOfMeasurement Uom
        {
            get { return uom; }
            set { uom = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public UnitOfMeasurement WidthUoM
        {
            get { return widthUoM; }
            set { widthUoM = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public UnitOfMeasurement LengthUoM
        {
            get { return lengthUoM; }
            set { lengthUoM = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public UnitOfMeasurement HeightUoM
        {
            get { return heightUoM; }
            set { heightUoM = value; }
        }

        /// <summary>
        /// m
        /// </summary>
        public UnitOfMeasurement WeightUoM
        {
            get { return weightUoM; }
            set { weightUoM = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int WidthValue
        {
          get { return widthValue; }
          set { widthValue = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int HeightValue
        {
          get { return heightValue; }
          set { heightValue = value; }
        } 

        /// <summary>
        /// 
        /// </summary>
        public int WeightValue
        {
          get { return weightValue; }
          set { weightValue = value; }
        } 

        /// <summary>
        /// 
        /// </summary>
        public int LenghtValue
        {
          get { return lengthValue; }
          set { lengthValue = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public bool IsVantilated
        {
            get { return isVantilated; }
            set { isVantilated = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public bool IsSealed
        {
            get { return isSealed; }
            set { isSealed = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public PackagingMaterial PackagingMaterial
        {
            get { return packagingMaterial; }
            set { packagingMaterial = value; }
        }

        /// <summary>
        /// Gets or sets the Package Type Catagory.
        /// </summary>
        public PackageTypeCategory PackTypeCategory
        {
            get { return packTypeCategory; }
            set { packTypeCategory = value; }
        }   
    }
}
