﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    /// <summary>
    /// 
    /// </summary>
    public class TreatmentType
    {
        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>
        /// The uid.
        /// </value>
        public long Uid { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the GS1 code.
        /// </summary>
        /// <value>
        /// The GS1 code.
        /// </value>
        public string Gs1Code { get; set; }

        /// <summary>
        /// Gets or sets the other code.
        /// </summary>
        /// <value>
        /// The other code.
        /// </value>
        public string OtherCode { get; set; }

        /// <summary>
        /// Gets or sets the ledger code.
        /// </summary>
        /// <value>
        /// The ledger code.
        /// </value>
        public string LedgerCode { get; set; }

        /// <summary>
        /// Gets or sets the product GRP langs.
        /// </summary>
        /// <value>
        /// The product GRP langs.
        /// </value>
        public IList<TreatmentTypeLang> CategoryLangs { get; set; }
        public TreatmentTypeCategory TreatmentTypeCategory { get; set; }
        public UnitOfMeasurement UnitOfMeasurement { get; set; }
    }
}
