﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    /// <summary>
    /// 
    /// </summary>
    public class DecompositionEx
    {
        /// <summary>
        /// 
        /// </summary>
        public DateTime PeriodFrom { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime PeriodTo { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public decimal Cost { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string CostCurrency { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public long DecompositionTypeId { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public long PackageId { get; set; }
    }
}
