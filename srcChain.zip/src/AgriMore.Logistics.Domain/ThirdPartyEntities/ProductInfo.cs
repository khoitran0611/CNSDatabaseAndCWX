﻿namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    public class ProductInfo
    {
        public string Uid { get; set; }

        public string Name { get; set; }

        public decimal Amount { get; set; }

        public string UoMName { get; set; }

        public long UoMId { get; set; }
    }
}
