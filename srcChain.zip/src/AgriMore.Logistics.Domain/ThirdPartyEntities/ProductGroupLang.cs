﻿namespace AgriMore.Logistics.Domain.ThirdPartyEntities
{
    /// <summary>
    /// 
    /// </summary>
    public class ProductGroupLang
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductGroupLang"/> class.
        /// </summary>
        public ProductGroupLang()
        {
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>
        /// The uid.
        /// </value>
        public long Uid { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the language code.
        /// </summary>
        /// <value>
        /// The language code.
        /// </value>
        public string LangCode { get; set; }

    }
}
