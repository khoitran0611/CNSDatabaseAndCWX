using System.Collections.Generic;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// Shipments for receiver specification
    /// </summary>
    public class DeliveredShipmentForChainEntityNotInLocatoinSpecification : ISpecification<Shipment>
    {
        private readonly Location deliveryLocation;
        private readonly ChainEntity receiver;


        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentsForForwarderSpecification"/> class.
        /// </summary>
        /// <param name="receiver">The receiver.</param>
        /// <param name="deliveryLocation">The delivery location.</param>
        public DeliveredShipmentForChainEntityNotInLocatoinSpecification(ChainEntity receiver, Location deliveryLocation)
        {
            this.deliveryLocation = deliveryLocation;
            this.receiver = receiver;
        }

        #region ISpecification<Shipment> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Shipment element)
        {
            if (!element.IsDelivered) return false;
            if (!element.Receiver.Equals(receiver)) return false;
            if (!element.DeliveryLocation.Equals(deliveryLocation)) return false;

            //Not all packages are put in locations
            List<Package> packagesInShipmentNotYetInLocation = new List<Package>(element.Packages);

            foreach (Package package in element.Packages)
            {
                foreach (Location location in receiver.Locations)
                {
                    if (location.Contains(package) || package.ParentPackage != null)
                    {
                        //The package has been internaly moved from the delivery location.
                        packagesInShipmentNotYetInLocation.Remove(package);
                    }
                }
            }

            return packagesInShipmentNotYetInLocation.Count > 0;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                //string queryString =
                //    "from Shipment shipment " +
                //    "where shipment.IsDelivered = 1 " +
                //    "and shipment.Receiver = :receiver " +
                //    "and shipment.DeliveryLocation = :deliveryLocation " +
                //    "and not exists " +
                //    "(from shipment.Receiver shipmentReceiver " +
                //    "join shipmentReceiver.Addresses address " +
                //    "join address.Locations location " +
                //    "join location.Packages locationPackage " +
                //    "join shipment.Packages shipmentPackage " +
                //    "where locationPackage = shipmentPackage " +
                //    "and shipmentPackage.ParentPackage is null) ";

                string queryString =
                    "from Shipment shipment " +
                    "where shipment.IsDelivered = 1 " +
                    "and shipment.Receiver = :receiver " +
                    "and shipment.DeliveryLocation = :deliveryLocation " +
                    "and exists " +
                    "("+
                        "from shipment.Packages shipmentPackage " +
                        "where not exists " +
                        "("+
                            "from shipment.Receiver receiver " +
                            "join receiver.Addresses address " +
                            "join address.Locations location " +
                            "join location.Packages locationPackage " +
                            "where locationPackage = shipmentPackage " +
                        ") "+
                        "and shipmentPackage.ParentPackage is null " +
                    ") ";
                return
                    new Query(queryString).AddParameter("receiver", receiver).AddParameter("deliveryLocation", deliveryLocation);
            }
        }

        #endregion
    }
}