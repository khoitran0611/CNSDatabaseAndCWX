using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// retrieve all packages that belong to;
    /// - a specific ChainEntity
    /// - not stored in a location
    /// - has packageTypeCategory grootverpakking
    /// </summary>
    public class PackageNotInLocationAndKleinVerpakkingForChainEntity : ISpecification<Package>
    {
        private readonly ChainEntity chainEntity;

        /// <summary>
        /// Initializes a new instance of the <see cref="PackageNotInLocationAndKleinVerpakkingForChainEntity"/> class.
        /// </summary>
        /// <param name="chainEntity">The chain entity.</param>
        public PackageNotInLocationAndKleinVerpakkingForChainEntity(ChainEntity chainEntity)
        {
            if (chainEntity == null)
            {
                throw new ArgumentNullException("chainEntity");
            }

            this.chainEntity = chainEntity;
        }

        #region ISpecification<Package> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Package element)
        {
            if (element.IdentificationForChainEntity(chainEntity) != String.Empty) //package belong to ChainEntity
            {
                bool isInLocation = false;

                foreach (Location location in chainEntity.Locations)
                {
                    if (location.Contains(element))
                    {
                        isInLocation = true;
                        break;
                    }
                }

                if (!isInLocation && element.PackageTypeCategoryId == 3) // Consumer
                {
                    return element.ParentPackage == null; // The last form of the package.
                }
                else
                {
                    return false;
                }
            }

            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from Package package " +
                    "where not exists " +
                    "(from ChainEntity chainEntity " +
                    "join chainEntity.Addresses address " +
                    "join address.Locations location " +
                    "join location.Packages locationPackage " +
                    "where locationPackage = package " +
                    "and chainEntity = :chainEntity) " +
                    //"and package.ParentPackage is null " +
                    //Refactor
                    //"and package.PackageType.PackageTypeCategory.Name = 'retailPackaging' " +
                    "and package.PackageTypeCategoryId = 3 " +
                    "and package.IsSplitted = 0";

                return
                    new Query(queryString).AddParameter("chainEntity", chainEntity);
            }
        }

        #endregion
    }
}