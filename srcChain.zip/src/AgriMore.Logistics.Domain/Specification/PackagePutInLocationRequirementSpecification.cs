using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// retrieve all packages that belong to;
    /// - a specific ChainEntity
    /// - not stored in a location
    /// - has packageTypeCategory grootverpakking
    /// </summary>
    public class PackagePutInLocationRequirementSpecification : ISpecification<Package>
    {
        private readonly ChainEntity chainEntity;
        private readonly ICollection<Shipment> shipments;

        /// <summary>
        /// Initializes a new instance of the <see cref="PackagePutInLocationRequirementSpecification"/> class.
        /// </summary>
        /// <param name="chainEntity">The chain entity.</param>
        /// <param name="shipments">The shipments.</param>
        public PackagePutInLocationRequirementSpecification(ChainEntity chainEntity,ICollection<Shipment> shipments)
        {
            if (chainEntity == null)
            {
                throw new ArgumentNullException("chainEntity");
            }

            this.chainEntity = chainEntity;
            this.shipments = shipments;
        }

        #region ISpecification<Package> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Package element)
        {
            if (element.IdentificationForChainEntity(chainEntity) != String.Empty) //package belong to ChainEntity
            {
                bool packageIsInLocation = false;
                bool packageIsInShipment=false;

                foreach (Location location in chainEntity.Locations)
                {
                    if (location.Contains(element))
                    {
                        packageIsInLocation = true;
                        break;
                    }
                }

                foreach (Shipment shipment in shipments)
                {
                    if(shipment.Contains(element))
                    {
                        packageIsInShipment = true;
                        break;
                    }
                }

                bool packagePackageTypeIsWholeSalePacking = element.PackageType.PackageTypeCategory.Name == "wholesalePackaging";
                bool packageIsNotUnpacked = element.IsUnpacked==false;
                bool packageIsNotInShipment = packageIsInShipment == false;
                bool packageIsNotInChainEntityLocation = packageIsInLocation==false;
                bool packageIsNotPacked = element.ParentPackage == null;

                if (packagePackageTypeIsWholeSalePacking && 
                    packageIsNotUnpacked && 
                    packageIsNotInShipment && 
                    packageIsNotInChainEntityLocation && 
                    packageIsNotPacked)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                return null;
            }
        }

        #endregion
    }
}