using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// 
    /// </summary>
    public class ShipmentsForShipperSpecification : ISpecification<Shipment>
    {
        private readonly ChainEntity shipper;
        private readonly bool isShipped;
        private readonly bool isDelivered;


        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentsForShipperSpecification"/> class.
        /// </summary>
        /// <param name="shipper">The shipper.</param>
        /// <param name="isShipped">if set to <c>true</c> [is shipped].</param>
        /// <param name="isDelivered">if set to <c>true</c> [is delivered].</param>
        public ShipmentsForShipperSpecification(ChainEntity shipper, bool isShipped, bool isDelivered)
        {
            this.isShipped = isShipped;
            this.isDelivered = isDelivered;
            this.shipper = shipper;
        }

        #region ISpecification<Shipment> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Shipment element)
        {
            if (element.Shipper == shipper && element.IsShipped == isShipped && element.IsDelivered == isDelivered)
            {
                return true;
            }
            return false;
        }


        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from Shipment shipment " +
                    "where shipment.Shipper = :shipper " +
                    "and shipment.IsShipped = :isShipped " +
                    "and shipment.IsDelivered = :isDelivered ";

                return
                    new Query(queryString).AddParameter("shipper", shipper).AddParameter("isShipped", isShipped).
                        AddParameter("isDelivered", isDelivered);
            }
        }

        #endregion
    }
}