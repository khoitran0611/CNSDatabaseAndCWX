using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// Get a user by its username.
    /// </summary>
    public class UserByUserNameSpecification : ISpecification<User>
    {
        private readonly string username;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserIsAuthenticatedSpecification"/> class.
        /// </summary>
        /// <param name="username">The username.</param>
        public UserByUserNameSpecification(string username)
        {
            if (username == null)
            {
                throw new ArgumentNullException("username");
            }

            this.username = username;
        }

        #region ISpecification<User> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(User element)
        {
            return element.Username == username;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from User user " +
                        "where user.Username = :username ";

                return
                    new Query(queryString).AddParameter("username", username);
            }
        }

        #endregion
    }
}