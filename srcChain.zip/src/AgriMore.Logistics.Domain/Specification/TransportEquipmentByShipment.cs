using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// retrieve shipments that belong to a ChainEntity
    /// </summary>
    public class TransportEquipmentByShipment : ISpecification<TransportEquipment>
    {
        private readonly Shipment shipment;

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentsByChainEntity"/> class.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        public TransportEquipmentByShipment(Shipment shipment)
        {
            this.shipment = shipment;
        }

        #region ISpecification<Shipment> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(TransportEquipment element)
        {
            if (element.Contains(shipment))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from TransportEquipment transportEquipment " +
                    "where :shipment in (select elements(transportEquipment.Shipments)) ";

                return new Query(queryString).AddParameter("shipment", shipment);
            }
        }

        #endregion
    }
}