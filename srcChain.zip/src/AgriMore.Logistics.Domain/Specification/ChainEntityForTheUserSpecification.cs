using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// LocationOfPackageSpecification. Find Location by Package
    /// </summary>
    public class ChainEntityForTheUserSpecification : ISpecification<ChainEntity>
    {
        private readonly User user;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChainEntityForTheUserSpecification"/> class.
        /// </summary>
        /// <param name="user">The package.</param>
        public ChainEntityForTheUserSpecification(User user)
        {
            if (user == null)
            {
                throw new ArgumentNullException("user");
            }
            this.user = user;
        }

        #region ISpecification<ChainEntity> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(ChainEntity element)
        {
            if (element.Contains(user))
            {
                return true;
            }
            return false;
        }


        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from ChainEntity chainEntity " +
                    "where exists " +
                    "(from chainEntity.Users user " +
                    "where user = :user) ";

                return
                    new Query(queryString).AddParameter("user", user).SetCacheAble();
            }
        }

        #endregion
    }
}