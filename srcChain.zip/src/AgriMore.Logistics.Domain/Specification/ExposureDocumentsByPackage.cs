using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// </summary>
    public class ExposureDocumentsByPackage : ISpecification<ExposureDocument>
    {
        private readonly Package package;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExposureDocumentsByPackage"/> class.
        /// </summary>
        /// <param name="package">The package.</param>
        public ExposureDocumentsByPackage(Package package)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            this.package = package;
        }

        #region ISpecification<ExposureDocument> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(ExposureDocument element)
        {
            if (element.Package.Equals(package))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from ExposureDocument exposureDocument " +
                    "where exposureDocument.Package = :package ";

                return
                    new Query(queryString).AddParameter("package", package);
            }
        }

        #endregion
    }
}