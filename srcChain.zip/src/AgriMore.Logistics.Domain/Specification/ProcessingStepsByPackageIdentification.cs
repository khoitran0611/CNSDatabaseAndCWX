using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// retrieves all procesing steps that belong to a particular package parent
    /// </summary>
    public class ProcessingStepsByPackageIdentification : ISpecification<ProcessingStep>
    {
        private readonly Package package;
        private readonly bool retrieveOnlyChildren;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessingStepsByPackageIdentification"/> class.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="retrieveOnlyChildren">if set to <c>true</c> [retrieve only children].</param>
        public ProcessingStepsByPackageIdentification(Package package, bool retrieveOnlyChildren)
        {
            this.package = package;
            this.retrieveOnlyChildren = retrieveOnlyChildren;
        }

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(ProcessingStep element)
        {
            if (retrieveOnlyChildren)
            {
                if (element.PackageParentId == package.Uid)
                {
                    return true;
                }
            }
            else
            {
                if (element.PackageId == package.Uid)
                {
                    return true;
                }
            }


            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from ProcessingStep processingStep " +
                    "where (processingStep.PackageUid = :package or :retrieveOnlyChildren = 1) " +
                    "and (processingStep.ParentPackageUid = :package or :retrieveOnlyChildren = 0) ";

                return
                    new Query(queryString).AddParameter("package", package).AddParameter("retrieveOnlyChildren",
                                                                                         retrieveOnlyChildren);
            }
        }
    }
}