using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// retrieve shipments that belong to a ChainEntity
    /// </summary>
    public class ShipmentsByChainEntity : ISpecification<Shipment>
    {
        private readonly ChainEntity chainEntity;

        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentsByChainEntity"/> class.
        /// </summary>
        /// <param name="chainEntity">The chainEntity.</param>
        public ShipmentsByChainEntity(ChainEntity chainEntity)
        {
            this.chainEntity = chainEntity;
        }

        #region ISpecification<Shipment> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Shipment element)
        {
            if (element.Shipper.Equals(chainEntity) || element.Forwarder.Equals(chainEntity) ||
                element.Receiver.Equals(chainEntity))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from Shipment shipment " +
                    "where shipment.Shipper = :chainEntity " +
                    "or shipment.Forwarder = :chainEntity " +
                    "or shipment.Receiver = :chainEntity ";

                return
                    new Query(queryString).AddParameter("chainEntity", chainEntity);
            }
        }

        #endregion
    }
}