using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// Shipments for forwarder specification
    /// </summary>
    public class ShipmentsForForwarderSpecification : ISpecification<Shipment>
    {
        private readonly ChainEntity forwarder;
        private readonly bool isShipped;
        private readonly bool isDelivered;


        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentsForForwarderSpecification"/> class.
        /// </summary>
        /// <param name="forwarder">The forwarder.</param>
        /// <param name="isShipped">if set to <c>true</c> [is shipped].</param>
        /// <param name="isDelivered">if set to <c>true</c> [is delivered].</param>
        public ShipmentsForForwarderSpecification(ChainEntity forwarder, bool isShipped, bool isDelivered)
        {
            this.isShipped = isShipped;
            this.isDelivered = isDelivered;
            this.forwarder = forwarder;
        }

        #region ISpecification<Shipment> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Shipment element)
        {
            if (element.Forwarder == forwarder && element.IsShipped == isShipped && element.IsDelivered == isDelivered)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from Shipment shipment " +
                    "where shipment.Forwarder = :forwarder " +
                    "and shipment.IsShipped = :isShipped " +
                    "and shipment.IsDelivered = :isDelivered ";

                return
                    new Query(queryString).AddParameter("forwarder", forwarder).AddParameter("isShipped", isShipped).
                        AddParameter("isDelivered", isDelivered);
            }
        }

        #endregion
    }
}