using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// </summary>
    public class ExposureDocumentsByLocation : ISpecification<ExposureDocument>
    {
        private readonly Location location;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExposureDocumentsByPackage"/> class.
        /// </summary>
        /// <param name="location">The location.</param>
        public ExposureDocumentsByLocation(Location location)
        {
            if (location == null)
            {
                throw new ArgumentNullException("location");
            }

            this.location = location;
        }

        #region ISpecification<ExposureDocument> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(ExposureDocument element)
        {
            if (element.Location.Equals(location))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from ExposureDocument exposureDocument " +
                    "where exposureDocument.Location = :location ";

                return
                    new Query(queryString).AddParameter("location", location);
            }
        }

        #endregion
    }
}