using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// </summary>
    public class IdentificationByChainEntity : ISpecification<Identification>
    {
        private readonly ChainEntity chainEntity;

        /// <summary>
        /// Initializes a new instance of the <see cref="IdentificationByChainEntity"/> class.
        /// </summary>
        /// <param name="chainEntity">The chainEntity.</param>
        public IdentificationByChainEntity(ChainEntity chainEntity)
        {
            if (chainEntity == null)
            {
                throw new ArgumentNullException("chainEntity");
            }

            this.chainEntity = chainEntity;
        }

        #region ISpecification<Identification> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Identification element)
        {
            if (element.ChainEntity.Equals(chainEntity))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from Identification identification " +
                        "where identification.ChainEntity = :chainEntity ";

                return
                    new Query(queryString).AddParameter("chainEntity", chainEntity);
            }
        }

        #endregion
    }
}