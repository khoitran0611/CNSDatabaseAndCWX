using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// Represents the PackageForPutInLocationSpecification class.
    /// </summary>
    public class PackageForPutInLocationSpecification : ISpecification<Package>
    {
        private readonly ChainEntity shipper;

        /// <summary>
        /// Initializes a new instance of the <see cref="PackageForPutInLocationSpecification"/> class.
        /// </summary>
        /// <param name="shipper">The shipper.</param>
        public PackageForPutInLocationSpecification(ChainEntity shipper)
        {
            this.shipper = shipper;
        }

        #region ISpecification<Shipment> Members

        /// <summary>
        /// Determines whether [is satisfied by] [the specified element].
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if [is satisfied by] [the specified element]; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Package element)
        {
            // See the NHibernate repository. This method will not be called.
            throw new NotImplementedException(
                "This specification is implemented using HQL. This is a combination of the former ShipmentsForShipperSpecification and PackagePutInLocationRequirementSpecification.");
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                //string queryString =
                //    "from Package package " +
                //    //"left outer join fetch package.PrimaryProducts " +
                //    "where not exists " +
                //    "(from Shipment shipment " +
                //    "join shipment.Packages shipmentPackage " +
                //    "where shipment.IsShipped = 1 " +
                //    "and shipment.IsDelivered = 0 " +
                //    "and shipment.Shipper = :shipper " +
                //    "and shipmentPackage = package) " +
                //    "and not exists " +
                //    "(from ChainEntity chainEntity " +
                //    "join chainEntity.Addresses address " +
                //    "join address.Locations location " +
                //    "join location.Packages locationPackage " +
                //    "where locationPackage = package)" +
                //    "and package.UnpackingDateTime = :dateTimeMinValue " +
                //    "and package.ParentPackage is null " +
                //    "and package.PackageType.PackageTypeCategory.Name = 'wholesalePackaging' " +
                //    "and exists " +
                //    "(from Package package2 " +
                //    "join package2.PackageIdentifications packageIdentification " +
                //    "where packageIdentification.ChainEntity = :shipper " +
                //    "and package2 = package " +
                //    ") ";
                //    ;

                string queryString =
                    "from Package package " +
                    "where not exists " +
                    "(from Shipment shipment " +
                    "join shipment.Packages shipmentPackage " +
                    "where shipment.IsShipped = 1 " +
                    "and shipment.IsDelivered = 0 " +
                    "and shipment.Shipper = :shipper " +
                    "and shipmentPackage = package) " +
                    "and not exists " +
                    "(from ChainEntity chainEntity " +
                    "join chainEntity.Addresses address " +
                    "join address.Locations location " +
                    "join location.Packages locationPackage " +
                    "where locationPackage = package "+
                    "and chainEntity = :shipper )" +
                    "and package.UnpackingDateTime = :dateTimeMinValue " +
                    "and package.IsSplitted = 0 " +
                    //"and package.ParentPackage is null " +
                    //"and package.PackageType.PackageTypeCategory.Name = 'wholesalePackaging' " +
                    "and (package.PackageTypeCategoryId = 1 or package.PackageTypeCategoryId = 2 or package.PackageTypeCategoryId = 4) " +
                    "and exists " +
                    "(from Package package2 " +
                    "join package2.PackageIdentifications packageIdentification " +
                    "where packageIdentification.ChainEntity = :shipper " +
                    "and package2 = package " +
                    ") order by package.Uid desc";

                return
                    new Query(queryString).AddParameter("shipper", shipper).AddParameter("dateTimeMinValue", DateTime.MinValue);
            }
        }

        /// <summary>
        /// Gets the shipper.
        /// </summary>
        /// <value>The shipper.</value>
        public ChainEntity Shipper
        {
            get { return shipper; }
        }

        #endregion
    }
}