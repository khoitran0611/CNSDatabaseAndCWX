namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// Represents the QueryParameter class.
    /// </summary>
    public class QueryParameter
    {
        private string name;
        private object value;

        /// <summary>
        /// Initializes a new instance of the <see cref="QueryParameter"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="value">The value.</param>
        public QueryParameter(string name, object value)
        {
            this.name = name;
            this.value = value;
        }


        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return name; }
        }

        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <value>The value.</value>
        public object Value
        {
            get { return value; }
        }
    }
}