using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// Specification criteria for a find by package identification. 
    /// </summary>
    public class PackageIdentificationSpecification : ISpecification<Package>
    {
        private readonly Identification identification;

        /// <summary>
        /// Initializes a new instance of the <see cref="PackageIdentificationSpecification"/> class.
        /// </summary>
        /// <param name="identification">The identification to find.</param>
        public PackageIdentificationSpecification(Identification identification)
        {
            this.identification = identification;
        }

        #region ISpecification<Package> Members

        /// <summary> 
        /// Determines whether this specification is satisfied by the specified element.
        /// In this case, if the element is identified by the identification.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Package element)
        {
            if (element.IsIdentifiedBy(identification))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from Package package " +
                    "where :identification in (select elements(package.PackageIdentifications)) ";

                return
                    new Query(queryString).AddParameter("identification", identification);
            }
        }

        #endregion
    }
}