using System;
using System.Collections.Generic;
using System.Text;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// </summary>
    public class ProcessingStepsByPackageAndIsParent : ISpecification<ProcessingStep>
    {
        private readonly Package package;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessingStepsByPackageAndIsParent"/> class.
        /// </summary>
        /// <param name="package">The package.</param>
        public ProcessingStepsByPackageAndIsParent(Package package)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }
            this.package = package;
        }

        #region ISpecification<ProcessingStep> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(ProcessingStep element)
        {
            if(element.PackageId == package.Uid && element.PackageParentId == -1)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from ProcessingStep processingStep " +
                    "where processingStep.PackageUid = :package and processingStep.ParentPackageUid = -1";

                return
                    new Query(queryString).AddParameter("package", package);
            }

        }

        #endregion
    }
}
