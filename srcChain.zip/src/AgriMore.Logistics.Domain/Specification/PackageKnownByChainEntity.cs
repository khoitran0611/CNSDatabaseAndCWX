using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// retrieve all packages that are known by a chainentity
    /// </summary>
    public class PackageKnownByChainEntity : ISpecification<Package>
    {
        private readonly ChainEntity chainEntity;

        /// <summary>
        /// Initializes a new instance of the <see cref="PackageIdentificationSpecification"/> class.
        /// </summary>
        /// <param name="chainEntity">The chain entity.</param>
        public PackageKnownByChainEntity(ChainEntity chainEntity)
        {
            this.chainEntity = chainEntity;
        }

        #region ISpecification<Package> Members

        /// <summary> 
        /// Determines whether this specification is satisfied by the specified element.
        /// In this case, if the element is identified by the identification.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Package element)
        {
            if (element.IdentificationForChainEntity(chainEntity) != String.Empty)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from Package package " +
                    "where exists " +
                    "(from package.PackageIdentifications packageIdentification " +
                    "where packageIdentification.ChainEntity = :chainEntity ) ";

                return
                    new Query(queryString).AddParameter("chainEntity", chainEntity);
            }
        }

        #endregion
    }
}