using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// Find packages that are contained in a location
    /// </summary>
    public class PackageInLocationAndNotPackedOnce : ISpecification<Package>
    {
        private readonly Location location;


        /// <summary>
        /// Initializes a new instance of the <see cref="PackageInLocationSpecification"/> class.
        /// </summary>
        /// <param name="location">The location.</param>
        public PackageInLocationAndNotPackedOnce(Location location)
        {
            if (location == null)
            {
                throw new ArgumentNullException("location");
            }

            this.location = location;
        }

        #region ISpecification<Package> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Package element)
        {
            if (location.Contains(element))
            {
                List<Package> listForCount = new List<Package>(element.Children);

                if (element.ParentPackage == null && listForCount.Count > 0)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from Package package " +
                    "where exists " +
                    "(from Location location " +
                    "join location.Packages locationPackage " +
                    "where location = :location " +
                    "and locationPackage = package) " +
                    "and exists (select elements(package.PreviousPackages)) " +
                    "and package.ParentPackage is null ";

                return
                    new Query(queryString).AddParameter("location", location);
            }
        }

        #endregion
    }
}