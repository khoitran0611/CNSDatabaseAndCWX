using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// Shipments for receiver specification
    /// </summary>
    public class UpcomingShipmentsForReceiverSpecification : ISpecification<Shipment>
    {
        private readonly ChainEntity receiver;


        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentsForForwarderSpecification"/> class.
        /// </summary>
        /// <param name="receiver">The receiver.</param>
        public UpcomingShipmentsForReceiverSpecification(ChainEntity receiver)
        {
            this.receiver = receiver;
        }

        #region ISpecification<Shipment> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Shipment element)
        {
            if (element.Receiver == receiver && element.IsShipped && !element.IsDelivered)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from Shipment shipment " +
                        "where shipment.Receiver = :receiver " +
                        "and shipment.IsShipped = 1 " +
                        "and shipment.IsDelivered = 0 ";

                return
                    new Query(queryString).AddParameter("receiver", receiver);
            }
        }

        #endregion
    }
}