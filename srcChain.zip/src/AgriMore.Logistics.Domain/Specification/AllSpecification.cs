using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// All match
    /// </summary>
    /// <typeparam name="TElement">The type of the element.</typeparam>
    public class AllSpecification<TElement> : ISpecification<TElement>
    {
        #region ISpecification<TElement> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(TElement element)
        {
            return true;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                return null;
            }
        }

        #endregion
    }
}