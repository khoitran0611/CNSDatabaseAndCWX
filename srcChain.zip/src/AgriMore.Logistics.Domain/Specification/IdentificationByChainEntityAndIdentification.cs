using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// </summary>
    public class IdentificationByChainEntityAndIdentification : ISpecification<Identification>
    {
        private readonly ChainEntity chainEntity;
        private readonly string identification;

        /// <summary>
        /// Initializes a new instance of the <see cref="IdentificationByChainEntityAndIdentification"/> class.
        /// </summary>
        /// <param name="chainEntity">The chainEntity.</param>
        /// <param name="identification">The identification.</param>
        public IdentificationByChainEntityAndIdentification(ChainEntity chainEntity, string identification)
        {
            if (chainEntity == null)
            {
                throw new ArgumentNullException("chainEntity");
            }

            this.chainEntity = chainEntity;
            this.identification = identification;
        }

        #region ISpecification<Identification> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Identification element)
        {
            if (element.ChainEntity.Equals(chainEntity) && element.Id.Equals(identification))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from Identification identification " +
                    "where identification.ChainEntity = :chainEntity " +
                    "and ((identification.Id = :identification and identification.FromUid = 0 and identification.ToUid) " +
                    "or ((identification.Id is null or identification.Id = '') and identification.FromUid <= :identification and :identification <= identification.ToUid))";

                return new Query(queryString)
                    .AddParameter("chainEntity", chainEntity)
                    .AddParameter("identification", identification);
            }
        }

        #endregion
    }
}