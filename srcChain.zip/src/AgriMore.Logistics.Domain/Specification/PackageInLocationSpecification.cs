using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// Find packages that are contained in a location
    /// </summary>
    public class PackageInLocationSpecification : ISpecification<Package>
    {
        private readonly Location location;


        /// <summary>
        /// Initializes a new instance of the <see cref="PackageInLocationSpecification"/> class.
        /// </summary>
        /// <param name="location">The location.</param>
        public PackageInLocationSpecification(Location location)
        {
            if (location == null)
            {
                throw new ArgumentNullException("location");
            }

            this.location = location;
        }

        #region ISpecification<Package> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(Package element)
        {
            if (location.Contains(element))
            {
                if (element.ParentPackage == null)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from Package package " +
                    "where exists " +
                    "(from Location location " +
                    "join location.Packages locationPackage " +
                    "where location = :location " +
                    "and locationPackage = package) and package.IsSplitted = 0 order by package.Uid desc";
                    //"and (package.PackageTypeCategoryId = 1 || package.PackageTypeCategoryId = 2)";

                return
                    new Query(queryString).AddParameter("location", location);
            }
        }

        #endregion
    }
}