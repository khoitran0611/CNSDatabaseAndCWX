using System;
using System.Collections.Generic;
using System.Text;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// </summary>
    public class RepackedRelationshipByPackage : ISpecification<RepackPackageRelationship>
    {
        private readonly Package package;

        /// <summary>
        /// Initializes a new instance of the <see cref="RepackedRelationshipByPackage"/> class.
        /// </summary>
        /// <param name="package">The package.</param>
        public RepackedRelationshipByPackage(Package package)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            this.package = package;
        }

        #region ISpecification<RepackPackageRelationship> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(RepackPackageRelationship element)
        {
            if (element.NewPackageFromRepackId == package.Uid || element.RepackedPackageId == package.Uid)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from RepackPackageRelationship repackPackageRelationship " +
                    "where repackPackageRelationship.NewPackageFromRepackId = :package " +
                    "or repackPackageRelationship.RepackedPackageId = :package ";

                return
                    new Query(queryString).AddParameter("package", package);
            }
        }

        #endregion
    }
}
