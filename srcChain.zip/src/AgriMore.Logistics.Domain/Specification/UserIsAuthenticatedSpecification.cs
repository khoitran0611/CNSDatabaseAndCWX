using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// secification that determines is user is known by its username and password
    /// </summary>
    public class UserIsAuthenticatedSpecification : ISpecification<User>
    {
        private readonly string password;
        private readonly string username;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserIsAuthenticatedSpecification"/> class.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        public UserIsAuthenticatedSpecification(string username, string password)
        {
            if (username == null)
            {
                throw new ArgumentNullException("username");
            }
            if (password == null)
            {
                throw new ArgumentNullException("password");
            }

            this.username = username;
            this.password = password;
        }

        #region ISpecification<User> Members

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(User element)
        {
            if (element.Username.Equals(username) && element.Password.Equals(password))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from User user " +
                    "where user.Username = :username " +
                    "and user.Password = :password ";

                return
                    new Query(queryString).AddParameter("username", username).AddParameter("password", password);
            }
        }

        #endregion
    }
}