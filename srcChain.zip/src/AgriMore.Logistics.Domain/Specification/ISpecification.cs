using AgriMore.Logistics.Domain.Specification;

namespace AgriMore.Logistics.Domain.Repository
{
    /// <summary>
    /// Specification interface. Allows searching for a domain object.
    /// The specification specifies the criteria on which the element will be found
    /// </summary>
    /// <typeparam name="TElement">an element that satisfies the specification</typeparam>
    public interface ISpecification<TElement>
    {
        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        bool IsSatisfiedBy(TElement element);

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        Query Query { get; }
    }
}