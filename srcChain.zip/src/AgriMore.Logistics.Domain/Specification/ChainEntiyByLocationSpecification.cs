using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// </summary>
    public class ChainEntiyByLocationSpecification : ISpecification<ChainEntity>
    {
        private readonly Location location;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChainEntiyByLocationSpecification"/> class.
        /// </summary>
        /// <param name="location">The location.</param>
        public ChainEntiyByLocationSpecification(Location location)
        {
            if (location == null)
            {
                throw new ArgumentNullException("location");
            }

            this.location = location;
        }

        /// <summary>
        /// Determines whether this specification is satisfied by the specified element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>
        /// 	<c>true</c> if this specification is satisfied by the specified element; otherwise, <c>false</c>.
        /// </returns>
        public bool IsSatisfiedBy(ChainEntity element)
        {
            return element.Contains(location);
        }

        /// <summary>
        /// Gets the query.
        /// </summary>
        /// <value>The query.</value>
        public Query Query
        {
            get
            {
                string queryString =
                    "from ChainEntity chainEntity " +
                        "where exists " +
                        "(from chainEntity.Addresses address " +
                        "join address.Locations location " +
                        "where location = :location) ";

                return
                    new Query(queryString).AddParameter("location", location);
            }
        }
    }
}
