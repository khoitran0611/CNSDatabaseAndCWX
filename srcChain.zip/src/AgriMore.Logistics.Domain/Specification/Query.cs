using System.Collections.Generic;

namespace AgriMore.Logistics.Domain.Specification
{
    /// <summary>
    /// Represents the Query class.
    /// </summary>
    public class Query
    {
        private string queryString;
        private bool isCacheAble = false;

        private List<QueryParameter> queryParameters = new List<QueryParameter>();

        /// <summary>
        /// Initializes a new instance of the <see cref="Query"/> class.
        /// </summary>
        /// <param name="queryString">The query string.</param>
        public Query(string queryString)
        {
            this.queryString = queryString;
        }

        /// <summary>
        /// Sets this query cache able if caching is enabled.
        /// </summary>
        /// <returns></returns>
        public Query SetCacheAble()
        {
            isCacheAble = true;
            return this;
        }

        /// <summary>
        /// Adds the parameter.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public Query AddParameter(string name, object value)
        {
            queryParameters.Add(new QueryParameter(name, value));
            return this;
        }

        /// <summary>
        /// Gets a value indicating whether this instance is cache able.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is cache able; otherwise, <c>false</c>.
        /// </value>
        public bool IsCacheAble
        {
            get { return isCacheAble; }
        }

        /// <summary>
        /// Gets the query string.
        /// </summary>
        /// <value>The query string.</value>
        public string QueryString
        {
            get { return queryString; }
        }

        /// <summary>
        /// Gets the query parameters.
        /// </summary>
        /// <value>The query parameters.</value>
        public ICollection<QueryParameter> QueryParameters
        {
            get { return queryParameters; }
        }
    }
}