using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{


    //}
    /// <summary>
    /// 
    /// </summary>
    public enum ProcessingStepType
    {
        /// <summary>
        /// 
        /// </summary>
        Treatment = 1,

        ///// <summary>
        ///// 
        ///// </summary>
        //Prescribed = 2,

        /// <summary>
        /// 
        /// </summary>
        Documented = 2,

        /// <summary>
        /// 
        /// </summary>
        CheckOut = 3,

        /// <summary>
        /// 
        /// </summary>
        Exposures = 4,

        /// <summary>
        /// 
        /// </summary>
        Move = 5,

        /// <summary>
        /// 
        /// </summary>
        PickUp = 6,
        /// <summary>
        /// 
        /// </summary>
        RemovedFromLocation = 7
    }


    /// <summary>
    /// represent one of the steps that a packages has gone through
    /// </summary>
    public class ProcessingStep : IIdentifyable
    {
        //database properties
        private string remarks;
        private readonly long packageUid;
        private readonly long parentPackageUid;
        private readonly ProcessingStepType processingStepType;    
        private readonly long objectUid;
        private readonly long packageTypeId;
        private readonly DateTime dateOfEntry;
        private readonly long userId;
        private long uid;
  
        //not in database!!
        private IList<ProcessingStep> documentedSteps = new List<ProcessingStep>();

        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessingStep"/> class.
        /// </summary>
        protected ProcessingStep()
        {

        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessingStep"/> class.
        /// </summary>
        /// <param name="remarks">The remarks.</param>
        /// <param name="packageUid">The package uid.</param>
        /// <param name="parentPackageUid">The parent package uid.</param>
        /// <param name="processingStepType">Type of the processing step.</param>
        /// <param name="objectUid">The object uid.</param>
        /// <param name="packageTypeId">The package type id.</param>
        /// <param name="dateOfEntry">The date of entry.</param>
        /// <param name="userId">The user id.</param>
        public ProcessingStep(string remarks, long packageUid, long parentPackageUid, ProcessingStepType processingStepType, long objectUid, long packageTypeId, DateTime dateOfEntry, long userId)
        {
            this.remarks = remarks;
            this.packageUid = packageUid;
            this.parentPackageUid = parentPackageUid;
            this.processingStepType = processingStepType;
            this.packageTypeId = packageTypeId;
            this.dateOfEntry = dateOfEntry;
            this.userId = userId;
            this.objectUid = objectUid;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }


        /// <summary>
        /// Gets the package type id.
        /// </summary>
        /// <value>The package type id.</value>
        public long PackageTypeId
        {
            get { return packageTypeId; }
        }

        /// <summary>
        /// Gets or sets the group id.
        /// </summary>
        /// <value>The group id.</value>
        public string Remarks
        {
            get { return remarks; }
        }

        /// <summary>
        /// Gets the package UID.
        /// </summary>
        /// <value>The package UID.</value>
        public long PackageId
        {
            get { return packageUid; }
        }

        /// <summary>
        /// Gets the type of the processing step.
        /// </summary>
        /// <value>The type of the processing step.</value>
        public ProcessingStepType ProcessingStepType
        {
            get { return processingStepType; }
        }

        /// <summary>
        /// Gets the package parent UID.
        /// </summary>
        /// <value>The package parent UID.</value>
        public long PackageParentId
        {
            get { return parentPackageUid; }
        }


        /// <summary>
        /// Gets the date of entry.
        /// </summary>
        /// <value>The date of entry.</value>
        public DateTime DateOfEntry
        {
            get { return dateOfEntry; }
        }

        /// <summary>
        /// Gets the user id.
        /// </summary>
        /// <value>The user id.</value>
        public long UserId
        {
            get { return userId; }
        }

        /// <summary>
        /// Gets the object uid.
        /// </summary>
        /// <value>The object uid.</value>
        public long ObjectUid
        {
            get { return objectUid; }
        }

        /// <summary>
        /// Adds the remark.
        /// </summary>
        /// <param name="newRemarks">The new remarks.</param>
        public void AddRemark(string newRemarks)
        {
            if (remarks == null)
            {
                remarks = String.Empty;
            }

            remarks = String.Format("{0}{1}{2}", newRemarks , Environment.NewLine, Remarks);
        }
    }
}
