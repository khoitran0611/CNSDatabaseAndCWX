using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// This class represents the treating in which a primary product or another package is treated.
    /// The quality factor is delegated to the treatment type and returned without any modifications.
    /// </summary>
    public class TreatmentType : IIdentifyable
    {
        private readonly string name;
        private long uid;
        private readonly TreatmentTypeCategory treatmentTypeCategory;
        private readonly UnitOfMeasurement unitOfMeasurement;


        /// <summary>
        /// Initializes a new instance of the <see cref="TreatmentType"/> class.
        /// </summary>
        protected TreatmentType()
        {
        }

        /// <summary>
        /// Gets the package type category.
        /// </summary>
        /// <value>The package type category.</value>
        public TreatmentTypeCategory TreatmentTypeCategory
        {
            get { return treatmentTypeCategory; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TreatmentType"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="treatmentTypeCategory">The treatment type category.</param>
        /// <param name="unitOfMeasurement">The unit of measurement.</param>
        public TreatmentType(string name, TreatmentTypeCategory treatmentTypeCategory, UnitOfMeasurement unitOfMeasurement)
        {
            if(name==null)
            {
                throw new ArgumentNullException("name");
            }

            if(name.Trim().Length==0)
            {
                throw new ArgumentException("Name cannot be empty.");
            }

            if (treatmentTypeCategory == null)
            {
                throw new ArgumentNullException("treatmentTypeCategory");
            }

            if (unitOfMeasurement == null)
            {
                throw new ArgumentNullException("unitOfMeasurement");
            }

            this.name = name;
            this.treatmentTypeCategory = treatmentTypeCategory;
            this.unitOfMeasurement = unitOfMeasurement;

            treatmentTypeCategory.AddTreatmentType(this);
        }

        /// <summary>
        /// Gets the name of the packingmaterial.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return name; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets the unit of measurement.
        /// </summary>
        /// <value>The unit of measurement.</value>
        public UnitOfMeasurement UnitOfMeasurement
        {
            get { return unitOfMeasurement; }
        }

        #endregion
        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            TreatmentType theOther = obj as TreatmentType;
            if (theOther == null)
            {
                return false;
            }
            if (theOther.name == name)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            int result = name != null ? name.GetHashCode() : 0;
            result = 29 * result + (int)uid;
            result = 29 * result + (treatmentTypeCategory != null ? treatmentTypeCategory.GetHashCode() : 0);
            result = 29 * result + (unitOfMeasurement != null ? unitOfMeasurement.GetHashCode() : 0);
            return result;
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return uid.ToString();
        }
    }
}