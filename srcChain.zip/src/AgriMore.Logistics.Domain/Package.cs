using System;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;
using log4net;
using AgriMore.Logistics.Domain.ThirdPartyEntities;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Packages are the items which are moved and traced in the system. Everything is about the package because it ulimatly
    /// contains the primary product. Packages are of a certain type (flowpack, cardboard box). Packages can be packed in other packages
    /// and can be unpacked. They can contain multiple primary products. Think of a a reg,green and yellow paprika. packages
    /// can also have multiple identifications because anyone handling a package at a certain moment has it's own identification.
    /// packages have the responsibility to pack and to unpack. Everything that can be done to a package has to be recorded.
    /// 
    /// 
    /// </summary>
    public class Package : IIdentifyable
    {
        private const string location = "location";
        private readonly ISet exposureDocuments = new HashedSet();
        private readonly ILog log = LogManager.GetLogger(typeof(Package));
        private readonly ISet packageIdentifications = new HashedSet();

        //private readonly PackageType packageType;
        private long packageTypeId;
        private long packageTypeCategoryId;
        private string packageTypeName;
        private readonly DateTime packingDateTime;
        private readonly ISet previousPackages = new HashedSet();
        public  ISet primaryProducts = new HashedSet();
        private readonly ISet treatments = new HashedSet();
        private Package parentPackage;
        private string productCode;
        private long uid;
        private DateTime unpackingDateTime = DateTime.MinValue;
        private DateTime shelfLifeStartDateTime = DateTime.MinValue;

        private DateTime shelfLifeEndDateTime = DateTime.MinValue;

        private DateTime bestBeforeEndDateTime = DateTime.MinValue;

        private int typeOfWaste;


        /// <summary>
        /// Gets or sets from uid.
        /// </summary>
        /// <value>From uid.</value>
        public long FromUid { get; set; }

        /// <summary>
        /// Gets or sets to uid.
        /// </summary>
        /// <value>To uid.</value>
        public long ToUid { get; set; }


        /// <summary>
        /// 
        /// </summary>
        public bool HasChild { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool IsSplitted { get; set; }


        /// <summary>
        /// 
        /// </summary>
        public DateTime ShelfLifeStartDateTime
        {
            get { return shelfLifeStartDateTime; }
            set { shelfLifeStartDateTime = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public DateTime ShelfLifeEndDateTime
        {
            get { return shelfLifeEndDateTime; }
            set { shelfLifeEndDateTime = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public DateTime BestBeforeEndDateTime
        {
            get { return bestBeforeEndDateTime; }
            set { bestBeforeEndDateTime = value; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Package"/> class.
        /// </summary>
        public Package()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="packageTypeId"></param>
        /// <param name="primaryProducts"></param>
        /// <param name="packingDateTime"></param>
        /// <param name="packIds"></param>
        /// <param name="packageTypeCategoryId"></param>
        /// <param name="packageTypeName"></param>
        public Package(long packageTypeId, IEnumerable<PrimaryProduct> primaryProducts,
                       DateTime packingDateTime, IEnumerable<Identification> packIds, long packageTypeCategoryId, string packageTypeName)
        {
            if (primaryProducts == null)
            {
                log.Debug("primaryProducts cannot be null.");
                throw new ArgumentNullException("primaryProducts");
            }
            //if (packageType == null)
            //{
            //    log.Debug("packageType cannot be null.");
            //    throw new ArgumentNullException("packageType");
            //}

            if (packIds == null)
            {
                log.Debug("packIds cannot be null.");
                throw new ArgumentNullException("packIds");
            }

            List<Identification> listForCount = new List<Identification>(packIds);
            if (listForCount.Count == 0)
            {
                log.Debug("Number of identification is 0.");
                throw new ArgumentException("Number of identification is 0.");
            }

            foreach (Identification identification in packIds)
            {
                if (identification == null)
                {
                    log.Debug("One of the packids is null.");
                    throw new ArgumentException("One of the packids is null.");
                }
                identification.Package = this;
            }

            if (packingDateTime > DateTime.Now)
            {
                throw new ArgumentException("Packing date time cannot be in the future.", "packingDateTime");
            }

            this.primaryProducts.AddAll(new List<PrimaryProduct>(primaryProducts));
            this.packingDateTime = packingDateTime;
            //this.packageType = packageType;
            this.packageTypeId = packageTypeId;
            this.packageTypeCategoryId = packageTypeCategoryId;
            this.packageTypeName = packageTypeName;
            packageIdentifications.AddAll(new List<Identification>(packIds));
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="packageTypeId"></param>
        /// <param name="primaryProducts"></param>
        /// <param name="packingDateTime"></param>
        /// <param name="packIds"></param>
        /// <param name="productCode"></param>
        /// <param name="packageTypeCategoryId"></param>
        /// <param name="packageTypeName"></param>
        public Package(long packageTypeId, IEnumerable<PrimaryProduct> primaryProducts,
                       DateTime packingDateTime, IEnumerable<Identification> packIds, string productCode, long packageTypeCategoryId, string packageTypeName)
            : this(packageTypeId, primaryProducts, packingDateTime, packIds, packageTypeCategoryId, packageTypeName)
        {
            this.productCode = productCode;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="packageTypeId"></param>
        /// <param name="primaryProducts"></param>
        /// <param name="packingDateTime"></param>
        /// <param name="packIds"></param>
        /// <param name="productCode"></param>
        /// <param name="fromUid"></param>
        /// <param name="toUid"></param>
        /// <param name="packageTypeCategoryId"></param>
        /// <param name="packageTypeName"></param>
        public Package(long packageTypeId, IEnumerable<PrimaryProduct> primaryProducts,
                       DateTime packingDateTime, IEnumerable<Identification> packIds, string productCode, long fromUid, long toUid, long packageTypeCategoryId, string packageTypeName)
            : this(packageTypeId, primaryProducts, packingDateTime, packIds, productCode, packageTypeCategoryId, packageTypeName)
        {
            this.FromUid = fromUid;
            this.ToUid = toUid;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="packageTypeId"></param>
        /// <param name="primaryProducts"></param>
        /// <param name="packingDateTime"></param>
        /// <param name="packIds"></param>
        /// <param name="productCode"></param>
        /// <param name="fromUid"></param>
        /// <param name="toUid"></param>
        /// <param name="packageTypeCategoryId"></param>
        /// <param name="packageTypeName"></param>
        /// <param name="shelfLifeStartDateTime"></param>
        /// <param name="shelfLifeEndDateTime"></param>
        /// <param name="bestBeforeEndDateTime"></param>
        public Package(long packageTypeId, IEnumerable<PrimaryProduct> primaryProducts,
                       DateTime packingDateTime, IEnumerable<Identification> packIds, string productCode, long fromUid, long toUid, long packageTypeCategoryId, string packageTypeName,
            DateTime shelfLifeStartDateTime, DateTime shelfLifeEndDateTime, DateTime bestBeforeEndDateTime)
            : this(packageTypeId, primaryProducts, packingDateTime, packIds, productCode, packageTypeCategoryId, packageTypeName)
        {
            this.FromUid = fromUid;
            this.ToUid = toUid;
            this.shelfLifeStartDateTime = shelfLifeStartDateTime;
            this.shelfLifeEndDateTime = shelfLifeEndDateTime;
            this.bestBeforeEndDateTime = bestBeforeEndDateTime;
        }

        /// <summary>
        /// Gets the product code.
        /// </summary>
        /// <value>The product code.</value>
        public string ProductCode
        {
            get { return productCode; }
        }

        /// <summary>
        /// Gets the primary products.
        /// </summary>
        /// <value>The primary products.</value>
        public List<PrimaryProduct> PrimaryProducts
        {
            get { return ListHandler.ConvertToGenericList<PrimaryProduct>(primaryProducts); }            
        }

        /// <summary>
        /// Gets the treatments.
        /// </summary>
        /// <value>The treatments.</value>
        public List<Treatment> Treatments
        {
            get { return ListHandler.ConvertToGenericList<Treatment>(treatments); }
        }

        /// <summary>
        /// Gets the exposure documents.
        /// </summary>
        /// <value>The exposure documents.</value>
        public IEnumerable<ExposureDocument> ExposureDocuments
        {
            get
            {
                List<ExposureDocument> allDocuments = new List<ExposureDocument>();

                foreach (ExposureDocument exposureDocument in exposureDocuments)
                {
                    allDocuments.Add(exposureDocument);
                }

                allDocuments.Sort(delegate(ExposureDocument p1, ExposureDocument p2) { return p2.Start.CompareTo(p1.Start); });

                return allDocuments;
            }
        }

        /// <summary>
        /// Gets the current exposure document.
        /// </summary>
        /// <value>The current exposure document.</value>
        public ExposureDocument CurrentExposureDocument
        {
            get
            {
                foreach (ExposureDocument exposureDocument in exposureDocuments)
                {
                    if (exposureDocument.IsActive)
                    {
                        return exposureDocument;
                    }
                }

                return null;
            }
        }

        /// <summary>
        /// Gets the type of the package.
        /// </summary>
        /// <value>The type of the package.</value>
        public PackageType PackageType
        {
            //get { return packageType; }
            get { return null; } //Refactor later
        }


        /// <summary>
        /// Gets the packing date time.
        /// </summary>
        /// <value>The packing date time.</value>
        public DateTime PackingDateTime
        {
            get { return packingDateTime; }
        }

        /// <summary>
        /// Gets the previousPackages.
        /// </summary>
        /// <value>The previousPackages.</value>
        public IEnumerable<Package> Children
        {
            get
            {
                foreach (Package package in previousPackages)
                {
                    yield return package;
                }
            }
        }

        /// <summary>
        /// Gets the parent package.
        /// </summary>
        /// <value>The parent package.</value>
        public Package ParentPackage
        {
            get { return parentPackage; }
            set { parentPackage = value; }
        }

        /// <summary>
        /// Gets the identifications.
        /// </summary>
        /// <value>The identifications.</value>
        public IEnumerable<Identification> Identifications
        {
            get
            {
                foreach (Identification identification in packageIdentifications)
                {
                    yield return identification;
                }
            }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set
            {
                uid = value;
            }
        }

        #endregion

        /// <summary>
        /// Adds the treatments.
        /// </summary>
        /// <param name="treatments">The treatments.</param>
        public void AddTreatments(IEnumerable<Treatment> treatments)
        {
            foreach (Treatment treatment in treatments)
            {
                this.treatments.Add(treatment);
            }
        }

        /// <summary>
        /// Adds the treatments.
        /// </summary>
        /// <param name="treatment">The treatment.</param>
        public void AddTreatment(Treatment treatment)
        {
            treatments.Add(treatment);
        }

        /// <summary>
        /// Creates the exposure document.
        /// </summary>
        /// <param name="exposureDocument">The exposure document.</param>
        public void AddExposureDocument(ExposureDocument exposureDocument)
        {
            exposureDocuments.Add(exposureDocument);
        }

        /// <summary>
        /// Retrieves the exposure document.
        /// </summary>
        /// <param name="location">The location.</param>
        /// <returns></returns>
        public ExposureDocument RetrieveExposureDocument(Location location)
        {
            if (location == null)
            {
                throw new ArgumentNullException(Package.location);
            }

            foreach (ExposureDocument exposureDocument in exposureDocuments)
            {
                if (exposureDocument.Contains(location) && exposureDocument.IsActive)
                {
                    return exposureDocument;
                }
            }

            return null;
        }


        /// <summary>
        /// Adds this package to an existing package.
        /// </summary>
        /// <param name="existingPackage">The existing package.</param>
        public Package Pack(Package existingPackage)
        {
            if (existingPackage == null)
            {
                log.Debug("existingPackage cannot be null.");
                throw new ArgumentNullException("existingPackage");
            }

            previousPackages.Add(existingPackage);
            existingPackage.parentPackage = this;

            return existingPackage;
        }

        /// <summary>
        /// Determines whether the specified package is a child package.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <returns>
        /// 	<c>true</c> if [contains] [the specified package]; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(Package package)
        {
            if (package == null)
            {
                return false;
            }

            return previousPackages.Contains(package);
        }


        /// <summary>
        /// Delegates the packing of this package into a new form with id and return is to the caller.
        /// </summary>
        /// <param name="wrappingPackageType">Type of the package.</param>
        /// <param name="wrapPackingDateTime">The packing date time.</param>
        /// <param name="packIds">The pack ids.</param>
        /// <returns></returns>
        public Package Pack(PackagingDefine wrappingPackageType, DateTime wrapPackingDateTime,
                            IEnumerable<Identification> packIds)
        {
            if (DateTime.Compare(wrapPackingDateTime, packingDateTime) < 0)
            {
                log.Debug("The packing cannot be before the packing date of the previousPackages.");
                throw new ArgumentException("The packing cannot be before the packing date of the previousPackages.");
            }

            Package newPackage =
                //Refactor later
                //new Package(wrappingPackageType, ListHandler.ConvertToGenericList<PrimaryProduct>(primaryProducts),
                //            wrapPackingDateTime, packIds);
                new Package(wrappingPackageType.Uid, ListHandler.ConvertToGenericList<PrimaryProduct>(primaryProducts),
                            wrapPackingDateTime, packIds, wrappingPackageType.PackTypeCategory.Uid, wrappingPackageType.Name);

            parentPackage = newPackage;
            newPackage.previousPackages.Add(this);
            return newPackage;
        }

        /// <summary>
        /// Packs the specified wrapping package type.
        /// </summary>
        /// <param name="wrappingPackageType">Type of the wrapping package.</param>
        /// <param name="wrapPackingDateTime">The wrap packing date time.</param>
        /// <param name="packIds">The pack ids.</param>
        /// <param name="productCode">The productCode code.</param>
        /// <returns></returns>
        public Package Pack(PackagingDefine wrappingPackageType, DateTime wrapPackingDateTime,
                            IEnumerable<Identification> packIds, string productCode, DateTime expiredStartDate, 
                            DateTime expiredEndDate, DateTime bestBeforeEndDate)            
        {
            Package newPackage = Pack(wrappingPackageType, wrapPackingDateTime, packIds);
            newPackage.productCode = productCode;
            newPackage.shelfLifeStartDateTime = expiredStartDate;
            newPackage.shelfLifeEndDateTime = expiredEndDate;
            newPackage.bestBeforeEndDateTime = bestBeforeEndDate;

            return newPackage;
        }

        /// <summary>
        /// Add a new identification to the package.
        /// </summary>
        /// <param name="identification">The identification.</param>
        public void AddIdentification(Identification identification)
        {
            if (identification == null)
            {
                log.Debug("packId cannot be null.");
                throw new ArgumentNullException("identification");
            }

            if (IsIdentifiedBy(identification))
            {
                log.Debug("The identification is already present.");
                throw new ArgumentException("The identification is already present.");
            }

            packageIdentifications.Add(identification);
            identification.Package = this;
        }

        /// <summary>
        /// _s the is identified by.
        /// </summary>
        /// <param name="identification">The identification.</param>
        /// <returns></returns>
        public bool IsIdentifiedBy(Identification identification)
        {
            bool result = false;
            // Check all id's
            foreach (Identification packageIdentification in packageIdentifications)
            {
                if (packageIdentification.Id == identification.Id && packageIdentification.ChainEntity.Uid == identification.ChainEntity.Uid)
                {
                    result = true;
                    break;
                }
            }
            return result;
        }

        /// <summary>
        /// Determines whether [is identified by] [the specified pack id].
        /// </summary>
        /// <param name="primaryProduct">The primary product.</param>
        /// <returns>
        /// 	<c>true</c> if [is identified by] [the specified pack id]; otherwise, <c>false</c>.
        /// </returns>
        public bool ContainsPrimaryProduct(PrimaryProduct primaryProduct)
        {
            if (primaryProduct == null)
            {
                return false;
            }
            return primaryProducts.Contains(primaryProduct);
        }

        /// <summary>
        /// Unpacks the this package and returns the previousPackages form of packing.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Package> Unpack(DateTime unpackingDateTime)
        {
            if (previousPackages.Count == 0)
            {
                log.Debug("No removal of the first pack is allowed. Try repacking.");
                throw new InvalidOperationException("No removal of the first pack is allowed. Try repacking.");
            }

            this.unpackingDateTime = unpackingDateTime;

            foreach (Package package in previousPackages)
            {
                package.parentPackage = null;
            }

            foreach (Package package in previousPackages)
            {
                yield return package;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void Repack(DateTime repackDateTime)
        {
            unpackingDateTime = repackDateTime;
        }


        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// If all id's are the same consider it the same package.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            Package other = obj as Package;
            if (other == null)
            {
                return false;
            }

            if (Uid != 0)
            {
                return (Uid == other.Uid);
            }

            if (packageIdentifications.Count != other.packageIdentifications.Count)
            {
                return false;
            }

            int count = 0;
            foreach (Identification identification in packageIdentifications)
            {
                foreach (Identification packageIdentification in other.packageIdentifications)
                {
                    if (identification.Equals(packageIdentification))
                    {
                        count++;
                        break;
                    }
                }
            }
            if (count == packageIdentifications.Count)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            string toString = string.Empty;

            foreach (Identification identification in packageIdentifications)
            {
                toString = toString + identification.ToString();
            }
            return toString;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            if (uid == 0)
            {
                int hash = 0;

                foreach (Identification identification in packageIdentifications)
                {
                    //Refactor later
                    //hash = identification.GetHashCode() + packageType.GetHashCode();
                    hash = identification.GetHashCode() + packageTypeId.GetHashCode();
                }


                return hash;
            }
            else
            {
                if (uid > int.MaxValue)
                {
                    return uid.GetHashCode();
                }
                else
                {
                    return (int)uid;
                }
            }
        }

        /// <summary>
        /// Gets the identification for a specific ChainEntity
        /// </summary>
        /// <param name="chainEntity">The chain entity.</param>
        /// <returns></returns>
        public Identification GetIdentification(ChainEntity chainEntity)
        {
            if (chainEntity == null)
            {
                throw new ArgumentNullException("chainEntity", "chainEntity cannot be null");
            }

            foreach (Identification indentification in packageIdentifications)
            {
                if (chainEntity.Uid == indentification.ChainEntity.Uid)
                    return indentification;
            }

            return null;
        }

        /// <summary>
        /// Gets the specific identification of a package for a chain entity.
        /// If not present it returns an empty string
        /// </summary>
        /// <param name="chainEntity">The chain entity.</param>
        /// <returns></returns>
        public string IdentificationForChainEntity(ChainEntity chainEntity)
        {
            if (chainEntity == null)
            {
                throw new ArgumentNullException("chainEntity", "chainEntity cannot be null");
            }

            foreach (Identification indentification in packageIdentifications)
            {
                if (chainEntity.Uid == indentification.ChainEntity.Uid)
                {
                    return string.Format("{0}{1} - {0}{2}", indentification.Id,
                    indentification.FromUid > 0 ? indentification.FromUid.ToString() : string.Empty,
                    indentification.ToUid > 0 ? indentification.ToUid.ToString() : string.Empty);
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// Clears the parrent.
        /// </summary>
        public void ClearParent()
        {
            parentPackage = null;
        }


        /// <summary>
        /// Gets all children from al children packages (recursive)
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Package> GetAllChildren()
        {
            List<Package> allChildren = new List<Package>();

            if (Children != null)
            {
                foreach (Package child in Children)
                {
                    allChildren.Add(child);
                    allChildren.AddRange(child.GetAllChildren());
                }
            }

            return allChildren;
        }

        /// <summary>
        /// Gets a value indicating whether this instance is in location.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is in location; otherwise, <c>false</c>.
        /// </value>
        public bool IsInLocation
        {
            get
            {
                return (CurrentExposureDocument != null);
            }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is checked out.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is checked out; otherwise, <c>false</c>.
        /// </value>
        public bool IsCheckedOut
        {
            get
            {
                if (exposureDocuments.Count > 0 && !IsInLocation)
                {
                    return true;
                }

                return false;
            }
        }

        /// <summary>
        /// Determines whether this instance is unpacked.
        /// </summary>
        /// <returns>
        /// 	<c>true</c> if this instance is unpacked; otherwise, <c>false</c>.
        /// </returns>
        public bool IsUnpacked
        {
            get
            {
                return unpackingDateTime != DateTime.MinValue;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public long PackageTypeId
        {
            get { return packageTypeId; }
            set { packageTypeId = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public long PackageTypeCategoryId
        {
            get { return packageTypeCategoryId; }
            set { packageTypeCategoryId = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string PackageTypeName
        {
            get { return packageTypeName; }
            set { packageTypeName = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int TypeOfWaste
        {
            get { return typeOfWaste; }
            set { typeOfWaste = value; }
        }
    }
}