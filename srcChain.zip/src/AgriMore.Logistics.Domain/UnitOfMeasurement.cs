namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Unit of measurement
    /// </summary>
    public class UnitOfMeasurement : AbstractKeyNameType
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UnitOfMeasurement"/> class.
        /// </summary>
        protected UnitOfMeasurement()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="UnitOfMeasurement"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public UnitOfMeasurement(string name)
            : base(name)
        {
        }
    }
}