using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// </summary>
    public class ProcessingStepDocument
    {
        private readonly Package package;
        private readonly ExposureDocument exposureDocument;
        private readonly ProcessingStepType processingStepType;
        private List<ProcessingStep> allSteps = new List<ProcessingStep>();
        private DateTime dateOfEntry = DateTime.Now;
        private long userId;
        private IEnumerable<Treatment> treatments;
        private string remarks;

        /// <summary>
        /// 
        /// </summary>
        public static string PutInLocation = "[{0}] Placed in storage";

        /// <summary>
        /// The decompose product
        /// </summary>
        public static string DecomposeProduct = "[{0}] Decompose product";
        /// <summary>
        ///        
        /// </summary>
        public static string Documented = "[{0}] Added documented exposure(s)";

        /// <summary>
        /// 
        /// </summary>
        public static string ExpiredProduct = "[{0}] Pack Expired product";
        /// <summary>
        /// 
        /// </summary>
        public static string PickUp = "[{0}] Placed in storage after pickup from \"{1}\"";

        /// <summary>
        /// 
        /// </summary>
        public static string RepackSfp = "Repacked Sfp";

        /// <summary>
        /// 
        /// </summary>
        public static string MovedSfp = "[{0}] Moved from \"{1}\" to \"{2}\"";
        /// <summary>
        /// 
        /// </summary>
        public static string PackSfp = "[{0}] Packed Sfp with new identification \"{1}\" as a \"{2}\"";

        /// <summary>
        /// 
        /// </summary>
        public static string UnpackSfp = "[{0}] Unpacked Sfp";

        /// <summary>
        /// 
        /// </summary>
        //public static string DateTimeFormat = "yyyy-MM-dd HH:mm:ss";
        public static string DateTimeFormat = "dd-MM-yyyy HH:mm:ss";

        /// <summary>
        /// 
        /// </summary>
        public static string CheckoutSfp = "[{0}] Removed from shelf using Cash Register \"{1}\" with remarks: {2}";


        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessingStepDocument"/> class.
        /// </summary>
        /// <param name="remarks">The remarks.</param>
        /// <param name="package">The package.</param>
        /// <param name="treatments">The treatments.</param>
        /// <param name="processingStepType">Type of the processing step.</param>
        /// <param name="user">The user.</param>
        public ProcessingStepDocument(Package package, IEnumerable<Treatment> treatments, ProcessingStepType processingStepType, User user, string remarks)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            if (user == null)
            {
                throw new ArgumentNullException("user");
            }

            this.package = package;
            this.treatments = treatments;
            this.processingStepType = processingStepType;
            this.userId = user.Uid;
            this.remarks = remarks;
            this.dateOfEntry = DateTime.Now;

            CreateProcessingSteps();
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessingStepDocument"/> class.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="exposureDocument">The exposure document.</param>
        /// <param name="processingStepType">Type of the processing step.</param>
        /// <param name="user">The user.</param>
        /// <param name="remarks">The remarks.</param>
        public ProcessingStepDocument(Package package, ExposureDocument exposureDocument, ProcessingStepType processingStepType, User user, string remarks)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            if (exposureDocument == null)
            {
                throw new ArgumentNullException("exposureDocument");
            }

            if (user == null)
            {
                throw new ArgumentNullException("user");
            }

            this.package = package;
            this.exposureDocument = exposureDocument;
            this.processingStepType = processingStepType;
            this.userId = user.Uid;
            this.remarks = remarks;
            this.dateOfEntry = DateTime.Now;

            CreateProcessingSteps();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessingStepDocument"/> class.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="parentPackId">The parent pack identifier.</param>
        /// <param name="exposureDocument">The exposure document.</param>
        /// <param name="processingStepType">Type of the processing step.</param>
        /// <param name="user">The user.</param>
        /// <param name="remarks">The remarks.</param>
        /// <exception cref="System.ArgumentNullException">
        /// package
        /// or
        /// exposureDocument
        /// or
        /// user
        /// </exception>
        public ProcessingStepDocument(Package package, long parentPackId, ExposureDocument exposureDocument, ProcessingStepType processingStepType, User user, string remarks)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            if (exposureDocument == null)
            {
                throw new ArgumentNullException("exposureDocument");
            }

            if (user == null)
            {
                throw new ArgumentNullException("user");
            }

            this.package = package;
            this.exposureDocument = exposureDocument;
            this.processingStepType = processingStepType;
            this.userId = user.Uid;
            this.remarks = remarks;
            this.dateOfEntry = DateTime.Now;

            CreateProcessingSteps(parentPackId);
        }

        /// <summary>
        /// Gets the steps.
        /// </summary>
        /// <value>The steps.</value>
        public IEnumerable<ProcessingStep> Steps
        {
            get { return allSteps; }
        }

        /// <summary>
        /// Creates the processing steps.
        /// </summary>
        private void CreateProcessingSteps()
        {
            List<ProcessingStep> allChildSteps = new List<ProcessingStep>();
            IEnumerable<ProcessingStep> parentSteps = CreateProcessingStepsFormMainPackage2(package);

            foreach (ProcessingStep parentStep in parentSteps)
            {
                foreach (Package child in package.GetAllChildren())
                {
                    //Refactor
                    //ProcessingStep ps = new ProcessingStep(parentStep.Remarks, child.Uid, parentStep.PackageId
                    //                                       , parentStep.ProcessingStepType, parentStep.ObjectUid,
                    //                                       child.PackageType.Uid, parentStep.DateOfEntry, parentStep.UserId);
                    ProcessingStep ps = new ProcessingStep(parentStep.Remarks, child.Uid, parentStep.PackageId
                                                           , parentStep.ProcessingStepType, parentStep.ObjectUid,
                                                           child.PackageTypeId, parentStep.DateOfEntry, parentStep.UserId);
                    allChildSteps.Add(ps);
                }
            }

            allChildSteps.AddRange(parentSteps);

            this.allSteps = allChildSteps;
        }

        /// <summary>
        /// Creates the processing steps.
        /// </summary>
        /// <param name="parentPackId">The parent pack identifier.</param>
        private void CreateProcessingSteps(long parentPackId)
        {
            List<ProcessingStep> allChildSteps = new List<ProcessingStep>();
            IEnumerable<ProcessingStep> parentSteps = CreateProcessingStepsFormMainPackage2(package, parentPackId);

            foreach (ProcessingStep parentStep in parentSteps)
            {
                foreach (Package child in package.GetAllChildren())
                {
                    //Refactor
                    //ProcessingStep ps = new ProcessingStep(parentStep.Remarks, child.Uid, parentStep.PackageId
                    //                                       , parentStep.ProcessingStepType, parentStep.ObjectUid,
                    //                                       child.PackageType.Uid, parentStep.DateOfEntry, parentStep.UserId);
                    ProcessingStep ps = new ProcessingStep(parentStep.Remarks, child.Uid, parentStep.PackageId
                                                           , parentStep.ProcessingStepType, parentStep.ObjectUid,
                                                           child.PackageTypeId, parentStep.DateOfEntry, parentStep.UserId);
                    allChildSteps.Add(ps);
                }
            }

            allChildSteps.AddRange(parentSteps);

            this.allSteps = allChildSteps;
        }

        /// <summary>
        /// Creates the processing steps form main package2.
        /// </summary>
        /// <param name="package">The package.</param>
        private List<ProcessingStep> CreateProcessingStepsFormMainPackage2(Package package)
        {
            List<ProcessingStep> allChildSteps = new List<ProcessingStep>();


            if (this.processingStepType == ProcessingStepType.Exposures || this.processingStepType == ProcessingStepType.Move || this.processingStepType == ProcessingStepType.Documented)
            {
                //ProcessingStep step =
                //    new ProcessingStep(this.remarks, package.Uid, -1, ProcessingStepType.Exposures, this.exposureDocument.Uid,
                //                       package.PackageType.Uid, dateOfEntry, this.userId);

                ProcessingStep step =
                    new ProcessingStep(this.remarks, package.Uid, -1, ProcessingStepType.Exposures, this.exposureDocument.Uid,
                                       package.PackageTypeId, dateOfEntry, this.userId);

                allChildSteps.Add(step);
            }

            if (this.processingStepType == ProcessingStepType.Treatment)
            {
                foreach (Treatment treatment in this.treatments)
                {
                    //Refactor
                    //ProcessingStep step =
                    //    new ProcessingStep(this.remarks, package.Uid, -1, ProcessingStepType.Treatment, treatment.Uid,
                    //                       package.PackageType.Uid, dateOfEntry, this.userId);

                    ProcessingStep step =
                        new ProcessingStep(this.remarks, package.Uid, -1, ProcessingStepType.Treatment, treatment.Uid,
                                           package.PackageTypeId, dateOfEntry, this.userId);

                    allChildSteps.Add(step);
                }

            }

            return allChildSteps;
        }

        /// <summary>
        /// Creates the processing steps form main package2.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="parentPackId">The parent pack identifier.</param>
        /// <returns></returns>
        private List<ProcessingStep> CreateProcessingStepsFormMainPackage2(Package package, long parentPackId)
        {
            List<ProcessingStep> allChildSteps = new List<ProcessingStep>();


            if (this.processingStepType == ProcessingStepType.Exposures || this.processingStepType == ProcessingStepType.Move || this.processingStepType == ProcessingStepType.Documented)
            {
                //Refactor
                //ProcessingStep step =
                //    new ProcessingStep(this.remarks, package.Uid, parentPackId, ProcessingStepType.Exposures, this.exposureDocument.Uid,
                //                       package.PackageType.Uid, dateOfEntry, this.userId);

                ProcessingStep step =
                    new ProcessingStep(this.remarks, package.Uid, parentPackId, ProcessingStepType.Exposures, this.exposureDocument.Uid,
                                       package.PackageTypeId, dateOfEntry, this.userId);

                allChildSteps.Add(step);
            }

            if (this.processingStepType == ProcessingStepType.Treatment)
            {
                foreach (Treatment treatment in this.treatments)
                {
                    //Refactor
                    //ProcessingStep step =
                    //    new ProcessingStep(this.remarks, package.Uid, parentPackId, ProcessingStepType.Treatment, treatment.Uid,
                    //                       package.PackageType.Uid, dateOfEntry, this.userId);
                    ProcessingStep step =
                        new ProcessingStep(this.remarks, package.Uid, parentPackId, ProcessingStepType.Treatment, treatment.Uid,
                                           package.PackageTypeId, dateOfEntry, this.userId);

                    allChildSteps.Add(step);
                }

            }

            return allChildSteps;
        }
    }
}
