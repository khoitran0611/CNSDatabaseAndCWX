using System;
using System.Text;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// This class serves as the primary product. It is the identification to the harves and is the first
    /// form to be packed. The only behaviour is validating the productionareaid and lifecycleid.
    /// It also contains a description for the harversted product. For example Tomato otherwise there is nothing
    /// in the system to identify what the actual product is.
    /// </summary>
    public class PrimaryProduct : IIdentifyable
    {
        private const string LengthExceptionMessage = "The length is to long.";
        private const int validlength = 255;

        private readonly string harvestedProductDescription;
        private string lifeCycleId;
        private string productionAreaId;

        private long uid;

        private int quantity;

        /// <summary>
        /// Initializes a new instance of the <see cref="PrimaryProduct"/> class.
        /// </summary>
        public PrimaryProduct()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrimaryProduct"/> class.
        /// </summary>
        /// <param name="productionAreaId">The production area id.</param>
        /// <param name="lifeCycleId">The life cycle id.</param>
        public PrimaryProduct(string productionAreaId, string lifeCycleId)
        {
            if (productionAreaId == null)
            {
                throw new ArgumentNullException("productionAreaId");
            }

            if (lifeCycleId == null)
            {
                throw new ArgumentNullException("lifeCycleId");
            }

            if (!Validate(productionAreaId))
            {
                throw new ArgumentException(LengthExceptionMessage, productionAreaId);
            }

            if (!Validate(lifeCycleId))
            {
                throw new ArgumentException(LengthExceptionMessage, lifeCycleId);
            }

            this.productionAreaId = productionAreaId.Trim();
            this.lifeCycleId = lifeCycleId.Trim();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PrimaryProduct"/> class.
        /// </summary>
        /// <param name="productionAreaId">The production area id.</param>
        /// <param name="lifeCycleId">The life cycle id.</param>
        /// <param name="harvestedProductDescription">The harvested product description.</param>
        public PrimaryProduct(string productionAreaId, string lifeCycleId, string harvestedProductDescription)
            : this(productionAreaId, lifeCycleId)
        {
            this.harvestedProductDescription = harvestedProductDescription;
        }

        /// <summary>
        /// Gets or sets the product uid.
        /// </summary>
        /// <value>
        /// The product uid.
        /// </value>
        public long ProductUid { get; set; }

        /// <summary>
        /// Gets or sets the name of the product.
        /// </summary>
        /// <value>
        /// The name of the product.
        /// </value>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets the product amount.
        /// </summary>
        /// <value>
        /// The product amount.
        /// </value>
        public decimal ProductAmount { get; set; }

        /// <summary>
        /// Gets or sets the uom uid.
        /// </summary>
        /// <value>
        /// The uom uid.
        /// </value>
        public UnitOfMeasurement Uom { get; set; }

        /// <summary>
        /// Gets or sets the parent uid.
        /// </summary>
        /// <value>
        /// The parent uid.
        /// </value>
        public long ParentUid { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="PrimaryProduct"/> is decomposed.
        /// </summary>
        /// <value>
        ///   <c>true</c> if decomposed; otherwise, <c>false</c>.
        /// </value>
        public bool Decomposed { get; set; }

        /// <summary>
        /// Gets or sets the matching product identifier.
        /// </summary>
        /// <value>
        /// The matching product identifier.
        /// </value>
        public long MatchingProdId { get; set; }

        /// <summary>
        /// Gets the life cycle id.
        /// </summary>
        /// <value>The life cycle id.</value>
        public string LifeCycleId
        {
            get { return lifeCycleId; }
            set { lifeCycleId = value; }
        }

        /// <summary>
        /// Gets the production area id.
        /// </summary>
        /// <value>The production area id.</value>
        public string ProductionAreaId
        {
            get { return productionAreaId; }
            set { productionAreaId = value; }
        }

        /// <summary>
        /// Gets the harvested product description_.
        /// </summary>
        /// <value>The harvested product description_.</value>
        public string HarvestedProductDescription
        {
            get { return harvestedProductDescription; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Validates the parameter according to the specified expression.
        /// </summary>
        /// <param name="tobeValidated">The string validated.</param>
        /// <returns></returns>
        private static bool Validate(string tobeValidated)
        {
            return tobeValidated.Length <= validlength;
        }

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            PrimaryProduct other = obj as PrimaryProduct;
            if (other == null)
            {
                return false;
            }
            if (other.productionAreaId == productionAreaId && other.lifeCycleId == lifeCycleId)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return productionAreaId.GetHashCode();
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            StringBuilder builder = new StringBuilder(productionAreaId);
            builder.Append(",");
            builder.Append(lifeCycleId);
            return builder.ToString();
        }
    }
}