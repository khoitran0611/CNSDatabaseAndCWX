using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;
using log4net;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public delegate void LocationEventHandler(Object sender, LocationEventArgs e);
    /// <summary>
    /// 
    /// </summary>
    public delegate void LocationMoveEventHandler(Object sender, LocationMoveEventArgs e);


    /// <summary>
    /// </summary>
    public class LocationMoveEventArgs : EventArgs
    {
        private readonly Package package;
        private readonly ExposureDocument exposureDocument;
        private readonly DateTime dateOfPlacement;
        private readonly Location from;
        private readonly Location to;

        /// <summary>
        /// Initializes a new instance of the <see cref="LocationMoveEventArgs"/> class.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="exposureDocument">The exposure document.</param>
        /// <param name="dateOfPlacement">The date of placement.</param>
        /// <param name="from">From.</param>
        /// <param name="to">To.</param>
        public LocationMoveEventArgs(Package package, ExposureDocument exposureDocument, DateTime dateOfPlacement, Location from, Location to)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            if (exposureDocument == null)
            {
                throw new ArgumentNullException("exposureDocument");
            }

            if (from == null)
            {
                throw new ArgumentNullException("from");
            }

            if (to == null)
            {
                throw new ArgumentNullException("to");
            }

            this.package = package;
            this.exposureDocument = exposureDocument;
            this.dateOfPlacement = dateOfPlacement;
            this.from = from;
            this.to = to;
        }

        /// <summary>
        /// Gets the package.
        /// </summary>
        /// <value>The package.</value>
        public Package Package
        {
            get { return package; }
        }

        /// <summary>
        /// Gets the exposure document.
        /// </summary>
        /// <value>The exposure document.</value>
        public ExposureDocument ExposureDocument
        {
            get { return exposureDocument; }
        }

        /// <summary>
        /// Gets the date of placement.
        /// </summary>
        /// <value>The date of placement.</value>
        public DateTime DateOfPlacement
        {
            get { return dateOfPlacement; }
        }

        /// <summary>
        /// Gets from.
        /// </summary>
        /// <value>From.</value>
        public Location From
        {
            get { return from; }
        }

        /// <summary>
        /// Gets to.
        /// </summary>
        /// <value>To.</value>
        public Location To
        {
            get { return to; }
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return String.Format("Moved from \"{0}\" to \"{1}\"", From.Name, To.Name);
        }

    }
    /// <summary>
    /// </summary>
    public class LocationEventArgs : EventArgs
    {
        private readonly Package package;
        private readonly ExposureDocument exposureDocument;
        private readonly DateTime dateOfPlacement;

        /// <summary>
        /// Initializes a new instance of the <see cref="LocationEventArgs"/> class.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="exposureDocument"></param>
        /// <param name="dateOfPlacement">The date of placement.</param>
        public LocationEventArgs(Package package, ExposureDocument exposureDocument, DateTime dateOfPlacement)
        {
            this.package = package;
            this.exposureDocument = exposureDocument;
            this.dateOfPlacement = dateOfPlacement;
        }

        /// <summary>
        /// Gets the package.
        /// </summary>
        /// <value>The package.</value>
        public Package Package
        {
            get { return package; }
        }

        /// <summary>
        /// Gets the date of placement.
        /// </summary>
        /// <value>The date of placement.</value>
        public DateTime DateOfPlacement
        {
            get { return dateOfPlacement; }
        }

        /// <summary>
        /// Gets the exposure document.
        /// </summary>
        /// <value>The exposure document.</value>
        public ExposureDocument ExposureDocument
        {
            get { return exposureDocument; }
        }
    }

    //public delegate void LineEventHandler(Object sender, LineEventArgs e);
    /// <summary>
    /// A PickupLocation has the responsibility to keep a package in storage.
    /// While the package is in the location, exposure can be documented for the package in the location.
    /// The location exposes the package to certain conditions, tracked in the form of exposures.
    /// This is done in an ExposureDocument. The ExposureDocument contains the prescibed exposures and the actual exposures
    /// for a package in a location.
    /// The life cycle of an ExposureDocument is the same as the interval that a package stays in storage.
    /// The moment the package is removed/moved from storage, the exposure is finished [and added to the journal].
    /// </summary>
    public class Location : IIdentifyable
    {
        /// <summary>
        /// Occurs when [remove fromlocation].
        /// </summary>
        public event LocationEventHandler RemoveFromlocation;

        /// <summary>
        /// Occurs when [put in location].
        /// </summary>
        public event LocationEventHandler PutInLocation;

        /// <summary>
        /// Occurs when [document location].
        /// </summary>
        public event LocationEventHandler DocumentLocation;

        /// <summary>
        /// Occurs when [move to another location].
        /// </summary>
        public event LocationMoveEventHandler MoveToAnotherLocation;


        //private readonly IDictionary<Package, ExposureDocument> exposureDocuments =
        //    new Dictionary<Package, ExposureDocument>();

        private readonly ILog log = LogManager.GetLogger(typeof (Location));

        //set by storage
        private readonly string name;
        private readonly ISet packages = new HashedSet();
        private long uid;
        private Address address;


        /// <summary>
        /// Initializes a new instance of the <see cref="Location"/> class.
        /// </summary>
        protected Location()
        {
        }

        /// <summary>
        /// Raises the <see cref="E:RemoveFromlocation"/> event.
        /// </summary>
        /// <param name="e">The <see cref="AgriMore.Logistics.Domain.LocationEventArgs"/> instance containing the event data.</param>
        protected virtual void OnRemoveFromlocation(LocationEventArgs e)
        {
            if (RemoveFromlocation != null)
            {
                RemoveFromlocation(this, e);
            }
        }

        /// <summary>
        /// Raises the <see cref="E:PutInLocation"/> event.
        /// </summary>
        /// <param name="e">The <see cref="AgriMore.Logistics.Domain.LocationEventArgs"/> instance containing the event data.</param>
        protected virtual void OnPutInLocation(LocationEventArgs e)
        {
            if (PutInLocation != null)
            {
                PutInLocation(this, e);
            }
        }

        /// <summary>
        /// Raises the <see cref="E:MoveToAnotherLocation"/> event.
        /// </summary>
        /// <param name="e">The <see cref="AgriMore.Logistics.Domain.LocationEventArgs"/> instance containing the event data.</param>
        protected virtual void OnMoveToAnotherLocation(LocationMoveEventArgs e)
        {
            if (MoveToAnotherLocation != null)
            {
                MoveToAnotherLocation(this, e);
            }
        }
        /// <summary>
        /// Raises the <see cref="E:DocumentLocation"/> event.
        /// </summary>
        /// <param name="e">The <see cref="AgriMore.Logistics.Domain.LocationEventArgs"/> instance containing the event data.</param>
        protected virtual void OnDocumentLocation(LocationEventArgs e)
        {
            if (DocumentLocation != null)
            {
                DocumentLocation(this, e);
            }
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="Location"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public Location(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            if (name.Trim() == String.Empty)
            {
                throw new ArgumentException("name cannot be empty");
            }

            this.name = name;
        }

        /// <summary>
        /// Gets the exposure documents.
        /// </summary>
        /// <value>The exposure documents.</value>
        public IEnumerable<ExposureDocument> ExposureDocuments
        {
            get
            {
                IList<ExposureDocument> exposureDocuments = new List<ExposureDocument>();
                foreach (Package package in packages)
                {
                    ExposureDocument exposureDocument = package.RetrieveExposureDocument(this);

                    if (exposureDocument != null)
                    {
                        exposureDocuments.Add(exposureDocument);
                    }
                }

                foreach (ExposureDocument document in exposureDocuments)
                {
                    yield return document;
                }
            }
        }

        /// <summary>
        /// Gets the packages.
        /// </summary>
        /// <value>The packages.</value>
        public IEnumerable<Package> Packages
        {
            get
            {
                foreach (Package package in packages)
                {
                    yield return package;
                }
            }
        }

        /// <summary>
        /// Gets or sets the location id.
        /// </summary>
        /// <value>The location id.</value>
        public string Name
        {
            get { return name; }
        }

        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>The address.</value>
        public Address Address
        {
            get
            {
                return address;
            }
            internal set
            {
                address = value;
            }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Determines whether this location [contains] [the specified package].
        /// </summary>
        /// <param name="package">The package.</param>
        /// <returns>
        /// 	<c>true</c> if [contains] [the specified package]; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(Package package)
        {
            if (package == null)
                throw new ArgumentNullException("package");

            return packages.Contains(package);
        }

        /// <summary>
        /// Puts the specified package in this location.
        /// The exposuredocument has to describe the package that is put.
        /// it needs to check if the script has prescribed and actuals. (so if exposures are valid for putting)
        /// location does not keep track of exposures, the journal does that.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="exposures">The exposures.</param>
        /// <param name="dateOfPlacement">The date of placement.</param>
        /// <exception cref="ArgumentNullException">when one or all of parameters is null</exception>
        /// <exception cref="ArgumentException">when package is already present in the location</exception>
        /// <exception cref="ArgumentException">when prescribed and/or actual exposures collections are empty </exception>
        public ExposureDocument Put(Package package, IEnumerable<Exposure> exposures, DateTime dateOfPlacement)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            if (exposures == null)
            {
                throw new ArgumentNullException("exposures");
            }

            if (Contains(package))
            {
                if (log.IsDebugEnabled)
                    log.Debug(string.Format("Package {0} already exists in location", package));

                throw new ArgumentException("Package already exists in location");
            }

            packages.Add(package);
            ExposureDocument newExposureDocument = new ExposureDocument(this, package, dateOfPlacement);

            package.AddExposureDocument(newExposureDocument);

            foreach (Exposure exposure in exposures)
            {
                newExposureDocument.AddExposure(exposure);
            }

            OnPutInLocation(new LocationEventArgs(package, newExposureDocument, dateOfPlacement));

            return newExposureDocument;
        }

        /// <summary>
        /// Puts the specified package.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="parentPackage">The parent package.</param>
        /// <param name="exposures">The exposures.</param>
        /// <param name="dateOfPlacement">The date of placement.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException">when one or all of parameters is null</exception>
        /// <exception cref="ArgumentException">when package is already present in the location</exception>
        /// <exception cref="ArgumentException">when prescribed and/or actual exposures collections are empty </exception>
        public ExposureDocument Put(Package package, Package parentPackage, IEnumerable<Exposure> exposures, DateTime dateOfPlacement)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            if (exposures == null)
            {
                throw new ArgumentNullException("exposures");
            }

            if (Contains(package))
            {
                if (log.IsDebugEnabled)
                    log.Debug(string.Format("Package {0} already exists in location", package));

                throw new ArgumentException("Package already exists in location");
            }

            packages.Add(package);
            var parenntExposureDocument = new ExposureDocument(this, parentPackage, dateOfPlacement);
            package.AddExposureDocument(parenntExposureDocument);

            var currentExposureDocument = new ExposureDocument(this, package, dateOfPlacement);
            package.AddExposureDocument(currentExposureDocument);

            foreach (Exposure exposure in exposures)
            {
                parenntExposureDocument.AddExposure(exposure);
            }

            OnPutInLocation(new LocationEventArgs(package, parenntExposureDocument, dateOfPlacement));

            return parenntExposureDocument;
        }


        /// <summary>
        /// Documents the actual value.
        /// </summary>
        /// <param name="measuredValue">The measured value.</param>
        /// <param name="exposureType">Type of the exposure.</param>
        public void DocumentActualValue(MeasuredValue measuredValue, ExposureType exposureType)
        {
            foreach (Package package in Packages)
            {
                MeasuredValue clonedMeasuredValue = (MeasuredValue)measuredValue.Clone();
                DocumentActualValue(package, clonedMeasuredValue, exposureType);
            }
        }


        /// <summary>
        /// Documents the actual measuredValue exposure.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="measuredValue">The measuredValue.</param>
        /// <param name="exposureType">Type of the exposure.</param>
        public void DocumentActualValue(Package package, MeasuredValue measuredValue, ExposureType exposureType)
        {

            ExposureDocument exposureDocument = GetExposureDocument(package);

            if (exposureDocument != null)
            {
                bool addedMeasuredValue = false;

                if (measuredValue.DateTimeOfMeasurement >= exposureDocument.Start)
                {
                    addedMeasuredValue = exposureDocument.AddActualValue(measuredValue, exposureType);
                }

                if (addedMeasuredValue)
                {
                    OnDocumentLocation(
                        new LocationEventArgs(package, exposureDocument, measuredValue.DateTimeOfMeasurement));
                }
            }
            else
            {
                throw new ArgumentException(
                    "The actual value exposure cannot be documented for a package that is not in the location");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="measuredValue"></param>
        /// <param name="exposureDefine"></param>
        public void DocumentActualValueForExposureDefine(MeasuredValue measuredValue, ExposureDefine exposureDefine)
        {
            foreach (Package package in Packages)
            {
                MeasuredValue clonedMeasuredValue = (MeasuredValue)measuredValue.Clone();
                DocumentActualValueForExposureDefine(package, clonedMeasuredValue, exposureDefine);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="package"></param>
        /// <param name="measuredValue"></param>
        /// <param name="exposureDefine"></param>
        public void DocumentActualValueForExposureDefine(Package package, MeasuredValue measuredValue, ExposureDefine exposureDefine)
        {

            ExposureDocument exposureDocument = GetExposureDocument(package);

            if (exposureDocument != null)
            {
                bool addedMeasuredValue = false;

                if (measuredValue.DateTimeOfMeasurement >= exposureDocument.Start)
                {
                    addedMeasuredValue = exposureDocument.AddActualValueForExposureDefine(measuredValue, exposureDefine);
                }

                if (addedMeasuredValue)
                {
                    OnDocumentLocation(
                        new LocationEventArgs(package, exposureDocument, measuredValue.DateTimeOfMeasurement));
                }
            }
            else
            {
                throw new ArgumentException(
                    "The actual value exposure cannot be documented for a package that is not in the location");
            }
        }

        /// <summary>
        /// Gets the ExposureDocument so far for a package in this location.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <returns></returns>
        public ExposureDocument GetExposureDocument(Package package)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            ExposureDocument exposureDocument;

            if (packages.Contains(package))
            {
                exposureDocument = package.RetrieveExposureDocument(this);
            }
            else
            {
                throw new ArgumentException(
                    String.Format("package with uid [{0}]is not in location [{1}]", package.Uid, name));
            }

            return exposureDocument;
        }

        /// <summary>
        /// Removes the specified package from the location.
        /// </summary>
        /// <param name="package">The package.</param>
        public void Delete(Package package)
        {
            if (Contains(package))
            {
                packages.Remove(package);
            }
            else
            {
                throw new ArgumentException(
                    String.Format("package with uid [{0}]is not in location [{1}]", package.Uid, name));
            }
        }

        /// <summary>
        /// Removes the specified package, returns the Finished
        /// ExposureDocument that was created while the package was in the location.
        /// This location no longer keeps the exposure for the package
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="datetime">DateTime of removal</param>
        /// <returns>the ExposureDocument</returns>
        public ExposureDocument Remove(Package package, DateTime datetime)
        {
            ExposureDocument exposureDocument;

            if (Contains(package))
            {
                exposureDocument = package.RetrieveExposureDocument(this);
                if (exposureDocument == null)
                {
                    throw new ArgumentException(
                        String.Format("package with uid [{0}] is in location [{1}] but has not active exposuredocument",
                                      package.Uid, name));
                }
            }
            else
            {
                throw new ArgumentException(
                    String.Format("package with uid [{0}] is not in location [{1}]", package.Uid, name));
            }

            exposureDocument.Finish(datetime);
            packages.Remove(package);

            OnRemoveFromlocation(new LocationEventArgs(package, exposureDocument, datetime));

            return exposureDocument;
        }

        /// <summary>
        /// Moves the specified package to the destination. returns the finished exposurescript of the source location.
        /// </summary>
        /// <param name="package">The package.</param>
        /// <param name="destination">The destination.</param>
        /// <param name="exposures">The exposures.</param>
        /// <param name="dateOfPlacement">The date of placement.</param>
        /// <returns>
        /// The finished script on the source location
        /// </returns>
        public ExposureDocument Move(Package package, Location destination, IEnumerable<Exposure> exposures,
                                     DateTime dateOfPlacement)
        {
            Remove(package, dateOfPlacement);
            
            ExposureDocument exposureDocument = destination.Put(package, exposures, dateOfPlacement);

            OnMoveToAnotherLocation(new LocationMoveEventArgs(package, destination.GetExposureDocument(package), dateOfPlacement, this, destination));

            return exposureDocument;
        }

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            return (obj is Location
                    && ((Location) obj).Name == name);
        }


        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return name;
        }

        /// <summary>
        /// Serves as a hash function for a particular type. <see cref="M:System.Object.GetHashCode"></see> is suitable for use in hashing algorithms and data structures like a hash table.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return name.GetHashCode();
        }

    }
}
