namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class Measurement
    {
        private int value;
        private UnitOfMeasurement unitOfMeasurement;

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        public int Value
        {
            get { return value; }
        }

        /// <summary>
        /// Gets or sets the unit of measurement.
        /// </summary>
        /// <value>The unit of measurement.</value>
        public UnitOfMeasurement UnitOfMeasurement
        {
            get { return unitOfMeasurement; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Measurement"/> class.
        /// </summary>
        protected Measurement()
        {
        }
        
        /// <summary>
        /// Initializes a new instance of the <see cref="Measurement"/> class.
        /// </summary>
        /// <param name="unitOfMeasurement">The unit of measurement.</param>
        /// <param name="value">The value.</param>
        public Measurement(UnitOfMeasurement unitOfMeasurement, int value)
        {
            this.unitOfMeasurement = unitOfMeasurement;
            this.value = value;
        }
    }
}