﻿using System.Collections.Generic;
using System.Linq;
using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class ExposureDefine : IIdentifyable
    {
        private long uid;
        private int temperature;        
        private UnitOfMeasurement temperatureUoM;                                       

        /// <summary>
        /// 
        /// </summary>
        public ExposureDefine()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="temperature"></param>
        /// <param name="temperatureUoM"></param>
        public ExposureDefine(int temperature, UnitOfMeasurement temperatureUoM)
        {
            this.temperature = temperature;                        
            this.temperatureUoM = temperatureUoM;
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Packaging Description.
        /// </summary>
        /// <value>The uid.</value>
        public int Temperature
        {
            get { return temperature; }
            set { temperature = value; }
        }        

        /// <summary>
        /// m
        /// </summary>
        public UnitOfMeasurement TemperatureUOM
        {
            get { return temperatureUoM; }
            set { temperatureUoM = value; }
        }       
    }
}
