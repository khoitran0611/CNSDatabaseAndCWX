using System;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Default implementation of IRange interface, A Generic Range defines a continuous interval between a start and an end of type T.
    /// </summary>
    public class Range<T> : IRange<T> where T : IComparable<T>
    {
        private readonly T start;
        private T end;

        /// <summary>
        /// Initializes a new instance of the <see cref="Range&lt;T&gt;"/> class with a start and an end equal to start.
        /// </summary>
        /// <param name="start">The start.</param>
        public Range(T start)
        {
            this.start = start;
            end = start;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Range&lt;T&gt;"/> class with a start and an end.
        /// </summary>
        /// <param name="start">The start.</param>
        /// <param name="end">The end.</param>
        public Range(T start, T end)
        {
            if (start.CompareTo(end) > 0)
            {
                throw new ArgumentException("start value can not be higher than end value");
            }

            this.start = start;
            this.end = end;
        }

        #region IRange<T> Members

        /// <summary>
        /// Gets the start of the range.
        /// </summary>
        /// <value>The start.</value>
        public T Start
        {
            get { return start; }
        }

        /// <summary>
        /// Gets the end of the range.
        /// </summary>
        /// <value>The end.</value>
        public T End
        {
            get { return end; }
        }

        /// <summary>
        /// Determines whether the specified value is in the range.
        /// </summary>
        /// <param name="valueToFind">The value to find.</param>
        /// <returns>
        /// 	<c>true</c> if [contains] [the specified value to find]; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(T valueToFind)
        {
            return valueToFind.CompareTo(Start) >= 0 &&
                   valueToFind.CompareTo(End) <= 0;
        }


        /// <summary>
        /// Extends the end to the specified further end.
        /// </summary>
        /// <param name="furtherEnd">The further end.</param>
        public void Extend(T furtherEnd)
        {
            if (furtherEnd.CompareTo(end) > 0)
            {
                end = furtherEnd;
            }
        }

        #endregion
    }
}