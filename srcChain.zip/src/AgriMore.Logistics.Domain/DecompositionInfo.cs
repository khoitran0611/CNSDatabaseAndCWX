﻿using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class DecompositionInfo : IIdentifyable
    {
        public virtual long Uid { get; set; }

        public virtual string KeyFigure4OrgId { get; set; }

        public virtual long RootProdId { get; set; }

        public virtual long FromProdId { get; set; }

        public virtual long ToProdId { get; set; }

        public virtual decimal KeyFigureVal { get; set; }

        public virtual decimal FigureWeight { get; set; }

        public virtual decimal ActualWeight { get; set; }

        public virtual long ProdSupplyId { get; set; }

        public virtual DateTime DecomposedDate { get; set; }

        public virtual long DecomposedByChainId { get; set; }
    }
}