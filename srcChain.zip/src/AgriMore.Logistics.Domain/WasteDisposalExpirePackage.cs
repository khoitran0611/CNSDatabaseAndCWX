﻿using AgriMore.Logistics.Domain.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain
{
    public class WasteDisposalExpirePackage : IIdentifyable
    {
         private long uid;
         private long expiredPackageId;                 
         private long wasteDisposalPackageId;
                        
        
        /// <summary>
        /// 
        /// </summary>
         public WasteDisposalExpirePackage()
         {
         }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public long WasteDisposalPackageId
        {
            get { return wasteDisposalPackageId; }
            set { wasteDisposalPackageId = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public long ExpiredPackageId
        {
            get { return expiredPackageId; }
            set { expiredPackageId = value; }
        } 
             
    }
}
