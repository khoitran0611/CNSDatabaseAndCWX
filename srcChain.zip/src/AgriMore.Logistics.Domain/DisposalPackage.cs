﻿using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    public class DisposalPackage : IIdentifyable
    {
        public long Uid { get; set; }

        public long Amount { get; set; }

        public DisposalPackingStatus Status { get; set; }

        public long UnPackId { get; set; }

        public long UnpackLocationId { get; set; }

        public long PackageTypeId { get; set; }

        public long PackageTypeCategoryId { get; set; }

        public long PackageMaterialId { get; set; }        

        public DateTime UnpackDate { get; set; }
    }

    public enum DisposalPackingStatus
    {
        Unpacked = 1,
        Reused = 2,
        Recycle = 3,
        ResidualWaste = 4,
        Expired = 5
    }
}
