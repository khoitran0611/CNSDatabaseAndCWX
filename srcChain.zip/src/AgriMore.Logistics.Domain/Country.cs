namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Represents the countries in the system.
    /// </summary>
    public class Country : AbstractKeyNameType
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Country"/> class.
        /// </summary>
        protected Country()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Country"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public Country(string name)
            : base(name)
        {
        }
    }
}