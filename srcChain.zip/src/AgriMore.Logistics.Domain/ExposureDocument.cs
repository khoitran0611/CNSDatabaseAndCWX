using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Script for prescribed and actual types of exposures for a location and a packed primary product.
    /// The script contains the exposures ('prescriptions' and the 'actuals') and knows the total time a 
    /// primary product has been in a location. 
    /// Contains exposures with prescribed values.
    /// Lifecycle of this object is the same as the time a package is in a particular location
    /// </summary>
    public class ExposureDocument : IRange<DateTime>, IIdentifyable
    {
        /// <summary>
        /// 
        /// </summary>
        public static readonly DateTime MaxDateTime = new DateTime(9999, 12, 31, 23, 59, 59); //needed for mysql

        private long uid;
        private readonly ISet exposures = new HashedSet();
        private readonly Package package;
        private readonly Location location;
        private DateTime dateOfPlacement;
        private DateTime dateOfRemoval = MaxDateTime;
        //private bool isActive;


        /// <summary>
        /// Initializes a new instance of the <see cref="ExposureDocument"/> class.
        /// </summary>
        protected ExposureDocument()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ExposureDocument"/> class.
        /// </summary>
        /// <param name="location">The location.</param>
        /// <param name="package">The package.</param>
        public ExposureDocument(Location location, Package package) : this(location, package, DateTime.Now)
        {

        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ExposureDocument"/> class.
        /// </summary>
        /// <param name="location">The location.</param>
        /// <param name="package">The package.</param>
        /// <param name="dateOfPlacement">The date of placement.</param>
        public ExposureDocument(Location location, Package package, DateTime dateOfPlacement)
            : this(location, package, new List<Exposure>(), dateOfPlacement)
        {

        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ExposureDocument"/> class.
        /// </summary>
        /// <param name="location">The location.</param>
        /// <param name="package">The package.</param>
        /// <param name="exposures">The exposures.</param>
        /// <param name="dateOfPlacement">The date of placement.</param>
        public ExposureDocument(Location location, Package package, IEnumerable<Exposure> exposures, DateTime dateOfPlacement)
        {
            if (dateOfPlacement > DateTime.Now)
            {
                throw new ArgumentException("date of placement can not be in the future");
            }

            if (location == null)
            {
                throw new ArgumentNullException("location");
            }   

            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            if (exposures == null)
            {
                throw new ArgumentNullException("exposures");
            }

            foreach (Exposure exposure in exposures)
            {
              this.exposures.Add(exposure);  
            }

            this.location = location;
            this.package = package;
            this.dateOfPlacement = dateOfPlacement;
        }

        /// <summary>
        /// Gets the exposures.
        /// </summary>
        /// <value>The exposures.</value>
        public IEnumerable<Exposure> Exposures
        {
            get
            {
                foreach (Exposure exposure in exposures)
                {
                    yield return exposure;
                }
            }
        }

        /// <summary>
        /// Gets the package.
        /// </summary>
        /// <value>The package.</value>
        public Package Package
        {
            get { return package; }
        }

        /// <summary>
        /// Gets the location.
        /// </summary>
        /// <value>The location.</value>
        public Location Location
        {
            get { return location; }
        }

        /// <summary>
        /// Adds the actual value.
        /// </summary>
        /// <param name="actualValue">The actual value and time.</param>
        /// <param name="exposureType">Type of the exposure.</param>
        public bool AddActualValue(MeasuredValue actualValue, ExposureType exposureType)
        {
            bool addedMeasuredValue = false;

            if (actualValue.DateTimeOfMeasurement < Start)
            {
                throw new ArgumentException("datetime of documented can not be before the first exposure datetime");
            }

            if (actualValue.DateTimeOfMeasurement > DateTime.Now)
            {
                throw new ArgumentException("datetime of documented can not be in the future");
            }

            foreach (Exposure exposure in exposures)
            {
                if (exposure.ExposureType != null && exposure.ExposureType.Equals(exposureType))
                {
                    exposure.AddActualValue(actualValue);
                    addedMeasuredValue = true;
                }
            }

            return addedMeasuredValue;
        }


        public bool AddActualValueForExposureDefine(MeasuredValue actualValue, ExposureDefine exposureDefine)
        {
            bool addedMeasuredValue = false;

            if (actualValue.DateTimeOfMeasurement < Start)
            {
                throw new ArgumentException("datetime of documented can not be before the first exposure datetime");
            }

            if (actualValue.DateTimeOfMeasurement > DateTime.Now)
            {
                throw new ArgumentException("datetime of documented can not be in the future");
            }

            foreach (Exposure exposure in exposures)
            {
                if (exposure.ExposureDefineId.Equals(exposureDefine.Uid))
                {
                    exposure.AddActualValue(actualValue);
                    addedMeasuredValue = true;
                }
            }

            return addedMeasuredValue;
        }


        /// <summary>
        /// Adds the exposure.
        /// </summary>
        /// <param name="exposure">The exposure.</param>
        public void AddExposure(Exposure exposure)
        {
            foreach (Exposure tmpExposure in exposures)
            {
                if (tmpExposure.ExposureType.Equals(exposure.ExposureType))
                {
                    throw new ArgumentException("Exposure already exists");
                } 
            }

            exposures.Add(exposure);

        }

        /// <summary>
        /// Finishes this ExposureDocument. this could be where an ExposureDocument event fires to
        /// the journal listener.
        /// </summary>
        public void Finish(DateTime dateOfRemoval)
        {
            if (dateOfRemoval < dateOfPlacement)
            {
                throw new ArgumentException("date of removal can not start before date of placement");
            }

            this.dateOfRemoval = dateOfRemoval;

        }

        /// <summary>
        /// Gets the start of the range.
        /// </summary>
        /// <value>The start.</value>
        public DateTime Start
        {
            get
            {
                DateTime lowestStartDate = DateTime.Now;

                foreach (Exposure exposure in exposures)
                {
                    if (exposure.Start < lowestStartDate)
                    {
                        lowestStartDate = exposure.Start;
                    }
                }

                return lowestStartDate;
            }
        }

        /// <summary>
        /// Gets the end of the range.
        /// </summary>
        /// <value>The end.</value>
        public DateTime End
        {
            get
            {
                DateTime highestStartDate = Start;

                foreach (Exposure exposure in exposures)
                {
                    if (exposure.End > highestStartDate)
                    {
                        highestStartDate = exposure.End;
                    }
                }

                return highestStartDate;
            }
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets the date of removal.
        /// </summary>
        /// <value>The date of removal.</value>
        public DateTime DateOfRemoval
        {
            get { return dateOfRemoval; }
        }

        /// <summary>
        /// Gets the date of placement.
        /// </summary>
        /// <value>The date of placement.</value>
        public DateTime DateOfPlacement
        {
            get { return dateOfPlacement; }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is active.
        /// </summary>
        /// <value><c>true</c> if this instance is active; otherwise, <c>false</c>.</value>
        public bool IsActive
        {
            get
            {
                return dateOfRemoval.Equals(MaxDateTime);
            }
        }

        /// <summary>
        /// Determines whether this range contains the specified value to find.
        /// </summary>
        /// <param name="valueToFind">The value to find.</param>
        /// <returns>
        /// 	<c>true</c> if this range contains the specified value to find; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(DateTime valueToFind)
        {
            if ((valueToFind >= Start) && (valueToFind <= End))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Determines whether [contains] [the specified location].
        /// </summary>
        /// <param name="locationToFind">The location to find.</param>
        /// <returns>
        /// 	<c>true</c> if [contains] [the specified location]; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(Location locationToFind)
        {
            return location.Equals(locationToFind);
        }

        /// <summary>
        /// Extends the end to the specified further end.
        /// </summary>
        /// <param name="furtherEnd">The further end.</param>
        public void Extend(DateTime furtherEnd)
        {
            foreach (Exposure exposure in exposures)
            {
                exposure.Extend(furtherEnd);
            }
        }
    }
}
