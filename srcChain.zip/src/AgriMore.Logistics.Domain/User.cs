using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;
using log4net;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// User class represents an user that is part af a ChainEntity. 
    /// </summary>
    public class User : IIdentifyable
    {
        private readonly ISet roles = new HashedSet();

        private readonly string firstName;
        private readonly string lastName;
        private readonly ILog log = LogManager.GetLogger(typeof (User));
        private string password;
        private long uid;
        private string username;
        private string usingLang;
        private string activeCode;
        private string email;        

        /// <summary>
        /// Initializes a new instance of the <see cref="User"/> class.
        /// </summary>
        protected User()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <param name="roles"></param>
        /// <param name="activeCode"></param>
        /// <param name="email"></param>
        /// <param name="usingLang"></param>
        public User(string username, string password, string firstName, string lastName, IEnumerable<Role> roles,
            string activeCode, string email, string usingLang = "en-GB")
        {
            if (username == null)
            {
                log.Debug("username cannot be null.");
                throw new ArgumentNullException("username");
            }

            if (password == null)
            {
                log.Debug("password cannot be null.");
                throw new ArgumentNullException("password");
            }
            if (firstName == null)
            {
                log.Debug("firstName cannot be null.");
                throw new ArgumentNullException("firstName");
            }

            if (lastName == null)
            {
                log.Debug("lastName cannot be null.");
                throw new ArgumentNullException("lastName");
            }

            if (username.Trim().Length == 0)
            {
                log.Debug("username cannot be empty.");
                throw new ArgumentException("username cannot be empty", "username");
            }

            if (password.Trim().Length == 0)
            {
                log.Debug("password cannot be empty.");
                throw new ArgumentException("password cannot be empty", "password");
            }
            if (firstName.Trim().Length == 0)
            {
                log.Debug("firstName cannot be empty.");
                throw new ArgumentException("firstName cannot be empty", "firstName");
            }

            if (lastName.Trim().Length == 0)
            {
                log.Debug("lastName cannot be empty.");
                throw new ArgumentException("lastName cannot be empty", "lastName");
            }

            //if (roles == null)
            //{
            //    throw new ArgumentNullException("roles");
            //}

            this.username = username;
            this.password = password;
            this.firstName = firstName;
            this.lastName = lastName;
            this.usingLang = usingLang;
            this.activeCode = activeCode;
            this.email = email;

            this.roles.AddAll(new List<Role>(roles));
        }
        
        /// <summary>
        /// Gets the username.
        /// </summary>
        /// <value>The username.</value>
        public string Username
        {
            get { return username; }
        }

        /// <summary>
        /// Gets the password.
        /// </summary>
        /// <value>The password.</value>
        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        /// <summary>
        /// Gets the name of the first.
        /// </summary>
        /// <value>The name of the first.</value>
        public string FirstName
        {
            get { return firstName; }
        }

        /// <summary>
        /// Gets the name of the last.
        /// </summary>
        /// <value>The name of the last.</value>
        public string LastName
        {
            get { return lastName; }
        }

        /// <summary>
        /// Gets the roles.
        /// </summary>
        /// <value>The roles.</value>
        public IEnumerable<Role> Roles
        {
            get
            {
                foreach (Role role in roles)
                {
                    yield return role;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public string UsingLang
        {
            get { return usingLang; }
            set { usingLang = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string ActiveCode
        {
            get { return activeCode; }
            set { activeCode = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// If all id's are the same consider it the same package.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            User other = obj as User;
            if (other == null)
            {
                return false;
            }

            if (Uid != 0)
            {
                return (Uid == other.Uid);
            }

            if (!Username.GetHashCode().Equals(other.Username.GetHashCode()))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return String.Format("{0} {1}", firstName, lastName);
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return Username.GetHashCode();
        }

        /// <summary>
        /// Adds the role.
        /// </summary>
        /// <param name="role">The role.</param>
        public void AddRole(Role role)
        {
            if(role==null)
            {
                throw new ArgumentNullException("role","role cannot be null.");
            }
            
            roles.Add(role);
        }
    }
}