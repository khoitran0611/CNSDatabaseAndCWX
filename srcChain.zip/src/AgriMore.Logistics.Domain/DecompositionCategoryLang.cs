﻿using AgriMore.Logistics.Common;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;
using System.Collections.Generic;
using System.Linq;

namespace AgriMore.Logistics.Domain
{
    ///<summary>
    ///</summary>
    public class DecompositionCategoryLang : IIdentifyable
    {
        private long uid;
        private string name;
        private string langCode;
        private DecompositionCategory decompositionCategory;
        private ISet decompositionCategoryLangs = new HashedSet();

        /// <summary>
        /// 
        /// </summary>
        public DecompositionCategoryLang()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="langCode"></param>
        /// <param name="category"></param>
        public DecompositionCategoryLang(string name, string langCode, DecompositionCategory category)
        {
            this.name = name;
            this.langCode = langCode;
            this.decompositionCategory = category;
        }

        /// <summary>
        /// Gets or sets the Uid
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Gets or sets the LangCode
        /// </summary>
        public string LangCode
        {
            get { return langCode; }
            set { langCode = value; }
        }

        /// <summary>
        /// Gets or sets the CategoryType
        /// </summary>
        public DecompositionCategory DecompositionCategory
        {
            get { return decompositionCategory; }
            set { decompositionCategory = value; }
        }

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            DecompositionCategoryLang categoryLang = CategoryLangs.Where(it => it.LangCode.Equals(langCode)).SingleOrDefault();

            return categoryLang == null ? Name : categoryLang.Name;
        }

        /// <summary>
        /// Gets or sets the CatTypeLangs.
        /// </summary>
        public IList<DecompositionCategoryLang> CategoryLangs
        {
            get { return ListHandler.ConvertToGenericList<DecompositionCategoryLang>(decompositionCategoryLangs); }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="categoryLang"></param>
        public void AddCategoryLangToList(DecompositionCategoryLang categoryLang)
        {
            decompositionCategoryLangs.Add(categoryLang);
        }

        /// <summary>
        /// Remove CategoryLangs
        /// </summary>
        public void RemoveCategoryLangFromList()
        {
            decompositionCategoryLangs.Clear();
        }

        /// <summary>
        /// Remove CategoryLangs
        /// </summary>
        public void RemoveCategoryLangFromList(DecompositionCategoryLang categoryLang)
        {
            decompositionCategoryLangs.Remove(categoryLang);
        }
    }
}
