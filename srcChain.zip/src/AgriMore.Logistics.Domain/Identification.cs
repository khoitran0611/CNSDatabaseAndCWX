using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// This class is an implementation for identification
    /// </summary>
    public class Identification : IIdentifyable
    {
        private readonly ChainEntity chainEntity;
        private readonly string id;
        private long uid;
        private Package package;

        /// <summary>
        /// Gets or sets from uid.
        /// </summary>
        /// <value>
        /// From uid.
        /// </value>
        public long FromUid { get; set; }

        /// <summary>
        /// Gets or sets to uid.
        /// </summary>
        /// <value>
        /// To uid.
        /// </value>
        public long ToUid { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ReferenceFrom { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ReferenceTo { get; set; }        

        /// <summary>
        /// Initializes a new instance of the <see cref="Identification"/> class.
        /// </summary>
        protected Identification()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Identification"/> class.
        /// </summary>
        /// <param name="id">The id.</param>
        /// <param name="chainEntity">The chain entity.</param>
        public Identification(string id, ChainEntity chainEntity)
        {
            if (id == null)
            {
                throw new ArgumentNullException("id");
            }
            if (chainEntity == null)
            {
                throw new ArgumentNullException("chainEntity");
            }
            this.id = id;
            this.chainEntity = chainEntity;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="chainEntity"></param>
        /// <param name="fromUid"></param>
        /// <param name="toUid"></param>
        public Identification(string id, ChainEntity chainEntity, long fromUid, long toUid)
            :this(id,chainEntity)
        {
            this.FromUid = fromUid;
            this.ToUid = toUid;
        }

        public Identification(string id, ChainEntity chainEntity, long fromUid, long toUid, string referenceFrom, string referenceTo)
            : this(id, chainEntity, fromUid, toUid)
        {
            this.ReferenceFrom = referenceFrom;
            this.ReferenceTo = referenceTo;            
        }

        /// <summary>
        /// Gets the id.
        /// </summary>
        /// <value>The id.</value>
        public string Id
        {
            get { return id; }
        }

        /// <summary>
        /// Gets the chainEntity.
        /// </summary>
        /// <value>The chainEntity.</value>
        public ChainEntity ChainEntity
        {
            get { return chainEntity; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            Identification other = obj as Identification;
            if (other == null)
            {
                return false;
            }

            if (Uid != 0)
            {
                return (Uid == other.Uid);
            }

            //chainEntity can never be null
            if (other.id == id && other.chainEntity.Equals(chainEntity))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return chainEntity.GetHashCode() + id.GetHashCode();
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return id;
        }

        /// <summary>
        /// Gets or sets the package.
        /// </summary>
        /// <value>The package.</value>
        public Package Package
        {
            get
            {
                return package;
            }
            internal set
            {
                package = value;
            }
        }
    }
}