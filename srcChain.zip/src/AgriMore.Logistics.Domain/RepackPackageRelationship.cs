using System;
using System.Collections.Generic;
using System.Text;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// </summary>
    public class RepackPackageRelationship : IIdentifyable
    {
        private long repackedPackageId;
        private long newPackageFromRepackId;
        private long uid;


        /// <summary>
        /// Initializes a new instance of the <see cref="RepackPackageRelationship"/> class.
        /// </summary>
        protected RepackPackageRelationship()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RepackPackageRelationship"/> class.
        /// </summary>
        /// <param name="repackedPackage">The repacked package.</param>
        /// <param name="newPackageFromRepack">The new package from repack.</param>
        public RepackPackageRelationship(long repackedPackage, long newPackageFromRepack)
        {
            this.repackedPackageId = repackedPackage;
            this.newPackageFromRepackId = newPackageFromRepack;
        }

        /// <summary>
        /// Gets the repacked package.
        /// </summary>
        /// <value>The repacked package.</value>
        public long RepackedPackageId
        {
            get { return repackedPackageId; }
        }

        /// <summary>
        /// Gets the new package from repack.
        /// </summary>
        /// <value>The new package from repack.</value>
        public long NewPackageFromRepackId
        {
            get { return newPackageFromRepackId; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion
    }
}
