using System;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;
using System.Collections.Generic;
using AgriMore.Logistics.Common;
using System.Linq;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// This class represents the treating in which a primary product or another package is treated.
    /// The quality factor is delegated to the treatment type and returned without any modifications.
    /// </summary>
    public class DecompositionType : IIdentifyable
    {
        private string name;
        private string gs1Code;
        private string otherCode;
        private string ledgerCode;
        private long uid;
        private DecompositionCategory decompositionCategory;
        private UnitOfMeasurement unitOfMeasurement;
        private readonly ISet decompositionTypeLangs = new HashedSet();


        /// <summary>
        /// Initializes a new instance of the <see cref="DecompositionType"/> class.
        /// </summary>
        public DecompositionType()
        {
        }

        /// <summary>
        /// Gets the package type category.
        /// </summary>
        /// <value>The package type category.</value>
        public DecompositionCategory DecompositionCategory
        {
            get { return decompositionCategory; }
            set { decompositionCategory = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="decompositionCategory"></param>
        /// <param name="unitOfMeasurement"></param>
        public DecompositionType(string name, DecompositionCategory decompositionCategory, UnitOfMeasurement unitOfMeasurement)
        {
            if(name==null)
            {
                throw new ArgumentNullException("name");
            }

            if(name.Trim().Length==0)
            {
                throw new ArgumentException("Name cannot be empty.");
            }

            if (decompositionCategory == null)
            {
                throw new ArgumentNullException("decompositionCategory");
            }

            if (unitOfMeasurement == null)
            {
                throw new ArgumentNullException("unitOfMeasurement");
            }

            this.name = name;
            this.decompositionCategory = decompositionCategory;
            this.unitOfMeasurement = unitOfMeasurement;

            decompositionCategory.AddDecompositionType(this);
        }


        public DecompositionType(string name, string gs1Code, string ledgerCode, string otherCode,
            DecompositionCategory decompositionCategory, UnitOfMeasurement unitOfMeasurement)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            if (name.Trim().Length == 0)
            {
                throw new ArgumentException("Name cannot be empty.");
            }

            if (decompositionCategory == null)
            {
                throw new ArgumentNullException("decompositionCategory");
            }

            if (unitOfMeasurement == null)
            {
                throw new ArgumentNullException("unitOfMeasurement");
            }

            this.name = name;
            this.gs1Code = gs1Code;
            this.ledgerCode = ledgerCode;
            this.otherCode = otherCode;
            this.decompositionCategory = decompositionCategory;
            this.unitOfMeasurement = unitOfMeasurement;

            decompositionCategory.AddDecompositionType(this);
        }

        /// <summary>
        /// Gets the name of the packingmaterial.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }


        ///<summary>
        /// Gets or sets Gs1 code
        ///</summary>
        public string Gs1Code
        {
            get { return gs1Code; }
            set { gs1Code = value; }
        }
        ///<summary>
        /// Gets or sets LedgerCode code
        ///</summary>
        public string LedgerCode
        {
            get { return ledgerCode; }
            set { ledgerCode = value; }
        }
        ///<summary>
        /// Gets or sets Other code
        ///</summary>
        public string OtherCode
        {
            get { return otherCode; }
            set { otherCode = value; }
        }

        /// <summary>
        /// Gets the unit of measurement.
        /// </summary>
        /// <value>The unit of measurement.</value>        
        public UnitOfMeasurement UnitOfMeasurement
        {
            get { return unitOfMeasurement; }
            set { unitOfMeasurement = value; }
        }

        #endregion
        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            DecompositionType theOther = obj as DecompositionType;
            if (theOther == null)
            {
                return false;
            }
            if (theOther.name == name)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            int result = name != null ? name.GetHashCode() : 0;
            result = 29 * result + (int)uid;
            result = 29 * result + (decompositionCategory != null ? decompositionCategory.GetHashCode() : 0);
            result = 29 * result + (unitOfMeasurement != null ? unitOfMeasurement.GetHashCode() : 0);
            return result;
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return uid.ToString();
        }

        ///<summary>
        ///</summary>
        ///<param name="langCode"></param>
        ///<returns></returns>
        public string GetName(string langCode)
        {
            DecompositionTypeLang categoryLang = CategoryLangs.Where(it => it.LangCode.Equals(langCode)).SingleOrDefault();

            return categoryLang == null ? Name : categoryLang.Name;
        }

        /// <summary>
        /// Gets or sets the CatTypeLangs.
        /// </summary>
        public IList<DecompositionTypeLang> CategoryLangs
        {
            get { return ListHandler.ConvertToGenericList<DecompositionTypeLang>(decompositionTypeLangs); }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="categoryLang"></param>
        public void AddDecompositionTypeLangToList(DecompositionTypeLang categoryLang)
        {
            decompositionTypeLangs.Add(categoryLang);
        }

        /// <summary>
        /// Remove CategoryLangs
        /// </summary>
        public void RemoveCategoryLangFromList()
        {
            decompositionTypeLangs.Clear();
        }

        /// <summary>
        /// Remove CategoryLangs
        /// </summary>
        public void RemoveCategoryLangFromList(DecompositionTypeLang categoryLang)
        {
            decompositionTypeLangs.Remove(categoryLang);
        }        
    }
}