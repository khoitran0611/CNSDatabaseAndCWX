using System;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// A Generic Range defines a continuous interval between a start and an end of type T.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IRange<T> where T : IComparable<T>
    {
        /// <summary>
        /// Gets the start of the range.
        /// </summary>
        /// <value>The start.</value>
        T Start { get; }

        /// <summary>
        /// Gets the end of the range.
        /// </summary>
        /// <value>The end.</value>
        T End { get; }

        /// <summary>
        /// Determines whether this range contains the specified value to find.
        /// </summary>
        /// <param name="valueToFind">The value to find.</param>
        /// <returns>
        /// 	<c>true</c> if this range contains the specified value to find; otherwise, <c>false</c>.
        /// </returns>
        bool Contains(T valueToFind);

        /// <summary>
        /// Extends the end to the specified further end.
        /// </summary>
        /// <param name="furtherEnd">The further end.</param>
        void Extend(T furtherEnd);
    }
}