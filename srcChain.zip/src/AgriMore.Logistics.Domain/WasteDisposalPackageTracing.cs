﻿using AgriMore.Logistics.Domain.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain
{
    public class WasteDisposalPackageTracing : IIdentifyable
    {
         private long uid;
         private long disposalPackageId;         
         private long childUnpackPackageId;         
         private long parentUnpackPackageId;
        
        /// <summary>
        /// 
        /// </summary>
        public WasteDisposalPackageTracing()
        {
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public long DisposalPackageId
        {
            get { return disposalPackageId; }
            set { disposalPackageId = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public long ChildUnpackPackageId
        {
            get { return childUnpackPackageId; }
            set { childUnpackPackageId = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public long ParentUnpackPackageId
        {
            get { return parentUnpackPackageId; }
            set { parentUnpackPackageId = value; }
        }
             
    }
}
