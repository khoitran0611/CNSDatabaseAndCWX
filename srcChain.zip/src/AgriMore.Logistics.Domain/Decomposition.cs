﻿using AgriMore.Logistics.Domain.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class Decomposition : IIdentifyable
    {
        private long uid;
        private DateTime periodFromDate;
        private string costUnit;

        public string CostUnit
        {
            get { return costUnit; }
            set { costUnit = value; }
        }

        public DateTime PeriodFromDate
        {
            get { return periodFromDate; }
            set { periodFromDate = value; }
        }
        private DateTime periodToDate;

        public DateTime PeriodToDate
        {
            get { return periodToDate; }
            set { periodToDate = value; }
        }
        private decimal cost;

        public decimal Cost
        {
            get { return cost; }
            set { cost = value; }
        }
        private string costCurrency;

        public string CostCurrency
        {
            get { return costCurrency; }
            set { costCurrency = value; }
        }
        private long decompositionTypeId;

        public long DecompositionTypeId
        {
            get { return decompositionTypeId; }
            set { decompositionTypeId = value; }
        }
        private long packageId;

        public long PackageId
        {
            get { return packageId; }
            set { packageId = value; }
        }

        public long NumberPackage { get; set; }

        public long MatchingProdId { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }
    }
}
