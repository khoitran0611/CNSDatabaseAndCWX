using System;
using System.Collections.Generic;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;
using log4net;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// A TransportEquipment is part of a transport chain entity and has the responsibility to pickup and deliver shipments.
    /// A TransportEquipment can transport many shipment at a time. 
    /// A TransportEquipment can be a truck, or any other vessel that can deliver goods.
    /// A TransportEquipment has a location, in which packages can be stored under prescribed and actual conditions.
    /// </summary>
    public class TransportEquipment : IIdentifyable
    {
        private readonly Location location;
        private readonly ILog log = LogManager.GetLogger(typeof (TransportEquipment));
        private readonly ISet shipments = new HashedSet();
        private long uid;

        /// <summary>
        /// Initializes a new instance of the <see cref="TransportEquipment"/> class.
        /// </summary>
        protected TransportEquipment()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TransportEquipment"/> class.
        /// </summary>
        /// <param name="forwarder">The chain entity that transports the shipment. (the shipper).</param>
        /// <param name="location">The forwarder it's own location. Owned by forwarder 
        /// </param>
        public TransportEquipment(ChainEntity forwarder, Location location)
        {
            if (forwarder == null)
            {
                log.Debug("forwarder cannot be null.");
                throw new ArgumentNullException("forwarder");
            }
            if (location == null)
            {
                log.Debug("location cannot be null.");
                throw new ArgumentNullException("location");
            }
            if (!forwarder.Contains(location))
            {
                log.Debug("ChainEntity and Location do not match for the TransportEquipment");
                throw new ArgumentException("ChainEntity and Location do not match for the TransportEquipment");
            }
            this.location = location;
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        #region ITransportEquipment Members



        /// <summary>
        /// Pickups the specified shipment.
        /// </summary>
        /// <param name="shipment">The shipment.</param>
        /// <param name="realDateofPickup">The real dateof pickup.</param>
        /// <param name="realPickUpLocation">The real pick up location.</param>
        /// <param name="exposures">The exposures.</param>
        public void Pickup(Shipment shipment, DateTime realDateofPickup, Location realPickUpLocation, IEnumerable<Exposure> exposures)
        {
            if (shipment == null)
            {
                log.Debug("shipment cannot be null.");
                throw new ArgumentNullException("shipment");
            }

            if (shipments.Contains(shipment))
            {
                log.Debug("Cannot pickup this shipment, the shipment is already in the shipments list");
                throw new ArgumentException("Cannot pickup this shipment, the shipment is already in the shipments list");
            }

            if (realPickUpLocation == null)
            {
                log.Debug("The real pickup Location cannot be null.");
                throw new ArgumentNullException("realPickUpLocation");
            }

            if (exposures == null)
            {
                log.Debug("The exposures cannot be null.");
                throw new ArgumentNullException("exposures");
            }

            if (!shipment.ArePackagesInPickupLocation())
            {
                log.Debug("Cannot pickup shipment, not all packages have arrived at the pickup location");
                throw new ArgumentException(
                    "Cannot pickup shipment, not all packages have arrived at the pickup location");
            }

            shipment.Pickup(realDateofPickup);

            foreach (Package currentPackage in shipment.Packages)
            {
                List<Exposure> clonedExposures = new List<Exposure>();
                foreach (Exposure exposure in exposures)
                {
                    clonedExposures.Add((Exposure)exposure.Clone());
                }

                realPickUpLocation.Move(currentPackage, location, clonedExposures, realDateofPickup);
            }

            shipments.Add(shipment);
        }

        /// <summary>
        /// Delivers the specified real dateof delivery.
        /// </summary>
        /// <param name="toDeliveryShipment">To delivery shipment.</param>
        /// <param name="realDateofDelivery">The real dateof delivery.</param>
        /// <param name="remarks">The remarks.</param>
        /// <param name="realDeliveryLocation">The real delivery location.</param>
        public void Deliver(Shipment toDeliveryShipment, DateTime realDateofDelivery, string remarks, Location realDeliveryLocation)
        {
            if (toDeliveryShipment == null)
            {
                log.Debug("Shipment is null");
                throw new ArgumentNullException("toDeliveryShipment");
            }
            
            if (realDateofDelivery > DateTime.Now)
            {
                log.Debug("Date of delivery needs to be in the past");
                throw new ArgumentException("Date of delivery needs to be in the past");
            }
            if (!shipments.Contains(toDeliveryShipment))
            {
                log.Debug("Cannot deliver shipment, no shipment available");
                throw new ArgumentException("Cannot deliver shipment, no shipment available");
            }
            foreach (Shipment shipment in shipments)
            {
                if (shipment == toDeliveryShipment)
                {
                    foreach (Package currentPackage in shipment.Packages)
                    {
                        location.Remove(currentPackage, realDateofDelivery);
                    }
                    shipment.Deliver(realDateofDelivery, remarks, realDeliveryLocation);
                }
            }

        }

        /// <summary>
        /// Determines whether [contains] [the specified shipment].
        /// </summary>
        /// <param name="specifiedShipment">The specified shipment.</param>
        /// <returns>
        /// 	<c>true</c> if [contains] [the specified shipment]; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(Shipment specifiedShipment)
        {
            foreach (Shipment shipment in shipments)
            {
                if (shipment.Equals(specifiedShipment))
                {
                    return true;
                }
            }
            return false;
        }

        #endregion
    }
}