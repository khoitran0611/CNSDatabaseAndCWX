using System;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// A timeable measurement interface. 
    /// </summary>
    public interface ITimeableMeasurement
    {
        /// <summary>
        /// Gets the date time of measurement.
        /// </summary>
        /// <value>The date time of measurement.</value>
        DateTime DateTimeOfMeasurement { get; }
    }
}