﻿using AgriMore.Logistics.Domain.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgriMore.Logistics.Domain
{
    public class PackagePackagingWasteInfo : IIdentifyable
    {
         private long uid;        
         private long packageId;
         private int typeOfWaste;         
         private string packingWasteDescription;        
        

        /// <summary>
        /// 
        /// </summary>
        public PackagePackagingWasteInfo()
        {
        }

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        public long PackageId
        {
            get { return packageId; }
            set { packageId = value; }
        }



        public string PackingWasteDescription
        {
            get { return packingWasteDescription; }
            set { packingWasteDescription = value; }
        }

        public int TypeOfWaste
        {
            get { return typeOfWaste; }
            set { typeOfWaste = value; }
        }
    }
}
