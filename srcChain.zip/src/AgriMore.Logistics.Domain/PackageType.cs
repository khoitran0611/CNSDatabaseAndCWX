using System;
using AgriMore.Logistics.Domain.Repository;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// This class represents the packing in which a primary product or another package is packed.
    /// The quality factor is delegated to the packingmaterial and returned without any modifications.
    /// A packagetype can be for example a flowpack or a cardboard box.
    /// </summary>
    public class PackageType : IIdentifyable
    {
        private readonly UnitOfMeasurement heightUnitOfMeasurement;
        private readonly int heightValue;
        private readonly bool isSealed;
        private readonly bool isVentilated;
        private readonly UnitOfMeasurement lenghtUnitOfMeasurement;
        private readonly int lenghtValue;

        private readonly string name;
        private readonly PackageTypeCategory packageTypeCategory;
        private readonly PackingMaterial packingMaterial;
        private readonly UnitOfMeasurement weightUnitOfMeasurement;

        private readonly int weightValue;

        private readonly UnitOfMeasurement widthUnitOfMeasurement;
        private readonly int widthValue;
        private long uid;

        /// <summary>
        /// Initializes the <see cref="PackageType"/> class.
        /// </summary>
        static PackageType()
        {
            //Initialize();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PackageType"/> class.
        /// </summary>
        protected PackageType()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PackageType"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="packageTypeCategory">The package type category.</param>
        /// <param name="packingMaterial">The packing material.</param>
        /// <param name="heightMeasurement">The height measurement.</param>
        /// <param name="lenghtMeasurement">The lenght measurement.</param>
        /// <param name="weightMeasurement">The weight measurement.</param>
        /// <param name="widthMeasurement">The width measurement.</param>
        /// <param name="isSealed">if set to <c>true</c> [is sealed].</param>
        /// <param name="isVentilated">if set to <c>true</c> [is ventilated].</param>
        public PackageType(
            string name,
            PackageTypeCategory packageTypeCategory,
            PackingMaterial packingMaterial,
            Measurement heightMeasurement,
            Measurement lenghtMeasurement,
            Measurement widthMeasurement,
            Measurement weightMeasurement,
            bool isSealed,
            bool isVentilated
            )
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            if (packingMaterial == null)
            {
                throw new ArgumentNullException("packingMaterial");
            }

            if (packageTypeCategory == null)
            {
                throw new ArgumentNullException("packageTypeCategory");
            }

            if (name.Trim().Length == 0)
            {
                throw new ArgumentException("PackageType.name cannot be empty.", "name");
            }

            this.name = name;
            this.packingMaterial = packingMaterial;
            this.packageTypeCategory = packageTypeCategory;

            heightUnitOfMeasurement = heightMeasurement.UnitOfMeasurement;
            heightValue = heightMeasurement.Value;

            this.isSealed = isSealed;
            this.isVentilated = isVentilated;
            lenghtUnitOfMeasurement = lenghtMeasurement.UnitOfMeasurement;
            lenghtValue = lenghtMeasurement.Value;
            this.name = name;
            this.packageTypeCategory = packageTypeCategory;
            this.packingMaterial = packingMaterial;
            weightUnitOfMeasurement = weightMeasurement.UnitOfMeasurement;
            weightValue = weightMeasurement.Value;
            widthUnitOfMeasurement = widthMeasurement.UnitOfMeasurement;
            widthValue = widthMeasurement.Value;
        }


        /// <summary>
        /// Gets a value indicating whether this instance is ventilated.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is ventilated; otherwise, <c>false</c>.
        /// </value>
        public bool IsVentilated
        {
            get { return isVentilated; }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is sealed.
        /// </summary>
        /// <value><c>true</c> if this instance is sealed; otherwise, <c>false</c>.</value>
        public bool IsSealed
        {
            get { return isSealed; }
        }

        /// <summary>
        /// Gets the lenght.
        /// </summary>
        /// <value>The lenght.</value>
        public Measurement Lenght
        {
            get { return new Measurement(lenghtUnitOfMeasurement, lenghtValue); }
        }

        /// <summary>
        /// Gets the width.
        /// </summary>
        /// <value>The width.</value>
        public Measurement Width
        {
            get { return new Measurement(widthUnitOfMeasurement, widthValue); }
        }

        /// <summary>
        /// Gets the height.
        /// </summary>
        /// <value>The height.</value>
        public Measurement Height
        {
            get { return new Measurement(heightUnitOfMeasurement, heightValue); }
        }

        /// <summary>
        /// Gets the weight.
        /// </summary>
        /// <value>The weight.</value>
        public Measurement Weight
        {
            get { return new Measurement(weightUnitOfMeasurement, weightValue); }
        }

        /// <summary>
        /// Gets the package type category.
        /// </summary>
        /// <value>The package type category.</value>
        public PackageTypeCategory PackageTypeCategory
        {
            get { return packageTypeCategory; }
        }

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return name; }
        }

        /// <summary>
        /// Gets the packing material.
        /// </summary>
        /// <value>The packing material.</value>
        public PackingMaterial PackingMaterial
        {
            get { return packingMaterial; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            PackageType other = obj as PackageType;
            if (other == null)
            {
                return false;
            }
            if (other.name == name)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return name.GetHashCode() + packageTypeCategory.GetHashCode();
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return uid.ToString();
        }
    }
}