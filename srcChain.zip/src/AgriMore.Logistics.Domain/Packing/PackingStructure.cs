using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace AgriMore.Logistics.Domain.Packing
{
    /// <summary>
    /// The packing structure is a data structure that keeps track of elements in a hierarchical fashion. 
    /// This class specifically exposes the following functions:
    /// 1. Add new elements.
    /// 2. Remove elements.
    /// 3. Rotate elements (needed?)
    /// 4. Serialize from in-memory data structure to readable text.
    /// 5. Deserialize from readable text to in memory data structure.
    /// </summary>
    /// <remarks>
    /// The serialized data is structured as follows:
    /// - Each element has a parent element;
    /// - Each element represents a value Int64;
    /// - When serialized, each element is represented by: "[{parent};{value}]", for example:
    /// Root: [0;1]
    /// Sibling [1;2]
    /// Sibling: [1;3]
    /// Sibling: [2;4]
    /// </remarks>
    public class PackingStructure : IEnumerable<PackingStructureNode>
    {
        private PackingStructureNode root;

        /// <summary>
        /// Initializes a new instance of the <see cref="PackingStructure"/> class.
        /// </summary>
        public PackingStructure()
        {
            root = PackingStructureNode.Empty;
        }

        /// <summary>
        /// Gets the <see cref="AgriMore.Logistics.Domain.Packing.PackingStructureNode"/> with the specified value.
        /// </summary>
        /// <value></value>
        public PackingStructureNode this[long value]
        {
            get
            {
                PackingStructureNode node = TryGetNode(value);
                if (node != null)
                    return node;
                throw new KeyNotFoundException();
            }
        }

        /// <summary>
        /// Gets the count.
        /// </summary>
        /// <value>The count.</value>
        public int Count
        {
            get { return root.IsEmpty ? 0 : (root.Siblings + 1); }
        }

        /// <summary>
        /// Gets the root node.
        /// </summary>
        /// <value>The root.</value>
        public PackingStructureNode Root
        {
            get { return root; }
        }

        #region IEnumerable<PackingStructureNode> Members

        /// <summary>
        /// Returns an enumerator that iterates through the collection.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.Collections.Generic.IEnumerator`1"></see> that can be used to iterate through the collection.
        /// </returns>
        public IEnumerator<PackingStructureNode> GetEnumerator()
        {
            if (root.IsEmpty)
                return null;

            IList<PackingStructureNode> nodes = new List<PackingStructureNode>();
            EnumNodes(nodes, root);
            return nodes.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        #endregion

        /// <summary>
        /// Adds the specified value.
        /// </summary>
        /// <param name="parent">The parent.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public PackingStructureNode Add(long parent, long value)
        {
            if (parent == 0
                && !root.IsEmpty)
                throw new InvalidOperationException("Root node already exists.");

            PackingStructureNode parentNode = null;

            if (parent != 0)
                if (Contains(parent))
                    parentNode = this[parent];

            PackingStructureNode node = new PackingStructureNode(parentNode, value);

            if (parentNode == null)
            {
                root = node;
            }
            else
            {
                parentNode.Nodes.Add(node);
            }

            // rebuild index
            EnsureIndex();

            return node;
        }

        /// <summary>
        /// Determines whether [contains] [the specified value].
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// 	<c>true</c> if [contains] [the specified value]; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(long value)
        {
            PackingStructureNode node = TryGetNode(value);
            return (node != null);
        }

        private PackingStructureNode TryGetNode(long value)
        {
            foreach (PackingStructureNode node in this)
                if (node.Value == value)
                    return node;
            return null;
        }

        /// <summary>
        /// Ensures that the index is built.
        /// </summary>
        public void EnsureIndex()
        {
            int index = 1;
            BuildIndex(root, ref index);
        }

        private void BuildIndex(PackingStructureNode node, ref int index)
        {
            node.Left = index++;
            foreach (PackingStructureNode child in node.Nodes)
            {
                BuildIndex(child, ref index);
            }
            node.Right = index++;
        }

        /// <summary>
        /// Removes the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        public void Remove(long value)
        {
            // rebuild the index
            EnsureIndex();

            PackingStructureNode node = TryGetNode(value);
            if (node == null)
                throw new KeyNotFoundException();

            // remove from parent
            node.Parent.Nodes.Remove(node);

            //int numberOfNodesRemoved = node.Siblings + 1;
            //this.count -= numberOfNodesRemoved;

            // rebuild index
            EnsureIndex();
        }

        /// <summary>
        /// Clears this instance.
        /// </summary>
        public void Clear()
        {
            root = PackingStructureNode.Empty;
        }

        /// <summary>
        /// Enums the node.
        /// </summary>
        /// <param name="nodes">The nodes.</param>
        /// <param name="node">The node.</param>
        private void EnumNodes(IList<PackingStructureNode> nodes, PackingStructureNode node)
        {
            nodes.Add(node);
            foreach (PackingStructureNode child in node.Nodes)
                EnumNodes(nodes, child);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public class PackingStructureNode
    {
        private readonly IList<PackingStructureNode> nodes = new List<PackingStructureNode>();
        private bool isEmpty;
        private bool isRootNode;

        /// <summary>
        /// 
        /// </summary>
        public int Left;

        private PackingStructureNode parent;

        /// <summary>
        /// 
        /// </summary>
        public int Right;

        private long value;

        /// <summary>
        /// Initializes a new instance of the <see cref="PackingStructureNode"/> class.
        /// </summary>
        public PackingStructureNode()
        {
            isRootNode = false;
            isEmpty = false;
            parent = null;
            value = 0;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PackingStructureNode"/> class.
        /// </summary>
        /// <param name="parent">The parent.</param>
        /// <param name="value">The value.</param>
        public PackingStructureNode(PackingStructureNode parent, long value)
        {
            isRootNode = (parent == null);
            isEmpty = false;
            this.parent = parent;
            this.value = value;
        }

        /// <summary>
        /// Gets the root node.
        /// </summary>
        /// <value>The root.</value>
        public static PackingStructureNode Root
        {
            get
            {
                PackingStructureNode n = new PackingStructureNode();
                n.isRootNode = true;
                return n;
            }
        }

        /// <summary>
        /// Gets an empty node.
        /// </summary>
        /// <value>The empty.</value>
        public static PackingStructureNode Empty
        {
            get
            {
                PackingStructureNode n = new PackingStructureNode();
                n.isEmpty = true;
                return n;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is the root node.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is root node; otherwise, <c>false</c>.
        /// </value>
        public bool IsRootNode
        {
            get { return isRootNode; }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is empty.
        /// </summary>
        /// <value><c>true</c> if this instance is empty; otherwise, <c>false</c>.</value>
        public bool IsEmpty
        {
            get { return isEmpty; }
        }

        /// <summary>
        /// Gets the parent.
        /// </summary>
        /// <value>The parent.</value>
        public PackingStructureNode Parent
        {
            get { return parent; }
        }

        /// <summary>
        /// Gets the (child) nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public IList<PackingStructureNode> Nodes
        {
            get { return nodes; }
        }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        public long Value
        {
            get { return value; }
            set { this.value = value; }
        }

        /// <summary>
        /// Gets the total number of siblings below this node.
        /// </summary>
        /// <value>The siblings.</value>
        public int Siblings
        {
            get { return (((Right - Left) - 1)/2); }
        }

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            if (obj is PackingStructureNode)
            {
                PackingStructureNode other = (PackingStructureNode) obj;
                return (other.isEmpty == true && isEmpty == true)
                       || (other.isRootNode == true && isRootNode == true)
                       || (other.value == value);
            }
            return false;
        }

        /// <summary>
        /// Serves as a hash function for a particular type. <see cref="M:System.Object.GetHashCode"></see> is suitable for use in hashing algorithms and data structures like a hash table.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return string.Format("{0}", value);
        }
    }


    /// <summary>
    /// Serializes and deserializes a packingstructure.
    /// </summary>
    public class PackingStructureFormatter
    {
        ///// <summary>
        ///// Initializes a new instance of the <see cref="PackingStructureFormatter"/> class.
        ///// </summary>
        //public PackingStructureFormatter()
        //{
        //}

        /// <summary>
        /// Serializes the specified packing structure.
        /// </summary>
        /// <param name="packingStructure">The packing structure.</param>
        /// <returns></returns>
        public string Serialize(PackingStructure packingStructure)
        {
            StringBuilder sb = new StringBuilder();
            using (StringWriter s = new StringWriter(sb))
            {
                Write(s, packingStructure);
                s.Flush();
                s.Close();
            }
            return sb.ToString();
        }

        /// <summary>
        /// Writes the specified writer.
        /// </summary>
        /// <param name="writer">The writer.</param>
        /// <param name="packingStructure">The packing structure.</param>
        public void Write(TextWriter writer, PackingStructure packingStructure)
        {
            if (packingStructure.Root.IsEmpty)
                return;

            //packingStructure.EnsureIndex();

            foreach (PackingStructureNode node in packingStructure)
                writer.Write("[{0};{1}]", node.IsRootNode ? 0 : node.Parent.Value, node.Value);
        }

        /// <summary>
        /// Deserializes the specified text.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns></returns>
        public PackingStructure Deserialize(string text)
        {
            PackingStructure packingStructure = new PackingStructure();
            IEnumerable<string> nodeTexts = ParseLevel1(text);
            foreach (string nodeText in nodeTexts)
            {
                long parent;
                long value;
                if (ParseLevel2(nodeText, out parent, out value))
                    packingStructure.Add(parent, value);
            }
            return packingStructure;
        }

        private IEnumerable<string> ParseLevel1(string text)
        {
            if (text.StartsWith("[")
                && text.EndsWith("]"))
            {
                text = text.Remove(0, 1);
                text = text.Remove(text.Length - 1, 1);
                string[] nodes = text.Split(new string[] {"]["}, StringSplitOptions.RemoveEmptyEntries);

                foreach (string node in nodes)
                    yield return node;
            }
        }

        private bool ParseLevel2(string text, out long parent, out long value)
        {
            parent = 0;
            value = 0;

            if (string.IsNullOrEmpty(text))
                return false;

            string[] parts = text.Split(new char[] {';'});
            if (parts.Length == 2)
            {
                if (!long.TryParse(parts[0], out parent))
                    return false;
                if (!long.TryParse(parts[1], out value))
                    return false;
            }

            return true;
        }
    }
}