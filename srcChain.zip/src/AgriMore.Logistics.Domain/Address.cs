using System;
using System.Collections.Generic;
using System.Text;
using AgriMore.Logistics.Domain.Repository;
using Iesi.Collections;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// An address contains address information.
    /// </summary>
    public class Address : IComparable<Address>, IIdentifyable
    {
        private long uid;
        private readonly string streetName;
        private readonly string streetNumber;
        private readonly string zipCode;
        private readonly string numberExtension;
        private readonly string stateProvence;
        private readonly string city;
        private readonly string telephone;
        private readonly Country country;
        private readonly string fax;
        private readonly string email;
        private readonly AgriMoreTimeZone timeZone;
        private readonly ISet locations = new HashedSet();
        private readonly ISet cashRegisters = new HashedSet();

        /// <summary>
        /// Gets the name of the street.
        /// </summary>
        /// <value>The name of the street.</value>
        public string StreetName
        {
            get { return streetName; }
        }

        /// <summary>
        /// Gets the street number.
        /// </summary>
        /// <value>The street number.</value>
        public string StreetNumber
        {
            get { return streetNumber; }
        }

        /// <summary>
        /// Gets the zip code.
        /// </summary>
        /// <value>The zip code.</value>
        public string ZipCode
        {
            get { return zipCode; }
        }

        /// <summary>
        /// Gets the number extension.
        /// </summary>
        /// <value>The number extension.</value>
        public string NumberExtension
        {
            get { return numberExtension; }
        }

        /// <summary>
        /// Gets the state provence.
        /// </summary>
        /// <value>The state provence.</value>
        public string StateProvence
        {
            get { return stateProvence; }
        }

        /// <summary>
        /// Gets the time zone.
        /// </summary>
        /// <value>The time zone.</value>
        public AgriMoreTimeZone TimeZone
        {
            get { return timeZone; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Address"/> class.
        /// </summary>
        protected Address()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Address"/> class.
        /// </summary>
        /// <param name="city">The city.</param>
        /// <param name="country">The country.</param>
        /// <param name="email">The email.</param>
        /// <param name="fax">The fax.</param>
        /// <param name="numberExtension">The number extension.</param>
        /// <param name="stateProvence">The state provence.</param>
        /// <param name="streetName">Name of the street.</param>
        /// <param name="streetNumber">The street number.</param>
        /// <param name="telephone">The telephone.</param>
        /// <param name="timeZone">The time zone.</param>
        /// <param name="zipCode">The zip code.</param>
        public Address(string city, Country country, string email, string fax, string numberExtension, string
            stateProvence, string streetName, string streetNumber, string telephone, AgriMoreTimeZone timeZone, string zipCode)
        {
            
            if (city == null) throw new ArgumentNullException("city");
            if (country == null) throw new ArgumentNullException("country");
            if (email == null) throw new ArgumentNullException("email");
            if (fax == null) throw new ArgumentNullException("fax");
            if (numberExtension == null) throw new ArgumentNullException("numberExtension");
            if (stateProvence == null) throw new ArgumentNullException("stateProvence");
            if (streetName == null) throw new ArgumentNullException("streetName");
            if (streetNumber == null) throw new ArgumentNullException("streetNumber");
            if (telephone == null) throw new ArgumentNullException("telephone");
            if (timeZone == null) throw new ArgumentNullException("timeZone");
            if (zipCode == null) throw new ArgumentNullException("zipCode");
            
            this.city = city;
            this.country = country;
            this.email = email;
            this.fax = fax;
            this.numberExtension = numberExtension;
            this.stateProvence = stateProvence;
            this.streetName = streetName;
            this.streetNumber = streetNumber;
            this.telephone = telephone;
            this.timeZone = timeZone;
            this.zipCode = zipCode;
        }

        ///// <summary>
        ///// Initializes a new instance of the <see cref="Address"/> class.
        ///// </summary>
        ///// <param name="city">The city.</param>
        ///// <param name="country">The country.</param>
        ///// <param name="email">The email.</param>
        ///// <param name="fax">The fax.</param>
        ///// <param name="numberExtension">The number extension.</param>
        ///// <param name="stateProvence">The state provence.</param>
        ///// <param name="streetName">Name of the street.</param>
        ///// <param name="streetNumber">The street number.</param>
        ///// <param name="telephone">The telephone.</param>
        ///// <param name="timeZone">The time zone.</param>
        ///// <param name="zipCode">The zip code.</param>
        ///// <param name="locations">The locations.</param>
        ///// <param name="cashRegisters">The cash registers.</param>
        //public Address(string city, Country country, string email, string fax, string numberExtension, string
        //stateProvence, string streetName, string streetNumber, string telephone, AgriMoreTimeZone timeZone, string zipCode, IEnumerable<Location> locations, IEnumerable<CashRegister> cashRegisters)
        //    :this( city,  country,  email,  fax,  numberExtension, 
        //stateProvence,  streetName,  streetNumber,  telephone,  timeZone,  zipCode)
        //{
        //    this.locations.AddAll(new List<Location>(locations));
        //    this.cashRegisters.AddAll(new List<CashRegister>(cashRegisters));
        //}

        /// <summary>
        /// Gets the locations.
        /// </summary>
        /// <value>The locations.</value>
        public IEnumerable<Location> Locations
        {
            get
            {
                foreach (Location location in locations)
                {
                    yield return location;
                }
            }
        }

        /// <summary>
        /// Gets the cash registers.
        /// </summary>
        /// <value>The cash registers.</value>
        public IEnumerable<CashRegister> CashRegisters
        {
            get
            {
                foreach (CashRegister register in cashRegisters)
                {
                    yield return register;
                }
            }
        }

        /// <summary>
        /// Gets the city.
        /// </summary>
        /// <value>The city.</value>
        public string City
        {
            get { return city; }
        }

        /// <summary>
        /// Gets the country.
        /// </summary>
        /// <value>The country.</value>
        public Country Country
        {
            get { return country; }
        }

        /// <summary>
        /// Gets the email.
        /// </summary>
        /// <value>The email.</value>
        public string Email
        {
            get { return email; }
        }

        /// <summary>
        /// Gets the fax.
        /// </summary>
        /// <value>The fax.</value>
        public string Fax
        {
            get { return fax; }
        }

        /// <summary>
        /// Gets the telephone.
        /// </summary>
        /// <value>The telephone.</value>
        public string Telephone
        {
            get { return telephone; }
        }

        #region IComparable<Address> Members

        /// <summary>
        /// Compares the current object with another object of the same type.
        /// </summary>
        /// <param name="other">An object to compare with this object.</param>
        /// <returns>
        /// A 32-bit signed integer that indicates the relative order of the objects being compared. The return value has the following meanings: Value Meaning Less than zero This object is less than the other parameter.Zero This object is equal to other. Greater than zero This object is greater than other.
        /// </returns>
        public int CompareTo(Address other)
        {
            Address otherAddress = other;
            if (otherAddress == null)
            {
                // im bigger than null
                return 1;
            }
            return StringRepresentation.CompareTo(otherAddress.ToString());
        }

        #endregion

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion


        /// <summary>
        /// Gets the string representation.
        /// </summary>
        /// <value>The string representation.</value>
        private string StringRepresentation
        {
            get
            {
                StringBuilder builder = new StringBuilder();
                builder.AppendLine(streetName);
                if (streetNumber != null)
                {
                    builder.AppendLine(streetNumber);
                }
                builder.Append(zipCode);
                builder.Append(" ");
                builder.AppendLine(city);
                if (numberExtension != null)
                {
                    builder.AppendLine(numberExtension);
                }
                builder.AppendLine(country.Name);
                return builder.ToString();
            }
        }

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            Address other = obj as Address;
            if (other == null)
            {
                return false;
            }

            if (Uid != 0)
            {
                return (Uid == other.Uid);
            }

            return StringRepresentation.Equals(other.ToString());
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return StringRepresentation;
        }

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return StringRepresentation.GetHashCode();
        }

        /// <summary>
        /// Adds the cash register.
        /// </summary>
        /// <param name="cashRegister">The cash register.</param>
        public void AddCashRegister(CashRegister cashRegister)
        {
            if (cashRegister == null)
            {
                throw new ArgumentNullException("cashRegister");
            }

            if (cashRegisters.Contains(cashRegister))
            {
                throw new ArgumentException(String.Format("CashRegister [{0}] already exists at address", cashRegister.Name), "cashRegister");
            }

            cashRegisters.Add(cashRegister);
        }

        /// <summary>
        /// Adds the location.
        /// </summary>
        /// <param name="location">The location.</param>
        public void AddLocation(Location location)
        {
            if (location == null)
            {
                throw new ArgumentNullException("location");
            }
            locations.Add(location);
            location.Address = this;
        }
    }


    /// <summary>
    /// 
    /// </summary>
    public class AgriMoreTimeZone : AbstractKeyNameType
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AgriMoreTimeZone"/> class.
        /// </summary>
        protected AgriMoreTimeZone()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AgriMoreTimeZone"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public AgriMoreTimeZone(string name)
            : base(name)
        {
        }
    }
}