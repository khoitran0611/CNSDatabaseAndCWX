using System;
using AgriMore.Logistics.Domain.Repository;
using log4net;

namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Treatment class have the responcibility to treat a primary product or a sfp.
    /// </summary>
    public class Treatment : IIdentifyable
    {
        private readonly DateTime durationDateTimeEnd;
        private readonly DateTime durationDateTimeStart;
        private readonly ILog log = LogManager.GetLogger(typeof (Treatment));
        private readonly Domain.TreatmentType treatmentType;
        private double value;
        private decimal cost;        
        private string costCurrency;        
        private string costUnit;
        
        private readonly int hashcode = Guid.NewGuid().GetHashCode();
        private long uid;


        /// <summary>
        /// Initializes a new instance of the <see cref="Treatment"/> class.
        /// </summary>
        protected Treatment()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Treatment"/> class.
        /// </summary>
        /// <param name="treatmentType">Type of the treatment.</param>
        /// <param name="duration">The treatment start end.</param>
        /// <param name="value">The value.</param>
        public Treatment(TreatmentType treatmentType, IRange<DateTime> duration, double value, decimal cost, string currency, string costUnit)
        {
            if (treatmentType == null)
            {
                log.Debug("treatmentType cannot be null.");
                throw new ArgumentNullException("treatmentType");
            }

            if (duration == null)
            {
                log.Debug("duration cannot be null.");
                throw new ArgumentNullException("duration");
            }

            durationDateTimeStart = duration.Start;
            durationDateTimeEnd = duration.End;
            this.treatmentType = treatmentType;
            this.value = value;
            this.cost = cost;
            this.costCurrency = currency;
            this.costUnit = costUnit;
        }

        /// <summary>
        /// Gets the type of the treatment.
        /// </summary>
        /// <value>The type of the treatment.</value>
        public Domain.TreatmentType TreatmentType
        {
            get { return treatmentType; }
        }

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return treatmentType.Name; }
        }

        /// <summary>
        /// Gets the start end.
        /// </summary>
        /// <value>The start end.</value>
        public IRange<DateTime> Duration
        {
            get { return new Range<DateTime>(durationDateTimeStart, durationDateTimeEnd); }
        }

        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <value>The value.</value>
        public double Value
        {
            get { return value; }
            set { this.value = value; }
        }

        public decimal Cost
        {
            get { return cost; }
            set { cost = value; }
        }

        public string CostCurrency
        {
            get { return costCurrency; }
            set { costCurrency = value; }
        }

        public string CostUnit
        {
            get { return costUnit; }
            set { costUnit = value; }
        }

        #region IIdentifyable Members

        /// <summary>
        /// Gets or sets the uid.
        /// </summary>
        /// <value>The uid.</value>
        public long Uid
        {
            get { return uid; }
            set { uid = value; }
        }

        #endregion

        /// <summary>
        /// Serves as a hash function for a particular type.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return hashcode;
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            return uid.ToString();
        }


        /// <summary>
        /// Equalses the specified treatment.
        /// </summary>
        /// <param name="other">The other.</param>
        /// <returns></returns>
        public override bool Equals(Object other)
        {
            Treatment treatment = other as Treatment;

            if (treatment == null) return false;

            return treatment.GetHashCode() == hashcode;
        }
    }
}