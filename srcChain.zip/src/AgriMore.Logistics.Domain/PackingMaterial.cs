namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Packing material is what a packagetype is made of.
    /// A packing material for example can be plastic and the material has a influence on the quality on whatever 
    /// is packed in it. So it implements quality IQualityFactorElement for the factor.
    /// </summary>
    public class PackingMaterial : AbstractKeyNameType
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PackingMaterial"/> class.
        /// </summary>
        protected PackingMaterial()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PackingMaterial"/> struct.
        /// </summary>
        /// <param name="name">The name.</param>
        public  PackingMaterial(string name)
            : base(name)
        {
        }
    }
}