namespace AgriMore.Logistics.Domain
{
    /// <summary>
    /// Role class represents a role that is referenced by a ChainUser.
    /// </summary>
    public class Role : AbstractKeyNameType
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Role"/> class.
        /// </summary>
        protected Role()
        {
        }

        static Role()
        {
            Initialize();
        }

        /// <summary>
        /// Initializes this instance.
        /// </summary>
        public static void Initialize()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Role"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public Role(string name)
            : base(name)
        {
        }
    }
}