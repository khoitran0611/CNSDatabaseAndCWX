//using System;
//using AgriMore.Logistics.Domain.Repository;

//namespace AgriMore.Logistics.Domain
//{
//    /// <summary>
//    ///  The ProofOfDelivery contains all need informations about the deliver
//    ///
//    /// </summary>
//    public class ProofOfDelivery : IIdentifyable
//    {
//        private readonly DateTime deliveryDateTime;
//        private readonly Location location;
//        private long uid;

//        /// <summary>
//        /// Gets or sets the delivery date time.
//        /// </summary>
//        /// <value>The delivery date time.</value>
//        public DateTime DeliveryDateTime
//        {
//            get { return deliveryDateTime; }
//        }

//        /// <summary>
//        /// Gets or sets the location.
//        /// </summary>
//        /// <value>The location.</value>
//        public Location Location
//        {
//            get { return location; }
//        }
        
//        /// <summary>
//        /// Initializes a new instance of the <see cref="ProofOfDelivery"/> class.
//        /// </summary>
//        protected ProofOfDelivery()
//        {
//        }



//        /// <summary>
//        /// Initializes a new instance of the <see cref="ProofOfDelivery"/> class.
//        /// </summary>
//        /// <param name="deliveryDateTime">The delivery date time.</param>
//        /// <param name="location">The location.</param>
//        public ProofOfDelivery(DateTime deliveryDateTime, Location location)
//        {
//            if (location == null)
//                throw new ArgumentNullException("location");

//            this.deliveryDateTime = deliveryDateTime;
//            this.location = location;
//        }

//        #region IIdentifyable Members

//        /// <summary>
//        /// Gets or sets the uid.
//        /// </summary>
//        /// <value>The uid.</value>
//        public long Uid
//        {
//            get { return uid; }
//            set { uid = value; }
//        }

//        #endregion
//    }
//}