using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using MySql.Data.MySqlClient;
using NUnit.Framework;

namespace AgriMore.Logistics.Data.Specs
{
    /// <summary>
    /// 
    /// </summary>
    [TestFixture]
    public class DatabaseTest
    {
        private const string conString =
            "Data Source = localhost; User ID = root; Password = miccSOE;";

        private const string DDLSCRIPT = @"..\..\..\MySql\database_script.sql";

        private const string conStringAgrimore =
            "Data Source = localhost; Database = agrimore_logistics; User ID = root; Password = miccSOE;";

        /// <summary> 
        /// Gets the connection string.
        /// </summary>
        /// <value>The connection string.</value>
        public static string ConnectionString
        {
            get { return conStringAgrimore; }
        }

        /// <summary>
        /// Creates an open database connection.
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        /// <returns></returns>
        private static IDbConnection CreateOpenConnection(string connectionString)
        {
            IDbConnection con = new MySqlConnection(connectionString);
            con.Open();
            return con;
        }

        /// <summary>
        /// Rebuilds the database.
        /// </summary>
        //[Test]
        internal static void RebuildDatabase()
        {
            //bool result;
            FileInfo fi = new FileInfo(DDLSCRIPT);
            if (fi.Exists)
            {
                Console.WriteLine("Rebuilding database from: {0}", fi.FullName);
                using (IDbConnection con = CreateOpenConnection(conString))
                {
                    ExecCommand(con, "drop database if exists agrimore_logistics");
                    IEnumerable<string> commands = ReadDDL(fi.FullName);
                    foreach (string commandText in commands)
                    {
                        ExecCommand(con, commandText);
                    }
                    //result = true;
                    con.Close();
                }
                Console.WriteLine("Rebuilding database: Done.");
            }
            else
            {
                throw new FileNotFoundException("Cannot find the DDL file to rebuild the database.", fi.FullName);
            }
            //Assert.IsTrue(result, "Cannot rebuild database.");
        }

        internal static void ExecDDL(string file)
        {
            //bool result;
            FileInfo fi = new FileInfo(file);
            if (fi.Exists)
            {
                Console.WriteLine("Executing DDL script: {0}", fi.FullName);
                using (IDbConnection con = CreateOpenConnection(conString))
                {
                    IEnumerable<string> commands = ReadDDL(fi.FullName);
                    foreach (string commandText in commands)
                    {
                        ExecCommand(con, commandText);
                    }
                    //result = true;
                    con.Close();
                }
                Console.WriteLine("Execute DDL script: Done.");
            }
            else
            {
                throw new FileNotFoundException(string.Format("Cannot find the DDL file: {0}", fi.FullName), fi.FullName);
            }
            //Assert.IsTrue(result, "Cannot rebuild database.");
        }

        private static int ExecCommand(IDbConnection con, string commandText)
        {
            using (IDbCommand command = con.CreateCommand())
            {
                command.CommandType = CommandType.Text;
                command.CommandText = commandText;
                return command.ExecuteNonQuery();
            }
        }

        private static IEnumerable<string> ReadDDL(string file)
        {
            FileInfo fi = new FileInfo(file);
            Assert.IsTrue(fi.Exists, string.Format("File '{0}' not found.", file));

            using (StreamReader s = new StreamReader(fi.FullName))
            {
                string line = string.Empty;
                while (!s.EndOfStream)
                {
                    line += s.ReadLine();
                    if (line != null)
                    {
                        line = line.Trim();
                        if (line.EndsWith(";"))
                        {
                            yield return line;
                            line = string.Empty;
                        }
                        else
                        {
                            line += " ";
                        }
                    }
                }
                s.Close();
            }
        }



        /// <summary>
        /// Tests the connection.
        /// </summary>
        [Test]
        public void TestConnection()
        {
            bool canReadFromDatabase = false;
            using (IDbConnection con = CreateOpenConnection(conString))
            {
                IDbCommand command = con.CreateCommand();
                command.CommandText = "show databases";
                using (IDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string dbName = reader.GetString(0);
                        Console.WriteLine("TestConnection found database: {0}", dbName);
                        if (!canReadFromDatabase)
                            canReadFromDatabase = true;
                    }
                    reader.Close();
                }
            }
            Assert.IsTrue(canReadFromDatabase, "Cannot read from database.");
        }




    }
}
