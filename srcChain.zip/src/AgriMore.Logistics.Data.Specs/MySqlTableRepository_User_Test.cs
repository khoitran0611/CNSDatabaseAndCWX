//using AgriMore.Logistics.Data.MySql.Repository;
//using AgriMore.Logistics.Domain;
//using AgriMore.Logistics.Domain.Repository;
//using AgriMore.Logistics.Domain.Specification;
//using NUnit.Framework;

//namespace AgriMore.Logistics.Data.Specs
//{
//    /// <summary>
//    /// Tests the my sql table repository
//    /// </summary>
//    [TestFixture]
//    public class MySqlTableRepository_User_Test
//    {
//        #region Setup/Teardown

//        /// <summary>
//        /// Setup of testfixture.
//        /// </summary>
//        [SetUp]
//        public void Setup()
//        {
//            // TODO: fix the DDL file location for server! (unit test currently fails)
//            //DatabaseTest.RebuildDatabase();

//            // create roles
//            DatabaseTest.ExecDDL(@"..\..\src\MySql\test_user.sql");
//        }

//        /// <summary>
//        /// Cleanup of testfixture.
//        /// </summary>
//        [TearDown]
//        public void TearDown()
//        {
//            // TODO: fix the DDL file location for server! (unit test currently fails)
//            //DatabaseTest.RebuildDatabase();
//        }

//        #endregion

//        /// <summary>
//        /// Tests:
//        /// - Add(Element)
//        /// - GetOne(id)
//        /// - GetOne(uid)
//        /// - Remove(Element)
//        /// </summary>
//        [Test]
//        public void Test_User_AddGetRemove()
//        {
//            IRepository<User> repUser = new MySqlChainUserRepository();
//            IRepository<Role> repRole = new MySqlChainRoleRepository();

//            User m =
//                new User("user1", "pass1", "George", "Bush",
//                         new Role[] { repRole.GetOne("President"), repRole.GetOne("Republican") });

//            long uid = repUser.Add(m);

//            Assert.AreNotEqual(0, uid);
//            Assert.AreNotEqual(0, m.Uid);
//            User foundByName = repUser.GetOne("user1");
//            Assert.AreEqual(m, foundByName);
//            User foundByUid = repUser.GetOne(uid);
//            Assert.AreEqual(m, foundByUid);
//            Assert.IsTrue(repUser.Remove(m));
//        }

//        /// <summary>
//        /// Tests:
//        /// - Add(Element)
//        /// - AsCollection()
//        /// - GetEnumerator()
//        /// - Find(ISpecification)
//        /// - Count()
//        /// - Count(ISpecification)
//        /// - Remove(ISpecification)
//        /// </summary>
//        [Test]
//        public void Test_User_CollectionEnumerableCountRemoveSpecs()
//        {
//            IRepository<User> repUser = new MySqlChainUserRepository();
//            IRepository<Role> repRole = new MySqlChainRoleRepository();
//            User bush =
//                new User("user1", "pass1", "George", "Bush",
//                         new Role[] { repRole.GetOne("President"), repRole.GetOne("Republican") });
//            User clinton =
//                new User("user2", "pass2", "Bill", "Clinton",
//                         new Role[] { repRole.GetOne("President"), repRole.GetOne("Democrat") });
//            repUser.Add(bush);
//            repUser.Add(clinton);
//            Assert.AreEqual(2, repUser.Count());
//            int i = 0;
//            foreach (User user in repUser)
//            {
//                if (user.Username == bush.Username)
//                {
//                    i++;
//                }
//                if (user.Username == clinton.Username)
//                {
//                    i++;
//                }
//            }
//            Assert.AreEqual(2, i);
//            i = 0;
//            foreach (User user in repUser.Find(new AllSpecification<User>()))
//            {
//                if (user.Username == bush.Username)
//                {
//                    i++;
//                }
//                if (user.Username == clinton.Username)
//                {
//                    i++;
//                }
//            }
//            Assert.AreEqual(2, i);
//            Assert.AreEqual(2, repUser.Count(new AllSpecification<User>()));
//            repUser.Remove(new AllSpecification<User>());
//            Assert.AreEqual(0, repUser.Count(new AllSpecification<User>()));
//        }

//        /// <summary>
//        /// Tests:
//        /// - Store(Element)
//        /// - Remove(Element)
//        /// - Add(Element)
//        /// - GetOne(uid)
//        /// </summary>
//        [Test]
//        public void Test_User_Store()
//        {
//            IRepository<User> repUser = new MySqlChainUserRepository();
//            IRepository<Role> repRole = new MySqlChainRoleRepository();

//            User m =
//                new User("user1", "pass1", "George", "Bush",
//                         new Role[] { repRole.GetOne("President"), repRole.GetOne("Republican") });
//            repUser.Store(m);
//            Assert.AreNotEqual(0, m.Uid);
//            Assert.IsTrue(repUser.Remove(m));
//            m.Uid = 0;
//            repUser.Add(m);
//            Assert.AreNotEqual(0, m.Uid);
//            repUser.Store(m);
//            //
//            //m.Username = "user3";
//            Assert.AreNotEqual(m, repUser.GetOne(m.Uid));
//            long id = m.Uid;
//            repUser.Store(m);
//            Assert.AreEqual(id, m.Uid);
//            Assert.AreEqual(m, repUser.GetOne(m.Uid));
//            Assert.IsTrue(repUser.Remove(m));
//        }
//    }
//}