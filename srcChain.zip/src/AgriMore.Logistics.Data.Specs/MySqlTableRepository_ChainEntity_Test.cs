//using AgriMore.Logistics.Data.MySql.Repository;
//using AgriMore.Logistics.Domain;
//using AgriMore.Logistics.Domain.Repository;
//using AgriMore.Logistics.Domain.Specification;
//using NUnit.Framework;

//namespace AgriMore.Logistics.Data.Specs
//{
//    /// <summary>
//    /// Tests the my sql table repository
//    /// </summary>
//    [TestFixture]
//    public class MySqlTableRepository_ChainEntity_Test
//    {
//        /// <summary>
//        /// Setup of testfixture.
//        /// </summary>
//        [SetUp]
//        public void Setup()
//        {
//            // TODO: fix the DDL file location for server! (unit test currently fails)
//            //DatabaseTest.RebuildDatabase();

//            // create roles
//            DatabaseTest.ExecDDL(@"..\..\src\MySql\test_chainentity.sql");
//        }

//        /// <summary>
//        /// Cleanup of testfixture.
//        /// </summary>
//        [TearDown]
//        public void TearDown()
//        {
//            // TODO: fix the DDL file location for server! (unit test currently fails)
//            //DatabaseTest.RebuildDatabase();
//        }

//        /// <summary>
//        /// Tests:
//        /// - Add(Element)
//        /// - GetOne(id)
//        /// - GetOne(uid)
//        /// - Remove(Element)
//        /// </summary>
//        //[Test]
//        //public void Test_ChainEntity_AddGetRemove()
//        //{
//        //    IRepository<ChainEntity> rep = new MySqlChainEntityRepository();
//        //    IRepository<Country> repCountry = new MySqlCountryRepository();
//        //    //IRepository<ExposureDocument> repExposureDocument = new MySqlExposureDocumentRepository();

//        //    ChainEntity chainEntity = new ChainEntity("Entity 1");
//        //    Country country = repCountry.GetOne("Country");
//        //    Address address = new Address("Street 1", "1234 AB", "City", country, "Suburb 1", "Subdivision", chainEntity);
//        //    //Location location = new Location("Location 1", "LocationType 1", address);

//        //    long uid = rep.Add(chainEntity);
//        //    Assert.AreNotEqual(0, uid);
//        //    Assert.AreNotEqual(0, chainEntity.Uid);
//        //    ChainEntity foundByName = rep.GetOne("Entity 1");
//        //    Assert.AreEqual(chainEntity, foundByName);
//        //    ChainEntity foundByUid = rep.GetOne(uid);
//        //    Assert.AreEqual(chainEntity, foundByUid);
//        //    Assert.IsTrue(rep.Remove(chainEntity));
//        //}

//        /// <summary>
//        /// Tests:
//        /// - Store(Element)
//        /// - Remove(Element)
//        /// - Add(Element)
//        /// - GetOne(uid)
//        /// </summary>
//        //[Test]
//        //public void Test_ChainEntity_Store()
//        //{
//        //    //IRepository<User> repUser = new MySqlChainUserRepository();
//        //    //IRepository<Role> repRole = new MySqlChainRoleRepository();
//        //    //User m = new User("user1", "pass1", "George", "Bush", new Role[] { repRole.GetOne("President"), repRole.GetOne("Republican") });
//        //    //repUser.Store(m);
//        //    //Assert.AreNotEqual(0, m.Uid);
//        //    //Assert.IsTrue(repUser.Remove(m));
//        //    //m.Uid = 0;
//        //    //repUser.Add(m);
//        //    //Assert.AreNotEqual(0, m.Uid);
//        //    //repUser.Store(m);
//        //    //m.Username = "user3";
//        //    //Assert.AreNotEqual(m, repUser.GetOne(m.Uid));
//        //    //long id = m.Uid;
//        //    //repUser.Store(m);
//        //    //Assert.AreEqual(id, m.Uid);
//        //    //Assert.AreEqual(m, repUser.GetOne(m.Uid));
//        //    //Assert.IsTrue(repUser.Remove(m));
//        //}

//        /// <summary>
//        /// Tests:
//        /// - Add(Element)
//        /// - AsCollection()
//        /// - GetEnumerator()
//        /// - Find(ISpecification)
//        /// - Count()
//        /// - Count(ISpecification)
//        /// - Remove(ISpecification)
//        /// </summary>
//        [Test]
//        public void Test_ChainEntity_CollectionEnumerableCountRemoveSpecs()
//        {
//            //IRepository<User> repUser = new MySqlChainUserRepository();
//            //IRepository<Role> repRole = new MySqlChainRoleRepository();
//            //User bush = new User("user1", "pass1", "George", "Bush", new Role[] { repRole.GetOne("President"), repRole.GetOne("Republican") });
//            //User clinton = new User("user2", "pass2", "Bill", "Clinton", new Role[] { repRole.GetOne("President"), repRole.GetOne("Democrat") });
//            //repUser.Add(bush);
//            //repUser.Add(clinton);
//            //Assert.AreEqual(2, repUser.Count());
//            //int i = 0;
//            //foreach (User user in repUser)
//            //{
//            //    if (user.Username == bush.Username)
//            //    {
//            //        i++;
//            //    }
//            //    if (user.Username == clinton.Username)
//            //    {
//            //        i++;
//            //    }
//            //}
//            //Assert.AreEqual(2, i);
//            //i = 0;
//            //foreach (User user in repUser.Find(new AllSpecification<User>()))
//            //{
//            //    if (user.Username == bush.Username)
//            //    {
//            //        i++;
//            //    }
//            //    if (user.Username == clinton.Username)
//            //    {
//            //        i++;
//            //    }
//            //}
//            //Assert.AreEqual(2, i);
//            //Assert.AreEqual(2, repUser.Count(new AllSpecification<User>()));
//            //repUser.Remove(new AllSpecification<User>());
//            //Assert.AreEqual(0, repUser.Count(new AllSpecification<User>()));
//        }
//    }
//}
