SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';
USE `agrimore_logistics`;
TRUNCATE TABLE `address`;
TRUNCATE TABLE `chainentity`;
TRUNCATE TABLE `country`;
INSERT INTO `country` (`name`) VALUES ('Country');
INSERT INTO `country` (`name`) VALUES ('Nederland');
