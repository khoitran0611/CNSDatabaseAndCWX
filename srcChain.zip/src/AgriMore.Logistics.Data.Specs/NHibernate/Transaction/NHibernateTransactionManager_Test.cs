using System;
using AgriMore.Logistics.Data.NHibernate.Repository;
using AgriMore.Logistics.Data.NHibernate.Transaction;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Transaction;
using NUnit.Framework;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Transaction
{
    /// <summary>
    /// Tests the NHibernateRepository
    /// </summary>
    [TestFixture]
    public class NHibernateTransactionManager_Test
    {
        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        [Test]
        public void Test_NHibernateTransactionManager_CanInstantiateNHibernateTransactionManager()
        {
            TransactionManager transactionManager = new TransactionManager();

            Assert.IsNotNull(transactionManager.ConcreteTransactionManager as NHibernateTransactionManager);
        }
    }
}
