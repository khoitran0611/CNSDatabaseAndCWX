using System;
using System.Collections.Generic;
using System.Diagnostics;
using AgriMore.Logistics.Data.NHibernate.Transaction;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using NUnit.Framework;
using AgriMore.Logistics.Data.NHibernate;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    /// <summary>
    /// Tests the NHibernateRepository
    /// </summary>
    [TestFixture]
    public class NHibernateRepository_ChainEntity_Test
    {
        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            //DatabaseTest.ExecDDL(@"..\..\src\MySql\test_chainentity.sql");
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        [Test]
        public void Test_NHibernateRepository_ChainEntity_Add()
        {
            NHibernateTransactionManager nHibernateTransactionManager = new NHibernateTransactionManager();
            nHibernateTransactionManager.BeginTransaction();

            ChainEntity chainEntity = GetExistingChainEntity();
            int expectedAddressesCount = new List<Address>(chainEntity.Addresses).Count;
            int expectedUsersCount = new List<User>(chainEntity.Users).Count;

            IRepository<ChainEntity> repository = new RepositoryFactory().CreateRepository<ChainEntity>();
            long uid = chainEntity.Uid;
            chainEntity = repository.GetOne(uid);

            Debug.WriteLine("Now fetching addresses");
            List<Address> addresses = new List<Address>(chainEntity.Addresses);
            Assert.AreEqual(expectedAddressesCount, addresses.Count);

            List<User> users = new List<User>(chainEntity.Users);
            Assert.AreEqual(expectedUsersCount, users.Count);

            Address address = GetNewAddress(3);
            chainEntity.AddAddress(address);
            chainEntity.AddUser(GetNewUser(4, 4));

            Debug.WriteLine("Storing ChainEntity with new address and new user");
            repository.Store(chainEntity);

            nHibernateTransactionManager.CommitTransaction();
            long addressUid = address.Uid;
            string expectedCountryName = address.Country.Name;

            chainEntity = repository.GetOne(chainEntity.Uid);

            addresses = new List<Address>(chainEntity.Addresses);
            Assert.AreEqual(expectedAddressesCount + 1, addresses.Count);

            for (int index = 0; index < addresses.Count; index++ )
            {
                address = addresses[index];
                if (address.Uid == addressUid)
                {
                    break;
                }
            }

            Assert.AreEqual(addressUid, address.Uid);
            Assert.AreEqual(2, new List<CashRegister>(address.CashRegisters).Count);
            Assert.AreEqual(expectedCountryName, address.Country.Name);

            users = new List<User>(chainEntity.Users);
            Assert.AreEqual(expectedUsersCount + 1, users.Count);

            nHibernateTransactionManager.CommitTransaction();

            nHibernateTransactionManager.BeginTransaction();

            chainEntity = repository.GetOne(uid);

            Debug.WriteLine("Now fetching addresses");
            addresses = new List<Address>(chainEntity.Addresses);
            Assert.AreEqual(expectedAddressesCount + 1, addresses.Count);
        }

        public static ChainEntity GetExistingChainEntity()
        {
            IRepository<ChainEntity> repository = new RepositoryFactory().GetChainEntityRepository();

            List<ChainEntity> chainEntities = new List<ChainEntity>(repository.AsCollection());
            if (chainEntities.Count > 0)
            {
                return chainEntities[0];
            }

            ChainEntity chainEntity = GetNewChainEntity();

            long uid = repository.Add(chainEntity);

            Assert.AreNotEqual(0, uid);
            return chainEntity;
        }

        public static ChainEntity GetNewChainEntity()
        {
            List<Address> addresses = new List<Address>();
            addresses.Add(GetNewAddress(1));
            addresses.Add(GetNewAddress(2));

            List<User> users = new List<User>();
            users.Add(GetNewUser(1, 1));
            users.Add(GetNewUser(2, 2));
            users.Add(GetNewUser(3, 3));

            return new ChainEntity("ChainEntity 1" + " " + Guid.NewGuid(), addresses, users);
        }

        public static User GetNewUser(int sequenceNumber, int numberOfRoles)
        {
            List<Role> roles = new List<Role>();
            for (int roleSequenceNumber = 1; roleSequenceNumber <= numberOfRoles; roleSequenceNumber++)
            {
                roles.Add(GetNewRole(sequenceNumber * 100 + roleSequenceNumber));
            }
            return new User("Username " + sequenceNumber + " " + Guid.NewGuid(), "Password " + sequenceNumber, "FirstName " + sequenceNumber, "LastName " + sequenceNumber, roles);
        }

        public static Role GetNewRole(int sequenceNumber)
        {
            return new Role("Role " + sequenceNumber + " " + Guid.NewGuid());
        }

        private static Address GetNewAddress(int sequenceNumber)
        {
            Country country = GetExistingCountry();
            AgriMoreTimeZone agriMoreTimeZone = GetExistingAgriMoreTimeZone();
            List<Location> locations = new List<Location>();
            locations.Add(GetNewLocation(1));
            locations.Add(GetNewLocation(1));

            List<CashRegister> cashRegisters = new List<CashRegister>();
            cashRegisters.Add(GetNewCashRegister(1));
            cashRegisters.Add(GetNewCashRegister(2));

            Address address = new Address("City " + sequenceNumber + " " + Guid.NewGuid(), country, "Email " + sequenceNumber, "Fax " + sequenceNumber, "NumberExtension " + sequenceNumber, "StateProvence " + sequenceNumber, "StreetName " + sequenceNumber, "StreetNumber " + sequenceNumber, "Telephone " + sequenceNumber, agriMoreTimeZone, "ZipCode " + sequenceNumber);
            address.AddLocation(GetNewLocation(1));
            address.AddLocation(GetNewLocation(1));

            address.AddCashRegister(GetNewCashRegister(1));
            address.AddCashRegister(GetNewCashRegister(2));

            return address;
            //return new Address("City " + sequenceNumber + " " + Guid.NewGuid(), country, "Email " + sequenceNumber, "Fax " + sequenceNumber, "NumberExtension " + sequenceNumber, "StateProvence " + sequenceNumber, "StreetName " + sequenceNumber, "StreetNumber " + sequenceNumber, "Telephone " + sequenceNumber, agriMoreTimeZone, "ZipCode " + sequenceNumber, locations, cashRegisters);
        }

        private static CashRegister GetNewCashRegister(int sequenceNumber)
        {
            return new CashRegister("CashRegister " + sequenceNumber + " " + Guid.NewGuid());
        }

        public static Location GetNewLocation(int sequenceNumber)
        {
            return new Location("Location " + sequenceNumber + " " + Guid.NewGuid());
        }

        public static Location GetExistingLocation()
        {
            IRepository<Location> repository = new RepositoryFactory().GetLocationRepository();

            List<Location> locations = new List<Location>(repository.AsCollection());
            if (locations.Count > 0)
            {
                return locations[0];
            }

            Location location = GetNewLocation(1);
            Assert.AreEqual(0, location.Uid);
            repository.Add(location);
            Assert.AreNotEqual(0, location.Uid);
            location = repository.GetOne(location.Uid);
            return location;
        }

        private static AgriMoreTimeZone GetExistingAgriMoreTimeZone()
        {
            IRepository<AgriMoreTimeZone> repository =
                new RepositoryFactory().CreateRepository<AgriMoreTimeZone>();

            List<AgriMoreTimeZone> agriMoreTimeZones = new List<AgriMoreTimeZone>(repository.AsCollection());
            if (agriMoreTimeZones.Count > 0)
            {
                return agriMoreTimeZones[0];
            }

            AgriMoreTimeZone agriMoreTimeZone = new AgriMoreTimeZone("CET" + " " + Guid.NewGuid());
            Assert.AreEqual(0, agriMoreTimeZone.Uid);
            repository.Add(agriMoreTimeZone);
            Assert.AreNotEqual(0, agriMoreTimeZone.Uid);
            agriMoreTimeZone = repository.GetOne(agriMoreTimeZone.Uid);
            return agriMoreTimeZone;
        }

        private static Country GetExistingCountry()
        {
            IRepository<Country> repository = new RepositoryFactory().CreateRepository<Country>();

            List<Country> countries = new List<Country>(repository.AsCollection());
            if (countries.Count > 0)
            {
                return countries[0];
            }

            Country country = new Country("Holland" + " " + Guid.NewGuid());
            Assert.AreEqual(0, country.Uid);
            repository.Add(country);
            Assert.AreNotEqual(0, country.Uid);
            country = repository.GetOne(country.Uid);
            return country;
        }
    }
}
