using System;
using System.Reflection;
using AgriMore.Logistics.Common.Exception;
using AgriMore.Logistics.Data.NHibernate.MySql;
using MySql.Data.MySqlClient;
using NHibernate;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    /// <summary>
    /// Tests the MySqlExceptionTranslator
    /// </summary>
    [TestFixture]
    public class MySqlExceptionTranslator_Test
    {
        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        [Test, ExpectedException(typeof(ArgumentNullException))]
        public void Test_MySqlExceptionTranslator_CanHandleNullArgument()
        {
            new MySqlExceptionTranslator().Translate(null);
        }

        [Test]
        public void Test_MySqlExceptionTranslator_CanTranslateMySqlException17()
        {
            int number = 17;
            ADOException adoException = GetAdoException(number);
            ObjectException objectException = new MySqlExceptionTranslator().Translate(adoException);
            Assert.That(objectException is ObjectLoginException);
            Assert.That(objectException.InnerException, Is.EqualTo(adoException.InnerException));
        }

        [Test]
        public void Test_MySqlExceptionTranslator_CanTranslateMySqlException4060()
        {
            int number = 4060;
            ADOException adoException = GetAdoException(number);
            ObjectException objectException = new MySqlExceptionTranslator().Translate(adoException);
            Assert.That(objectException is ObjectLoginException);
            Assert.That(objectException.InnerException, Is.EqualTo(adoException.InnerException));
        }

        [Test]
        public void Test_MySqlExceptionTranslator_CanTranslateMySqlException18456()
        {
            int number = 18456;
            ADOException adoException = GetAdoException(number);
            ObjectException objectException = new MySqlExceptionTranslator().Translate(adoException);
            Assert.That(objectException is ObjectLoginException);
            Assert.That(objectException.InnerException, Is.EqualTo(adoException.InnerException));
        }

        [Test]
        public void Test_MySqlExceptionTranslator_CanTranslateMySqlException1451()
        {
            int number = 1451;
            ADOException adoException = GetAdoException(number);
            ObjectException objectException = new MySqlExceptionTranslator().Translate(adoException);
            Assert.That(objectException is ObjectInUseException);
            Assert.That(objectException.InnerException, Is.EqualTo(adoException.InnerException));
        }

        [Test]
        public void Test_MySqlExceptionTranslator_CanTranslateMySqlException1205()
        {
            int number = 1205;
            ADOException adoException = GetAdoException(number);
            ObjectException objectException = new MySqlExceptionTranslator().Translate(adoException);
            Assert.That(objectException is ObjectDeadLockException);
            Assert.That(objectException.InnerException, Is.EqualTo(adoException.InnerException));
        }

        [Test]
        public void Test_MySqlExceptionTranslator_CanTranslateMySqlException2627()
        {
            int number = 2627;
            ADOException adoException = GetAdoException(number);
            ObjectException objectException = new MySqlExceptionTranslator().Translate(adoException);
            Assert.That(objectException is ObjectInUseException);
            Assert.That(objectException.InnerException, Is.EqualTo(adoException.InnerException));
        }

        [Test]
        public void Test_MySqlExceptionTranslator_CanTranslateMySqlException2601()
        {
            int number = 2601;
            ADOException adoException = GetAdoException(number);
            ObjectException objectException = new MySqlExceptionTranslator().Translate(adoException);
            Assert.That(objectException is ObjectInUseException);
            Assert.That(objectException.InnerException, Is.EqualTo(adoException.InnerException));
        }

        [Test]
        public void Test_MySqlExceptionTranslator_CanTranslateUnknownMySqlException()
        {
            int number = int.MaxValue;
            ADOException adoException = GetAdoException(number);
            ObjectException objectException = new MySqlExceptionTranslator().Translate(adoException);
            Assert.That(objectException is UnknownObjectException);
            Assert.That(objectException.InnerException, Is.EqualTo(adoException.InnerException));
        }

        public static ADOException GetAdoException(int number)
        {
            MySqlException mySqlException = GetMySqlException(number);
            return new ADOException("NHibernate Exception", mySqlException);
        }

        private static MySqlException GetMySqlException(int number)
        {
            Type type = typeof(MySqlException);
            MySqlException mySqlException = (MySqlException)Activator.CreateInstance(type, true);
            FieldInfo field = mySqlException.GetType().GetField("errorCode", BindingFlags.Instance | BindingFlags.NonPublic);
            field.SetValue(mySqlException, number);
            return mySqlException;
        }
    }
}
