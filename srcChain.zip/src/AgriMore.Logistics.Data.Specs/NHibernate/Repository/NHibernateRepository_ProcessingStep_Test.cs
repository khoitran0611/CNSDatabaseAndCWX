using System;
using AgriMore.Logistics.Data.NHibernate.Transaction;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using NUnit.Framework;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    /// <summary>
    /// Tests the NHibernateRepository
    /// </summary>
    [TestFixture]
    public class NHibernateRepository_ProcessingStep_Test
    {
        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            //DatabaseTest.ExecDDL(@"..\..\src\MySql\test_chainentity.sql");
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        [Test]
        public void Test_NHibernateRepository_ProcessingStep_Add()
        {
            NHibernateTransactionManager nHibernateTransactionManager = new NHibernateTransactionManager();
            nHibernateTransactionManager.BeginTransaction();

            ProcessingStep processingStep = CreateProcessingStep();

            IRepository<ProcessingStep> repository = new RepositoryFactory().GetProcessingStepRepository();

            #region Get expectations

            string expectedRemarks = processingStep.Remarks;
            //object expectedStartValue = processingStep.StartValue;
            //object expectedEndValue = processingStep.EndValue;
            ProcessingStepType expectedProcessingStepType = processingStep.ProcessingStepType;

            #endregion

            long uid = repository.Add(processingStep);

            nHibernateTransactionManager.CommitTransaction();

            nHibernateTransactionManager.BeginTransaction();

            processingStep = repository.GetOne(uid);

            #region Verify expectations

            Assert.AreEqual(expectedRemarks, processingStep.Remarks);
            //Assert.AreEqual(expectedStartValue, processingStep.StartValue);
            //Assert.AreEqual(expectedEndValue, processingStep.EndValue);
            Assert.AreEqual(expectedProcessingStepType, processingStep.ProcessingStepType);

            #endregion

            nHibernateTransactionManager.CommitTransaction();
        }

        public static ProcessingStep CreateProcessingStep()
        {
            ProcessingStep processingStep =
                new ProcessingStep("Remarks", 1, 2, ProcessingStepType.Documented, 4, 5, new DateTime(2008, 10, 11), 7);
            return processingStep;
        }
    }
}