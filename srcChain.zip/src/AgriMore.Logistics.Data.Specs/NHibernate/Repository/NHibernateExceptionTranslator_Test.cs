using System;
using AgriMore.Logistics.Common.Exception;
using AgriMore.Logistics.Data.NHibernate;
using AgriMore.Logistics.Domain;
using NHibernate;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;
using ObjectNotFoundException=NHibernate.ObjectNotFoundException;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    /// <summary>
    /// Tests the NHibernateExceptionTranslator
    /// </summary>
    [TestFixture]
    public class NHibernateExceptionTranslator_Test
    {
        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        [Test, ExpectedException(typeof(ArgumentNullException))]
        public void Test_NHibernateExceptionTranslator_CanHandleNullArgument()
        {
            new NHibernateExceptionTranslator().Translate(null);
        }

        [Test]
        public void Test_NHibernateExceptionTranslator_CanTranslateObjectNotFoundException()
        {
            ObjectNotFoundException sourceException = new ObjectNotFoundException(Guid.NewGuid(), typeof(Package));
            ObjectException objectException = new NHibernateExceptionTranslator().Translate(sourceException);
            Assert.That(objectException is AgriMore.Logistics.Common.Exception.ObjectNotFoundException);
            Assert.That(objectException.InnerException, Is.EqualTo(sourceException));
        }

        [Test]
        public void Test_NHibernateExceptionTranslator_CanTranslateUnknownNHibernateException()
        {
            TransientObjectException sourceException = new TransientObjectException("Test");
            ObjectException objectException = new NHibernateExceptionTranslator().Translate(sourceException);
            Assert.That(objectException is UnknownObjectException);
            Assert.That(objectException.InnerException, Is.EqualTo(sourceException));
        }
    }
}
