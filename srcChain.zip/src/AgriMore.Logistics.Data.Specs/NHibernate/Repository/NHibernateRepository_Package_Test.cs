using System;
using System.Collections.Generic;
using System.Diagnostics;
using AgriMore.Logistics.Data.NHibernate.Transaction;
using AgriMore.Logistics.Domain;
using AgriMore.Logistics.Domain.Repository;
using AgriMore.Logistics.Domain.Specification;
using AgriMore.Logistics.Domain.Transaction;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;

namespace AgriMore.Logistics.Data.Specs.NHibernate.Repository
{
    /// <summary>
    /// Tests the NHibernateRepository
    /// </summary>
    [TestFixture]
    public class NHibernateRepository_Package_Test
    {
        #region Setup/Teardown

        /// <summary>
        /// Setup of testfixture.
        /// </summary>
        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        /// Cleanup of testfixture.
        /// </summary>
        [TearDown]
        public void TearDown()
        {
        }

        #endregion

        public static Package GetExistingPackage()
        {
            IRepository<Package> repository = new RepositoryFactory().GetPackageRepository();

            List<Package> packages = new List<Package>(repository.AsCollection());
            if (packages.Count > 0)
            {
                return packages[0];
            }

            Package package = GetNewPackage();
            long uid = repository.Add(package);

            Assert.AreNotEqual(0, uid);
            return package;
        }

        public static Package GetNewPackage()
        {
            PackageType packageType = GetExistingPackageType();
            return GetNewPackage(packageType);
        }

        public static Package GetNewPackage(PackageType packageType)
        {
            List<Identification> identifications = GetNewIdentifications();
            List<PrimaryProduct> primaryProducts = GetNewPrimaryProducts();

            return new Package(packageType, primaryProducts, new DateTime(2007, 3, 31), identifications);
        }

        public static List<PrimaryProduct> GetNewPrimaryProducts()
        {
            List<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();
            primaryProducts.Add(GetNewPrimaryProduct(1));
            primaryProducts.Add(GetNewPrimaryProduct(2));
            return primaryProducts;
        }

        private static PrimaryProduct GetNewPrimaryProduct(int sequenceNumber)
        {
            string productionAreaId = ("ProductionAreaId " + sequenceNumber + " " + Guid.NewGuid()).Substring(0, 19);
            string lifeCycleId = ("LifeCycleId " + sequenceNumber + " " + Guid.NewGuid()).Substring(0, 19);

            return
                new PrimaryProduct(productionAreaId, lifeCycleId,
                                   "HarvestedProductDescription " + sequenceNumber + " " + Guid.NewGuid());
        }

        public static List<Identification> GetNewIdentifications()
        {
            List<Identification> identifications = new List<Identification>();
            identifications.Add(GetNewIdentification(1));
            identifications.Add(GetNewIdentification(2));
            return identifications;
        }

        public static PackageType GetExistingPackageType()
        {
            IRepository<PackageType> repository = new RepositoryFactory().GetPackageTypeRepository();

            List<PackageType> packageTypes = new List<PackageType>(repository.AsCollection());
            if (packageTypes.Count > 0)
            {
                return packageTypes[0];
            }

            string packageTypeCategoryName = "retailPackaging";
            string packageTypeName = "FlowPack";

            PackageType packageType = GetNewPackageType(packageTypeCategoryName, packageTypeName);

            repository.Add(packageType);
            packageType = repository.GetOne(packageType.Uid);
            return packageType;
        }

        public static PackageType GetNewPackageType(string packageTypeCategoryName, string packageTypeName)
        {
            PackageTypeCategory packageTypeCategory;
            packageTypeCategory = new PackageTypeCategory(packageTypeCategoryName);
            PackageType packageType = new PackageType(
                packageTypeName,
                packageTypeCategory,
                GetExistingPackingMaterial(),
                new Measurement(new UnitOfMeasurement("cm"), 5),
                new Measurement(new UnitOfMeasurement("cm"), 10),
                new Measurement(new UnitOfMeasurement("cm"), 15),
                new Measurement(new UnitOfMeasurement("cm3"), 5),
                false, false
                );
            return packageType;
        }

        public static PackingMaterial GetExistingPackingMaterial()
        {
            IRepository<PackingMaterial> repository = new RepositoryFactory().CreateRepository<PackingMaterial>();

            List<PackingMaterial> packingMaterials = new List<PackingMaterial>(repository.AsCollection());
            if (packingMaterials.Count > 0)
            {
                return packingMaterials[0];
            }

            PackingMaterial packingMaterial = new PackingMaterial("Plastic");

            repository.Add(packingMaterial);
            packingMaterial = repository.GetOne(packingMaterial.Uid);
            return packingMaterial;
        }

        private static Identification GetNewIdentification(int sequenceNumber)
        {
            ChainEntity chainEntity = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();
            return new Identification("Identification " + sequenceNumber + " " + Guid.NewGuid(), chainEntity);
        }

        [Test]
        public void Test_NHibernateRepository_Package_Add()
        {
            NHibernateTransactionManager nHibernateTransactionManager = new NHibernateTransactionManager();
            nHibernateTransactionManager.BeginTransaction();

            Package package = GetExistingPackage();

            IRepository<Package> repository = new RepositoryFactory().GetPackageRepository();

            Package parentPackage =
                package.Pack(GetExistingPackageType(), package.PackingDateTime.AddDays(1), GetNewIdentifications());

            #region Get expectations

            List<Package> children = new List<Package>(parentPackage.Children);
            int expectedChildCount = children.Count;

            Package childPackage = children[0];

            int expectedPrimaryProductsCount = parentPackage.PrimaryProducts.Count;

            PackageType packageType = childPackage.PackageType;
            string expectedPackageTypeName = packageType.Name;

            PackageTypeCategory packageTypeCategory = packageType.PackageTypeCategory;
            string expectedPackageTypeCategoryName = packageTypeCategory.Name;

            string expectedPackingMaterialName = packageType.PackingMaterial.Name;

            #endregion

            long uid = repository.Add(parentPackage);

            nHibernateTransactionManager.CommitTransaction();

            nHibernateTransactionManager.BeginTransaction();

            parentPackage = repository.GetOne(uid);

            #region Verify expectations

            children = new List<Package>(parentPackage.Children);
            Assert.AreEqual(expectedChildCount, children.Count);

            childPackage = children[0];
            Assert.AreEqual(expectedPrimaryProductsCount, parentPackage.PrimaryProducts.Count);
            //childPackage.PrimaryProducts.Count);

            packageType = childPackage.PackageType;
            Assert.AreEqual(expectedPackageTypeName, packageType.Name);

            packageTypeCategory = packageType.PackageTypeCategory;
            Assert.AreEqual(expectedPackageTypeCategoryName, packageTypeCategory.Name);

            Assert.AreEqual(expectedPackingMaterialName, packageType.PackingMaterial.Name);

            #endregion

            nHibernateTransactionManager.CommitTransaction();
        }

        [Test]
        public void Test_NHibernateRepository_Package_Add_Bulk()
        {
            TransactionManager transactionManager = new TransactionManager();

            try
            {
                transactionManager.BeginTransaction();

                int from = 1;
                int to = 0;

                ChainEntity receiver = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();

                ChainEntity chainEntity = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();

                PackageType packageType = GetExistingPackageType();

                List<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();

                primaryProducts.Add(GetNewPrimaryProduct(1));
                primaryProducts.Add(GetNewPrimaryProduct(2));

                DateTime dateTimeOfPacking = new DateTime(2008, 3, 1);

                for (int counter = from; counter <= to; counter++)
                {
                    List<Identification> packageIdentifications = GetPackageIdentifications(counter, chainEntity);
                    packageIdentifications.AddRange(GetPackageIdentifications(counter, receiver));

                    Package package = new Package(packageType, primaryProducts, dateTimeOfPacking, packageIdentifications, "ProductCode " + counter);

                    new RepositoryFactory().GetPackageRepository().Add(package);
                }

                transactionManager.CommitTransaction();
            }
            catch (Exception)
            {
                transactionManager.RollbackTransaction();
                throw;
            }

            try
            {
                transactionManager.BeginTransaction();

                int from = 1;
                int to = 1;

                ChainEntity receiver = NHibernateRepository_ChainEntity_Test.GetExistingChainEntity();

                ChainEntity chainEntity = NHibernateRepository_ChainEntity_Test.GetNewChainEntity();

                new RepositoryFactory().GetChainEntityRepository().Add(chainEntity);

                PackageType packageType = GetExistingPackageType();

                List<PrimaryProduct> primaryProducts = new List<PrimaryProduct>();

                primaryProducts.Add(GetNewPrimaryProduct(1));
                primaryProducts.Add(GetNewPrimaryProduct(2));

                DateTime dateTimeOfPacking = new DateTime(2008, 3, 1);

                for (int counter = from; counter <= to; counter++)
                {
                    List<Identification> packageIdentifications = GetPackageIdentifications(counter, chainEntity);
                    packageIdentifications.AddRange(GetPackageIdentifications(counter, receiver));

                    Package package = new Package(packageType, primaryProducts, dateTimeOfPacking, packageIdentifications, "ProductCode " + counter);

                    new RepositoryFactory().GetPackageRepository().Add(package);
                }

                transactionManager.CommitTransaction();
            }
            catch (Exception)
            {
                transactionManager.RollbackTransaction();
                throw;
            }

        }

        private static List<Identification> GetPackageIdentifications(int counter, ChainEntity chainEntity)
        {
            List<Identification> packageIdentifications = new List<Identification>();
            Identification identification = new Identification(counter.ToString(), chainEntity);
            packageIdentifications.Add(identification);
            return packageIdentifications;
        }
    }
}