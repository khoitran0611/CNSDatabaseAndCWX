using System;

namespace AgriMore.Logistics.Common.Exception
{
    /// <summary>
    /// Summary description for ObjectException.
    /// </summary>
    [Serializable]
    public class ObjectException : System.Exception
    {
        /// <summary>
        /// Initializes a new instance of the ObjectException class with a specified error message and a reference to the inner exception that is the cause of this exception.
        /// </summary>
        /// <param name="message">The error message string.</param>
        /// <param name="innerException">The inner exception reference.</param>
        public ObjectException(string message, System.Exception innerException)
            : base(message, innerException)
        {
        }
    }
}