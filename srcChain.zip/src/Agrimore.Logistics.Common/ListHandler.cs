using System.Collections;
using System.Collections.Generic;

namespace AgriMore.Logistics.Common
{
    /// <summary>
    /// Represents the ListHandler class.
    /// </summary>
    public class ListHandler
    {
        /// <summary>
        /// Converts the specified <see cref="ICollection"/> to a generic list.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="listOfObjects">The list of objects.</param>
        /// <returns></returns>
        public static List<T> ConvertToGenericList<T>(ICollection listOfObjects)
        {
            ArrayList notStronglyTypedList = new ArrayList(listOfObjects);
            return new List<T>(notStronglyTypedList.ToArray(typeof (T)) as T[]);
        }

        /// <summary>
        /// Converts to unique generic list.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="listOfObjects">The list of objects.</param>
        /// <returns></returns>
        public static List<T> ConvertToUniqueGenericList<T>(ICollection listOfObjects)
        {
            ArrayList notStronglyTypedList = new ArrayList(listOfObjects);
            T[] ts = notStronglyTypedList.ToArray(typeof(T)) as T[];
            Dictionary<int, T> dictionary = new Dictionary<int, T>();

            if (ts != null)
            {
                foreach (T t in ts)
                {
                    int hashCode = t.GetHashCode();
                    if (!dictionary.ContainsKey(hashCode))
                    {
                        dictionary.Add(hashCode, t);
                    }
                }
            }

            return new List<T>(dictionary.Values);
        }
    }
}