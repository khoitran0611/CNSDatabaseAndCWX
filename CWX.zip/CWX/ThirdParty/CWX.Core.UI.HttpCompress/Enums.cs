namespace CWX.Core.UI.HttpCompress
{
    public enum CompressionType
    {
        None=0,
        none=0,
        GZip=1,
        Gzip=1,
        gzip=1,
        Deflate=2,
        deflate=2
    }
}