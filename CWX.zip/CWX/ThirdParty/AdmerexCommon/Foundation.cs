using System;
using System.Configuration;
using System.Threading;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Data;
using System.IO;
using Admerex.Common.Exceptions;

namespace Admerex.Common
{
    /// <summary>
    /// Summary description for Foundation.
    /// </summary>
    public static class Foundation
    {
        private static DbDataSource ds;
        private static string path;

        public static DbDataSource DataSource
        {
            get { return ds; }
        }

        public static DataDictionary DataDictionary
        {
            get { return DataDictionary.Instance; }
        }

        public static string ConfigFilesPath
        {
            get { return path; }
        }

        /// <summary>
        /// Initialise the foundation
        /// </summary>
        public static void Init(Assembly resourceAssembly, string language, string sourceType, string sourceConnectionString, string configFilesPath)
        {
            path = configFilesPath;
            ds = DbDataSourceFactory.CreateDataSource(sourceType, sourceConnectionString);

            //Thread.CurrentThread.CurrentCulture =  Thread.CurrentThread.CurrentUICulture = new CultureInfo(language);
            AssemblyName assemblyName = resourceAssembly.GetName();
            ResourceManager rm = new ResourceManager(assemblyName.Name + ".AppStrings", resourceAssembly);
            //Stream stream = resourceAssembly.GetManifestResourceStream(assemblyName.Name + ".DefaultDictionary.xml");
            Stream stream = new FileStream(path + "DefaultDictionary.xml", FileMode.Open);
            DataDictionary.Init(ds, stream, rm);
        }
    }
}
