﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using System.Reflection;

namespace Admerex.Common
{
    public class SerializableDictionary : IXmlSerializable
    {

        private IDictionary dictionary;

        public SerializableDictionary()
        {
            this.dictionary = new SortedDictionary<string, object>();
        }

        public SerializableDictionary(IDictionary dictionary)
        {
            this.dictionary = dictionary;
        }

        public IDictionary Dictionary
        {
            get { return dictionary; }
            set { dictionary = value; }
        }

        public void ReadXml(XmlReader reader)
        {
            try
            {
                reader.Read();

                reader.ReadStartElement("SortedDictionary");

                while (reader.NodeType != XmlNodeType.EndElement)
                {
                    reader.ReadStartElement("SortedDictionaryItem");

                    string key = reader.ReadElementString("Key");
                    object value = reader.ReadElementString("Value");
                    dictionary.Add(key, value);

                    reader.ReadEndElement(); // </DictionaryItem>
                    reader.MoveToContent();
                }

                if (reader.Name == "SortedDictionary")
                {
                    reader.ReadEndElement(); // </Dictionary>
                }

                reader.ReadEndElement();
                reader.MoveToContent();
            }
            catch (XmlException ex)
            {
                string errMsg = DataDictionary.Instance.GetString("ERR_READ_XML");
                string exstring = ex.Message.ToString();
            }
        }

        public void WriteXml(XmlWriter writer)
        {
            try
            {
                writer.WriteStartElement("SortedDictionary");

                foreach (string key in dictionary.Keys)
                {
                    writer.WriteStartElement("SortedDictionaryItem");

                    writer.WriteElementString("Key", key);

                    object value = dictionary[key];

                    if (value == null)
                        writer.WriteElementString("Value", "");
                    else
                        writer.WriteElementString("Value", value.ToString());

                    writer.WriteEndElement();
                }

                writer.WriteEndElement();
            }
            catch (InvalidOperationException ex)
            {
                string errMsg = DataDictionary.Instance.GetString("ERR_WRITE_XML");
                string exstring = ex.Message.ToString();
            }
        }

        public XmlSchema GetSchema()
        {
            return null;
        }
    }
}
