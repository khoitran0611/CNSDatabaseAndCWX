using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace Admerex.Common.Exceptions
{
    /// <summary>
    /// This class must be used as the base class for all our exceptions.
    /// </summary>
    [Serializable]
    public class AdmerexException : BaseApplicationException
    {
        public AdmerexException() : base()
        {
        }

        public AdmerexException(string message) : base(message)
        {
        }

        public AdmerexException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected AdmerexException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

        public static Exception InnerMostException(Exception ex)
        {
            if (ex.InnerException != null)
                return InnerMostException(ex.InnerException);
            else
                return ex;
        }

        private static string BuildStackTrace(Exception ex)
        {
            StringBuilder result = new StringBuilder();

            StackTrace stack = new StackTrace(ex, true);
            StackFrame[] stackFrame = stack.GetFrames();

            if (stackFrame == null)
            {
                result.Append(ex.StackTrace);
            }
            else
            {
                foreach (StackFrame frame in stack.GetFrames())
                {
                    result.Append(frame.GetMethod().DeclaringType.FullName);
                    result.Append(".");
                    result.Append(frame.GetMethod().Name);
                    result.Append("():");
                    result.Append(Environment.NewLine);

                    try
                    {
                        string filename = frame.GetFileName();

                        if (filename != null && filename.Length > 0)
                        {
                            result.Append("File: ");
                            result.Append(filename);
                            result.Append(Environment.NewLine);
                        }

                        int line = frame.GetFileLineNumber();

                        if (line > 0)
                        {
                            result.Append("Line: ");
                            result.Append(line);
                            result.Append(Environment.NewLine);
                        }
                    }
                    catch
                    {

                    }

                    result.Append(Environment.NewLine);
                }
            }

            return result.ToString();
        }
    }
}
