using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace Admerex.Common.Exceptions
{
    [Serializable]
    public class DacException : AdmerexException
    {
        public DacException()
            : base()
        {
        }

        public DacException(string message)
            : base(message)
        {
        }

        public DacException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        protected DacException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
