using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace Admerex.Common.Exceptions
{
    [Serializable]
    public class DataDictionaryException : AdmerexException
    {
        public DataDictionaryException() : base()
        {
        }

        public DataDictionaryException(string message) : base(message)
        {
        }

        public DataDictionaryException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected DataDictionaryException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
