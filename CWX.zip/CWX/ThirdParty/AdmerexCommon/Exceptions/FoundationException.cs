using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace Admerex.Common.Exceptions
{
    [Serializable]
    public class FoundationException : AdmerexException
    {
        public FoundationException() : base()
        {
        }

        public FoundationException(string message) : base(message)
        {
        }

        public FoundationException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected FoundationException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
