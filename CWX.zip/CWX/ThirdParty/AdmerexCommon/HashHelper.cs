using System;
using System.Text;
using System.Security.Cryptography;

namespace Admerex.Common
{
    /// <summary>
    /// This class provides methods for creating a hashed and salted password and 
    /// for comparing a given plain password with a previously hashed and salted 
    /// password.
    /// </summary>
    /// <remarks>
    /// Starting point: MSDN article - Password Credential Protection
    /// http://msdn2.microsoft.com/en-us/library/Aa289843(VS.71).aspx
    /// </remarks>
    public static class HashHelper
    {
        private const int saltLength = 4;

        public static string HashSaltPassword(string plainPassword)
        {
            SHA1 sha1 = SHA1.Create();
            byte[] hashedPassword = sha1.ComputeHash(Encoding.Default.GetBytes(plainPassword));
            byte[] saltedPassword = CreateDbPassword(hashedPassword);
            return Encoding.Default.GetString(saltedPassword);
        }

        public static bool ComparePasswords(string storedPassword, string plainPassword)
        {
            SHA1 sha1 = SHA1.Create();
            byte[] hashedPassword = sha1.ComputeHash(Encoding.Default.GetBytes(plainPassword));
            return ComparePasswords(Encoding.Default.GetBytes(storedPassword), hashedPassword);
        }

        // Create salted password to save in database.
        private static byte[] CreateDbPassword(byte[] unsaltedPassword)
        {
            //Create a salt value.
            byte[] saltValue = new byte[saltLength];
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            rng.GetBytes(saltValue);

            return CreateSaltedPassword(saltValue, unsaltedPassword);
        }

        /// <summary>
        /// Given the salt value, create a salted password.
        /// </summary>
        private static byte[] CreateSaltedPassword(byte[] saltValue, byte[] unsaltedPassword)
        {
            // Add the salt to the hash.
            byte[] rawSalted = new byte[unsaltedPassword.Length + saltValue.Length];
            unsaltedPassword.CopyTo(rawSalted, 0);
            saltValue.CopyTo(rawSalted, unsaltedPassword.Length);

            // Create the salted hash.
            SHA1 sha1 = SHA1.Create();
            byte[] saltedPassword = sha1.ComputeHash(rawSalted);

            // Add the salt value to the salted hash.
            byte[] dbPassword = new byte[saltedPassword.Length + saltValue.Length];
            saltedPassword.CopyTo(dbPassword, 0);
            saltValue.CopyTo(dbPassword, saltedPassword.Length);

            return dbPassword;
        }

        /// <summary>
        /// Compare a hashed password against the stored version.
        /// </summary>
        private static bool ComparePasswords(byte[] storedPassword, byte[] hashedPassword)
        {
            if (storedPassword == null || hashedPassword == null || hashedPassword.Length != storedPassword.Length - saltLength)
                return false;

            // Get the saved saltValue.
            byte[] saltValue = new byte[saltLength];
            int saltOffset = storedPassword.Length - saltLength;

            for (int i = 0; i < saltLength; i++)
                saltValue[i] = storedPassword[saltOffset + i];

            byte[] saltedPassword = CreateSaltedPassword(saltValue, hashedPassword);

            // Compare the values.
            return CompareByteArray(storedPassword, saltedPassword);
        }

        /// <summary>
        /// Compare the contents of two byte arrays.
        /// </summary>
        private static bool CompareByteArray(byte[] array1, byte[] array2)
        {
            if (array1.Length != array2.Length)
                return false;

            for (int i = 0; i < array1.Length; i++)
            {
                if (array1[i] != array2[i])
                    return false;
            }

            return true;
        }
    }
}
