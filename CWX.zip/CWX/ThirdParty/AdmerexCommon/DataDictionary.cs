using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Resources;
using System.Data;
using System.Data.Common;
using System.Xml;
using Admerex.Common.Exceptions;

namespace Admerex.Common
{
    /// <summary>
    /// DataDictionary is a singleton class that provides access to 
    /// the Resource strings and to the DataDictionary table.
    /// </summary>
    public sealed class DataDictionary
    {
        private static DataDictionary instance;
        private DataTable dtDictionary = new DataTable();
        private ResourceManager resourceManager;
        private DbDataSource ds;

        private DataDictionary(DbDataSource ds, Stream defaultDictionaryStream)
        {
            this.ds = ds;
            Load();
            ValidateDefaultDictionary(defaultDictionaryStream);
        }

        private DataDictionary(DbDataSource ds, Stream defaultDictionaryStream, ResourceManager rmAppStrings)
        {
            this.resourceManager = rmAppStrings;
            this.ds = ds;
            Load();
            ValidateDefaultDictionary(defaultDictionaryStream);
        }

        internal static DataDictionary Instance
        {
            get { return instance; }
        }

        internal static void Init(DbDataSource ds, Stream defaultDictionaryStream)
        {
            instance = new DataDictionary(ds, defaultDictionaryStream);
        }

        internal static void Init(DbDataSource ds, Stream defaultDictionaryStream, ResourceManager rmAppStrings)
        {
            instance = new DataDictionary(ds, defaultDictionaryStream, rmAppStrings);
        }

        private void Load()
        {
            DbConnection conn = ds.CreateConnection();
            conn.Open();

            try
            {
                DbCommand cmd = ds.ProviderFactory.CreateCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from MC_DataDictionary";

                DbDataAdapter da = ds.ProviderFactory.CreateDataAdapter();
                da.SelectCommand = cmd;

                da.Fill(dtDictionary);
            }
            finally
            {
                conn.Close();
            }
        }

        private void ValidateDefaultDictionary(Stream defaultDictionaryStream)
        {
            // Load the default dictionary from the XML file
            DataTable dt = GetDictionarySchema();
            
            using (XmlTextReader xtr = new XmlTextReader(defaultDictionaryStream))
            {
                dt.ReadXml(xtr);
            }

            DataRow[] rows = dt.Select(string.Format("{0} = {1}", DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Application));

            // There should be only one record of type Application
            if (rows.Length != 1)
                throw new DataDictionaryException(GetString("ERR_DD_INVALID_STRUCTURE"));

            DictionaryItem defaultApplication = new DictionaryItem(rows[0]);
            DictionaryItem dbApplication = GetApplicationItem();

            // Check the ApplicationName
            if (dbApplication.PhysicalName.ToUpper() != defaultApplication.PhysicalName.ToUpper())
                throw new DataDictionaryException(GetString("ERR_DD_APPNAME_MISMATCH"));

            // Check the Version
            if (dbApplication.DefaultValue != defaultApplication.DefaultValue)
                throw new DataDictionaryException(GetString("ERR_DD_VERSION_MISMATCH"));

            // Check that all the system tables exist
            rows = dt.Select(string.Format("{0} = {1}", DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Table));

            DictionaryItem[] defaultTables = GetDictionaryItemArray(rows);
            DictionaryItem[] dbSystemTables = GetSystemTables();

            if (dbSystemTables.Length == 0)
                throw new DataDictionaryException(GetString("ERR_DD_DEFAULT_SCHEMA_MISMATCH"));

            bool isMissing = false;

            foreach (DictionaryItem diDefaultTable in defaultTables)
            {
                bool found = false;

                foreach (DictionaryItem diDbSystemTable in dbSystemTables)
                {
                    if (diDefaultTable.MetaName == diDbSystemTable.MetaName &&
                        diDefaultTable.ParentId == diDbSystemTable.ParentId)
                    {
                        found = true;
                        break;
                    }
                }

                if (!found)
                {
                    isMissing = true;
                    break;
                }
            }

            if (isMissing)
                throw new DataDictionaryException(GetString("ERR_DD_DEFAULT_SCHEMA_MISMATCH"));

            // Check that all the system fields exist
            foreach (DictionaryItem diDefaultTable in defaultTables)
            {
                DataRow[] fields = dt.Select(
                    string.Format("{0} = {1} and {2} = {3}",
                    DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Field,
                    DictionaryItem.PARENTID, diDefaultTable.Id));

                DictionaryItem[] defaultTableFields = GetDictionaryItemArray(fields);
                DictionaryItem[] dbTableFields = GetSystemFieldsForTable(diDefaultTable.MetaName);

                if (dbTableFields.Length == 0)
                {
                    isMissing = true;
                    break;
                }

                bool fieldMissing = false;

                foreach (DictionaryItem diDefaultTableField in defaultTableFields)
                {
                    bool found = false;

                    foreach (DictionaryItem diDbTableField in dbTableFields)
                    {
                        if (diDefaultTableField.MetaName == diDbTableField.MetaName &&
                            diDefaultTableField.Id == diDbTableField.Id &&
                            diDefaultTableField.ParentId == diDbTableField.ParentId &&
                            diDefaultTableField.DotNetType == diDbTableField.DotNetType &&
                            diDefaultTableField.DbType == diDbTableField.DbType &&
                            diDefaultTableField.IsRequired == diDbTableField.IsRequired)
                        {
                            found = true;
                            break;
                        }
                    }

                    if (!found)
                    {
                        fieldMissing = true;
                        break;
                    }
                }

                if (fieldMissing)
                {
                    isMissing = true;
                    break;
                }
            }

            if (isMissing)
                throw new DataDictionaryException(GetString("ERR_DD_DEFAULT_SCHEMA_MISMATCH"));

            // Check that all the system primary keys exist
            foreach (DictionaryItem diDefaultTable in defaultTables)
            {
                DataRow[] fields = dt.Select(
                    string.Format("{0} = {1} and {2} = {3} and {4} = 1",
                    DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Field,
                    DictionaryItem.PARENTID, diDefaultTable.Id,
                    DictionaryItem.ISPRIMARYKEY));

                DictionaryItem[] defaultTablePKs = GetDictionaryItemArray(fields);
                DictionaryItem[] dbTablePKs = GetPrimaryKeysForTable(diDefaultTable.MetaName);

                if (dbTablePKs.Length == 0) continue;

                bool fieldMissing = false;

                foreach (DictionaryItem diDefaultTablePK in defaultTablePKs)
                {
                    bool found = false;

                    foreach (DictionaryItem diDbTablePK in dbTablePKs)
                    {
                        if (diDefaultTablePK.MetaName == diDbTablePK.MetaName &&
                            diDefaultTablePK.ParentId == diDbTablePK.ParentId &&
                            diDefaultTablePK.DotNetType == diDbTablePK.DotNetType &&
                            diDefaultTablePK.DbType == diDbTablePK.DbType &&
                            diDefaultTablePK.IsSystem == diDbTablePK.IsSystem)
                        {
                            found = true;
                            break;
                        }
                    }

                    if (!found)
                    {
                        fieldMissing = true;
                        break;
                    }
                }

                if (fieldMissing)
                {
                    isMissing = true;
                    break;
                }
            }

            if (isMissing)
                throw new DataDictionaryException(GetString("ERR_DD_DEFAULT_SCHEMA_MISMATCH"));

            // TODO: There should be only one concurrency flag per table.
        }

        /// <summary>
        /// Gets the key's corresponding string from the resource file.
        /// </summary>
        public string GetString(string key)
        {
            if (resourceManager == null || key == null) return "";

            return resourceManager.GetString(key);
        }

        // TODO: Make metanames case insensitive.
        public DictionaryItem GetItemByMetaName(string metaName)
        {
            DataRow[] rows = dtDictionary.Select(string.Format("{0} = '{1}'", DictionaryItem.METANAME, metaName));

            if (rows.Length == 1)
                return new DictionaryItem(rows[0]);

            return null;
        }

        public DictionaryItem GetConcurrencyItem(string tableMetaName)
        {
            DictionaryItem tableItem = GetTableItem(tableMetaName);

            if (tableItem != null)
            {
                DataRow[] rows = dtDictionary.Select(
                    string.Format("{0} = {1} and {2} = {3} and {4} = 1",
                        DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Field,
                        DictionaryItem.PARENTID, tableItem.Id, DictionaryItem.ISCONCURRENCYFLAG));

                if (rows.Length == 1)
                    return new DictionaryItem(rows[0]);
            }

            return null;
        }

        public DictionaryItem GetApplicationItem()
        {
            DataRow[] rows = dtDictionary.Select(
                string.Format("{0} = {1}", DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Application));

            if (rows.Length == 1)
                return new DictionaryItem(rows[0]);

            return null;
        }

        public DictionaryItem GetTableItem(string metaName)
        {
            DataRow[] rows = dtDictionary.Select(
                string.Format("{0} = {1} and {2} = '{3}'",
                    DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Table,
                    DictionaryItem.METANAME, metaName));

            if (rows.Length == 1)
                return new DictionaryItem(rows[0]);

            return null;
        }

        public DictionaryItem[] GetSystemTables()
        {
            DataRow[] rows = dtDictionary.Select(
                string.Format("{0} = {1} and {2} = 1",
                DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Table, DictionaryItem.ISSYSTEM));

            return GetDictionaryItemArray(rows);
        }

        public DictionaryItem GetFieldItem(string metaName)
        {
            DataRow[] rows = dtDictionary.Select(
                string.Format("{0} = {1} and {2} = '{3}'",
                DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Field,
                DictionaryItem.METANAME, metaName));

            if (rows.Length == 1)
                return new DictionaryItem(rows[0]);

            return null;
        }

        public DictionaryItem GetFieldItem(string tableMetaName, string fieldMetaName)
        {
            DictionaryItem tableItem = GetTableItem(tableMetaName);

            if (tableItem != null)
            {
                DataRow[] rows = dtDictionary.Select(
                    string.Format("{0} = {1} and {2} = {3} and {4} = '{5}'",
                    DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Field,
                    DictionaryItem.PARENTID, tableItem.Id,
                    DictionaryItem.METANAME, fieldMetaName));

                if (rows.Length == 1)
                    return new DictionaryItem(rows[0]);
            }

            return null;
        }

        public DictionaryItem[] GetFieldsForTable(string metaName)
        {
            return GetFieldsForTable(metaName, "");
        }

        public DictionaryItem[] GetFieldsForTable(string metaName, string sort)
        {
            DictionaryItem tableItem = GetTableItem(metaName);

            if (tableItem != null)
            {
                DataRow[] rows = dtDictionary.Select(
                string.Format("{0} = {1} and {2} = {3}",
                DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Field,
                DictionaryItem.PARENTID, tableItem.Id), sort);

                return GetDictionaryItemArray(rows);
            }

            return new DictionaryItem[0];
        }

        public DictionaryItem[] GetSystemFieldsForTable(string metaName)
        {
            return GetSystemFieldsForTable(metaName, "");
        }

        public DictionaryItem[] GetSystemFieldsForTable(string metaName, string sort)
        {
            DictionaryItem tableItem = GetTableItem(metaName);

            if (tableItem != null)
            {
                DataRow[] rows = dtDictionary.Select(
                    string.Format("{0} = {1} and {2} = {3} and {4} = 1",
                    DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Field,
                    DictionaryItem.PARENTID, tableItem.Id, DictionaryItem.ISSYSTEM), sort);

                return GetDictionaryItemArray(rows);
            }

            return new DictionaryItem[0];
        }

        public DictionaryItem[] GetNonSystemFieldsForTable(string metaName)
        {
            return GetNonSystemFieldsForTable(metaName, "");
        }

        public DictionaryItem[] GetNonSystemFieldsForTable(string metaName, string sort)
        {
            DictionaryItem tableItem = GetTableItem(metaName);

            if (tableItem != null)
            {
                DataRow[] rows = dtDictionary.Select(
                    string.Format("{0} = {1} and {2} = {3} and {4} = 0",
                    DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Field,
                    DictionaryItem.PARENTID, tableItem.Id, DictionaryItem.ISSYSTEM), sort);

                return GetDictionaryItemArray(rows);
            }

            return new DictionaryItem[0];
        }

        public DictionaryItem[] GetPrimaryKeysForTable(string metaName)
        {
            DictionaryItem tableItem = GetTableItem(metaName);

            if (tableItem != null)
            {
                DataRow[] rows = dtDictionary.Select(
                    string.Format("{0} = {1} and {2} = {3} and {4} = 1",
                    DictionaryItem.ITEMTYPE, (int)DictionaryItemTypes.Field,
                    DictionaryItem.PARENTID, tableItem.Id, DictionaryItem.ISPRIMARYKEY));

                return GetDictionaryItemArray(rows);
            }

            return new DictionaryItem[0];
        }

        // Helper method to create an array of DictionaryItem elements.
        private DictionaryItem[] GetDictionaryItemArray(DataRow[] rows)
        {
            List<DictionaryItem> dictionaryItems = new List<DictionaryItem>();

            for (int i = 0; i < rows.Length; i++)
                dictionaryItems.Add(new DictionaryItem(rows[i]));

            return dictionaryItems.ToArray();
        }

        public static DataTable GetDictionarySchema()
        {
            DataTable dt = new DataTable();
            dt.TableName = "DataDictionary";
            dt.Columns.Add(new DataColumn(DictionaryItem.ID, typeof(int)));
            dt.Columns.Add(new DataColumn(DictionaryItem.PARENTID, typeof(int)));
            dt.Columns.Add(new DataColumn(DictionaryItem.METANAME, typeof(String)));
            dt.Columns.Add(new DataColumn(DictionaryItem.PHYSICALNAME, typeof(String)));
            dt.Columns.Add(new DataColumn(DictionaryItem.CAPTION, typeof(String)));
            dt.Columns.Add(new DataColumn(DictionaryItem.ITEMTYPE, typeof(DictionaryItemTypes)));
            dt.Columns.Add(new DataColumn(DictionaryItem.DOTNETTYPE, typeof(string)));
            dt.Columns.Add(new DataColumn(DictionaryItem.DBTYPE, typeof(string)));
            dt.Columns.Add(new DataColumn(DictionaryItem.ISPRIMARYKEY, typeof(bool)));
            dt.Columns.Add(new DataColumn(DictionaryItem.ISREQUIRED, typeof(bool)));
            dt.Columns.Add(new DataColumn(DictionaryItem.ISSYSTEM, typeof(bool)));
            dt.Columns.Add(new DataColumn(DictionaryItem.ISCONCURRENCYFLAG, typeof(bool)));
            dt.Columns.Add(new DataColumn(DictionaryItem.DEFAULTVALUE, typeof(String)));
            dt.Columns.Add(new DataColumn(DictionaryItem.LASTMODIFIED, typeof(DateTime)));
            return dt;
        }
    }

    public sealed class DictionaryItem
    {
        // column names
        public static string ID = "id";
        public static string PARENTID = "parentId";
        public static string METANAME = "metaName";        
        public static string PHYSICALNAME = "physicalName";
        public static string CAPTION = "caption";
        public static string ITEMTYPE = "itemType";
        public static string DOTNETTYPE = "dotNetType";
        public static string DBTYPE = "dbType";
        public static string ISPRIMARYKEY = "isPrimaryKey";
        public static string ISREQUIRED = "isRequired";
        public static string ISSYSTEM = "isSystem";
        public static string ISCONCURRENCYFLAG = "isConcurrencyFlag";
        public static string DEFAULTVALUE = "defaultValue";
        public static string LASTMODIFIED = "lastModified";

        private int id;
        private int parentId;
        private string metaName;
        private string physicalName;
        private string caption;
        private DictionaryItemTypes itemType;
        private Type dotNetType;
        private DbType dbType;
        private bool isPrimaryKey;
        private bool isRequired;
        private bool isSystem;
        private bool isConcurrencyFlag;
        private string defaultValue;
        private DateTime lastModified;

        public int Id
        {
            get { return id; }
        }

        public int ParentId
        {
            get { return parentId; }
        }

        public string MetaName
        {
            get { return metaName; }
        }

        public string PhysicalName
        {
            get { return physicalName; }
        }

        public string Caption
        {
            get { return caption; }
        }

        public DictionaryItemTypes ItemType
        {
            get { return itemType; }
        }

        public Type DotNetType
        {
            get { return dotNetType; }
        }

        public DbType DbType
        {
            get { return dbType; }
        }

        public bool IsPrimaryKey
        {
            get { return isPrimaryKey; }
        }

        public bool IsRequired
        {
            get { return isRequired; }
        }

        public bool IsSystem
        {
            get { return isSystem; }
        }

        public bool IsConcurrencyFlag
        {
            get { return isConcurrencyFlag; }
        }

        public string DefaultValue
        {
            get { return defaultValue; }
        }

        public DateTime LastModified
        {
            get { return lastModified; }
        }

        public DictionaryItem(DataRow row)
        {
            id = (int)row[DictionaryItem.ID];
            parentId = (int)row[DictionaryItem.PARENTID];
            metaName = (string)row[DictionaryItem.METANAME];
            physicalName = (string)row[DictionaryItem.PHYSICALNAME];
            caption = (string)row[DictionaryItem.CAPTION];
            itemType = (DictionaryItemTypes)row[DictionaryItem.ITEMTYPE];

            if (row.IsNull(DictionaryItem.DOTNETTYPE))
                dotNetType = typeof(Object);
            else
                dotNetType = Type.GetType((string)row[DictionaryItem.DOTNETTYPE]);

            if (row.IsNull(DictionaryItem.DBTYPE))
                dbType = DbType.Object;
            else
                dbType = (DbType)Enum.Parse(typeof(DbType), (string)row[DictionaryItem.DBTYPE]);

            isPrimaryKey = (row.IsNull(DictionaryItem.ISPRIMARYKEY) ? false : (bool)row[DictionaryItem.ISPRIMARYKEY]);
            isRequired = (row.IsNull(DictionaryItem.ISREQUIRED) ? false : (bool)row[DictionaryItem.ISREQUIRED]);
            isSystem = (bool)row[DictionaryItem.ISSYSTEM];
            isConcurrencyFlag = (row.IsNull(DictionaryItem.ISCONCURRENCYFLAG) ? false : (bool)row[DictionaryItem.ISCONCURRENCYFLAG]);
            defaultValue = (row.IsNull(DictionaryItem.DEFAULTVALUE) ? "" : (string)row[DictionaryItem.DEFAULTVALUE]);
            lastModified = (DateTime)row[DictionaryItem.LASTMODIFIED];
        }
    }
}
