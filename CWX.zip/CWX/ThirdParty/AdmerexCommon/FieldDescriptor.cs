﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Admerex.Common
{
    // TODO: Define a base class and then create specific classes for each type
    //       of control (i.e. DescriptorBase, ComboBoxDescriptor, textBoxDescriptor).
    public enum ControlTypes
    {
        Unspecified = 0,
        ComboBox = 1,
        NumericTextBox = 2,
        TextBox = 3,
        DatePicker = 4
    }

    public class FieldDescriptor
    {
        private string fieldMetaName;
        private ControlTypes controlType = ControlTypes.Unspecified;
        private List<ComparisonOperators> allowedOperators = new List<ComparisonOperators>();
        private List<FieldItem> items = new List<FieldItem>();
        private string fieldDataSource;
        private string fieldDataMember;
        private string fieldDataText;
        private string fieldDataValue;
        private string numericType;
        private int decimalDigits;

        public string FieldMetaName
        {
            get { return fieldMetaName; }
            set { fieldMetaName = value; }
        }
        public ControlTypes ControlType
        {
            get { return controlType; }
            set { controlType = value; }
        }
        public List<ComparisonOperators> AllowedOperators
        {
            get { return allowedOperators; }
            set { allowedOperators = value; }
        }
        public string FieldDataSource
        {
            get { return fieldDataSource; }
            set { fieldDataSource = value; }
        }
        public string FieldDataMember
        {
            get { return fieldDataMember; }
            set { fieldDataMember = value; }
        }
        public string FieldDataText
        {
            get { return fieldDataText; }
            set { fieldDataText = value; }
        }
        public string FieldDataValue
        {
            get { return fieldDataValue; }
            set { fieldDataValue = value; }
        }
        public List<FieldItem> Items
        {
            get { return items; }
            set { items = value; }
        }
        public string NumericType
        {
            get { return numericType; }
            set { numericType = value; }
        }
        public int DecimalDigits
        {
            get { return decimalDigits; }
            set { decimalDigits = value; }
        }
    }

    public class FieldItem
    {
        private string dataText;
        private string dataValue;

        public FieldItem()
        {
        }

        public FieldItem(string fieldText, string fieldValue)
        {
            dataText = fieldText;
            dataValue = fieldValue;
        }

        public string DataText
        {
            get { return dataText; }
            set { dataText = value; }
        }
        public string DataValue
        {
            get { return dataValue; }
            set { dataValue = value; }
        }
    }
}
