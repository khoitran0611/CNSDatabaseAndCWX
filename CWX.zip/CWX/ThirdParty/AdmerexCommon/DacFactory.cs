using System;
using System.Collections;
using System.Collections.Generic;
using Admerex.Common;

namespace Admerex.Security.Data
{
    /// <remarks>
    /// The only way to obtain a reference to a data access component
    /// should be through the DacFactory.
    /// </remarks>
    public class DacFactory
    {
        private Dictionary<Type, BaseDac> cachedDacs;

        private static DacFactory instance;

        private DacFactory()
        {
            cachedDacs = new Dictionary<Type, BaseDac>();
        }

        public static DacFactory Instance
        {
            get
            {
                if (instance == null)
                    instance = new DacFactory();

                return instance;
            }
        }

        public BaseDac GetDac(Type type)
        {
            if (!cachedDacs.ContainsKey(type) || cachedDacs[type] == null)
                cachedDacs.Add(type, (BaseDac)Activator.CreateInstance(type, true));

            return cachedDacs[type];
        }
    }
}
