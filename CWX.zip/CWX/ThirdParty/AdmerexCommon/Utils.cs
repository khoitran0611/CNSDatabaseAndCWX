using System;
using System.Collections.Generic;
using System.Text;

namespace Admerex.Common
{
    public static class Utils
    {
        public static string GetComparisonOperatorText(ComparisonOperators code)
        {
            switch (code)
            {
                case ComparisonOperators.Equal:
                    return "=";
                case ComparisonOperators.Greater:
                    return ">";
                case ComparisonOperators.Less:
                    return "<";
                case ComparisonOperators.GreaterEqual:
                    return ">=";
                case ComparisonOperators.LessEqual:
                    return "<=";
                case ComparisonOperators.NotEqual:
                    return "<>";
                case ComparisonOperators.Like:
                    return "LIKE";
                default:
                    return "";
            }
        }

        public static string GetLogicalOperatorText(LogicalOperators code)
        {
            switch (code)
            {
                case LogicalOperators.AND:
                    return "AND";
                case LogicalOperators.OR:
                    return "OR";
                default:
                    return "";
            }
        }
    }
}
