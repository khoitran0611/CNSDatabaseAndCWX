using System;
using System.Collections.Generic;
using System.Text;

namespace Admerex.Common
{
    public static class DbDataSourceFactory
    {
        public static DbDataSource CreateDataSource(string sourceType, string sourceConnectionString)
        {
            DataSourceTypes theSourceType = (DataSourceTypes)Enum.Parse(typeof(DataSourceTypes), sourceType);

            switch (theSourceType)
            {
                case DataSourceTypes.SqlServer:
                    return new SqlDataSource(sourceConnectionString);

                case DataSourceTypes.Oracle:
                    return new OracleDataSource(sourceConnectionString);

                default:
                    return null;
            }
        }
    }
}
