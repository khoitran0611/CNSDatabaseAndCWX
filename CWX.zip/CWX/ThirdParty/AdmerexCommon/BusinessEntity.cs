using System;
using System.Data;
using System.Data.Common;
using System.Collections.Generic;
using System.Reflection;
using Admerex.Common.Exceptions;

namespace Admerex.Common
{
    /// <summary>
    /// This is the base class for all the business entities in the system.
    /// </summary>
    public abstract class BusinessEntity
    {

        protected DataSet dataSet;

        protected BusinessEntity()
        {
            dataSet = new DataSet();
            Initialise();
        }

        /// <summary>
        /// Give public access to the underlying data set.
        /// </summary>
        /// <remarks>
        /// By default public external access is allowed to the data set,
        /// but there are cases when the access should be restricted to
        /// only a few carefully chosen public methods. In such cases, in
        /// order to restrict access to the underlying data this property 
        /// should be overridden and null could be returned instead.
        /// </remarks>
        public virtual DataSet DataSet { get { return dataSet; } }

        /// <summary>
        /// Initialise the data set.
        /// </summary>
        /// <remarks>
        /// Usually different data access components will be called in here
        /// and the results will be aggregated inside the underlying data set.
        /// Also, this is the right place to setup any required relations between
        /// the tables inside the data set, define event handlers or customise the
        /// data set tables (e.g. adding computed columns etc).
        /// </remarks>
        protected abstract void Initialise();

        /// <summary>
        /// Reset this business entity.
        /// </summary>
        public virtual void Reset() { }

        /// <summary>
        /// Override this method to specify the validation for this business entity.
        /// </summary>
        /// <param name="errors">
        /// The list of errors returned in case the process fails.
        /// </param>
        protected virtual bool PerformValidation(List<string> errors)
        {
            throw new BusinessException(DataDictionary.Instance.GetString("ERR_BE_SAVE_NOT_IMPLEMENTED"));
        }
        
        // I just could not make up my mind which option would be better that's why I kept both.
        // Option 1:
        // In this version most of the work is done in this base class and all the writer
        // of the concrete business entity has to do is implement the actual save process
        // without having to worry about handling any transactions (see UserRegistration).
        // Option 2:
        // In this version everything is left to be done in the concrete business entity 
        // (see UserRegistration). Therefore the writer of the concrete business entities
        // has a more difficult job, but on the other hand s/he also has better control
        // over the whole process.

        #region Option No 1

        /// <summary>
        /// Override this method to save this business entity.
        /// </summary>
        /// <param name="tran">
        /// The business entity must be saved as part of this database transaction.
        /// </param>
        protected virtual void PerformSave(DbTransaction tran)
        {
            throw new BusinessException(DataDictionary.Instance.GetString("ERR_BE_SAVE_NOT_IMPLEMENTED"));
        }

        /// <summary>
        /// Override this method to save this business entity.
        /// </summary>
        /// <param name="tran">
        /// The business entity must be saved as part of this database transaction.
        /// </param>
        /// <param name="errors">
        /// The list of errors returned in case the process fails.
        /// </param>
        private bool InternalSave(DbTransaction tran, List<string> errors)
        {
            // TODO: Revise this now that I've added the tran in the dac
            DbConnection conn = null;

            if (tran == null)
            {
                conn = Foundation.DataSource.CreateConnection();

                try
                {
                    conn.Open();
                }
                catch (Exception ex)
                {
                    string errMsg = DataDictionary.Instance.GetString("ERR_DB_CONN_OPEN_FAILED");
                    errors.Add(errMsg);
                    string exstring = ex.Message.ToString();

                    return false;
                }

                tran = conn.BeginTransaction();
            }

            try
            {
                PerformSave(tran);

                if (conn != null)
                    tran.Commit();

                return true;
            }
            catch (BusinessException ex)
            {
                if (conn != null)
                    tran.Rollback();

                errors.Add(ex.Message);

                return false;
            }
            finally
            {
                if (conn != null)
                    conn.Close();
            }
        }

        /// <summary>
        /// Save this business entity.
        /// </summary>
        public bool Save()
        {
            List<string> errors = new List<string>();
            return PerformValidation(errors) && InternalSave(null, errors);
        }

        /// <summary>
        /// Save this business entity.
        /// </summary>
        /// <param name="tran">
        /// The business entity must be saved as part of this database transaction.
        /// </param>
        public bool Save(DbTransaction tran)
        {
            List<string> errors = new List<string>();
            return PerformValidation(errors) && InternalSave(tran, errors);
        }

        /// <summary>
        /// Save this business entity.
        /// </summary>
        /// <param name="errors">
        /// The list of errors returned in case the process fails.
        /// </param>
        public bool Save(List<string> errors)
        {
            return PerformValidation(errors) && InternalSave(null, errors);
        }

        /// <summary>
        /// Save this business entity.
        /// </summary>
        /// <param name="tran">
        /// The business entity must be saved as part of this database transaction.
        /// </param>
        /// <param name="errors">
        /// The list of errors returned in case the process fails.
        /// </param>
        public bool Save(DbTransaction tran, List<string> errors)
        {
            return PerformValidation(errors) && InternalSave(tran, errors);
        }

        #endregion

        #region Option No 2

        ///// <summary>
        ///// Override this method to save this business entity.
        ///// </summary>
        ///// <param name="tran">
        ///// The business entity must be saved as part of this database transaction.
        ///// </param>
        ///// <param name="errors">
        ///// The list of errors returned in case the process fails.
        ///// </param>
        //protected virtual void PerformSave(DbTransaction tran, List<string> errors)
        //{
        //    throw new BusinessException(DataDictionary.Instance.GetString("ERR_BE_SAVE_NOT_IMPLEMENTED"));
        //}

        ///// <summary>
        ///// Save this business entity.
        ///// </summary>
        //public bool Save()
        //{
        //    List<string> errors = new List<string>();
        //    return PerformValidation(errors) && PerformSave(null, errors);
        //}

        ///// <summary>
        ///// Save this business entity.
        ///// </summary>
        ///// <param name="tran">
        ///// The business entity must be saved as part of this database transaction.
        ///// </param>
        //public bool Save(DbTransaction tran)
        //{
        //    List<string> errors = new List<string>();
        //    return PerformValidation(errors) && PerformSave(tran, errors);
        //}

        ///// <summary>
        ///// Save this business entity.
        ///// </summary>
        ///// <param name="errors">
        ///// The list of errors returned in case the process fails.
        ///// </param>
        //public bool Save(List<string> errors)
        //{
        //    return PerformValidation(errors) && PerformSave(null, errors);
        //}

        ///// <summary>
        ///// Save this business entity.
        ///// </summary>
        ///// <param name="tran">
        ///// The business entity must be saved as part of this database transaction.
        ///// </param>
        ///// <param name="errors">
        ///// The list of errors returned in case the process fails.
        ///// </param>
        //public bool Save(DbTransaction tran, List<string> errors)
        //{
        //    return PerformValidation(errors) && PerformSave(tran, errors);
        //}

        #endregion
    }
}
