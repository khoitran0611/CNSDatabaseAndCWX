using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using Admerex.Common.Exceptions;

using Microsoft.Practices.EnterpriseLibrary.Data;
using CWX.Core.Common;

namespace Admerex.Common
{
    /// <summary>
    /// This is the base class for all the data access components in the system.
    /// </summary>
    /// <remarks>
    /// 1.  Classes derived from BaseDac should be the only classes in the System
    ///     containing SQL statements.
    /// 2.  These classes should be stateless.
    /// 3.  All the constructors in the derived classes should be declared internal.
    /// </remarks>
    public abstract class BaseDac
    {
        /// <summary>
        /// This is the metaName of the table.
        /// </summary>
        public abstract string TableName { get; }

        #region Public Methods

        /// <summary>
        /// Get the schema of the underlying table. 
        /// </summary>
        /// <param name="dataTableName">The name to be used for the resulting data table</param>
        /// <remarks>
        /// No rows are retrieved from the database, only the
        /// information related to the structure of the underlying table.
        /// </remarks>
        public DataTable GetSchema(string dataTableName)
        {
            DataTable dt = GetTable(dataTableName, "select " + GetAllFields(false) + " from #" + TableName + "#", false);

            DictionaryItem[] primaryKeyItems = DataDictionary.Instance.GetPrimaryKeysForTable(TableName);

            if (primaryKeyItems.Length > 0)
            {
                DataColumn[] tablePrimaryKeys = new DataColumn[primaryKeyItems.Length];

                for (int i = 0; i < primaryKeyItems.Length; i++)
                    tablePrimaryKeys[i] = dt.Columns[primaryKeyItems[i].MetaName];

                dt.PrimaryKey = tablePrimaryKeys;
            }

            return dt;
        }

        /// <summary>
        /// Get the schema of the underlying table, but only include the
        /// columns asked for.
        /// </summary>
        /// <param name="dataTableName">The name to be used for the resulting data table</param>
        public DataTable GetSchema(string dataTableName, string[] columns)
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < columns.Length; i++)
            {
                if (i > 0) sb.Append(",");

                sb.Append("#");
                sb.Append(columns[i]);
                sb.Append("# AS ");
                sb.Append(columns[i]);
            }

            return GetTable(dataTableName, "select " + sb.ToString() + " from #" + TableName + "#", false);
        }

        /// <summary>
        /// Get all the rows in the underlying table (include all the defined columns).
        /// </summary>
        /// <param name="dataTableName">The name to be used for the resulting data table</param>
        /// <remarks>
        /// It is not necessary to call GetSchema first, because this method will
        /// automatically create the structure of the underlying table.
        /// </remarks>
        public DataTable GetAllRows(string dataTableName)
        {
            return GetAllRows(dataTableName, new Dictionary<string, string>(0));
        }

        /// <summary>
        /// Get all the rows in the underlying table (include all the defined columns).
        /// </summary>
        /// <param name="dataTableName">The name to be used for the resulting data table</param>
        /// <param name="sort">The fields used to sort the result set</param>
        /// <remarks>
        /// It is not necessary to call GetSchema first, because this method will
        /// automatically create the structure of the underlying table.
        /// </remarks>
        public DataTable GetAllRows(string dataTableName, Dictionary<string, string> sort)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select ");
            sb.Append(GetAllFields(false));
            sb.Append(" from #");
            sb.Append(TableName);
            sb.Append("#");

            if (sort.Count > 0)
            {
                sb.Append(" order by ");

                int i = 0;

                foreach (KeyValuePair<string, string> kvp in sort)
                {
                    if (i > 0)
                        sb.Append(",");

                    sb.Append("#");
                    sb.Append(kvp.Key);
                    sb.Append("# ");
                    sb.Append(kvp.Value);

                    i++;
                }
            }

            DataTable dt = GetTable(dataTableName, sb.ToString(), true);

            DictionaryItem[] primaryKeyItems = DataDictionary.Instance.GetPrimaryKeysForTable(TableName);

            if (primaryKeyItems.Length > 0)
            {
                DataColumn[] tablePrimaryKeys = new DataColumn[primaryKeyItems.Length];

                for (int i = 0; i < primaryKeyItems.Length; i++)
                    tablePrimaryKeys[i] = dt.Columns[primaryKeyItems[i].MetaName];

                dt.PrimaryKey = tablePrimaryKeys;
            }

            return dt;
        }

        /// <summary>
        /// Get all the rows in the underlying table, but use only the given columns.
        /// </summary>
        /// <param name="dataTableName">The name to be used for the resulting data table</param>
        public DataTable GetAllRows(string dataTableName, string[] columns)
        {
            return GetAllRows(dataTableName, columns, new Dictionary<string, string>(0));
        }

        public DataTable GetAllRows(string dataTableName, string[] columns, Dictionary<string, string> sort)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select ");

            for (int i = 0; i < columns.Length; i++)
            {
                if (i > 0) sb.Append(",");

                sb.Append("#");
                sb.Append(columns[i]);
                sb.Append("# AS ");
                sb.Append(columns[i]);
            }

            sb.Append(" from #");
            sb.Append(TableName);
            sb.Append("#");

            if (sort.Count > 0)
            {
                sb.Append(" order by ");

                int i = 0;

                foreach (KeyValuePair<string, string> kvp in sort)
                {
                    if (i > 0)
                        sb.Append(",");

                    sb.Append("#");
                    sb.Append(kvp.Key);
                    sb.Append("# ");
                    sb.Append(kvp.Value);

                    i++;
                }
            }

            return GetTable(dataTableName, sb.ToString(), true);
        }

        /// <summary>
        /// Fill the table (load all the rows in the underlying table).
        /// </summary>
        /// <remarks>
        /// The method determines what columns to use from the given table.
        /// </remarks>
        public void Fill(DataTable dt)
        {
            Fill(dt, new Dictionary<string, string>(0));
        }

        public void Fill(DataTable dt, Dictionary<string, string> sort)
        {
            if (dt == null)
                throw new DacException(DataDictionary.Instance.GetString("ERR_DAC_WRONG_FILLTABLE_USAGE"));

            StringBuilder sb = new StringBuilder();
            sb.Append("select ");
            sb.Append(GetColumns(dt, false));
            sb.Append(" from #");
            sb.Append(TableName);
            sb.Append("#");

            if (sort.Count > 0)
            {
                sb.Append(" order by ");

                int i = 0;

                foreach (KeyValuePair<string, string> kvp in sort)
                {
                    if (i > 0)
                        sb.Append(",");

                    sb.Append("#");
                    sb.Append(kvp.Key);
                    sb.Append("# ");
                    sb.Append(kvp.Value);

                    i++;
                }
            }

            FillTable(dt, sb.ToString());
        }

        /// <summary>
        /// Fill the table based on the given criteria.
        /// </summary>
        /// <remarks>
        /// The method determines what columns to use from the given table.
        /// </remarks>
        public void Fill(DataTable dt, Dictionary<string, object> criteria)
        {
            Fill(dt, criteria, new Dictionary<string, string>(0));
        }

        public void Fill(DataTable dt, Dictionary<string, object> criteria, Dictionary<string, string> sort)
        {
            if (criteria.Count > 0)
            {
                if (dt == null)
                    throw new DacException(DataDictionary.Instance.GetString("ERR_DAC_WRONG_FILLTABLE_USAGE"));

                DbDataSource ds = Foundation.DataSource;

                DbParameter[] parameters = new DbParameter[criteria.Count];
                StringBuilder sb = new StringBuilder();

                sb.Append("select ");
                sb.Append(GetColumns(dt, false));
                sb.Append(" from #");
                sb.Append(TableName);
                sb.Append("#");

                if (criteria.Count > 0)
                {
                    sb.Append(" where ");

                    int i = 0;

                    foreach (KeyValuePair<string, object> kvp in criteria)
                    {
                        DictionaryItem di = DataDictionary.Instance.GetFieldItem(kvp.Key);

                        if (di == null)
                            throw new DacException(String.Format(DataDictionary.Instance.GetString("ERR_DAC_INVALID_FIELD"), kvp.Key));

                        if (i > 0)
                            sb.Append(" and ");

                        sb.Append("(#");
                        sb.Append(di.MetaName);
                        sb.Append("# = ");
                        sb.Append(ds.GetParameterName(di.MetaName + i.ToString()));
                        sb.Append(")");

                        DbParameter param = ds.CreateParameter();
                        param.IsNullable = !di.IsRequired;
                        param.ParameterName = ds.GetParameterName(di.MetaName + i.ToString());
                        param.SourceColumn = di.PhysicalName;
                        param.DbType = di.DbType;
                        param.Value = kvp.Value;

                        parameters[i] = param;

                        i++;
                    }
                }

                if (sort.Count > 0)
                {
                    sb.Append(" order by ");

                    int i = 0;

                    foreach (KeyValuePair<string, string> kvp in sort)
                    {
                        if (i > 0)
                            sb.Append(",");

                        sb.Append("#");
                        sb.Append(kvp.Key);
                        sb.Append("# ");
                        sb.Append(kvp.Value);

                        i++;
                    }
                }

                FillTable(dt, sb.ToString(), parameters);
            }
        }

        /// <summary>
        /// Insert all the new records.
        /// </summary>
        public int Insert(DbTransaction tran, DataTable dt)
        {
            return Insert(tran.Connection, tran, dt, TableName);
        }

        /// <summary>
        /// No transaction, just insert the new records.
        /// </summary>
        public int Insert(DataTable dt)
        {
            DbConnection conn = Foundation.DataSource.CreateConnection();

            conn.Open();

            try
            {
                return Insert(conn, null, dt, TableName);
            }
            finally
            {
                conn.Close();
            }
        }

        /// <summary>
        /// Update all the modified records.
        /// </summary>
        /// <remarks>
        /// By default this method only updates the modified columns, but
        /// it can be overriden if a different behaviour is required.
        /// </remarks>
        public virtual int Update(DbTransaction tran, DataTable dt)
        {
            return UpdateModifiedColumns(tran.Connection, tran, dt);
        }

        /// <summary>
        /// No transaction, just update the modified records.
        /// </summary>
        /// <remarks>
        /// By default this method only updates the modified columns, but
        /// it can be overriden if a different behaviour is required.
        /// </remarks>
        public virtual int Update(DataTable dt)
        {
            DbConnection conn = Foundation.DataSource.CreateConnection();

            conn.Open();

            try
            {
                return UpdateModifiedColumns(conn, null, dt);
            }
            finally
            {
                conn.Close();
            }
        }

        /// <summary>
        /// Delete all the records marked for deletion.
        /// </summary>
        public int Delete(DbTransaction tran, DataTable dt)
        {
            return Delete(tran.Connection, tran, dt, TableName);
        }

        /// <summary>
        /// No transaction, just delete the records marked for deletion.
        /// </summary>
        public int Delete(DataTable dt)
        {
            DbConnection conn = Foundation.DataSource.CreateConnection();

            conn.Open();

            try
            {
                return Delete(conn, null, dt, TableName);
            }
            finally
            {
                conn.Close();
            }
        }

        #region Direct database access methods

        // **********************************************************
        // * The following methods access the table directly into the 
        // * database, they do not work with an in memory DataTable
        // * object.
        // **********************************************************

        /// <summary>
        /// Delete all the records in the underlying table.
        /// </summary>
        public int DeleteAll(DbTransaction tran)
        {
            DbConnection conn = null;

            if (tran == null)
            {
                conn = Foundation.DataSource.CreateConnection();

                try
                {
                    conn.Open();
                }
                catch (Exception ex)
                {
                    throw new DacException(DataDictionary.Instance.GetString("ERR_DB_CONN_OPEN_FAILED"), ex);
                }
            }
            else
                conn = tran.Connection;

            DbCommand cmd = conn.CreateCommand();
            cmd.Transaction = tran;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = ParseQuery("delete from #" + TableName + "#");

            try
            {
                return cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new DacException(string.Format(DataDictionary.Instance.GetString("ERR_DAC_FAILED_DELETE_ALL"), TableName), ex);
            }
        }

        /// <summary>
        /// Count all the records in the underlying table.
        /// </summary>
        public int Count()
        {
            return Count(null);
        }

        /// <summary>
        /// Count how many records satisfy the given criteria.
        /// </summary>
        public int Count(Dictionary<string, object> criteria)
        {
            DbDataSource ds = Foundation.DataSource;

            DbConnection conn = ds.CreateConnection();
            DbCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;

            if (criteria == null || criteria.Count < 1)
            {
                cmd.CommandText = ParseQuery("select count(*) from #" + TableName + "#");
            }
            else
            {
                int i = 0;
                StringBuilder sb = new StringBuilder();

                foreach (KeyValuePair<string, object> kvp in criteria)
                {
                    DictionaryItem di = DataDictionary.Instance.GetFieldItem(kvp.Key);

                    if (di == null)
                        throw new DacException(String.Format(DataDictionary.Instance.GetString("ERR_DAC_INVALID_FIELD"), kvp.Key));

                    if (i > 0)
                        sb.Append(" and ");

                    sb.Append("(#");
                    sb.Append(di.MetaName);
                    sb.Append("# = ");
                    sb.Append(ds.GetParameterName(di.MetaName + i.ToString()));
                    sb.Append(")");

                    DbParameter param = ds.CreateParameter();
                    param.IsNullable = !di.IsRequired;
                    param.ParameterName = ds.GetParameterName(di.MetaName + i.ToString());
                    param.SourceColumn = di.PhysicalName;
                    param.DbType = di.DbType;
                    param.Value = kvp.Value;

                    cmd.Parameters.Add(param);

                    i++;
                }

                cmd.CommandText = ParseQuery("select count(*) from #" + TableName + "# where " + sb.ToString());
            }

            try
            {
                conn.Open();
            }
            catch (Exception ex)
            {
                throw new DacException(DataDictionary.Instance.GetString("ERR_DB_CONN_OPEN_FAILED"), ex);
            }

            try
            {
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw new DacException(string.Format(DataDictionary.Instance.GetString("ERR_DAC_COUNT_FAILED"), TableName), ex);
            }
            finally
            {
                conn.Close();
            }
        }

        #endregion

        #endregion

        #region Private & Protected Methods

        // TODO: I should get rid of the connection since I can get it from the transaction
        private int UpdateModifiedColumns(DbConnection conn, DbTransaction tran, DataTable dt)
        {
            DataTable dtModified = dt.GetChanges(DataRowState.Modified);

            if (dtModified == null) return 0;

            int rowsAffected = 0;
            string concurrencyValueScript = "";
            string concurrencyNewFieldName = "";
            DbDataSource ds = Foundation.DataSource;
            DictionaryItem concurrencyItem = DataDictionary.Instance.GetConcurrencyItem(TableName);

            if (concurrencyItem != null)
            {
                concurrencyNewFieldName = "New_" + concurrencyItem.MetaName;
                concurrencyValueScript = ",#" + concurrencyItem.MetaName + "# = " + ds.GetParameterName(concurrencyNewFieldName);
            }

            foreach (DataRow row in dtModified.Rows)
            {
                DbCommand command = conn.CreateCommand();
                command.CommandType = CommandType.Text;
                command.Transaction = tran;

                StringBuilder sbValues = new StringBuilder();

                foreach (DataColumn dc in dtModified.Columns)
                {
                    if (row[dc, DataRowVersion.Current].ToString() != row[dc, DataRowVersion.Original].ToString())
                    {
                        DictionaryItem di = DataDictionary.Instance.GetFieldItem(dc.ColumnName);

                        // Avoid setting the concurrency field. We will handle it separately.
                        if (di != null && (concurrencyItem == null || di.Id != concurrencyItem.Id))
                        {
                            if (sbValues.Length > 0)
                                sbValues.Append(",");

                            sbValues.Append("#");
                            sbValues.Append(di.MetaName);
                            sbValues.Append("# = ");
                            sbValues.Append(ds.GetParameterName(di.MetaName));

                            DbParameter param = ds.CreateParameter();
                            param.IsNullable = !di.IsRequired;
                            param.ParameterName = ds.GetParameterName(di.MetaName);
                            param.SourceColumn = di.PhysicalName;
                            param.DbType = di.DbType;
                            param.Value = row[di.MetaName, DataRowVersion.Current];
                            command.Parameters.Add(param);
                        }
                    }
                }

                // There is nothing to update in this row
                if (sbValues.Length == 0) continue;

                // Handle the concurrency flag details now
                if (concurrencyItem != null)
                {
                    sbValues.Append(concurrencyValueScript);

                    DbParameter param = ds.CreateParameter();
                    param.IsNullable = !concurrencyItem.IsRequired;
                    param.ParameterName = ds.GetParameterName(concurrencyNewFieldName);
                    param.SourceColumn = concurrencyItem.PhysicalName;
                    param.DbType = concurrencyItem.DbType;
                    param.Direction = ParameterDirection.Output;

                    command.Parameters.Add(param);
                }

                StringBuilder sbWhere = new StringBuilder();

                DictionaryItem[] items = DataDictionary.Instance.GetPrimaryKeysForTable(TableName);

                foreach (DictionaryItem di in items)
                {
                    if (sbWhere.Length > 0)
                        sbWhere.Append(" and ");

                    sbWhere.Append("(#");
                    sbWhere.Append(di.MetaName);
                    sbWhere.Append("# = ");
                    sbWhere.Append(ds.GetParameterName("Original_" + di.MetaName));
                    sbWhere.Append(")");

                    DbParameter param = ds.CreateParameter();
                    param.IsNullable = !di.IsRequired;
                    param.ParameterName = ds.GetParameterName("Original_" + di.MetaName);
                    param.SourceColumn = di.PhysicalName;
                    param.DbType = di.DbType;
                    param.Value = row[di.MetaName, DataRowVersion.Original];
                    command.Parameters.Add(param);
                }

                if (sbWhere.Length > 0)
                {
                    string prefixScript = "";

                    if (concurrencyItem != null)
                    {
                        sbWhere.Append(" and (#");
                        sbWhere.Append(concurrencyItem.MetaName);
                        sbWhere.Append("# = ");
                        sbWhere.Append(ds.GetParameterName("Original_" + concurrencyItem.MetaName));
                        sbWhere.Append(")");

                        DbParameter param = ds.CreateParameter();
                        param.IsNullable = !concurrencyItem.IsRequired;
                        param.ParameterName = ds.GetParameterName("Original_" + concurrencyItem.MetaName);
                        param.SourceColumn = concurrencyItem.PhysicalName;
                        param.DbType = concurrencyItem.DbType;
                        param.Value = row[concurrencyItem.MetaName, DataRowVersion.Original];
                        command.Parameters.Add(param);

                        prefixScript = ds.GetConcurrencySettingScript(concurrencyNewFieldName);
                    }

                    command.CommandText = ParseQuery(prefixScript + "update #" + TableName + "# set " + sbValues.ToString() + " where " + sbWhere.ToString());

                    try
                    {
                        rowsAffected += command.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        throw new DacException(string.Format(DataDictionary.Instance.GetString("ERR_DAC_FAILED_UPDATE"), TableName), ex);
                    }
                }
            }

            return rowsAffected;
        }

        private string GetPhysicalNameFor(Match m)
        {
            string metaName = m.ToString().Replace("#", "");

            DictionaryItem di = DataDictionary.Instance.GetItemByMetaName(metaName);

            if (di == null)
                throw new DacException(String.Format(DataDictionary.Instance.GetString("ERR_DAC_INVALID_METANAME"), metaName));

            switch (di.ItemType)
            {
                case DictionaryItemTypes.Table:
                case DictionaryItemTypes.Field:
                    return di.PhysicalName;
            }

            return "";
        }

        protected string ParseQuery(string query)
        {
            return Regex.Replace(query, @"#\w+#", new MatchEvaluator(GetPhysicalNameFor));
        }

        protected string GetColumns(DataTable dt, bool prefixed)
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < dt.Columns.Count; i++)
            {
                DictionaryItem di = DataDictionary.Instance.GetFieldItem(dt.Columns[i].ColumnName);

                if (di != null)
                {
                    if (i > 0) sb.Append(",");

                    if (prefixed)
                    {
                        sb.Append("#");
                        sb.Append(TableName);
                        sb.Append("#");
                        sb.Append(".");
                    }

                    sb.Append("#");
                    sb.Append(di.MetaName);
                    sb.Append("# AS ");
                    sb.Append(di.MetaName);
                }
            }

            return sb.ToString();
        }

        /// <summary>
        /// Gets a table from the database according to the specified criteria
        /// </summary>
        /// <param name="dataTableName">The name to be used for the resulting data table</param>
        /// <param name="sqlStmt">The SQL statement used to define/retrieve the result set</param>
        /// <param name="filled">Whether or not the resulting table should be returned filled with data</param>
        /// <returns></returns>
        protected DataTable GetTable(string dataTableName, string sqlStmt, bool filled)
        {
            DbDataSource ds = Foundation.DataSource;

            DbConnection conn = ds.CreateConnection();

            DbCommand command = conn.CreateCommand();
            command.CommandType = CommandType.Text;
            command.CommandText = ParseQuery(sqlStmt);

            return GetTable(dataTableName, command, filled);
        }

        protected DataTable GetTable(string dataTableName, DbCommand selectCommand, bool filled)
        {
            DbDataAdapter da = Foundation.DataSource.CreateDataAdapter();
            da.SelectCommand = selectCommand;

            DataTable dt = new DataTable(dataTableName);

            if (filled)
                da.Fill(dt);
            else
                da.FillSchema(dt, SchemaType.Mapped);

            for (int i = 0; i < dt.Columns.Count; i++)
            {
                DictionaryItem di = DataDictionary.Instance.GetFieldItem(dt.Columns[i].ColumnName);

                if (di != null)
                {
                    dt.Columns[i].Caption = di.Caption;

                    if (di.DefaultValue != null && di.DefaultValue.Length > 0)
                        dt.Columns[i].DefaultValue = Convert.ChangeType(di.DefaultValue, dt.Columns[i].DataType);
                }
            }

            return dt;
        }

        protected void FillTable(DataTable dt, string stmt)
        {
            if (dt.Columns.Count < 1)
                throw new DacException(DataDictionary.Instance.GetString("ERR_DAC_WRONG_FILLTABLE_USAGE"));

            DbDataSource ds = Foundation.DataSource;

            DbConnection conn = ds.CreateConnection();

            DbCommand command = conn.CreateCommand();
            command.CommandType = CommandType.Text;
            command.CommandText = ParseQuery(stmt);

            DbDataAdapter da = ds.CreateDataAdapter();
            da.SelectCommand = command;
            da.Fill(dt);
        }

        protected void FillTable(DataTable dt, string stmt, DbParameter[] parameters)
        {
            try
            {
                if (dt.Columns.Count < 1)
                    throw new DacException(DataDictionary.Instance.GetString("ERR_DAC_WRONG_FILLTABLE_USAGE"));

                DbDataSource ds = Foundation.DataSource;

                DbConnection conn = ds.CreateConnection();

                DbCommand command = conn.CreateCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = ParseQuery(stmt);

                foreach (DbParameter param in parameters)
                    command.Parameters.Add(param);

                DbDataAdapter da = ds.CreateDataAdapter();
                da.SelectCommand = command;
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void FillTable(DataTable dt, DbCommand selectCommand)
        {
            if (dt.Columns.Count < 1)
                throw new DacException(DataDictionary.Instance.GetString("ERR_DAC_WRONG_FILLTABLE_USAGE"));

            DbDataAdapter da = Foundation.DataSource.CreateDataAdapter();
            da.SelectCommand = selectCommand;
            da.Fill(dt);
        }

        /// <summary>
        /// This method returns a string containing all the table columns 
        /// in #META_NAME# AS META_NAME, ... format. Therefore, whenever 
        /// all the fields are required from a certain table this should be
        /// used instead (i.e. instead of SELECT * FROM COMPANIES use
        /// SELECT GetAllFields(false/true) FROM COMPANIES).
        /// </summary>
        protected string GetAllFields(bool prefixed)
        {
            DictionaryItem[] items = DataDictionary.Instance.GetFieldsForTable(TableName);
            
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < items.Length; i++)
            {
                if (i > 0) sb.Append(",");

                if (prefixed)
                {
                    sb.Append("#");
                    sb.Append(TableName);
                    sb.Append("#");
                    sb.Append(".");
                }

                sb.Append("#");
                sb.Append(items[i].MetaName);
                sb.Append("# AS ");
                sb.Append(items[i].MetaName);
            }

            return sb.ToString();
        }

        // TODO: I should get rid of the connection since I can get it from the transaction
        protected int Insert(DbConnection conn, DbTransaction tran, DataTable dt, string dbTable)
        {
            DataTable dtAdded = dt.GetChanges(DataRowState.Added);

            if (dtAdded == null) return 0;

            int rowsAffected = 0;
            DbDataSource ds = Foundation.DataSource;
            DictionaryItem concurrencyItem = DataDictionary.Instance.GetConcurrencyItem(TableName);

            foreach (DataRow row in dtAdded.Rows)
            {
                DbCommand command = conn.CreateCommand();
                command.CommandType = CommandType.Text;
                command.Transaction = tran;

                StringBuilder sbFields = new StringBuilder();
                StringBuilder sbValues = new StringBuilder();

                foreach (DataColumn dc in dtAdded.Columns)
                {
                    DictionaryItem di = DataDictionary.Instance.GetFieldItem(dc.ColumnName);

                    // Avoid setting the concurrency field. We will handle it separately.
                    if (di != null && (concurrencyItem == null || di.Id != concurrencyItem.Id))
                    {
                        if (sbFields.Length > 0)
                            sbFields.Append(",");

                        sbFields.Append("#");
                        sbFields.Append(di.MetaName);
                        sbFields.Append("#");

                        if (sbValues.Length > 0)
                            sbValues.Append(",");

                        sbValues.Append(ds.GetParameterName(di.MetaName));

                        DbParameter param = ds.CreateParameter();
                        param.IsNullable = !di.IsRequired;
                        param.ParameterName = ds.GetParameterName(di.MetaName);
                        param.SourceColumn = di.PhysicalName;
                        param.DbType = di.DbType;
                        param.Value = row[di.MetaName, DataRowVersion.Current];

                        command.Parameters.Add(param);
                    }
                }

                // There is a problem with this row
                if (sbFields.Length == 0) continue;

                // Handle the concurrency flag details now
                if (concurrencyItem != null)
                {
                    sbFields.Append(",");
                    sbFields.Append("#");
                    sbFields.Append(concurrencyItem.MetaName);
                    sbFields.Append("#");

                    sbValues.Append(",");
                    sbValues.Append(ds.GetParameterName(concurrencyItem.MetaName));

                    DbParameter param = ds.CreateParameter();
                    param.IsNullable = !concurrencyItem.IsRequired;
                    param.ParameterName = ds.GetParameterName(concurrencyItem.MetaName);
                    param.SourceColumn = concurrencyItem.PhysicalName;
                    param.DbType = concurrencyItem.DbType;
                    param.Direction = ParameterDirection.Output;

                    command.Parameters.Add(param);
                }

                string prefixScript = "";

                if (concurrencyItem != null)
                    prefixScript = ds.GetConcurrencySettingScript(concurrencyItem.MetaName);

                command.CommandText = ParseQuery(prefixScript + "insert into #" + dbTable + "# (" + sbFields.ToString() + ") values (" + sbValues.ToString() + ")");

                try
                {
                    rowsAffected += command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new DacException(string.Format(DataDictionary.Instance.GetString("ERR_DAC_FAILED_INSERT"), TableName), ex);
                }
            }

            return rowsAffected;
        }

        // TODO: I should get rid of the connection since I can get it from the transaction
        protected int Delete(DbConnection conn, DbTransaction tran, DataTable dt, string dbTable)
        {
            DataTable dtDeleted = dt.GetChanges(DataRowState.Deleted);

            if (dtDeleted == null) return 0;

            DbDataSource ds = Foundation.DataSource;

            DbCommand command = conn.CreateCommand();
            command.CommandType = CommandType.Text;
            command.Transaction = tran;

            DbDataAdapter da = ds.ProviderFactory.CreateDataAdapter();

            DictionaryItem diTable = DataDictionary.Instance.GetTableItem(dbTable);

            if (diTable == null)
                throw new DacException(String.Format(DataDictionary.Instance.GetString("ERR_DAC_INVALID_TABLENAME"), dbTable));

            ITableMapping dtm = da.TableMappings.Add(diTable.PhysicalName, dtDeleted.TableName);

            DictionaryItem[] primaryKeys = DataDictionary.Instance.GetPrimaryKeysForTable(dbTable);

            if (primaryKeys.Length == 0)
                throw new DacException(String.Format(DataDictionary.Instance.GetString("ERR_DAC_NO_PK"), dbTable));

            StringBuilder sb = new StringBuilder();

            foreach (DictionaryItem di in primaryKeys)
            {
                if (sb.Length > 0)
                    sb.Append(" and ");

                sb.Append("(#");
                sb.Append(di.MetaName);
                sb.Append("# = ");
                sb.Append(ds.GetParameterName("Original_" + di.MetaName));
                sb.Append(")");

                DbParameter param = ds.CreateParameter();
                param.IsNullable = !di.IsRequired;
                param.ParameterName = ds.GetParameterName("Original_" + di.MetaName);
                param.SourceColumn = di.PhysicalName;
                param.DbType = di.DbType;
                command.Parameters.Add(param);

                dtm.ColumnMappings.Add(di.PhysicalName, di.MetaName);
            }

            command.CommandText = ParseQuery("delete from #" + dbTable + "# where " + sb.ToString());
            da.DeleteCommand = command;

            try
            {
                return da.Update(dtDeleted);
            }
            catch (Exception ex)
            {
                throw new DacException(string.Format(DataDictionary.Instance.GetString("ERR_DAC_FAILED_DELETE"), TableName), ex);
            }
        }

        protected DataTable ExecuteDataTable(string storedProcedureName, Dictionary<string, object> parameters, int pageSize, int pageIndex, out int rowCount)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
                throw new ArgumentException("StoreProcedureName cannot be empty.");

            Database db = DatabaseFactory.CreateDatabase(ConnectionManager.CWXDatabaseName);
            string sqlCommand = storedProcedureName;
            DbCommand dbCommand = db.GetStoredProcCommand(sqlCommand);
            rowCount = 0;

            foreach (KeyValuePair<string, object> dItem in parameters)
            {
                db.AddInParameter(dbCommand, dItem.Key, GetParameterType(dItem.Value), dItem.Value);
            }

            //db.AddInParameter(dbCommand, "OrderByClause",DbType orderByClause);
            db.AddInParameter(dbCommand, "PageSize", DbType.Int32, pageSize);
            db.AddInParameter(dbCommand, "PageIndex", DbType.Int32, pageIndex);
            db.AddParameter(dbCommand, "RowCount", DbType.Int32, ParameterDirection.ReturnValue, "", DataRowVersion.Current, rowCount);

            DataTable dt = new DataTable();
            dt = db.ExecuteDataSet(dbCommand).Tables[0];

            rowCount = int.Parse(Convert.ToString(db.GetParameterValue(dbCommand, "RowCount")));

            return dt;
        }

        protected DataTable ExecuteDataTable(string storedProcedureName, Dictionary<string, object> parameters)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
                throw new ArgumentException("StoreProcedureName cannot be empty.");

            Database db = DatabaseFactory.CreateDatabase(ConnectionManager.CWXDatabaseName);
            string sqlCommand = storedProcedureName;
            DbCommand dbCommand = db.GetStoredProcCommand(sqlCommand);

            foreach (KeyValuePair<string, object> dItem in parameters)
            {
                db.AddInParameter(dbCommand, dItem.Key, GetParameterType(dItem.Value), dItem.Value);
            }

            return db.ExecuteDataSet(dbCommand).Tables[0];
        }

        private DbType GetParameterType(object parameter)
        {
            string typeName = parameter.GetType().Name;

            if (typeName.ToLower() == "string")
                return DbType.String;
            if (typeName.ToLower() == "int16")
                return DbType.Int16;
            if (typeName.ToLower() == "int32")
                return DbType.Int32;
            if (typeName.ToLower() == "int64")
                return DbType.Int64;
            if (typeName.ToLower() == "boolean")
                return DbType.Boolean;
            if (typeName.ToLower() == "date")
                return DbType.Date;
            if (typeName.ToLower() == "datetime")
                return DbType.DateTime;
            if (typeName.ToLower() == "decimal")
                return DbType.Decimal;
            if (typeName.ToLower() == "double")
                return DbType.Double;
            if (typeName.ToLower() == "guid")
                return DbType.Guid;
            else
                throw new Exception("Cannot find type: " + typeName);
        }

        #endregion
    }
}
