using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data;
using System.Data.Common;
using System.Xml.Serialization;
using Admerex.Common.Exceptions;

namespace Admerex.Common
{
    [XmlRoot("DbDataSource")]
    public class OracleDataSource : DbDataSource
    {
        internal OracleDataSource()
        {
        }

        internal OracleDataSource(string path) : base(path)
        {
        }

        public override DbProviderFactory ProviderFactory
        {
            get { return DbProviderFactories.GetFactory("System.Data.OracleClient"); }
        }

        public override string GetParameterName(string fieldName)
        {
            return ":" + fieldName;
        }

        public override string GetConcurrencySettingScript(string fieldName)
        {
            throw new AdmerexException(DataDictionary.Instance.GetString("MSG_TO_BE_IMPLEMENTED"));
        }

        protected override string[] GetConnectionStringServerKeywords()
        {
            string[] result = {};
            return result;
        }

        protected override string[] GetConnectionStringDatabaseKeywords()
        {
            string[] result = { "Data Source" };
            return result;
        }

        protected override string[] GetConnectionStringUserIdKeywords()
        {
            string[] result = { "Uid", "User Id" };
            return result;
        }

        protected override string[] GetConnectionStringPasswordKeywords()
        {
            string[] result = { "Pwd", "Password" };
            return result;
        }
    }
}
