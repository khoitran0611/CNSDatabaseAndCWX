using System;
using System.Collections.Generic;
using System.Text;

namespace Admerex.Common
{
    public enum DataSourceTypes
    {
        SqlServer = 1,
        Oracle = 2
    }

    public enum DictionaryItemTypes
    {
        Application = 1,
        Table = 2,
        Field = 3
    }

    public enum SortTypes
    {
        Ascending = 1,
        Descending = 2,
        Unsorted = 3
    }

    public enum LogicalOperators
    {
        // TODO: This logical operator list should complete later
        AND = 1,
        OR = 2
    }

    public enum ComparisonOperators
    {
        Equal = 1,
        Greater = 2,
        Less = 3,
        GreaterEqual = 4,
        LessEqual = 5,
        NotEqual = 6,
        Like = 7
    }
}
