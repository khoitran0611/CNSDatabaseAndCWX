using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Xml.Serialization;

using CWX.Core.Common;

namespace Admerex.Common
{
    /// <remarks>
    /// The constructors are declared internal in order to force
    /// anybody trying to create instances of this class from
    /// outside this assembly to use DbDataSourceFactory.
    /// Actually, it is recommended to always use DbDataSourceFactory 
    /// to create data source instances.
    /// </remarks>
    public abstract class DbDataSource
    {
        private string connectionString;

        internal DbDataSource()
        {
        }

        internal DbDataSource(string connectionString)
        {
            if (connectionString != null)
                this.connectionString = connectionString;
        }

        /// <summary>
        /// The information needed to connect to this data source 
        /// </summary>
        public string ConnectionString
        {
            get { return connectionString; }
            set { if (value != null) { connectionString = value; } }
        }

        /// <summary>
        /// Gets the factory to be used for generating objects
        /// (connection, command, etc.) to interact with this data source
        /// </summary>
        public abstract DbProviderFactory ProviderFactory { get; }

        /// <summary>
        /// Creates a new connection to the database.
        /// </summary>
        public DbConnection CreateConnection()
        {
            DbConnection conn = ProviderFactory.CreateConnection();
            conn.ConnectionString = connectionString;
            return conn;
        }

        /// <summary>
        /// Creates a new parameter.
        /// </summary>
        public DbParameter CreateParameter()
        {
            return ProviderFactory.CreateParameter();
        }

        /// <summary>
        /// Creates a new data adapter.
        /// </summary>
        public DbDataAdapter CreateDataAdapter()
        {
            return ProviderFactory.CreateDataAdapter();
        }

        /// <summary>
        /// Gets the parameter name formatted properly for this data source.
        /// </summary>
        public abstract string GetParameterName(string fieldName);

        /// <summary>
        /// Gets the sql script that sets a new value for the concurrency flag.
        /// </summary>
        public abstract string GetConcurrencySettingScript(string fieldName);

        /// <summary>
        /// Extracts the server name from this data source's connection string
        /// </summary>
        public string GetServerName()
        {
            return GetServerName(connectionString);
        }

        /// <summary>
        /// Extracts the server name from the given connection string
        /// </summary>
        public string GetServerName(string someConnectionString)
        {
            string[] connectionElements = someConnectionString.Split(';');

            foreach (string element in connectionElements)
            {
                string[] parts = element.Split('=');

                if (parts.Length == 2)
                {
                    string name = parts[0].Trim().ToLower();
                    string value = parts[1];

                    foreach (string keyword in GetConnectionStringServerKeywords())
                    {
                        if (name == keyword.ToLower())
                        {
                            return value;
                        }
                    }
                }
            }

            return "";
        }

        /// <summary>
        /// Extracts the database name from this data source's connection string
        /// </summary>
        public string GetDatabaseName()
        {
            return GetDatabaseName(connectionString);
        }

        /// <summary>
        /// Extracts the database name from the given connection string
        /// </summary>
        public string GetDatabaseName(string someConnectionString)
        {
            string[] connectionElements = someConnectionString.Split(';');

            foreach (string element in connectionElements)
            {
                string[] parts = element.Split('=');

                if (parts.Length == 2)
                {
                    string name = parts[0].Trim().ToLower();
                    string value = parts[1];

                    foreach (string keyword in GetConnectionStringDatabaseKeywords())
                    {
                        if (name == keyword.ToLower())
                        {
                            return value;
                        }
                    }
                }
            }

            return "";
        }

        /// <summary>
        /// Extracts the user id from this data source's connection string
        /// </summary>
        public string GetUserId()
        {
            return GetUserId(connectionString);
        }

        /// <summary>
        /// Extracts the user id from the given connection string
        /// </summary>
        public string GetUserId(string someConnectionString)
        {
            string[] connectionElements = someConnectionString.Split(';');

            foreach (string element in connectionElements)
            {
                string[] parts = element.Split('=');

                if (parts.Length == 2)
                {
                    string name = parts[0].Trim().ToLower();
                    string value = parts[1];

                    foreach (string keyword in GetConnectionStringUserIdKeywords())
                    {
                        if (name == keyword.ToLower())
                        {
                            return value;
                        }
                    }
                }
            }

            return "";
        }

        /// <summary>
        /// Extracts the password from this data source's connection string
        /// </summary>
        public string GetPassword()
        {
            return GetPassword(connectionString);
        }

        /// <summary>
        /// Extracts the password from the given connection string
        /// </summary>
        public string GetPassword(string someConnectionString)
        {
            string[] connectionElements = someConnectionString.Split(';');

            foreach (string element in connectionElements)
            {
                string[] parts = element.Split('=');

                if (parts.Length == 2)
                {
                    string name = parts[0].Trim().ToLower();
                    string value = parts[1];

                    foreach (string keyword in GetConnectionStringPasswordKeywords())
                    {
                        if (name == keyword.ToLower())
                        {
                            return value;
                        }
                    }
                }
            }

            return "";
        }

        /// <summary>
        /// Gets a list with the possible identifiers of the server
        /// in the connection string
        /// </summary>
        protected abstract string[] GetConnectionStringServerKeywords();

        /// <summary>
        /// Gets a list with the possible identifiers of the database
        /// in the connection string
        /// </summary>
        protected abstract string[] GetConnectionStringDatabaseKeywords();

        /// <summary>
        /// Gets a list with the possible identifiers of the user id
        /// in the connection string
        /// </summary>
        protected abstract string[] GetConnectionStringUserIdKeywords();

        /// <summary>
        /// Gets a list with the possible identifiers of the password
        /// in the connection string
        /// </summary>
        protected abstract string[] GetConnectionStringPasswordKeywords();
    }
}
