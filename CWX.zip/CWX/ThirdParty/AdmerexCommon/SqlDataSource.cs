using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Xml.Serialization;

namespace Admerex.Common
{
    [XmlRoot("DbDataSource")]
    public class SqlDataSource : DbDataSource
    {
        internal SqlDataSource()
        {
        }

        internal SqlDataSource(string path) : base(path)
        {
        }

        public override DbProviderFactory ProviderFactory
        {
            get { return DbProviderFactories.GetFactory("System.Data.SqlClient"); }
        }

        public override string GetParameterName(string fieldName)
        {
            return "@" + fieldName;
        }

        public override string GetConcurrencySettingScript(string fieldName)
        {
            return "set " + GetParameterName(fieldName) + " = getdate();" + Environment.NewLine;
        }

        protected override string[] GetConnectionStringServerKeywords()
        {
            string[] result = { "Server", "Data Source" };
            return result;
        }

        protected override string[] GetConnectionStringDatabaseKeywords()
        {
            string[] result = { "Database", "Initial Catalog" };
            return result;
        }

        protected override string[] GetConnectionStringUserIdKeywords()
        {
            string[] result = { "Uid", "User Id" };
            return result;
        }

        protected override string[] GetConnectionStringPasswordKeywords()
        {
            string[] result = { "Pwd", "Password" };
            return result;
        }
    }
}
