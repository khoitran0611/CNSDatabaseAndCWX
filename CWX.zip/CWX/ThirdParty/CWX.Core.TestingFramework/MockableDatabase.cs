using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;

namespace CWX.Core.TestingFramework
{
    public class MockableDatabase : Database
    {
        public MockableDatabase(string connectionString, DbProviderFactory dbProviderFactory)
            : base(connectionString, dbProviderFactory)
        { 
        }

        protected override void DeriveParameters(DbCommand discoveryCommand)
        {
        }
    }
}
