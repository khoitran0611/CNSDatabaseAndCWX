/*
using System;
using System.Xml;
using System.Data;
using System.Data.Common;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;

using Microsoft.Practices.EnterpriseLibrary.Data;
using NUnit.Framework;
using Rhino.Mocks;

using CWX.Core.Common.Data;
using CWX.Core.Data.UnitTests.TestData;
using CWX.Core.TestingFramework;
using CWX.Core.Providers.Data.Mapping;
using CWX.Core.Providers.Data;



namespace CWX.Core.Data.UnitTests
{
    [TestFixture]
    public class SqlDataProviderTest
    {
        [TestFixtureSetUp]
        public void Setup()
        {             
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
        }

        #region Test Method Insert
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestInsertWithNullTDomainObject()
        {
            SqlDataProvider dataProvider = new SqlDataProvider();
            dataProvider.Insert<TestDomainObject>(null);
        }

        [Test]
        public void TestInsert()
        {
            MockRepository mockRepository = new MockRepository();
            IDataMappingProvider mockedMappingProvider = BuildMockedDataMappingExpectToRepeatOnce(mockRepository);           

            string sqlConnectionString = "Testing Connection";           
            string sqlCommand = "Select Id, Name From EmployeeTb";
            DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.SqlClient");
            MockableDatabase mockedDatabase = mockRepository.CreateMock<MockableDatabase>(new object[] { sqlConnectionString, factory });
            DbCommand insertCommand = mockedDatabase.GetSqlStringCommand(sqlCommand);
            Expect.Call(mockedDatabase.ExecuteNonQuery(insertCommand))         
                .IgnoreArguments()
                .Return(1);

            mockRepository.ReplayAll();

            SqlDataProvider dataProvider = new SqlDataProvider(mockedDatabase, mockedMappingProvider);
            dataProvider.MappingProvider = mockedMappingProvider;

            bool result = dataProvider.Insert<TestDomainObject>(new TestDomainObject());

            Assert.AreEqual(true, result);

            mockRepository.VerifyAll();

        }
        #endregion

        #region Test Method Update
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestUpdateWithNullTDomainObject()
        {
            SqlDataProvider dataProvider = new SqlDataProvider();
            dataProvider.Update<TestDomainObject>(null);
        }

        [Test]
        public void TestUpdate()
        {
            MockRepository mockRepository = new MockRepository();
            IDataMappingProvider mockedMappingProvider = BuildMockedDataMappingExpectToRepeatOnce(mockRepository);
            
            string sqlConnectionString = "Testing Connection";
            string sqlCommand = "Update EmployeeTb";
            DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.SqlClient");

            MockableDatabase mockedDatabase = mockRepository.CreateMock<MockableDatabase>(new object[] { sqlConnectionString, factory });
            DbCommand updateCommand = mockedDatabase.GetSqlStringCommand(sqlCommand);
            Expect.Call(mockedDatabase.ExecuteNonQuery(updateCommand))
                .IgnoreArguments()
                .Return(1);

            mockRepository.ReplayAll();

            SqlDataProvider dataProvider = new SqlDataProvider(mockedDatabase, mockedMappingProvider);
            dataProvider.MappingProvider = mockedMappingProvider;

            bool result = dataProvider.Update<TestDomainObject>(new TestDomainObject());

            Assert.AreEqual(true, result);

            mockRepository.VerifyAll();
        }
        #endregion

        #region Test Method Delete
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]        
        public void TestDeleteWithNullIdentityFields()
        {
            SqlDataProvider dataProvider = new SqlDataProvider();
            dataProvider.Delete<TestDomainObject>(null, new object[] { });
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestDeleteWithNullIdentityValues()
        {
            SqlDataProvider dataProvider = new SqlDataProvider();
            dataProvider.Delete<TestDomainObject>(new string[] { "Id" }, null);
        }

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestDeleteWithLengthOfIdentityFieldsIsEqualZero()
        {
            SqlDataProvider dataProvider = new SqlDataProvider();
            dataProvider.Delete<TestDomainObject>(new string[] { }, new object[] { "1st IdentityValue" });
        }

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestDeleteWithLengthOfIdentityValuesIsEqualZero()
        {
            SqlDataProvider dataProvider = new SqlDataProvider();
            dataProvider.Delete<TestDomainObject>(new string[] {"1st IdentityField" }, new object[] { });
        }

        [Test]
        [ExpectedException(typeof(Exception))]
        public void TestDeleteWithTIdentityButNoPrimaryKey()
        {
            MockRepository mockRepository = new MockRepository();
            TableMappingInfo tableInfo = BuildTestingTableMappingInfoWithNoPrimaryKey();
            IDataMappingProvider dataMappingProvider = mockRepository.CreateMock<IDataMappingProvider>();
            Expect.Call(dataMappingProvider.GetTableMappingInfo(null))
                .IgnoreArguments()
                .Return(tableInfo);

            DbProviderFactory fatory = DbProviderFactories.GetFactory("System.Data.SqlClient");
            MockableDatabase mockableDatabase = mockRepository.CreateMock<MockableDatabase>(new object[] { "SQL Connection String", fatory});
                        
            mockRepository.ReplayAll();

            SqlDataProvider dataProvider = new SqlDataProvider(mockableDatabase, dataMappingProvider);
            dataProvider.Delete<TestDomainObject, int>(1);

            mockRepository.VerifyAll();
        }

        [Test]
        [ExpectedException(typeof(Exception))]
        public void TestDeleteWithTIdentityButTwoPrimaryKey()
        {
            MockRepository mockRepository = new MockRepository();
            TableMappingInfo tableInfo = BuildTestingTableMappingInfoWithNoPrimaryKey();
            IDataMappingProvider dataMappingProvider = mockRepository.CreateMock<IDataMappingProvider>();
            Expect.Call(dataMappingProvider.GetTableMappingInfo(null))
                .IgnoreArguments()
                .Return(tableInfo);

            DbProviderFactory fatory = DbProviderFactories.GetFactory("System.Data.SqlClient");
            MockableDatabase mockableDatabase = mockRepository.CreateMock<MockableDatabase>(new object[] { "SQL Connection String", fatory });
            
            mockRepository.ReplayAll();

            SqlDataProvider dataProvider = new SqlDataProvider(mockableDatabase, dataMappingProvider);
            dataProvider.Delete<TestDomainObject, int>(1);

            mockRepository.VerifyAll();
        }

        [Test]        
        public void TestDeleteWithValidTIdentity()
        {
            MockRepository mockRepository = new MockRepository();
            IDataMappingProvider mockedMappingProvider = BuildMockedDataMappingExpectToRepeatOnce(mockRepository);
            
            DbProviderFactory fatory = DbProviderFactories.GetFactory("System.Data.SqlClient");
            MockableDatabase mockableDatabase = mockRepository.CreateMock<MockableDatabase>(new object[] { "SQL Connection String", fatory });
            DbCommand deleteCommand = mockableDatabase.GetSqlStringCommand("Delete EmployeeTb");
            Expect.Call(mockableDatabase.ExecuteNonQuery(deleteCommand))
                .IgnoreArguments()
                .Return(1);

            mockRepository.ReplayAll();

            SqlDataProvider dataProvider = new SqlDataProvider(mockableDatabase, mockedMappingProvider);
            dataProvider.Delete<TestDomainObject, int>(1);

            mockRepository.VerifyAll();
        }

        [Test]
        public void TestDeleteWithValidIdentityFieldsAndValidIdentityValues()
        {
            MockRepository mockRepository = new MockRepository();
            IDataMappingProvider mockedMappingProvider = BuildMockedDataMappingExpectToRepeatOnce(mockRepository);            

            DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.SqlClient");
            MockableDatabase mockedDatabase = mockRepository.CreateMock<MockableDatabase>(new object[] { "SQL Connection String", factory });
            DbCommand deleteCommand = mockedDatabase.GetSqlStringCommand("Delete EmployeeTb");
            Expect.Call(mockedDatabase.ExecuteNonQuery(deleteCommand))
                .IgnoreArguments()
                .Return(1);

            mockRepository.ReplayAll();

            SqlDataProvider dataProvider = new SqlDataProvider(mockedDatabase, mockedMappingProvider);
            dataProvider.MappingProvider = mockedMappingProvider;

            string[] identityFields = new string[2] {"Id", "Name"};
            object[] identityValues = new object[2] { 1, "Tuan Luong" };

            bool result = dataProvider.Delete<TestDomainObject>(identityFields, identityValues);

            Assert.AreEqual(true, result);

            mockRepository.VerifyAll();
        }
        #endregion

        #region Test Methods Fill
        #region *  Test Method Fill With TDomainObject
        [Test]
        public void TestFillWithValidTDomain()
        {
            MockRepository mockRepository = new MockRepository();
            IDataMappingProvider mockedMappingProvider = BuildMockedDataMappingExpectToRepeatTwice(mockRepository);
            MockableDataReader mockedDataReader = BuildMockedDataReaderExpectToRepeatReadOnceAndReturnsOneFullInfoRecord(mockRepository);
            MockableDatabase mockedDatabase = BuildMockedDataBaseExpectToExecuteReaderFillCommandAndReturnsMockedDataReader(mockRepository, mockedDataReader);

            mockRepository.ReplayAll();

            SqlDataProvider dataProvider = new SqlDataProvider(mockedDatabase, mockedMappingProvider);
            
            TestDomainObject testDomainObject = BuildTestDomainObjectHaveOnlyIdentity();
            TestDomainObject resultTestDomainObject = dataProvider.Fill<TestDomainObject>(testDomainObject);

            Assert.AreEqual("Tuan Luong", resultTestDomainObject.DummyName);

            mockRepository.VerifyAll();
        }
        #endregion

        #region *  Test Method Fill With IdentityFields And IdentityValues
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestFillWithNullIdentityFieldsAndIdentityValues()
        {
            SqlDataProvider dataProvider = new SqlDataProvider();
            dataProvider.Fill<TestDomainObject>(null, new object[] { });
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestFillWithIdentityFieldsAndNullIdentityValues()
        {
            SqlDataProvider dataProvider = new SqlDataProvider();
            dataProvider.Fill<TestDomainObject>(new string[] { "Id" }, null);
        }

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestFillWithIdentityFieldsAndIdentityValuesButLengthOfIdentityFieldsIsGreaterThanToLengthOfIdentityValues()
        {
            SqlDataProvider dataProvider = new SqlDataProvider();
            string[] identityFields = new string[] {"Id", "Name" };
            object[] identityValues = new object[] { 1 };
            dataProvider.Fill<TestDomainObject>(identityFields, identityValues);
        }

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestFillWithIdentityFieldsAndIdentityValuesButLengthOfIdentityFieldsIsLessThanToLengthOfIdentityValues()
        {
            SqlDataProvider dataProvider = new SqlDataProvider();
            string[] identityFields = new string[] { "Id" };
            object[] identityValues = new object[] { 1, 2 };
            dataProvider.Fill<TestDomainObject>(identityFields, identityValues);
        }

        [Test]
        public void TestFillWithValidIdentityFieldsAndValidIdentityValues()
        {
            MockRepository mockRepository = new MockRepository();
            IDataMappingProvider mockedMappingProvider = BuildMockedDataMappingExpectToRepeatTwice(mockRepository);
            MockableDataReader mockedDataReader = BuildMockedDataReaderExpectToRepeatReadOnceAndReturnsOneFullInfoRecord(mockRepository);
            MockableDatabase mockedDatabase = BuildMockedDataBaseExpectToExecuteReaderFillCommandAndReturnsMockedDataReader(mockRepository, mockedDataReader);
            
            mockRepository.ReplayAll();

            SqlDataProvider dataProvider = new SqlDataProvider(mockedDatabase, mockedMappingProvider);
            dataProvider.MappingProvider = mockedMappingProvider;

            string[] identityFields = new string[2] { "Id", "Name" };
            object[] identityValues = new object[2] { 001, "Tuan Luong" };

            TestDomainObject testDomainObject = dataProvider.Fill<TestDomainObject>(identityFields, identityValues);

            TestDomainObject predictedDomainObject = BuildTestDomainObject();

            bool expectedResult = true;

            if (testDomainObject.DummyID != predictedDomainObject.DummyID)
                expectedResult = false;
            if (testDomainObject.DummyName != predictedDomainObject.DummyName)
                expectedResult = false;

            Assert.AreEqual(true, expectedResult);

            mockRepository.VerifyAll();
        }        
        #endregion

        #region *  Test Method Fill With IdentityFields And IdentityValues And FillFields
        //Not test with null IdentityFields or null IdentityValues or IdentityFields's lenth = 0 or IdentityValues's lenth = 0 or
        //IdentityFields's length != IdentityValues's length b/c these tests are passed by testing above methods

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestFillWithIdentityFieldsAndIdentityValuesAndNullFillFields()
        {
            SqlDataProvider dataProvider = new SqlDataProvider();
            dataProvider.Fill<TestDomainObject>(new string[] {"Id" }, new object[] {1 }, null);
        }

        [Test]
        public void TestFillWithValidIdentityFieldsAndValidIdentityValuesAndValidFillFields()
        {
            MockRepository mockRepository = new MockRepository();
            IDataMappingProvider mockedMappingProvider = BuildMockedDataMappingExpectToRepeatTwice(mockRepository);
           
            MockableDataReader mockedDataReader = mockRepository.CreateMock<MockableDataReader>();           
            Expect.Call(mockedDataReader.GetOrdinal("Name"))
                .Return(1)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(1))
                .Return("Tuan Luong")
                .Repeat.Once();
            Expect.Call(mockedDataReader.Read())
                .Return(true);

            MockableDatabase mockedDatabase = BuildMockedDataBaseExpectToExecuteReaderFillCommandAndReturnsMockedDataReader(mockRepository, mockedDataReader);

            mockRepository.ReplayAll();

            SqlDataProvider dataProvider = new SqlDataProvider(mockedDatabase, mockedMappingProvider);
            dataProvider.MappingProvider = mockedMappingProvider;

            string[] identityFields = new string[2] { "Id", "Name" };
            object[] identityValues = new object[2] { 001, "Tuan Luong" };
            string[] fillFields = new string[1] { "Name" };

            TestDomainObject testDomainObject = dataProvider.Fill<TestDomainObject>(identityFields, identityValues, fillFields);

            TestDomainObject predictedDomainObject = BuildTestDomainObject();

            bool expectedResult = true;

            if (testDomainObject.DummyName != predictedDomainObject.DummyName)
                expectedResult = false;

            Assert.AreEqual(true, expectedResult);

            mockRepository.VerifyAll();
        }
        #endregion

        #region *  Test Method Fill From IDataReader
            #region ****************Test Methods Fill From Only IDataReader
            [Test]
            [ExpectedException(typeof(ArgumentNullException))]
            public void TestFillFromReaderWithNullDataReader() 
            {
                SqlDataProvider dataProvider = new SqlDataProvider();
                dataProvider.FillFromReader<TestDomainObject>(null);
            }

            //Methods FillFromIDataReader(IDataReader) and FillFromIDataReader(IDataReader, string[] fillFields) are tested 
            //b/c they are called by above testing methods
            #endregion

            #region ****************Test Methods Fill From IDataReader and Delegate
            [Test]
            public void TestFillFromReaderWithValidReaderAndValidDelegate()
            {
                MockRepository mockRepository = new MockRepository();
                IDataMappingProvider mockedMappingProvider = BuildMockedDataMappingExpectToRepeatOnce(mockRepository);
                MockableDataReader mockableDataReader = BuildMockedDataReaderExpectToRepeatReadOnceAndReturnsOneFullInfoRecord(mockRepository);
                
                DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.SqlClient");
                MockableDatabase mockedDatabase = mockRepository.CreateMock<MockableDatabase>(new object[] { "Testing Connection", factory });
                DbCommand fillCommand = mockedDatabase.GetSqlStringCommand("Select EmployeeTb");                

                mockRepository.ReplayAll();

                SqlDataProvider dataProvider = new SqlDataProvider(mockedDatabase, mockedMappingProvider);            

                string[] identityFields = new string[2] { "Id", "Name" };
                object[] identityValues = new object[2] { 001, "Tuan Luong" };                      

                TestDomainObject testDomainObject = dataProvider.FillFromReader<TestDomainObject>(mockableDataReader, 
                    new CWX.Core.Common.Data.ProcessReader<TestDomainObject>(
                        delegate(IDataReader reader,ref TestDomainObject domainObject)
                        {
                            domainObject.DummyName = "Tuan";
                        })
                        ) ;  

                TestDomainObject predictedDomainObject = BuildTestDomainObject();

                bool expectedResult = true;

                if (testDomainObject.DummyName != "Tuan")
                    expectedResult = false;

                Assert.AreEqual(true, expectedResult);

                mockRepository.VerifyAll();
            }
                
            #endregion

            #region ****************Test Methods Fill From IDataReader and selectedFields and Delegate
            [Test]
            [ExpectedException(typeof(ArgumentNullException))]
            public void TestFillFromReaderWithNullReader()
            {
                SqlDataProvider dataProvider = new SqlDataProvider();
                dataProvider.FillFromReader<TestDomainObject>(null, new string[] {"Id"}, 
                    new ProcessReader<TestDomainObject>(delegate(IDataReader reader, ref TestDomainObject domainObject)
                    {
                        domainObject.DummyName = "Tuan";
                    })
                );
            }

            [Test]
            [ExpectedException(typeof(NullReferenceException))]
            public void TestFillFromReaderWithSelectedFieldDoesNotExistInReaderFieldCollection()
            {
                MockRepository mockRepository = new MockRepository();
                IDataMappingProvider mockedMappingProvider = mockRepository.CreateMock<IDataMappingProvider>();

                TableMappingInfo tableInfo = BuildTestingTableMappingInfo();
                Expect.Call(mockedMappingProvider.GetTableMappingInfo(null))
                    .IgnoreArguments()
                    .Return(tableInfo)
                    .Repeat.Once();

                MockableDataReader mockableDataReader = mockRepository.CreateMock<MockableDataReader>();
                Expect.Call(mockableDataReader.GetOrdinal("Id"))
                    .Return(0)
                    .Repeat.Once();
                Expect.Call(mockableDataReader.GetValue(0))
                    .Return("001")
                    .Repeat.Once();
                Expect.Call(mockableDataReader.GetOrdinal("Name"))
                    .Return(1)
                    .Repeat.Once();
                Expect.Call(mockableDataReader.GetValue(1))
                    .Return("Tuan Luong")
                    .Repeat.Once();

                Expect.Call(mockableDataReader.Read())
                    .Return(true);

                string sqlConnectionString = "Testing Connection";
                string sqlCommand = "Select EmployeeTb";
                DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.SqlClient");
                MockableDatabase mockedDatabase = mockRepository.CreateMock<MockableDatabase>(new object[] { sqlConnectionString, factory });
                DbCommand fillCommand = mockedDatabase.GetSqlStringCommand(sqlCommand);

                mockRepository.ReplayAll();

                SqlDataProvider dataProvider = new SqlDataProvider(mockedDatabase, mockedMappingProvider);

                string[] identityFields = new string[2] { "Id", "Name" };
                object[] identityValues = new object[2] { 001, "Tuan Luong" };
                string[] selectedFields = new string[1] { "Company" };

                TestDomainObject testDomainObject = dataProvider.FillFromReader<TestDomainObject>(mockableDataReader, selectedFields, 
                    new CWX.Core.Common.Data.ProcessReader<TestDomainObject>(
                        delegate(IDataReader reader, ref TestDomainObject domainObject)
                        {
                            domainObject.DummyName = "Tuan";
                        })
                        );
                
                mockRepository.VerifyAll();
                
            }
            #endregion

            #region ****************Test Methods FillList
            public void TestFillListWithValidOrderByClauseAndWhereClause()
            {
                MockRepository mockRepository = new MockRepository();
                IDataMappingProvider mockedMappingProvider = BuildMockedDataMappingExpectToRepeatOnce(mockRepository);
                MockableDataReader mockedDataReader = BuildMockedDataReaderExpectToRepeatReadTwiceTrueOnceFalseAndReturnsTwoFullInfoRecords(mockRepository);
                MockableDatabase mockedDatabase = BuildMockedDataBaseExpectToExecuteReaderFillCommandAndReturnsMockedDataReader(mockRepository, mockedDataReader);
                
                mockRepository.ReplayAll();

                SqlDataProvider dataProvider = new SqlDataProvider(mockedDatabase, mockedMappingProvider);
                Collection<TestDomainObject> testDomainObjectList = dataProvider.FillList<TestDomainObject>("Name","Name like 'Tuan'");
                Collection<TestDomainObject> predictedObjectList = BuildTestDomainObjectList();

                Assert.AreEqual(2, testDomainObjectList.Count);

                bool isSameCollection = true;

                for (int i = 0; i < testDomainObjectList.Count; i++)
                {
                    if (testDomainObjectList[i].DummyID != predictedObjectList[i].DummyID)
                        isSameCollection = false;
                    if (testDomainObjectList[i].DummyName != predictedObjectList[i].DummyName)
                        isSameCollection = false;
                }
                Assert.AreEqual(true, isSameCollection);

                mockRepository.VerifyAll();
            }        
            #endregion
        #endregion

        #endregion

        #region Private Methods
            #region Build Mocked Objects
            private static IDataMappingProvider BuildMockedDataMappingExpectToRepeatOnce(MockRepository mockRepository)
            {
                IDataMappingProvider mockedMappingProvider = mockRepository.CreateMock<IDataMappingProvider>();

                TableMappingInfo tableInfo = BuildTestingTableMappingInfo();
                Expect.Call(mockedMappingProvider.GetTableMappingInfo(null))
                    .IgnoreArguments()
                    .Return(tableInfo)
                    .Repeat.Once();
                return mockedMappingProvider;
            }    

            private static IDataMappingProvider BuildMockedDataMappingExpectToRepeatTwice(MockRepository mockRepository)
            {
                IDataMappingProvider mockedMappingProvider = mockRepository.CreateMock<IDataMappingProvider>();

                TableMappingInfo tableInfo = BuildTestingTableMappingInfo();
                Expect.Call(mockedMappingProvider.GetTableMappingInfo(null))
                    .IgnoreArguments()
                    .Return(tableInfo)
                    .Repeat.Twice();
                return mockedMappingProvider;
            }

            private static MockableDataReader BuildMockedDataReaderExpectToRepeatReadOnceAndReturnsOneFullInfoRecord(MockRepository mockRepository)
            {
                MockableDataReader mockedDataReader = mockRepository.CreateMock<MockableDataReader>();
                Expect.Call(mockedDataReader.GetOrdinal("Id"))
                    .Return(0)
                    .Repeat.Once();
                Expect.Call(mockedDataReader.GetValue(0))
                    .Return("001")
                    .Repeat.Once();
                Expect.Call(mockedDataReader.GetOrdinal("Name"))
                    .Return(1)
                    .Repeat.Once();
                Expect.Call(mockedDataReader.GetValue(1))
                    .Return("Tuan Luong")
                    .Repeat.Once();
                Expect.Call(mockedDataReader.Read())
                    .Return(true)
                    .Repeat.Once();
                return mockedDataReader;
            }

            private static MockableDataReader BuildMockedDataReaderExpectToRepeatReadTwiceTrueOnceFalseAndReturnsTwoFullInfoRecords(MockRepository mockRepository)
            {
                MockableDataReader mockableDataReader = mockRepository.CreateMock<MockableDataReader>();
                Expect.Call(mockableDataReader.GetOrdinal("Id"))
                    .Return(0)
                    .Repeat.Once();
                Expect.Call(mockableDataReader.GetValue(0))
                    .Return("001")
                    .Repeat.Once();
                Expect.Call(mockableDataReader.GetOrdinal("Name"))
                    .Return(1)
                    .Repeat.Once();
                Expect.Call(mockableDataReader.GetValue(1))
                    .Return("Tuan Luong")
                    .Repeat.Once();
                Expect.Call(mockableDataReader.Read())
                    .Return(true)
                    .Repeat.Once();
                Expect.Call(mockableDataReader.GetOrdinal("Id"))
                    .Return(0)
                    .Repeat.Once();
                Expect.Call(mockableDataReader.GetValue(0))
                    .Return("002")
                    .Repeat.Once();
                Expect.Call(mockableDataReader.GetOrdinal("Name"))
                    .Return(1)
                    .Repeat.Once();
                Expect.Call(mockableDataReader.GetValue(1))
                    .Return("Long Nguyen")
                    .Repeat.Once();
                Expect.Call(mockableDataReader.Read())
                    .Return(true)
                    .Repeat.Once();
                Expect.Call(mockableDataReader.Read())
                    .Return(false)
                    .Repeat.Once();
                return mockableDataReader;
            }

            private static MockableDatabase BuildMockedDataBaseExpectToExecuteReaderFillCommandAndReturnsMockedDataReader(MockRepository mockRepository, MockableDataReader mockedDataReader)
            {
                DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.SqlClient");
                MockableDatabase mockedDatabase = mockRepository.CreateMock<MockableDatabase>(new object[] { "SQL Connection String", factory });
                DbCommand fillCommand = mockedDatabase.GetSqlStringCommand("Select * From EmployeeTb");
                Expect.Call(mockedDatabase.ExecuteReader(fillCommand))
                    .IgnoreArguments()
                    .Return(mockedDataReader);
                return mockedDatabase;
            }
            #endregion

            #region Build Predicted Result Objects
            private static TableMappingInfo BuildTestingTableMappingInfo()
        {
            TableMappingInfo tableInfo = new TableMappingInfo();
            tableInfo.DBTableName = "EmployeeTb";
            FieldMappingInfo fieldInfo = new FieldMappingInfo();
            fieldInfo.DBFieldName = "Id";
            fieldInfo.DBType = System.Data.DbType.String;
            fieldInfo.ObjectFieldName = "DummyID";
            fieldInfo.IsPrimaryKey = true;

            tableInfo.FieldMappings.Add(fieldInfo);

            FieldMappingInfo fieldInfo1 = new FieldMappingInfo();
            fieldInfo1.DBFieldName = "Name";
            fieldInfo1.DBType = System.Data.DbType.String;
            fieldInfo1.ObjectFieldName = "DummyName";

            tableInfo.FieldMappings.Add(fieldInfo1);

            return tableInfo;
        }

            private static TableMappingInfo BuildTestingTableMappingInfoWithNoPrimaryKey()
            {
                TableMappingInfo tableInfo = new TableMappingInfo();
                tableInfo.DBTableName = "EmployeeTb";
                FieldMappingInfo fieldInfo = new FieldMappingInfo();
                fieldInfo.DBFieldName = "Id";
                fieldInfo.DBType = System.Data.DbType.String;
                fieldInfo.ObjectFieldName = "DummyID";            

                tableInfo.FieldMappings.Add(fieldInfo);

                FieldMappingInfo fieldInfo1 = new FieldMappingInfo();
                fieldInfo1.DBFieldName = "Name";
                fieldInfo1.DBType = System.Data.DbType.String;
                fieldInfo1.ObjectFieldName = "DummyName";

                tableInfo.FieldMappings.Add(fieldInfo1);

                return tableInfo;
            }

            private static TableMappingInfo BuildTestingTableMappingInfoWithTwoPrimaryKey()
            {
                TableMappingInfo tableInfo = new TableMappingInfo();
                tableInfo.DBTableName = "EmployeeTb";
                FieldMappingInfo fieldInfo = new FieldMappingInfo();
                fieldInfo.DBFieldName = "Id";
                fieldInfo.DBType = System.Data.DbType.String;
                fieldInfo.ObjectFieldName = "DummyID";
                fieldInfo.IsPrimaryKey = true;

                tableInfo.FieldMappings.Add(fieldInfo);

                FieldMappingInfo fieldInfo1 = new FieldMappingInfo();
                fieldInfo1.DBFieldName = "Name";
                fieldInfo1.DBType = System.Data.DbType.String;
                fieldInfo1.ObjectFieldName = "DummyName";
                fieldInfo1.IsPrimaryKey = true;

                tableInfo.FieldMappings.Add(fieldInfo1);

                return tableInfo;
            }

            private static TestDomainObject BuildTestDomainObject()
            {
                TestDomainObject testDomainObject = new TestDomainObject();
                testDomainObject.DummyID = "001";
                testDomainObject.DummyName = "Tuan Luong";

                return testDomainObject;
            }

            private static TestDomainObject BuildTestDomainObjectHaveOnlyIdentity()
            {
                TestDomainObject testDomainObject = new TestDomainObject();
                testDomainObject.DummyID = "001";            

                return testDomainObject;
            }

            private static Collection<TestDomainObject> BuildTestDomainObjectList()
        {
            Collection<TestDomainObject> list = new Collection<TestDomainObject>();
            TestDomainObject testDomainObject1 = new TestDomainObject();
            testDomainObject1.DummyID = "001";
            testDomainObject1.DummyName = "Tuan Luong";
            list.Add(testDomainObject1);

            TestDomainObject testDomainObject2 = new TestDomainObject();
            testDomainObject2.DummyID = "002";
            testDomainObject2.DummyName = "Long Nguyen";
            list.Add(testDomainObject2);

            return list;
        }
            #endregion
        #endregion
    }
}
*/