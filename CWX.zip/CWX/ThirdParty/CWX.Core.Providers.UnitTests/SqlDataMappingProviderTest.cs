using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Reflection;

using NUnit.Framework;
using Rhino.Mocks;
using Rhino.Mocks.Constraints;

using CWX.Core.Common.Data;
using CWX.Core.Providers.Data.Mapping;
using CWX.Core.Providers.Data;

namespace CWX.Core.Data.UnitTests
{
    [TestFixture]
    public class SqlDataMappingProviderTest
    {
        [TestFixtureSetUp]
        public void Setup()
        { 
        }

        [TestFixtureTearDown]
        public void TearDown()
        { 
        }

        [Test]
        public void TestGetTableMappingInfo()
        {
            MockRepository mockRepository = new MockRepository();
            IXmlMappingReader mockedReader = mockRepository.CreateMock<IXmlMappingReader>();

            XmlDocument xDoc = BuildTestingXmlMappingData();
            Expect.Call(mockedReader.GetXmlMapping(null))
                .IgnoreArguments()
                .Return(xDoc);

            mockRepository.ReplayAll();

            TableMappingInfo mappingInfo = new SqlDataMappingProvider(mockedReader).GetTableMappingInfo(null);

            //Verify the test data
            Assert.AreEqual(mappingInfo.DBTableName, "123");
            Assert.AreEqual(mappingInfo.FieldMappings.Count, 0);

            mockRepository.VerifyAll();
        }

        private static XmlDocument BuildTestingXmlMappingData()
        {
            XmlDocument xDoc = new XmlDocument();
            XmlElement tableNode = xDoc.CreateElement("table");
            tableNode.SetAttribute("tableName", "123");
            tableNode.SetAttribute("objectType", "456");
            xDoc.AppendChild(tableNode);
            return xDoc;
        }


    }
}
