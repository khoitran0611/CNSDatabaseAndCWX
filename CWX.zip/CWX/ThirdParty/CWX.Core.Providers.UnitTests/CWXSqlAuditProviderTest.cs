using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Reflection;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using NUnit.Framework;
using Rhino.Mocks;
using Rhino.Mocks.Constraints;
using Microsoft.Practices.EnterpriseLibrary.Data;

using CWX.Core.Common.Audit;
using CWX.Core.Common.Data;
using CWX.Core.Providers.Data.Mapping;
using CWX.Core.Providers.Data;
using CWX.Core.Providers.Audit;
using CWX.Core.TestingFramework;
using CWX.Core.Providers.Data.Query;

namespace CWX.Core.Providers.UnitTests
{
    [TestFixture]
    public class CWXSqlAuditProviderTest
    {
        private const string AUDITTRAIL_CATEGORY = "CWXSqlAuditProvider-AuditTrail";
        private const string AUDITTABLES_CATEGORY = "CWXSqlAuditProvider-AuditTables";
        private string _connectionString = string.Empty;
        private string _providerName = string.Empty;
        private string _dataMappingProviderType = string.Empty;
        MockRepository _mockRepository;

        [TestFixtureSetUp]
        public void Setup()
        {
            _mockRepository = new MockRepository();
            _connectionString = "Data Source=192.168.177.190;Initial Catalog=CWX.Core;User ID=sa;Password=cwxsystem";
            _providerName = "System.Data.SqlClient";
            _dataMappingProviderType = "CWX.Core.Providers.Data.SqlDataMappingProvider, CWX.Core.Providers, Version=1.0.0.0, Culture=neutral, PublicKeyToken=9bb8c3eac4beada4";
        }

        [TestFixtureTearDown]
        public void TearDown() 
        {
            _mockRepository.VerifyAll();
        }

        [Category(AUDITTRAIL_CATEGORY)]
        [Test]
        public void TestSearchTrail()
        {            
            IDataProvider mockedDataProvider = _mockRepository.CreateMock<IDataProvider>();
            IDataExecutionContext mockedDataExecution = _mockRepository.CreateMock<IDataExecutionContext>();
            DataSet expectedDataSet = new DataSet();

            Expect.Call(mockedDataProvider.BeginExecution(new SqlStoreProcedureQuerryBuilder(string.Empty)))
                .IgnoreArguments()
                .Return(mockedDataExecution);
            Expect.Call(mockedDataExecution.RunDataSet())
                .IgnoreArguments()
                .Return(expectedDataSet);
            Expect.Call(mockedDataExecution.GetParameterOutPutIntegerValue("RowCount"))
                .Return(99);
            Expect.Call(delegate { mockedDataExecution.Dispose(); });
            
            CWXSqlAuditProvider auditProvider = new CWXSqlAuditProvider();
            auditProvider.DataProvider = mockedDataProvider;

            _mockRepository.ReplayAll();

            int totalRow = 0;
            Assert.IsNotNull(auditProvider.SearchTrail(null, null, null, null, null, null, null, 0, 10, out totalRow));
        }

        [Category(AUDITTRAIL_CATEGORY)]
        [Test]
        public void TestGetTrail()
        {
            IDataProvider mockedDataProvider = _mockRepository.CreateMock<IDataProvider>();
            IDataExecutionContext mockedDataExecution = _mockRepository.CreateMock<IDataExecutionContext>();
            IDataReader expectedDataReader = BuildMockedDataReaderWith1RowForTrail();
            IDataMappingProvider mockedMappingProvider = BuildMockedDataMappingForTrailTable();

            Expect.Call(mockedDataProvider.BeginExecution(new SqlStoreProcedureQuerryBuilder(string.Empty)))
                .IgnoreArguments()
                .Return(mockedDataExecution);
            Expect.Call(mockedDataExecution.RunReader(CommandBehavior.SingleRow))
                .Return(expectedDataReader);
            Expect.Call(delegate { mockedDataExecution.Dispose(); });

            CWXSqlAuditProvider auditProvider = new CWXSqlAuditProvider();
            auditProvider.DataProvider = mockedDataProvider;
            auditProvider.MappingProvider = mockedMappingProvider;

            _mockRepository.ReplayAll();
            CWXAuditTrail trail = auditProvider.GetTrail(123);

            Assert.AreEqual(trail.TrailID, 7);
            Assert.AreEqual(trail.ChangedTable, "CWX_ProfileData");
            Assert.AreEqual(trail.ChangedField, "Culture");
        }

        [Obsolete("This is DB integration test method. Do not run test it in this scope. Move to DB Integration test scope when avaible.", true)]
        public void TestAddTrailToDB()
        {
            CWXAuditTrail trail = this.CreateTestTrailData();
            IDataMappingProvider mockedMappingProvider = BuildMockedDataMappingForTrailTable();

            DbProviderFactory dbFactory = DbProviderFactories.GetFactory(_providerName);
            Database mockedDatabase = _mockRepository.CreateMock<Database>(_connectionString, dbFactory);
            DbConnection expectedDbConnection = BuildTestingSqlConnection();
            DbCommand expectedDbCommand = BuildTestingDbCommandWithSqlCommand();
            Expect.Call(mockedDatabase.CreateConnection())
                .IgnoreArguments()
                .Return(expectedDbConnection);
            Expect.Call(mockedDatabase.GetStoredProcCommand(""))
                .IgnoreArguments()
                .Return(expectedDbCommand);

            _mockRepository.ReplayAll();

            SqlDataProvider dataProvider = new SqlDataProvider(mockedDatabase, mockedMappingProvider);


            CWXSqlAuditProvider auditProvider = new CWXSqlAuditProvider();
            auditProvider.DataProvider = dataProvider;
            auditProvider.MappingProvider = mockedMappingProvider;

            bool result = auditProvider.AddTrail(trail);
            Assert.IsTrue(result, "Insert data doesn't successfully.");
        }

        [Category(AUDITTRAIL_CATEGORY)]
        [Test]
        public void TestAddTrail()
        {
            //IDataProvider mockedDataProvider = _mockRepository.CreateMock<IDataProvider>();
            //IDataExecutionContext mockedDataExecution = _mockRepository.CreateMock<IDataExecutionContext>();

            //Expect.Call(mockedDataProvider.BeginExecution(new SqlStoreProcedureQuerryBuilder(string.Empty)))
            //    .IgnoreArguments()
            //    .Return(mockedDataExecution);
            //Expect.Call<int>(mockedDataExecution.RunNonQuery())
            //    .Return(1);
            //Expect.Call(delegate { mockedDataExecution.Dispose(); });

            //CWXSqlAuditProvider auditProvider = new CWXSqlAuditProvider();
            //auditProvider.DataProvider = mockedDataProvider;

            //_mockRepository.ReplayAll();

            //CWXAuditTrail trail = CreateTestTrailData();
            //bool updateResult = auditProvider.AddTrail(trail);

            //Assert.IsTrue(updateResult);
        }       

        #region Build Predicted Result Objects

        private SqlCommand BuildTestingDbCommandWithSqlCommand()
        {
            SqlCommand cmd = new SqlCommand("CWX_AuditTrail_Insert", BuildTestingSqlConnection());
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            return cmd;
        }

        private IDataMappingProvider BuildMockedDataMappingForTrailTable()
        {
            IDataMappingProvider mockedMappingProvider = _mockRepository.CreateMock<IDataMappingProvider>();

            TableMappingInfo tableInfo = BuildTestingAuditTrailTableMapping();
            Expect.Call(mockedMappingProvider.GetTableMappingInfo(null))
                .IgnoreArguments()
                .Return(tableInfo);
            return mockedMappingProvider;
        }

        private SqlConnection BuildTestingSqlConnection()
        {
            SqlConnection conn = new SqlConnection(_connectionString);
            return conn;
        }

        private TableMappingInfo BuildTestingAuditTrailTableMapping()
        {
            TableMappingInfo tableAuditTrail = new TableMappingInfo();
            tableAuditTrail.DBTableName = "CWX_AuditTrail";
            
            FieldMappingInfo fieldAuditId = new FieldMappingInfo();
            fieldAuditId.DBFieldName = "AuditID";
            fieldAuditId.DBType = "int";
            fieldAuditId.ObjectFieldName = "TrailID";
            fieldAuditId.IsPrimaryKey = true;
            tableAuditTrail.FieldMappings.Add(fieldAuditId);

            //FieldMappingInfo fieldSequenceId = new FieldMappingInfo();
            //fieldSequenceId.DBFieldName = "SequenceID";
            //fieldSequenceId.DBType = "int";
            //fieldSequenceId.ObjectFieldName = "SequenceID";
            //tableAuditTrail.FieldMappings.Add(fieldSequenceId);

            FieldMappingInfo fieldEmployeeID = new FieldMappingInfo();
            fieldEmployeeID.DBFieldName = "EmployeeID";
            fieldEmployeeID.DBType = "int";
            fieldEmployeeID.ObjectFieldName = "EmployeeID";
            tableAuditTrail.FieldMappings.Add(fieldEmployeeID);

            //FieldMappingInfo fieldDebtorId = new FieldMappingInfo();
            //fieldDebtorId.DBFieldName = "DebtorID";
            //fieldDebtorId.DBType = "int";
            //fieldDebtorId.ObjectFieldName = "DebtorID";
            //tableAuditTrail.FieldMappings.Add(fieldDebtorId);

            //FieldMappingInfo fieldAccountId = new FieldMappingInfo();
            //fieldAccountId.DBFieldName = "AccountID";
            //fieldAccountId.DBType = "int";
            //fieldAccountId.ObjectFieldName = "AccountID";
            //tableAuditTrail.FieldMappings.Add(fieldAccountId);

            FieldMappingInfo fieldActionId = new FieldMappingInfo();
            fieldActionId.DBFieldName = "ActionID";
            fieldActionId.DBType = "int";
            fieldActionId.ObjectFieldName = "Action";
            tableAuditTrail.FieldMappings.Add(fieldActionId);

            FieldMappingInfo fieldChangeTable = new FieldMappingInfo();
            fieldChangeTable.DBFieldName = "ChangeTable";
            fieldChangeTable.DBType = "varchar";
            fieldChangeTable.Length = 50;
            fieldChangeTable.ObjectFieldName = "ChangedTable";
            tableAuditTrail.FieldMappings.Add(fieldChangeTable);

            FieldMappingInfo fieldChangeField = new FieldMappingInfo();
            fieldChangeField.DBFieldName = "ChangeField";
            fieldChangeField.DBType = "varchar";
            fieldChangeField.Length = 50;
            fieldChangeField.ObjectFieldName = "ChangedField";            
            tableAuditTrail.FieldMappings.Add(fieldChangeField);

            FieldMappingInfo fieldChangeData = new FieldMappingInfo();
            fieldChangeData.DBFieldName = "ChangeData";
            fieldChangeData.DBType = "nvarchar";
            fieldChangeData.Length = 0;
            fieldChangeData.ObjectFieldName = "ChangedData";
            tableAuditTrail.FieldMappings.Add(fieldChangeData);

            FieldMappingInfo fieldAuditDateTime = new FieldMappingInfo();
            fieldAuditDateTime.DBFieldName = "AuditDateTime";
            fieldAuditDateTime.DBType = "datetime";
            fieldAuditDateTime.ObjectFieldName = "AuditDateTime";
            tableAuditTrail.FieldMappings.Add(fieldAuditDateTime);



            return tableAuditTrail;
        }

        private CWXAuditTrail CreateTestTrailData()
        {
            CWXAuditTrail trail = new CWXAuditTrail();
            trail.Action = CWXAuditAction.Edit;
            trail.AuditDateTime = DateTime.UtcNow;
            trail.OriginalData = "Original data";
            trail.ChangedData = "This data is changed in CreateTestTrailData method";
            trail.ChangedField = "CreateTestTrailData";
            trail.ChangedTable = "CWXTrail";
            trail.EmployeeID = 0;
            return trail;
        }

        /// <summary>
        /// Build mocked DataReader with 1 row.
        /// </summary>
        /// <returns>IDataReader with 1 row.</returns>
        private IDataReader BuildMockedDataReaderWith1RowForTrail()
        {
            IDataReader mockedDataReader = _mockRepository.CreateMock<IDataReader>();
            
            Expect.Call(mockedDataReader.Read())
                .Return(true)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("AuditID"))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(0))
                .Return(7)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("SequenceID"))
                .Return(1)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(1))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("EmployeeID"))
                .Return(2)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(2))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("DebtorID"))
                .Return(3)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(3))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("AccountID"))
                .Return(4)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(4))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("ActionID"))
                .Return(5)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(5))
                .Return(1)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("ChangeTable"))
                .Return(6)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(6))
                .Return("CWX_ProfileData")
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("ChangeField"))
                .Return(7)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(7))
                .Return("Culture")
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("ChangeData"))
                .Return(8)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(8))
                .Return("en-US")
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("AuditDateTime"))
                .Return(9)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(9))
                .Return(DateTime.Parse("09/25/2007"))
                .Repeat.Once();
            
            Expect.Call(delegate { mockedDataReader.Close(); });

            return mockedDataReader;
        }

        /// <summary>
        /// Build mocked DataReader with 2 rows.
        /// </summary>
        /// <returns>IDataReader with 2 rows.</returns>
        private IDataReader BuildMockedDataReaderWith2RowsForTrail()
        {
            IDataReader mockedDataReader = _mockRepository.CreateMock<IDataReader>();

            Expect.Call<bool>(mockedDataReader.Read())
                .Return(true)
                .Repeat.Times(1, 2);
            Expect.Call(mockedDataReader.GetOrdinal("AuditID"))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(0))
                .Return(7)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("SequenceID"))
                .Return(1)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(1))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("EmployeeID"))
                .Return(2)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(2))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("DebtorID"))
                .Return(3)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(3))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("AccountID"))
                .Return(4)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(4))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("ActionID"))
                .Return(5)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(5))
                .Return(1)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("ChangeTable"))
                .Return(6)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(6))
                .Return("CWX_ProfileData")
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("ChangeField"))
                .Return(7)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(7))
                .Return("Culture")
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("ChangeData"))
                .Return(8)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(8))
                .Return("en-US")
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("AuditDateTime"))
                .Return(9)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(9))
                .Return(DateTime.Parse("09/25/2007"))
                .Repeat.Once();
            
            //Row 2
            Expect.Call(mockedDataReader.GetOrdinal("AuditID"))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(0))
                .Return(8)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("SequenceID"))
                .Return(1)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(1))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("EmployeeID"))
                .Return(2)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(2))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("DebtorID"))
                .Return(3)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(3))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("AccountID"))
                .Return(4)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(4))
                .Return(0)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("ActionID"))
                .Return(5)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(5))
                .Return(2)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("ChangeTable"))
                .Return(6)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(6))
                .Return("CWX_ProfileData")
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("ChangeField"))
                .Return(7)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(7))
                .Return("ProfileID")
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("ChangeData"))
                .Return(8)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(8))
                .Return("2")
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetOrdinal("AuditDateTime"))
                .Return(9)
                .Repeat.Once();
            Expect.Call(mockedDataReader.GetValue(9))
                .Return(DateTime.Parse("09/25/2007"))
                .Repeat.Once();

            Expect.Call<bool>(mockedDataReader.Read())
                .Return(false)
                .Repeat.Times(0, 1);
            Expect.Call(delegate { mockedDataReader.Close(); });

            return mockedDataReader;
        }


        #endregion
    }
}