using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;

using NUnit.Framework;
using Microsoft.Practices.EnterpriseLibrary.Data;

using CWX.Core.Common.Data;
using CWX.Core.Providers.Data;
using CWX.Core.Providers.Data.Query;
using CWX.Core.TestingFramework;

namespace CWX.Core.Providers.UnitTests.Data.Query
{
    [TestFixture]
    public class SqlStoreProcedureQuerryBuilderTest
    {
        #region Private variables

        private string _testStoreProcedure;
        private string _returnParameter;

        private string _parameterName1;
        private string _parameterValue1;
        private string _parameterName2;
        private string _parameterValue2;

        private DataProviderBase _dataProvider;

        #endregion

        #region Init

        [SetUp]
        public void Init()
        {
            _testStoreProcedure = "TestStoreProcedure";
            _returnParameter = "ReturnParameter";

            _parameterName1 = "ParameterName1";
            _parameterValue1 = "ParameterValue2";
            _parameterName2 = "ParameterName2";
            _parameterValue2 = "ParameterValue2";

            DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.SqlClient");
            MockableDatabase mockableDatabase = new MockableDatabase("ConnectionString", factory);
            _dataProvider = new SqlDataProvider(mockableDatabase, null);
        }

        #endregion

        #region Test Methods

        #region Normal

        [Test]
        public void TestBuildCommand_Normal_OneParameter()
        {
            SqlStoreProcedureQuerryBuilder querryBuilder = new SqlStoreProcedureQuerryBuilder(_testStoreProcedure);
            querryBuilder.AddParameter(_parameterName1, _parameterValue1);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format(_testStoreProcedure);
            Assert.AreEqual(cmd.CommandText, _testStoreProcedure);
            Assert.AreEqual(cmd.CommandType, System.Data.CommandType.StoredProcedure);
            Assert.AreEqual(cmd.Parameters["@" + _parameterName1].Value.ToString(), _parameterValue1);
        }

        [Test]
        public void TestBuildCommand_Normal_TwoParameter()
        {
            SqlStoreProcedureQuerryBuilder querryBuilder = new SqlStoreProcedureQuerryBuilder(_testStoreProcedure);
            querryBuilder.AddParameter(_parameterName1, _parameterValue1);
            querryBuilder.AddParameter(_parameterName2, _parameterValue2);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format(_testStoreProcedure);
            Assert.AreEqual(cmd.CommandText, _testStoreProcedure);
            Assert.AreEqual(cmd.CommandType, System.Data.CommandType.StoredProcedure);
            Assert.AreEqual(cmd.Parameters["@" + _parameterName1].Value.ToString(), _parameterValue1);
            Assert.AreEqual(cmd.Parameters["@" + _parameterName2].Value.ToString(), _parameterValue2);
        }

        #endregion

        #region ReturnValue

        [Test]
        public void TestBuildCommand_ReturnValue_OneParameter()
        {
            SqlStoreProcedureQuerryBuilder querryBuilder = new SqlStoreProcedureQuerryBuilder(_testStoreProcedure);
            querryBuilder.AddParameter(_parameterName1, _parameterValue1);
            querryBuilder.AppendReturnParameter(_returnParameter);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format(_testStoreProcedure);
            Assert.AreEqual(cmd.CommandText, _testStoreProcedure);
            Assert.AreEqual(cmd.CommandType, CommandType.StoredProcedure);
            Assert.AreEqual(cmd.Parameters["@" + _parameterName1].Value.ToString(), _parameterValue1);
            Assert.AreEqual(cmd.Parameters["@" + _returnParameter].Direction, ParameterDirection.ReturnValue);
        }

        #endregion

        #region Exception

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void BuildCommand_EmptyStoreProcedureName()
        {
            SqlStoreProcedureQuerryBuilder querryBuilder = new SqlStoreProcedureQuerryBuilder(string.Empty);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();
        }

        #endregion

        #endregion
    }
}
