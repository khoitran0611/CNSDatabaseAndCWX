using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;

using NUnit.Framework;

using CWX.Core.Providers.Data;
using CWX.Core.Providers.Data.Query;
using CWX.Core.Common.Data;
using CWX.Core.TestingFramework;

namespace CWX.Core.Providers.UnitTests.Data.Query
{
    [TestFixture]
    public class SqlInsertQueryBuilderTest
    {
        #region Private variables

        private string _testTable;

        private string _columnName1;
        private string _columnValue1;
        private string _columnName2;
        private string _columnValue2;

        private DataProviderBase _dataProvider;

        #endregion

        #region Init

        [SetUp]
        public void Init()
        {
            _testTable = "TestTb";

            _columnName1 = "ColumnName1";
            _columnValue1 = "ColumnValue1";
            _columnName2 = "ColumnName2";
            _columnValue2 = "ColumnValue2";

            DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.SqlClient");
            MockableDatabase mockableDatabase = new MockableDatabase("ConnectionString", factory);
            _dataProvider = new SqlDataProvider(mockableDatabase, null);
        }

        #endregion

        #region Test Methods

        #region Normal

        [Test]
        public void TestBuildCommand_Normal_OneColumn()
        {
            SqlInsertQueryBuilder querryBuilder = new SqlInsertQueryBuilder(_testTable);
            querryBuilder.AddInsertColumn(_columnName1, _columnValue1);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("INSERT INTO {0}({1}) VALUES(@{1});", _testTable, _columnName1);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters["@" + _columnName1].Value.ToString(), _columnValue1);
        }

        [Test]
        public void TestBuildCommand_Normal_TwoColumn()
        {
            SqlInsertQueryBuilder querryBuilder = new SqlInsertQueryBuilder(_testTable);
            querryBuilder.AddInsertColumn(_columnName1, _columnValue1)
                .AddInsertColumn(_columnName2, _columnValue2);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("INSERT INTO {0}({1} , {2}) VALUES(@{1} , @{2});", _testTable, _columnName1, _columnName2);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters["@" + _columnName1].Value.ToString(), _columnValue1);
            Assert.AreEqual(cmd.Parameters["@" + _columnName2].Value.ToString(), _columnValue2);
        }

        #endregion

        #region Exception

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestBuildCommand_EmptyTableName()
        {
            SqlInsertQueryBuilder querryBuilder = new SqlInsertQueryBuilder(string.Empty);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();
        }

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestBuildCommand_NoColumn()
        {
            SqlInsertQueryBuilder querryBuilder = new SqlInsertQueryBuilder(_testTable);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();
        }

        #endregion

        #endregion
    }
}
