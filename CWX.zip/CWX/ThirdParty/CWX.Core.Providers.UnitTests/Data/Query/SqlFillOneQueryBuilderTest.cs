using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;

using NUnit.Framework;
using Microsoft.Practices.EnterpriseLibrary.Data;

using CWX.Core.Common.Data;
using CWX.Core.Providers.Data;
using CWX.Core.Providers.Data.Query;
using CWX.Core.TestingFramework;

namespace CWX.Core.Providers.UnitTests.Data.Query
{
    [TestFixture]
    public class SqlFillOneQueryBuilderTest
    {
        #region Private variables

        private string _testTable;
        private string _whereClause;
        private string _orderByClause;

        private string _identityName1;
        private string _identityValue1;
        private string _identityName2;
        private string _identityValue2;

        private string _columnName1;
        private string _columnName2;

        private DataProviderBase _dataProvider;

        #endregion

        #region Init

        [SetUp]
        public void Init()
        {
            _testTable = "TestTb";
            _whereClause = "Status = 1";
            _orderByClause = "FirstName ASC";

            _identityName1 = "IdentityName1";
            _identityValue1 = "IdentityValue1";
            _identityName2 = "IdentityName2";
            _identityValue2 = "IdentityValue2";

            _columnName1 = "ColumnName1";
            _columnName2 = "ColumnName2";

            DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.SqlClient");
            MockableDatabase mockableDatabase = new MockableDatabase("ConnectionString", factory);
            _dataProvider = new SqlDataProvider(mockableDatabase, null);
        }

        #endregion

        #region Test Method

        #region Normal

        [Test]
        public void BuildCommand_Normal_OneColumnOneIdentity()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddSelectColumn(_columnName1);
            querryBuilder.AddIdentity(_identityName1, _identityValue1);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT {0} FROM {1} WHERE {2} = @{2} ", _columnName1, _testTable, _identityName1);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters.Count, 1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
        }

        [Test]
        public void BuildCommand_Normal_TwoColumnTwoIdentity()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddSelectColumn(_columnName1);
            querryBuilder.AddSelectColumn(_columnName2);
            querryBuilder.AddIdentity(_identityName1, _identityValue1);
            querryBuilder.AddIdentity(_identityName2, _identityValue2);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT {0} , {1} FROM {2} WHERE {3} = @{3} AND {4} = @{4} ", _columnName1, _columnName2, _testTable, _identityName1, _identityName2);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters.Count, 2);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName2].Value.ToString(), _identityValue2);
        }

        #endregion

        #region Where Clause

        [Test]
        public void BuildCommand_WhereClause_OneColumnOneIdentity()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddSelectColumn(_columnName1);
            querryBuilder.AddIdentity(_identityName1, _identityValue1);
            querryBuilder.AppendWhereClause(_whereClause);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT {0} FROM {1} WHERE {2} = @{2} AND {3} ", _columnName1, _testTable, _identityName1, _whereClause);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters.Count, 1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
        }

        [Test]
        public void BuildCommand_WhereClause_TwoColumnTwoIdentity()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddSelectColumn(_columnName1);
            querryBuilder.AddSelectColumn(_columnName2);
            querryBuilder.AddIdentity(_identityName1, _identityValue1);
            querryBuilder.AddIdentity(_identityName2, _identityValue2);
            querryBuilder.AppendWhereClause(_whereClause);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT {0} , {1} FROM {2} WHERE {3} = @{3} AND {4} = @{4} AND {5} ", _columnName1, _columnName2, _testTable, _identityName1, _identityName2, _whereClause);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters.Count, 2);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName2].Value.ToString(), _identityValue2);
        }

        #endregion

        #region Order By

        [Test]
        public void BuildCommand_OrderBy_OneAsc()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddSelectColumn(_columnName1);
            querryBuilder.AddIdentity(_identityName1, _identityValue1);
            querryBuilder.AddOrderBy(_columnName1, OrderByDirection.Ascending);
            querryBuilder.AppendWhereClause(_whereClause);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT {0} FROM {1} WHERE {2} = @{2} AND {3} ORDER BY {0} ASC", _columnName1, _testTable, _identityName1, _whereClause);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters.Count, 1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
        }

        [Test]
        public void BuildCommand_OrderBy_TwoAsc()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddSelectColumn(_columnName1);
            querryBuilder.AddSelectColumn(_columnName2);
            querryBuilder.AddIdentity(_identityName1, _identityValue1);
            querryBuilder.AddOrderBy(_columnName1, OrderByDirection.Ascending);
            querryBuilder.AddOrderBy(_columnName2, OrderByDirection.Ascending);
            querryBuilder.AppendWhereClause(_whereClause);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT {0} , {1} FROM {2} WHERE {3} = @{3} AND {4} ORDER BY {0} ASC, {1} ASC", _columnName1, _columnName2, _testTable, _identityName1, _whereClause);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters.Count, 1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
        }

        [Test]
        public void BuildCommand_OrderBy_OneDesc()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddSelectColumn(_columnName1);
            querryBuilder.AddIdentity(_identityName1, _identityValue1);
            querryBuilder.AddOrderBy(_columnName1, OrderByDirection.Descending);
            querryBuilder.AppendWhereClause(_whereClause);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT {0} FROM {1} WHERE {2} = @{2} AND {3} ORDER BY {0} DESC", _columnName1, _testTable, _identityName1, _whereClause);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters.Count, 1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
        }

        [Test]
        public void BuildCommand_OrderBy_TwoDesc()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddSelectColumn(_columnName1);
            querryBuilder.AddSelectColumn(_columnName2);
            querryBuilder.AddIdentity(_identityName1, _identityValue1);
            querryBuilder.AddOrderBy(_columnName1, OrderByDirection.Descending);
            querryBuilder.AddOrderBy(_columnName2, OrderByDirection.Descending);
            querryBuilder.AppendWhereClause(_whereClause);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT {0} , {1} FROM {2} WHERE {3} = @{3} AND {4} ORDER BY {0} DESC, {1} DESC", _columnName1, _columnName2, _testTable, _identityName1, _whereClause);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters.Count, 1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
        }

        [Test]
        public void BuildCommand_OrderBy_OneAscOneDesc()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddSelectColumn(_columnName1);
            querryBuilder.AddSelectColumn(_columnName2);
            querryBuilder.AddIdentity(_identityName1, _identityValue1);
            querryBuilder.AddOrderBy(_columnName1, OrderByDirection.Ascending);
            querryBuilder.AddOrderBy(_columnName2, OrderByDirection.Descending);
            querryBuilder.AppendWhereClause(_whereClause);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT {0} , {1} FROM {2} WHERE {3} = @{3} AND {4} ORDER BY {0} ASC, {1} DESC", _columnName1, _columnName2, _testTable, _identityName1, _whereClause);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters.Count, 1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
        }

        [Test]
        public void BuildCommand_OrderBy_OrderByClause()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddSelectColumn(_columnName1);
            querryBuilder.AddIdentity(_identityName1, _identityValue1);
            querryBuilder.AddOrderBy(_columnName1, OrderByDirection.Ascending);
            querryBuilder.AppendOrderByClause(_orderByClause);
            querryBuilder.AppendWhereClause(_whereClause);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT {0} FROM {1} WHERE {2} = @{2} AND {3} ORDER BY {4}, {0} ASC", _columnName1, _testTable, _identityName1, _whereClause, _orderByClause);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters.Count, 1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
        }

        #endregion

        #region Special: no column or identity

        [Test]
        public void BuildCommand_NoColumnNoIdentity()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT TOP 1 * FROM {0} ", _testTable);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
        }

        [Test]
        public void BuildCommand_NoColumnNoIdentity_OrderBy()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AppendOrderByClause(_orderByClause);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT TOP 1 * FROM {0} ORDER BY {1}", _testTable, _orderByClause);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
        }

        [Test]
        public void BuildCommand_NoColumnOneIdentity()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddIdentity(_identityName1, _identityValue1);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT * FROM {0} WHERE {1} = @{1} ", _testTable, _identityName1);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters.Count, 1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
        }

        [Test]
        public void BuildCommand_OneColumnNoIdentity()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddSelectColumn(_columnName1);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT TOP 1 {0} FROM {1} ", _columnName1, _testTable);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
        }

        [Test]
        public void BuildCommand_OneColumnNoIdentity_OrderBy()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(_testTable);
            querryBuilder.AddSelectColumn(_columnName1);
            querryBuilder.AppendOrderByClause(_orderByClause);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("SELECT TOP 1 {0} FROM {1} ORDER BY {2}", _columnName1, _testTable, _orderByClause);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
        }

        #endregion

        #region Exception

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void BuildCommand_EmptyTableName()
        {
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(string.Empty);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();
        }

        #endregion

        #endregion
    }
}
