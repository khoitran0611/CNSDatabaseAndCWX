using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;

using NUnit.Framework;
using Microsoft.Practices.EnterpriseLibrary.Data;

using CWX.Core.Common.Data;
using CWX.Core.Providers.Data;
using CWX.Core.Providers.Data.Query;
using CWX.Core.TestingFramework;

namespace CWX.Core.Providers.UnitTests.Data.Query
{
    [TestFixture]
    public class SqlDeleteQueryBuilderTest
    {
        #region Private variables

        private string _testTable;
        private string _whereClause;

        private string _identityName1;
        private string _identityValue1;
        private string _identityName2;
        private string _identityValue2;

        private DataProviderBase _dataProvider;

        #endregion

        #region Init

        [SetUp]
        public void Init()
        {
            _testTable = "TestTb";
            _whereClause = "Status = 1";

            _identityName1 = "IdentityName1";
            _identityValue1 = "IdentityValue1";
            _identityName2 = "IdentityName2";
            _identityValue2 = "IdentityValue2";

            DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.SqlClient");
            MockableDatabase mockableDatabase = new MockableDatabase("ConnectionString", factory);
            _dataProvider = new SqlDataProvider(mockableDatabase, null);
        }

        #endregion

        #region Test Methods

        #region Normal

        [Test]
        public void TestBuildCommand_Normal_OneIdentity()
        {
            SqlDeleteQueryBuilder querryBuilder = new SqlDeleteQueryBuilder(_testTable);
            querryBuilder.AddIdentity(_identityName1, _identityValue1);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("DELETE {0} WHERE {1} = @{1}", _testTable, _identityName1);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
        }

        [Test]
        public void TestBuildCommand_Normal_TwoIdentity()
        {
            SqlDeleteQueryBuilder querryBuilder = new SqlDeleteQueryBuilder(_testTable);
            querryBuilder.AddIdentity(_identityName1, _identityValue1)
                .AddIdentity(_identityName2, _identityValue2);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("DELETE {0} WHERE {1} = @{1} AND {2} = @{2}", _testTable, _identityName1, _identityName2);

            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName2].Value.ToString(), _identityValue2);
        }

        #endregion

        #region Where Clause

        [Test]
        public void TestBuildCommand_WhereClause_OneIdentity()
        {
            SqlDeleteQueryBuilder querryBuilder = new SqlDeleteQueryBuilder(_testTable);
            querryBuilder.AddIdentity(_identityName1, _identityValue1)
                .AppendWhereClause(_whereClause);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("DELETE {0} WHERE {1} = @{1} AND {2}", _testTable, _identityName1, _whereClause);
            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
        }

        [Test]
        public void TestBuildCommand_WhereClause_TwoIdentity()
        {
            SqlDeleteQueryBuilder querryBuilder = new SqlDeleteQueryBuilder(_testTable);
            querryBuilder.AddIdentity(_identityName1, _identityValue1)
                .AddIdentity(_identityName2, _identityValue2)
                .AppendWhereClause(_whereClause);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();

            string expectedCommandText = string.Format("DELETE {0} WHERE {1} = @{1} AND {2} = @{2} AND {3}", _testTable, _identityName1, _identityName2, _whereClause);

            Assert.AreEqual(cmd.CommandText, expectedCommandText);
            Assert.AreEqual(cmd.Parameters["@" + _identityName1].Value.ToString(), _identityValue1);
            Assert.AreEqual(cmd.Parameters["@" + _identityName2].Value.ToString(), _identityValue2);
        }

        #endregion

        #region Exception

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestBuildCommand_EmptyTableName()
        {
            SqlDeleteQueryBuilder querryBuilder = new SqlDeleteQueryBuilder(string.Empty);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();
        }

        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestBuildCommand_NoIdentity()
        {
            SqlDeleteQueryBuilder querryBuilder = new SqlDeleteQueryBuilder(_testTable);

            querryBuilder.DataProvider = _dataProvider;
            DbCommand cmd = querryBuilder.BuildCommand();
        }

        #endregion

        #endregion
    }
}
