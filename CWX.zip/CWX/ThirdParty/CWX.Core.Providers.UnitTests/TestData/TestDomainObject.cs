using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Data.UnitTests.TestData
{
    public class TestDomainObject
    {
        private string _dummyID;

        public string DummyID
        {
            get { return _dummyID; }
            set { _dummyID = value; }
        }

        private string _dummyName;

        public string DummyName
        {
            get { return _dummyName; }
            set { _dummyName = value; }
        }

    }
}
