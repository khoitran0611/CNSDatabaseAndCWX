using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Collections;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Threading;
using System.Globalization;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;

using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

using CWX.Core.Common;
using CWX.Core.Common.Exceptions;
using CWX.Core.Common.Security;
using CWX.Core.Common.Resource;


namespace CWX.Core.UI
{
    /// <summary>
    /// Represents a CWX Web Forms page, requested from 
    /// a server that hosts an ASP.NET Web application.
    /// </summary>
    /// <history>
    ///     2007/12/25  [Binh Truong]   Init version.
    ///     2008/05/29  [Binh Truong]   Add loading progress function.
    ///     2008/07/04  [Binh Truong]   Add TelerikWindowEmbedEnable property.
    ///     2008/12/16  [Alvin Marable] Add WorkflowProcessId property.
    /// </history>
    public class CWXPage : Page
    {

        public const string CUSTOMER_SEARCHES = "Searches";
        private const string sessionKeyUpdateProfile = "UpdateProfile";

        #region Private Fields

        private const string SET_BYPASS_SCRIPT = "dirtyCheck('false');";
        private const string SET_DIRTY_SCRIPT = "dirtyCheck('true');";
        private bool _checkDirtyEnable = false;
        private string _nonSavedConfirmMessage = CWXResourceManager.GetString(ResourceCategory.Strings, "WebCommon_NonSavedConfirm");
        private List<string[]> _localizationMessages;

        #endregion

        #region Properties

        protected bool IsViewMode
        {
            get
            {

                return string.IsNullOrEmpty(Request["IsViewMode"]) ? false : string.Equals(Request["IsViewMode"], "true", StringComparison.InvariantCultureIgnoreCase);
            }
        }

        /// <summary>
        /// Get current ScriptManager.
        /// </summary>        
        public ScriptManager ScriptMan
        {
            get
            {
                try
                {
                    return ScriptManager.GetCurrent(this.Page);
                }
                catch
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets or sets a value whether web form is enabled for check dirty.
        /// Webpage will be open a confirm dialog to make sure user want to leave without saving data.
        /// </summary>
        /// <history>
        ///     2008/05/29  [Binh Truong]   Change property name from IsInEdit to CheckDirtyEnable.
        /// </history>
        public bool CheckDirtyEnable
        {
            get { return _checkDirtyEnable; }
            set { _checkDirtyEnable = value; }
        }

        /// <summary>
        /// Non-saved confirm message.
        /// </summary>
        public string NonSavedConfirmMessage
        {
            get { return _nonSavedConfirmMessage; }
            set { _nonSavedConfirmMessage = value; }
        }

        /// <summary>
        /// Indicates AJAX calling or not.
        /// </summary>
        public bool IsAjax
        {
            get
            {
                if (!IsPostBack && ScriptMan != null)
                    return ScriptMan.IsInAsyncPostBack;
                return !IsPostBack && IsCallback;
            }
        }

        private CWXIdentity _currentIdentity;
        /// <summary>
        /// Get current user identify.
        /// </summary>
        public CWXIdentity CurrentIdentity
        {
            get
            {
                if (_currentIdentity == null)
                    _currentIdentity = Thread.CurrentPrincipal.Identity as CWXIdentity;

                return _currentIdentity;
            }
        }

        private bool m_LoadingProgessVisible = true;
        /// <summary>
        /// Gets or sets a value whether show loading message when page is loading. Default is true.
        /// </summary>
        /// <history>
        ///     2008/05/29  [Binh Truong]   Init version.
        /// </history>
        public bool LoadingProgressVisible
        {
            get { return m_LoadingProgessVisible; }
            set { m_LoadingProgessVisible = value; }
        }

        private bool _telerikWindowEmbedEnable = true;
        /// <summary>
        /// Gets or sets a boolean value whether Telerik window use on current page.
        /// Default value is true.
        /// </summary>
        /// <history>
        ///     08/07/04    [Binh Truong]   Init version.
        /// </history>
        public bool TelerikWindowEmbedEnable
        {
            get { return _telerikWindowEmbedEnable; }
            set { _telerikWindowEmbedEnable = value; }
        }

        public CultureInfo GlobalSettingCulture
        {
            get
            {
                if (CWXApplicationState.GlobalSettingCulture == null)
                    CWXApplicationState.GlobalSettingCulture = CultureInfo.InvariantCulture;
                return CWXApplicationState.GlobalSettingCulture;
            }
            set { CWXApplicationState.GlobalSettingCulture = value; }
        }

        /// <summary>
        /// Workflow process id.
        /// </summary>
        public long WorkflowProcessID
        {
            get { return CWXUtilities.GetRequestValue<long>("WorkflowProcessID"); }
        }

        #endregion

        #region Page Methods
        /// <summary>
        /// Redirects the browser to the login URL.
        /// </summary>
        protected void RedirectToLoginPage()
        {
            FormsAuthentication.RedirectToLoginPage();
            Response.End();
        }

        /// <summary>
        /// Register <see cref="System.Web.UI.IAttributeAccessor"/> controls 
        /// for bypass non-saved confirm message.
        /// </summary>
        public void RegisterByPassConfirmControl(params IAttributeAccessor[] controls)
        {
            if (!CheckDirtyEnable)
                throw new InvalidOperationException("CheckDirtyEnable property must be set True before use RegisterByPassConfirmControl method.");

            foreach (IAttributeAccessor control in controls)
            {
                control.SetAttribute("onclick",
                    string.Concat(SET_BYPASS_SCRIPT, control.GetAttribute("onclick"))
                    );
            }
        }

        /// <summary>
        /// Register <see cref="System.Web.UI.IAttributeAccessor"/> controls monitor onchange data.
        /// </summary>
        public void RegisterControlMonitorChange(params IAttributeAccessor[] controls)
        {
            if (!CheckDirtyEnable)
                throw new InvalidOperationException("CheckDirtyEnable property must be set True before use RegisterControlMonitorChange method.");

            foreach (IAttributeAccessor control in controls)
            {
                control.SetAttribute("onchange",
                    string.Concat(SET_DIRTY_SCRIPT, control.GetAttribute("onchange"))
                    );
            }
        }

        /// <summary>
        /// Get current web application path.
        /// </summary>
        public string GetApplicationPath()
        {
            if (Request.ApplicationPath.Length == 1)
                return Request.ApplicationPath;
            else
                return string.Concat(Request.ApplicationPath, "/");
        }

        /// <summary>
        /// Gets the current user host name
        /// </summary>
        public string GetServerHostName()
        {
            return string.Concat("http://", Request.ServerVariables["SERVER_NAME"]);
        }

        /// <summary>
        /// Gets the full path of current web appliaction, including UseHostName and ApplicationPath
        /// </summary>
        public string GetFullApplicationPath()
        {
            return GetServerHostName() + GetApplicationPath();
        }

        /// <summary>
        /// Get full path of resource file in the current theme.
        /// </summary>
        /// <param name="resourcePathInTheme">The rest of resource path App_Themes/[Theme name]/[ResourcePathInTheme here]. 
        /// Ex: images/btn_login.jpg
        /// </param>
        /// <returns>Full path of resource file.</returns>
        public string GetCurrentThemePath(string resourcePathInTheme)
        {
            return string.Format("{2}App_Themes/{0}/{1}", this.Theme, resourcePathInTheme, GetApplicationPath());
        }

        /// <summary>
        /// Get current theme path.
        /// Ex: App_Themes/[Theme name]/
        /// </summary>
        /// <returns>Current theme path.</returns>
        protected string GetCurrentThemePath()
        {
            return GetCurrentThemePath(string.Empty);
        }

        /// <summary>
        /// Get full path of the RadControl SkinsPath
        /// </summary>
        /// <returns>Full path of the RadControl SkinsPath</returns>
        protected string GetRadControlSkinsPath()
        {
            return string.Format("{0}RadControls/", GetCurrentThemePath());
        }

        /// <summary>
        /// Register localization messages at client-side.
        /// To use message at client-side, call CWXMessages.[ResourceCategory]_[ResourceKey]
        /// Note: register messages before OnPreRender event occur.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        public void RegisterLocalizationMessage(string resourceKey, ResourceCategory resCategory)
        {
            RegisterLocalizationMessage(resourceKey, resCategory, null);
        }

        /// <summary>
        /// Register localization messages at client-side.
        /// To use message at client-side, call CWXMessages.[ResourceCategory]_[ResourceKey]
        /// Note: register messages before OnPreRender event occur.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <param name="args">Array of System.Object to format</param>
        public void RegisterLocalizationMessage(string resourceKey, ResourceCategory resCategory, params object[] args)
        {
            if (_localizationMessages == null)
                _localizationMessages = new List<string[]>();

            if (args == null || args.Length == 0)
            {
                _localizationMessages.Add(new string[] {
                                        string.Format("{0}_{1}", Enum.GetName(resCategory.GetType(), resCategory), resourceKey), 
                                        CWXResourceManager.GetString(resCategory, resourceKey)
                                        });
            }
            else
            {
                _localizationMessages.Add(new string[] {
                                        string.Format("{0}_{1}", Enum.GetName(resCategory.GetType(), resCategory), resourceKey), 
                                        string.Format(CWXResourceManager.GetString(resCategory, resourceKey), args)
                                        });
            }
        }

        /// <summary>
        /// Refresh current page.
        /// </summary>
        public void RefreshPage()
        {
            Response.Redirect(Request.RawUrl);
        }

        /// <summary>
        /// Get postback control.
        /// </summary>
        /// <param name="page">Page to get postback control</param>
        /// <returns>Postback control if found, else return null.</returns>
        /// <history>
        ///     2008/05/02  [Binh Truong]   Init version.
        ///     2008/06/02  [Binh Truong]   Check IsNullOrEmpty for Request.Form collection.
        /// </history>
        public Control GetPostBackControl(Page page)
        {
            Control control = null;
            string postBackControlName = Request.Params.Get("__EVENTTARGET");
            string eventArgument = Request.Params.Get("__EVENTARGUMENT");

            if (!string.IsNullOrEmpty(postBackControlName))
            {
                control = Page.FindControl(postBackControlName);
            }
            else
            {
                foreach (string str in Request.Form)
                {
                    if (!string.IsNullOrEmpty(str))
                    {
                        Control c = Page.FindControl(str);
                        if (c is Button)
                        {
                            control = c;
                            break;
                        }
                    }
                }
            }

            return control;
        }

        /// <summary>
        /// Check permission of current user.
        /// </summary>
        /// <param name="throwException">Indicates whether throw exception user does not have permission or not.</param>
        /// <history>
        ///     2008/09/10  [Binh Truong]   Update throw CWXAuthorizationException.
        /// </history>
        public bool CheckPermission(CWXPermissionConstant permission, bool throwException)
        {
            bool hasPermission = CWXAuthorizationManager.Authorize(Thread.CurrentPrincipal, permission);
            if (throwException && !hasPermission)
                throw new CWXAuthorizationException(permission);

            return hasPermission;
        }

        #endregion

        #region Override Methods

        /// <summary>
        /// Sets the System.Web.UI.Page.Culture and System.Web.UI.Page.UICulture for the current thread of the page.
        /// </summary>
        protected override void InitializeCulture()
        {
            try
            {
                if (HttpContext.Current.User != null && HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    string language = HttpContext.Current.Profile.GetPropertyValue("Culture").ToString();
                    if (!string.IsNullOrEmpty(language))
                    {
                        Thread.CurrentThread.CurrentUICulture = new CultureInfo(language);
                        Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(language);

                        //resolve Arabic culture problem with Calendar control
                        Thread.CurrentThread.CurrentCulture.DateTimeFormat.Calendar = new GregorianCalendar();
                    }
                }
            }
            catch { }
        }

        /// <summary>
        /// Raises the System.Web.UI.Control.Init event to initialize the page.
        /// </summary>
        /// <param name="e">An System.EventArgs that contains the event data.</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Check session available
            if (CWXSessionState.CurrentUser == null)
                RedirectToLoginPage();

            if (ScriptMan != null)
            {
                ScriptMan.AsyncPostBackError += new EventHandler<AsyncPostBackErrorEventArgs>(scriptManager_AsyncPostBackError);
                // Comment out this line to allow the redirect.
                ScriptMan.AllowCustomErrorsRedirect = false;
            }

            this.Response.Cache.SetCacheability(HttpCacheability.NoCache);

            //Prevents the one-click attack [Microsoft Security Guideline ASP.NET 2.0]
            this.ViewStateUserKey = Session.SessionID;

            //Check the user's permissions.
            this.Authorize();

            //Update DbConnectionName of Profile if not
            if (SessionManager.GetObject(sessionKeyUpdateProfile) != null && !HttpContext.Current.Profile.IsAnonymous)
            {
                HttpContext.Current.Profile.SetPropertyValue("DbConnectionName", SessionManager.GetObject(sessionKeyUpdateProfile).ToString());
                HttpContext.Current.Profile.Save();
                SessionManager.RemoveObject(sessionKeyUpdateProfile);
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            HandleDuplicateRequiredErrorMessage();
            HandleOnBeforeUnloadEvent();

            this.RegisterTelerikWindowManager();
        }

        protected override void Render(HtmlTextWriter writer)
        {
            this.RegisterGlobalClientVariables();
            this.RegisterClientLocalizationMessages();
            base.Render(writer);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Register Telerik window manager.
        /// </summary>
        /// <history>
        ///     08/07/04    [Binh Truong]   Add check this functionality is enable or not.
        /// </history>

        private void RegisterTelerikWindowManager()
        {
            if (TelerikWindowEmbedEnable)
            {
                Telerik.WebControls.RadWindowManager windowManager = new Telerik.WebControls.RadWindowManager();
                windowManager.Modal = true;
                windowManager.Title = "CWX";
                windowManager.VisibleStatusbar = false;
                windowManager.SingleNonMinimizedWindow = true;
                //No minimize button because it makes the window no more modal
                //windowManager.Behavior = Telerik.WebControls.RadWindowBehaviorFlags.Close | Telerik.WebControls.RadWindowBehaviorFlags.Maximize
                //| Telerik.WebControls.RadWindowBehaviorFlags.Move | Telerik.WebControls.RadWindowBehaviorFlags.Reload | Telerik.WebControls.RadWindowBehaviorFlags.Resize;

                if (Page.Form != null)
                    Page.Form.Controls.Add(windowManager);
            }
        }
        private void HandleDuplicateRequiredErrorMessage()
        {

        }

        /// <summary>
        /// Register global client variables for client-side.
        /// </summary>
        private void RegisterGlobalClientVariables()
        {
            string scriptKey = "ClientGlobalVariables";
            if (!ClientScript.IsClientScriptBlockRegistered(scriptKey))
            {
                StringBuilder sb = new StringBuilder();

                // Application Path
                sb.AppendFormat("var g_AppPath=\"{0}\";", Request.ApplicationPath.Length == 1 ? Request.ApplicationPath : string.Concat(Request.ApplicationPath, "/"));
                sb.AppendFormat("var g_AppImgPath=\"{0}{1}\";", GetCurrentThemePath(), "Images/");
                sb.AppendFormat("var g_AppImgCalendarPath=\"{0}{1}\";", GetCurrentThemePath(), "Images/calendar/");
                // Module Path
                sb.AppendFormat("var g_EmployeeModulePath=\"{0}/{1}\";", Request.ApplicationPath, "Employee/");
                sb.AppendFormat("var g_AppSetupModulePath=\"{0}/{1}\";", Request.ApplicationPath, "ApplicationSetup/");
                // Culture
                sb.AppendFormat("var g_CurrentCulture=\"{0}\";", Thread.CurrentThread.CurrentUICulture.Name);
                sb.AppendFormat("var g_ShortDatePattern=\"{0}\";", GlobalSettingCulture.DateTimeFormat.ShortDatePattern);
                sb.AppendFormat("var g_ShortTimePattern=\"{0}\";", GlobalSettingCulture.DateTimeFormat.ShortTimePattern);

                // Pages
                sb.AppendFormat("var g_DefaultPage=\"{0}\";", FormsAuthentication.DefaultUrl);
                sb.AppendFormat("var g_LoginPage=\"{0}\";", FormsAuthentication.LoginUrl);
                sb.AppendFormat("var g_LogOutPage=\"{0}\";", Page.ResolveUrl("~/SignOut.aspx"));

                this.ClientScript.RegisterClientScriptBlock(this.GetType(), scriptKey, sb.ToString(), true);
            }
        }

        /// <summary>
        /// Register client localization messages script on client side.
        /// </summary>
        private void RegisterClientLocalizationMessages()
        {
            InitDefaultClientMessages();
            if (_localizationMessages != null && _localizationMessages.Count > 0)
            {
                string scriptKey = "ClientLocalizationMesssages";
                if (!ClientScript.IsClientScriptBlockRegistered(scriptKey))
                {
                    StringBuilder sb = new StringBuilder();
                    sb.Append("CWXMessages={");
                    sb.AppendLine();
                    for (int i = 0; i < _localizationMessages.Count - 1; i++)
                    {
                        sb.AppendFormat(
                            "\"{0}\":\"{1}\",",
                            _localizationMessages[i][0],
                            _localizationMessages[i][1]
                        );
                    }
                    if (_localizationMessages.Count != 0)
                    {
                        sb.AppendFormat(
                            "\"{0}\":\"{1}\"",
                            _localizationMessages[_localizationMessages.Count - 1][0],
                            _localizationMessages[_localizationMessages.Count - 1][1]
                        );
                    }
                    sb.Append("};");

                    if (ScriptMan == null)
                        ClientScript.RegisterClientScriptBlock(this.GetType(), scriptKey, sb.ToString(), true);
                    else
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), scriptKey, sb.ToString(), true);
                }
            }
        }

        /// <summary>
        /// Init default client messages.
        /// </summary>
        private void InitDefaultClientMessages()
        {
            RegisterLocalizationMessage("WebCommon_UnhandlerError1", ResourceCategory.Errors);
            RegisterLocalizationMessage("WebCommon_NoCheckedBox", ResourceCategory.Strings);
        }

        /// <summary>
        /// Handle OnBeforeUnload event on client-side.
        /// </summary>
        private void HandleOnBeforeUnloadEvent()
        {
            string scriptKey = "HandleOnBeforeUnloadEvent";
            if (!ClientScript.IsStartupScriptRegistered(this.GetType(), scriptKey))
            {
                StringBuilder sbScript = new StringBuilder();
                sbScript.Append("function onBeforeUnloadHandler() {");

                if (LoadingProgressVisible)
                    sbScript.Append("try{if(!window.disableLoading){cwx_ShowLoadingIndicator(true);window.disableLoading=false;}}catch(e){}");

                //If we are in edit mode, register the script
                if (CheckDirtyEnable)
                {
                    sbScript.Append("if($get('__ISDIRTY')){if($get('__ISDIRTY').value=='true'){ return '");
                    sbScript.Append(NonSavedConfirmMessage);
                    sbScript.Append("';}}");

                    this.ClientScript.RegisterHiddenField("__ISDIRTY", "false");
                    ClientScript.RegisterClientScriptBlock(
                        this.GetType(),
                        "dirtyCheck",
                        "function dirtyCheck(isBypass) {$get('__ISDIRTY').value = isBypass;}",
                        true
                        );
                }
                sbScript.Append("}");
                sbScript.Append("window.onbeforeunload = onBeforeUnloadHandler;");
                //ClientScript.RegisterStartupScript(this.GetType(), scriptKey, sbScript.ToString(), true);
                ScriptManager.RegisterStartupScript(this, this.GetType(), scriptKey, sbScript.ToString(), true);
            }

            if (LoadingProgressVisible)
                RegisterAnchorPreventEvent();
        }

        /// <summary>
        /// Prevent click event when all anchors in case using javascript.
        /// </summary>
        private void RegisterAnchorPreventEvent()
        {
            string anchorCallScriptKey = "anchorCallScript";
            string anchorFunctionScriptKey = "anchorFunctionScript";
            if (!ClientScript.IsStartupScriptRegistered(this.GetType(), anchorCallScriptKey))
            {
                string anchorFunctionScript = @"function cwx_AnchorPreventEvent(){
                        if(window.attachEvent){
                            var a = document.getElementsByTagName('A');
                            for (i=0;i<a.length;i++)
                                if (a[i].protocol=='javascript:' && a[i].href.indexOf('void(0)')!=-1)
                                    a[i].attachEvent('onclick',function(){window.disableLoading=true;});
                        }
                    }";
                ClientScript.RegisterClientScriptBlock(this.GetType(), anchorFunctionScriptKey, anchorFunctionScript, true);

                string anchorCallScript = "try{cwx_AnchorPreventEvent();}catch(e){}";
                ScriptManager.RegisterStartupScript(this, this.GetType(), anchorCallScriptKey, anchorCallScript, true);
            }
        }

        #endregion

        #region Virtual Methods


        /// <summary>
        /// Authorize user. If user don't have permission on this page, throw a CWXAuthorizationException
        /// </summary>
        protected virtual void Authorize()
        {
            if (!CWXAuthorizationManager.Authorize(Thread.CurrentPrincipal, CWXPermissionConstant.ACCESS_CWX_SYSTEM))
            {
                throw new CWXAuthorizationException(CWXPermissionConstant.ACCESS_CWX_SYSTEM);
            }
        }

        #endregion

        #region Error Handler

        /// <summary>
        /// Error handler for unhandled exception.
        /// </summary>
        private void scriptManager_AsyncPostBackError(object sender, AsyncPostBackErrorEventArgs e)
        {
#if (DEBUG)
            if (ScriptMan != null)
            {
                ScriptMan.AsyncPostBackErrorMessage = e.Exception.Message;
            }
#else
            if (ScriptMan != null) {
                ScriptMan.AsyncPostBackErrorMessage = 
                    CWXResourceManager.GetString(ResourceCategory.Errors, "WebCommon_UnhandlerError");
            }            
#endif

        }

        #endregion
    }
}
