using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.UI
{
    /// <summary>
    /// Indicates the webpage status.
    /// </summary>
    public enum PageStatus
    {
        /// <summary>
        /// Not specify.
        /// </summary>
        Unspecify,
        Add,
        Edit,
        Copy,
        View,
        EditRestricted
    }

	public enum AfterSavingStatus
	{
		None,
		CloseWindow,
		BackToPrevious
	}
}
