using System;
using System.Globalization;
using System.Web.Security;

using CWX.Core.Common;

namespace CWX.Core.UI
{
    public class CWXApplicationState
    {
        private const string GlobalSettingCultureKey = "__GlobalSettingCulture_";
        /// <summary>
        /// Global culture settings.
        /// </summary>
        /// <history>
        ///     2008/06/05  [LongNguyen]    Init version.
        /// </history>
        public static CultureInfo GlobalSettingCulture
        {
            get
            {
                return ApplicationManager.GetObject(GlobalSettingCultureKey + ConnectionManager.CWXDatabaseName) as CultureInfo;
            }
            set
            {
                ApplicationManager.SetObject(GlobalSettingCultureKey + ConnectionManager.CWXDatabaseName, value);
            }
        }
    }
}
