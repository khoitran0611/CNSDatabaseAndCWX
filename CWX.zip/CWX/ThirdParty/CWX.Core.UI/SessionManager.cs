using System;
using System.Web;
using System.Web.SessionState;

namespace CWX.Core.UI
{
    /// <summary>
    /// This class can be seen as a wrapper of the Session object.
    /// </summary>
    public class SessionManager
    {

        public SessionManager()
        {
        }

        public static void AddObject(string name, object value)
        {
            CurrentSession.Add(name, value);
        }

        public static void SetObject(string name, object value)
        {
            if (CurrentSession == null)
                throw new InvalidOperationException("Session has been expired.");

            CurrentSession[name] = value;
        }

        public static object GetObject(string name)
        {
            if (CurrentSession == null)
                return null;
            return CurrentSession[name];
        }

        public static void RemoveObject(string name)
        {
            CurrentSession.Remove(name);
        }

        public static HttpSessionState CurrentSession
        {
            get
            {
                return HttpContext.Current.Session;
            }
        }

        public static void ClearSession()
        {
            CurrentSession.Clear();
        }

        public static void AbandonSession()
        {
            CurrentSession.Abandon();
        }
    }
}