using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.Security;
using System.Globalization;

namespace CWX.Core.UI
{
    /// <summary>
    /// Represents a CWX user control, requested from a server that hosts an ASP.NET Web application. 
    /// The file must be called from a Web Forms page or a parser error will occur.
    /// </summary>
    public class CWXUserControl : UserControl
    {
        #region Properties

        /// <summary>
        /// The parent page, instance of <see cref="CWX.Core.UI.CWXPage"/>, of this user control.
        /// </summary>
        protected CWXPage CWXPageBase
        {
            get 
            { 
                return this.Page as CWXPage; 
            }
        }

        protected bool IsViewMode
        {
            get
            {

                return string.IsNullOrEmpty(Request["IsViewMode"]) ? false : string.Equals(Request["IsViewMode"], "true", StringComparison.InvariantCultureIgnoreCase);
            }
        }

        #endregion

        #region Virtual methods

        /// <summary>
        /// Override this method to authorize user.
        /// </summary>
        protected virtual void Authorize()
        {
            
        }

        #endregion

        #region Override methods

        /// <summary>
        /// Raises the <see cref="System.Web.UI.Control.Init"/> event.
        /// </summary>
        /// <param name="e">An System.EventArgs object that contains the event data.</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Check the user's permissions.
            this.Authorize();
        }

        #endregion

        /// <summary>
        /// Register <see cref="System.Web.UI.IAttributeAccessor"/> control 
        /// for bypass non-saved confirm message.
        /// </summary>
        protected void RegisterByPassConfirmControl(IAttributeAccessor control)
        {
            CWXPageBase.RegisterByPassConfirmControl(control);
        }

        /// <summary>
        /// Get current web application path.
        /// </summary>
        protected string GetApplicationPath()
        {
            return CWXPageBase.GetApplicationPath();
        }

        /// <summary>
        /// Get full path of resource file in the current theme.
        /// </summary>
        /// <param name="resourcePathInTheme">The rest of resource path App_Themes/[Theme name]/[ResourcePathInTheme here]. 
        /// Ex: images/btn_login.jpg
        /// </param>
        /// <returns>Full path of resource file.</returns>
        protected string GetCurrentThemePath(string resourcePathInTheme)
        {
            return CWXPageBase.GetCurrentThemePath(resourcePathInTheme);
        }

        /// <summary>
        /// Get current theme path.
        /// Ex: App_Themes/[Theme name]/
        /// </summary>
        /// <returns>Current theme path.</returns>
        protected string GetCurrentThemePath()
        {
            return GetCurrentThemePath(string.Empty);
        }

        protected void RefreshPage()
        {
            CWXPageBase.RefreshPage();            
        }

        protected CultureInfo GlobalSettingCulture
        { 
            get
            {
                return CWXPageBase.GlobalSettingCulture;
            }            
        }
    }
}
