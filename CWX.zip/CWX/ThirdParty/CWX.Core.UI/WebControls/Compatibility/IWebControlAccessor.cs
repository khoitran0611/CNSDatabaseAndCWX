namespace CWX.Core.UI.WebControls.Compatibility {
    using System.Web.UI;

    internal interface IWebControlAccessor {
        HtmlTextWriterTag TagKey {
            get;
        }
    }
}
