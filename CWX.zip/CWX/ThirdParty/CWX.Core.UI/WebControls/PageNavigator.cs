using System;
using System.Collections;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using CWX.Core.Common.Resource;
using System.Collections.ObjectModel;

namespace CWX.Core.UI.WebControls
{
    [ToolboxData("<{0}:PageNavigator runat=server></{0}:PageNavigator>")]
    public class PageNavigator : Control, INamingContainer
    {
        public delegate void PageIndexChangedEventHandler(object sender, PagingEventArgs e);
        public event PageIndexChangedEventHandler PageIndexChanged;

        private Collection<Control> controls;

        #region Properties

        public string CssClass
        {
            get
            {
                if (ViewState["CssClass"] == null)
                    return string.Empty;

                return (string)ViewState["CssClass"];
            }
            set { ViewState["CssClass"] = value; }
        }

        public bool ShowSummary
        {
            get
            {
                if (ViewState["ShowSummary"] == null)
                    return true;

                return (bool)ViewState["ShowSummary"];
            }
            set { ViewState["ShowSummary"] = value; }
        }

        public bool DisplayPageTotal
        {
            get
            {
                if (ViewState["DisplayPageTotal"] == null)
                    return false;

                return (bool)ViewState["DisplayPageTotal"];
            }
            set { ViewState["DisplayPageTotal"] = value; }
        }

        public bool IsFooter
        {
            get
            {
                if (ViewState["IsFooter"] == null)
                    return false;

                return (bool)ViewState["IsFooter"];
            }
            set
            {
                ViewState["IsFooter"] = value;
            }
        }

        /// <summary>
        /// Total record found.
        /// </summary>
        public int ItemCount
        {
            get
            {
                if (ViewState["ItemCount"] == null)
                    return 0;

                return Convert.ToInt32(ViewState["ItemCount"]);
            }
            set
            {
                ViewState["ItemCount"] = value;
            }
        }

        public int PageCount
        {
            get
            {
                if (ViewState["PageCount"] == null)
                    return -1;

                return Convert.ToInt32(ViewState["PageCount"]);
            }
            set
            {
                ViewState["PageCount"] = value;
            }
        }

        /// <summary>
        /// Total item in a page.
        /// This property can manual set or it will 
        /// get in web.config/AppSettings/PageSize value automatically. 
        /// Default is 10.
        /// </summary>
        public int PageSize
        {
            get
            {
                if (ViewState["PageSize"] == null)
                {
                    string pageSize = ConfigurationManager.AppSettings["PageSize"];
                    if (pageSize != null)
                        return Convert.ToInt32(pageSize);
                    return 10;
                }

                return Convert.ToInt32(ViewState["PageSize"]);
            }
            set
            {
                ViewState["PageSize"] = value;
            }
        }

        /// <summary>
        /// Amount of navigator number.
        /// Default is 5.
        /// </summary>
        public int GroupSize
        {
            get
            {
                if (ViewState["GroupSize"] == null)
                    return 5;

                return Convert.ToInt32(ViewState["GroupSize"]);
            }
            set
            {
                ViewState["GroupSize"] = value;
            }
        }

        [Browsable(false)]
        public int CurrentPageIndex
        {
            get
            {
                if (ViewState["CurrentPageIndex"] == null)
                    return 0;

                return Convert.ToInt32(ViewState["CurrentPageIndex"]);
            }
            set
            {
                ViewState["CurrentPageIndex"] = value;
                if (value == 0)
                    this.CurrentGroupIndex = 0;
                else
                    this.CurrentGroupIndex = this.CurrentPageIndex / this.GroupSize;
            }
        }

        [Browsable(false)]
        public int CurrentGroupIndex
        {
            get
            {
                if (ViewState["CurrentGroupIndex"] == null)
                    return 0;

                return Convert.ToInt32(ViewState["CurrentGroupIndex"]);
            }
            set
            {
                ViewState["CurrentGroupIndex"] = value;
            }
        }

        public int NumOfPage
        {
            get
            {
                if (PageCount == -1)
                {
                    if (PageSize > 0)
                    {
                        if (ItemCount % PageSize == 0)
                            return ItemCount / PageSize;
                        else
                            return (ItemCount / PageSize) + 1;
                    }
                    else
                        return 1;
                }
                else
                    return PageCount;

            }
        }

        protected int GroupCount
        {
            get
            {
                if (NumOfPage % GroupSize == 0)
                    return NumOfPage / GroupSize;
                else
                    return (NumOfPage / GroupSize) + 1;
            }
        }

        #endregion

        #region Creating for Design
        private Literal NewLiteral(string text)
        {
            Literal lb = new Literal();
            lb.Text = text;
            return lb;
        }


        private void CreateFirstPreviousDesign()
        {
            if (this.CurrentPageIndex > 0)
            {
                //first group
                LinkButton lbtnFirst = new LinkButton();
                lbtnFirst.ID = "btnFirst";
                lbtnFirst.Text = string.Format("[{0}]", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_First"));
                lbtnFirst.CausesValidation = false;
                lbtnFirst.CssClass = "Link_menu";
                controls.Add(NewLiteral("&nbsp;&nbsp;&nbsp;"));
                controls.Add(lbtnFirst);
                controls.Add(NewLiteral("&nbsp;"));
                lbtnFirst.Click += new EventHandler(this.FirstClick);

                //previous group
                LinkButton lbtnPrev = new LinkButton();
                lbtnPrev.ID = "btnPrevious";
                lbtnPrev.Text = string.Format("[{0}]", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_Previous"));
                lbtnPrev.CausesValidation = false;
                lbtnPrev.CssClass = "Link_menu";
                controls.Add(lbtnPrev);
                lbtnPrev.Click += new EventHandler(this.PreviousClick);
            }
            else
            {
                controls.Add(NewLiteral(string.Format("&nbsp;&nbsp;&nbsp;<span>[{0}]</span>&nbsp;", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_First"))));
                controls.Add(NewLiteral(string.Format("<span>[{0}]</span>", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_Previous"))));
            }
        }

        private void CreatePageSelectorDesign()
        {
            controls.Add(NewLiteral("<strong>"));
            for (int i = 0; i < this.GroupSize; i++)
            {
                int p = i + this.CurrentGroupIndex * this.GroupSize;
                if (p < this.NumOfPage)
                {
                    controls.Add(NewLiteral("&nbsp;&nbsp;"));

                    if (p == this.CurrentPageIndex)
                        controls.Add(NewLiteral((p + 1).ToString()));
                    else
                    {
                        LinkButton lbtnPage = new LinkButton();
                        lbtnPage.ID = "lbtnPage" + p.ToString();
                        lbtnPage.CausesValidation = false;
                        lbtnPage.Text = (p + 1).ToString();
                        controls.Add(lbtnPage);
                        lbtnPage.Click += new EventHandler(this.PageClick);
                    }
                }
            }
            controls.Add(NewLiteral("</strong>"));
        }
        private void CreateNextLastDesign()
        {
            controls.Add(NewLiteral("&nbsp;"));
            if (this.CurrentPageIndex < this.NumOfPage - 1)
            {
                //next group
                LinkButton lbtnNext = new LinkButton();
                lbtnNext.ID = "btnNext";
                lbtnNext.Text = string.Format("[{0}]", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_Next"));
                lbtnNext.CausesValidation = false;
                lbtnNext.CssClass = "Link_menu";
                controls.Add(lbtnNext);
                lbtnNext.Click += new EventHandler(this.NextClick);

                ////last group
                LinkButton lbtnLast = new LinkButton();
                lbtnLast.ID = "btnLast";
                lbtnLast.Text = string.Format("[{0}]", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_Last"));
                lbtnLast.CausesValidation = false;
                lbtnLast.CssClass = "Link_menu";
                controls.Add(NewLiteral("&nbsp;"));
                controls.Add(lbtnLast);
                lbtnLast.Click += new EventHandler(this.LastClick);
            }
            else
            {
                controls.Add(NewLiteral(string.Format("[{0}]", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_Next"))));
                controls.Add(NewLiteral(string.Format("&nbsp;[{0}]", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_Last"))));
            }

        }

        private void CreateControlsForDesign()
        {
            controls = new Collection<Control>();

            if (NumOfPage > 1)
            {
                CreateFirstPreviousDesign();

                CreatePageSelectorDesign();

                controls.Add(NewLiteral("&nbsp;"));
                CreateNextLastDesign();
            }
            CreateSummaryInfo();
        }

        private void CreateSummaryInfo()
        {
            HtmlTable tbl = new HtmlTable();
            tbl.Width = "100%";
            tbl.Border = 0;
            tbl.CellPadding = 0;
            tbl.CellSpacing = 0;
            if (CssClass.Length > 0)
                tbl.Attributes.Add("class", CssClass);

            HtmlTableRow row = new HtmlTableRow();

            HtmlTableCell col1 = new HtmlTableCell();
            col1.Align = "right";

            if (ShowSummary)
            {
                if (DisplayPageTotal)
                {
                    col1.Controls.Add(NewLiteral(string.Format("<b>" + CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_TotalPage") + "</b>", this.NumOfPage)));
                }
                else
                {
                    col1.Controls.Add(NewLiteral(string.Format("<b>" + CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_TotalRecord") + "</b>", this.ItemCount)));
                }
            }
            

            for (int i = 0; i < controls.Count; i++)
                col1.Controls.Add((Control)controls[i]);
            row.Controls.Add(col1);

            tbl.Rows.Add(row);
            this.Controls.Add(tbl);
        }

        #endregion

        private void OnPageIndexChanged(int newPage)
        {
            if (this.PageIndexChanged != null)
                this.PageIndexChanged(this, new PagingEventArgs(newPage));
        }

        protected void PreviousClick(object sender, System.EventArgs e)
        {
            if (this.CurrentPageIndex == this.CurrentGroupIndex * this.GroupSize && this.CurrentGroupIndex > 0)
            {
                this.CurrentGroupIndex--;
                this.CurrentPageIndex--;
            }
            else if (this.CurrentPageIndex > 0)
                this.CurrentPageIndex--;

            CreateChildControls();
            OnPageIndexChanged(this.CurrentPageIndex);
        }

        protected void NextClick(object sender, System.EventArgs e)
        {
            if (this.CurrentPageIndex + 1 == (this.CurrentGroupIndex + 1) * this.GroupSize && this.CurrentGroupIndex < this.GroupCount - 1)
            {
                this.CurrentGroupIndex++;
                this.CurrentPageIndex = this.CurrentGroupIndex * this.GroupSize;
            }
            else if (this.CurrentPageIndex < this.NumOfPage - 1)
                this.CurrentPageIndex++;

            CreateChildControls();
            OnPageIndexChanged(this.CurrentPageIndex);
        }

        protected void FirstClick(object sender, System.EventArgs e)
        {
            this.CurrentGroupIndex = 0;
            this.CurrentPageIndex = 0;

            CreateChildControls();
            OnPageIndexChanged(this.CurrentPageIndex);
        }

        protected void LastClick(object sender, System.EventArgs e)
        {
            this.CurrentGroupIndex = this.GroupCount - 1;
            this.CurrentPageIndex = this.NumOfPage - 1;

            CreateChildControls();
            OnPageIndexChanged(this.CurrentPageIndex);
        }

        protected void PageClick(object sender, System.EventArgs e)
        {
            LinkButton lbtn = sender as LinkButton;

            this.CurrentPageIndex = Convert.ToInt32(lbtn.Text) - 1;
            CreateChildControls();
            OnPageIndexChanged(Convert.ToInt32(lbtn.Text) - 1);
        }


        protected override void CreateChildControls()
        {
            this.Controls.Clear();
            CreateControlsForDesign();
        }
    }

    /// <summary>
    /// Paging event arguments. 
    /// Created by Binh Truong.
    /// </summary>
    public class PagingEventArgs : EventArgs
    {
        int m_NewPageIndex;

        public PagingEventArgs(int newPageIndex)
        {
            this.m_NewPageIndex = newPageIndex;
        }

        /// <summary>
        /// New page index.
        /// </summary>
        public int NewPageIndex
        {
            get { return m_NewPageIndex; }
            set { m_NewPageIndex = value; }
        }
    }
}
