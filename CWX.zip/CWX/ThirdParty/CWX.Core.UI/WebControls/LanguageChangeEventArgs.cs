using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.UI.WebControls
{
    public delegate void LanguageChangedEventHandler(object sender, LanguageChangeEventArgs args);

    public class LanguageChangeEventArgs : EventArgs
    {

        public LanguageChangeEventArgs()
            : base()
        { 
        }

        public LanguageChangeEventArgs(string culture)
        { 
        }

        private string _culture;
        public string Culture
        {
            get { return _culture; }
            set { _culture = value; }
        }
	
    }
}
