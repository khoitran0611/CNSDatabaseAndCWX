using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace CWX.Core.UI.WebControls
{
    /// <summary>
    /// Represents a message list webcontrol.
    /// </summary>
    [ToolboxData("<{0}:MessageList runat=server>MessageList</{0}:MessageList>")]
    public class MessageList : Control, INamingContainer
    {

        /// <summary>
        /// Message type.
        /// </summary>
        public enum MessageType 
        {
            Message,
            Error
        }

        private List<string> _errorMessages = new List<string>();
        private string _message;
        private readonly string _errorMessagesUIClass = "ErrorMsg";
        private readonly string _errorMessageUIClass = "ErrorMsg2";
        private readonly string _messageUIClass = "MessageBox";

        /// <summary>
        /// Called by the ASP.NET page framework to notify server controls that use composition-based
        /// implementation to create any child controls they contain in preparation for
        /// posting back or rendering.
        /// </summary>
        protected override void CreateChildControls()
        {
            this.Controls.Clear();
            
            this.ErrorMessageRender();
            this.MessageRender();            
        }

        /// <summary>
        /// Render error messages to HTML.
        /// </summary>
        private void ErrorMessageRender()
        {
            if (_errorMessages.Count == 0)
                return;

            StringBuilder sbMessages = new StringBuilder();
            StringBuilder liMessages = new StringBuilder();
            
            if (_errorMessages.Count > 1)
            {
                sbMessages.AppendFormat("<div id=\"{0}\" class=\"{1}\" >", this.ClientID, _errorMessagesUIClass);
                foreach (string message in _errorMessages)
                {
                    liMessages.AppendFormat("<li>{0}</li>", message);
                }
                sbMessages.AppendFormat("<ul>{0}</ul>", liMessages.ToString());
            }
            if (_errorMessages.Count == 1)
            {
                sbMessages.AppendFormat("<div id=\"{0}\" class=\"{1}\" >", this.ClientID, _errorMessageUIClass);
                liMessages.AppendFormat("<li>{0}</li>", _errorMessages[0]);
                sbMessages.AppendFormat("<ul>{0}</ul>", liMessages.ToString());
            }
            sbMessages.Append("</div>");
                        
            Literal litHolder = new Literal();
            litHolder.Text = sbMessages.ToString();
            this.Controls.Add(litHolder);
        }

        /// <summary>
        /// Render message to HTML.
        /// </summary>
        private void MessageRender()
        {
            if (string.IsNullOrEmpty(_message))
                return;

            StringBuilder sbMessages = new StringBuilder();
            sbMessages.AppendFormat("<div id=\"{0}\" class=\"{1}\" >", this.ClientID, _messageUIClass);
            sbMessages.Append(_message);
            sbMessages.Append("</div>");

            Literal litHolder = new Literal();
            litHolder.Text = sbMessages.ToString();
            this.Controls.Add(litHolder);
        }

        /// <summary>
        /// Add message.
        /// </summary>
        /// <param name="type">Message type.</param>
        public void AddMessage(string message, MessageType type)
        {
            if (type == MessageType.Error)
            {
                _errorMessages.Add(message);
            }
            else if (type == MessageType.Message)
            {
                _message = message;
            }            
        }
    }
}
