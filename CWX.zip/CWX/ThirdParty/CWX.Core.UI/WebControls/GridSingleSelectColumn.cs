using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Telerik.WebControls;
using System.Web.UI.HtmlControls;

namespace CWX.Core.UI.WebControls
{
    [ToolboxData("<{0}:GridSingleSelectColumn runat=server></{0}:GridSingleSelectColumn>")]
    public class GridSingleSelectColumn : GridButtonColumn
    {
        public override GridColumn Clone()
        {
            GridSingleSelectColumn column = new GridSingleSelectColumn();
            column.CopyBaseProperties(this);
            return column;
        }

        public override void InitializeCell(TableCell cell, int columnIndex, GridItem inItem)
        {
            base.InitializeCell(cell, columnIndex, inItem);
            if (!(inItem is GridHeaderItem) || base.Owner.OwnerGrid.AllowMultiRowSelection)
            {
                if ((inItem is GridDataItem) && !base.Owner.OwnerGrid.ClientSettings.Selecting.AllowRowSelect)
                {
                    throw new GridException("Please set ClientSettings.Selecting.AllowRowSelect to \"True\" to start using GridClientSelectColumn.");
                }
                if ((inItem is GridHeaderItem) || (inItem is GridDataItem))
                {
                    RadioButton child = new RadioButton();
                    child.ID = string.Format("{0}SelectCheckBox", this.UniqueName);
                    if ((inItem is GridHeaderItem) && base.Owner.OwnerGrid.AllowMultiRowSelection)
                    {
                        child.Attributes["onclick"] = string.Format("window[\"{0}\"].SelectAllRows(\"{1}\", \"{2}\", event)", base.Owner.OwnerGrid.ClientID, base.Owner.UniqueID, inItem.ItemIndex);
                    }
                    if (inItem is GridDataItem)
                    {
                        child.Checked = inItem.Selected;
                        child.Attributes["onclick"] = string.Format("window[\"{0}\"].SelectRow(\"{1}\", \"{2}\", event)", base.Owner.OwnerGrid.ClientID, base.Owner.UniqueID, inItem.ItemIndex);
                    }
                    cell.Controls.Clear();
                    cell.Controls.Add(child);
                    inItem.PreRender += new EventHandler(this.inItem_PreRender);
                }
            }
        }

        private void inItem_PreRender(object sender, EventArgs e)
        {
            RadioButton box = (RadioButton)((GridItem)sender).FindControl(string.Format("{0}SelectCheckBox", this.UniqueName));
            if (box != null)
            {
                box.Checked = ((GridItem)sender).Selected;
            }
        }
    }
}
