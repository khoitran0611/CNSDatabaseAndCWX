﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CWX.Core.Common.Resource;
using System.Collections.ObjectModel;
using Telerik.WebControls;

namespace CWX.Core.UI.WebControls
{
	[ToolboxData("<{0}:RecordNavigator runat=server></{0}:RecordNavigator>")]
	public class RecordNavigator : Control, INamingContainer
	{
		public delegate void RecordIndexChangedEventHandler(object sender, RecordNavigatorEventArgs e);
		public event RecordIndexChangedEventHandler RecordIndexChanged;

		#region Constants
		private const string RecordIndexViewStateKey = "CWX.Core.UI.WebControls.RecordNavigator.RecordIndex";
		private const string TotalRecordsViewStateKey = "CWX.Core.UI.WebControls.RecordNavigator.TotalRecords";
		#endregion

		private Collection<Control> controls;
		private RadNumericTextBox rtbRecordIndex = null;

		#region Properties
		public int CurrentRecordIndex
		{
			get
			{
				object obj = ViewState[RecordIndexViewStateKey];
				if (obj != null)
					return (int)obj;
				return 0;
			}

			set { ViewState[RecordIndexViewStateKey] = value; }
		}

		public int TotalRecords
		{
			get
			{
				object obj = ViewState[TotalRecordsViewStateKey];
				if (obj != null)
					return (int)obj;
				return 0;
			}

			set { ViewState[TotalRecordsViewStateKey] = value; }
		}		
		#endregion

		#region Override Methods
		protected override void CreateChildControls()
		{
			this.Controls.Clear();
			CreateControlsForDesign();
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
			CreateChildControls();
			if (rtbRecordIndex != null)
				rtbRecordIndex.ShowSpinButtons = false;			
		}
		#endregion

		#region Private Methods
		private void CreateControlsForDesign()
		{
			controls = new Collection<Control>();
			if (CurrentRecordIndex > 0 && TotalRecords > 0)
			{
				CreateFirstPreviousDesign();
				CreateRecordSelectorDesign();
				CreateNextLastDesign();
			}

			PopulateControls();
		}

		private void PopulateControls()
		{
			HtmlTable tbl = new HtmlTable();
			tbl.Width = "100%";
			tbl.Border = 0;
			tbl.CellPadding = 0;
			tbl.CellSpacing = 0;
			tbl.EnableViewState = true;

			HtmlTableRow row = new HtmlTableRow();
			HtmlTableCell col1 = new HtmlTableCell();
			col1.Align = "right";

			for (int i = 0; i < controls.Count; i++)
				col1.Controls.Add((Control)controls[i]);
			row.Controls.Add(col1);

			tbl.Rows.Add(row);
			this.Controls.Add(tbl);
		}

		private Literal NewLiteral(string text)
		{
			Literal lb = new Literal();
			lb.Text = text;
			return lb;
		}

		private void CreateFirstPreviousDesign()
		{
			if (this.CurrentRecordIndex > 1)
			{
				//first group
				LinkButton lbtnFirst = new LinkButton();
				lbtnFirst.ID = "btnFirst";
				lbtnFirst.Text = string.Format("[{0}]", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_First"));
				lbtnFirst.CausesValidation = false;
				lbtnFirst.CssClass = "Link_menu";
				controls.Add(NewLiteral("&nbsp;&nbsp;&nbsp;"));
				controls.Add(lbtnFirst);
				controls.Add(NewLiteral("&nbsp;"));
				lbtnFirst.Click += new EventHandler(this.FirstClick);

				//previous group
				LinkButton lbtnPrev = new LinkButton();
				lbtnPrev.ID = "btnPrevious";
				lbtnPrev.Text = string.Format("[{0}]", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_Previous"));
				lbtnPrev.CausesValidation = false;
				lbtnPrev.CssClass = "Link_menu";
				controls.Add(lbtnPrev);
				controls.Add(NewLiteral("&nbsp;"));
				lbtnPrev.Click += new EventHandler(this.PreviousClick);
			}
			else
			{
				controls.Add(NewLiteral(string.Format("&nbsp;&nbsp;&nbsp;<span>[{0}]</span>&nbsp;", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_First"))));
				controls.Add(NewLiteral(string.Format("<span>[{0}]</span>&nbsp;", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_Previous"))));
			}
		}

		private void CreateRecordSelectorDesign()
		{
			rtbRecordIndex = new RadNumericTextBox();
			rtbRecordIndex.ID = "rtbRecordIndex";
			rtbRecordIndex.ShowSpinButtons = false;
			rtbRecordIndex.Type = NumericType.Number;
			rtbRecordIndex.NumberFormat.DecimalDigits = 0;
			rtbRecordIndex.MaxLength = 3;
			rtbRecordIndex.Width = new Unit(30);
			rtbRecordIndex.CssClass = "InputText";
			rtbRecordIndex.MinValue = 1;
			rtbRecordIndex.MaxValue = this.TotalRecords;
			rtbRecordIndex.Value = this.CurrentRecordIndex;
			rtbRecordIndex.AutoPostBack = true;
			rtbRecordIndex.CausesValidation = false;
			controls.Add(rtbRecordIndex);
			rtbRecordIndex.TextChanged += new EventHandler(rtbRecordIndex_TextChanged);

			controls.Add(NewLiteral("<strong>"));
			controls.Add(NewLiteral("of "));
			controls.Add(NewLiteral(TotalRecords.ToString()));			
			controls.Add(NewLiteral("</strong>"));
			controls.Add(NewLiteral("&nbsp;"));
		}		

		private void CreateNextLastDesign()
		{
			controls.Add(NewLiteral("&nbsp;"));
			if (this.CurrentRecordIndex < this.TotalRecords)
			{
				//next group
				LinkButton lbtnNext = new LinkButton();
				lbtnNext.ID = "btnNext";
				lbtnNext.Text = string.Format("[{0}]", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_Next"));
				lbtnNext.CausesValidation = false;
				lbtnNext.CssClass = "Link_menu";
				controls.Add(lbtnNext);
				lbtnNext.Click += new EventHandler(this.NextClick);

				////last group
				LinkButton lbtnLast = new LinkButton();
				lbtnLast.ID = "btnLast";
				lbtnLast.Text = string.Format("[{0}]", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_Last"));
				lbtnLast.CausesValidation = false;
				lbtnLast.CssClass = "Link_menu";
				controls.Add(NewLiteral("&nbsp;"));
				controls.Add(lbtnLast);
				lbtnLast.Click += new EventHandler(this.LastClick);
			}
			else
			{
				controls.Add(NewLiteral(string.Format("[{0}]", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_Next"))));
				controls.Add(NewLiteral(string.Format("&nbsp;[{0}]", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_Last"))));
			}

		}

		private void OnRecordIndexChanged(int newRecordIndex)
		{
			if (this.RecordIndexChanged != null)
				this.RecordIndexChanged(this, new RecordNavigatorEventArgs(newRecordIndex));
		}
		#endregion

		#region Event Handlers
		protected void PreviousClick(object sender, System.EventArgs e)
		{
			this.CurrentRecordIndex--;

			CreateChildControls();
			OnRecordIndexChanged(this.CurrentRecordIndex);
		}

		protected void NextClick(object sender, System.EventArgs e)
		{
			this.CurrentRecordIndex++;

			CreateChildControls();
			OnRecordIndexChanged(this.CurrentRecordIndex);
		}

		protected void FirstClick(object sender, System.EventArgs e)
		{
			this.CurrentRecordIndex = 1;

			CreateChildControls();
			OnRecordIndexChanged(this.CurrentRecordIndex);
		}

		protected void LastClick(object sender, System.EventArgs e)
		{
			this.CurrentRecordIndex = TotalRecords;

			CreateChildControls();
			OnRecordIndexChanged(this.CurrentRecordIndex);
		}

		protected void rtbRecordIndex_TextChanged(object sender, EventArgs e)
		{
			if (rtbRecordIndex.Value.HasValue)
				this.CurrentRecordIndex = (int)rtbRecordIndex.Value;
			else
				this.CurrentRecordIndex = 0;

			CreateChildControls();
			OnRecordIndexChanged(this.CurrentRecordIndex);
		}
		#endregion
	}

	public class RecordNavigatorEventArgs : EventArgs
	{
		private int _recordIndex;

		public RecordNavigatorEventArgs(int newRecordIndex)
		{
			_recordIndex = newRecordIndex;
		}

		/// <summary>
		/// Gets the new record index.
		/// </summary>
		public int RecordIndex
		{
			get { return _recordIndex; }
		}
	}
}
