﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Collections.ObjectModel;
using Telerik.WebControls;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Web.UI.HtmlControls;
using System.Globalization;
using CWX.Core.Common.Resource;

namespace CWX.Core.UI.WebControls
{
	[ToolboxData("<{0}:CWXNumericRangeTextBox runat=server></{0}:CWXNumericRangeTextBox>")]
	public class CWXNumericRangeTextBox : WebControl, INamingContainer
	{
		#region Constants
		private const string CultureViewStateKey = "CWXNumericRangeTextBox.Culture";
		private const string ReadOnlyViewStateKey = "CWXNumericRangeTextBox.ReadOnly";
		private const string DecimalDigitsViewStateKey = "CWXNumericRangeTextBox.DecimalDigits";
		private const string IsRequiredViewStateKey = "CWXNumericRangeTextBox.IsRequired";
		#endregion

		#region Properties
		private RadNumericTextBox rtbRangeFromValue = new RadNumericTextBox();
		private RadNumericTextBox rtbRangeToValue = new RadNumericTextBox();
		private CompareValidator compareValidator;
		private RequiredFieldValidator reqValidatorFromValue;
		private RequiredFieldValidator reqValidatorToValue;

		[Browsable(false)]
		private NumericRangeValue _rangeValue;
		public NumericRangeValue RangeValue
		{
			get
			{
				if (_rangeValue == null)
					_rangeValue = new NumericRangeValue();
				_rangeValue.FromValue = RangeFromValue;
				_rangeValue.ToValue = RangeToValue;
				return _rangeValue;
			}
			set
			{
				_rangeValue = value;
				RangeFromValue = value.FromValue;
				RangeToValue = value.ToValue;
			}
		}

		[Browsable(true)]
		public double? RangeFromValue
		{
			get
			{
				return rtbRangeFromValue.Value;
			}
			set 
			{
				rtbRangeFromValue.Value = value;
			}
		}

		[Browsable(true)]
		public double? RangeToValue
		{
			get
			{
				return rtbRangeToValue.Value;
			}
			set 
			{
				rtbRangeToValue.Value = value;
			}

		}

		[Browsable(true)]
		public double MinFromValue
		{
			get
			{
				return rtbRangeFromValue.MinValue;
			}
			set
			{
				rtbRangeFromValue.MinValue = value;
			}
		}

		[Browsable(true)]
		public double MaxFromValue
		{
			get
			{
				return rtbRangeFromValue.MaxValue;
			}
			set
			{
				rtbRangeFromValue.MaxValue = value;
			}
		}

		[Browsable(true)]
		public double MinToValue
		{
			get
			{
				return rtbRangeToValue.MinValue;
			}
			set
			{
				rtbRangeToValue.MinValue = value;
			}
		}

		[Browsable(true)]
		public double MaxToValue
		{
			get
			{
				return rtbRangeToValue.MaxValue;
			}
			set
			{
				rtbRangeToValue.MaxValue = value;
			}
		}

		[Browsable(false)]
		public CultureInfo Culture
		{
			get
			{
				if (ViewState[CultureViewStateKey] == null)
					return new CultureInfo("en-US");
				return (CultureInfo)ViewState[CultureViewStateKey];
			}
			set { ViewState[CultureViewStateKey] = value; }
		}

		[Browsable(true)]
		public bool ReadOnly
		{
			get
			{
				if (ViewState[ReadOnlyViewStateKey] == null)
					return false;
				return (bool)ViewState[ReadOnlyViewStateKey];
			}
			set { ViewState[ReadOnlyViewStateKey] = value; }
		}

		[Browsable(true)]
		public int DecimalDigits
		{
			get
			{
				if (ViewState[DecimalDigitsViewStateKey] == null)
					return 0;
				return (int)ViewState[DecimalDigitsViewStateKey];
			}
			set { ViewState[DecimalDigitsViewStateKey] = value; }
		}

		[Browsable(true)]
		public bool IsRequired
		{
			get
			{
				if (ViewState[IsRequiredViewStateKey] == null)
					return false;
				return (bool)ViewState[IsRequiredViewStateKey];
			}
			set
			{
				ViewState[IsRequiredViewStateKey] = value;
			}
		}
		#endregion

		#region Override Methods
		protected override void CreateChildControls()
		{
			this.Controls.Clear();
			CreateControlsForDesign();
		}
		
		protected override void OnPreRender(EventArgs e)
		{			
			base.OnPreRender(e);
			reqValidatorFromValue.Visible = reqValidatorToValue.Visible = IsRequired;
		}

		public override short TabIndex
		{
			get { return rtbRangeFromValue.TabIndex; }
			set
			{
				rtbRangeFromValue.TabIndex = value;
				rtbRangeToValue.TabIndex = value;
			}
		}
		#endregion

		#region Private Methods
		private Literal NewLiteral(string text)
		{
			Literal lb = new Literal();
			lb.Text = text;
			return lb;
		}

		private void CreateControlsForDesign()
		{
			HtmlTable table = new HtmlTable();
			if (!Width.IsEmpty)
				table.Width = Width.Value.ToString();
			table.Border = 0;
			table.CellPadding = 0;
			table.CellSpacing = 0;

			HtmlTableRow row = new HtmlTableRow();

			// Add RangeFromValue NumericTextBox
			HtmlTableCell colRangeFromValue = new HtmlTableCell();
			colRangeFromValue.Width = "40%";
			CreateRadNumericTextBox(rtbRangeFromValue, "rtbRangeFromValue", RangeFromValue, MinFromValue, MaxFromValue);
			colRangeFromValue.Controls.Add(rtbRangeFromValue);

			// Add RequiredFieldValidator to rtbRangeFromValue
			reqValidatorFromValue = CreateRequiredFieldValidator("reqValidatorFromValue", "rtbRangeFromValue");
			colRangeFromValue.Controls.Add(reqValidatorFromValue);

			row.Controls.Add(colRangeFromValue);

			// Add separator
			HtmlTableCell colSeparator = new HtmlTableCell();
			colSeparator.Width = "10%";
			//colSeparator.Controls.Add(NewLiteral(String.Format("<strong>&nbsp;{0}&nbsp;&nbsp;</string>", CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_To").ToLower())));
			colSeparator.Controls.Add(NewLiteral(CWXResourceManager.GetString(ResourceCategory.Glossary, "WebCommon_To").ToLower()));
			row.Controls.Add(colSeparator);

			// Add RangeToValue NumericTextBox
			HtmlTableCell colRangeToValue = new HtmlTableCell();
			colRangeToValue.Width = "40%";
			CreateRadNumericTextBox(rtbRangeToValue, "rtbRangeToValue", RangeToValue, MinToValue, MaxToValue);
			colRangeToValue.Controls.Add(rtbRangeToValue);

			// Add RequiredFieldValidator to rtbRangeToValue
			reqValidatorToValue = CreateRequiredFieldValidator("reqValidatorToValue", "rtbRangeToValue");
			colRangeToValue.Controls.Add(reqValidatorToValue);

			// Add CompareValidator
			compareValidator = CreateCompareValidator("compareValidator", "rtbRangeToValue", "rtbRangeFromValue");
			colRangeToValue.Controls.Add(compareValidator);

			row.Controls.Add(colRangeToValue);

			table.Controls.Add(row);			
			this.Controls.Add(table);
			this.CssClass = "";
		}

		private RadNumericTextBox CreateRadNumericTextBox(RadNumericTextBox rtb, string id, double? value, double minValue, double maxValue)
		{
			rtb.ID = id;
			rtb.CssClass = CssClass;
			rtb.Culture = Culture;
			rtb.ReadOnly = ReadOnly;
			rtb.NumberFormat.DecimalDigits = DecimalDigits;
			rtb.MinValue = minValue;
			rtb.MaxValue = maxValue;
			rtb.Value = value;
			rtb.Width = new Unit(Width.Value * 0.40);	
			return rtb;			
		}

		private RequiredFieldValidator CreateRequiredFieldValidator(string id, string controlToValidate)
		{
			RequiredFieldValidator reqValidator = new RequiredFieldValidator();
			reqValidator.ID = id;
			reqValidator.ControlToValidate = controlToValidate;
			reqValidator.Display = ValidatorDisplay.Dynamic;
			reqValidator.ErrorMessage = CWXResourceManager.GetString(ResourceCategory.Errors, "Val_Common_RequireField");
			reqValidator.ToolTip = reqValidator.ErrorMessage;
			reqValidator.Text = "*";
			reqValidator.SetFocusOnError = true;
			reqValidator.Visible = IsRequired;
			return reqValidator;
		}

		private CompareValidator CreateCompareValidator(string id, string controlToValidate, string controlToCompare)
		{
			CompareValidator compareValidator = new CompareValidator();
			compareValidator.ID = id;
			compareValidator.ControlToCompare = controlToCompare;
			compareValidator.ControlToValidate = controlToValidate;
			compareValidator.Operator = ValidationCompareOperator.GreaterThanEqual;
			compareValidator.Type = ValidationDataType.Double;
			compareValidator.Display = ValidatorDisplay.Dynamic;
			compareValidator.ErrorMessage = CWXResourceManager.GetString(ResourceCategory.Errors, "Val_RangeValues");
			compareValidator.ToolTip = compareValidator.ErrorMessage;
			compareValidator.Text = "*";
			compareValidator.SetFocusOnError = true;
			return compareValidator;
		}
		#endregion
	}


	public class NumericRangeValue
	{
		private double? _fromValue;
		public double? FromValue
		{
			get { return _fromValue; }
			set { _fromValue = value; }
		}

		private double? _toValue;
		public double? ToValue
		{
			get { return _toValue; }
			set { _toValue = value; }
		}

		public NumericRangeValue() : this(0, 0)
		{
		}

		public NumericRangeValue(double? fromValue, double? toValue)
		{
			FromValue = fromValue;
			ToValue = toValue;
		}
	}
}
