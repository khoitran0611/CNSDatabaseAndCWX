using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CWX.Core.UI.WebControls
{
    /// <summary>
    /// Displays a summary of all validation errors inline on a Web page, in a message box, or both.
    /// </summary>
    [ToolboxData("<{0}:CWXValidationSummary runat=\"server\" />")]
    public class CWXValidationSummary : CWX.Core.UI.WebControls.Compatibility.ValidationSummary
    {
        /// <summary>
        /// Allows the caller to place custom text messages inside the ValidationSummary control.
        /// DummyValidator.ValidationGroup = this.ValidationGroup.
        /// </summary>
        /// <param name="message">The message you want to appear in the summary</param>
        public void AddErrorMessage(string message)
        {
            this.Page.Validators.Add(new DummyValidator(message, this.ValidationGroup));
        }

        /// <summary>Allows the caller to place custom text messages inside the ValidationSummary control.</summary>
        /// <param name="message">The message you want to appear in the summary</param>
        /// <param name="validationGroup">User defined validation group</param>
        public void AddErrorMessage(string message, string validationGroup)
        {
            this.Page.Validators.Add(new DummyValidator(message, validationGroup));
        }

        /// <summary>
        /// Allows the caller to place custom text messages inside the validationsummary control
        /// DummyValidator.ValidationGroup = this.ValidationGroup.
        /// </summary>
        /// <param name="messages">A list of messages you want to appear in the summary</param>
        public void AddErrorMessage(IEnumerable<string> messages)
        {
            new List<string>(messages).ForEach(delegate(string message) { this.Page.Validators.Add(new DummyValidator(message, this.ValidationGroup)); });
        }

        /// <summary>Allows the caller to place custom text messages inside the validationsummary control</summary>
        /// <param name="messages">A list of messages you want to appear in the summary</param>
        /// <param name="validationGroup">User defined validation group</param>
        public void AddErrorMessage(IEnumerable<string> messages, string validationGroup)
        {
            new List<string>(messages).ForEach(delegate(string message) { this.Page.Validators.Add(new DummyValidator(message, validationGroup)); });
        }

        /// <summary>
        /// Only exists for MyValidationSummary. Always invalid. Inherit CustomValidator to 
        /// work with ValidationGroup
        /// </summary>
        private class DummyValidator : CustomValidator
        {
            /// <summary>Ctor.</summary>
            /// <param name="errorMessage">error message to display with ValidationSummary</param>
            /// <param name="validationGroup">always part of the ValidationSummary's ValidationGroup</param>
            public DummyValidator(string errorMessage, string validationGroup)
            {
                this.ErrorMessage = errorMessage;
                this.ValidationGroup = validationGroup;
                this.IsValid = string.IsNullOrEmpty(this.ErrorMessage);
            }

            /// <summary>Remove this validator when the page is unloaded.</summary>
            /// <param name="e">Not Used</param>
            protected override void OnUnload(EventArgs e)
            {
                if (this.Page != null)
                {
                    this.Page.Validators.Remove(this);
                }
                base.OnUnload(e);
            }
        }
    }
}
