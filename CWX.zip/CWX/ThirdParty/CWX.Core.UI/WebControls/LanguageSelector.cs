using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;

namespace CWX.Core.UI.WebControls
{
    [ToolboxData("<{0}:LanguageSelector runat=server></{0}:LanguageSelector>")]
    [Obsolete("This control was not completed yet.", true)]
    internal class LanguageSelector: WebControl
    {
        private Collection<LinkButton> _languageButtons = new Collection<LinkButton>();

        //public event LanguageChangedEventHandler LanguageChanged;

        [Category("Data")]
        [Browsable(true)]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        public Collection<LanguageItem> LanguageItems
        {
            get 
            {

                if (ViewState["__LANGUAGEITEMS"] == null)
                    ViewState["__LANGUAGEITEMS"] = new Collection<LanguageItem>();
                return ViewState["__LANGUAGEITEMS"] as Collection<LanguageItem>;
            }
            set 
            {
                ViewState["__LANGUAGEITEMS"] = value;
            }
        }

        protected override void CreateChildControls()
        {
            if (!this.ChildControlsCreated)
            {
                _languageButtons = new Collection<LinkButton>();
                if (!DesignMode)
                {
                    for (int index = 0; index < LanguageItems.Count; index++)
                    {
                        LinkButton langButton = new LinkButton();
                        langButton.ID = "languagelink_" + index.ToString(CultureInfo.InvariantCulture);
                        langButton.Text = LanguageItems[index].LanguageText;
                        this.Controls.Add(langButton);
                    }
                }
                else
                {
                    LinkButton langButton = new LinkButton();
                    langButton.ID = "languagelink";
                    langButton.Text = "LanguageSelector";
                    this.Controls.Add(langButton);
                }
            }
            base.CreateChildControls();
        }

        //private ArrayList _languageList;
        //private ArrayList _controls;

        //public string SelectedLanguage
        //{
        //    get 
        //    {
        //        if (ViewState["LanguageSelector.SelectedLanguage"] == null)
        //            return String.Empty;
        //        return ViewState["LanguageSelector.SelectedLanguage"] as string;
        //    }
        //    set 
        //    {
        //        ViewState["LanguageSelector.SelectedLanguage"] = value;                
        //    }
        //}

        //#region Creating for Design
        //private Literal NewLiteral(string text)
        //{
        //    Literal lb = new Literal();
        //    lb.Text = text;
        //    return lb;
        //}

        //private Image NewImage(string imageUrl)
        //{
        //    Image img = new Image();
        //    img.ImageUrl = imageUrl;
        //    img.BorderWidth = 0;
        //    img.Height = 10;
        //    img.Width = 15;
        //    return img;
        //}

        //protected override void CreateChildControls()
        //{
        //    this.Controls.Clear();
        //    CreateLanguageList();
        //    CreateControlsForDesign();
        //    for (int i = 0; i < _controls.Count; i++)
        //        this.Controls.Add((Control)_controls[i]);
        //}

        //private void CreateLanguageList()
        //{
        //    _languageList = new ArrayList();
        //    _languageList.Add(new LanguageItem("en-US", "English", "App_Themes/Default/Images/logo.jpg", false));
        //    _languageList.Add(new LanguageItem("vi-VN", "Vietnamese", "App_Themes/Default/Images/logo.jpg", false));
        //    foreach (LanguageItem lang in _languageList)
        //    {
        //        if (lang.Culture == SelectedLanguage)
        //        {
        //            lang.IsSelected = true;
        //            break;
        //        }
        //    }
        //}

        //private void CreateControlsForDesign()
        //{
        //    _controls = new ArrayList();

        //    _controls.Add(NewLiteral("<div id='menulanguage'><ul id='navmenu-h'><li class='SelectedLang'>"));

        //    LinkButton btnSelectedLanguage = new LinkButton();
        //    foreach (LanguageItem lang in _languageList)
        //    {
        //        if (lang.IsSelected)
        //        {
        //            btnSelectedLanguage.ID = "btnSelectedLanguage";
        //            btnSelectedLanguage.CausesValidation = false;                                        
        //            btnSelectedLanguage.Controls.Add(NewImage(lang.ImageUrl));
        //            btnSelectedLanguage.Controls.Add(NewLiteral(lang.Name));
        //            break;
        //        }
        //    }
        //    _controls.Add(btnSelectedLanguage);

        //    _controls.Add(NewLiteral("<ul>"));

        //    for (int i=0; i<_languageList.Count;i++)
        //    {
        //        LanguageItem lang = _languageList[i] as LanguageItem;
        //        if (!lang.IsSelected)
        //        {
        //            _controls.Add(NewLiteral("<li>"));
        //            LinkButton btnOtherLanguage = new LinkButton();
        //            btnOtherLanguage.ID = lang.Culture;                    
        //            btnOtherLanguage.CausesValidation = false;
        //            btnOtherLanguage.Click += new EventHandler(btnOtherLanguage_Click);
        //            btnOtherLanguage.Controls.Add(NewImage(lang.ImageUrl));
        //            btnOtherLanguage.Controls.Add(NewLiteral(lang.Name));
        //            _controls.Add(btnOtherLanguage);
        //            _controls.Add(NewLiteral("</li>"));
        //        }
        //    }

        //    _controls.Add(NewLiteral("</li></ul></div>"));            

        //}

        //protected void btnOtherLanguage_Click(object sender, EventArgs e)
        //{
        //    LinkButton btnOtherLanguage = sender as LinkButton;
        //    CreateChildControls();
        //    OnLanguageChanged(btnOtherLanguage.ID);
        //}

        //private void OnLanguageChanged(string culture)
        //{
        //    this.LanguageChanged(culture);  
        //}
        
        //#endregion
    }

    [Serializable]
    public class LanguageItem
    {
        #region "Class Language Properties"
        private string _culture;
        public string Culture
        {
            get { return _culture; }
            set { _culture = value; }
        }

        private string _name;
        public string LanguageText
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _imageUrl;
        public string ImageUrl
        {
            get { return _imageUrl; }
            set { _imageUrl = value; }
        }

        private bool _isSelected;

        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; }
        }

        #endregion

        public LanguageItem()
        { 
        }
        public LanguageItem(string culture, string name, string imageUrl, bool isSelected)
        {
            _culture = culture;
            _name = name;
            _imageUrl = imageUrl;
            _isSelected = isSelected;
        }
    }
}
