using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Services;
using CWX.Core.Common.Security;
using System.Threading;
using CWX.Core.Common.Exceptions;

namespace CWX.Core.UI
{

    /// <summary>
    /// CWX Webservice base class.
    /// </summary>
    /// <history>
    ///     2008/07/15  [Binh Truong]   Init version.
    /// </history>
    public class CWXWebService : WebService
    {

        public CWXWebService()
        {
            Authorize();
        }
        
        #region Virtual Methods
        /// <summary>
        /// Authorize user. If user don't have permission on this page, throw a CWXAuthorizationException
        /// </summary>
        protected virtual void Authorize()
        {
            if (!CWXAuthorizationManager.Authorize(Thread.CurrentPrincipal, CWXPermissionConstant.ACCESS_CWX_SYSTEM))
            {
                throw new CWXAuthorizationException(CWXPermissionConstant.ACCESS_CWX_SYSTEM);
            }
        }
        #endregion

        #region Protected Methods

        /// <summary>
        /// Check permission of current user.
        /// </summary>
        /// <param name="throwException">Indicates whether throw exception user does not have permission or not.</param>
        /// <history>
        ///     2008/09/10  [Binh Truong]   Init version.
        /// </history>
        protected bool CheckPermission(CWXPermissionConstant permission, bool throwException)
        {
            bool hasPermission = CWXAuthorizationManager.Authorize(Thread.CurrentPrincipal, permission);
            if (throwException && !hasPermission)
                throw new CWXAuthorizationException(permission);
            
            return hasPermission;
        }

        #endregion

    }
}
