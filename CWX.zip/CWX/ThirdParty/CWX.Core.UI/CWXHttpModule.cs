using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using CWX.Core.Common.Security;
using System.Threading;
using System.Globalization;
using CWX.Core.Common.Exceptions;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

namespace CWX.Core.UI
{
    public class CWXHttpModule : IHttpModule
    {
        #region IHttpModule Members

        public void Dispose() {}

        public void Init(HttpApplication app)
        {
            
        }

        

        #endregion

        

    }
}
