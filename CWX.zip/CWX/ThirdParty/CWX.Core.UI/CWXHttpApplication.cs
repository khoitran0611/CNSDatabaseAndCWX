using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using CWX.Core.Common.Exceptions;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Caching;

using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

using CWX.Core.Common.Security;
using CWX.Core.Common.Resource;
using CWX.Core.Common.Configuration;


namespace CWX.Core.UI
{
    /// <summary>
    /// Defines the methods, properties, and events that are common to all application
    /// objects within an ASP.NET application.
    /// </summary>
    /// <history>
    ///     2008/12/16  [Alvin Marable] Add initialization and termination of workflow service runtime.
    /// </history>
    public class CWXHttpApplication : HttpApplication
    {

        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup

            //initialize workflow service instance
            if (CWXConfigurationManager.AppSettings.IsWorkflowServiceAvailable)
            {
                CWX.WorkflowEngine.CWXWorkflowService.InitializeWorkflowRuntime();
            }
        }

        void Application_AuthenticateRequest(Object sender, EventArgs e)
        {
            AuthenticateRequestWithCaching();
        }

        void Session_Start(object sender, EventArgs e)
        {
            string cookieHeader = Request.Headers["Cookie"];
            if (cookieHeader != null)
            {
                if ((cookieHeader.IndexOf("ASP.NET_SessionId") >= 0 || cookieHeader.IndexOf(".ASPXFORMSAUTH") >= 0)
                    && HttpContext.Current.Request.Path.IndexOf(FormsAuthentication.LoginUrl) < 0)

                    RedirectToLoginPage();
            }
        }

        void Session_End(object sender, EventArgs e)
        {
            // Code that runs when a session ends. 
            // Note: The Session_End event is raised only when the sessionstate mode
            // is set to InProc in the Web.config file. If session mode is set to StateServer 
            // or SQLServer, the event is not raised.

        }

        void Application_End(object sender, EventArgs e)
        {
            //  Code that runs on application shutdown

            // end workflow service runtime
            if (CWXConfigurationManager.AppSettings.IsWorkflowServiceAvailable)
            {
                CWX.WorkflowEngine.CWXWorkflowService.EndWorkflowRuntime();
            }

        }

        #region Error Handler

        void Application_Error(object sender, EventArgs e)
        {
            bool isUnexpectedException = true;
            HttpContext context = ((HttpApplication)sender).Context;

            Exception ex = context.Server.GetLastError();
            if (ex.InnerException != null)
                ex = ex.InnerException;

            CWXException cwxEx = ex as CWXException;

            if (cwxEx == null)
            {
                if (ex is HttpException)
                {
                    HttpException hex = (HttpException)ex;
                    if (hex.GetHttpCode() == 404) // Requested page not found
                    {
                        isUnexpectedException = false;
                        context.Server.ClearError();
                        cwxEx = new CWXException(
                            CWXResourceManager.GetString(ResourceCategory.Errors, "WebCommon_PageNotFound"));
                        cwxEx.SetTrace(hex);
                        context.AddError(cwxEx);
                    }
                }
                else if (ex is SqlException)
                {
                    SqlException sqlEx = (SqlException)ex;
                    if (sqlEx.Number == 53 || sqlEx.Number == 1231)
                    {
                        isUnexpectedException = false;
                        context.Server.ClearError();
                        cwxEx = new CWXException(
                            CWXResourceManager.GetString(ResourceCategory.Errors, "WebCommon_CannotConnectDB"));
                        cwxEx.SetTrace(sqlEx);
                        context.AddError(cwxEx);
                    }
                }
            }
            else
            {
                isUnexpectedException = false;
            }

            if (isUnexpectedException)
                HandleUnexpectedException(ex);
            else
                HandleExpectedException(cwxEx);
        }

        /// <summary>
        /// Handle all unexpected exception.
        /// </summary>
        private void HandleUnexpectedException(Exception ex)
        {
            Exception e;
            ExceptionPolicy.HandleException(ex, "Common Exception", out e);
            TransferToErrorPage(e.Message);
        }

        /// <summary>
        /// Handle all expected exception.
        /// </summary>
        private void HandleExpectedException(CWXException cwxEx)
        {
            if (cwxEx is CWXAuthorizationException)
            {
                CWXAuthorizationException cwxAuthorizationException = (CWXAuthorizationException)cwxEx;
                switch (cwxAuthorizationException.ViolatedPermission)
                {
                    case CWXPermissionConstant.ACCESS_CWX_SYSTEM:
                        RedirectToLoginPage();
                        break;
                    default:
                        TransferToErrorPage();
                        break;

                }
            }
            else if (cwxEx is CWXDataNotFoundException)
            {
                TransferToErrorPage();
            }
            else
            {
                HandleUnexpectedException(cwxEx);
            }
        }



        #endregion

        #region Private methods

        /// <summary>
        /// Redirects the browser to the login URL.
        /// </summary>
        public void RedirectToLoginPage()
        {
            FormsAuthentication.SignOut();
            FormsAuthentication.RedirectToLoginPage();
            Response.End();
        }

        /// <summary>
        /// Transfer to error page.
        /// </summary>
        private void TransferToErrorPage(string handlingInstanceID)
        {
            bool isShowFriendlyError = true;
            bool.TryParse(ConfigurationManager.AppSettings.Get("ShowFriendlyError"), out isShowFriendlyError);

            if (isShowFriendlyError)
                Server.Transfer("~/error.aspx?ErrorCode=" + handlingInstanceID);
        }

        private void TransferToErrorPage()
        {
            bool isShowFriendlyError = true;
            bool.TryParse(ConfigurationManager.AppSettings.Get("ShowFriendlyError"), out isShowFriendlyError);

            if (isShowFriendlyError)
                Server.Transfer("~/error.aspx");
        }

        /// <summary>
        /// Build <see cref="CWXPrincipal"/> from HttpContext.Cache 
        /// and store in <see cref="HttpContext.Current.User"/>.
        /// </summary>
        /// <history>
        ///     2008/07/01  [Binh Truong]   Init version.
        ///     2008/07/03  [Binh Truong]   Save CWXPrincipal object into application cache instead of 
        ///                                 save userInformation string then create CWXPrincipal from it.
        ///     2008/07/29  [Thao Nguyen]   Add DBConnectionName to CWXIdentity.
        /// </history>
        private void AuthenticateRequestWithCaching()
        {
            if (HttpContext.Current.User != null && HttpContext.Current.User.Identity.IsAuthenticated)
            {
                string cacheKey = string.Concat("UserInfo_", HttpContext.Current.User.Identity.Name);

                CWXPrincipal cwxPrincipal = System.Web.HttpContext.Current.Cache[cacheKey] as CWXPrincipal;

                if (cwxPrincipal == null)
                {
                    CWXUser user = CWXMembershipManager.GetUser(HttpContext.Current.User.Identity.Name, true) as CWXUser;
                    if (user == null) // user not found
                        RedirectToLoginPage();

                    user.Role = CWXMembershipManager.GetUserRole(user.UserID);
                    CWXPermissionConstant[] permissionConstants = CWXPermissionManager.GetUserPermissions(user.UserID);
                    StringBuilder sbUserInformation = new StringBuilder();
                    sbUserInformation.AppendFormat("{0}|", user.UserID);
                    sbUserInformation.AppendFormat("{0}|", user.FullName);
                    sbUserInformation.AppendFormat("{0}|", user.Role == null ? string.Empty : user.Role.RoleName);
                    if (permissionConstants.Length > 0)
                    {
                        for (int i = 0; i < permissionConstants.Length - 1; i++)
                            sbUserInformation.AppendFormat("{0},", permissionConstants[i].GetHashCode());
                        sbUserInformation.AppendFormat("{0}", permissionConstants[permissionConstants.Length - 1].GetHashCode());
                    }
                    else // permission not found
                    {
                        throw new CWXAuthorizationException(CWXPermissionConstant.ACCESS_CWX_SYSTEM);
                    }

                    int cacheMin;
                    int defaultCacheMin = 10;
                    int.TryParse(ConfigurationManager.AppSettings["UserPermissionSlidingExpiration"], out cacheMin);
                    cacheMin = cacheMin == 0 ? defaultCacheMin : cacheMin;
                    cwxPrincipal = BuildCWXPrincipal(sbUserInformation.ToString());
                    HttpContext.Current.Cache.Add(cacheKey, cwxPrincipal, null, DateTime.MaxValue, TimeSpan.FromMinutes(cacheMin), CacheItemPriority.Normal, null);
                }
                //Update DbConnectionName of CWXIdentity if not
                UpdateDbName(cwxPrincipal);

                HttpContext.Current.User = cwxPrincipal;
            }
        }

        /// <summary>
        /// Build <see cref="CWXPrincipal"/> from FormsAuthenticationTicket object 
        /// and store in <see cref="HttpContext.Current.User"/>.
        /// </summary>
        /// <history>
        ///     08/07/01    [Binh Truong]   Init version.
        /// </history>
        private void AuthenticateRequestWithCookie()
        {
            if (HttpContext.Current.User != null)
            {
                if (HttpContext.Current.User.Identity.IsAuthenticated && HttpContext.Current.User.Identity.AuthenticationType.Equals("Forms"))
                {
                    FormsAuthenticationTicket ticket = ((FormsIdentity)HttpContext.Current.User.Identity).Ticket;
                    string userInformation = ticket.UserData; // Get data from cookie

                    // Create the user cookie if it doesn't exist yet for this session.
                    if (string.IsNullOrEmpty(userInformation))
                    {
                        CWXUser user = CWXMembershipManager.GetUser(HttpContext.Current.User.Identity.Name, true) as CWXUser;
                        user.Role = CWXMembershipManager.GetUserRole(user.UserID);
                        CWXPermissionConstant[] permissionConstants = CWXPermissionManager.GetUserPermissions(user.UserID);
                        StringBuilder sbUserInformation = new StringBuilder();
                        sbUserInformation.AppendFormat("{0}|", user.UserID);
                        sbUserInformation.AppendFormat("{0}|", user.FullName);
                        sbUserInformation.AppendFormat("{0}|", user.Role == null ? string.Empty : user.Role.RoleName);
                        if (permissionConstants.Length > 0)
                        {
                            for (int i = 0; i < permissionConstants.Length - 1; i++)
                                sbUserInformation.AppendFormat("{0},", permissionConstants[i].GetHashCode());
                            sbUserInformation.AppendFormat("{0}", permissionConstants[permissionConstants.Length - 1].GetHashCode());
                        }
                        else // permission not found
                        {
                            throw new CWXAuthorizationException(CWXPermissionConstant.ACCESS_CWX_SYSTEM);
                        }
                        userInformation = sbUserInformation.ToString();

                        // Create a cookie authentication ticket.
                        ticket = new FormsAuthenticationTicket(
                            1,                              // version
                            User.Identity.Name,             // user name
                            DateTime.Now,                   // issue time
                            DateTime.Now.AddMinutes(30),    // expires every 30 mins
                            true,                           // don't persist cookie
                            userInformation,                // user info
                            FormsAuthentication.FormsCookiePath
                            );

                        // Encrypt the ticket.
                        string encTicket = FormsAuthentication.Encrypt(ticket);

                        // Create the cookie.
                        Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName, encTicket));
                    }

                    HttpContext.Current.User = BuildCWXPrincipal(userInformation);
                }
            }
        }

        /// <summary>
        /// Build <see cref="CWXPrincipal"/> from userdata string.
        /// </summary>
        /// <param name="userInformation">
        /// UserData from <see cref="FormsAuthenticationTicket"/> object.
        /// info[0] UserID, info[1] Full name, info[2] Role name, info[3] permission ID in string
        /// </param>
        /// <returns>CWXPrincipal</returns>
        private CWXPrincipal BuildCWXPrincipal(string userInformation)
        {

            string[] info = userInformation.Split(new char[] { '|' });
            if (info.Length != 4) // Validate userdata
                RedirectToLoginPage();

            int userID = 0;
            int.TryParse(info[0], out userID);
            string fullName = info[1];
            string roleName = info[2];
            string[] roleIDs = info[3].Split(new char[] { ',' });

            if (userID == 0 || string.IsNullOrEmpty(fullName) || roleIDs.Length == 0) // Validate userdata
                RedirectToLoginPage();

            CWXPermissionConstant[] userPermissions = new CWXPermissionConstant[roleIDs.Length];
            for (int i = 0; i < roleIDs.Length; i++)
                userPermissions[i] = (CWXPermissionConstant)int.Parse(roleIDs[i]);

            CWXIdentity cwxIdentity = new CWXIdentity(userID, HttpContext.Current.User.Identity.Name, fullName);

            return new CWXPrincipal(cwxIdentity, new string[] { roleName }, userPermissions);
        }

        /// <summary>
        /// Update DB name.
        /// </summary>
        /// <history>
        ///     2008/07/29  [Thao Nguyen]   Init version.
        ///     2008/08/06  [LongNguyen]    Comment the remove cache code.
        /// </history>
        private void UpdateDbName(CWXPrincipal cwxPrincipal)
        {
            string cacheKeyDbName = string.Concat("DbConnectionName_", HttpContext.Current.User.Identity.Name.ToLower());
            object cacheValue = System.Web.HttpContext.Current.Cache[cacheKeyDbName];
            if (cacheValue != null)
            {
                CWXIdentity cwxIdentity = cwxPrincipal.Identity as CWXIdentity;
                cwxIdentity.DbConnectionName = cacheValue.ToString();

                //System.Web.HttpContext.Current.Cache.Remove(cacheKeyDbName);
            }
        }

        #endregion
    }
}
