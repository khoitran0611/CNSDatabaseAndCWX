using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;

using CWX.Core.UI;
using CWX.Core.Common.Configuration;

namespace CWX.Core.UI
{
    /// <summary>
    /// Summary description for CWXCustomerPage
    /// </summary>
    /// <history>
    ///     2008/11/11  [Binh Truong]   Init version.
    /// </history>
    public class CWXCustomerPage : CWXPage
    {

        private const string CUSTOMER_CUSTOM_MODULE_URL_PATTERN = "^(?<g1>/customer/)(?<g2>custom/)(?<g3>[a-zA-Z1-9]+/)(?<g4>.*)$";
        private const string CUSTOMER_CUSTOM_MODULE_URL_PATTERN_USER = "^(?<g1>/customer/custom/)(?<g2>{0}/)(?<g3>.*)$";
        private const string CUSTOMER_DEFAULT_MODULE_URL_PATTERN = "^(?<g1>/customer/)(?!custom/)(?<g3>.*)$"; // "^(?<g1>/customer/)(?<g2>[a-zA-Z1-9]+)(?<g3>/.*)$";


        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            SwitchCustomerCustomHandle();
        }

        /// <summary>
        /// Switch approciate customer module for specific user.
        /// </summary>
        /// <history>
        ///     2008/11/12  [Binh Truong]   Init version.
        ///     2008/12/29  [Binh Truong]   Fix request url missing query string.
        /// </history>
        private void SwitchCustomerCustomHandle()
        {
            string realPath = Request.RawUrl.Remove(0, Request.ApplicationPath.Length);

            string userCmsID = GetUserCmsID();

            if (Regex.IsMatch(realPath, CUSTOMER_DEFAULT_MODULE_URL_PATTERN, RegexOptions.IgnoreCase))
            {
                // User is requesting default CMS
                if (!userCmsID.Length.Equals(0))
                {
                    // User is set to use custom CMS
                    string newPath = Regex.Replace(realPath,
                        CUSTOMER_DEFAULT_MODULE_URL_PATTERN,
                        string.Concat("${g1}", "custom/", userCmsID, "/${g3}"),
                        RegexOptions.IgnoreCase
                         );
                    Response.Redirect(string.Concat(Request.ApplicationPath, newPath));
                }
            }
            else
            {
                // User is requesting CustomCMS
                if (userCmsID.Length.Equals(0))
                {
                    // User is set to use default CMS
                    string replacePattern = "${g1}${g4}";
                    string newPath = Regex.Replace(realPath, CUSTOMER_CUSTOM_MODULE_URL_PATTERN, replacePattern, RegexOptions.IgnoreCase);
                    Response.Redirect(string.Concat(Request.ApplicationPath, newPath));
                }
                else if (!Regex.IsMatch(realPath, string.Format(CUSTOMER_CUSTOM_MODULE_URL_PATTERN_USER, userCmsID), RegexOptions.IgnoreCase))
                {
                    // User is requesting wrong custom CMS ID 
                    string replacePattern = string.Concat("${g1}${g2}", userCmsID, "/${g4}");
                    string newPath = Regex.Replace(realPath, CUSTOMER_CUSTOM_MODULE_URL_PATTERN, replacePattern, RegexOptions.IgnoreCase);
                    Response.Redirect(string.Concat(Request.ApplicationPath, newPath));
                }
            }
        }

        /// <summary>
        /// Get user CMS ID and validate if ID is exists or enable in web.config.
        /// </summary>
        /// <history>
        ///     2008/11/18  [Binh Truong]   Init version.
        /// </history>
        private string GetUserCmsID()
        {
            string userCmsID = HttpContext.Current.Profile.GetPropertyValue("CmsID").ToString();
            if (string.IsNullOrEmpty(userCmsID))
                return string.Empty;
            
            bool isUserCmsIDDefined = false;
            foreach (CustomCMSElement customCMS in CWXConfigurationManager.CWXConfiguarationInstance.CustomCMSs)
            {
                if (customCMS.Name.Equals(userCmsID, StringComparison.InvariantCultureIgnoreCase) && customCMS.Enabled)
                    isUserCmsIDDefined = true;
            }
            if (!isUserCmsIDDefined)
                userCmsID = string.Empty;

            return userCmsID;
        }

    }
}