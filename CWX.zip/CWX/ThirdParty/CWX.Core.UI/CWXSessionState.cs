using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Globalization;

using CWX.Core.Common.Security;
using CWX.Core.Common;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace CWX.Core.UI
{
    /// <summary>
    /// Summary description for CWXContext
    /// </summary>
    public class CWXSessionState
    {
        private const string UserSessionKey = "__CWXCurrentUser";
        private const string CurrentDebtorXmlDocumentKey = "__CWXCurrentDebtorXMLDocument";
        private const string LoginDateTimeKey = "__LoginDateTime";
        private const string CurrentReportScheduleParamsKey = "__CWXCurrentReportScheduleParamsKey";
        private const string CurrentManualNoteListKey = "__CWXCurrentManualNoteListKey";
        private const string DialerStatusKey = "__DialerStatus";
        private const string ProcessingDialerQueueKey = "__ProcessingDialerQueue";
        private const string NotePriorityListKey = "__CWXNotePriorityListKey";
        private const string InterestTypeInfoKey = "_CWXInterestTypeInfo";
        private const string InterestRateInfoKey = "_CWXInterestRateInfo";
		private const string LegalStepTransactionListKey = "__LegalStepTransactionListKey";
		private const string ClientDataLoadKey = "__ClientDataLoadKey";
		private const string EmployeeQueueItemUsageKey = "_EmployeeQueueItemUsageKey";
		private const string EmployeeQueueTabUsageKey = "_EmployeeQueueTabUsageKey";
		private const string EmployeeAvailableQueueKey = "_EmployeeAvailableQueueKey";
		private const string EmployeeAvailableQueueItemKey = "_EmployeeAvailableQueueItemKey";
		
        public static string SessionID
        {
            get
            {
                if (SessionManager.CurrentSession == null)
                    return string.Empty;
                return SessionManager.CurrentSession.SessionID;
            }
        }

        /// <summary>
        /// Gets or sets current user.
        /// </summary>
        public static CWXUser CurrentUser
        {
            get
            {
                return SessionManager.GetObject(UserSessionKey) as CWXUser;
            }
            set
            {
                SessionManager.SetObject(UserSessionKey, value);
            }
        }

        public static XmlDocument CurrentDebtorXmlDocument
        {
            get
            {
                return SessionManager.GetObject(CurrentDebtorXmlDocumentKey) as XmlDocument;
            }
            set
            {
                SessionManager.SetObject(CurrentDebtorXmlDocumentKey, value);
            }
        }

        public static object CurrentReportScheduleParams
        {
            get
            {
                return SessionManager.GetObject(CurrentReportScheduleParamsKey);
            }
            set
            {
                SessionManager.SetObject(CurrentReportScheduleParamsKey, value);
            }
        }

        public static object CurrentManualNoteList
        {
            get
            {
                return SessionManager.GetObject(CurrentManualNoteListKey);
            }
            set
            {
                SessionManager.SetObject(CurrentManualNoteListKey, value);
            }
        }

        public static object NotePriorityList
        {
            get
            {
                return SessionManager.GetObject(NotePriorityListKey);
            }
            set
            {
                SessionManager.SetObject(NotePriorityListKey, value);
            }
        }

        public static object InterestTypeInfo
        {
            get
            {
                return SessionManager.GetObject(InterestTypeInfoKey);
            }
            set
            {
                SessionManager.SetObject(InterestTypeInfoKey, value);
            }
        }

        public static object IntestRateInfo
        {
            get
            {
                return SessionManager.GetObject(InterestRateInfoKey);
            }
            set
            {
                SessionManager.SetObject(InterestRateInfoKey, value);
            }
        }

		public static object LegalStepTransactionList
		{
			get
			{
				return SessionManager.GetObject(LegalStepTransactionListKey);
			}
			set
			{
				SessionManager.SetObject(LegalStepTransactionListKey, value);
			}
		}

		public static object ClientDataLoadImportDataInfo
		{
			get
			{
				return SessionManager.GetObject(ClientDataLoadKey);
			}
			set
			{
				SessionManager.SetObject(ClientDataLoadKey, value);
			}
		}
        
        public static bool IsLoggedIn
        {
            get
            {
                return CurrentUser != null;
            }
        }

        public static DateTime LoginDateTime
        {
            get
            {
                if (SessionManager.GetObject(LoginDateTimeKey) != null)
                    return (DateTime)SessionManager.GetObject(LoginDateTimeKey);
                return DateTime.MinValue;
            }
            set { SessionManager.SetObject(LoginDateTimeKey, value); }
        }

		public static object EmployeeQueueItemUsage
		{
			get
			{ 
				if(SessionManager.GetObject(EmployeeQueueItemUsageKey) != null)
					return SessionManager.GetObject(EmployeeQueueItemUsageKey) as Dictionary<int, Dictionary<int, string>>;
				return null;
			}
			set
			{
				SessionManager.SetObject(EmployeeQueueItemUsageKey, value);
			}
		}

		public static void RemoveEmployeeQueueItemUsage()
		{
			SessionManager.RemoveObject(EmployeeQueueItemUsageKey);
		}

		public static object EmployeeQueueTabUsage
		{
			get
			{
				if (SessionManager.GetObject(EmployeeQueueTabUsageKey) != null)
					return SessionManager.GetObject(EmployeeQueueTabUsageKey) as Collection<int>;
				return null;
			}
			set
			{
				SessionManager.SetObject(EmployeeQueueTabUsageKey, value);
			}
		}

		public static void RemoveEmployeeQueueTabUsage()
		{
			SessionManager.RemoveObject(EmployeeQueueTabUsageKey);
		}

		public static object EmployeeAvailableQueue		
		{
			get
			{
				if (SessionManager.GetObject(EmployeeAvailableQueueKey) != null)
					return SessionManager.GetObject(EmployeeAvailableQueueKey) as Collection<int>;
				return null;
			}
			set
			{
				SessionManager.SetObject(EmployeeAvailableQueueKey,value);
			}
		}

		public static void RemoveAvailableEmployeeQueue()
		{
			SessionManager.RemoveObject(EmployeeAvailableQueueKey);
		}

		public static object EmployeeAvailableQueueItem
		{
			get
			{
				if (SessionManager.GetObject(EmployeeAvailableQueueItemKey) != null)
					return SessionManager.GetObject(EmployeeAvailableQueueItemKey) as Dictionary<int, Dictionary<int, string>>;
				return null;
			}
			set
			{
				SessionManager.SetObject(EmployeeAvailableQueueItemKey, value);
			}
		}

		public static void RemoveEmployeeAvailableQueueItem()
		{
			SessionManager.RemoveObject(EmployeeAvailableQueueItemKey);
		}
        /// <summary>
        /// Gets or sets dialer status of employee.
        /// </summary>
        /// <history>
        ///     2008/08/29  [Binh Truong]   Init version.
        /// </history>
        public static string DialerStatus
        {
            get
            {
                if (SessionManager.GetObject(DialerStatusKey) == null)
                    return string.Empty;

                return SessionManager.GetObject(DialerStatusKey).ToString();
            }
            set
            {
                SessionManager.SetObject(DialerStatusKey, value);
            }
        }

        /// <summary>
        /// Gets or sets processing DialerQueue.
        /// </summary>
        /// <history>
        ///     2008/09/03  [Binh Truong]   Init version.
        /// </history>
        public static object ProcessingDialerQueue
        {
            get
            {
                return SessionManager.GetObject(ProcessingDialerQueueKey);
            }
            set
            {
                SessionManager.SetObject(ProcessingDialerQueueKey, value);
            }
        }

        /// <summary>
        /// Clear Dialer session.
        /// </summary>
        /// <history>
        ///     2008/09/08  [Binh Truong]   Init version.
        /// </history>
        public static void ClearDialerSession()
        {
            SessionManager.RemoveObject(DialerStatusKey);
            SessionManager.RemoveObject(ProcessingDialerQueueKey);
        }

        
    }
}
