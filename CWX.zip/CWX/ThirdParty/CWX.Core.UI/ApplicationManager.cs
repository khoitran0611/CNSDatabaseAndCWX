using System;
using System.Web;
using System.Web.SessionState;

namespace CWX.Core.UI
{
    /// <summary>
    /// This class can be seen as a wrapper of the Application object.
    /// </summary>
    public class ApplicationManager
    {
        public ApplicationManager()
        {

        }

        public static void AddObject(string name, object value)
        {
            CurrentApplication.Add(name, value);
        }

        public static void SetObject(string name, object value)
        {
            if (CurrentApplication == null)
                throw new InvalidOperationException("Application has been expired.");

            CurrentApplication[name] = value;
        }

        public static object GetObject(string name)
        {
            if (CurrentApplication == null)
                return null;
            return CurrentApplication[name];
        }

        public static void RemoveObject(string name)
        {
            CurrentApplication.Remove(name);
        }

        public static HttpApplicationState CurrentApplication
        {
            get
            {
                return HttpContext.Current.Application;
            }
        }
    }
}
