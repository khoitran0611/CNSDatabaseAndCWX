using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;

using CWX.Core.Common.Security;
using CWX.Core.Common.Exceptions;
using CWX.Core.Common.Audit;


namespace CWX.Core.PolicyInjection.CallHandlers
{

    public class CWXAuditCallHandler : ICallHandler
    {
        private CWXAuditAction _auditAction;

        public CWXAuditCallHandler(CWXAuditAction auditAction)
        {
            _auditAction = auditAction;         
        }

        #region ICallHandler Members

        public IMethodReturn Invoke(IMethodInvocation input, GetNextHandlerDelegate getNext)
        {
            
            return getNext().Invoke(input, getNext);
        }

        #endregion
    }
}
