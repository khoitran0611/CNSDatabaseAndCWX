using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;
using CWX.Core.Common.Security;
using System.Threading;
using CWX.Core.Common.Exceptions;

namespace CWX.Core.PolicyInjection.CallHandlers
{
    public class CWXAuthorizationCallHandler : ICallHandler
    {
        private CWXPermissionConstant _permission;

        public CWXAuthorizationCallHandler(CWXPermissionConstant permission)
        {
            _permission = permission;
        }

        #region ICallHandler Members

        public IMethodReturn Invoke(IMethodInvocation input, GetNextHandlerDelegate getNext)
        {
            //if (!CWXAuthorizationManager.Authorize(Thread.CurrentPrincipal, _permission))
            //{
            //    CWXAuthorizationException ex = new CWXAuthorizationException(_permission);
            //    return input.CreateExceptionMethodReturn(ex);
            //}
            return getNext().Invoke(input, getNext);
        }

        #endregion
    }
}
