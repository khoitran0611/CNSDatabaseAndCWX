using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;

using CWX.Core.Common.Audit;

namespace CWX.Core.PolicyInjection.CallHandlers
{
    /// <summary>
    /// Specifies whether a method is under auditing.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public class CWXAuditAttribute : HandlerAttribute
    {
        CWXAuditAction _auditAction;

        /// <summary>
        /// Initializes a new instance of the CWX.Core.PolicyInjection.CallHandlers.CWXAuditAttribute class.
        /// </summary>
        /// <param name="auditAction">Specify auditing action.</param>
        public CWXAuditAttribute(CWXAuditAction auditAction)
        {
            _auditAction = auditAction;
        }

        public override ICallHandler CreateHandler()
        {
            return new CWXAuditCallHandler(_auditAction);
        }
    }
}
