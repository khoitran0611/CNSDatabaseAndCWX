using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;
using CWX.Core.Common.Security;

namespace CWX.Core.PolicyInjection.CallHandlers
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class CWXAuthorizationAttribute : HandlerAttribute
    {
        private CWXPermissionConstant _permission;

        public CWXAuthorizationAttribute(CWXPermissionConstant permission)
        {
            _permission = permission;
        }

        public override ICallHandler CreateHandler()
        {
            return new CWXAuthorizationCallHandler(_permission);
        }
    }
}
