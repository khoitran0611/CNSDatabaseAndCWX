using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace CWX.Core.Common.Data.DataConverter
{
    public interface IDataConverter
    {
        /// <summary>
        /// Converts database value to object's property value
        /// </summary>
        /// <param name="dataValue">Database value</param>
        /// <param name="dbType">Database type</param>
        /// <param name="propertyType">Property type</param>
        /// <returns>Property value</returns>
        object ConvertTo(object dataValue, DbType dbType, Type propertyType);

        /// <summary>
        /// Converts property value to database value
        /// </summary>
        /// <param name="propertyValue">Property value</param>
        /// <param name="dbType">Database type</param>
        /// <param name="propertyType">Property type</param>
        /// <returns>Database value</returns>
        object ConvertFrom(object propertyValue, DbType dbType, Type propertyType);
    }
}
