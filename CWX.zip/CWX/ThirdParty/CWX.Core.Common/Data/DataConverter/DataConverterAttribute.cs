using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Data.DataConverter
{
    [AttributeUsage(AttributeTargets.Property)]
    public class DataConverterAttribute : Attribute
    {
        public DataConverterAttribute(Type dataConverterType)
        {
            _dataConverterType = dataConverterType;
        }

        private Type _dataConverterType;
        public Type DataConverterType
        {
            get { return _dataConverterType; }
            set { _dataConverterType = value; }
        }
    }
}
