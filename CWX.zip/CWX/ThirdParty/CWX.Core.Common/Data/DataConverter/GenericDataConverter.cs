using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace CWX.Core.Common.Data.DataConverter
{
    public class GenericDataConverter : IDataConverter
    {
        #region IDataConverter Members
        /// <summary>
        /// Converts database value to object's property value
        /// </summary>
        /// <param name="dataValue">Database value</param>
        /// <param name="dbType">Database type</param>
        /// <param name="propertyType">Property type</param>
        /// <returns>Property value</returns>
        public object ConvertTo(object dataValue, DbType dbType, Type objectType)
        {
            if (dataValue == DBNull.Value || dataValue == null)
            {
                if (objectType == typeof(bool))
                    return false;
                if (objectType == typeof(string))
                    return string.Empty;
                if (objectType == typeof(DateTime))
                    return DateTime.MinValue;
                if (objectType == typeof(TimeSpan))
                    return TimeSpan.MinValue;
                return null;
            }
            else
            {
                if (objectType == typeof(Int16))
                    return Convert.ToInt16(dataValue);
                if (objectType == typeof(Int32))
                    return Convert.ToInt32(dataValue);
                if (objectType == typeof(DateTime))
                    return Convert.ToDateTime(dataValue);
                if (objectType == typeof(TimeSpan))
                    return TimeSpan.Parse(dataValue.ToString());
                if (objectType == typeof(bool))
                    return Convert.ToBoolean(dataValue);
                if (objectType == typeof(char))
                    return Convert.ToChar(dataValue);

                return dataValue;
            }
        }

        /// <summary>
        /// Converts property value to database value
        /// </summary>
        /// <param name="propertyValue">Property value</param>
        /// <param name="dbType">Database type</param>
        /// <param name="propertyType">Property type</param>
        /// <returns>Database value</returns>
        public object ConvertFrom(object objectValue, DbType dbType, Type objectType)
        {
            if (objectValue == null)
                return DBNull.Value;

            if (objectType == typeof(DateTime))
            {
                if (((DateTime)objectValue) == DateTime.MinValue)
                    return DBNull.Value;
            }
            return objectValue;
        }

        #endregion
    }
}
