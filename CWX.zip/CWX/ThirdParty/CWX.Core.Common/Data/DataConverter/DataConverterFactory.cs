using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace CWX.Core.Common.Data.DataConverter
{
    public class DataConverterFactory
    {
        public static IDataConverter Create(PropertyInfo propertyInfo)
        {
            DataConverterAttribute[] attributes = (DataConverterAttribute[])propertyInfo.GetCustomAttributes(typeof(DataConverterAttribute), false);
            if (attributes != null && attributes.Length != 0)
            {
                DataConverterAttribute attr = attributes[0];
                return (IDataConverter)Activator.CreateInstance(attr.DataConverterType);
            }
            return new GenericDataConverter();
        }
    }
}
