using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Data;
using System.Data.Common;

namespace CWX.Core.Common.Data
{
    public abstract class DataProviderBase : IDataProvider
    {
        #region IDataProvider Members

        public abstract bool Insert<TDomainObject>(TDomainObject domainObject);

        public abstract bool Insert<TDomainObject>(TDomainObject domainObject, out int newID);

		public abstract bool Insert<TDomainObject>(DataTable dataTable) where TDomainObject : class, new();

        public abstract bool Delete<TDomainObject>(string[] identityFields, object[] identityValues);

        public abstract bool Delete<TDomainObject>(TDomainObject domainObject);

        public abstract bool Delete<TDomainObject, TIdentity>(TIdentity identityValue);

        public abstract bool SoftDelete<TDomainObject>(string[] identityFields, object[] identityValues);

        public abstract bool SoftDelete<TDomainObject>(TDomainObject domainObject);

        public abstract bool SoftDelete<TDomainObject, TIdentity>(TIdentity identityValue);

        public abstract bool Update<TDomainObject>(TDomainObject domainObject);

        public abstract bool Update<TDomainObject>(DataTable dataTable) where TDomainObject : class, new();

        public abstract TDomainObject Fill<TDomainObject>(string[] identityFields, object[] identityValues)
            where TDomainObject : class, new();

        public abstract TDomainObject Fill<TDomainObject>(string[] identityFields, object[] identityValues, string[] fillFields)
            where TDomainObject : class, new();

        public abstract TDomainObject Fill<TDomainObject>(TDomainObject domainObject)
            where TDomainObject : class, new();

        public abstract TDomainObject Fill<TDomainObject, TIdentity>(TIdentity identityValue)
            where TDomainObject : class, new();

        public abstract TDomainObject FillFromReader<TDomainObject>(IDataReader reader)
            where TDomainObject : class, new();

        public abstract TDomainObject FillFromReader<TDomainObject>(IDataReader reader, string[] selectedFields)
            where TDomainObject : class, new();

        public abstract TDomainObject FillFromReader<TDomainObject>(IDataReader reader, ProcessReader<TDomainObject> postProcess)
            where TDomainObject : class, new();

        public abstract TDomainObject FillFromReader<TDomainObject>(IDataReader reader, string[] selectedFields, ProcessReader<TDomainObject> postProcess)
            where TDomainObject : class, new();

        public abstract Collection<TDomainObject> FillList<TDomainObject>()
            where TDomainObject : class, new();

        public abstract Collection<TDomainObject> FillList<TDomainObject>(string orderByClause)
            where TDomainObject : class, new();

        public abstract Collection<TDomainObject> FillList<TDomainObject>(string orderByClause, string whereClause)
            where TDomainObject : class, new();

        public abstract Collection<TDomainObject> FillListByStoreProcedure<TDomainObject>(string storeProcedure)
            where TDomainObject : class, new();

        public abstract Collection<TDomainObject> FillListByStoreProcedure<TDomainObject>(string storeProcedure, string[] parameterNames, object[] parameterValues)
            where TDomainObject : class, new();

        public abstract Collection<TDomainObject> FillPagingList<TDomainObject>(int pageSize, int pageIndex, string orderByColumnName, OrderByDirection orderDirection, out int rowCount)
            where TDomainObject : class, new();

        public abstract Collection<TDomainObject> FillPagingList<TDomainObject>(int pageSize, int pageIndex, string orderByClause, string whereClause, out int rowCount)
            where TDomainObject : class, new();

        public abstract Collection<TDomainObject> FillPagingList<TDomainObject>(int pageSize, int pageIndex, string orderByColumnName, OrderByDirection orderDirection, string whereClause, out int rowCount)
            where TDomainObject : class, new();

        public abstract Collection<TDomainObject> FillPagingList<TDomainObject>(string storeProcedure, int pageSize, int pageIndex, out int rowCount)
            where TDomainObject : class, new();

        public abstract Collection<TDomainObject> FillPagingList<TDomainObject>(string storeProcedure, string[] parameterNames, object[] parameterValues, int pageSize, int pageIndex, out int rowCount)
            where TDomainObject : class, new();

        public abstract int GetMaxIdentity<TDomainObject>();

        public abstract int GetMaxIdentity<TDomainObject>(string identityFieldName);

        public abstract int GetMaxIdentity<TDomainObject>(string identityFieldName, string whereClause);

        public abstract int ExecuteNonQuery(string cmdText, CommandType cmdType);

        public abstract int ExecuteNonQuery(string cmdText, CommandType cmdType, DbTransaction transaction);

        public abstract int ExecuteNonQuery(DbCommand command);

        public abstract int ExecuteNonQuery(DbCommand command, DbTransaction transaction);

        public abstract int ExecuteNonQuery(string storedProcedureName, out int returnedValue);

        public abstract int ExecuteNonQuery(string storedProcedureName, string[] parameterNames, object[] parameterValues);

        public abstract int ExecuteNonQuery(string storedProcedureName, string[] parameterNames, object[] parameterValues, out int returnedValue);


        public abstract int ExecuteNonQuery(string storedProcedureName, Dictionary<string, object> parameters);

        public abstract IDataReader ExecuteReader(string cmdText, CommandType cmdType);

        public abstract IDataReader ExecuteReader(string cmdText, CommandType cmdType, DbTransaction transaction);

        public abstract IDataReader ExecuteReader(object[] paramValues, string storedProcedureName);

        public abstract IDataReader ExecuteReader(object[] paramValues, string storedProcedureName, DbTransaction transaction);

        public abstract IDataReader ExecuteReader(DbCommand command);

        public abstract IDataReader ExecuteReader(DbCommand command, DbTransaction transaction);

        public abstract object ExecuteScalar(string cmdText, CommandType cmdType);

        public abstract object ExecuteScalar(string cmdText, CommandType cmdType, DbTransaction transaction);

        public abstract object ExecuteScalar(object[] paramValues, string storedProcedureName);

        public abstract object ExecuteScalar(object[] paramValues, string storedProcedureName, DbTransaction transaction);

        public abstract object ExecuteScalar(DbCommand command);

        public abstract object ExecuteScalar(DbCommand command, DbTransaction transaction);

        public abstract DataSet ExecuteDataSet(DbCommand command);

        public abstract DataSet ExecuteDataSet(CommandType commandType, string commandText);

        public abstract DataSet ExecuteDataSet(DbCommand command, DbTransaction transaction);

        public abstract DataSet ExecuteDataSet(string storedProcedureName);

        public abstract DataSet ExecuteDataSet(string storedProcedureName, params object[] parameterValues);

        public abstract DataSet ExecuteDataSet(DbTransaction transaction, CommandType commandType, string commandText);

        public abstract DataSet ExecuteDataSet(DbTransaction transaction, string storedProcedureName, params object[] parameterValues);

        public abstract DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues);

        public abstract DataSet ExecuteDataSet(string storedProcedureName, int pageSize, int pageIndex, out int rowCount);

        public abstract DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues, int pageSize, int pageIndex, out int rowCount);

        public abstract DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues, string orderByClause, int pageSize, int pageIndex, out int rowCount);

        public abstract DbConnection CreateConnection();

        public abstract DbCommand CreateCommand(QueryBuilderBase queryBuilder);

        public abstract DbCommand CreateCommand(CommandType commandType);

        public abstract DbCommand CreateTextCommand(string commandText);

        public abstract DbCommand CreateStoreProcedureCommand(string storeProcedureName);

        public abstract IDataAdapter CreateDataAdapter(DbCommand selectCommand);

        public abstract string FormatParameterName(string parameterName);

        public IDataExecutionContext BeginExecution()
        {
            return new DataExecutionContext(this);
        }

        public IDataExecutionContext BeginExecution(bool transaction)
        {
            return new DataExecutionContext(transaction, this);
        }

        public IDataExecutionContext BeginExecution(QueryBuilderBase queryBuilder)
        {
            return new DataExecutionContext(this, queryBuilder);
        }

        public IDataExecutionContext BeginExecution(bool transaction, QueryBuilderBase queryBuilder)
        {
            return new DataExecutionContext(transaction, this, queryBuilder);
        }

        #endregion

        #region IDisposable Members

        public abstract void Dispose();

        #endregion
    }
}
