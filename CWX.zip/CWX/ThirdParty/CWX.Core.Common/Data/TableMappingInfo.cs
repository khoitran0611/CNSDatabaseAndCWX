using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using CWX.Core.Common.Exceptions;

namespace CWX.Core.Common.Data
{
    /// <summary>
    /// Represents table mapping information for a specific business object.
    /// </summary>
    /// <history>
    ///     2008/05/22  [Binh Truong]   Add comments.
    /// </history>
    public class TableMappingInfo
    {
        private FieldMappingInfo _primaryFieldInfo;
        public TableMappingInfo()
        {
            _fieldMappings = new Collection<FieldMappingInfo>();
        }

        private string _dbTableName;

        /// <summary>
        /// Gets or sets table name which is mapping to an business object.
        /// </summary>
        public string DBTableName
        {
            get { return _dbTableName; }
            set { _dbTableName = value; }
        }

        private Collection<FieldMappingInfo> _fieldMappings;

        public Collection<FieldMappingInfo> FieldMappings
        {
            get { return _fieldMappings; }
            set { _fieldMappings = value; }
        }

        private Type _objectType;

        public Type ObjectType
        {
            get { return _objectType; }
            set { _objectType = value; }
        }

        private bool _softDeletable;

        /// <summary>
        /// Gets or sets an value whether the business object can be marked as deleted.
        /// </summary>
        public bool SoftDeletable
        {
            get { return _softDeletable; }
            set { _softDeletable = value; }
        }

        private string _recordStatusField;

        /// <summary>
        /// Gets or sets a field name indicating the business object was marked delete or not.
        /// </summary>
        public string RecordStatusField
        {
            get { return _recordStatusField; }
            set { _recordStatusField = value; }
        }

        /// <summary>
        /// Returns a <see cref="FieldMappingInfo"/> which is primary key in database.
        /// </summary>
        /// <returns></returns>
        public FieldMappingInfo GetPrimaryFieldInfo()
        {
            if (_primaryFieldInfo == null && this.FieldMappings != null)
            {
                foreach (FieldMappingInfo fieldInfo in FieldMappings)
                {
                    if (fieldInfo.IsPrimaryKey)
                    {
                        _primaryFieldInfo = fieldInfo;
                        break;
                    }
                }
            }
            return _primaryFieldInfo;
        }

        private bool _forceAudit;
        /// <summary>
        /// get or set an value that require always audit, skip setting audit option
        /// </summary>
        public bool ForceAudit
        {
            get { return _forceAudit; }
            set { _forceAudit = value; }
        }

        private bool _auditOnActionAdd=true;
        /// <summary>
        /// get or set an value that require audit when add or not
        /// </summary>
        public bool AuditOnActionAdd
        {
            get { return _auditOnActionAdd; }
            set { _auditOnActionAdd = value; }
        }

        private bool _auditOnActionEdit = true;
        /// <summary>
        /// get or set an value that require audit when edit or not
        /// </summary>
        public bool AuditOnActionEdit
        {
            get { return _auditOnActionEdit; }
            set { _auditOnActionEdit = value; }
        }

        private bool _auditOnActionDelete = true;
        /// <summary>
        /// get or set an value that require audit when delete or not
        /// </summary>
        public bool AuditOnActionDelete
        {
            get { return _auditOnActionDelete; }
            set { _auditOnActionDelete = value; }
        }
    }
}
