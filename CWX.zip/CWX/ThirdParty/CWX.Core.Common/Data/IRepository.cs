using System;
using System.Data;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace CWX.Core.Common.Data
{
    public interface IRepository<TDomainObject>
        where TDomainObject: class, new()
    {
        /// <summary>
        /// Add a domain object to the datasource.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to add to the datasource.</param>
        /// <returns>true if adding domain object successfully; otherwise, false. </returns>
        bool Add(TDomainObject domainObject);

        /// <summary>
        /// Add a domain object to the datasource. Then output newID.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to add to the datasource.</param>
        /// <returns>true if adding domain object successfully; otherwise, false. </returns>
        bool Add(TDomainObject domainObject, out int newID);

		/// <summary>
		/// Convert multiple rows in DataTable to objects and insert all records to database which return true if inserts successfully, 
		/// otherwise returns false
		/// </summary>
		/// <typeparam name="TDomainObject">The type of domain object.</typeparam>
		/// <param name="domainObject">An instant of DataTable object.</param>
		/// <returns>Returns true if inserts successfully, otherwise returns false.</returns>
		bool Add(DataTable dataTable);

        /// <summary>
        /// Remove a domain object from the datasource.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to remove from the datasource.</param>
        /// <returns>true if removing domain object successfully; otherwise, false.</returns>
        bool Remove(TDomainObject domainObject);

        /// <summary>
        /// Remove a domain object from the datasource.
        /// </summary>
        /// <typeparam name="TIdentity">Type of domain object identity.</typeparam>
        /// <param name="identityValue">The identity for the domain object.</param>
        /// <returns>true if removing domain object successfully; otherwise, false.</returns>
        /// <remarks>TDomainObject must have only <b>one identity</b></remarks>
        bool Remove<TIdentity>(TIdentity identity);

        /// <summary>
        /// Marks a domain object as deleted.
        /// </summary>
        /// <typeparam name="TIdentity">Type of domain object identity.</typeparam>
        /// <param name="identityValue">The identity for the domain object.</param>
        /// <returns>true if removing domain object successfully; otherwise, false.</returns>
        /// <remarks>TDomainObject must have only <b>one identity</b></remarks>
        bool SoftDelete<TIdentity>(TIdentity identityValue);

        /// <summary>
        /// Marks a domain object as deleted.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to remove from the datasource.</param>
        /// <returns>true if removing domain object successfully; otherwise, false.</returns>
        bool SoftDelete(TDomainObject domainObject);

        /// <summary>
        /// Update a domain object in the datasource and clear cache if existed.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to update.</param>
        /// <returns>true if updating domain object successfully; otherwise, false. </returns>
        bool Update(TDomainObject domainObject);

        /// <summary>
        /// Update a domain object in the datasource
        /// </summary>
        /// <param name="domainObject">A TDomainObject to update.</param>
        /// <param name="clearCache">true clear cache; otherwise, false.</param>
        /// <returns>true if updating domain object successfully; otherwise, false.</returns>
        bool Update(TDomainObject domainObject, bool clearCache);

        bool Update(DataTable dataTable);

        /// <summary>
        /// Find a domain object from the datasource.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to find from the datasource.</param>
        /// <returns>A TDomainObject</returns>
        TDomainObject FindOne(TDomainObject domainObject);

        /// <summary>
        /// Find a domain object from the datasource.
        /// </summary>
        /// <typeparam name="TIdentity">Type of domain object identity.</typeparam>
        /// <param name="identityValue">The identity for the domain object.</param>
        /// <returns>A TDomainObject</returns>
        /// <remarks>TDomainObject must have only <b>one identity</b></remarks>
        TDomainObject FindOne<TIdentity>(TIdentity identity);

        /// <summary>
        /// Find a domain object from the datasource.
        /// </summary>
        /// <param name="identityFields">The identity's names for the domain object.</param>
        /// <param name="identityValues">The identity's values for the domain object.</param>
        /// <returns>A TDomainObject</returns>
        TDomainObject FindOne(string[] identityFields, object[] identityValues);

        /// <summary>
        /// Get a list of TDomainObject from the datasource.
        /// </summary>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;></returns>
        Collection<TDomainObject> FillList();

        /// <summary>
        /// Get a list of TDomainObject from the datasource.
        /// </summary>
        /// <param name="orderByClause">order by clause to sort the TDomainObject list</param>
        /// <returns>A System.Collections.ObjectModel.Collection<TDomainObject></returns>
        Collection<TDomainObject> FillList(string orderByClause);

        /// <summary>
        /// Get a list of TDomainObject from the datasource.
        /// </summary>
        /// <param name="orderByClause">order by clause to sort the TDomainObject list</param>
        /// <param name="whereClause">where clause to filter the TDomainObject list</param>
        /// <returns>A System.Collections.ObjectModel.Collection<TDomainObject></returns>
        Collection<TDomainObject> FillList(string orderByClause, string whereClause);

        /// <summary>
        /// Get a list of TDomainObject from the application cache.
        /// </summary>
        /// <remarks>
        /// If AppSettings BusinessCacheTime does not exist in the config file, default cache time will be 10 mins.
        /// Cache key is generated from "FillList_[TDomainObject class name]".
        /// </remarks>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;></returns>
        /// <history>
        ///     08/07/01    [Binh Truong]   Init version.
        /// </history>
        Collection<TDomainObject> FillListFromCache();
                
        /// <summary>
        /// Get a list of TDomainObject from the datasource with giving pageSize and pageIndex.
        /// </summary>
        /// <param name="pageSize">pageSize</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="orderByColumnName">orderByColumn</param>
        /// <param name="orderDirection">orderDirection</param>
        /// <param name="rowCount">The number of selected TDomainObjects</param>
        /// <returns>A System.Collections.ObjectModel.Collection<TDomainObject></returns>
        Collection<TDomainObject> FillPagingList(int pageSize, int pageIndex, string orderByColumnName, OrderByDirection orderDirection, out int rowCount);

        /// <summary>
        /// Selects record(s) with the given pageSize, pageIndex, orderByColumnName and orderDirection then returns an collection of objects
        /// and supplies the number of found records through output param rowCount.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="orderByClause">Expression of orderByClause including order direction. Ex: "[FieldName] ASC" or "[FieldName] DESC".</param>
        /// <param name="whereClause">Expression of whereClause. Ex: "[FieldName] = value" or "[FieldName] like '%value%'".</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        Collection<TDomainObject> FillPagingList(int pageSize, int pageIndex, string orderByClause, string whereClause, out int rowCount);

        /// <summary>
        /// Selects record(s) with the given pageSize, pageIndex, orderByColumnName and orderDirection then returns an collection of objects
        /// and supplies the number of found records through output param rowCount.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="orderByColumnName">The name of the column that is used to order found records.</param>
        /// <param name="orderDirection">Type of orderDirection</param>
        /// <param name="whereClause">Expression of whereClause. Ex: "[FieldName] = value" or "[FieldName] like '%value%'".</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        Collection<TDomainObject> FillPagingList(int pageSize, int pageIndex, string orderByColumnName, OrderByDirection orderDirection, string whereClause, out int rowCount);

        /// <summary>
        /// Fills a DataSet.
        /// </summary>
        /// <param name="storedProcedureName">stored procedure to select data.</param>
        /// <param name="parameterNames">the names for the stored procedure parameters.</param>
        /// <param name="paremeterValues">the values for the stored procedure parameters.</param>
        /// <returns>A System.Data.DataSet</returns>
        DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues);

        /// <summary>
        /// Fills a DataSet.
        /// </summary>
        /// <param name="storedProcedureName">stored procedure to select data.</param>
        /// <param name="parameterNames">the names for the stored procedure parameters.</param>
        /// <param name="paremeterValues">the values for the stored procedure parameters.</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="rowCount">the number of selected records.</param>
        /// <returns>A System.Data.DataSet</returns>
        DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues, int pageSize, int pageIndex, out int rowCount);

        /// <summary>
        /// Fills a DataSet
        /// </summary>
        /// <param name="commandText"></param>
        /// <returns></returns>
        DataSet ExecuteDataSet(string commandText, CommandType commandType);

        /// <summary>
        /// Executes a store procedure and returns the number of rows affected.
        /// </summary>
        /// <param name="storedProcedureName">stored procedure to execute.</param>
        /// <param name="parameterNames">the names for the stored procedure parameters.</param>
        /// <param name="parameterValues">the values for the stored procedure parameters.</param>
        /// <returns>the number of rows affected.</returns>
        int ExecuteNonQuery(string storedProcedureName, string[] parameterNames, object[] parameterValues);

        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="returnedValue">System.Int32</param>
        /// <returns>The number of rows affected.</returns>
        int ExecuteNonQuery(string storedProcedureName, out int returnedValue);

        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="parameterNames">Array of parameter names.</param>
        /// <param name="parameterValues">Array of parameter values.</param>
        /// <param name="returnedValue">System.Int32</param>
        /// <returns></returns>
        int ExecuteNonQuery(string storedProcedureName, string[] parameterNames, object[] parameterValues, out int returnedValue);

        /// <summary>
        /// Execute a T-SQL statement and return a IDataReader object
        /// </summary>
        /// <param name="cmdText">The T-SQL statement</param>
        /// <returns>A IDataReader</returns>
        IDataReader ExecuteReader(string cmdText);

        /// <summary>
        /// Executes a store procedure.
        /// If the store procedure doesn't receive any parameters, let pass the NULL value in paramNames and paramValues.
        /// </summary>
        /// <param name="storeProcedureName">The store procedure name which is wanted to run</param>
        /// <param name="paramNames">The parameter names</param>
        /// <param name="paramValues">The parameter values</param>
        /// <returns>A IDataReader</returns>
        IDataReader ExecuteReader(string storeProcedureName, string[] paramNames, object[] paramValues);

        /// <summary>
        /// Get the max identity of the TDomainObject from the datasource.
        /// </summary>
        /// <returns>The max identity of the TDomainObject.</returns>
        int GetMaxIdentity();

        /// <summary>
        /// Get the max identity of the TDomainObject from the datasource.
        /// </summary>
        /// <returns>The max identity of the TDomainObject.</returns>
        int GetMaxIdentity(string identityFieldName, string whereClause);

        /// <summary>
        /// Clear FillList cache.
        /// </summary>
        void ClearFillListCache();
    }
}
