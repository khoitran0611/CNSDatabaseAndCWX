using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;

namespace CWX.Core.Common.Data
{
    public interface IQueryBuilder
    {
        DbCommand BuildCommand();
    }
}
