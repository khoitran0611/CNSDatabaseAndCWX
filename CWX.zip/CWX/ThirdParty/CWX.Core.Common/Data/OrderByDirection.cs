using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Data
{
    public enum OrderByDirection
    {
        Ascending,
        Descending
    }
}
