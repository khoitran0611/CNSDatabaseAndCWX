using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace CWX.Core.Common.Data
{
    public class ParameterInfo
    {
        private string _parameterName;
        public string ParameterName
        {
            get { return _parameterName; }
            set { _parameterName = value; }
        }

        private object _parameterValue;
        public object ParameterValue
        {
            get { return _parameterValue; }
            set { _parameterValue = value; }
        }

        private ParameterDirection _direction;
        public ParameterDirection Direction
        {
            get { return _direction; }
            set { _direction = value; }
        }
    }
}
