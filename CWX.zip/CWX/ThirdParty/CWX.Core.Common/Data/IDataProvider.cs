using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;


namespace CWX.Core.Common.Data
{
    public delegate void ProcessReader<TDomainObject>(IDataReader reader, ref TDomainObject domainObject);
    public interface IDataProvider : IDisposable
    {
        #region CRUD Action Methods

        /// <summary>
        /// Inserts an object into database and returns true if inserts successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Returns true if inserts successfully, otherwise returns false.</returns>
        bool Insert<TDomainObject>(TDomainObject domainObject);

        /// <summary>
        /// Inserts an object into database and returns true if inserts successfully, otherwise returns false.
        /// Then output new ID.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Returns true if inserts successfully, otherwise returns false.</returns>
        bool Insert<TDomainObject>(TDomainObject domainObject, out int newID);

		/// <summary>
		/// Convert multiple rows in DataTable to objects and insert all records to database which return true if inserts successfully, 
		/// otherwise returns false
		/// </summary>
		/// <typeparam name="TDomainObject">The type of domain object.</typeparam>
		/// <param name="domainObject">An instant of DataTable object.</param>
		/// <returns>Returns true if inserts successfully, otherwise returns false.</returns>
		bool Insert<TDomainObject>(DataTable dataTable) where TDomainObject : class, new();

        /// <summary>
        /// Deletes a record with the given array of identity fields that have identity values 
        /// and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="identityFields">An array of identity fields.</param>
        /// <param name="identityValues">An array of identity values.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        bool Delete<TDomainObject>(string[] identityFields, object[] identityValues);

        /// <summary>
        /// Deletes a record where its identity value is equal to the identity value of the given object
        /// and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        bool Delete<TDomainObject>(TDomainObject domainObject);

        /// <summary>
        /// Deletes a record with the given identityValue and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <typeparam name="TIdentity">The type of the given identityValue.</typeparam>
        /// <param name="identityValue">The value of identity.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        bool Delete<TDomainObject, TIdentity>(TIdentity identityValue);

        /// <summary>
        /// Marks deleted a record with the given array of identity fields that have identity values 
        /// and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="identityFields">An array of identity fields.</param>
        /// <param name="identityValues">An array of identity values.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        bool SoftDelete<TDomainObject>(string[] identityFields, object[] identityValues);

        /// <summary>
        /// Marks deleted a record where its identity value is equal to the identity value of the given object
        /// and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        bool SoftDelete<TDomainObject>(TDomainObject domainObject);

        /// <summary>
        /// Marks deleted a record with the given identityValue and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <typeparam name="TIdentity">The type of the given identityValue.</typeparam>
        /// <param name="identityValue">The value of identity.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        bool SoftDelete<TDomainObject, TIdentity>(TIdentity identityValue);

        /// <summary>
        /// Updates a record where its identity value is equal to the identity value of the given object
        /// and return true if updates successfully, otherwise return false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Return true if updates successfully, otherwise return false</returns>
        bool Update<TDomainObject>(TDomainObject domainObject);

        /// <summary>
        /// Convert multiple rows in DataTable to objects and update all records to database which return true if updates successfully, 
        /// otherwise returns false
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of DataTable object.</param>
        /// <returns>Returns true if updates successfully, otherwise returns false.</returns>
        bool Update<TDomainObject>(DataTable dataTable) where TDomainObject : class, new();

        /// <summary>
        /// Selects a record with the given array of identity fields that have identity values
        /// and returns an object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="identityFields">An array of identity fields.</param>
        /// <param name="identityValues">An array of identity values.</param>
        /// <returns>Returns an object.</returns>
        TDomainObject Fill<TDomainObject>(string[] identityFields, object[] identityValues) where TDomainObject : class, new();

        /// <summary>
        /// Selects a record with the given fill fields and the given array of identity fields that have identity values
        /// then returns an object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="identityFields">An array of identity fields.</param>
        /// <param name="identityValues">An array of identity values.</param>
        /// <param name="fillFields">An array of fill fields.</param>
        /// <returns>Returns an object.</returns>
        TDomainObject Fill<TDomainObject>(string[] identityFields, object[] identityValues, string[] fillFields) where TDomainObject : class, new();

        /// <summary>
        /// Selects a record where its identity value is equal to the identity value of the given object
        /// and returns an object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Returns an object.</returns>
        TDomainObject Fill<TDomainObject>(TDomainObject domainObject) where TDomainObject : class, new();

        /// <summary>
        /// Selects a record where its identity value is equal to the given identity value
        /// and returns an object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <typeparam name="TIdentity">The type of the given identityValue</typeparam>
        /// <param name="identityValue">Value of identity.</param>
        /// <returns>Returns an object.</returns>
        TDomainObject Fill<TDomainObject, TIdentity>(TIdentity identityValue) where TDomainObject : class, new();

        /// <summary>
        /// Selects a record from the given reader and returns an object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="reader">System.Data.IDataReader.</param>
        /// <returns>Returns an object.</returns>
        TDomainObject FillFromReader<TDomainObject>(IDataReader reader) where TDomainObject : class, new();

        /// <summary>
        /// Selects a record from the given reader with the given selected fields and returns an object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="reader">System.Data.IDataReader.</param>
        /// <param name="selectedFields">An array of the selected fields.</param>
        /// <returns>Returns an object.</returns>
        TDomainObject FillFromReader<TDomainObject>(IDataReader reader, string[] selectedFields) where TDomainObject : class, new();

        /// <summary>
        /// Selects a record from the given reader then processes the result before returning a final object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="reader">System.Data.IDataReader.</param>
        /// <param name="postProcess">Name of an delegate.</param>
        /// <returns>Returns an object.</returns>
        TDomainObject FillFromReader<TDomainObject>(IDataReader reader, ProcessReader<TDomainObject> postProcess) where TDomainObject : class, new();

        /// <summary>
        /// Selects a record from the given reader with the given selected fields then processes the result before returning a final object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="reader">System.Data.IDataReader.</param>
        /// <param name="selectedFields">An array of selected fields.</param>
        /// <param name="postProcess">Name of an delegate.</param>
        /// <returns>Returns an ojbects.</returns>
        TDomainObject FillFromReader<TDomainObject>(IDataReader reader, string[] selectedFields, ProcessReader<TDomainObject> postProcess) where TDomainObject : class, new();

        /// <summary>
        /// Selects record(s) then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <returns>Returns a collection of objects.</returns>
        Collection<TDomainObject> FillList<TDomainObject>() where TDomainObject : class, new();

        /// <summary>
        /// Selects record(s) with the given oderByClause then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="orderByClause">Expression of orderByClause including order direction. Ex: "[FieldName] ASC" or "[FieldName] DESC".</param>
        /// <returns>Returns a collection of objects.</returns>
        Collection<TDomainObject> FillList<TDomainObject>(string orderByClause) where TDomainObject : class, new();

        /// <summary>
        /// Selects record(s) with the given whereClause and oderByClause then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="orderByClause">Expression of orderByClause including order direction. Ex: "[FieldName] ASC" or "[FieldName] DESC".</param>
        /// <param name="whereClause">Expression of whereClause. Ex: "[FieldName] = value" or "[FieldName] like '%value%'".</param>
        /// <returns>Returns a collection of objects.</returns>
        Collection<TDomainObject> FillList<TDomainObject>(string orderByClause, string whereClause) where TDomainObject : class, new();

        /// <summary>
        /// Selects record(s) with the given storeprocedure then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="orderByClause">storeprocedure name.</param>
        /// <returns>Returns a collection of objects.</returns>
        Collection<TDomainObject> FillListByStoreProcedure<TDomainObject>(string storeProcedure) where TDomainObject : class, new();

        /// <summary>
        /// Selects record(s) with the given storeprocedure, parameterNames and parameterValues then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject"></typeparam>
        /// <param name="storeProcedure">storeprocedure name</param>
        /// <param name="parameterNames">parameter names</param>
        /// <param name="parameterValues">parameter values</param>
        /// <returns>Returns a collection of objects.</returns>
        Collection<TDomainObject> FillListByStoreProcedure<TDomainObject>(string storeProcedure, string[] parameterNames, object[] parameterValues) where TDomainObject : class, new();

        /// <summary>
        /// Selects record(s) with the given pageSize, pageIndex, orderByColumnName and orderDirection then returns an collection of objects
        /// and supplies the number of found records through output param rowCount.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="orderByColumnName">The name of the column that is used to order found records.</param>
        /// <param name="orderDirection">Type of orderDirection</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        Collection<TDomainObject> FillPagingList<TDomainObject>(int pageSize, int pageIndex, string orderByColumnName, OrderByDirection orderDirection, out int rowCount) where TDomainObject : class, new();

        /// <summary>
        /// Selects record(s) with the given pageSize, pageIndex, orderByColumnName and orderDirection then returns an collection of objects
        /// and supplies the number of found records through output param rowCount.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="orderByClause">Expression of orderByClause including order direction. Ex: "[FieldName] ASC" or "[FieldName] DESC".</param>
        /// <param name="whereClause">Expression of whereClause. Ex: "[FieldName] = value" or "[FieldName] like '%value%'".</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        Collection<TDomainObject> FillPagingList<TDomainObject>(int pageSize, int pageIndex, string orderByClause, string whereClause, out int rowCount) where TDomainObject : class, new();

        /// <summary>
        /// Selects record(s) with the given pageSize, pageIndex, orderByColumnName and orderDirection then returns an collection of objects
        /// and supplies the number of found records through output param rowCount.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="orderByColumnName">The name of the column that is used to order found records.</param>
        /// <param name="orderDirection">Type of orderDirection</param>
        /// <param name="whereClause">Expression of whereClause. Ex: "[FieldName] = value" or "[FieldName] like '%value%'".</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        Collection<TDomainObject> FillPagingList<TDomainObject>(int pageSize, int pageIndex, string orderByColumnName, OrderByDirection orderDirection, string whereClause, out int rowCount)
            where TDomainObject : class, new();

        /// <summary>
        /// Selects record(s) with the given storeprocedure then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="storeProcedure">storeprocedure name.</param>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        Collection<TDomainObject> FillPagingList<TDomainObject>(string storeProcedure, int pageSize, int pageIndex, out int rowCount)
            where TDomainObject : class, new();

        /// <summary>
        /// Selects record(s) with the given storeprocedure, parameterNames and parameterValues then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject"></typeparam>
        /// <param name="storeProcedure">storeprocedure name</param>
        /// <param name="parameterNames">parameter names</param>
        /// <param name="parameterValues">parameter values</param>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        Collection<TDomainObject> FillPagingList<TDomainObject>(string storeProcedure, string[] parameterNames, object[] parameterValues, int pageSize, int pageIndex, out int rowCount)
            where TDomainObject : class, new();

        /// <summary>
        /// Get the max identity of the TDomainObject from the datasource.
        /// </summary>
        /// <returns>The max identity of the TDomainObject.</returns>
        int GetMaxIdentity<TDomainObject>();
        
        /// <summary>
        /// Get the max identity of the TDomainObject from the datasource.
        /// </summary>
        /// <typeparam name="TDomainObject"></typeparam>
        /// <param name="identityFieldName"></param>
        /// <returns>The max identity of the TDomainObject.</returns>
        int GetMaxIdentity<TDomainObject>(string identityFieldName);

        /// <summary>
        /// Get the max identity of the TDomainObject from the datasource.
        /// </summary>
        /// <typeparam name="TDomainObject"></typeparam>
        /// <param name="identityFieldName"></param>
        /// <param name="whereClause"></param>
        /// <returns>The max identity of the TDomainObject.</returns>
        int GetMaxIdentity<TDomainObject>(string identityFieldName, string whereClause);

        #endregion

        #region Common Access Methods

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType and
        ///     returns the number of rows affected.
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <returns>The number of rows affected.</returns>
        int ExecuteNonQuery(string cmdText, CommandType cmdType);

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType as part
        ///     of the given transaction and returns the number of rows affected. 
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>The number of rows affected.</returns>
        int ExecuteNonQuery(string cmdText, CommandType cmdType, DbTransaction transaction);

        /// <summary>
        ///     Executes the command and returns the number of rows affected.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <returns>The number of rows affected.</returns>
        int ExecuteNonQuery(DbCommand command);

        /// <summary>
        ///     Executes the command within the given transaction, and returns the number
        ///     of rows affected.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>The number of rows affected.</returns>
        int ExecuteNonQuery(DbCommand command, DbTransaction transaction);

        /// <summary>
        /// Excutes a store procedure with the give storedProcedureName, parameterNames, parameterValues.
        /// </summary>
        /// <param name="storedProcedureName">Name of the store procedure.</param>
        /// <param name="parameterNames">An array of param names.</param>
        /// <param name="paremeterValues">An array of param values.</param>
        /// <returns>The number of rows affected.</returns>
        int ExecuteNonQuery(string storedProcedureName, string[] parameterNames, object[] parameterValues);

        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="returnedValue">System.Int32</param>
        /// <returns>The number of rows affected.</returns>
        int ExecuteNonQuery(string storedProcedureName, out int returnedValue);        

        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="parameterNames">Array of parameter names.</param>
        /// <param name="parameterValues">Array of parameter values.</param>
        /// <param name="returnedValue">System.Int32</param>
        /// <returns></returns>
        int ExecuteNonQuery(string storedProcedureName, string[] parameterNames, object[] parameterValues, out int returnedValue);

        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="parameters">>Array of parameter</param>
        /// <returns>System.Int32</returns>
        int ExecuteNonQuery(string storedProcedureName, Dictionary<string, object> parameters);

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType and
        ///     returns an System.Data.IDataReader through which the result can be read.
        ///     It is the responsibility of the caller to close the connection and reader
        ///     when finished.
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <returns>An System.Data.IDataReader object.</returns>
        IDataReader ExecuteReader(string cmdText, CommandType cmdType);

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType as part
        ///     of the given transaction and returns the number of rows affected.
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns></returns>
        IDataReader ExecuteReader(string cmdText, CommandType cmdType, DbTransaction transaction);

        /// <summary>
        ///     Executes the storedProcedureName with the given parameterValues and returns
        ///     an System.Data.IDataReader through which the result can be read.  It is the
        ///     responsibility of the caller to close the connection and reader when finished.
        /// </summary>
        /// <param name="paramValues">An array of paramters to pass to the stored procedure. The parameter values
        ///    must be in call order as they appear in the stored procedure.</param>
        /// <param name="storedProcedureName">The name of the stored procedure to execute.</param>
        /// <returns>An System.Data.IDataReader object.</returns>
        IDataReader ExecuteReader(object[] paramValues, string storedProcedureName);

        /// <summary>
        ///     Executes the storedProcedureName with the given parameterValues within the
        ///     given transaction and returns an System.Data.IDataReader through which the
        ///     result can be read.  It is the responsibility of the caller to close the
        ///     connection and reader when finished.
        /// </summary>
        /// <param name="paramValues">An array of paramters to pass to the stored procedure. The parameter values
        ///     must be in call order as they appear in the stored procedure.</param>
        /// <param name="storedProcedureName">The command that contains the query to execute.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>An System.Data.IDataReader object.</returns>
        IDataReader ExecuteReader(object[] paramValues, string storedProcedureName, DbTransaction transaction);

        /// <summary>
        ///     Executes the command and returns an System.Data.IDataReader through which
        ///     the result can be read.  It is the responsibility of the caller to close
        ///     the connection and reader when finished.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <returns>An System.Data.IDataReader object.</returns>
        IDataReader ExecuteReader(DbCommand command);

        /// <summary>
        ///     Executes the command within a transaction and returns an System.Data.IDataReader
        ///     through which the result can be read.  It is the responsibility of the caller
        ///     to close the connection and reader when finished.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>An System.Data.IDataReader object.</returns>
        IDataReader ExecuteReader(DbCommand command, DbTransaction transaction);

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType and
        ///     returns the first column of the first row in the result set returned by the
        ///    query. Extra columns or rows are ignored.
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <returns>The first column of the first row in the result set.</returns>
        object ExecuteScalar(string cmdText, CommandType cmdType);

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType within
        ///     the given transaction and returns the first column of the first row in the
        ///     result set returned by the query. Extra columns or rows are ignored.
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>The first column of the first row in the result set.</returns>
        object ExecuteScalar(string cmdText, CommandType cmdType, DbTransaction transaction);

        /// <summary>
        ///     Executes the storedProcedureName with the given parameterValues and returns
        ///     the first column of the first row in the result set returned by the query.
        ///     Extra columns or rows are ignored.
        /// </summary>
        /// <param name="paramValues">An array of paramters to pass to the stored procedure. The parameter values
        ///     must be in call order as they appear in the stored procedure.</param>
        /// <param name="storedProcedureName">The stored procedure to execute.</param>
        /// <returns>The first column of the first row in the result set.</returns>
        object ExecuteScalar(object[] paramValues, string storedProcedureName);

        /// <summary>
        ///     Executes the storedProcedureName with the given parameterValues within a
        ///     transaction and returns the first column of the first row in the result set
        ///     returned by the query. Extra columns or rows are ignored.
        /// </summary>
        /// <param name="paramValues">An array of paramters to pass to the stored procedure. The parameter values
        ///     must be in call order as they appear in the stored procedure.</param>
        /// <param name="storedProcedureName">The stored procedure to execute.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns></returns>
        object ExecuteScalar(object[] paramValues, string storedProcedureName, DbTransaction transaction);

        /// <summary>
        ///     Executes the command and returns the first column of the first row in the
        ///     result set returned by the query. Extra columns or rows are ignored.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <returns>The first column of the first row in the result set.</returns>
        object ExecuteScalar(DbCommand command);

        /// <summary>
        ///     Executes the command within a transaction, and returns the first column of
        ///     the first row in the result set returned by the query. Extra columns or rows
        ///     are ignored.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>The first column of the first row in the result set.</returns>
        object ExecuteScalar(DbCommand command, DbTransaction transaction);

        /// <summary>
        /// Executes the command and returns the results in a new System.Data.DataSet.
        /// </summary>
        /// <param name="command">The System.Data.Common.DbCommand to execute.</param>
        /// <returns>A System.Data.DataSet with the results of the command.</returns>
        DataSet ExecuteDataSet(DbCommand command);

        /// <summary>
        /// Executes the commandText interpreted as specified by the commandType and
        ///  returns the results in a new System.Data.DataSet.
        /// </summary>
        /// <param name="commandType">One of the System.Data.CommandType values.</param>
        /// <param name="commandText">The command text to execute.</param>
        /// <returns>A System.Data.DataSet with the results of the commandText.</returns>
        DataSet ExecuteDataSet(CommandType commandType, string commandText);

        /// <summary>
        /// Executes the command as part of the transaction and returns the results in
        ///  a new System.Data.DataSet.
        /// </summary>
        /// <param name="command">The System.Data.Common.DbCommand to execute.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>A System.Data.DataSet with the results of the command.</returns>
        DataSet ExecuteDataSet(DbCommand command, DbTransaction transaction);

        /// <summary>
        /// Executes the storedProcedureName with parameterValues and returns the results
        ///  in a new System.Data.DataSet.
        /// </summary>
        /// <param name="storedProcedureName">The stored procedure to execute.</param>
        /// <returns>A System.Data.DataSet with the results of the storedProcedureName.</returns>
        DataSet ExecuteDataSet(string storedProcedureName);

        /// <summary>
        /// Executes the storedProcedureName with parameterValues and returns the results
        ///  in a new System.Data.DataSet.
        /// </summary>
        /// <param name="storedProcedureName">The stored procedure to execute.</param>
        /// <param name="parameterValues">An array of parameters to pass to the stored procedure. The parameter values must be in call order as they appear in the stored procedure.</param>
        /// <returns>A System.Data.DataSet with the results of the storedProcedureName.</returns>
        DataSet ExecuteDataSet(string storedProcedureName, params object[] parameterValues);

        /// <summary>
        /// Executes the commandText as part of the given transaction and returns the
        ///  results in a new System.Data.DataSet.
        /// </summary>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <param name="commandType">One of the System.Data.CommandType values.</param>
        /// <param name="commandText">The command text to execute.</param>
        /// <returns>A System.Data.DataSet with the results of the commandText.</returns>
        DataSet ExecuteDataSet(DbTransaction transaction, CommandType commandType, string commandText);

        /// <summary>
        /// Executes the storedProcedureName with parameterValues as part of the transaction
        ///  and returns the results in a new System.Data.DataSet within a transaction.
        /// </summary>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <param name="storedProcedureName">The stored procedure to execute.</param>
        /// <param name="parameterValues">An array of paramters to pass to the stored procedure. The parameter values must be in call order as they appear in the stored procedure.</param>
        /// <returns>A System.Data.DataSet with the results of the storedProcedureName.</returns>
        DataSet ExecuteDataSet(DbTransaction transaction, string storedProcedureName, params object[] parameterValues);

        /// <summary>
        /// Excutes a store procedure with the give storedProcedureName, parameterNames, parameterValues
        /// and returns a System.Data.DataSet as the result.
        /// </summary>
        /// <param name="storedProcedureName">Name of the store procedure.</param>
        /// <param name="parameterNames">An array of param names.</param>
        /// <param name="paremeterValues">An array of param values.</param>
        /// <returns>System.Data.DataSet</returns>
        DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues);
        
        /// <summary>
        /// Excutes a store procedure with the give storedProcedureName, parameterNames, parameterValues
        /// and returns a System.Data.DataSet as the result.
        /// </summary>
        /// <param name="storedProcedureName">Name of the store procedure.</param>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>System.Data.DataSet</returns>
        DataSet ExecuteDataSet(string storedProcedureName, int pageSize, int pageIndex, out int rowCount);

        /// <summary>
        /// Excutes a store procedure with the give storedProcedureName, parameterNames, parameterValues
        /// and returns a System.Data.DataSet as the result.
        /// </summary>
        /// <param name="storedProcedureName">Name of the store procedure.</param>
        /// <param name="parameterNames">An array of param names.</param>
        /// <param name="paremeterValues">An array of param values.</param>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>System.Data.DataSet</returns>
        DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues, int pageSize, int pageIndex, out int rowCount);

        /// <summary>
        /// Excutes a store procedure with the give storedProcedureName, parameterNames, parameterValues
        /// and returns a System.Data.DataSet as the result.
        /// </summary>
        /// <param name="storedProcedureName">Name of the store procedure.</param>
        /// <param name="parameterNames">An array of param names.</param>
        /// <param name="paremeterValues">An array of param values.</param>
        /// <param name="orderByClause">
        /// Order by clause to sort the list. This parametter is required.
        /// Ex: "EmployeeName DESC, Salary ASC"
        /// </param>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>System.Data.DataSet</returns>
        DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues, string orderByClause, int pageSize, int pageIndex, out int rowCount);

        #endregion

        /// <summary>
        /// Create the DbConnection object in the database
        /// </summary>
        /// <returns></returns>
        DbConnection CreateConnection();

        /// <summary>
        /// Create the DbCommand base on the QueryBuilderBase
        /// </summary>
        /// <param name="queryBuilder"></param>
        /// <returns></returns>
        DbCommand CreateCommand(QueryBuilderBase queryBuilder);

        /// <summary>
        /// Create a query statement command
        /// </summary>
        /// <returns>The DbCommand</returns>
        DbCommand CreateTextCommand(string commandText);

        /// <summary>
        /// Create a store procedure command
        /// </summary>
        /// <param name="storeProcedureName">The store procedure name</param>
        /// <returns>The DbCommand</returns>
        DbCommand CreateStoreProcedureCommand(string storeProcedureName);

        /// <summary>
        /// Create a command with a specific CommandType value
        /// </summary>
        /// <param name="commandType">The type of command which want to be created</param>
        /// <returns>The DbCommand</returns>
        DbCommand CreateCommand(CommandType commandType);

        /// <summary>
        /// Create a DataAdapter object from the particular database.
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        IDataAdapter CreateDataAdapter(DbCommand selectCommand);

        /// <summary>
        /// Begin a data execution context without transaction context
        /// </summary>
        /// <returns></returns>
        IDataExecutionContext BeginExecution();

        /// <summary>
        /// Begin a data execution context with the specified transaction
        /// </summary>
        /// <param name="transaction"></param>
        /// <returns></returns>
        IDataExecutionContext BeginExecution(bool transaction);

        /// <summary>
        /// Begin a data execution context without transaction context and using the
        /// query builder to build the command.
        /// </summary>
        /// <param name="queryBuilder"></param>
        /// <returns></returns>
        IDataExecutionContext BeginExecution(QueryBuilderBase queryBuilder);

        /// <summary>
        /// Begin a data execution context with transaction context and using the
        /// query builder to build the command.
        /// </summary>
        /// <param name="transaction"></param>
        /// <param name="queryBuilder"></param>
        /// <returns></returns>
        IDataExecutionContext BeginExecution(bool transaction, QueryBuilderBase queryBuilder);

        /// <summary>
        /// Format the parameter name of the command in the particular database query syntax.
        /// </summary>
        /// <param name="parameterName">The parameter name</param>
        /// <returns></returns>
        string FormatParameterName(string parameterName);
        
    }
}
