using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Data
{

    /// <summary>
    /// Represents a record status in database.
    /// </summary>
    public struct RecordStatusConstant
    {
        /// <summary>
        /// Indicating record data is active. Status = "A".
        /// </summary>
        public const string ACTIVE = "A";
        /// <summary>
        /// Indicating record data is deleted. Status = "R".
        /// </summary>
        public const string RETIRED = "R";
        /// <summary>
        /// Indicating record data is temporally deactive. Status = "D".
        /// </summary>
        public const string DEACTIVE = "D";
    }
}
