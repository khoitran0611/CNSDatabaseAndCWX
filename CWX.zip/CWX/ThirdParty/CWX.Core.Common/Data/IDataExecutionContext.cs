using System;
using System.Data;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;

namespace CWX.Core.Common.Data
{
    public interface IDataExecutionContext : IDisposable
    {

        #region Properties
        /// <summary>
        /// The collection of ParameterInfo. It represents the information of DbParameter of a DbCommand.
        /// </summary>
        Collection<ParameterInfo> ParameterInfos
        {
            get;
        }

        /// <summary>
        /// The affected records number after the execution.
        /// </summary>
        int AffectedRowsCount
        {
            get;
        }

        #endregion

        #region Context Setting Methods
        /// <summary>
        /// Set the command text which want to execute.
        /// The command text can be a query statement or a store procedure name
        /// </summary>
        /// <param name="commandText">The command text</param>
        void SetCommandText(string commandText);

        /// <summary>
        /// Set the command text which want to execute.
        /// The command text can be a query statement or a store procedure name
        /// </summary>
        /// <param name="commandText">The command text</param>
        /// <param name="commandType">The command type which want to execute</param>
        void SetCommandText(string commandText, CommandType commandType);

        /// <summary>
        /// Add a paremeter infomation to the data execution context.
        /// It will be parses to DbParameter of executing command.
        /// </summary>
        /// <param name="parameterName">The parameter name</param>
        /// <param name="parameterValue">The parameter value</param>
        /// <remarks>The parameter direction is input direction by default</remarks>
        void AddParameter(string parameterName, object parameterValue);

        /// <summary>
        /// Add a paremeter infomation to the data execution context.
        /// It will be parses to DbParameter of executing command.
        /// </summary>
        /// <param name="parameterName">The parameter name</param>
        /// <param name="parameterValue">The parameter value</param>
        /// <param name="direction">The parameter direction</param>
        void AddParameter(string parameterName, object parameterValue, ParameterDirection direction);

        /// <summary>
        /// Add a paremeter infomation to the data execution context.
        /// It will be parses to DbParameter of executing command.
        /// </summary>
        /// <param name="parameterValue">The parameter value</param>
        /// <returns>The parameter name which is generated continously</returns>
        /// <remarks>The parameter direction is input direction by default</remarks>
        string AddParameterAndGetHolderString(object parameterValue);

        /// <summary>
        /// Add a paremeter infomation to the data execution context.
        /// It will be parses to DbParameter of executing command.
        /// </summary>
        /// <param name="parameterValue">The parameter value</param>
        /// <param name="direction">The parameter direction</param>
        /// <returns>The parameter name which is generated continously</returns>
        string AddParameterAndGetHolderString(object parameterValue, ParameterDirection direction);

        #endregion

        #region Context Execution Methods
        /// <summary>
        /// Execute the command and return a IDataReader
        /// </summary>
        /// <returns>The running IDataReader object</returns>
        IDataReader RunReader();

        /// <summary>
        /// Execute the command and return a IDataReader using one of the CommandBehavior value
        /// </summary>
        /// <param name="readBehavior">The command behavior value</param>
        /// <returns>The running IDataReader object</returns>
        IDataReader RunReader(CommandBehavior readBehavior);

        /// <summary>
        /// Execute the command and return the number of the affected records
        /// </summary>
        /// <returns>The number of the affected records</returns>
        int RunNonQuery();

        /// <summary>
        /// Execute the command and return a scalar value
        /// </summary>
        /// <returns></returns>
        object RunScalar();

        /// <summary>
        /// Execute the command and return a DataSet which holds returned record set.
        /// </summary>
        /// <returns></returns>
        DataSet RunDataSet();

        #endregion

        #region Retrieve Execution Output Value Methods
        /// <summary>
        /// Get integer output value after the command executed
        /// </summary>
        /// <param name="parameterName">The output parameter name</param>
        /// <returns>The integer output value</returns>
        int GetParameterOutPutIntegerValue(string parameterName);

        /// <summary>
        /// Get string output value after the command executed
        /// </summary>
        /// <param name="parameterName">The output parameter name</param>
        /// <returns>The string output value</returns>
        string GetParameterOutPutStringValue(string parameterName);

        /// <summary>
        /// Get boolean output value after the command executed
        /// </summary>
        /// <param name="parameterName">The output parameter name</param>
        /// <returns>The boolean output value</returns>
        bool GetParameterOutPutBooleanValue(string parameterName);

        /// <summary>
        /// Get output DateTime value after the command executed
        /// </summary>
        /// <param name="parameterName">The output parameter name</param>
        /// <returns>The output DateTime value</returns>
        DateTime GetParameterOutPutDateTimeValue(string parameterName);

        /// <summary>
        /// Get output Double value after the command executed
        /// </summary>
        /// <param name="parameterName">The output parameter name</param>
        /// <returns>The output Double value</returns>
        double GetParameterOutPutDoubleValue(string parameterName);

        #endregion

        #region Transaction Methods

        /// <summary>
        /// With the specified transaction, rollback the current transaction in the context.
        /// </summary>
        void Rollback();

        /// <summary>
        /// With the specified transaction, commit the current transaction in the context.
        /// </summary>
        void Commit();

        #endregion

        #region Renew Context Methods

        /// <summary>
        /// Clear the context.
        /// </summary>
        void Clear();

        #endregion
    }
}
