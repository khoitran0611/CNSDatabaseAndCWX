using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;

namespace CWX.Core.Common.Data.Query
{
    public abstract class SelectQueryBuilderBase : QueryBuilderBase
    {
        #region Constructors

        public SelectQueryBuilderBase(string tableName)
        {
            _tableName = tableName;
            _columns = new Collection<string>();
            _orderBys = new Dictionary<string, OrderByDirection>();
        }

        public SelectQueryBuilderBase(string tableName, DataProviderBase dataProvider)
            : this(tableName)
        {
            DataProvider = dataProvider;
        }

        #endregion

        #region Protected Properties

        private string _tableName;
        protected string TableName
        {
            get
            {
                return _tableName;
            }
        }

        private string _whereClause;
        protected string WhereClause
        {
            get
            {
                return _whereClause;
            }
        }

        private string _orderByClause;
        protected string OrderByClause
        {
            get
            {
                return _orderByClause;
            }
        }

        private Collection<string> _columns;
        protected Collection<string> Columns
        {
            get
            {
                return _columns;
            }
        }

        private Dictionary<string, OrderByDirection> _orderBys;
        protected Dictionary<string, OrderByDirection> OrderBys
        {
            get
            {
                return _orderBys;
            }
        }
        #endregion

        /// <summary>
        /// Add an order by column to the command text. The order by will be 'ORDER BY ColumnName Direction'
        /// </summary>
        /// <param name="columnName">The order by column's name.</param>
        /// <param name="direction">The order by direction.</param>
        /// <returns>SelectQueryBuilderBase after adding order by column.</returns>
        public SelectQueryBuilderBase AddOrderBy(string columnName, OrderByDirection direction)
        {
            if (!string.IsNullOrEmpty(columnName))
                _orderBys.Add(columnName, direction);
            return this;
        }

        /// <summary>
        /// Add column (will be selected) to the command text.
        /// </summary>
        /// <param name="columnName">The name of column that will be selected.</param>
        /// <returns>SelectQueryBuilderBase after adding select column.</returns>
        public SelectQueryBuilderBase AddSelectColumn(string columnName)
        {
            if (!string.IsNullOrEmpty(columnName))
                _columns.Add(columnName);
            return this;
        }

        /// <summary>
        /// Append where clause to the command text.
        /// </summary>
        /// <param name="whereClause">The where clause will be appended. Note: whereClause must not contain 'WHERE'.</param>
        /// <returns>SelectQueryBuilderBase after appending where clause.</returns>
        public SelectQueryBuilderBase AppendWhereClause(string whereClause)
        {
            _whereClause = whereClause;
            return this;
        }

        /// <summary>
        /// Append order by clause to the command text.
        /// </summary>
        /// <param name="orderByClause">The order by clause will be appended. Note: orderByClause must not contain 'ORDER BY'.</param>
        /// <returns>SelectQueryBuilderBase after appending where clause.</returns>
        public SelectQueryBuilderBase AppendOrderByClause(string orderByClause)
        {
            _orderByClause = orderByClause;
            return this;
        }
    }
}
