using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace CWX.Core.Common.Data.Query
{
    public abstract class FillListQueryBuilder : SelectQueryBuilderBase
    {
        #region Constructors
        public FillListQueryBuilder(string tableName)
            : base(tableName)
        {
            _params = new Collection<ParameterInfo>();
            _pageSize = 0;
            _pageIndex = 0;
            _rowCountParameterName = string.Empty;
        }

        public FillListQueryBuilder(string tableName, DataProviderBase dataProvider)
            : this(tableName)
        {
            DataProvider = dataProvider;
        }

        #endregion

        #region Properties
        private Collection<ParameterInfo> _params;
        protected Collection<ParameterInfo> Parameters
        {
            get { return _params; }
            set { _params = value; }
        }

        private int _pageSize;
        /// <summary>
        /// The maximum number of return records. If the value is zero, returns all records.
        /// </summary>
        public int PageSize
        {
            get { return _pageSize; }
            set { _pageSize = value; }
        }

        private int _pageIndex;
        /// <summary>
        /// The index of paging list.
        /// </summary>
        public int PageIndex
        {
            get { return _pageIndex; }
            set { _pageIndex = value; }
        }

        private string _rowCountParameterName;
        public string RowCountParameterName
        {
            get { return _rowCountParameterName; }
            set { _rowCountParameterName = value; }
        }
	
	
        #endregion

        #region Public Methods
        public FillListQueryBuilder AddParameter(string parameterName, ParameterDirection direction, string dbType)
        {
            ValidateParameter(parameterName, direction);

            ParameterInfo param = new ParameterInfo();
            param.ParameterName = parameterName;
            param.Direction = direction;
            param.DbType = dbType;

            _params.Add(param);

            return this;
        }

        public FillListQueryBuilder AddParameter(string parameterName, ParameterDirection direction, string dbType, int length)
        {
            ValidateParameter(parameterName, direction);

            ParameterInfo param = new ParameterInfo();
            param.ParameterName = parameterName;
            param.Direction = direction;
            param.DbType = dbType;
            param.Length = length;

            _params.Add(param);

            return this;
        }

        public FillListQueryBuilder AddParameter(string parameterName, ParameterDirection direction, string dbType, int precision, int scale)
        {
            ValidateParameter(parameterName, direction);

            ParameterInfo param = new ParameterInfo();
            param.ParameterName = parameterName;
            param.Direction = direction;
            param.DbType = dbType;
            param.Precision = precision;
            param.Scale = scale;

            _params.Add(param);

            return this;
        }
        #endregion

        #region Utility Method
        private void ValidateParameter(string parameterName, ParameterDirection direction)
        {
            if (string.IsNullOrEmpty(parameterName))
                throw new ArgumentNullException("ParameterName cannot be empty");
            if (direction == ParameterDirection.ReturnValue || direction == ParameterDirection.InputOutput)
                throw new ArgumentOutOfRangeException("Not support Return and InputOutput parameter direction");
        }
        #endregion

        #region Internal Info Class
        protected class ParameterInfo
        {
            private string _paramName;
            public string ParameterName
            {
                get { return _paramName; }
                set { _paramName = value; }
            }

            private ParameterDirection _direction;
            public ParameterDirection Direction
            {
                get { return _direction; }
                set { _direction = value; }
            }
	

            private string _dbType;
            public string DbType
            {
                get { return _dbType; }
                set { _dbType = value; }
            }

            private int _length;
            public int Length
            {
                get { return _length; }
                set { _length = value; }
            }

            private int _precision;
            public int Precision
            {
                get { return _precision; }
                set { _precision = value; }
            }

            private int _scale;
            public int Scale
            {
                get { return _scale; }
                set { _scale = value; }
            }

            private object _value;
            public object Value
            {
                get { return _value; }
                set { _value = value; }
            }
        }
        #endregion
    }
}
