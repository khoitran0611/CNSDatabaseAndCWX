using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Data.Query
{
    public abstract class UpdateQueryBuilderBase : QueryBuilderBase
    {
        #region Constructors

        public UpdateQueryBuilderBase(string tableName)
        {
            _tableName = tableName;
            _columns = new Dictionary<string, object>();
            _identities = new Dictionary<string, object>();
        }

        public UpdateQueryBuilderBase(string tableName, DataProviderBase provider)
            : this(tableName)
        {
            DataProvider = provider;
        }

        #endregion

        #region Protected Properties

        private string _tableName;
        protected string TableName
        {
            get
            {
                return _tableName;
            }
        }

        private string _whereClause;
        protected string WhereClause
        {
            get
            {
                return _whereClause;
            }
        }

        private Dictionary<string, object> _columns;
        protected Dictionary<string, object> Columns
        {
            get
            {
                return _columns;
            }
        }

        private Dictionary<string, object> _identities;
        protected Dictionary<string, object> Identities
        {
            get
            {
                return _identities;
            }
        }
        #endregion

        /// <summary>
        /// Add column (will be updated value) to the command text.
        /// </summary>
        /// <param name="columnName">The name of column that will be updated.</param>
        /// <param name="columnValue">The new value of column that will be updated.</param>
        /// <returns>UpdateQueryBuilder after adding column.</returns>
        public UpdateQueryBuilderBase AddUpdateColumn(string columnName, object columnValue)
        {
            if (!string.IsNullOrEmpty(columnName))
                _columns.Add(columnName, columnValue);
            return this;
        }

        /// <summary>
        /// Add selected object's identity to the where clause of the command text. The where clause will be like 'where ObjectID = value'
        /// </summary>
        /// <param name="identityName">The name of object's identity.</param>
        /// <param name="identityValue">The value of object's identity.</param>
        /// <returns>UpdateQueryBuilder after adding identity.</returns>
        public UpdateQueryBuilderBase AddIdentity(string identityName, object identityValue)
        {
            if (!string.IsNullOrEmpty(identityName))
                _identities.Add(identityName, identityValue);
            return this;
        }

        /// <summary>
        /// Append where clause to the command text.
        /// </summary>
        /// <param name="whereClause">The where clause will be appended. Note: whereClause must not contain 'WHERE'.</param>
        /// <returns>DeleteQueryBuilder after appending where clause.</returns>
        public UpdateQueryBuilderBase AppendWhereClause(string whereClause)
        {
            _whereClause = whereClause;
            return this;
        }
    }
}
