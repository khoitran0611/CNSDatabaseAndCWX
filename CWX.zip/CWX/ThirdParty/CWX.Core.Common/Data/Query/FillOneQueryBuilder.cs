using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Data.Query
{
    public abstract class FillOneQueryBuilder : SelectQueryBuilderBase
    {
        #region Constructors
        public FillOneQueryBuilder(string tableName)
            : base(tableName)
        {
            _identities = new Dictionary<string, object>();
        }

        public FillOneQueryBuilder(string tableName, DataProviderBase dataProvider)
            : this(tableName)
        {
            DataProvider = dataProvider;
        }

        #endregion

        #region Properties
        private Dictionary<string, object> _identities;
        protected Dictionary<string, object> Identities
        {
            get
            {
                return _identities;
            }
        }
        #endregion

        #region Public Method
        /// <summary>
        /// Add selected object's identity to the where clause of the command text. The where clause will be like 'where ObjectID = value'
        /// </summary>
        /// <param name="identityName">The name of object's identity.</param>
        /// <param name="identityValue">The value of object's identity.</param>
        /// <returns>SelectQueryBuilderBase after adding identity.</returns>
        public FillOneQueryBuilder AddIdentity(string identityName, object identityValue)
        {
            if (!string.IsNullOrEmpty(identityName))
                _identities.Add(identityName, identityValue);
            return this;
        }
        #endregion
    }
}
