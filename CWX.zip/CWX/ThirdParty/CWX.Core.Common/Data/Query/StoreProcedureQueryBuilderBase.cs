using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Data.Query
{
    public abstract class StoreProcedureQueryBuilderBase : QueryBuilderBase
    {
        #region Constructors

        public StoreProcedureQueryBuilderBase(string storeProcedureName)
        {
            _storeProcedureName = storeProcedureName;
            _parameters = new Dictionary<string, object>();
        }
        public StoreProcedureQueryBuilderBase(string storeProcedureName, DataProviderBase provider)
            : this(storeProcedureName)
        {
            DataProvider = provider;
        }

        #endregion

        #region Protected Properties

        private Dictionary<string, object> _parameters;
        protected Dictionary<string, object> Parameters
        {
            get
            {
                return _parameters;
            }
        }

        private string _returnParameterName;
        protected string ReturnParameterName
        {
            get
            {
                return _returnParameterName;
            }
        }

        private string _storeProcedureName;
        protected string StoreProcedureName
        {
            get
            {
                return _storeProcedureName;
            }
        }

        #endregion

        /// <summary>
        /// Add parameter to the command.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <param name="parameterValue">parameter value</param>
        /// <returns>StoreProcedureQueryBuilderBase</returns>
        public StoreProcedureQueryBuilderBase AddParameter(string parameterName, object parameterValue)
        {
            _parameters.Add(parameterName, parameterValue);
            return this;
        }

        /// <summary>
        /// Add an return parameter to the command.
        /// </summary>
        /// <param name="returnParameterName">Return Parameter Name</param>
        /// <returns>StoreProcedureQueryBuilderBase</returns>
        public StoreProcedureQueryBuilderBase AppendReturnParameter(string returnParameterName)
        {
            _returnParameterName = returnParameterName;
            return this;
        }
    }
}
