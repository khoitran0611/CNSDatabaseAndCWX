using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Data.Query
{
    public abstract class InsertQueryBuilderBase : QueryBuilderBase
    {
        #region Constructors

        public InsertQueryBuilderBase(string tableName)
        {
            _tableName = tableName;
            _columns = new Dictionary<string, object>();
        }

        public InsertQueryBuilderBase(string tableName, DataProviderBase provider)
            : this(tableName)
        {
            DataProvider = provider;
        }

        #endregion

        #region Protected Properties
        private string _tableName;
        protected string TableName
        {
            get
            {
                return _tableName;
            }
        }

        private Dictionary<string, object> _columns;
        protected Dictionary<string, object> Columns
        {
            get
            {
                return _columns;
            }
        }

        private bool _returnIdentity;
        public bool ReturnIdentity
        {
            get { return _returnIdentity; }
            set { _returnIdentity = value; }
        }


        #endregion

        #region Public Methods
        /// <summary>
        /// Add column (will be inserted value) to the command text.
        /// </summary>
        /// <param name="columnName">The name of column that will be inserted.</param>
        /// <param name="columnValue">The value of column that will be inserted.</param>
        /// <returns>InsertQueryBuilder after inserting column.</returns>
        public InsertQueryBuilderBase AddInsertColumn(string columnName, object columnValue)
        {
            if (!string.IsNullOrEmpty(columnName))
                _columns.Add(columnName, columnValue);
            return this;
        }
        #endregion
    }
}
