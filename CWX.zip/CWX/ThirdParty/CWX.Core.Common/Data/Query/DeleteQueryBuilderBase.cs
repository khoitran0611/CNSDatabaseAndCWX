using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;

namespace CWX.Core.Common.Data.Query
{
    public abstract class DeleteQueryBuilderBase : QueryBuilderBase
    {
        #region Constructors
        public DeleteQueryBuilderBase(string tableName)
        {
            _tableName = tableName;
            _identities = new Dictionary<string, object>();
        }
        public DeleteQueryBuilderBase(string tableName, DataProviderBase provider)
            : this(tableName)
        {
            DataProvider = provider;
        }

        #endregion

        #region Protected Properties
        private string _tableName;
        protected string TableName
        {
            get
            {
                return _tableName;
            }
        }

        private string _whereClause;
        protected string WhereClause
        {
            get
            {
                return _whereClause;
            }
        }

        private Dictionary<string, object> _identities;
        protected Dictionary<string, object> Identities
        {
            get
            {
                return _identities;
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Add selected object's identity to the where clause of the command text. The where clause will be like 'where ObjectID = value'
        /// </summary>
        /// <param name="identityName">The name of object's identity.</param>
        /// <param name="identityValue">The value of object's identity.</param>
        /// <returns>DeleteQueryBuilder after adding identity.</returns>
        public DeleteQueryBuilderBase AddIdentity(string identityName, object identityValue)
        {
            if (!string.IsNullOrEmpty(identityName))
                _identities.Add(identityName, identityValue);
            return this;
        }

        /// <summary>
        /// Append where clause to the command text.
        /// </summary>
        /// <param name="whereClause">The where clause will be appended. Note: whereClause must not contain 'WHERE'.</param>
        /// <returns>DeleteQueryBuilder after appending where clause.</returns>
        public DeleteQueryBuilderBase AppendWhereClause(string whereClause)
        {
            _whereClause = whereClause;
            return this;
        }
        #endregion
    }
}
