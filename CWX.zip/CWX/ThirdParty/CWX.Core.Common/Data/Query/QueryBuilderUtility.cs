using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Data.Query
{
    public static class QueryBuilderUtility
    {
        static QueryBuilderUtility()
        { }

        public static string BuildFormatString(ICollection<string> collection, string stringFormat, string splitter)
        {
            if (collection == null || collection.Count <= 0 || string.IsNullOrEmpty(stringFormat))
                return string.Empty;

            StringBuilder sb = new StringBuilder();
            bool isFirst = true;

            foreach (string item in collection)
            {
                if (isFirst)
                {
                    sb.Append(string.Format(stringFormat, item));

                    isFirst = false;
                }
                else
                {
                    sb.Append(" " + splitter + " " + string.Format(stringFormat, item));
                }
            }

            return sb.ToString();
        }
    }
}
