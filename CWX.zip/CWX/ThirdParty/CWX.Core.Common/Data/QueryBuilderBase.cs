using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace CWX.Core.Common.Data
{
    public abstract class QueryBuilderBase : IQueryBuilder
    {
        private DataProviderBase _dataProvider;
        public DataProviderBase DataProvider
        {
            get { return _dataProvider; }
            set { _dataProvider = value; }
        }

        #region IQueryBuilder Members

        public abstract DbCommand BuildCommand();

        #endregion
    }
}
