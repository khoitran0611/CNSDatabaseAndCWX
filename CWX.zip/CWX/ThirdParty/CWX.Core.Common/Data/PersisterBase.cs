using System;
using System.Data;
using System.Data.Common;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Web;
using System.Configuration;
using System.Web.Caching;

using CWX.Core.Common.Data;
using CWX.Core.Common.Configuration;

namespace CWX.Core.Common.Data
{
    public class PersisterBase<TDomainObject> 
        where TDomainObject : class, new()
    {
        #region Properties

        private IDataProvider _dataProvider;
        protected IDataProvider DataProvider
        {
            get
            {
                return _dataProvider;
            }
        }

        #endregion

        #region Constructor
        public PersisterBase()
        {
            _dataProvider = new DataProviderFactory().Create();
        }

        public PersisterBase(string databaseName)
        {
            _dataProvider = new DataProviderFactory().Create(databaseName);
        }

        public PersisterBase(IDataProvider dataProvider)
        {
            _dataProvider = dataProvider;
        }
        #endregion

        #region Public Methods

        #region CRUD Action Methods

        /// <summary>
        /// Add a domain object to the datasource.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to add to the datasource.</param>
        /// <returns>true if adding domain object successfully; otherwise, false. </returns>
        public virtual bool Add(TDomainObject domainObject)
        {
            ClearFillListCache();
            return _dataProvider.Insert<TDomainObject>(domainObject);
        }

        /// <summary>
        /// Add a domain object to the datasource. Then output newID.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to add to the datasource.</param>
        /// <returns>true if adding domain object successfully; otherwise, false. </returns>
        public virtual bool Add(TDomainObject domainObject, out int newID)
        {
            ClearFillListCache();
            return _dataProvider.Insert<TDomainObject>(domainObject, out newID);
        }

		/// <summary>
		/// Convert multiple rows in DataTable to objects and insert all records to database which return true if inserts successfully, 
		/// otherwise returns false
		/// </summary>
		/// <typeparam name="TDomainObject">The type of domain object.</typeparam>
		/// <param name="domainObject">An instant of DataTable object.</param>
		/// <returns>Returns true if inserts successfully, otherwise returns false.</returns>
		public virtual bool Add(DataTable dataTable)
		{
			ClearFillListCache();
			return _dataProvider.Insert<TDomainObject>(dataTable);
		}

        /// <summary>
        /// Remove a domain object from the datasource.
        /// </summary>
        /// <typeparam name="TIdentity">Type of domain object identity.</typeparam>
        /// <param name="identityValue">The identity for the domain object.</param>
        /// <returns>true if removing domain object successfully; otherwise, false.</returns>
        /// <remarks>TDomainObject must have only <b>one identity</b></remarks>
        public virtual bool Remove<TIdentity>(TIdentity identityValue)
        {
            ClearFillListCache();
            return _dataProvider.Delete<TDomainObject, TIdentity>(identityValue);
        }

        /// <summary>
        /// Remove a domain object from the datasource.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to remove from the datasource.</param>
        /// <returns>true if removing domain object successfully; otherwise, false.</returns>
        public virtual bool Remove(TDomainObject domainObject)
        {
            ClearFillListCache();
            return _dataProvider.Delete<TDomainObject>(domainObject);
        }

        /// <summary>
        /// Deletes a record with the given array of identity fields that have identity values 
        /// and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="identityFields">An array of identity fields.</param>
        /// <param name="identityValues">An array of identity values.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        public virtual bool Remove(string[] identityFields, object[] identityValues)
        {
            ClearFillListCache();
            return _dataProvider.Delete<TDomainObject>(identityFields, identityValues);
        }

        /// <summary>
        /// Marks a domain object as deleted.
        /// </summary>
        /// <typeparam name="TIdentity">Type of domain object identity.</typeparam>
        /// <param name="identityValue">The identity for the domain object.</param>
        /// <returns>true if removing domain object successfully; otherwise, false.</returns>
        /// <remarks>TDomainObject must have only <b>one identity</b></remarks>
        public virtual bool SoftDelete<TIdentity>(TIdentity identityValue)
        {
            ClearFillListCache();
            return _dataProvider.SoftDelete<TDomainObject, TIdentity>(identityValue);
        }

        /// <summary>
        /// Marks a domain object as deleted.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to remove from the datasource.</param>
        /// <returns>true if removing domain object successfully; otherwise, false.</returns>
        public virtual bool SoftDelete(TDomainObject domainObject)
        {
            ClearFillListCache();
            return _dataProvider.SoftDelete<TDomainObject>(domainObject);
        }

        /// <summary>
        /// Update a domain object in the datasource.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to update.</param>
        /// <returns>true if updating domain object successfully; otherwise, false. </returns>
        public virtual bool Update(TDomainObject domainObject)
        {
            return Update(domainObject, true);
        }

        /// <summary>
        /// Update a domain object in the datasource
        /// </summary>
        /// <param name="domainObject">A TDomainObject to update.</param>
        /// <param name="clearCache">true clear cache; otherwise, false.</param>
        /// <returns>true if updating domain object successfully; otherwise, false.</returns>
        public virtual bool Update(TDomainObject domainObject, bool clearCache)
        {
            if (clearCache)
                ClearFillListCache();
            return _dataProvider.Update<TDomainObject>(domainObject);
        }

        public virtual bool Update(DataTable dataTable)
        {
            ClearFillListCache();
            return _dataProvider.Update<TDomainObject>(dataTable);
        }

        /// <summary>
        /// Find a domain object from the datasource.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to find from the datasource.</param>
        /// <returns>A TDomainObject</returns>
        public virtual TDomainObject FindOne(TDomainObject domainObject)
        {
            return _dataProvider.Fill<TDomainObject>(domainObject);
        }

        /// <summary>
        /// Find a domain object from the datasource.
        /// </summary>
        /// <typeparam name="TIdentity">Type of domain object identity.</typeparam>
        /// <param name="identityValue">The identity for the domain object.</param>
        /// <returns>A TDomainObject</returns>
        /// <remarks>TDomainObject must have only <b>one identity</b></remarks>
        public virtual TDomainObject FindOne<TIdentity>(TIdentity identityValue)
        {
            return _dataProvider.Fill<TDomainObject, TIdentity>(identityValue);
        }

        /// <summary>
        /// Find a domain object from the datasource.
        /// </summary>
        /// <param name="identityFields">The identity's names for the domain object.</param>
        /// <param name="identityValues">The identity's values for the domain object.</param>
        /// <returns>A TDomainObject</returns>
        public virtual TDomainObject FindOne(string[] identityFields, object[] identityValues)
        {
            return _dataProvider.Fill<TDomainObject>(identityFields, identityValues);
        }

        /// <summary>
        /// Get a list of TDomainObject from the datasource.
        /// </summary>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;></returns>
        public virtual Collection<TDomainObject> FillList()
        {
            return _dataProvider.FillList<TDomainObject>();
        }

        /// <summary>
        /// Get a list of TDomainObject from the datasource.
        /// </summary>
        /// <param name="orderByClause">order by clause to sort the TDomainObject list</param>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;></returns>
        public virtual Collection<TDomainObject> FillList(string orderByClause)
        {
            return _dataProvider.FillList<TDomainObject>(orderByClause);
        }

        /// <summary>
        /// Get a list of TDomainObject from the datasource.
        /// </summary>
        /// <param name="orderByClause">order by clause to sort the TDomainObject list</param>
        /// <param name="whereClause">where clause to filter the TDomainObject list</param>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;</returns>
        public virtual Collection<TDomainObject> FillList(string orderByClause, string whereClause)
        {
            return _dataProvider.FillList<TDomainObject>(orderByClause, whereClause);
        }

        /// <summary>
        /// Get a list of TDomainObject from the application cache.
        /// If cached data does not exist, get list from database.
        /// </summary>
        /// <remarks>
        /// If AppSettings BusinessCacheTime does not exist in the config file, default cache time will be 10 mins.
        /// Cache key is generated from "FillList_[TDomainObject class name]_DBName".
        /// </remarks>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;></returns>
        /// <history>
        ///     08/07/01    [Binh Truong]   Init version.
        /// </history>
        public virtual Collection<TDomainObject> FillListFromCache()
        {
            string cacheKey = string.Format("FillList_{0}_{1}", (typeof(TDomainObject)).FullName, ConnectionManager.CWXDatabaseName);
            Collection<TDomainObject> result = HttpContext.Current.Cache[cacheKey] as Collection<TDomainObject>;
            if (result == null)
            {
                result = FillList();
                HttpContext.Current.Cache.Add(cacheKey, result, null, DateTime.MaxValue, TimeSpan.FromMinutes(10), CacheItemPriority.Normal, null);
            }
            return result;
        }

        /// <summary>
        /// Selects record(s) with the given storeprocedure then returns an collection of objects.
        /// </summary>
        /// <param name="orderByClause">storeprocedure name.</param>
        /// <returns>Returns a collection of objects.</returns>
        public virtual Collection<TDomainObject> FillListByStoreProcedure(string storeProcedure)
        {
            return _dataProvider.FillListByStoreProcedure<TDomainObject>(storeProcedure);
        }

        /// <summary>
        /// Selects record(s) with the given storeprocedure, parameterNames and parameterValues then returns an collection of objects.
        /// </summary>
        /// <param name="storeProcedure">storeprocedure name</param>
        /// <param name="parameterNames">parameter names</param>
        /// <param name="parameterValues">parameter values</param>
        /// <returns>Returns a collection of objects.</returns>
        public virtual Collection<TDomainObject> FillListByStoreProcedure(string storeProcedure, string[] parameterNames, object[] parameterValues)
        {
            return _dataProvider.FillListByStoreProcedure<TDomainObject>(storeProcedure, parameterNames, parameterValues);
        }

        /// <summary>
        /// Get a list of TDomainObject from the datasource with giving pageSize and pageIndex.
        /// </summary>
        /// <param name="pageSize">The size of the page of results to return.</param>
        /// <param name="pageIndex">The index of the page of results to return. pageIndex is zero-based.</param>
        /// <param name="orderByColumnName">orderByColumn</param>
        /// <param name="orderDirection">orderDirection</param>
        /// <param name="rowCount">The number of matched TDomainObjects</param>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;</returns>
        public virtual Collection<TDomainObject> FillPagingList(int pageSize, int pageIndex, string orderByColumnName, OrderByDirection orderDirection, out int rowCount)
        {
            return _dataProvider.FillPagingList<TDomainObject>(pageSize, pageIndex, orderByColumnName, orderDirection, out rowCount);
        }

        /// <summary>
        /// Selects record(s) with the given pageSize, pageIndex, orderByColumnName and orderDirection then returns an collection of objects
        /// and supplies the number of found records through output param rowCount.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="orderByClause">Expression of orderByClause including order direction. Ex: "[FieldName] ASC" or "[FieldName] DESC".</param>
        /// <param name="whereClause">Expression of whereClause. Ex: "[FieldName] = value" or "[FieldName] like '%value%'".</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        public virtual Collection<TDomainObject> FillPagingList(int pageSize, int pageIndex, string orderByClase, string whereClause, out int rowCount)
        {
            return _dataProvider.FillPagingList<TDomainObject>(pageSize, pageIndex, orderByClase, whereClause, out rowCount);
        }

        /// <summary>
        /// Selects record(s) with the given pageSize, pageIndex, orderByColumnName and orderDirection then returns an collection of objects
        /// and supplies the number of found records through output param rowCount.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="orderByColumnName">The name of the column that is used to order found records.</param>
        /// <param name="orderDirection">Type of orderDirection</param>
        /// <param name="whereClause">Expression of whereClause. Ex: "[FieldName] = value" or "[FieldName] like '%value%'".</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        public virtual Collection<TDomainObject> FillPagingList(int pageSize, int pageIndex, string orderByColumnName, OrderByDirection orderDirection, string whereClause, out int rowCount)
        {
            return _dataProvider.FillPagingList<TDomainObject>(pageSize, pageIndex, orderByColumnName, orderDirection, whereClause, out rowCount);
        }

        /// <summary>
        /// Get the max identity of the TDomainObject from the datasource.
        /// </summary>
        /// <returns>The max identity of the TDomainObject.</returns>
        public virtual int GetMaxIdentity()
        {
            return _dataProvider.GetMaxIdentity<TDomainObject>();
        }

        /// <summary>
        /// Get the max identity of the TDomainObject from the datasource.
        /// </summary>
        /// <typeparam name="TDomainObject"></typeparam>
        /// <param name="identityFieldName"></param>
        /// <returns>The max identity of the TDomainObject.</returns>
        public virtual int GetMaxIdentity(string identityFieldName)
        {
            return _dataProvider.GetMaxIdentity<TDomainObject>(identityFieldName);
        }

        /// <summary>
        /// Get the max identity of the TDomainObject from the datasource.
        /// </summary>
        /// <typeparam name="TDomainObject"></typeparam>
        /// <param name="identityFieldName"></param>
        /// <param name="whereClause"></param>
        /// <returns>The max identity of the TDomainObject.</returns>
        public virtual int GetMaxIdentity(string identityFieldName, string whereClause)
        {
            return _dataProvider.GetMaxIdentity<TDomainObject>(identityFieldName, whereClause);
        }

        #endregion

        #region Common Access Methods

        /// <summary>
        /// Excutes a store procedure with the give storedProcedureName
        /// and returns a System.Data.DataSet as the result.
        /// </summary>
        /// <param name="storedProcedureName">Name of the store procedure.</param>
        /// <returns>System.Data.DataSet</returns>
        public DataSet ExecuteDataSet(string storedProcedureName)
        {
            return _dataProvider.ExecuteDataSet(storedProcedureName);
        }

        /// <summary>
        /// Excutes a store procedure with the give storedProcedureName
        /// and returns a System.Data.DataSet as the result.
        /// </summary>
        /// <param name="storedProcedureName">Name of the store procedure.</param>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>System.Data.DataSet</returns>
        public DataSet ExecuteDataSet(string storedProcedureName, int pageSize, int pageIndex, out int rowCount)
        {
            return _dataProvider.ExecuteDataSet(storedProcedureName, pageSize, pageIndex, out rowCount);
        }

        /// <summary>
        /// Fills a DataSet.
        /// </summary>
        /// <param name="storedProcedureName">stored procedure to select data.</param>
        /// <param name="parameterNames">the names for the stored procedure parameters.</param>
        /// <param name="paremeterValues">the values for the stored procedure parameters.</param>
        /// <returns>A System.Data.DataSet</returns>
        public DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues)
        {
            return _dataProvider.ExecuteDataSet(storedProcedureName, parameterNames, paremeterValues);
        }

        /// <summary>
        /// Fills a DataSet.
        /// </summary>
        /// <param name="storedProcedureName">stored procedure to select data.</param>
        /// <param name="parameterNames">the names for the stored procedure parameters.</param>
        /// <param name="paremeterValues">the values for the stored procedure parameters.</param>
        /// <param name="pageSize">The size of the page of results to return.</param>
        /// <param name="pageIndex">The index of the page of results to return. pageIndex is zero-based.</param>
        /// <param name="rowCount">the number of matched records.</param>
        /// <returns>A System.Data.DataSet</returns>
        public DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues, int pageSize, int pageIndex, out int rowCount)
        {
            return _dataProvider.ExecuteDataSet(storedProcedureName, parameterNames, paremeterValues, pageSize, pageIndex, out rowCount);
        }

        /// <summary>
        /// Fills a DataSet.
        /// </summary>
        /// <param name="storedProcedureName">stored procedure to select data.</param>
        /// <param name="parameterNames">the names for the stored procedure parameters.</param>
        /// <param name="paremeterValues">the values for the stored procedure parameters.</param>
        /// <param name="orderByClause">Order by clause to sort the list. This parametter is required.</param>
        /// <param name="pageSize">The size of the page of results to return.</param>
        /// <param name="pageIndex">The index of the page of results to return. pageIndex is zero-based.</param>
        /// <param name="rowCount">the number of matched records.</param>
        /// <returns>A System.Data.DataSet</returns>
        public DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues, string orderByClause, int pageSize, int pageIndex, out int rowCount)
        {
            return _dataProvider.ExecuteDataSet(storedProcedureName, parameterNames, paremeterValues, orderByClause, pageSize, pageIndex, out rowCount);
        }

        /// <summary>
        /// Fills a DataSet
        /// </summary>
        /// <param name="commandText">The T-SQL statement</param>
        /// <returns></returns>
        public DataSet ExecuteDataSet(string commandText, CommandType commandType)
        {
            return _dataProvider.ExecuteDataSet(commandType, commandText);
        }

        /// <summary>
        ///     Executes the command and returns the number of rows affected.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <returns>The number of rows affected.</returns>
        public int ExecuteNonQuery(DbCommand command)
        {
            return _dataProvider.ExecuteNonQuery(command);
        }

        /// <summary>
        /// Executes a Transact-SQL statement against the connection and returns the number of rows affected.
        /// </summary>
        /// <param name="storedProcedureName">stored procedure to execute.</param>
        /// <param name="parameterNames">the names for the stored procedure parameters.</param>
        /// <param name="parameterValues">the values for the stored procedure parameters.</param>
        /// <returns>the number of rows affected.</returns>
        public int ExecuteNonQuery(string storedProcedureName, string[] parameterNames, object[] parameterValues)
        {
            return _dataProvider.ExecuteNonQuery(storedProcedureName, parameterNames, parameterValues);            
        }

        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="returnedValue">System.Int32</param>
        /// <returns>The number of rows affected.</returns>
        public int ExecuteNonQuery(string storedProcedureName, out int returnedValue)
        {
            return _dataProvider.ExecuteNonQuery(storedProcedureName, out returnedValue);
        }

        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="parameterNames">Array of parameter names.</param>
        /// <param name="parameterValues">Array of parameter values.</param>
        /// <param name="returnedValue">System.Int32</param>
        /// <returns></returns>
        public int ExecuteNonQuery(string storedProcedureName, string[] parameterNames, object[] parameterValues, out int returnedValue)
        {
            return _dataProvider.ExecuteNonQuery(storedProcedureName, parameterNames, parameterValues, out returnedValue);
        }

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType and
        ///     returns the number of rows affected.
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <returns>The number of rows affected.</returns>
        public int ExecuteNonQuery(string cmdText, CommandType cmdType)
        {
            return _dataProvider.ExecuteNonQuery(cmdText, cmdType);
        }

        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="parameters">>Array of parameter</param>
        /// <returns>System.Int32</returns>
        public  int ExecuteNonQuery(string storedProcedureName, Dictionary<string, object> parameters) 
        {
            return _dataProvider.ExecuteNonQuery(storedProcedureName, parameters);
        }



        /// <summary>
        /// Executes the storedProcedureName with the given parameterValues and returns
        /// the first column of the first row in the result set returned by the query.
        /// Extra columns or rows are ignored.
        /// </summary>
        /// <param name="paramValues">An array of paramters to pass to the stored procedure. The parameter values
        /// must be in call order as they appear in the stored procedure.</param>
        /// <param name="storedProcedureName">The stored procedure to execute.</param>
        /// <returns>The first column of the first row in the result set.</returns>
        public object ExecuteScalar(object[] paramValues, string storedProcedureName)
        {
            return _dataProvider.ExecuteScalar(paramValues, storedProcedureName);
        }

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType and
        ///     returns the first column of the first row in the result set returned by the
        ///    query. Extra columns or rows are ignored.
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <returns>The first column of the first row in the result set.</returns>
        public object ExecuteScalar(string cmdText, CommandType cmdType)
        {
            return _dataProvider.ExecuteScalar(cmdText, cmdType);
        }

        /// <summary>
        /// Execute the sql command and return IDataReader object
        /// </summary>
        /// <param name="sql">string to query data</param>
        /// <returns>The record set of query result.</returns>
        public IDataReader ExecuteReader(string sql)
        {
            return _dataProvider.ExecuteReader(sql, CommandType.Text);
        }

        /// <summary>
        /// Execute a store procedure with the given parameter names and values.
        /// </summary>
        /// <param name="storeProcedureName">The store procedure name which is wanted to run</param>
        /// <param name="paramNames">The parameter names</param>
        /// <param name="paramValues">The parameter values</param>
        /// <returns>A IDataReader</returns>
        public IDataReader ExecuteReader(string storeProcedureName, string[] paramNames, object[] paramValues)
        {
            if (paramNames == null && paramValues != null)
                throw new ArgumentNullException("paramNames");
            if (paramNames != null && paramValues == null)
                throw new ArgumentNullException("paramValues");
            if (paramNames.Length != paramValues.Length)
                throw new ArgumentOutOfRangeException("paramNames, paramValues", "Parameter names and values must have the same length");
            
            DbCommand cmd = _dataProvider.CreateCommand(CommandType.StoredProcedure);
            cmd.CommandText = storeProcedureName;
            for (int paramIndex = 0; (paramNames != null) && (paramIndex < paramNames.Length); paramIndex++)
            {
                DbParameter param = cmd.CreateParameter();
                param.ParameterName = _dataProvider.FormatParameterName(paramNames[paramIndex]);
                param.Value = paramValues[paramIndex];
                cmd.Parameters.Add(param);
            }

            return this.ExecuteReader(cmd);
        }

        /// <summary>
        /// Execute a command object.
        /// </summary>
        /// <param name="cmd">A input command object</param>
        /// <returns>The Record set of query result</returns>
        public IDataReader ExecuteReader(IDbCommand cmd)
        {
            return _dataProvider.ExecuteReader((DbCommand)cmd);
        }        

        #endregion

        /// <summary>
        /// Clear FillList cache.
        /// </summary>
        /// <history>
        /// 16/12/2008  Alvin Marable   Add HttpContext.Current validation.
        /// </history>
        public void ClearFillListCache()
        {
            if (HttpContext.Current != null)
            {
                string cacheKey = string.Format("FillList_{0}_{1}", (typeof(TDomainObject)).FullName, ConnectionManager.CWXDatabaseName);
                HttpContext.Current.Cache.Remove(cacheKey);
            }
        }

        #endregion
    }
}
