using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Collections.ObjectModel;
using System.Data;
using System.ComponentModel;
using System.Globalization;

namespace CWX.Core.Common.Data
{
    /// <summary>
    /// Represent the database execution context. It manages the connection, command and transaction
    /// inside a life-time context.
    /// </summary>
    public sealed class DataExecutionContext : IDataExecutionContext
    {
        #region Fields
        private bool _isInTransaction;
        private string _commandText;
        private int _parameterCounter = 0;
        private int _affectedRowCount = 0;

        private CommandType _commandType;
        private DbCommand _command;
        private DbTransaction _transaction;
        private IDataReader _reader;
        private Collection<ParameterInfo> _parameters;
        private DbConnection _connection;
        private IDataProvider _provider;
        private QueryBuilderBase _queryBuilder;
        #endregion

        #region Constructors
        internal DataExecutionContext(IDataProvider provider)
            : this(false, provider)
        { 
        }

        internal DataExecutionContext(bool isInTransaction, IDataProvider provider)
        {
            _isInTransaction = isInTransaction;
            _provider = provider;
        }

        internal DataExecutionContext(IDataProvider provider, QueryBuilderBase queryBuilder)
            : this(false, provider, queryBuilder)
        {
        }

        internal DataExecutionContext(bool isInTransaction, IDataProvider provider, QueryBuilderBase queryBuilder)
        {
            _isInTransaction = isInTransaction;
            _provider = provider;
            _queryBuilder = queryBuilder;
        }
        #endregion

        #region Properties
        /// <summary>
        /// The collection of ParameterInfo. It represents the information of DbParameter of a DbCommand.
        /// </summary>
        public Collection<ParameterInfo> ParameterInfos
        {
            get
            {
                if (_parameters == null)
                    _parameters = new Collection<ParameterInfo>();
                return _parameters;
            }
        }

        /// <summary>
        /// The affected records number after the execution.
        /// </summary>
        public int AffectedRowsCount
        {
            get
            {
                return _affectedRowCount;
            }
        }

        #endregion

        #region Context Setting Methods
        /// <summary>
        /// Set the command text which want to execute.
        /// The command text can be a query statement or a store procedure name
        /// </summary>
        /// <param name="commandText">The command text</param>
        public void SetCommandText(string commandText)
        {
            SetCommandText(commandText, CommandType.Text);
        }
        
        /// <summary>
        /// Set query builder which want to execute.
        /// </summary>
        public void SetQueryBuilder(QueryBuilderBase queryBuilder)
        {
            _queryBuilder = queryBuilder;
        }

        /// <summary>
        /// Set the command text which want to execute.
        /// The command text can be a query statement or a store procedure name
        /// </summary>
        /// <param name="commandText">The command text</param>
        /// <param name="commandType">The command type which want to execute</param>
        public void SetCommandText(string commandText, CommandType commandType)
        {
            _commandText = commandText;
            _commandType = commandType;
        }

        /// <summary>
        /// Add a paremeter infomation to the data execution context.
        /// It will be parses to DbParameter of executing command.
        /// </summary>
        /// <param name="parameterName">The parameter name</param>
        /// <param name="parameterValue">The parameter value</param>
        /// <remarks>The parameter direction is input direction by default</remarks>
        public void AddParameter(string parameterName, object parameterValue)
        {
            AddParameter(parameterName, parameterValue, ParameterDirection.Input);
        }

        /// <summary>
        /// Add a paremeter infomation to the data execution context.
        /// It will be parses to DbParameter of executing command.
        /// </summary>
        /// <param name="parameterName">The parameter name</param>
        /// <param name="parameterValue">The parameter value</param>
        /// <param name="direction">The parameter direction</param>
        public void AddParameter(string parameterName, object parameterValue, ParameterDirection direction)
        {
            ParameterInfo paramInfo = new ParameterInfo();
            paramInfo.ParameterName = FormatParameterName(parameterName);
            paramInfo.ParameterValue = parameterValue;
            paramInfo.Direction = direction;

            ParameterInfos.Add(paramInfo);
        }

        /// <summary>
        /// Add a paremeter infomation to the data execution context.
        /// It will be parses to DbParameter of executing command.
        /// </summary>
        /// <param name="parameterValue">The parameter value</param>
        /// <returns>The parameter name which is generated continously</returns>
        /// <remarks>The parameter direction is input direction by default</remarks>
        public string AddParameterAndGetHolderString(object parameterValue)
        {
            return AddParameterAndGetHolderString(parameterValue, ParameterDirection.Input);
        }

        /// <summary>
        /// Add a paremeter infomation to the data execution context.
        /// It will be parses to DbParameter of executing command.
        /// </summary>
        /// <param name="parameterValue">The parameter value</param>
        /// <param name="direction">The parameter direction</param>
        /// <returns>The parameter name which is generated continously</returns>
        public string AddParameterAndGetHolderString(object parameterValue, ParameterDirection direction)
        {
            string parameterName = FormatParameterName("P" + _parameterCounter.ToString());
            AddParameter(parameterName, parameterValue, direction);

            ++_parameterCounter;
            return parameterName;
        }

        #endregion

        #region Context Execution Methods
        /// <summary>
        /// Execute the command and return a IDataReader
        /// </summary>
        /// <returns>The running IDataReader object</returns>
        public IDataReader RunReader()
        {
            EnsureContextIsReady();

            DbDataReader reader = _command.ExecuteReader();
            _reader = reader;
            _affectedRowCount = reader.RecordsAffected;

            return reader;
        }

        /// <summary>
        /// Execute the command and return a IDataReader using one of the CommandBehavior value
        /// </summary>
        /// <param name="readBehavior">The command behavior value</param>
        /// <returns>The running IDataReader object</returns>
        public IDataReader RunReader(CommandBehavior readBehavior)
        {
            EnsureContextIsReady();
           
            DbDataReader reader = _command.ExecuteReader(readBehavior);
            _reader = reader;
            _affectedRowCount = reader.RecordsAffected;

            return reader;
        }

        /// <summary>
        /// Execute the command and return the number of the affected records
        /// </summary>
        /// <returns>The number of the affected records</returns>
        public int RunNonQuery()
        {
            EnsureContextIsReady();

            _affectedRowCount = _command.ExecuteNonQuery();

            return _affectedRowCount;
        }

        /// <summary>
        /// Execute the command and return a scalar value
        /// </summary>
        /// <returns></returns>
        public object RunScalar()
        {
            EnsureContextIsReady();
            _affectedRowCount = 1;
            return _command.ExecuteScalar();
        }

        /// <summary>
        /// Execute the command and return a DataSet which holds returned record set.
        /// </summary>
        /// <returns></returns>
        public DataSet RunDataSet()
        {
            EnsureContextIsReady();

            IDataAdapter dataAdapter = _provider.CreateDataAdapter(_command);
            DataSet dataSet = new DataSet();
            _affectedRowCount = dataAdapter.Fill(dataSet);

            return dataSet;
        }

        #endregion

        #region Retrieve Execution Output Value Methods
        /// <summary>
        /// Get integer output value after the command executed
        /// </summary>
        /// <param name="parameterName">The output parameter name</param>
        /// <returns>The integer output value</returns>
        public int GetParameterOutPutIntegerValue(string parameterName)
        {
            DbParameter outputParam = GetOutPutParameter(parameterName);

            return Convert.ToInt32(outputParam.Value, CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// Get string output value after the command executed
        /// </summary>
        /// <param name="parameterName">The output parameter name</param>
        /// <returns>The string output value</returns>
        public string GetParameterOutPutStringValue(string parameterName)
        {
            DbParameter outputParam = GetOutPutParameter(parameterName);

            return outputParam.Value.ToString();
        }

        /// <summary>
        /// Get boolean output value after the command executed
        /// </summary>
        /// <param name="parameterName">The output parameter name</param>
        /// <returns>The boolean output value</returns>
        public bool GetParameterOutPutBooleanValue(string parameterName)
        {
            DbParameter outputParam = GetOutPutParameter(parameterName);

            return Convert.ToBoolean(outputParam.Value, CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// Get output DateTime value after the command executed
        /// </summary>
        /// <param name="parameterName">The output parameter name</param>
        /// <returns>The output DateTime value</returns>
        public DateTime GetParameterOutPutDateTimeValue(string parameterName)
        {
            DbParameter outputParam = GetOutPutParameter(parameterName);

            return Convert.ToDateTime(outputParam.Value, CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// Get output Double value after the command executed
        /// </summary>
        /// <param name="parameterName">The output parameter name</param>
        /// <returns>The output Double value</returns>
        public double GetParameterOutPutDoubleValue(string parameterName)
        {
            DbParameter outputParam = GetOutPutParameter(parameterName);

            return Convert.ToDouble(outputParam.Value, CultureInfo.InvariantCulture);
        }
        #endregion

        #region Transaction Methods
        /// <summary>
        /// With the specified transaction, rollback the current transaction in the context.
        /// </summary>
        public void Rollback()
        {
            if (_isInTransaction == true && _transaction != null)
                _transaction.Rollback();
        }

        /// <summary>
        /// With the specified transaction, commit the current transaction in the context.
        /// </summary>
        public void Commit()
        {
            if (_isInTransaction == true && _transaction != null)
                _transaction.Commit();
        }
        #endregion

        #region Renew Context Methods
        /// <summary>
        /// Clear the context.
        /// </summary>
        public void Clear()
        {
            ParameterInfos.Clear();
            _parameterCounter = 0;
            _commandText = string.Empty;
            _commandType = CommandType.Text;
            _affectedRowCount = 0;
            if (_reader != null)
                _reader.Dispose();
            if (_command != null)
                _command.Dispose();
        }
        #endregion

        #region Private Utility Methods

        /// <summary>
        /// Prepare the context is ready for execution
        /// </summary>
        private void EnsureContextIsReady()
        {
            if (_reader != null)
                _reader.Dispose();
            if (_connection == null)
                _connection = _provider.CreateConnection();
            if (_connection != null && _connection.State != ConnectionState.Open && _connection.State != ConnectionState.Executing)
                _connection.Open();

            if (_isInTransaction == true && _transaction == null)
            {
                _transaction = _connection.BeginTransaction();
            }

            if (_queryBuilder != null)
            {
                _command = _provider.CreateCommand(_queryBuilder);
            }
            else
            {
                if (_commandType == CommandType.Text)
                    _command = _provider.CreateTextCommand(_commandText);
                else if (_commandType == CommandType.StoredProcedure)
                    _command = _provider.CreateStoreProcedureCommand(_commandText);
                else
                    _command = _provider.CreateCommand(_commandType);

                foreach (ParameterInfo paramInfo in ParameterInfos)
                {
                    DbParameter param = _command.CreateParameter();
                    param.ParameterName = paramInfo.ParameterName;
                    param.Value = paramInfo.ParameterValue;
                    param.Direction = paramInfo.Direction;

                    _command.Parameters.Add(param);
                }
            }
            _command.Connection = _connection;
            if (_isInTransaction)
                _command.Transaction = _transaction;
        }

        /// <summary>
        /// Get output DbParameter in the command
        /// </summary>
        /// <param name="parameterName">The output parameter</param>
        /// <returns>The DbParameter object</returns>
        private DbParameter GetOutPutParameter(string parameterName)
        {
            parameterName = FormatParameterName(parameterName); // Binh Truong: add format the parametter, so we don't need to add '@' prefix.
            if (string.IsNullOrEmpty(parameterName))
                throw new ArgumentNullException("parameterName");
            if (_command == null)
                throw new InvalidOperationException();
            if (_command.Parameters[parameterName] == null)
                throw new ArgumentException("Not existed parameter");
            DbParameter outputParam = _command.Parameters[FormatParameterName(parameterName)];
            if (outputParam.Direction == ParameterDirection.Input)
                throw new ArgumentException(string.Format("The parameter '{0}' is the input parameter", parameterName));
            return outputParam;
        }

        /// <summary>
        /// Ensure the parameter name must be prefixed by "@" character
        /// </summary>
        /// <param name="parameterName">The raw parameter name</param>
        /// <returns>The formatted parameter name</returns>
        private string FormatParameterName(string parameterName)
        {
            string formattedName = parameterName.Trim();
            if (formattedName[0] != '@')
                formattedName = "@" + formattedName;
            return formattedName;
        }
        #endregion

        #region IDisposable Members
        /// <summary>
        /// Dispose all resources which were used in the context.
        /// </summary>
        public void Dispose()
        {
            Clear();
            if (_transaction != null)
            {
                _transaction.Commit();
                _transaction.Dispose();
            }
            if (_connection != null)
            {
                _connection.Close();
                _connection.Dispose();
            }

            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
