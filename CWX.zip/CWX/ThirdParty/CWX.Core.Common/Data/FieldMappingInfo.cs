using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace CWX.Core.Common.Data
{
    public class FieldMappingInfo
    {
        private string _dbFieldName;

        public string DBFieldName
        {
            get { return _dbFieldName; }
            set { _dbFieldName = value; }
        }

        private string _dbType;
        public string DBType
        {
            get { return _dbType; }
            set { _dbType = value; }
        }

        private int _length;
        public int Length
        {
            get { return _length; }
            set { _length = value; }
        }

        private int _precision;
        public int Precision
        {
            get { return _precision; }
            set { _precision = value; }
        }

        private int _scale;
        public int Scale
        {
            get { return _scale; }
            set { _scale = value; }
        }

        private bool _isPrimaryKey;

        public bool IsPrimaryKey
        {
            get { return _isPrimaryKey; }
            set { _isPrimaryKey = value; }
        }

        private bool _automatedIncrease;
        /// <summary>
        /// Set true for auto increase number of identity field. Default is false.
        /// </summary>
        public bool AutomatedIncrease
        {
            get { return _automatedIncrease; }
            set { _automatedIncrease = value; }
        }
	

        private string _objectFieldName;

        public string ObjectFieldName
        {
            get { return _objectFieldName; }
            set { _objectFieldName = value; }
        }

        private bool _readOnly;

        public bool ReadOnly
        {
            get { return _readOnly; }
            set { _readOnly = value; }
        }

    }
}
