using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

using CWX.Core.Common.Configuration;

namespace CWX.Core.Common.Data
{
    public class DataProviderFactory : IDataProviderFactory
    {
        #region IDataProviderFactory Members
        public IDataProvider Create()
        {
            Type dataProviderType = GetDataProviderTypeFromConfiguration();
            return (IDataProvider)Activator.CreateInstance(dataProviderType);
        }

        public IDataProvider Create(string databaseName)
        {
            Type dataProviderType = GetDataProviderTypeFromConfiguration();
            return (IDataProvider)Activator.CreateInstance(dataProviderType, databaseName);
        }
        #endregion

        private Type GetDataProviderTypeFromConfiguration()
        {
            CWXConfigurationSection configurationSection = ConfigurationManager.GetSection("cwx") as CWXConfigurationSection;
            if (configurationSection == null)
                throw new Exception("The 'cwx' section does not exist.");
            return configurationSection.DataProvider.Type;
        }
    }
}
