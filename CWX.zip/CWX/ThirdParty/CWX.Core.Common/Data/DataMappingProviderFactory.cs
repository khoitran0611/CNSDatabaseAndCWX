using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

using CWX.Core.Common.Configuration;

namespace CWX.Core.Common.Data
{
    public class DataMappingProviderFactory : IDataMappingProviderFactory
    {
        #region IDataMappingProviderFactory Members

        /// <summary>
        /// Create an instance of IDataMappingProvider
        /// </summary>
        /// <returns>an instance of IDataMappingProvider</returns>
        public IDataMappingProvider Create()
        {
            CWXConfigurationSection configurationSection = ConfigurationManager.GetSection("cwx") as CWXConfigurationSection;
            if (configurationSection == null)
                throw new Exception("The 'cwx' section does not exist.");
            return (IDataMappingProvider)Activator.CreateInstance(configurationSection.DataMapping.Type);
        }

        #endregion
    }
}
