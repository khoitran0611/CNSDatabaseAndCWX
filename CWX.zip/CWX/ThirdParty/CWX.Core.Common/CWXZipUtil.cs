﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.SharpZipLib.Zip;
using System.IO;

namespace CWX.Core.Common
{
    public class CWXZipUtil
    {
        /// <summary>
        /// Extracts the specified zip file with its directory hierarchy and delete zip file after extracting
        /// </summary>
        /// <param name="filePath">Zip file to be extracted</param>
        /// <param name="extractFolderPath">New folder that the zip will be extracted into</param>
        public static List<string> Extract(string filePath, string extractFolderPath)
        {
            return Extract(filePath, extractFolderPath, true);
        }

        /// <summary>
        /// Extracts the specified zip file with its directory hierarchy
        /// </summary>
        /// <param name="filePath">Zip file to be extracted</param>
        /// <param name="extractFolderPath">New folder that the zip will be extracted into</param>
        /// <param name="deleteZip">Delete or keep the original zip after extracting</param>
        /// <returns>List of extracted files</returns>
        public static List<string> Extract(string filePath, string extractFolderPath, bool deleteZip)
        {
            List<string> extractedFiles = new List<string>();

            // Simple format check
            if (!filePath.ToLower().EndsWith("zip"))
            {
                throw new ZipException("Invalid file format.");
            }
            // Check for the existency
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException("Zip file does not exist.");
            }
            try
            {
                if (!Directory.Exists(extractFolderPath))
                {
                    Directory.CreateDirectory(extractFolderPath);
                }

                ZipInputStream zis = new ZipInputStream(File.OpenRead(filePath));
                ZipEntry ze = zis.GetNextEntry();
                while (ze != null)
                {
                    string directoryName = Path.GetDirectoryName(ze.Name);
                    string fileName = Path.GetFileName(ze.Name);

                    // Check for any folder existency in the zip folder
                    if (directoryName.Length > 0)
                    {
                        Directory.CreateDirectory(extractFolderPath);
                    }
                    if (!string.IsNullOrEmpty(fileName))
                    {
                        string entryFilePath = extractFolderPath + @"\" + ze.Name;
                        using (FileStream fs = File.Create(entryFilePath))
                        {
                            int i = 2048;
                            byte[] b = new byte[2048];

                            while (true)
                            {
                                i = zis.Read(b, 0, b.Length);
                                if (i > 0)
                                {
                                    fs.Write(b, 0, i);
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }
                        extractedFiles.Add(entryFilePath);
                    }
                    ze = zis.GetNextEntry();
                }
            }
            catch (ExecutionEngineException ex)
            {
                throw ex;
            }
            finally
            {
                // Delete the original zip file after extracting it
                if (deleteZip)
                {
                    File.Delete(filePath);
                }
            }
            return extractedFiles;
        }
    }
}
