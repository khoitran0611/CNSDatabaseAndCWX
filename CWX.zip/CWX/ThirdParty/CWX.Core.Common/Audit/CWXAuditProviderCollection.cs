using System;
using System.Configuration.Provider;

namespace CWX.Core.Common.Audit
{
    /// <summary>
    /// Represents a collection of provider objects that inherit from <see cref="ProviderCollection" />.
    /// </summary>
    public class CWXAuditProviderCollection : ProviderCollection
    {
        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("The provider parameter cannot be null.");

            if (!(provider is CWXAuditProvider))
                throw new ArgumentException("The provider parameter must be of type CWXAuditProvider.");

            base.Add(provider);
        }

        new public CWXAuditProvider this[string name]
        {
            get { return (CWXAuditProvider)base[name]; }
        }

        public void CopyTo(CWXAuditProvider[] array, int index)
        {
            base.CopyTo(array, index);
        }
    }
}
