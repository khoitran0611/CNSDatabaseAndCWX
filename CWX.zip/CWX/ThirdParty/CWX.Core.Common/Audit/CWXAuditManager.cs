using System;
using System.Configuration;
using System.Configuration.Provider;
using System.Web.Configuration;
using System.Data;
using CWX.Core.Common.DomainObject;
using CWX.Core.Common.Data;
using System.Collections.ObjectModel;


namespace CWX.Core.Common.Audit
{
    public class CWXAuditManager
    {
        //Initialization related variables and logic
        private static bool _isInitialized = false;
        private static Exception _initializationException;
        private static object _initializationLock;
                
        private static CWXAuditProvider _defaultProvider;
        private static CWXAuditProviderCollection _providerCollection;

        public static CWXAuditProvider Provider
        {
            get { return _defaultProvider; }
        }

        public static CWXAuditProviderCollection Providers
        {
            get { return _providerCollection; }
        }

        static CWXAuditManager()
        {
            _initializationLock = new object();
            Initialize();
        }

        private static void Initialize()
        {
            if (_isInitialized)
            {
                if (_initializationException != null)
                {
                    throw _initializationException;
                }
            }
            else
            {
                lock (_initializationLock)
                {
                    try
                    {
                        //Get the feature's configuration info
                        CWXAuditConfiguration auditConfiguration =
                            (CWXAuditConfiguration)ConfigurationManager.GetSection("system.web/CWXAuditManager");

                        if (auditConfiguration.DefaultProvider == null || auditConfiguration.Providers == null || auditConfiguration.Providers.Count < 1)
                        {
                            throw new ProviderException("You must specify a valid default provider.");
                        }

                        //Instantiate the providers
                        _providerCollection = new CWXAuditProviderCollection();
                        ProvidersHelper.InstantiateProviders(auditConfiguration.Providers, _providerCollection, typeof(CWXAuditProvider));
                        _providerCollection.SetReadOnly();
                        _defaultProvider = _providerCollection[auditConfiguration.DefaultProvider];
                        if (_defaultProvider == null)
                        {
                            throw new ConfigurationErrorsException(
                                "You must specify a default provider for the feature.",
                                auditConfiguration.ElementInformation.Properties["defaultProvider"].Source,
                                auditConfiguration.ElementInformation.Properties["defaultProvider"].LineNumber);
                        }
                    }
                    catch (Exception ex)
                    {
                        _initializationException = ex;
                        _isInitialized = true;
                        throw ex;
                    }

                    _isInitialized = true; 
                }
                if (_initializationException != null)
                {
                    throw _initializationException;
                }
            }
        }
        //Public feature API
        #region Audit-related Public Methods

        /// <summary>
        /// Search AuditTrail.
        /// </summary>
        /// <param name="fromDate">Get trail "From Date".</param>
        /// <param name="toDate">Get trail "To Date".</param>
        /// <param name="pageSize">Number record per page.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="totalRow">Total search result.</param>
        public static DataSet SearchTrail(Nullable<int> trailId, Nullable<int> employeeId, 
            Nullable<int> debtorId, Nullable<int> accountId, Nullable<int> actionId, string changeTable, 
            string changeField, Nullable<DateTime> fromDate, Nullable<DateTime> toDate, 
            int pageSize, int pageIndex, out int totalRow)
        {
            return Provider.SearchTrail(trailId, employeeId, actionId, changeTable, changeField,
                                        fromDate, toDate, pageSize, pageIndex, out totalRow);                                        
        }

        /// <summary>
        /// Get AuditTrail object.
        /// </summary>
        /// <param name="trailId">Trail ID.</param>
        public static CWXAuditTrail GetTrail(int trailId)
        {
            return Provider.GetTrail(trailId);
        }

        /// <summary>
        /// Add a trail to database.
        /// </summary>
        /// <param name="trail">Object CWXAuditTrail to add.</param>
        /// <returns>Successful state.</returns>
        public static bool AddTrail(CWXAuditTrail trail)
        {
            return Provider.AddTrail(trail);
        }

        /// <summary>
        /// Update a trail.
        /// </summary>
        /// <param name="trail">Trail to update.</param>
        /// <returns>Successful state.</returns>
        public static bool UpdateTrail(CWXAuditTrail trail)
        {
            return Provider.UpdateTrail(trail);
        }

        /// <summary>
        /// Delete a trail.
        /// </summary>
        /// <param name="trailId">Trail ID.</param>
        /// <returns>Successful state.</returns>
        public static bool DeleteTrail(int trailId)
        {
            return Provider.DeleteTrail(trailId);
        }

        /// <summary>
        /// Search AuditTable.
        /// </summary>
        /// <param name="id">Identity.</param>
        /// <param name="className">Auditing class name.</param>
        /// <param name="audited">Is auditing.</param>
        /// <param name="allowed">Is allow to audit.</param>
        public static DataSet SearchAuditTable(Nullable<int> id, string className, Nullable<bool> audited, Nullable<bool> allowed, int pageSize, int pageIndex, out int totalRow)
        {
            return Provider.SearchAuditTable(id, className, audited, pageSize, pageIndex, out totalRow);
        }

        /// <summary>
        /// Get AuditTable object.
        /// </summary>
        /// <param name="id">ID.</param>
        public static CWXAuditTable GetAuditTable(int id)
        {
            return Provider.GetAuditTable(id);
        }

        /// <summary>
        /// Get AuditTable object.
        /// </summary>
        /// <param name="className">Auditing class name.</param>
        public static CWXAuditTable GetAuditTable(string className)
        {
            return Provider.GetAuditTable(className);
        }

        /// <summary>
        /// Add class name to audit.
        /// </summary>
        /// <param name="auditTable">AuditTable object</param>
        public static bool AddAuditTable(CWXAuditTable auditTable)
        {
            return Provider.AddAuditTable(auditTable);
        }

        /// <summary>
        /// Update AuditTable.
        /// </summary>
        /// <param name="auditTable">AuditTable object to update.</param>
        public static bool UpdateAuditTable(CWXAuditTable auditTable)
        {
            return Provider.UpdateAuditTable(auditTable);
        }

        /// <summary>
        /// Audit domain object values.
        /// </summary>
        /// <param name="domainObject">domain object to audit.</param>
        /// <param name="action">Audit action.</param>
        /// <param name="tableInfo"><see cref="TableMappingInfo"/> which relate to this domain object.</param>
        /// <remarks>
        /// Should use AuditObject(IDomainObject domainObject, CWXAuditAction action, TableMappingInfo tableInfo) 
        /// if possible to increase performance.
        /// </remarks>
        public static void AuditObject(IDomainObject domainObject, CWXAuditAction action)
        {
            Provider.AuditObject(domainObject, action);
        }

        /// <summary>
        /// Audit domain object values.
        /// </summary>
        /// <param name="domainObject">domain object to audit.</param>
        /// <param name="action">Audit action.</param>
        /// <param name="tableInfo"><see cref="TableMappingInfo"/> which relate to this domain object.</param>
        public static void AuditObject(IDomainObject domainObject, CWXAuditAction action, TableMappingInfo tableInfo)
        {            
            Provider.AuditObject(domainObject, action, tableInfo);
        }

        /// <summary>
        /// Add a trail to database. 
        /// </summary>
        /// <param name="tableName">Determine the table name need to audit or not.</param>
        public static void AuditObject(CWXAuditTrail trail, string tableName)
        {
            Provider.AuditObject(trail, tableName);
        }

        /// <summary>
        /// Audit custom domain object values which has no table mapping info.
        /// </summary>
        /// <param name="domainObject">domain object to audit.</param>        
        /// <param name="tableInfo"><see cref="TableMappingInfo"/> which relate to this domain object.</param>
        /// <remarks>
        /// </remarks>
        public static void AuditEditCustomObject(IDomainObject domainObject, string auditObjectName)
        {
            Provider.AuditEditCustomObject(domainObject, auditObjectName);
        }

        public static void BeginAudit<TDomainObject, KType>(KType key, string[] propertyNames, CWXAuditAction action)
            where TDomainObject : class, new()
        {
            Provider.BeginAudit<TDomainObject, KType>(key, propertyNames, action);
        }

        public static void EndAudit<TDomainObject, KType>(KType key)
            where TDomainObject : class, new()
        {
            Provider.EndAudit<TDomainObject, KType>(key);
        }

        /// <summary>
        /// Audit trail on multiple rows
        /// </summary>
        /// <param name="propertyNames">Property names of TDomainObject which want to audit.</param>
        /// <param name="values">Changed valued of propertyNames parameter.</param>
        /// <param name="action">Change action.</param>
        /// <param name="whereClause">Where clause with search criteria to select data to audit.</param>
        /// <history>
        ///     2008/06/30  [Khoa Dang]     Init version.
        ///     2008/08/11  [Binh Truong]   Add parameter comments.
        /// </history>
        public static void WriteAudit<TDomainObject>(string[] propertyNames, object[] values, CWXAuditAction action, string whereClause)
            where TDomainObject : class, new()
        {
            Provider.WriteAudit<TDomainObject>(propertyNames, values, action, whereClause);
        }

        /// <summary>
        /// Audit trail on single row
        /// </summary>
        /// <param name="domainBusinessObject">Domain business object to audit.</param>
        /// <param name="propertyNames">Property names of domainBusinessObject which want to audit.</param>
        /// <param name="values">Changed valued of propertyNames parameter.</param>
        /// <param name="action">Change action.</param>
        /// <history>
        ///     2008/06/30  [Khoa Dang]     Init version.
        ///     2008/08/11  [Binh Truong]   Add parameter comments.
        /// </history>
        public static void WriteAudit(object domainBusinessObject, string[] propertyNames, object[] values, CWXAuditAction action)
        {
            Provider.WriteAudit(domainBusinessObject, propertyNames, values, action);
        }

        /// <summary>
        /// Audit Trail on single column and multiple rows.
        /// Purpose: it only used with SoftDelete data
        /// </summary>
        /// <param name="tableName">Changed table name.</param>
        /// <param name="primaryFieldName">Field which have primary key.</param>
        /// <param name="fieldName">Changed field name.</param>
        /// <param name="value">Changed data value of fieldName (parameter).</param>
        /// <param name="whereClause">Where clause with search criteria to select data to audit.</param>
        /// <history>
        ///     2008/06/30  [Khoa Dang]     Init version.
        ///     2008/08/11  [Binh Truong]   Add parameter comments.
        /// </history>
        public static void WriteAudit<TDomainObject>(string tableName, string primaryFieldName, string fieldName, string value, string whereClause)
            where TDomainObject : class, new()
        {
            Provider.WriteAudit<TDomainObject>(tableName, primaryFieldName, fieldName, value, whereClause);
        }

        public static DataSet GetList(int employeeID, string changeTable, DateTime? fromDate, DateTime? toDate, int actionID, string rowID, int pageSize, int pageIndex, out int rowCount)
        {
            return Provider.GetList(employeeID, changeTable, fromDate, toDate, actionID, rowID, pageSize, pageIndex, out rowCount);
        }

        public static Collection<string> GetChangeTableList()
        {
            return Provider.GetChangeTableList();
        }

		public static int GetLastAgencyStatusFromAuditTrail(int accountId, string dbConnectionName)
		{
			return Provider.GetLastAgencyStatusFromAuditTrail(accountId, dbConnectionName);
		}
        #endregion
    }
}
