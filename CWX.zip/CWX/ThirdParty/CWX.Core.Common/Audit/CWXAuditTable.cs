using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Audit
{
    /// <summary>
    /// Represents the auditable class
    /// </summary>
    public class CWXAuditTable
    {
        private int _id;
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        private string _className;
        public string ClassName
        {
            get { return _className; }
            set { _className = value; }
        }

        private string _description;
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        
        private bool _audited;
        public bool Audited
        {
            get { return _audited; }
            set { _audited = value; }
        }
    }
}
