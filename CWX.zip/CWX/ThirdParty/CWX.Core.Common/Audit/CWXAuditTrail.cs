using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Audit
{
    public class CWXAuditTrail
    {
        private int _trailID;
        public int TrailID
        {
            get { return _trailID; }
            set { _trailID = value; }
        }

        private int _employeeID;
        public int EmployeeID
        {
            get { return _employeeID; }
            set { _employeeID = value; }
        }

        private CWXAuditAction _action;
        public CWXAuditAction Action
        {
            get { return _action; }
            set { _action = value; }
        }

        private string _changedDatabase = string.Empty;
        public string ChangedDatabase
        {
            get { return _changedDatabase; }
            set { _changedDatabase = value; }
        }

        private string _changedTable = string.Empty;
        public string ChangedTable
        {
            get { return _changedTable; }
            set { _changedTable = value; }
        }

        private string _rowID = string.Empty;
        public string RowID
        {
            get { return _rowID; }
            set { _rowID = value; }
        }

        private string _changedField = string.Empty;
        public string ChangedField
        {
            get { return _changedField; }
            set { _changedField = value; }
        }

        private string _originalData = string.Empty;
        public string OriginalData
        {
            get { return _originalData; }
            set { _originalData = value; }
        }

        private string _changedData = string.Empty;
        public string ChangedData
        {
            get { return _changedData; }
            set { _changedData = value; }
        }

        private DateTime _auditDateTime;
        public DateTime AuditDateTime
        {
            get { return _auditDateTime; }
            set { _auditDateTime = value; }
        }
    }
}
