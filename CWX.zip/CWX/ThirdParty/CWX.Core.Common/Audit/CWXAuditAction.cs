using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Audit
{
    public enum CWXAuditAction
    {
        Add = 1,
        Edit = 2,
        Delete = 3
    }
}
