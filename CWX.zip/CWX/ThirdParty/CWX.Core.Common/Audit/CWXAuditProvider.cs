using System;
using System.Configuration.Provider;
using System.Data;

using CWX.Core.Common.DomainObject;
using CWX.Core.Common.Data;
using System.Collections.ObjectModel;

namespace CWX.Core.Common.Audit
{
    public abstract class CWXAuditProvider : ProviderBase
    {

        /// <summary>
        /// Search AuditTrail.
        /// </summary>
        /// <param name="fromDate">Get trail "From Date".</param>
        /// <param name="toDate">Get trail "To Date".</param>
        /// <param name="pageSize">Number record per page.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="totalRow">Total search result.</param>
        public abstract DataSet SearchTrail(Nullable<int> trailId, Nullable<int> employeeId, Nullable<int> actionId, string changeTable, string changeField, Nullable<DateTime> fromDate, Nullable<DateTime> toDate, int pageSize, int pageIndex, out int totalRow);

        /// <summary>
        /// Get AuditTrail object.
        /// </summary>
        /// <param name="trailId">Trail ID.</param>
        public abstract CWXAuditTrail GetTrail(int trailId);

        /// <summary>
        /// Add a trail to database.
        /// </summary>
        /// <param name="trail">Object CWXAuditTrail to add.</param>
        /// <returns>Successful state.</returns>
        public abstract bool AddTrail(CWXAuditTrail trail);

        /// <summary>
        /// Add a collection of trails to database
        /// </summary>
        /// <param name="trails">A collection of trails to add</param>
        /// <returns></returns>
        /// <history>
        ///     2008/09/08  [Long Nguyen]   Initialize.
        /// </history>
        public abstract bool AddTrail(Collection<CWXAuditTrail> trails);

        /// <summary>
        /// Update a trail.
        /// </summary>
        /// <param name="trail">Trail to update.</param>
        /// <returns>Successful state.</returns>
        public abstract bool UpdateTrail(CWXAuditTrail trail);

        /// <summary>
        /// Delete a trail.
        /// </summary>
        /// <param name="trailId">Trail ID.</param>
        /// <returns>Successful state.</returns>
        public abstract bool DeleteTrail(int trailId);

        /// <summary>
        /// Search AuditTable.
        /// </summary>
        /// <param name="id">Identity.</param>
        /// <param name="className">Auditing class name.</param>
        /// <param name="audited">Is auditing.</param>
        /// <param name="allowed">Is allow to audit.</param>
        public abstract DataSet SearchAuditTable(Nullable<int> id, string className, Nullable<bool> audited, int pageSize, int pageIndex, out int totalRow);

        /// <summary>
        /// Get AuditTable object.
        /// </summary>
        /// <param name="id">ID.</param>
        public abstract CWXAuditTable GetAuditTable(int id);

        /// <summary>
        /// Get AuditTable object.
        /// </summary>
        /// <param name="className">Auditing class name.</param>
        public abstract CWXAuditTable GetAuditTable(string className);

        /// <summary>
        /// Add class name to audit.
        /// </summary>
        /// <param name="auditTable">AuditTable object</param>
        public abstract bool AddAuditTable(CWXAuditTable auditTable);

        /// <summary>
        /// Update AuditTable.
        /// </summary>
        /// <param name="auditTable">AuditTable object to update.</param>
        public abstract bool UpdateAuditTable(CWXAuditTable auditTable);

        /// <summary>
        /// Audit domain object values.
        /// </summary>
        /// <param name="domainObject">domain object to audit.</param>
        /// <param name="action">Audit action.</param>
        /// <param name="tableInfo"><see cref="TableMappingInfo"/> which relate to this domain object.</param>
        public abstract void AuditObject(IDomainObject domainObject, CWXAuditAction action, TableMappingInfo tableInfo);

        /// <summary>
        /// Audit domain object values.
        /// </summary>
        /// <param name="domainObject">domain object to audit.</param>
        /// <param name="action">Audit action.</param>
        /// <param name="tableInfo"><see cref="TableMappingInfo"/> which relate to this domain object.</param>
        /// <remarks>
        /// Should use AuditObject(IDomainObject domainObject, CWXAuditAction action, TableMappingInfo tableInfo) 
        /// if possible to increase performance.
        /// </remarks>
        public abstract void AuditObject(IDomainObject domainObject, CWXAuditAction action);

        /// <summary>
        /// Add a trail to database. 
        /// </summary>
        /// <param name="tableName">Determine the table name need to audit or not.</param>
        public abstract void AuditObject(CWXAuditTrail trail, string tableName);

        /// <summary>
        /// Audit custom domain object values which has no table mapping info.
        /// </summary>
        /// <param name="domainObject">domain object to audit.</param>
        /// <param name="action">Audit action.</param>
        /// <param name="tableInfo"><see cref="TableMappingInfo"/> which relate to this domain object.</param>
        /// <remarks>
        /// </remarks>
        public abstract void AuditEditCustomObject(IDomainObject domainObject, string auditObjectName);

        public abstract void BeginAudit<TDomainObject, KType>(KType key, string[] propertyNames, CWXAuditAction action) where TDomainObject : class, new();
        public abstract void EndAudit<TDomainObject, KType>(KType key) where TDomainObject : class, new();
        public abstract void WriteAudit<TDomainObject>(string[] propertyNames, object[] values, CWXAuditAction action, string whereClause) where TDomainObject : class, new();
        public abstract void WriteAudit(object domainBusinessObject, string[] propertyNames, object[] values, CWXAuditAction action);
        public abstract void WriteAudit<TDomainObject>(string tableName, string primaryFieldName, string fieldName, string value, string whereClause) where TDomainObject : class, new();

        public abstract Collection<string> GetChangeTableList();

        public abstract DataSet GetList(int employeeID, string changeTable, DateTime? fromDate, DateTime? toDate, int actionID, string rowID, int pageSize, int pageIndex, out int rowCount);

		public abstract int GetLastAgencyStatusFromAuditTrail(int accountId, string dbConnectionName);
    }
}
