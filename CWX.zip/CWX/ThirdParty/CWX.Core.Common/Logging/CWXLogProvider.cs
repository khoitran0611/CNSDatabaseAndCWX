using System;
using System.Collections.Generic;
using System.Configuration.Provider;
using System.Diagnostics;

using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Logging;
using Microsoft.Practices.EnterpriseLibrary.Logging.Filters;
using Microsoft.Practices.EnterpriseLibrary.Logging.Configuration;

namespace CWX.Core.Common.Logging
{
    public abstract class CWXLogProvider: ProviderBase
    {
        public abstract string ApplicationName { get; set;}
        /// <summary>
        /// Gets the instance of Microsoft.Practices.EnterpriseLibrary.Logging.LogWriter
        ///     used by the facade.
        /// Remarks:
        ///     The lifetime of this instance is managed by the facade.
        /// </summary>
        public abstract LogWriter Writer { get; }
        /// <summary>
        /// Empty the context items dictionary.
        /// </summary>
        public abstract void FlushContextItems();
        /// <summary>
        /// Returns the filter named name.
        /// </summary>
        /// <param name="name">The name of the filter required.</param>
        /// <returns>The filter named name in the filters collection, or null if there is no such filter.</returns>
        public abstract ILogFilter GetFilter(string name);
        /// <summary>
        /// Query whether logging is enabled.
        /// </summary>
        /// <returns>true if logging is enabled.</returns>
        public abstract bool IsLoggingEnabled();
        /// <summary>
        /// Add a key/value pair to the System.Runtime.Remoting.Messaging.CallContext
        ///    dictionary. Context items will be recorded with every log entry.
        /// </summary>
        /// <param name="key">Hashtable key</param>
        /// <param name="value">Value. Objects will be serialized.</param>
        public abstract void SetContextItem(object key, object value);
        /// <summary>
        /// Query whether a Microsoft.Practices.EnterpriseLibrary.Logging.LogEntry shold be logged.
        /// </summary>
        /// <param name="log">The log entry to check</param>
        /// <returns>Returns true if the entry should be logged.</returns>
        public abstract bool ShouldLog(LogEntry log);
        /// <summary>
        /// Write a new log entry as defined in the Microsoft.Practices.EnterpriseLibrary.Logging.LogEntry
        ///    parameter.
        /// </summary>
        /// <param name="log">Log entry object to write.</param>
        public abstract void Write(LogEntry log);
        /// <summary>
        /// Write a new log entry to the default category.
        /// </summary>
        /// <param name="log">Message body to log. Value from ToString() method from message object.</param>
        public abstract void Write(object message);
        /// <summary>
        /// Write a new log entry to a specific collection of categories.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="categories">Category names used to route the log entry to a one or more trace listeners.</param>
        public abstract void Write(object message, ICollection<string> categories);
        /// <summary>
        /// Write a new log entry and a dictionary of extended properties.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="properties">Dictionary of key/value pairs to log.</param>
        public abstract void Write(object message, IDictionary<string, object> properties);
        /// <summary>
        /// Write a new log entry to a specific category.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="category">Category name used to route the log entry to a one or more trace listeners.</param>
        public abstract void Write(object message, string category);
        /// <summary>
        /// Write a new log entry to a specific collection of categories with a dictionary
        ///    of extended properties.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="categories">Category names used to route the log entry to a one or more trace listeners.</param>
        /// <param name="properties">Dictionary of key/value pairs to log.</param>
        public abstract void Write(object message, ICollection<string> categories, IDictionary<string, object> properties);
        /// <summary>
        /// Write a new log entry with a specific collection of categories and priority.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="categories">Category names used to route the log entry to a one or more trace listeners.</param>
        /// <param name="priority">Only messages must be above the minimum priority are processed.</param>
        public abstract void Write(object message, ICollection<string> categories, int priority);
        /// <summary>
        /// Write a new log entry to a specific category with a dictionary of extended
        ///     properties.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="category">Category name used to route the log entry to a one or more trace listeners.</param>
        /// <param name="properties">Dictionary of key/value pairs to log.</param>
        public abstract void Write(object message, string category, IDictionary<string, object> properties);
        /// <summary>
        /// Write a new log entry with a specific category and priority.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="category">Category name used to route the log entry to a one or more trace listeners.</param>
        /// <param name="priority">Only messages must be above the minimum priority are processed.</param>
        public abstract void Write(object message, string category, int priority);
        /// <summary>
        /// Write a new log entry to with a specific collection of categories, priority
        ///    and a dictionary of extended properties.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="categories">Category names used to route the log entry to a one or more trace listeners.</param>
        /// <param name="priority">Only messages must be above the minimum priority are processed.</param>
        /// <param name="properties">Dictionary of key/value pairs to log.</param>
        public abstract void Write(object message, ICollection<string> categories, int priority, IDictionary<string, object> properties);
        /// <summary>
        /// Write a new log entry with a specific collection of categories, priority
        ///    and event id.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="categories">Category name used to route the log entry to a one or more trace listeners.</param>
        /// <param name="priority">Only messages must be above the minimum priority are processed.</param>
        /// <param name="eventId">Event number or identifier.</param>
        public abstract void Write(object message, ICollection<string> categories, int priority, int eventId);
        /// <summary>
        /// Write a new log entry to with a specific category, priority and a dictionary
        ///    of extended properties.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="category">Category name used to route the log entry to a one or more the trace listeners.</param>
        /// <param name="priority">Only messages must be above the minimum priority are processed.</param>
        /// <param name="properties">Dictionary of key/value pairs to log.</param>
        public abstract void Write(object message, string category, int priority, IDictionary<string, object> properties);
        /// <summary>
        /// Write a new log with a specific category, priority and eventId.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="category">Category name used to route the log entry to a one or more trace listeners.</param>
        /// <param name="priority">Only messages must be above the minimum priority are processed.</param>
        /// <param name="eventId">Event number of identifier.</param>
        public abstract void Write(object message, string category, int priority, int eventId);
        /// <summary>
        /// Write a new log entry with a specific collection of categories, priority,
        ///    event id and severity.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="categories">Category names used to route the log entry to a one or more trace listeners.</param>
        /// <param name="priority">Only messages must be above the minimum priority are processed.</param>
        /// <param name="eventId">Event number or identifier.</param>
        /// <param name="severity">Log entry severity as System.Diagnostics.TraceEventType enumeration. (Unspecified,
        ///     Information, Warning or Error).</param>
        public abstract void Write(object message, ICollection<string> categories, int priority, int eventId, TraceEventType severity);
        /// <summary>
        /// Write a new log entry with a specific category, priority, event id and severity.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="category">Category name used to route the log entry to a one or more trace listeners.</param>
        /// <param name="priority">Only messages must be above the minimum priority are processed.</param>
        /// <param name="eventId">Event number or identifier.</param>
        /// <param name="severity">Log entry severity as a System.Diagnostics.TraceEventType enumeration. (Unspecified,
        ///     Information, Warning or Error).</param>
        public abstract void Write(object message, string category, int priority, int eventId, TraceEventType severity);
        /// <summary>
        /// Write a new log entry with a specific collection of categories, priority,
        ///     event id, severity and title.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="categories">Category name used to route the log entry to a one or more trace listeners.</param>
        /// <param name="priority">Only messages must be above the minimum priority are processed.</param>
        /// <param name="eventId">Event number or identifier.</param>
        /// <param name="severity">Log entry severity as a System.Diagnostics.TraceEventType enumeration. (Unspecified,
        ///     Information, Warning or Error).</param>
        /// <param name="title">Additional description of the log entry message.</param>
        public abstract void Write(object message, ICollection<string> categories, int priority, int eventId, TraceEventType severity, string title);
        /// <summary>
        /// Write a new log entry with a specific category, priority, event id, severity
        ///     and title.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="category">Category name used to route the log entry to a one or more trace listeners.</param>
        /// <param name="priority">Only messages must be above the minimum priority are processed.</param>
        /// <param name="eventId">Event number or identifier.</param>
        /// <param name="severity">Log entry severity as a System.Diagnostics.TraceEventType enumeration. (Unspecified,
        ///     Information, Warning or Error).</param>
        /// <param name="title">Additional description of the log entry message.</param>
        public abstract void Write(object message, string category, int priority, int eventId, TraceEventType severity, string title);
        /// <summary>
        /// Write a new log entry with a specific category, priority, event Id, severity
        ///     title and dictionary of extended properties.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="categories">Category name used to route the log entry to a one or more trace listeners.</param>
        /// <param name="priority">Only messages must be above the minimum priority are processed.</param>
        /// <param name="eventId">Event number or identifier.</param>
        /// <param name="severity">Log entry severity as a System.Diagnostics.TraceEventType enumeration. (Unspecified,
        ///     Information, Warning or Error).</param>
        /// <param name="title">Additional description of the log entry message</param>
        /// <param name="properties">Dictionary of key/value pairs to log.</param>
        public abstract void Write(object message, ICollection<string> categories, int priority, int eventId, TraceEventType severity, string title, IDictionary<string, object> properties);
        /// <summary>
        /// Write a new log entry with a specific category, priority, event Id, severity
        ///     title and dictionary of extended properties.
        /// </summary>
        /// <param name="message">Message body to log. Value from ToString() method from message object.</param>
        /// <param name="category">Category name used to route the log entry to a one or more trace listeners.</param>
        /// <param name="priority">Only messages must be above the minimum priority are processed.</param>
        /// <param name="eventId">Event number or identifier.</param>
        /// <param name="severity">Log entry severity as a System.Diagnostics.TraceEventType enumeration. (Unspecified,
        ///     Information, Warning or Error).</param>
        /// <param name="title">dditional description of the log entry message</param>
        /// <param name="properties">Dictionary of key/value pairs to log.</param>
        public abstract void Write(object message, string category, int priority, int eventId, TraceEventType severity, string title, IDictionary<string, object> properties);
    }
}
