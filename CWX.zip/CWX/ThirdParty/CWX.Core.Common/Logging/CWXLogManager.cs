using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Configuration.Provider;
using System.Web.Configuration;
using System.Diagnostics;

using Microsoft.Practices.EnterpriseLibrary.Logging.Filters;
using Microsoft.Practices.EnterpriseLibrary.Logging;

using CWX.Core.Common.Logging.Configuration;


namespace CWX.Core.Common.Logging
{
    public static class CWXLogManager
    {
        #region Fields

        private static object _lock;
        private static CWXLogProvider _cwxLogProvider;
        private static CWXLogProviderCollection _cwxLogProviders;
        private static bool _initialized;
        private static Exception _initializeException;
        private static bool _enabled;
        private static bool _enabledSet;

        #endregion

        #region Properties

        public static CWXLogProvider Provider
        {
            get
            {
                CWXLogManager.EnsureEnabled();
                return CWXLogManager._cwxLogProvider;
            }
        }

        public static CWXLogProviderCollection Providers
        {
            get
            {
                CWXLogManager.EnsureEnabled();
                return CWXLogManager._cwxLogProviders;
            }
        }

        public static bool Enabled
        {
            get
            {
                if (!CWXLogManager._initialized && !CWXLogManager._enabledSet)
                {
                    CWXLogManagerSection section = ConfigurationManager.GetSection("system.web/CWXLogManager") as CWXLogManagerSection;
                    CWXLogManager._enabled = section.Enabled;
                    CWXLogManager._enabledSet = true;
                }
                return CWXLogManager._enabled;
            }
        }

        #endregion

        #region Constructor

        static CWXLogManager()
        {
            _initialized = false;
            _initializeException = null;
            _lock = new object();
        }

        #endregion

        #region Private Methods

        private static void EnsureEnabled()
        {
            CWXLogManager.Initialize();
            if (!CWXLogManager._enabled)
            {
                throw new ProviderException("LogManager feature is not enabled.");
            }
        }

        private static void Initialize()
        {
            if (CWXLogManager._initialized)
            {
                if (CWXLogManager._initializeException != null)
                {
                    throw CWXLogManager._initializeException;
                }
            }
            else
            {
                lock (CWXLogManager._lock)
                {
                    try
                    {
                        CWXLogManagerSection section = ConfigurationManager.GetSection("system.web/CWXLogManager") as CWXLogManagerSection;
                        CWXLogManager._enabled = section.Enabled;
                        if (CWXLogManager._enabled)
                        {
                            CWXLogManager._cwxLogProviders = new CWXLogProviderCollection();
                            ProvidersHelper.InstantiateProviders(section.Providers, CWXLogManager._cwxLogProviders, typeof(CWXLogProvider));
                            CWXLogManager._cwxLogProviders.SetReadOnly();
                            if (section.DefaultProvider == null)
                            {
                                CWXLogManager._initializeException = new ProviderException("Default log provider is not specified.");
                            }
                            else
                            {
                                try
                                {
                                    CWXLogManager._cwxLogProvider = CWXLogManager._cwxLogProviders[section.DefaultProvider];
                                }
                                catch
                                {
                                }
                            }
                            if (CWXLogManager._cwxLogProvider == null)
                            {
                                CWXLogManager._initializeException = new ConfigurationErrorsException("Default log provider is not found", section.ElementInformation.Properties["defaultProvider"].Source, section.ElementInformation.Properties["defaultProvider"].LineNumber);
                            }
                        }
                    }
                    catch (Exception exception)
                    {
                        CWXLogManager._initializeException = exception;
                    }
                    CWXLogManager._initialized = true;
                }
                if (CWXLogManager._initializeException != null)
                {
                    throw CWXLogManager._initializeException;
                }
            }
        }
        #endregion

        #region Log-related Public Properties and Methods
        public static LogWriter Writer
        {
            get
            {
                CWXLogManager.EnsureEnabled();
                return CWXLogManager.Provider.Writer;
            }
        }
        public static void FlushContextItems()
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.FlushContextItems();
        }

        public static ILogFilter GetFilter(string name)
        {
            CWXLogManager.EnsureEnabled();
            return CWXLogManager.Provider.GetFilter(name);
        }

        public static bool IsLoggingEnabled()
        {
            CWXLogManager.EnsureEnabled();
            return CWXLogManager.Provider.IsLoggingEnabled();
        }

        public static void SetContextItem(object key, object value)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.SetContextItem(key, value);
        }

        public static bool ShouldLog(LogEntry log)
        {
            CWXLogManager.EnsureEnabled();
            return CWXLogManager.Provider.ShouldLog(log);
        }

        public static void Write(LogEntry log)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(log);
        }

        public static void Write(object message)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message);
        }

        public static void Write(object message, ICollection<string> categories)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, categories);
        }

        public static void Write(object message, IDictionary<string, object> properties)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, properties);
        }

        public static void Write(object message, string category)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, category);
        }

        public static void Write(object message, ICollection<string> categories, IDictionary<string, object> properties)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, categories, properties);
        }

        public static void Write(object message, ICollection<string> categories, int priority)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, categories, priority);
        }

        public static void Write(object message, string category, IDictionary<string, object> properties)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, category, properties);
        }

        public static void Write(object message, string category, int priority)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, category, priority);
        }

        public static void Write(object message, ICollection<string> categories, int priority, IDictionary<string, object> properties)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, categories, priority, properties);
        }

        public static void Write(object message, ICollection<string> categories, int priority, int eventId)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, categories, priority, eventId);
        }

        public static void Write(object message, string category, int priority, IDictionary<string, object> properties)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, category, priority, properties);
        }

        public static void Write(object message, string category, int priority, int eventId)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, category, priority, eventId);
        }

        public static void Write(object message, ICollection<string> categories, int priority, int eventId, TraceEventType severity)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, categories, priority, eventId, severity);
        }

        public static void Write(object message, string category, int priority, int eventId, TraceEventType severity)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, category, priority, eventId, severity);
        }

        public static void Write(object message, ICollection<string> categories, int priority, int eventId, TraceEventType severity, string title)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, categories, priority, eventId, severity, title);
        }

        public static void Write(object message, string category, int priority, int eventId, TraceEventType severity, string title)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, category, priority, eventId, severity, title);
        }

        public static void Write(object message, ICollection<string> categories, int priority, int eventId, TraceEventType severity, string title, IDictionary<string, object> properties)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, categories, priority, eventId, severity, title, properties);
        }

        public static void Write(object message, string category, int priority, int eventId, TraceEventType severity, string title, IDictionary<string, object> properties)
        {
            CWXLogManager.EnsureEnabled();
            CWXLogManager.Provider.Write(message, category, priority, eventId, severity, title, properties);
        }
        #endregion
    }
}
