using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CWX.Core.Common.Logging.Configuration
{
    class CWXLogManagerSection: ConfigurationSection
    {
        private static ConfigurationPropertyCollection m_properties;
        private static readonly ConfigurationProperty m_propProviders;
        private static readonly ConfigurationProperty m_propDefaultProvider;
        private static readonly ConfigurationProperty m_propEnabled;

        static CWXLogManagerSection()
        {
            m_propEnabled = new ConfigurationProperty("enabled", typeof(bool), false, ConfigurationPropertyOptions.None);
            m_propProviders = new ConfigurationProperty("providers", typeof(ProviderSettingsCollection), null, ConfigurationPropertyOptions.None);
            m_propDefaultProvider = new ConfigurationProperty("defaultProvider", typeof(string), "CWXLogProvider", null, new StringValidator(1), ConfigurationPropertyOptions.None);

            CWXLogManagerSection.m_properties = new ConfigurationPropertyCollection();
            CWXLogManagerSection.m_properties.Add(m_propEnabled);
            CWXLogManagerSection.m_properties.Add(m_propDefaultProvider);
            CWXLogManagerSection.m_properties.Add(m_propProviders);
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get
            {
                return CWXLogManagerSection.m_properties;
            }
        }

        [ConfigurationProperty("providers")]
        public ProviderSettingsCollection Providers
        {
            get 
            {
                return (ProviderSettingsCollection)base[CWXLogManagerSection.m_propProviders];
            }
        }

        [ConfigurationProperty("defaultProvider", DefaultValue = "CWXLogProvider"), StringValidator(MinLength = 1)] 
        public string DefaultProvider
        {
            get 
            {
                return (string)base[CWXLogManagerSection.m_propDefaultProvider];
            }
            set 
            {
                base[CWXLogManagerSection.m_propDefaultProvider] = value; 
            }
        }

        [ConfigurationProperty("enabled", DefaultValue = false)]
        public bool Enabled
        {
            get
            {
                return (bool)base[CWXLogManagerSection.m_propEnabled];
            }
            set
            {
                base[CWXLogManagerSection.m_propEnabled] = value;
            }
        }
    }
}
