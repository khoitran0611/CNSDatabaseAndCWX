using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace CWX.Core.Common.Exceptions
{
    public class RepositoryConcurrencyViolationException : RepositoryException
    {
        #region Constructors
        public RepositoryConcurrencyViolationException()
            : base()
        {
        }

        public RepositoryConcurrencyViolationException(string message)
            : base(message)
        {
        }

        public RepositoryConcurrencyViolationException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public RepositoryConcurrencyViolationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
        #endregion


    }
}
