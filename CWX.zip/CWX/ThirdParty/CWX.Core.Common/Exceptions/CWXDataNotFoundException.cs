using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

using CWX.Core.Common.Security;
using CWX.Core.Common.Resource;

namespace CWX.Core.Common.Exceptions
{
    /// <summary>
    /// Represents errors that occur when an ID cannot found in the system.
    /// </summary>
    public class CWXDataNotFoundException : CWXException
    {

        public CWXDataNotFoundException(string message)
            : base(message)
        {
        }

        public CWXDataNotFoundException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public CWXDataNotFoundException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
