using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

using CWX.Core.Common.Security;
using CWX.Core.Common.Resource;

namespace CWX.Core.Common.Exceptions
{
    public class CWXAuthorizationException : CWXException
    {
        private string _message = string.Empty;
        /// <summary>
        /// The message that describes the error.
        /// </summary>
        public override string Message
        {
            get
            {
                if (string.IsNullOrEmpty(_message))
                {
                    switch (ViolatedPermission)
                    {
                        /*
                        case CWXPermissionConstant.ACCESS_ACCOUNT_MANAGEMENT:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException_ACCESS_ACCOUNT_MANAGEMENT");
                            break;
                        case CWXPermissionConstant.ACCESS_CUSTOMER_MANAGEMENT:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException_ACCESS_CUSTOMER_MANAGEMENT");
                            break;
                        case CWXPermissionConstant.ACCESS_CWX_SYSTEM:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException_ACCESS_CWX_SYSTEM");
                            break;
                        case CWXPermissionConstant.ACCESS_EMPLOYEE_MANAGEMENT:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException_ACCESS_EMPLOYEE_MANAGEMENT");
                            break;
                        case CWXPermissionConstant.ACCESS_PRODUCT_MANAGEMENT:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException_ACCESS_PRODUCT_MANAGEMENT");
                            break;
                        case CWXPermissionConstant.ACCESS_EMPLOYEE_ACTIVE_REPORT:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException_ACCESS_PRODUCTIVITY_MANAGEMENT");
                            break;
                        case CWXPermissionConstant.ACCESS_REPORT_MANAGEMENT:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException_ACCESS_REPORT_MANAGEMENT");
                            break;
                        case CWXPermissionConstant.ACCESS_SYSTEM_SETUP:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException_ACCESS_SYSTEM_SETUP");
                            break;
                        case CWXPermissionConstant.SUPERVISOR:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException_SUPERVISOR");
                            break;
                        case CWXPermissionConstant.ACCESS_GLOBAL_SETTINGS:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException_ACCESS_GLOBAL_SETTINGS");
                            break;
                        case CWXPermissionConstant.ACCESS_PASSWORD_SETTINGS:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException_ACCESS_PASSWORD_SETTINGS");
                            break;
                        case CWXPermissionConstant.ACCESS_BUSINESS_RULES_MANAGER:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException_ACCESS_BUSINESS_RULE_SETTINGS");
                            break;
                        */
                        default:
                            _message = CWXResourceManager.GetString(ResourceCategory.Errors, "AuthorizationException");
                            break;
                    }
                }
                return _message;
            }
        }

        private CWXPermissionConstant _violatedPermission;
        public CWXPermissionConstant ViolatedPermission
        {
            get { return _violatedPermission; }
            set { _violatedPermission = value; }
        }

        public CWXAuthorizationException()
            : base()
        {
        }

        public CWXAuthorizationException(string message)
            : base(message)
        {
            _message = message;
        }

        public CWXAuthorizationException(string message, Exception innerException)
            : base(message, innerException)
        {
            _message = message;
        }

        public CWXAuthorizationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public CWXAuthorizationException(CWXPermissionConstant violatedPermission)
        {
            _violatedPermission = violatedPermission;
        }

    }
}
