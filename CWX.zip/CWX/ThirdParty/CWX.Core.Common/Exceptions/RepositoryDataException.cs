using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace CWX.Core.Common.Exceptions
{
    public class RepositoryDataException : RepositoryException
    {
        #region Constructors
        public RepositoryDataException()
            : base()
        {
        }

        public RepositoryDataException(string message)
            : base(message)
        {
        }

        public RepositoryDataException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public RepositoryDataException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
        #endregion
    }
}
