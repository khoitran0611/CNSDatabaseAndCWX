using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.Reflection;

namespace CWX.Core.Common.Exceptions
{
    /// <summary>
    /// Represents errors that occur during CWX execution.
    /// </summary>
    public class CWXException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the CWXException class.
        /// </summary>
        public CWXException()
            : base()
        { 
        }

        /// <summary>
        /// Initializes a new instance of the CWXException class with a specified error message.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        public CWXException(string message)
            : base(message)
        { 
        }

        /// <summary>
        /// Initializes a new instance of the System.Exception class with a specified
        /// error message and a reference to the inner exception that is the cause of
        /// this exception.
        /// </summary>
        /// <param name="message">The error message that explains the reason for the exception.</param>
        /// <param name="innerException">
        /// The exception that is the cause of the current exception, or a null reference
        /// (Nothing in Visual Basic) if no inner exception is specified.
        /// </param>
        public CWXException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the CWXException class with serialized data.
        /// </summary>
        /// <param name="info">The System.Runtime.Serialization.SerializationInfo that holds the serialized 
        /// object data about the exception being thrown.</param>
        /// <param name="context">The System.Runtime.Serialization.StreamingContext that contains contextual 
        /// information about the source or destination.</param>
        public CWXException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        { 
        }

        /// <summary>
        /// Set stack trace from input exception.
        /// </summary>
        /// <param name="ex">Exception to get trace.</param>
        public void SetTrace(Exception ex)
        {
            if (ex.InnerException != null)
                ex = ex.InnerException;

            this.Source = ex.Source;
            BindingFlags bindingFlags = BindingFlags.NonPublic | BindingFlags.Instance;
            Type exceptionType = typeof(Exception);
            FieldInfo stackTraceField = exceptionType.GetField("_stackTrace", bindingFlags);
            object stackTraceValue = stackTraceField.GetValue(ex);
            if (stackTraceField != null)
                stackTraceField.SetValue(this, stackTraceValue);

            FieldInfo remoteStackTraceStringField = exceptionType.GetField("_remoteStackTraceString", bindingFlags);
            object remoteStackTraceValue = remoteStackTraceStringField.GetValue(ex);
            if (remoteStackTraceValue != null)
                remoteStackTraceStringField.SetValue(this, remoteStackTraceValue);            
        }

    }
}
