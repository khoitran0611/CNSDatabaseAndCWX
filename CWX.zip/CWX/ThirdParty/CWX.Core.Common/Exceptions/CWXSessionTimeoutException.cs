using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

using CWX.Core.Common.Resource;


namespace CWX.Core.Common.Exceptions
{
    /// <summary>
    /// Represents errors that occur when session timeout.
    /// </summary>
    public class CWXSessionTimeoutException : CWXException
    {
        public CWXSessionTimeoutException()
            : base(CWXResourceManager.GetString(ResourceCategory.Errors, "WebCommon_SessionTimeout"))
        {
        }

        public CWXSessionTimeoutException(string message)
            : base(message)
        {
        }

        public CWXSessionTimeoutException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public CWXSessionTimeoutException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
