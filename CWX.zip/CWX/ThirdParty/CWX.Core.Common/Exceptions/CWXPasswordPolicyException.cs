using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using CWX.Core.Common.Security;

namespace CWX.Core.Common.Exceptions
{
    public class CWXPasswordPolicyException : CWXException
    {
        public CWXPasswordPolicyException()
            : base()
        {
        }

        public CWXPasswordPolicyException(CWXPasswordPolicy policy)
            : base(policy.Name)
        {
        }


        public CWXPasswordPolicyException(string message)
            : base(message)
        {
        }

        public CWXPasswordPolicyException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public CWXPasswordPolicyException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
