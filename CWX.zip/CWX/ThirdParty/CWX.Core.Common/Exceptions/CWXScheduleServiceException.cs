using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

using CWX.Core.Common.Security;
using CWX.Core.Common.Resource;

namespace CWX.Core.Common.Exceptions
{
    /// <summary>
    /// Represents errors that occur while schedule service are running.
    /// </summary>
    public class CWXScheduleServiceException : CWXException
    {

        public CWXScheduleServiceException(string message)
            : base(message)
        {
        }

        public CWXScheduleServiceException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public CWXScheduleServiceException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
