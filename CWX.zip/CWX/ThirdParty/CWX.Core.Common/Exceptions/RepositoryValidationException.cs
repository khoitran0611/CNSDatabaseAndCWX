using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace CWX.Core.Common.Exceptions
{
    public class RepositoryValidationException: RepositoryException
    {
        #region Constructors
        public RepositoryValidationException()
        { 
        }

        public RepositoryValidationException(string failureField, string failureReason)
        {
            _failureField = failureField;
            _failureReason = failureReason;
        }

        public RepositoryValidationException(string failureField, string failureReason, Exception innerException)
        {
            _failureField = failureField;
            _failureReason = failureReason;
        }

        public RepositoryValidationException(string message)
            : base(message)
        { 

        }

        public RepositoryValidationException(string message, Exception innerException)
            : base(message, innerException)
        {
            
        }

        public RepositoryValidationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        #endregion

        #region Properties
        private string _failureField;
        public string FailureField
        {
            get { return _failureField; }
            set { _failureField = value; }
        }

        private string _failureReason;
        public string FailureReason
        {
            get { return _failureReason; }
            set { _failureReason = value; }
        }

        private string InnerMessage
        {
            get
            {
                return FailureField + ": " + FailureReason;
            }
        }
        #endregion

        #region Override Methods
        public override string ToString()
        {
            return InnerMessage;
        }

        #endregion
    }
}
