using System;
using System.Data;
using System.Collections.Generic;
using System.Text;
using CWX.Core.Common.Data;
using System.Collections.ObjectModel;

namespace CWX.Core.Common
{
    public class BusinessService<TDomainObject,TRepository>
        where TDomainObject: class, new()
        where TRepository : IRepository<TDomainObject>
    {
        public BusinessService() 
        { 
        }
        public BusinessService(TRepository repository)
        {
            _repository = repository;
        }

        protected IRepository<TDomainObject> _repository;

        /// <summary>
        /// Add a domain object to the datasource.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to add to the datasource.</param>
        /// <returns>true if adding domain object successfully; otherwise, false. </returns>
        public virtual bool Add(TDomainObject domainObject)
        {
            return _repository.Add(domainObject);
        }

        /// <summary>
        /// Add a domain object to the datasource. Then output newID.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to add to the datasource.</param>
        /// <returns>true if adding domain object successfully; otherwise, false. </returns>
        public virtual bool Add(TDomainObject domainObject, out int newID)
        {
            return _repository.Add(domainObject, out newID);
        }

		/// <summary>
		/// Convert multiple rows in DataTable to objects and insert all records to database which return true if inserts successfully, 
		/// otherwise returns false
		/// </summary>
		/// <typeparam name="TDomainObject">The type of domain object.</typeparam>
		/// <param name="domainObject">An instant of DataTable object.</param>
		/// <returns>Returns true if inserts successfully, otherwise returns false.</returns>
		public virtual bool Add(DataTable dataTable)
		{
			return _repository.Add(dataTable);
		}

        /// <summary>
        /// Remove a domain object from the datasource.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to remove from the datasource.</param>
        /// <returns>true if removing domain object successfully; otherwise, false.</returns>
        public virtual bool Remove(TDomainObject domainObject)
        {
            return _repository.Remove(domainObject);
        }

        /// <summary>
        /// Remove a domain object from the datasource.
        /// </summary>
        /// <typeparam name="TIdentity">Type of domain object identity.</typeparam>
        /// <param name="identityValue">The identity for the domain object.</param>
        /// <returns>true if removing domain object successfully; otherwise, false.</returns>
        /// <remarks>TDomainObject must have only <b>one identity</b></remarks>
        public virtual bool Remove<TIdentity>(TIdentity identity)
        {
            return _repository.Remove<TIdentity>(identity);
        }

        /// <summary>
        /// Marks deleted a record where its identity value is equal to the identity value of the given object
        /// and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        public virtual bool SoftDelete(TDomainObject domainObject)
        {
            return _repository.SoftDelete(domainObject);
        }

        /// <summary>
        /// Marks deleted a record with the given identityValue and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <typeparam name="TIdentity">The type of the given identityValue.</typeparam>
        /// <param name="identityValue">The value of identity.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        public virtual bool SoftDelete<TIdentity>(TIdentity identity)
        {
            return _repository.SoftDelete<TIdentity>(identity);
        }

        /// <summary>
        /// Update a domain object in the datasource.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to update.</param>
        /// <returns>true if updating domain object successfully; otherwise, false. </returns>
        public virtual bool Update(TDomainObject domainObject)
        {
            return _repository.Update(domainObject);
        }

        /// <summary>
        /// Update a domain object in the datasource
        /// </summary>
        /// <param name="domainObject">A TDomainObject to update.</param>
        /// <param name="clearCache">true clear cache; otherwise, false.</param>
        /// <returns>true if updating domain object successfully; otherwise, false.</returns>
        public virtual bool Update(TDomainObject domainObject, bool clearCache)
        {
            return _repository.Update(domainObject, clearCache);
        }

        public virtual bool Update(DataTable dataTable)
        {
            return _repository.Update(dataTable);
        }

        /// <summary>
        /// Find a domain object from the datasource.
        /// </summary>
        /// <param name="domainObject">A TDomainObject to find from the datasource.</param>
        /// <returns>A TDomainObject</returns>
        public virtual TDomainObject FindOne(TDomainObject domainObject)
        {
            return _repository.FindOne(domainObject);
        }

        /// <summary>
        /// Find a domain object from the datasource.
        /// </summary>
        /// <typeparam name="TIdentity">Type of domain object identity.</typeparam>
        /// <param name="identityValue">The identity for the domain object.</param>
        /// <returns>A TDomainObject</returns>
        /// <remarks>TDomainObject must have only <b>one identity</b></remarks>
        public virtual TDomainObject FindOne<TIdentity>(TIdentity identity)
        {
            return _repository.FindOne<TIdentity>(identity);
        }

        /// <summary>
        /// Find a domain object from the datasource.
        /// </summary>
        /// <param name="identityFields">The identity's names for the domain object.</param>
        /// <param name="identityValues">The identity's values for the domain object.</param>
        /// <returns>A TDomainObject</returns>
        public virtual TDomainObject FindOne(string[] identityFields, object[] identityValues)
        {
            return _repository.FindOne(identityFields, identityValues);
        }

        /// <summary>
        /// Get a list of TDomainObject from the datasource.
        /// </summary>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;></returns>
        public virtual Collection<TDomainObject> FillList()
        {
            return _repository.FillList();
        }

        /// <summary>
        /// Get a list of TDomainObject from the datasource.
        /// </summary>
        /// <param name="orderByClause">order by clause to sort the TDomainObject list</param>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;></returns>
        public virtual Collection<TDomainObject> FillList(string orderByClause)
        {
            return _repository.FillList(orderByClause);
        }

        /// <summary>
        /// Get a list of TDomainObject from the datasource.
        /// </summary>
        /// <param name="orderByClause">order by clause to sort the TDomainObject list</param>
        /// <param name="whereClause">where clause to filter the TDomainObject list</param>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;></returns>
        public virtual Collection<TDomainObject> FillList(string orderByClause, string whereClause)
        {
            return _repository.FillList(orderByClause, whereClause);
        }

        /// <summary>
        /// Get a list of TDomainObject from the application cache.
        /// </summary>
        /// <remarks>
        /// If AppSettings BusinessCacheTime does not exist in the config file, default cache time will be 10 mins.
        /// Cache key is generated from "FillList_[TDomainObject class name]".
        /// </remarks>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;></returns>
        /// <history>
        ///     08/07/01    [Binh Truong]   Init version.
        /// </history>
        public virtual Collection<TDomainObject> FillListFromCache()
        {
            return _repository.FillListFromCache();
        }

        /// <summary>
        /// Get a list of TDomainObject from the datasource with giving pageSize and pageIndex.
        /// </summary>
        /// <param name="pageSize">pageSize</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="orderByColumnName">orderByColumn</param>
        /// <param name="orderDirection">orderDirection</param>
        /// <param name="rowCount">The number of selected TDomainObjects</param>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;</returns>
        public virtual Collection<TDomainObject> FillPagingList(int pageSize, int pageIndex, string orderByColumnName, OrderByDirection orderDirection, out int rowCount)
        {
            return _repository.FillPagingList(pageSize, pageIndex, orderByColumnName, orderDirection, out rowCount);
        }

        /// <summary>
        /// Selects record(s) with the given pageSize, pageIndex, orderByColumnName and orderDirection then returns an collection of objects
        /// and supplies the number of found records through output param rowCount.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="orderByClause">Expression of orderByClause including order direction. Ex: "[FieldName] ASC" or "[FieldName] DESC".</param>
        /// <param name="whereClause">Expression of whereClause. Ex: "[FieldName] = value" or "[FieldName] like '%value%'".</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        public virtual Collection<TDomainObject> FillPagingList(int pageSize, int pageIndex, string orderByClause, string whereClause, out int rowCount)
        {
            return _repository.FillPagingList(pageSize, pageIndex, orderByClause, whereClause, out rowCount);
        }

        /// <summary>
        /// Get a list of TDomainObject from the datasource with giving pageSize and pageIndex.
        /// </summary>
        /// <param name="pageSize">pageSize</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="orderByColumnName">orderByColumn</param>
        /// <param name="orderDirection">orderDirection</param>
        /// <param name="whereClause">WHERE clause</param>
        /// <param name="rowCount">The number of selected TDomainObjects</param>
        /// <returns>A System.Collections.ObjectModel.Collection&lt;TDomainObject&gt;</returns>
        public virtual Collection<TDomainObject> FillPagingList(int pageSize, int pageIndex, string orderByColumnName, OrderByDirection orderDirection, string whereClause, out int rowCount)
        {
            return _repository.FillPagingList(pageSize, pageIndex, orderByColumnName, orderDirection, whereClause, out rowCount);
        }

        /// <summary>
        /// Executes a Transact-SQL statement against the connection and returns the number of rows affected.
        /// </summary>
        /// <param name="storedProcedureName">stored procedure to execute.</param>
        /// <param name="parameterNames">the names for the stored procedure parameters.</param>
        /// <param name="parameterValues">the values for the stored procedure parameters.</param>
        /// <returns>the number of rows affected.</returns>
        public virtual int ExecuteNonQuery(string storedProcedureName, string[] parameterNames, object[] parameterValues)
        {
            return _repository.ExecuteNonQuery(storedProcedureName, parameterNames, parameterValues);
        }

        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="returnedValue">System.Int32</param>
        /// <returns>The number of rows affected.</returns>
        public virtual int ExecuteNonQuery(string storedProcedureName, out int returnedValue)
        {
            return _repository.ExecuteNonQuery(storedProcedureName, out returnedValue);
        }

        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="parameterNames">Array of parameter names.</param>
        /// <param name="parameterValues">Array of parameter values.</param>
        /// <param name="returnedValue">System.Int32</param>
        /// <returns></returns>
        public virtual int ExecuteNonQuery(string storedProcedureName, string[] parameterNames, object[] parameterValues, out int returnedValue)
        {
            return _repository.ExecuteNonQuery(storedProcedureName, parameterNames, parameterValues, out returnedValue);
        }

        public virtual object GetMaxIdentity()
        {
            return _repository.GetMaxIdentity();
        }

        public virtual object GetMaxIdentity(string identityFieldName, string whereClause)
        {
            return _repository.GetMaxIdentity(identityFieldName, whereClause);
        }

        /// <summary>
        /// Clear FillList cache.
        /// </summary>
        public void ClearFillListCache()
        {
            _repository.ClearFillListCache();
        }
    }
}
