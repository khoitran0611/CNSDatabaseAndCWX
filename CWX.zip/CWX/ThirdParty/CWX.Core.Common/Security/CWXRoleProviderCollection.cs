using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration.Provider;

namespace CWX.Core.Common.Security
{
    /// <summary>
    /// A collection of objects that inherit the <see cref="CwxRoleProvider"/> abstract class. 
    /// </summary>
    public class CWXRoleProviderCollection : ProviderCollection
    {
        /// <summary>
        /// Gets the role provider in the collection referenced by the specified provider name. 
        /// </summary>
        /// <param name="name">The name of the role provider.</param>
        /// <returns>An object that inherits the <see cref="CwxRoleProvider"/> abstract class.</returns>
        public new CWXRoleProvider this[string name]
        {
            get { return (CWXRoleProvider)base[name]; }
        }

        /// <summary>
        /// Adds a role provider to the collection. 
        /// </summary>
        /// <param name="provider">The role provider to add to the collection.</param>
        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");

            if (!(provider is CWXRoleProvider))
                throw new ArgumentException
                    ("Invalid provider type", "provider");

            base.Add(provider);
        }
    }
}
