using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

using System.Configuration;
using System.Configuration.Provider;
using System.Web.Configuration;

using CWX.Core.Common.Security.Configuration;

namespace CWX.Core.Common.Security
{
    public static class CWXRoleManager
    {
        #region Fields

        private static object _lock;
        private static CWXRoleProvider _cwxRoleProvider;
        private static CWXRoleProviderCollection _cwxRoleProviders;
        private static bool _initialized;
        private static Exception _initializeException;
        private static bool _enabled;
        private static bool _enabledSet;

        #endregion

        #region Properties

        public static CWXRoleProvider Provider
        {
            get
            {
                CWXRoleManager.EnsureEnabled();
                return CWXRoleManager._cwxRoleProvider;
            }
        }

        public static CWXRoleProviderCollection Providers
        {
            get
            {
                CWXRoleManager.EnsureEnabled();
                return CWXRoleManager._cwxRoleProviders;
            }
        }

        public static bool Enabled
        {
            get
            {
                if (!CWXRoleManager._initialized && !CWXRoleManager._enabledSet)
                {
                    CWXRoleManagerSection section = ConfigurationManager.GetSection("system.web/CWXRoleManager") as CWXRoleManagerSection;
                    CWXRoleManager._enabled = section.Enabled;
                    CWXRoleManager._enabledSet = true;
                }
                return CWXRoleManager._enabled;
            }
        }

        #endregion

        #region Constructor

        static CWXRoleManager()
        {
            _initialized = false;
            _initializeException = null;
            _lock = new object();
        }

        #endregion

        #region Private Methods

        private static void EnsureEnabled()
        {
            CWXRoleManager.Initialize();
            if (!CWXRoleManager._enabled)
            {
                throw new ProviderException("RoleManager feature is not enabled.");
            }
        }

        private static void Initialize()
        {
            if (CWXRoleManager._initialized)
            {
                if (CWXRoleManager._initializeException != null)
                {
                    throw CWXRoleManager._initializeException;
                }
            }
            else
            {
                lock (CWXRoleManager._lock)
                {
                    try
                    {
                        CWXRoleManagerSection section = ConfigurationManager.GetSection("system.web/CWXRoleManager") as CWXRoleManagerSection;
                        CWXRoleManager._enabled = section.Enabled;
                        if (CWXRoleManager._enabled)
                        {
                            CWXRoleManager._cwxRoleProviders = new CWXRoleProviderCollection();
                            ProvidersHelper.InstantiateProviders(section.Providers, CWXRoleManager._cwxRoleProviders, typeof(CWXRoleProvider));
                            CWXRoleManager._cwxRoleProviders.SetReadOnly();
                            if (section.DefaultProvider == null)
                            {
                                CWXRoleManager._initializeException = new ProviderException("Default role provider is not specified.");
                            }
                            else
                            {
                                try
                                {
                                    CWXRoleManager._cwxRoleProvider = CWXRoleManager._cwxRoleProviders[section.DefaultProvider];
                                }
                                catch
                                {
                                }
                            }
                            if (CWXRoleManager._cwxRoleProvider == null)
                            {
                                CWXRoleManager._initializeException = new ConfigurationErrorsException("Default role provider is not found", section.ElementInformation.Properties["defaultProvider"].Source, section.ElementInformation.Properties["defaultProvider"].LineNumber);
                            }
                        }
                    }
                    catch (Exception exception)
                    {
                        CWXRoleManager._initializeException = exception;
                    }
                    CWXRoleManager._initialized = true;
                }
                if (CWXRoleManager._initializeException != null)
                {
                    throw CWXRoleManager._initializeException;
                }
            }
        }

        #endregion

        #region Role-related Public Methods

        /// <summary>
        /// Adds a new role to the data source.
        /// </summary>
        /// <param name="role">A CWX.Core.Common.Security.CWXRole to add to the datasource.</param>
        public static void CreateRole(CWXRole role)
        {
            CWXRoleManager.EnsureEnabled();

            CWXRoleManager.Provider.CreateRole(role);
        }

        /// <summary>
        /// Adds a new role to the data source.
        /// </summary>
        /// <param name="roleName">The name for the new role.</param>
        /// <param name="rolePermissions">The permissions for the new role.</param>
        public static void CreateRole(string roleName)
        {
            CWXRoleManager.EnsureEnabled();

            CWXRoleManager.Provider.CreateRole(roleName);
        }

        /// <summary>
        /// Adds a new role to the data source.
        /// </summary>
        /// <param name="roleName">The name for the new role.</param>
        /// <param name="permissions">The permissions for the new role.</param>
        public static void CreateRole(string roleName, Collection<CWXPermission> permissions)
        {
            CWXRoleManager.EnsureEnabled();

            CWXRoleManager.Provider.CreateRole(roleName, permissions);
        }

        /// <summary>
        /// Update a selected role.
        /// </summary>
        /// <param name="role">A CWX.Core.Common.Security.CWXRole to update.</param>
        public static void UpdateRole(CWXRole role)
        {
            CWXRoleManager.EnsureEnabled();

            CWXRoleManager.Provider.UpdateRole(role);
        }

        /// <summary>
        /// Update a selected role.
        /// </summary>
        /// <param name="roleID">The id for the selected role.</param>
        /// <param name="roleName">The name for the selected role.</param>
        /// <param name="roleOrder">The order for the selected role.</param>
        /// <param name="permissions">The new permissions for the selected role.</param>
        public static void UpdateRole(int roleID, string roleName, int roleOrder, Collection<CWXPermission> permissions)
        {
            CWXRoleManager.EnsureEnabled();

            CWXRoleManager.Provider.UpdateRole(roleID, roleName, roleOrder, permissions);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="roleID"></param>
        public static void MoveUp(int roleID)
        {
            CWXRoleManager.EnsureEnabled();

            CWXRoleManager.Provider.MoveUp(roleID);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="roleID"></param>
        public static void MoveDown(int roleID)
        {
            CWXRoleManager.EnsureEnabled();

            CWXRoleManager.Provider.MoveDown(roleID);
        }

        /// <summary>
        /// Delete a selected role.
        /// </summary>
        /// <param name="role">A CWX.Core.Common.Security.CWXRole to delete.</param>
        public static void DeleteRole(CWXRole role)
        {
            CWXRoleManager.EnsureEnabled();

            CWXRoleManager.Provider.DeleteRole(role);
        }

        /// <summary>
        /// Delete a selected role.
        /// </summary>
        /// <param name="roleID">The id for the selected role.</param>
        public static void DeleteRole(int roleID)
        {
            CWXRoleManager.EnsureEnabled();

            CWXRoleManager.Provider.DeleteRole(roleID);
        }

        /// <summary>
        /// SoftDelete a selected role.
        /// </summary>
        /// <param name="role">A CWX.Core.Common.Security.CWXRole to delete.</param>
        public static void SoftDeleteRole(CWXRole role)
        {
            CWXRoleManager.EnsureEnabled();

            CWXRoleManager.Provider.SoftDeleteRole(role);
        }

        /// <summary>
        /// SoftDelete a selected role.
        /// </summary>
        /// <param name="roleID">The id for the selected role.</param>
        public static void SoftDeleteRole(int roleID)
        {
            CWXRoleManager.EnsureEnabled();

            CWXRoleManager.Provider.SoftDeleteRole(roleID);
        }

        /// <summary>
        /// Soft delete all roles.
        /// </summary>
        public static void SoftDeleteAll()
        {
            CWXRoleManager.EnsureEnabled();
            CWXRoleManager.Provider.SoftDeleteAll();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="roleName"></param>
        /// <returns></returns>
        public static bool RoleExists(string roleName)
        {
            CWXRoleManager.EnsureEnabled();

            return CWXRoleManager.Provider.RoleExists(roleName);
        }

        /// <summary>
        /// Get a role from the datasource.
        /// </summary>
        /// <param name="roleID">The id for the selected role.</param>
        /// <returns>A CWX.Core.Common.Security.CWXRole</returns>
        public static CWXRole GetRole(int roleID)
        {
            CWXRoleManager.EnsureEnabled();

            return CWXRoleManager.Provider.GetRole(roleID);
        }

        /// <summary>
        /// Get a role from the datasource.
        /// </summary>
        /// <param name="roleName">The Name for the selected role.</param>
        /// <returns>A CWX.Core.Common.Security.CWXRole</returns>
        public static CWXRole GetRole(string roleName)
        {
            CWXRoleManager.EnsureEnabled();

            return CWXRoleManager.Provider.GetRole(roleName);
        }

        /// <summary>
        /// Gets a list of all the roles from the datasource.
        /// </summary>
        /// <returns>A System.Collections.Generic.List&lt;CWXRole&gt;</returns>
        public static List<CWXRole> GetRoles()
        {
            CWXRoleManager.EnsureEnabled();

            return CWXRoleManager.Provider.GetRoles();
        }

        /// <summary>
        /// Gets a list of the roles by paging from the datasource.
        /// </summary>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>A System.Collections.Generic.List&lt;CWXRole&gt;</returns>
        public static List<CWXRole> GetRoles(int pageSize, int pageIndex, out int rowCount)
        {
            CWXRoleManager.EnsureEnabled();

            return CWXRoleManager.Provider.GetRoles(pageSize, pageIndex,  out rowCount);
        }


        /// <summary>
        /// Apply role permissions for all user that have RoleID=roleID
        /// </summary>
        /// <param name="roleID"></param>
        /// <returns></returns>
        public static bool ApplyNewRolePermissions(int roleID)
        {
            CWXRoleManager.EnsureEnabled();

            return CWXRoleManager.Provider.ApplyNewRolePermissions(roleID);
        }

        #endregion Role-related Public Methods

        
    }
}
