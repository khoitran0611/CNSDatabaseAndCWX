using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Security
{
    public class CWXPermissionGroup
    {
        public CWXPermissionGroup()
        {
        }

        public CWXPermissionGroup(CWXPermissionGroupConstant groupType, string groupName)
        {
            _groupType = groupType;
            _groupName = groupName;
        }

        private CWXPermissionGroupConstant _groupType;

        public CWXPermissionGroupConstant GroupType
        {
            get { return _groupType; }
            set { _groupType = value; }
        }

        public int GroupID
        {
            get 
            {
                return _groupType.GetHashCode();
            }
        }

        private string _groupName;

        public string GroupName
        {
            get { return _groupName; }
            set { _groupName = value; }
        }
	
	    
    }
}
