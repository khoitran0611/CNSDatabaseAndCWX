using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration.Provider;

namespace CWX.Core.Common.Security
{
    public class CWXPermissionProviderCollection : ProviderCollection
    {
        /// <summary>
        /// Gets the permission provider in the collection referenced by the specified provider name. 
        /// </summary>
        /// <param name="name">The name of the permission provider.</param>
        /// <returns>An object that inherits the <see cref="CwxRoleProvider"/> abstract class.</returns>
        public new CWXPermissionProvider this[string name]
        {
            get { return (CWXPermissionProvider)base[name]; }
        }

        /// <summary>
        /// Adds a permission provider to the collection. 
        /// </summary>
        /// <param name="provider">The permission provider to add to the collection.</param>
        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");

            if (!(provider is CWXPermissionProvider))
                throw new ArgumentException
                    ("Invalid provider type", "provider");

            base.Add(provider);
        }
    }
}
