using System;
using System.Collections.Generic;
using System.Configuration;
using System.Configuration.Provider;
using System.Web.Configuration;

using CWX.Core.Common.Security.Configuration;



namespace CWX.Core.Common.Security
{
    public class CWXPasswordPolicyManager
    {
        #region Fields

        private static object _lock;
        private static CWXPasswordPolicyProvider _cwxPasswordPolicyProvider;
        private static CWXPasswordPolicyProviderCollection _cwxPasswordPolicyProviders;
        private static bool _initialized;
        private static Exception _initializeException;
        private static bool _enabled;
        private static bool _enabledSet;

        #endregion

        #region Properties

        public static CWXPasswordPolicyProvider Provider
        {
            get
            {
                CWXPasswordPolicyManager.EnsureEnabled();
                return CWXPasswordPolicyManager._cwxPasswordPolicyProvider;
            }
        }

        public static CWXPasswordPolicyProviderCollection Providers
        {
            get
            {
                CWXPasswordPolicyManager.EnsureEnabled();
                return CWXPasswordPolicyManager._cwxPasswordPolicyProviders;
            }
        }

        public static bool Enabled
        {
            get
            {
                if (!CWXPasswordPolicyManager._initialized && !CWXPasswordPolicyManager._enabledSet)
                {
                    CWXPasswordPolicyManagerSection section = ConfigurationManager.GetSection("system.web/CWXPasswordPolicyManager") as CWXPasswordPolicyManagerSection;
                    CWXPasswordPolicyManager._enabled = section.Enabled;
                    CWXPasswordPolicyManager._enabledSet = true;
                }
                return CWXPasswordPolicyManager._enabled;
            }
        }

        #endregion

        #region Constructor

        static CWXPasswordPolicyManager()
        {
            _initialized = false;
            _initializeException = null;
            _lock = new object();
        }

        #endregion

        #region Private Methods

        private static void EnsureEnabled()
        {
            CWXPasswordPolicyManager.Initialize();
            if (!CWXPasswordPolicyManager._enabled)
            {
                throw new ProviderException("PasswordPolicyManager feature is not enabled.");
            }
        }

        private static void Initialize()
        {
            if (CWXPasswordPolicyManager._initialized)
            {
                if (CWXPasswordPolicyManager._initializeException != null)
                {
                    throw CWXPasswordPolicyManager._initializeException;
                }
            }
            else
            {
                lock (CWXPasswordPolicyManager._lock)
                {
                    try
                    {
                        CWXPasswordPolicyManagerSection section = ConfigurationManager.GetSection("system.web/CWXPasswordPolicyManager") as CWXPasswordPolicyManagerSection;
                        CWXPasswordPolicyManager._enabled = section.Enabled;
                        if (CWXPasswordPolicyManager._enabled)
                        {
                            CWXPasswordPolicyManager._cwxPasswordPolicyProviders = new CWXPasswordPolicyProviderCollection();
                            ProvidersHelper.InstantiateProviders(section.Providers, CWXPasswordPolicyManager._cwxPasswordPolicyProviders, typeof(CWXPasswordPolicyProvider));
                            CWXPasswordPolicyManager._cwxPasswordPolicyProviders.SetReadOnly();
                            if (section.DefaultProvider == null)
                            {
                                CWXPasswordPolicyManager._initializeException = new ProviderException("Default PasswordPolicy provider is not specified.");
                            }
                            else
                            {
                                try
                                {
                                    CWXPasswordPolicyManager._cwxPasswordPolicyProvider = CWXPasswordPolicyManager._cwxPasswordPolicyProviders[section.DefaultProvider];
                                }
                                catch
                                {
                                }
                            }
                            if (CWXPasswordPolicyManager._cwxPasswordPolicyProvider == null)
                            {
                                CWXPasswordPolicyManager._initializeException = new ConfigurationErrorsException("Default PasswordPolicy provider is not found", section.ElementInformation.Properties["defaultProvider"].Source, section.ElementInformation.Properties["defaultProvider"].LineNumber);
                            }
                        }
                    }
                    catch (Exception exception)
                    {
                        CWXPasswordPolicyManager._initializeException = exception;
                    }
                    CWXPasswordPolicyManager._initialized = true;
                }
                if (CWXPasswordPolicyManager._initializeException != null)
                {
                    throw CWXPasswordPolicyManager._initializeException;
                }
            }
        }

        #endregion

        #region Password-related methods
        /// <summary>
        /// Update a selected passwordPolicy.
        /// </summary>
        /// <param name="passwordPolicy">A CWX.Core.Common.Security.CWXPasswordPolicy to update.</param>
        public static void UpdatePasswordPolicy(CWXPasswordPolicy passwordPolicy)
        {
            CWXPasswordPolicyManager.EnsureEnabled();
            CWXPasswordPolicyManager.Provider.UpdatePasswordPolicy(passwordPolicy);
        }

        /// <summary>
        /// Update a selected passwordPolicy with the given passwordPolicyName and passwordPolicyValue.
        /// </summary>
        /// <param name="passwordPolicyType">Type of password policy.</param>
        /// <param name="passwordPolicyValue">Value of password policy.</param>
        public static int UpdatePasswordPolicy(CWXPasswordPolicyConstant passwordPolicyType, string passwordPolicyValue)
        {
            CWXPasswordPolicyManager.EnsureEnabled();
            return CWXPasswordPolicyManager.Provider.UpdatePasswordPolicy(passwordPolicyType, passwordPolicyValue);
        }

        /// <summary>
        /// Get a list of all PasswordPolicy from datasource.    
        /// </summary>
        /// <returns>A System.Collections.Generic.List&lt;CWXPasswordPolicy&gt;</returns>
        public static List<CWXPasswordPolicy> GetPasswordPolicies()
        {
            CWXPasswordPolicyManager.EnsureEnabled();
            return CWXPasswordPolicyManager.Provider.GetPasswordPolicies();
        }
        /// <summary>
        /// Get an instant of CWXPasswordPolicy that is available in the password setting module by the given passwordPolicyType.
        /// </summary>
        /// <param name="passwordPolicyType">CWXPasswordPolicyConstant</param>
        /// <returns>Returns an instant of CWXPasswordPolicy if it's available, otherwise returns null.</returns>
        public static CWXPasswordPolicy GetAvailPasswordPolicy(CWXPasswordPolicyConstant passwordPolicyType)
        {
            CWXPasswordPolicyManager.EnsureEnabled();
            return CWXPasswordPolicyManager.Provider.GetAvailPasswordPolicy(passwordPolicyType);
        }

        public static CWXPasswordPolicy ValidatePasswordSettingsAndReturnViolatedPolicy(string rawPassword, object userId)
        {
            CWXPasswordPolicyManager.EnsureEnabled();
            return CWXPasswordPolicyManager.Provider.ValidatePasswordSettingsAndReturnViolatedPolicy(rawPassword, userId);
        }

        public static List<CWXPasswordPolicy> ValidatePasswordSettingsAndReturnViolatedPolicyList(string rawPassword, object userId)
        {
            CWXPasswordPolicyManager.EnsureEnabled();
            return CWXPasswordPolicyManager.Provider.ValidatePasswordSettingsAndReturnViolatedPolicyList(rawPassword, userId);
        }

        public static bool ValidatePreviousPasswordsAreSame(string newPassword, object userId, int times)
        {
            CWXPasswordPolicyManager.EnsureEnabled();
            return CWXPasswordPolicyManager.Provider.ValidatePreviousPasswordsAreSame(newPassword, userId, times);
        }

        public static bool ValidateUserNotInUse(string userName, int availableDays)
        {

            CWXPasswordPolicyManager.EnsureEnabled();
            return CWXPasswordPolicyManager.Provider.ValidateUserNotInUse(userName, availableDays);
        }
        public static bool NeedChangePassword(string userName, int availableDays)
        {

            CWXPasswordPolicyManager.EnsureEnabled();
            return CWXPasswordPolicyManager.Provider.NeedChangePassword(userName, availableDays);
        }

		/// <summary>
		/// Checks the password expiry policy.
		/// </summary>
		/// <param name="lastPasswordChangedDate">The date that the password last to be changed.</param>
		/// <param name="renewPasswordDays">The number of days for renewing password.</param>
		/// <param name="forceChangePasswordDays">The number of days for forcing change password.</param>
		/// <returns>Returns a CWXForcePasswordExpiryConstant value</returns>
		public static CWXForcePasswordExpiryConstant CheckPasswordExpiry(DateTime lastPasswordChangedDate, int renewPasswordDays, int forceChangePasswordDays)
		{
			CWXPasswordPolicyManager.EnsureEnabled();
			return CWXPasswordPolicyManager.Provider.CheckPasswordExpiry(lastPasswordChangedDate, renewPasswordDays, forceChangePasswordDays);
		}

		/// <summary>
		/// Gets the number of remain days that the password will expire.
		/// </summary>
		/// <param name="userName">The user name.</param>
		/// <returns></returns>
		public static int GetPasswordExpiredRemainDays(DateTime lastPasswordChangedDate)
		{
			CWXPasswordPolicyManager.EnsureEnabled();
			return CWXPasswordPolicyManager.Provider.GetPasswordExpiredRemainDays(lastPasswordChangedDate);
		}
        public static int GetBeforePasswordExpiryWarning()
        {
            return CWXPasswordPolicyManager.Provider.GetBeforePasswordExpiryDays();
        }
        #endregion
    }
}
