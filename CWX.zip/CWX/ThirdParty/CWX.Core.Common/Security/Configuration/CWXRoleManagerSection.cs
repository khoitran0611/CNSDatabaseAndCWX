using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CWX.Core.Common.Security.Configuration
{
    class CWXRoleManagerSection : ConfigurationSection
    {
        private static ConfigurationPropertyCollection _properties;
        private static readonly ConfigurationProperty _propProviders;
        private static readonly ConfigurationProperty _propDefaultProvider;
        private static readonly ConfigurationProperty _propEnabled;

        static CWXRoleManagerSection()
        {
            _propEnabled = new ConfigurationProperty("enabled", typeof(bool), false, ConfigurationPropertyOptions.None);
            _propProviders = new ConfigurationProperty("providers", typeof(ProviderSettingsCollection), null, ConfigurationPropertyOptions.None);
            _propDefaultProvider = new ConfigurationProperty("defaultProvider", typeof(string), "CWXRoleProvider", null, new StringValidator(1), ConfigurationPropertyOptions.None);

            CWXRoleManagerSection._properties = new ConfigurationPropertyCollection();
            CWXRoleManagerSection._properties.Add(_propEnabled);
            CWXRoleManagerSection._properties.Add(_propDefaultProvider);
            CWXRoleManagerSection._properties.Add(_propProviders);
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get
            {
                return CWXRoleManagerSection._properties;
            }
        }

        [ConfigurationProperty("providers")]
        public ProviderSettingsCollection Providers
        {
            get 
            {
                return (ProviderSettingsCollection)base[CWXRoleManagerSection._propProviders];
            }
        }

        [ConfigurationProperty("defaultProvider", DefaultValue = "CWXRoleProvider"), StringValidator(MinLength = 1)] 
        public string DefaultProvider
        {
            get 
            {
                return (string)base[CWXRoleManagerSection._propDefaultProvider];
            }
            set 
            {
                base[CWXRoleManagerSection._propDefaultProvider] = value; 
            }
        }

        [ConfigurationProperty("enabled", DefaultValue = false)]
        public bool Enabled
        {
            get
            {
                return (bool)base[CWXRoleManagerSection._propEnabled];
            }
            set
            {
                base[CWXRoleManagerSection._propEnabled] = value;
            }
        }
    }
}
