using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CWX.Core.Common.Security.Configuration
{
    class CWXPasswordPolicyManagerSection: ConfigurationSection
    {
        private static ConfigurationPropertyCollection _properties;
        private static readonly ConfigurationProperty _propProviders;
        private static readonly ConfigurationProperty _propDefaultProvider;
        private static readonly ConfigurationProperty _propEnabled;

        static CWXPasswordPolicyManagerSection()
        {
            _propEnabled = new ConfigurationProperty("enabled", typeof(bool), false, ConfigurationPropertyOptions.None);
            _propProviders = new ConfigurationProperty("providers", typeof(ProviderSettingsCollection), null, ConfigurationPropertyOptions.None);
            _propDefaultProvider = new ConfigurationProperty("defaultProvider", typeof(string), "CWXPasswordPolicyProvider", null, new StringValidator(1), ConfigurationPropertyOptions.None);

            CWXPasswordPolicyManagerSection._properties = new ConfigurationPropertyCollection();
            CWXPasswordPolicyManagerSection._properties.Add(_propEnabled);
            CWXPasswordPolicyManagerSection._properties.Add(_propDefaultProvider);
            CWXPasswordPolicyManagerSection._properties.Add(_propProviders);
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get
            {
                return CWXPasswordPolicyManagerSection._properties;
            }
        }

        [ConfigurationProperty("providers")]
        public ProviderSettingsCollection Providers
        {
            get 
            {
                return (ProviderSettingsCollection)base[CWXPasswordPolicyManagerSection._propProviders];
            }
        }

        [ConfigurationProperty("defaultProvider", DefaultValue = "CWXPasswordPolicyProvider"), StringValidator(MinLength = 1)] 
        public string DefaultProvider
        {
            get 
            {
                return (string)base[CWXPasswordPolicyManagerSection._propDefaultProvider];
            }
            set 
            {
                base[CWXPasswordPolicyManagerSection._propDefaultProvider] = value; 
            }
        }

        [ConfigurationProperty("enabled", DefaultValue = false)]
        public bool Enabled
        {
            get
            {
                return (bool)base[CWXPasswordPolicyManagerSection._propEnabled];
            }
            set
            {
                base[CWXPasswordPolicyManagerSection._propEnabled] = value;
            }
        }
    }
}
