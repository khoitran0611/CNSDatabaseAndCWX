using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CWX.Core.Common.Security.Configuration
{
    class CWXPermissionManagerSection : ConfigurationSection
    {
        private static ConfigurationPropertyCollection m_properties;
        private static readonly ConfigurationProperty m_propProviders;
        private static readonly ConfigurationProperty m_propDefaultProvider;
        private static readonly ConfigurationProperty m_propEnabled;

        static CWXPermissionManagerSection()
        {
            m_propEnabled = new ConfigurationProperty("enabled", typeof(bool), false, ConfigurationPropertyOptions.None);
            m_propProviders = new ConfigurationProperty("providers", typeof(ProviderSettingsCollection), null, ConfigurationPropertyOptions.None);
            m_propDefaultProvider = new ConfigurationProperty("defaultProvider", typeof(string), "CWXRoleProvider", null, new StringValidator(1), ConfigurationPropertyOptions.None);

            CWXPermissionManagerSection.m_properties = new ConfigurationPropertyCollection();
            CWXPermissionManagerSection.m_properties.Add(m_propEnabled);
            CWXPermissionManagerSection.m_properties.Add(m_propDefaultProvider);
            CWXPermissionManagerSection.m_properties.Add(m_propProviders);
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get
            {
                return CWXPermissionManagerSection.m_properties;
            }
        }

        [ConfigurationProperty("providers")]
        public ProviderSettingsCollection Providers
        {
            get 
            {
                return (ProviderSettingsCollection)base[CWXPermissionManagerSection.m_propProviders];
            }
        }

        [ConfigurationProperty("defaultProvider", DefaultValue = "CWXPermissionProvider"), StringValidator(MinLength = 1)] 
        public string DefaultProvider
        {
            get 
            {
                return (string)base[CWXPermissionManagerSection.m_propDefaultProvider];
            }
            set 
            {
                base[CWXPermissionManagerSection.m_propDefaultProvider] = value; 
            }
        }

        [ConfigurationProperty("enabled", DefaultValue = false)]
        public bool Enabled
        {
            get
            {
                return (bool)base[CWXPermissionManagerSection.m_propEnabled];
            }
            set
            {
                base[CWXPermissionManagerSection.m_propEnabled] = value;
            }
        }
    }
}
