using System;
using System.Collections.Generic;
using System.Configuration.Provider;

namespace CWX.Core.Common.Security
{
    public class CWXPasswordPolicyProviderCollection: ProviderCollection
    {
        public new CWXPasswordPolicyProvider this[string name]
        {
            get { return (CWXPasswordPolicyProvider)base[name]; }
        }

        /// <summary>
        /// Adds a passwordPolicy provider to the collection. 
        /// </summary>
        /// <param name="provider">The passwordPolicy provider to add to the collection.</param>
        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");

            if (!(provider is CWXPasswordPolicyProvider))
                throw new ArgumentException
                    ("Invalid provider type", "provider");

            base.Add(provider);
        }
    }
}
