using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Principal;

namespace CWX.Core.Common.Security
{
    /// <summary>
    /// Defines identity of user.
    /// </summary>
    /// <history>
    ///     2008/05/24  [Binh Truong]   Add Fullname property.
    ///     2008/07/25  [Thao Nguyen]   Add DbConnectionName property.
    /// </history>
	[Serializable]
    public class CWXIdentity : IIdentity
    {
        #region Constructor
       
        /// <summary>
        /// Create an instance of CWXIdentity.
        /// </summary>
        /// <param name="userID">User ID.</param>
        /// <param name="name">Username.</param>
        /// <param name="fullname">Fullname.</param>
        public CWXIdentity(int userID, string name, string fullname)
        {
            _userID = userID;
            _name = name;
            _fullname = fullname;
        }

        #endregion

        #region Properties

        private int _userID;
        /// <summary>
        /// Represents UserID or EmployeeID.
        /// </summary>
        public int UserID
        {
            get { return _userID; }
        }

        private string _fullname = string.Empty;
        /// <summary>
        /// Represents fullname of current identity.
        /// </summary>
        public string Fullname
        {
            get { return _fullname; }
            set { _fullname = value; }
        }

        private string _dbConnectionName = string.Empty;
        /// <summary>
        /// Represents fullname of current identity.
        /// </summary>
        public string DbConnectionName
        {
            get { return _dbConnectionName; }
            set { _dbConnectionName = value; }
        }
        #endregion

        #region IIdentity Members

        /// <summary>
        /// Gets the type of authentication used.
        /// </summary>
        /// <returns>
        /// The type of authentication used to identify the user.
        /// </returns>
        public string AuthenticationType
        {
            get
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Gets a value that indicates whether the user has been authenticated.
        /// </summary>
        /// <returns>
        /// True if the user was authenticated; otherwise, false.
        /// </returns>
        public bool IsAuthenticated
        {
            get
            {
                return true;
            }
        }

        private string _name;
        /// <summary>
        /// Gets the username of the current user.
        /// </summary>
        /// <returs>
        /// The username of the user on whose behalf the code is running.
        /// </returs>
        public string Name
        {
            get
            {
                return _name;
            }
        }

        #endregion
    }
}
