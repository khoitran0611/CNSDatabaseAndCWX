using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration.Provider;

namespace CWX.Core.Common.Security
{
    public abstract class CWXPermissionProvider: ProviderBase
    {
        #region Permission Group

        public abstract CWXPermissionGroupConstant[] GetPermissionGroupContants();

        public abstract CWXPermissionGroup[] GetPermissionGroups();

        #endregion

        #region User Permission

        public abstract CWXPermission[] GetAllUserPermissions();

        public abstract CWXPermission[] GetAvailUserPermissionsByPermissionGroup(int userID, CWXPermissionGroupConstant permissionGroupConstant);

        public abstract CWXPermission[] GetGrantedUserPermissionsByPermissionGroup(int userID, CWXPermissionGroupConstant permissionGroupConstant);

        public abstract CWXPermissionConstant[] GetUserPermissions(int userID);

        public abstract string[] GetAvailUserPermissionsString(int userID);

        public abstract string[] GetGrantedUserPermissionsString(int userID);

        public abstract void AddUserPermissions(int userID, CWXPermissionConstant permission);

        public abstract void RemoveUserPermissions(int userID, CWXPermissionConstant permission);

        public abstract void RemoveAllUserPermissions(int userID);

        #endregion

        #region Role Permission

        public abstract CWXPermission[] GetAllPermissions();

        public abstract CWXPermission[] GetAvailRolePermissionsByPermissionGroup(int roleID, CWXPermissionGroupConstant permissionGroupConstant);

        public abstract CWXPermission[] GetGrantedRolePermissionsByPermissionGroup(int roleID, CWXPermissionGroupConstant permissionGroupConstant);

        public abstract CWXPermissionConstant[] GetRolePermissions(int roleID);

        public abstract string[] GetAvailRolePermissionsString(int roleID);

        public abstract string[] GetGrantedRolePermissionsString(int roleID);

        public abstract void AddRolePermissions(int roleID, CWXPermissionConstant permission);

        public abstract void RemoveRolePermissions(int roleID, CWXPermissionConstant permission);

        public abstract void RemoveAllRolePermissions(int roleID);

        #endregion

    }
}
