using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Security
{
    public class CWXPasswordPolicy
    {
        #region Properties
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _value;

        public string Value
        {
            get { return _value; }
            set { _value = value; }
        }

        private CWXPasswordPolicyConstant _type;

        public CWXPasswordPolicyConstant Type
        {
            get { return _type; }
            set { _type = value; }
        }
        private bool _isViolated;

        public bool IsViolated
        {
            get { return _isViolated; }
            set { _isViolated = value; }
        }
	
	
        #endregion

        #region Constructor
        public CWXPasswordPolicy()
        {

        }
        #endregion
    }
}
