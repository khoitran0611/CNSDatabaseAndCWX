using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Security;
using System.Data;
using System.Collections.ObjectModel;

namespace CWX.Core.Common.Security
{
    public abstract class CWXMembershipProvider : MembershipProvider
    {
        #region Properties

        public override string ApplicationName
        {
            get
            {
                throw new NotSupportedException();
            }
            set
            {
                throw new NotSupportedException();
            }
        }

        public override int MaxInvalidPasswordAttempts
        {
            get { throw new NotSupportedException(); }
        }

        public override int MinRequiredNonAlphanumericCharacters
        {
            get { return 0; }
        }

        public override int MinRequiredPasswordLength
        {
            get { return 0; }
        }

        public override int PasswordAttemptWindow
        {
            get { throw new NotSupportedException(); }
        }

        public override MembershipPasswordFormat PasswordFormat
        {
            get
            {
                throw new NotSupportedException();
            }
        }

        public override string PasswordStrengthRegularExpression
        {
            get
            {
                throw new NotSupportedException();
            }
        }

        public override bool RequiresQuestionAndAnswer
        {
            get { throw new NotSupportedException(); }
        }

        public override bool RequiresUniqueEmail
        {
            get { throw new NotSupportedException(); }
        }

        public override bool EnablePasswordReset
        {
            get { throw new NotSupportedException(); }
        }

        public override bool EnablePasswordRetrieval
        {
            get { throw new NotSupportedException(); }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get user by permission.
        /// </summary>
        /// <returns>DataTable with fields: UserID, Fullname</returns>
        public abstract DataTable GetUserByPermission(CWXPermissionConstant permission);

        /// <summary>
        /// Get LoginLogInfo.
        /// </summary>
        /// <history>
        ///     2008/08/12  [Binh Truong]   Init version.
        /// </history>
        public abstract LoginLogInfo GetLoginLogInfo(int userID, string dbConnectionName);
        
        /// <summary>
        /// Get GetLoggedInUser.
        /// </summary>
        /// <history>
        ///     2008/09/06  [Thuy Nguyen]   Init version.
        /// </history>
        public abstract DataTable GetLoggedInUser(string employeeIDString, bool isGetBySupervisor, string dbConnectionName);

        /// <summary>
        /// Fill list LoginLogInfo.
        /// </summary>
        /// <history>
        ///     2008/08/26  [Binh Truong]   Init version.
        /// </history>
        public abstract Collection<LoginLogInfo> FillListLoginLogInfo(string dbConnectionName, int pageSize, int pageIndex, out int rowCount);

        /// <summary>
        /// Log login and working time information
        /// </summary>
        public abstract void LoginLog(int userID, DateTime loginDate, DateTime logoutDate, int duration, string dbName);

        public abstract void UpdateLoginLog(int userID, DateTime loginDate, DateTime logoutDate, int duration, string dbName);

        public abstract void LoginAttemptsLog(string loginUser, DateTime loginDate, string ipAddress, string loginStatus, string reason);

        /// <summary>
        /// Update user last activity time.
        /// </summary>
        /// <remarks>
        /// The LastActivity will be updated repeatedly while user is working.
        /// </remarks>
        /// <history>
        ///     2008/07/11  [Binh Truong]   Init version.
        /// </history>
        public abstract void UpdateLastActivity(string username);

        /// <summary>
        /// Update user online status.
        /// </summary>
        /// <param name="userIsOnlineTimeWindow">
        /// The number of minutes after the last-activity date/time stamp for a user during 
        /// which the user is considered online.
        /// </param>
        public abstract void UpdateUserOnlineStatus(string username, int userIsOnlineTimeWindow);

        /// <summary>
        /// Sets user online status.
        /// </summary>
        /// <history>
        ///     2008/07/14  [Binh Truong]   Init version.
        /// </history>
        public abstract void SetUserOnlineStatus(string username, bool isOnline);

        /// <summary>
        /// Deactive user by user ID.
        /// </summary>
        /// <history>
        ///     2008/08/15  [Binh Truong]   Init version.
        /// </history>
        public abstract bool DeactiveUser(int userID);

        /// <summary>
        /// Active user by user ID.
        /// </summary>
        /// <history>
        ///     2008/08/19  [Binh Truong]   Init version.
        /// </history>
        public abstract bool ActiveUser(int userID);

        /// <summary>
        /// Active all users.
        /// </summary>
        /// <history>
        ///     2008/08/19  [Binh Truong]   Init version.
        /// </history>
        public abstract bool ActiveAll();

        public abstract bool AssignCMS(string userIDs, string cmsID);

        #endregion

        #region Override Methods

        #region Password's Methods

        /// <summary>
        /// Processes a request to update the password for a membership user.
        /// </summary>
        /// <param name="username">The user to update the password for.</param>
        /// <param name="oldPassword">The current password for the specified user.</param>
        /// <param name="newPassword">The new password for the specified user.</param>
        /// <returns>true if the password was updated successfully; otherwise, false.</returns>
        public override bool ChangePassword(string username, string oldPassword, string newPassword)
        {
            return false;
        }

        /// <summary>
        /// Processes a request to update the password for a membership user.
        /// </summary>
        /// <param name="userID">The user to update the password for.</param>
        /// <param name="newPassword">The new password for the specified user.</param>
        /// <returns>true if the password was updated successfully; otherwise, false.</returns>
        public abstract bool ChangePassword(int userID, string newPassword);

        /// <summary>
        /// Processes a request to update the password for a membership user.
        /// </summary>
        /// <param name="username">The user to update the password for.</param>
        /// <param name="newPassword">The new password for the specified user.</param>
        /// <returns>true if the password was updated successfully; otherwise, false.</returns>
        public abstract bool ChangePassword(string username, string newPassword);

        /// <summary>
        /// Processes a request to update the password question and answer for a membership user.
        /// </summary>
        /// <param name="username">The user to change the password question and answer for.</param>
        /// <param name="password">The password for the specified user.</param>
        /// <param name="newPasswordQuestion">The new password question for the specified user.</param>
        /// <param name="newPasswordAnswer">The new password answer for the specified user.</param>
        /// <returns>true if the password question and answer are updated successfully; otherwise, false</returns>
        public override bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion, string newPasswordAnswer)
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Gets the password for the specified user name from the data source.
        /// </summary>
        /// <param name="username">The user to retrieve the password for.</param>
        /// <param name="answer">The password answer for the user.</param>
        /// <returns>The password for the specified user name.</returns>
        public override string GetPassword(string username, string answer)
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Resets a user's password to a new, automatically generated password.
        /// </summary>
        /// <param name="username">The user to reset the password for.</param>
        /// <param name="answer">The password answer for the specified user.</param>
        /// <returns>The new password for the specified user.</returns>
        public override string ResetPassword(string username, string answer)
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Processes a request to reset the password of the given userID and newPassword 
        /// then resets ChangedPasswordDate and ChangePasswordCount for a membership user.
        /// </summary>
        /// <param name="userID">The userID to update the password for.</param>
        /// <param name="newPassword">The new password for the specified user.</param>
        /// <returns>true if the password was updated successfully; otherwise, false.</returns>
        public abstract bool CWXResetPassword(int userID, string newPassword);

        /// <summary>
        /// Processes a request to reset the password of the given username and newPassword 
        /// then resets ChangedPasswordDate and ChangePasswordCount for a membership user.
        /// </summary>
        /// <param name="username">The user to update the password for.</param>
        /// <param name="newPassword">The new password for the specified user.</param>
        /// <returns>true if the password was updated successfully; otherwise, false.</returns>
        public abstract bool CWXResetPassword(string username, string newPassword);

        /// <summary>
        /// Password encrypt algorithm of CWX version 6 and below.
        /// </summary>
        /// <param name="pass">Raw password string.</param>
        /// <param name="userID">UserID.</param>
        /// <returns>Encrypt password string.</returns>
        [Obsolete("This password encrypt algorithm is obsolete. Use the overload method 'string EncryptPassword(string pass, string salt, int passwordFormat)' instead.", false)]
        public abstract string EncryptPassword(string pass, int userID);

        public abstract string EncryptPassword(string pass,string salt,int passwordFormat);
        #endregion

        #region MembershipUser

        /// <summary>
        /// Verifies that the specified user name and password exist in the data source.
        /// </summary>
        /// <param name="username">The name of the user to validate.</param>
        /// <param name="password">The password for the specified user.</param>
        /// <returns>true if the specified username and password are valid; otherwise, false.</returns>
        public override bool ValidateUser(string username, string password)
        {
            return false;
        }

        /// <summary>
        /// Gets information from the data source for a user. Provides an option 
        /// to update the last-activity date/time stamp for the user.
        /// </summary>
        /// <param name="username">The name of the user to get information for.</param>
        /// <param name="password">The password of the user to get information for.</param>
        /// <returns>
        /// A System.Web.Security.MembershipUser object populated with 
        /// the specified user's information from the data source.
        /// </returns>
        public abstract MembershipUser GetUser(string username, string password);

        /// <summary>
        /// Gets information from the data source for a user. Provides an option 
        /// to update the last-activity date/time stamp for the user.
        /// </summary>
        /// <param name="username">The name of the user to get information for.</param>
        /// <param name="userIsOnline">
        /// true to update the last-activity date/time stamp for the user; 
        /// false to return user information without updating the last-activity 
        /// date/time stamp for the user.
        /// </param>
        /// <returns>
        /// A System.Web.Security.MembershipUser object populated with 
        /// the specified user's information from the data source.
        /// </returns>
        public override MembershipUser GetUser(string username, bool userIsOnline)
        {
            return null;
        }

        /// <summary>
        /// Gets information from the data source for a user based on the unique identifier 
        /// for the membership user. Provides an option to update the last-activity date/time 
        /// stamp for the user.
        /// </summary>
        /// <param name="providerUserKey">The unique identifier for the membership user to get 
        /// information for.</param>
        /// <param name="userIsOnline">
        /// true to update the last-activity date/time stamp for the user; 
        /// false to return user information without updating the last-activity 
        /// date/time stamp for the user.
        /// </param>
        /// <returns>
        /// A System.Web.Security.MembershipUser object populated with the specified 
        /// user's information from the data source.
        /// </returns>
        public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Gets the user name associated with the specified e-mail address.
        /// </summary>
        /// <param name="email">The e-mail address to search for.</param>
        /// <returns>
        /// The user name associated with the specified e-mail address. 
        /// If no match is found, return null.
        /// </returns>
        public override string GetUserNameByEmail(string email)
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Adds a new membership user to the data source.
        /// </summary>
        /// <param name="userID">The user id for the new user.</param>
        /// <param name="username">The user name for the new user.</param>
        /// <param name="password">The password for the new user.</param>
        /// <param name="fullName">The full name for the new user.</param>
        /// <param name="email">The e-mail address for the new user.</param>
        /// <param name="comment">The comment for the new user.</param>
        /// <param name="roleID">The role id for the new user.</param>
        /// <returns>
        /// A System.Web.Security.MembershipUser object populated with the 
        /// information for the newly created user.
        /// </returns>
        public abstract MembershipUser CreateUser(string username, string password, string fullName, string email, string comment, int roleID,string salt);

        /// <summary>
        /// Adds a new membership user to the data source.
        /// </summary>
        /// <param name="username">The user name for the new user.</param>
        /// <param name="password">The password for the new user.</param>
        /// <param name="email">The e-mail address for the new user.</param>
        /// <param name="passwordQuestion">The password question for the new user.</param>
        /// <param name="passwordAnswer">The password answer for the new user</param>
        /// <param name="isApproved">Whether or not the new user is approved to be validated.</param>
        /// <param name="providerUserKey">The unique identifier from the membership data source for the user.</param>
        /// <param name="status">
        /// A System.Web.Security.MembershipCreateStatus enumeration value indicating whether 
        /// the user was created successfully.
        /// </param>
        /// <returns>
        /// A System.Web.Security.MembershipUser object populated with the information for the newly created user.
        /// </returns>
        public override MembershipUser CreateUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, object providerUserKey, out MembershipCreateStatus status)
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Removes a user from the membership data source.
        /// </summary>
        /// <param name="username">The name of the user to delete.</param>
        /// <param name="deleteAllRelatedData">
        /// true to delete data related to the user from the database; false to leave data related to 
        /// the user in the database.
        /// </param>
        /// <returns>true if the user was successfully deleted; otherwise, false.</returns>
        public override bool DeleteUser(string username, bool deleteAllRelatedData)
        {
            return false;
        }

        /// <summary>
        /// Removes a user from the membership data source.
        /// </summary>
        /// <param name="userID">The id of user to delete.</param>
        /// <returns>true if the user was successfully deleted; otherwise, false.</returns>
        public abstract bool DeleteUser(int userID);

        /// <summary>
        /// Gets a collection of membership users where the e-mail address contains the 
        /// specified e-mail address to match.
        /// </summary>
        /// <param name="emailToMatch"></param>
        /// <param name="pageIndex">The index of the page of results to return. pageIndex is zero-based.</param>
        /// <param name="pageSize">The size of the page of results to return.</param>
        /// <param name="totalRecords">The total number of matched users.</param>
        /// <returns>
        /// A System.Web.Security.MembershipUserCollection collection that contains a
        ///  page of pageSizeSystem.Web.Security.MembershipUser objects beginning at the
        ///  page specified by pageIndex.
        /// </returns>
        public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Gets a collection of membership users where the user name contains the specified
        ///  user name to match.
        /// </summary>
        /// <param name="usernameToMatch">The user name to search for.</param>
        /// <param name="pageIndex">The index of the page of results to return. pageIndex is zero-based.</param>
        /// <param name="pageSize">The size of the page of results to return.</param>
        /// <param name="totalRecords">The total number of matched users.</param>
        /// <returns>
        /// A System.Web.Security.MembershipUserCollection collection that contains a
        ///  page of pageSizeSystem.Web.Security.MembershipUser objects beginning at the
        ///  page specified by pageIndex.
        /// </returns>
        public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Get a collecion of membership users by role
        /// </summary>
        /// <param name="roleID"></param>
        /// <returns></returns>
        public abstract MembershipUserCollection FindUsersByRole(int roleID);

        /// <summary>
        /// Gets a collection of all the users in the data source in pages of data.
        /// </summary>
        /// <param name="pageIndex">The index of the page of results to return. pageIndex is zero-based.</param>
        /// <param name="pageSize">The size of the page of results to return.</param>
        /// <param name="totalRecords">The total number of matched users.</param>
        /// <returns>
        /// A System.Web.Security.MembershipUserCollection collection that contains a
        ///  page of pageSizeSystem.Web.Security.MembershipUser objects beginning at the
        ///  page specified by pageIndex.
        /// </returns>
        public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Gets the number of users currently accessing the application.
        /// </summary>
        /// <returns>The number of users currently accessing the application.</returns>
        public override int GetNumberOfUsersOnline()
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Unlock All users in the datasource
        /// </summary>
        /// <returns></returns>
        public abstract bool UnlockAll();

        /// <summary>
        /// Clears a lock so that the membership user can be validated.
        /// </summary>
        /// <param name="userName">The membership user to clear the lock status for.</param>
        /// <returns>true if the membership user was successfully unlocked; otherwise, false.</returns>
        public override bool UnlockUser(string userName)
        {
            return false;
        }

        /// <summary>
        /// Clears a lock so that the membership user can be validated.
        /// </summary>
        /// <param name="userID">The id of membership user to clear the lock status for.</param>
        /// <returns>true if the membership user was successfully unlocked; otherwise, false.</returns>
        public abstract bool UnlockUser(int userID);

        /// <summary>
        /// Lock a user.
        /// </summary>
        /// <param name="userName">The membership user to clear the lock status for.</param>
        /// <returns>true if the membership user was successfully locked; otherwise, false.</returns>
        public abstract bool LockUser(string userName);

        /// <summary>
        /// Lock a user.
        /// </summary>
        /// <param name="userID">The id of membership user to clear the lock status for.</param>
        /// <returns>true if the membership user was successfully locked; otherwise, false.</returns>
        public abstract bool LockUser(int userID);

        /// <summary>
        /// Updates information about a user in the data source.
        /// </summary>
        /// <param name="userID">id for the updated user</param>
        /// <param name="username">username for the updated user</param>
        /// <param name="fullName">fullName for the updated user</param>
        /// <param name="email">emailfor the updated user</param>
        /// <param name="comment">comment for the updated user</param>
        /// <param name="roleID">roleID for the updated user</param>
        public abstract void UpdateUser(int userID, string username, string fullName, string email, string comment, int roleID);

        /// <summary>
        /// Updates information about a user in the data source.
        /// </summary>
        /// <param name="user">
        /// A System.Web.Security.MembershipUser object that represents the user to update
        ///  and the updated information for the user.
        /// </param>
        public override void UpdateUser(MembershipUser user)
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Get userId of a user.
        /// </summary>
        /// <param name="userName">userName for the selected user.</param>
        /// <returns>the id of the selected user.</returns>
        public abstract int GetUserID(string userName);

        /// <summary>
        /// Get roleId of a user
        /// </summary>
        /// <param name="userID">id of the selected user.</param>
        /// <returns>the roleId of the selected user.</returns>
        public abstract int GetUserRoleID(int userID);

        /// <summary>
        /// Get a list of locked user and fill into a dataset
        /// </summary>
        /// <param name="pageIndex">The index of the page of results to return. pageIndex is zero-based.</param>
        /// <param name="pageSize">The size of the page of results to return.</param>
        /// <param name="rowCount">The total number of matched users.</param>
        /// <returns>System.Data.DataSet</returns>
        public abstract DataSet GetLockedUserDataSet(int pageIndex, int pageSize, out int rowCount);

        

        #endregion

        #endregion

    }
}
