using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Principal;
using Microsoft.Practices.EnterpriseLibrary.Security;

namespace CWX.Core.Common.Security
{
    public class CWXAuthorizationManager
    {
        public static bool Authorize(IPrincipal principal, CWXPermissionConstant permission)
        {
            IAuthorizationProvider authorizationProvider = AuthorizationFactory.GetAuthorizationProvider();
            return authorizationProvider.Authorize(principal, Enum.GetName(typeof(CWXPermissionConstant), permission));
        }
    }
}
