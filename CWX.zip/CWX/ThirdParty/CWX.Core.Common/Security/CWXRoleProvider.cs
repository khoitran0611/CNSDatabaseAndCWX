using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration.Provider;
using System.Collections.ObjectModel;


namespace CWX.Core.Common.Security
{
    public abstract class CWXRoleProvider : ProviderBase
    {
        /// <summary>
        /// Gets or sets the name of the application to store and retrieve role information for.
        /// </summary>
        public abstract string ApplicationName { get; set;}

        /// <summary>
        /// Adds a new role to the data source.
        /// </summary>
        /// <param name="role">A CWX.Core.Common.Security.CWXRole to add to the datasource.</param>
        public abstract void CreateRole(CWXRole role);

        /// <summary>
        /// Adds a new role to the data source.
        /// </summary>
        /// <param name="roleName">The name for the new role.</param>
        /// <param name="rolePermissions">The permissions for the new role.</param>
        public abstract void CreateRole(string roleName);

        /// <summary>
        /// Adds a new role to the data source.
        /// </summary>
        /// <param name="roleName">The name for the new role.</param>
        /// <param name="permissions">The permissions for the new role.</param>
        public abstract void CreateRole(string roleName, Collection<CWXPermission> permissions);

        /// <summary>
        /// Update a selected role.
        /// </summary>
        /// <param name="role">A CWX.Core.Common.Security.CWXRole to update.</param>
        public abstract void UpdateRole(CWXRole role);

        /// <summary>
        /// Update a selected role.
        /// </summary>
        /// <param name="roleID">The id for the selected role.</param>
        /// <param name="roleName">The name for the selected role.</param>
        /// <param name="roleOrder">The order for the selected role.</param>
        /// <param name="permissions">The new permissions for the selected role.</param>
        public abstract void UpdateRole(int roleID, string roleName, int roleOrder, Collection<CWXPermission> permissions);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="roleID"></param>
        public abstract void MoveUp(int roleID);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="roleID"></param>
        public abstract void MoveDown(int roleID);

        /// <summary>
        /// Delete a selected role.
        /// </summary>
        /// <param name="role">A CWX.Core.Common.Security.CWXRole to delete.</param>
        public abstract void DeleteRole(CWXRole role);

        /// <summary>
        /// Delete a selected role.
        /// </summary>
        /// <param name="roleID">The id for the selected role.</param>
        public abstract void DeleteRole(int roleID);

        /// <summary>
        /// SoftDelete a selected role.
        /// </summary>
        /// <param name="role">A CWX.Core.Common.Security.CWXRole to delete.</param>
        public abstract void SoftDeleteRole(CWXRole role);

        /// <summary>
        /// SoftDelete a selected role.
        /// </summary>
        /// <param name="roleID">The id for the selected role.</param>
        public abstract void SoftDeleteRole(int roleID);

        /// <summary>
        /// Get a role from the datasource.
        /// </summary>
        /// <param name="roleID">The id for the selected role.</param>
        /// <returns>A CWX.Core.Common.Security.CWXRole</returns>
        public abstract CWXRole GetRole(int roleID);

        /// <summary>
        /// Get a role from the datasource.
        /// </summary>
        /// <param name="roleName">The Name for the selected role.</param>
        /// <returns>A CWX.Core.Common.Security.CWXRole</returns>
        public abstract CWXRole GetRole(string roleName);

        /// <summary>
        /// Gets a list of all the roles from the datasource.
        /// </summary>
        /// <returns>A System.Collections.Generic.List&lt;CWXRole&gt;</returns>
        public abstract List<CWXRole> GetRoles();

        /// <summary>
        /// Gets a list of the roles by paging from the datasource.
        /// </summary>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>A System.Collections.Generic.List&lt;CWXRole&gt;</returns>
        public abstract List<CWXRole> GetRoles(int pageSize, int pageIndex, out int rowCount);

        /// <summary>
        /// Gets a value indicating whether the specified role name already exists in the role data source.
        /// </summary>
        /// <param name="roleName">The name of the role to search for in the data source.</param>
        /// <returns>true if the role name already exists in the data source for the configured applicationName; otherwise, false. </returns>
        public abstract bool RoleExists(string roleName);

        /// <summary>
        /// Soft delete all roles.
        /// </summary>
        public abstract void SoftDeleteAll();

        /// <summary>
        /// Apply role permissions for all user that have RoleID=roleID
        /// </summary>
        /// <param name="roleID"></param>
        /// <returns></returns>
        public abstract bool ApplyNewRolePermissions(int roleID);
    }
}
