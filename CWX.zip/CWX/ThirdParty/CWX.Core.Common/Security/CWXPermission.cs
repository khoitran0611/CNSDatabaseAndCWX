using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Security
{
    public class CWXPermission
    {
        public CWXPermission()
        {

        }

        public CWXPermission(CWXPermissionConstant permissionType, string permissionName)
        {
            _permissionType = permissionType;
            _permissionName = permissionName;
        }

        private CWXPermissionConstant _permissionType;

        public CWXPermissionConstant PermissionType
        {
            get { return _permissionType; }
            set { _permissionType = value; }
        }

        
        public int PermissionID
        {
            get 
            { 
                return _permissionType.GetHashCode(); 
            }            
        }
	

        private string _permissionName;

        public string PermissionName
        {
            get { return _permissionName; }
            set { _permissionName = value; }
        }
	
	
    }
}
