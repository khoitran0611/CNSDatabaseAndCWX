using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Security;
using System.Data;
using System.Collections.ObjectModel;

namespace CWX.Core.Common.Security
{
    public class CWXMembershipManager
    {
        private static CWXMembershipProvider Provider
        {
            get
            {
                return Membership.Provider as CWXMembershipProvider;
            }
        }

        public static bool ChangePassword(int userID, string newPassword)
        {
            return Provider.ChangePassword(userID, newPassword);
        }

        public static bool ChangePassword(string username, string newPassword)
        {
            return Provider.ChangePassword(username, newPassword);
        }

        public static bool CWXResetPassword(int userID, string newPassword)
        {
            return Provider.CWXResetPassword(userID, newPassword);
        }

        public static bool CWXResetPassword(string username, string newPassword)
        {
            return Provider.CWXResetPassword(username, newPassword);
        }

        /// <summary>
        /// Password encrypt algorithm of CWX version 6 and below.
        /// </summary>
        /// <param name="pass">Raw password string.</param>
        /// <param name="userID">UserID.</param>
        /// <returns>Encrypt password string.</returns>
        [Obsolete("This password encrypt algorithm is obsolete. Use the overload method 'string EncryptPassword(string pass, string salt, int passwordFormat)' instead.", false)]
        public static string EncryptPassword(string rawPassword, int userId)
        { 
            return Provider.EncryptPassword(rawPassword, userId);
        }

        public static string EncryptPassword(string rawPassword, string salt, int passwordFormat)
        {
            return Provider.EncryptPassword(rawPassword,salt,passwordFormat);
        }

        public static MembershipUser GetUser(string username, string password)
        {
            return Provider.GetUser(username, password);
        }

        public static MembershipUser GetUser(object providerUserKey, bool userIsOnline)
        {
            return Provider.GetUser(providerUserKey, userIsOnline);
        }

        public static MembershipUser GetUser(string username, bool userIsOnline)
        {
            return Provider.GetUser(username, userIsOnline);
        }

        public static MembershipUserCollection FindUsersByRole(int roleID)
        {
            return Provider.FindUsersByRole(roleID);
        }

        public static bool ValidateUser(string username, string password)
        {
            return Provider.ValidateUser(username, password);
        }

        public static MembershipUser CreateUser(string username, string password, string fullName, string email, string comment, int roleID, string salt)
        {
            return Provider.CreateUser(username, password, fullName, email, comment, roleID, salt);
        }

        public static int GetUserID(string userName)
        {
            return Provider.GetUserID(userName);
        }

        public static CWXRole GetUserRole(int userID)
        {
            int roleID = Provider.GetUserRoleID(userID);
            return CWXRoleManager.GetRole(roleID);
        }

        public static void UpdateUser(int userID, string username, string fullName, string email, string comment, int roleID)
        {
            Provider.UpdateUser(userID, username, fullName, email, comment, roleID);
        }

        public static bool DeleteUser(int userID)
        {
            return Provider.DeleteUser(userID);
        }

        /// <summary>
        /// Deactive user by user ID.
        /// </summary>
        /// <history>
        ///     2008/08/15  [Binh Truong]   Init version.
        /// </history>
        public static bool DeactiveUser(int userID)
        {
            return Provider.DeactiveUser(userID);
        }

        /// <summary>
        /// Active user by user ID.
        /// </summary>
        /// <history>
        ///     2008/08/19  [Binh Truong]   Init version.
        /// </history>
        public static bool ActiveUser(int userID)
        {
            return Provider.ActiveUser(userID);
        }

        /// <summary>
        /// Active all users.
        /// </summary>
        /// <history>
        ///     2008/08/19  [Binh Truong]   Init version.
        /// </history>
        public static bool ActiveAll()
        {
            return Provider.ActiveAll();
        }

        public static bool UnlockAll()
        {
            return Provider.UnlockAll();
        }

        public static bool UnlockUser(int userID)
        {
            return Provider.UnlockUser(userID);
        }

        public static bool UnlockUser(string username)
        {
            return Provider.UnlockUser(username);
        }

        public static bool LockUser(int userID)
        {
            return Provider.LockUser(userID);
        }

        public static bool LockUser(string username)
        {
            return Provider.LockUser(username);
        }

        public static DataSet GetLockedUserDataSet(int pageIndex, int pageSize, out int rowCount)
        {
            return Provider.GetLockedUserDataSet(pageIndex, pageSize, out rowCount);
        }

        /// <summary>
        /// Get user by permission.
        /// </summary>
        /// <returns>DataTable with fields: UserID, Fullname</returns>
        public static DataTable GetUserByPermission(CWXPermissionConstant permission)
        {
            return Provider.GetUserByPermission(permission);
        }

        /// <summary>
        /// Get LoginLogInfo.
        /// </summary>
        /// <history>
        ///     2008/08/12  [Binh Truong]   Init version.
        /// </history>
        public static LoginLogInfo GetLoginLogInfo(int userID, string dbConnectionName)
        {
            return Provider.GetLoginLogInfo(userID, dbConnectionName);
        }

        /// <summary>
        /// Get GetLoggedInUser.
        /// </summary>
        /// <history>
        ///     2008/09/06  [Thuy Nguyen]   Init version.
        /// </history>
        public static DataTable GetLoggedInUser(string employeeIDString, bool isGetBySupervisor, string dbConnectionName)
        {
            return Provider.GetLoggedInUser(employeeIDString, isGetBySupervisor, dbConnectionName);
        }

        /// <summary>
        /// Fill list LoginLogInfo.
        /// </summary>
        /// <history>
        ///     2008/08/26  [Binh Truong]   Init version.
        /// </history>
        public static Collection<LoginLogInfo> FillListLoginLogInfo(string dbConnectionName, int pageSize, int pageIndex, out int rowCount)
        {
            return Provider.FillListLoginLogInfo(dbConnectionName, pageSize, pageIndex, out rowCount);
        }

        /// <summary>
        /// Log login and working time information
        /// </summary>
        public static void LoginLog(int userID, DateTime loginDate, DateTime logoutDate, int minutesLoggedIn, string dbName)
        {
            Provider.LoginLog(userID, loginDate, logoutDate, minutesLoggedIn, dbName);
        }

        public static void UpdateLoginLog(int userID, DateTime loginDate, DateTime logoutDate, int minutesLoggedIn, string dbName)
        {
            Provider.UpdateLoginLog(userID, loginDate, logoutDate, minutesLoggedIn, dbName);
        }

        public static void LoginAttemptsLog(string loginUser, DateTime loginDate, string ipAddress, string loginStatus, string reason)
        {
            Provider.LoginAttemptsLog(loginUser, loginDate, ipAddress, loginStatus, reason);
        }

        /// <summary>
        /// Update user last activity time.
        /// </summary>
        /// <remarks>
        /// The LastActivity will be updated repeatedly while user is working.
        /// </remarks>
        /// <history>
        ///     2008/07/11  [Binh Truong]   Init version.
        /// </history>
        public static void UpdateLastActivity(string username)
        {
            Provider.UpdateLastActivity(username);
        }

        /// <summary>
        /// Update user online status.
        /// </summary>
        /// <param name="userIsOnlineTimeWindow">
        /// The number of minutes after the last-activity date/time stamp for a user during 
        /// which the user is considered online.
        /// </param>
        /// <history>
        ///     2008/07/11  [Binh Truong]   Init version.
        /// </history>
        public static void UpdateUserOnlineStatus(string username, int userIsOnlineTimeWindow)
        {
            Provider.UpdateUserOnlineStatus(username, userIsOnlineTimeWindow);
        }

        /// <summary>
        /// Sets user online status.
        /// </summary>
        /// <history>
        ///     2008/07/14  [Binh Truong]   Init version.
        /// </history>
        public static void SetUserOnlineStatus(string username, bool isOnline)
        {
            Provider.SetUserOnlineStatus(username, isOnline);
        }

        public static bool AssignCMS(string userIDs, string cmsID)
        {
            return Provider.AssignCMS(userIDs, cmsID);
        }

    }
}
