using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Security
{
    /// <summary>
    /// Represents login information of user.
    /// </summary>
    /// <history>
    ///     2008/08/12  [Binh Truong]   Init version.
    /// </history>
    public class LoginLogInfo
    {
        private int _userID;

        public int UserID
        {
            get { return _userID; }
            set { _userID = value; }
        }

        private DateTime _loginTime;

        public DateTime LoginTime
        {
            get { return _loginTime; }
            set { _loginTime = value; }
        }

        private DateTime _logoutTime;

        public DateTime LogoutTime
        {
            get { return _logoutTime; }
            set { _logoutTime = value; }
        }

        private int _minutesLoggedIn;

        public int MinutesLoggedIn
        {
            get { return _minutesLoggedIn; }
            set { _minutesLoggedIn = value; }
        }

        private string _dbConnectionName;

        public string DBConnectionName
        {
            get { return _dbConnectionName; }
            set { _dbConnectionName = value; }
        }

        private bool _signOn;
        /// <summary>
        /// Gets or sets boolean value indicating whether user online.
        /// </summary>
        public bool SignOn
        {
            get { return _signOn; }
            set { _signOn = value; }
        }

    }
}
