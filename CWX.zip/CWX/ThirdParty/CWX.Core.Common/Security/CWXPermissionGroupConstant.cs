using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Security
{
    public enum CWXPermissionGroupConstant
    {
        ACCESS_MODULE = 1,
        ADMINISTRATOR_FUNCTIONS = 2,
        OTHER_FUNCTIONS = 3,
        //LEGAL_MODULE = 200,
    }
}
