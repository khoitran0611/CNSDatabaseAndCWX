using System;
using System.Collections.Generic;
using System.Text;
using CWX.Core.Common.Security.Configuration;
using System.Configuration.Provider;
using System.Configuration;
using System.Web.Configuration;

namespace CWX.Core.Common.Security
{
    public static class CWXPermissionManager
    {
        private static object _lockObject;
        private static CWXPermissionProvider _permProvider;
        private static CWXPermissionProviderCollection _permProviders;
        private static bool _initialized;
        private static Exception _initializeException;
        private static bool _enabled;
        private static bool _enabledSet;


        static CWXPermissionManager()
        {
            _initialized = false;
            _initializeException = null;
            _lockObject = new object();
        }

        #region Properties
        public static CWXPermissionProvider Provider
        {
            get
            {
                CWXPermissionManager.EnsureEnabled();
                return CWXPermissionManager._permProvider;
            }
        }

        public static CWXPermissionProviderCollection Providers
        {
            get
            {
                CWXPermissionManager.EnsureEnabled();
                return CWXPermissionManager._permProviders;
            }
        }

        public static bool Enabled
        {
            get 
            {
                if (!CWXPermissionManager._initialized && !CWXPermissionManager._enabledSet)
                {
                    CWXPermissionManagerSection section = ConfigurationManager.GetSection("system.web/CWXPermissionManager") as CWXPermissionManagerSection;
                    CWXPermissionManager._enabled = section.Enabled;
                    CWXPermissionManager._enabledSet = true;
                }
                return CWXPermissionManager._enabled;
            }
        }

        private static void EnsureEnabled()
        {
            CWXPermissionManager.Initialize();
            if (!CWXPermissionManager._enabled)
            {
                throw new ProviderException("PermissionManager feature is not enabled.");
            }
        }

        private static void Initialize()
        {
            if (_initialized)
            {
                if (_initializeException != null)
                {
                    throw _initializeException;
                }
            }
            else
            {
                lock (_lockObject)
                {
                    try
                    {
                        CWXPermissionManagerSection section = ConfigurationManager.GetSection("system.web/CWXPermissionManager") as CWXPermissionManagerSection;
                        _enabled = section.Enabled;
                        if (_enabled)
                        {
                            _permProviders = new CWXPermissionProviderCollection();
                            ProvidersHelper.InstantiateProviders(section.Providers, _permProviders, typeof(CWXPermissionProvider));
                            _permProviders.SetReadOnly();
                            if (section.DefaultProvider == null)
                            {
                                _initializeException = new ProviderException("Default role provider is not specified.");
                            }
                            else
                            {
                                try
                                {
                                    _permProvider = _permProviders[section.DefaultProvider];
                                }
                                catch
                                {
                                }
                            }
                            if (_permProvider == null)
                            {
                                _initializeException = new ConfigurationErrorsException("Default role provider is not found", section.ElementInformation.Properties["defaultProvider"].Source, section.ElementInformation.Properties["defaultProvider"].LineNumber);
                            }
                        }
                    }
                    catch (Exception exception)
                    {
                        _initializeException = exception;
                    }
                    _initialized = true;
                }
                if (_initializeException != null)
                {
                    throw _initializeException;
                }
            }
        }
        #endregion

        #region PermissionGroup-related Public Methods
        public static CWXPermissionGroupConstant[] GetPermissionGroupContants()
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetPermissionGroupContants();
        }

        public static CWXPermissionGroup[] GetPermissionGroups()
        { 
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetPermissionGroups();
        }
        #endregion

        #region Permission-related Public Methods

        public static CWXPermissionConstant[] GetUserPermissions(int userID)
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetUserPermissions(userID);
        }

        public static CWXPermission[] GetAllUserPermissions()
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetAllUserPermissions();
        }

        public static CWXPermission[] GetAvailUserPermissionsByPermissionGroup(int userID, CWXPermissionGroupConstant permissionGroupConstant)
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetAvailUserPermissionsByPermissionGroup(userID, permissionGroupConstant);
        }

        public static CWXPermission[] GetGrantedUserPermissionsByPermissionGroup(int userID, CWXPermissionGroupConstant permissionGroupConstant)
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetGrantedUserPermissionsByPermissionGroup(userID, permissionGroupConstant);
        }

        public static string[] GetAvailUserPermissionsString(int userID)
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetAvailUserPermissionsString(userID);
        }

        public static string[] GetGrantedUserPermissionsString(int userID)
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetGrantedUserPermissionsString(userID);
        }

        public static void AddUserPermissions(int userID, CWXPermissionConstant permission)
        {
            CWXPermissionManager.EnsureEnabled();
            CWXPermissionManager.Provider.AddUserPermissions(userID, permission);
        }

        public static void RemoveUserPermissions(int userID, CWXPermissionConstant permission)
        {
            CWXPermissionManager.EnsureEnabled();
            CWXPermissionManager.Provider.RemoveUserPermissions(userID, permission);
        }
        public static void RemoveAllUserPermissions(int userID)
        {
            CWXPermissionManager.EnsureEnabled();
            CWXPermissionManager.Provider.RemoveAllUserPermissions(userID);
        }


        public static CWXPermissionConstant[] GetRolePermissions(int roleID)
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetRolePermissions(roleID);
        }

        public static CWXPermission[] GetAllPermissions()
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetAllPermissions();
        }

        public static CWXPermission[] GetAvailRolePermissionsByPermissionGroup(int roleID, CWXPermissionGroupConstant permissionGroupConstant)
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetAvailRolePermissionsByPermissionGroup(roleID, permissionGroupConstant);
        }

        public static CWXPermission[] GetGrantedRolePermissionsByPermissionGroup(int roleID, CWXPermissionGroupConstant permissionGroupConstant)
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetGrantedRolePermissionsByPermissionGroup(roleID, permissionGroupConstant);
        }

        public static string[] GetAvailRolePermissionsString(int roleID)
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetAvailRolePermissionsString(roleID);
        }

        public static string[] GetGrantedRolePermissionsString(int roleID)
        {
            CWXPermissionManager.EnsureEnabled();
            return CWXPermissionManager.Provider.GetGrantedRolePermissionsString(roleID);
        }

        public static void AddRolePermissions(int roleID, CWXPermissionConstant permission)
        {
            CWXPermissionManager.EnsureEnabled();
            CWXPermissionManager.Provider.AddRolePermissions(roleID, permission);
        }

        public static void RemoveRolePermissions(int roleID, CWXPermissionConstant permission)
        {
            CWXPermissionManager.EnsureEnabled();
            CWXPermissionManager.Provider.RemoveRolePermissions(roleID, permission);
        }
        public static void RemoveAllRolePermissions(int roleID)
        {
            CWXPermissionManager.EnsureEnabled();
            CWXPermissionManager.Provider.RemoveAllRolePermissions(roleID);
        }

        #endregion Permission-related Public Methods
    }
}
