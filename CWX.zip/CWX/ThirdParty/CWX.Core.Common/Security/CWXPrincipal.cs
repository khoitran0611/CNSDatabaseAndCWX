using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Principal;
using System.Collections.ObjectModel;

namespace CWX.Core.Common.Security
{
	[Serializable]
    public class CWXPrincipal : IPrincipal
    {
        #region Private Fields
        private string[] _roles;
        private CWXPermissionConstant[] _permissions;
        #endregion

        #region Constructors
        public CWXPrincipal(int userID, string username, string fullname, string[] roles, CWXPermissionConstant[] permissions)
            : this(roles, permissions)
        {
            _identity = new CWXIdentity(userID, username, fullname);
        }
        public CWXPrincipal(IIdentity identity, string[] roles, CWXPermissionConstant[] permissions)
            : this(roles, permissions)
        {
            _identity = identity;
        }
        private CWXPrincipal(string[] roles, CWXPermissionConstant[] permissions)
        {
            _roles = roles;
            _permissions = permissions;
        }
        #endregion

        #region IPrincipal Members
        private IIdentity _identity;
        public IIdentity Identity
        {
            get
            {
                return _identity;
            }
        }


        public bool IsInRole(string role)
        {
            return Array.Exists<string>(_roles, new Predicate<string>(
                delegate(string target)
                {
                    return string.Compare(target, role, true) == 0;
                }));
        }

        #endregion

        #region Methods
        public bool Authorize(CWXPermissionConstant permission)
        {
            return Array.Exists<CWXPermissionConstant>(_permissions, new Predicate<CWXPermissionConstant>(
                delegate(CWXPermissionConstant target)
                {
                    return permission == target;
                }));
        }
        #endregion
    }
}
