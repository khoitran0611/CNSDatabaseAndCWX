using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Security
{
    [Flags]
    public enum CWXPermissionConstant
    {
        ACCESS_CWX_SYSTEM = 0,

        #region Access Module Permissions
        ACCESS_CUSTOMER_MANAGEMENT = 1,
        ACCESS_EMPLOYEE_MANAGEMENT = 2,         // Access Employee Setup
        ACCESS_SYSTEM_SETUP = 3,                // Access Application Setup
        ACCESS_ACCOUNT_MANAGEMENT = 4,
        ACCESS_REPORT_MANAGEMENT = 5,
        ACCESS_PRODUCT_MANAGEMENT = 6,
        ACCESS_EMPLOYEE_ACTIVE_REPORT = 7,
        ACCESS_MANAGEMENT_CONSOLE = 8,
        ACCESS_DEBTOR_MANAGEMENT = 82,
		VIEW_UPLOAD_LETTER = 86,

        #endregion

        #region Administrator Permissions

        CWX_SYSTEM_ADMINISTRATOR = 11,
        SUPERVISOR = 12,

        #endregion

        #region Collector Functions

        EXPORT_TO_EXCEL = 33,
        CHANGE_DELINQUENCY_OFFICER_FLAG = 34,
        ACCESS_QUICK_SEARCH = 35,
        CHANGE_COLLECTOR = 36,
        CHANGE_STATUS = 37,
        CHANGE_QUEUE_DATE = 38,
        CHANGE_REFER_TO = 39,
        CHANGE_NEXT_ACTION = 40,
        CHANGE_CALL_RESULT = 41,
        CHANGE_REASON = 42,
        ACCESS_STANDARD_NOTES = 43,
        ORDER_ON_DEMAND_LETTER = 44,
        ORDER_BATCH_LETTER = 45,
        STOP_LETTER = 46,
        APPLY_FEES = 47,
        STOP_FEES = 48,
        EDIT_HOT_NOTE = 49,
        DELETE_PROMISES_TAKEN = 50,
        EDIT_PHONE_DETAILS = 51,
        EDIT_ADDRESS_DETAILS = 52,
        ACCESS_RECEIVE_PAYMENT_AND_ADD_OTHER_CHARGES = 53,
        CREATE_NEW_TICKET = 54,
        ACCESS_LEGAL_MODULE = 55,
        SEND_MESSAGE_BETWEEN_COLLECTOR = 56,
        SEND_BROADCAST_MESSAGE = 57,
        ACCESS_IMAGING = 58,
        ACCESS_PRINT_OPTIONS = 59,
        ACCESS_HELP_MODULE = 60,
        SEARCH_ALL_ACCOUNTS = 61,
        ALLOW_QUEUE_PICKING = 62,
        WORK_DEBTORS = 63,
        MARK_ACCOUNT_PENDING = 71,
        ACCESS_DIALER = 72,
        CREATE_GROUP_ACCOUNT = 73,
        MAKE_CHANGE_TO_CLOSED_ACCOUNT = 74,
        EDIT_SYSTEM_PHONE = 75,
        EDIT_SYSTEM_ADDRESS = 76,
        ADD_EDIT_COBORROWER_INFO = 77,
        ALLOW_PROMISE_ON_NOT_ASSIGNED_ACCOUNT = 78,
        ADD_NEW_ACCOUNT = 80,
        EDIT_FULL_CMS_CUSTOMER_AND_ACCOUNT = 81,
        DELETE_LETTER_HISTORY = 79,
        SEARCH_ACCOUNTS_IN_THE_USER_ASSIGNED_CLIENTS = 83,
        EDIT_DELETE_TRANSACTIONS = 84,
        SEND_EMAIL_SMS = 85,
        #endregion

        #region Other Permissions
        
        ACCESS_GLOBAL_SETTINGS = 64,
        ACCESS_PASSWORD_SETTINGS = 65,
        ACCESS_BUSINESS_RULES_MANAGER = 66,
        EXECUTE_RULES_ASSIGNMENTS = 67,
        CONFIGURE_POOL = 68,
        PROCESS_PRINT_AND_POST_LETTERS = 69,
        OVERRIDE_MIN_ACCEPTABLE_PROMISE_AMOUNT_PERCENT = 70

        #endregion
        #region Legal Modules

        //ADD_EDIT_LEGAL_GROUP = 201,
        //DELETE_LEGAL_GROUP = 202,
        //ADD_EDIT_LEGAL_GROUP_STEP = 203,
        //DELETE_LEGAL_GROUP_STEP = 204,
        //ADD_EDIT_LEGAL_GROUP_STEP_EVENT = 205,
        //DELETE_LEGAL_GROUP_STEP_EVENT = 206,
        //ADD_EDIT_LEGAL_GROUP_STEP_SNAPSHOT = 207,
        //DELETE_LEGAL_GROUP_STEP_SNAPSHOT = 208
        
        #endregion
    }
}
