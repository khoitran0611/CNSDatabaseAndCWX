using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Security;

namespace CWX.Core.Common.Security
{
    /// <summary>
    /// Exposes and updates membership user information in the membership data store.
    /// </summary>
    /// <history>
    ///     2008/05/24  [Binh Truong]   Inherits from MembershipUser.
    ///                                 Add Fullname property.
	///     2009/11/30	[Minh Dam]		Mark Serializable
    /// </history>
	[Serializable]
    public class CWXUser : MembershipUser
    {

        /// <summary>
        /// Creates a new membership user object with the specified property values.
        /// </summary>
        /// <param name="providerName">
        /// The System.Web.Security.MembershipUser.ProviderName string for the membership user.
        /// </param>
        /// <param name="name">The System.Web.Security.MembershipUser.UserName string for the membership user.</param>
        /// <param name="providerUserKey">The System.Web.Security.MembershipUser.ProviderUserKey identifier for the membership user.</param>
        /// <param name="fullName">Fullname of user.</param>
        /// <param name="email">The System.Web.Security.MembershipUser.Email string for the membership user.</param>
        /// <param name="passwordQuestion">The System.Web.Security.MembershipUser.PasswordQuestion string for the membership user.</param>
        /// <param name="comment">The System.Web.Security.MembershipUser.Comment string for the membership user.</param>
        /// <param name="isApproved">The System.Web.Security.MembershipUser.IsApproved value for the membership user.</param>
        /// <param name="isLockedOut">true to lock out the membership user; otherwise, false.</param>
        /// <param name="creationDate">The System.Web.Security.MembershipUser.CreationDateSystem.DateTime object for the membership user.</param>
        /// <param name="lastLoginDate">The System.Web.Security.MembershipUser.LastLoginDateSystem.DateTime object for the membership user.</param>
        /// <param name="lastActivityDate">
        /// The System.Web.Security.MembershipUser.LastActivityDateSystem.DateTime object for the membership user.
        /// </param>
        /// <param name="lastPasswordChangedDate">
        /// The System.Web.Security.MembershipUser.LastPasswordChangedDateSystem.DateTime object for the membership user.
        /// </param>
        /// <param name="lastLockoutDate">
        /// The System.Web.Security.MembershipUser.LastLockoutDateSystem.DateTime object for the membership user.
        /// </param>
        /// <exception cref="System.ArgumentException">
        /// providerName is null.-or-providerName is not found in the System.Web.Security.Membership.Providers collection.
        /// </exception>
        public CWXUser(string providerName, string name, object providerUserKey, string fullName, string email, string passwordQuestion, string comment, bool isApproved, bool isLockedOut, DateTime creationDate, DateTime lastLoginDate, DateTime lastActivityDate, DateTime lastPasswordChangedDate, DateTime lastLockoutDate)
            : base(providerName,name,providerUserKey,email,passwordQuestion,comment,isApproved,isLockedOut,creationDate,lastLoginDate,lastActivityDate,lastPasswordChangedDate,lastLockoutDate )
        {
            this.FullName = fullName;
            this.UserID = Convert.ToInt32(providerUserKey);
        }

        private int _userID;
        /// <summary>
        /// Represents UserID or EmployeeID.
        /// </summary>
        public int UserID
        {
            get { return _userID; }
            set { _userID = value; }
        }      

        private string _fullName;
        /// <summary>
        /// Represents full name of User or Employee.
        /// </summary>
        public string FullName
        {
            get { return _fullName; }
            set { _fullName = value; }
        }

        private bool _isOnline;     
        /// <summary>
        /// Gets or sets whether the user is currently online.
        /// </summary>
        /// <returns>true if the user is online; otherwise, false.</returns>
        public new bool IsOnline
        {
            get { return _isOnline; }
            set { _isOnline = value; }
        }
        
        private CWXRole _role;
        /// <summary>
        /// Represents role of User or Employee.
        /// </summary>
        public CWXRole Role
        {
            get { return _role; }
            set { _role = value; }
        }

        private string _userStatus;
        /// <summary>
        /// Gets or sets status of user.
        /// </summary>
        public string UserStatus
        {
            get { return _userStatus; }
            set { _userStatus = value; }
        }

        private bool _changePwdOnLogon;
        /// <summary>
        /// Gets or sets status of user.
        /// </summary>
        public bool ChangePwdOnLogon
        {
            get { return _changePwdOnLogon; }
            set { _changePwdOnLogon = value; }
        }
    }
}
