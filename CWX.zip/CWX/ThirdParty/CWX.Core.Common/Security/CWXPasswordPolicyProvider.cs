using System;
using System.Collections.Generic;
using System.Configuration.Provider;

namespace CWX.Core.Common.Security
{
    public abstract class CWXPasswordPolicyProvider:ProviderBase
    {
        /// <summary>
        /// Gets or sets the name of the application to store and retrieve password policy information for.
        /// </summary>
        public abstract string ApplicationName { get; set;}
        /// <summary>
        /// Validate the given rawPassword whether it is a valid form of the available password settings.
        /// </summary>
        /// <param name="rawPassword">An instant of System.String contains a raw password.</param>
        /// <param name="userId">Indentity of user whose password is validating.</param>
        /// <returns>An instant of CWXPasswordPolicy that are violated by the validating password, otherwise null.</returns>
        public abstract CWXPasswordPolicy ValidatePasswordSettingsAndReturnViolatedPolicy(string rawPassword, object userId);
        /// <summary>
        /// Validate the given rawPassword whether it is a valid form of the available password settings.
        /// </summary>
        /// <param name="rawPassword">An instant of System.String contains a raw password.</param>
        /// <param name="userId">Indentity of user whose password is validating.</param>
        /// <returns>A System.Collections.Generic.Listlt;CWXPasswordPolicygt; that are violated by the validating password, otherwise null.</returns>
        public abstract List<CWXPasswordPolicy> ValidatePasswordSettingsAndReturnViolatedPolicyList(string rawPassword, object userId);
        /// <summary>
        /// Validate the given raw password whether its value and the previous passwords are same or not.
        /// </summary>
        /// <param name="newPassword">An instant of System.String contains a raw password.</param>
        /// <param name="userId">Indentity of user whose password is validating.</param>
        /// <param name="times"></param>
        /// <returns>return true if the validating password and the previous passwords are same, otherwise return false.</returns>
        public abstract bool ValidatePreviousPasswordsAreSame(string newPassword, object userId, int times);
        /// <summary>
        /// Update a selected passwordPolicy.
        /// </summary>
        /// <param name="passwordPolicy">A CWX.Core.Common.Security.CWXPasswordPolicy to update.</param>
        public abstract void UpdatePasswordPolicy(CWXPasswordPolicy passwordPolicy);
        /// <summary>
        /// Update a selected passwordPolicy with the given passwordPolicyName and passwordPolicyValue.
        /// </summary>
        /// <param name="passwordPolicyType">Type of password policy.</param>
        /// <param name="passwordPolicyValue">Value of password policy.</param>
        /// <returns>Returns effected row(s)</returns>
        public abstract int UpdatePasswordPolicy(CWXPasswordPolicyConstant passwordPolicyType, string passwordPolicyValue);

        /// <summary>
        /// Get a list of all PasswordPolicy from datasource.    
        /// </summary>
        /// <returns>A System.Collections.Generic.List&lt;CWXPasswordPolicy&gt;</returns>
        public abstract List<CWXPasswordPolicy> GetPasswordPolicies();
        
        /// <summary>
        /// Get an instant of CWXPasswordPolicy that is available in the password setting module by the given passwordPolicyType.
        /// </summary>
        /// <param name="passwordPolicyType">CWXPasswordPolicyConstant</param>
        /// <returns>Returns an instant of CWXPasswordPolicy if it's available, otherwise returns null.</returns>
        public abstract CWXPasswordPolicy GetAvailPasswordPolicy(CWXPasswordPolicyConstant passwordPolicyType);

        public abstract bool ValidateUserNotInUse(string userName, int availableDays);

        public abstract bool NeedChangePassword(string userName, int availableDays);

		/// <summary>
		/// Checks the password expiry policy.
		/// </summary>
		/// <param name="lastPasswordChangedDate">The date that the password last to be changed.</param>
		/// <param name="renewPasswordDays">The number of days for renewing password.</param>
		/// <param name="forceChangePasswordDays">The number of days for forcing change password.</param>
		/// <returns>Returns a CWXForcePasswordExpiryConstant value</returns>
		public abstract CWXForcePasswordExpiryConstant CheckPasswordExpiry(DateTime lastPasswordChangedDate, int renewPasswordDays, int forceChangePasswordDays);

		/// <summary>
		/// Gets the number of remain days that the password will expire.
		/// </summary>
		/// <param name="userName">The user name.</param>
		/// <returns></returns>
		public abstract int GetPasswordExpiredRemainDays(DateTime lastPasswordChangedDate);
        public abstract int GetBeforePasswordExpiryDays();
    }
}
