using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;

namespace CWX.Core.Common.Security
{
	[Serializable]
    public class CWXRole
    {
        #region Properties

        private int _roleID;

        public int RoleID
        {
            get { return _roleID; }
            set { _roleID = value; }
        }
        
        private string _roleName;

        public string RoleName
        {
            get { return _roleName; }
            set { _roleName = value; }
        }

        private int _roleOrder;

        public int RoleOrder
        {
            get { return _roleOrder; }
            set { _roleOrder = value; }
        }

        //public string RolePermissions
        //{
        //    get { return _rolePermissions; }
        //    set { _rolePermissions = value; }
        //}

        public string RoleNameAndOrder
        {
            get
            {
                return _roleName + " - " + _roleOrder;
            }
        }

        private Collection<CWXPermission> _permissions;

        public Collection<CWXPermission> Permissions
        {
            get { return _permissions; }
            set { _permissions = value; }
        }

        #endregion

        #region Constructor

        public CWXRole()
        {
        }

        #endregion
    }
}
