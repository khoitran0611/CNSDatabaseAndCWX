using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Reflection;
using System.IO;
using System.Xml.Schema;
using System.Resources;
using System.Globalization;

namespace CWX.Core.Common.Resource
{
    /// <summary>
    /// Resource utilities to get resource strings from Resource file.
    /// </summary>
    public class ResourceUtil
    {
                
        public static XmlDocument GetXmlDocumentFromAssembly(Assembly asm, string resourceName)
        {
            XmlDocument xmlDoc = new XmlDocument();

            using (Stream xmlStream = asm.GetManifestResourceStream(resourceName))
            {
                XmlTextReader xmlReader = new XmlTextReader(xmlStream);
                xmlDoc.Load(xmlReader);
                xmlReader.Close();
            }
            return xmlDoc;
        }       
    }
}
