using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Configuration;
using System.Globalization;
using System.Threading;

using CWX.Core.Common.Exceptions;

namespace CWX.Core.Common.Resource
{
    /// <summary>
    /// Manage all resource in CWX.
    /// </summary>
    public class CWXResourceManager
    {
        //Initialization related variables and logic
        private static bool _isInitialized = false;
        private static Exception _initializationException;
        private static object _initializationLock = new object();
        private static CWXResourceProviderBase _defaultResourceProvider;
        private static CWXResourceProviderCollection _cwxResourceProviderCollection;

        /// <summary>
        /// Get default resource provider.
        /// </summary>
        public static CWXResourceProviderBase DefaultProvider
        {
            get { return _defaultResourceProvider; }
        }

        /// <summary>
        /// Get resource provider collection.
        /// </summary>
        public static CWXResourceProviderCollection Providers
        {
            get 
            {
                if (_cwxResourceProviderCollection == null)
                {
                    _cwxResourceProviderCollection = new CWXResourceProviderFactory().CreateCollection();
                }
                return _cwxResourceProviderCollection; 
            }
        }

        static CWXResourceManager()
        {
            _initializationLock = new object();
            Initialize();
        }

        private static void Initialize()
        {
            if (_isInitialized)
            {
                if (_initializationException != null)
                {
                    throw _initializationException;
                }
            }
            else
            {
                lock (_initializationLock)
                {
                    try
                    {
                        _cwxResourceProviderCollection = new CWXResourceProviderFactory().CreateCollection();
                        _defaultResourceProvider = Providers[CWXResourceConfiguration.Instance.DefaultProvider];
                    }
                    catch (Exception ex)
                    {
                        _initializationException = ex;
                        _isInitialized = true;
                        throw ex;
                    }

                    _isInitialized = true; 
                }
                if (_initializationException != null)
                {
                    throw _initializationException;
                }
            }
        }

        #region Public feature API

        #region Obsolete methods

        /// <summary>
        /// Retrieves object resource of default resource provider.
        /// </summary>
        /// <param name="resCategory">Resource category.</param>
        /// <returns>The resource value if found.</returns>
        [Obsolete("Please use CWXResourceManager.GetObject methods")]
        public static object GetObjectResource(string resourceKey, ResourceCategory resCategory)
        {
            return DefaultProvider.GetObjectResource(resCategory, resourceKey);
        }

        /// <summary>
        /// Retrieves object resource of default resource provider.
        /// </summary>
        /// <param name="resCategory">Resource category.</param>
        /// <param name="culture">The culture to find.</param>
        /// <returns>The resource value if found.</returns>
        [Obsolete("Please use CWXResourceManager.GetObject methods")]
        public static object GetObjectResource(string resourceKey, ResourceCategory resCategory, CultureInfo culture)
        {
            return DefaultProvider.GetObjectResource(resCategory, resourceKey, culture);
        }

        /// <summary>
        /// Retrieves string resource of default resource provider.
        /// </summary>
        /// <param name="resCategory">Resource category.</param>
        /// <returns>The resource value if found.</returns>
        [Obsolete("Please use CWXResourceManager.GetString methods")]
        public static string GetStringResource(string resourceKey, ResourceCategory resCategory)
        {
            return DefaultProvider.GetStringResource(resCategory, resourceKey);
        }

        /// <summary>
        /// Retrieves string resource of default resource provider.
        /// </summary>
        /// <param name="resCategory">Resource category.</param>
        /// <param name="culture">The culture to find.</param>
        /// <returns>The resource value if found.</returns>
        [Obsolete("Please use CWXResourceManager.GetString methods")]
        public static string GetStringResource(string resourceKey, ResourceCategory resCategory, CultureInfo culture)
        {
            return DefaultProvider.GetStringResource(resCategory, resourceKey, culture);
        }

        /// <summary>
        /// Retrieves string resource of default resource provider.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <param name="stringParams">A string array containing zero or more strings to format.</param>
        /// <returns>The resource value if found.</returns>
        [Obsolete("Please use CWXResourceManager.GetString methods")]
        public static string GetStringResource(string resourceKey, ResourceCategory resCategory, params object[] objParams)
        {
            return DefaultProvider.GetStringResource(resCategory, resourceKey, Thread.CurrentThread.CurrentUICulture, objParams);
        }

        /// <summary>
        /// Retrieves string resource of default resource provider.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <param name="culture">The culture to find.</param>
        /// <param name="stringParams">A string array containing zero or more strings to format.</param>
        /// <returns>The resource value if found.</returns>
        [Obsolete("Please use CWXResourceManager.GetString methods")]
        public static string GetStringResource(string resourceKey, ResourceCategory resCategory, CultureInfo culture, params object[] objParams)
        {
            return DefaultProvider.GetStringResource(resCategory, resourceKey, culture, objParams);
        }

        #endregion

        /// <summary>
        /// Retrieves string resource of default resource provider.
        /// </summary>
        /// <returns>The resource value if found.</returns>
        public static string GetString(string classKey, string resourceKey)
        {
            return GetString(classKey, resourceKey, null);
        }

        /// <summary>
        /// Retrieves string resource of default resource provider.
        /// </summary>
        /// <returns>The resource value if found.</returns>
        public static string GetString(string classKey, string resourceKey, CultureInfo culture)
        {
            return (string)GetObject(classKey, resourceKey, culture);
        }

        /// <summary>
        /// Retrieves string resource of default resource provider.
        /// </summary>
        /// <returns>The resource value if found.</returns>
        public static string GetString(ResourceCategory resCategory, string resourceKey)
        {
            return GetString(resCategory, resourceKey, null);
        }

        /// <summary>
        /// Retrieves string resource of default resource provider.
        /// </summary>
        /// <returns>The resource value if found.</returns>
        public static string GetString(ResourceCategory resCategory, string resourceKey, CultureInfo culture)
        {
            return (string)GetObject(resCategory, resourceKey, culture);
        }

        /// <summary>
        /// Retrieves object resource of default resource provider.
        /// </summary>
        /// <returns>The resource value if found.</returns>
        public static object GetObject(string classKey, string resourceKey)
        {
            return GetObject(classKey, resourceKey, null);
        }

        /// <summary>
        /// Retrieves object resource of default resource provider.
        /// </summary>
        /// <returns>The resource value if found.</returns>
        public static object GetObject(string classKey, string resourceKey, CultureInfo culture)
        {
            return GetObject(
                (ResourceCategory)Enum.Parse(typeof(ResourceCategory), classKey),
                resourceKey,
                culture
                );
        }

        /// <summary>
        /// Retrieves object resource of default resource provider.
        /// </summary>
        /// <returns>The resource value if found.</returns>
        public static object GetObject(ResourceCategory resCategory, string resourceKey)
        {
            return GetObject(resCategory, resourceKey, null);
        }

        /// <summary>
        /// Retrieves object resource of default resource provider.
        /// </summary>
        /// <returns>The resource value if found.</returns>
        public static object GetObject(ResourceCategory resCategory, string resourceKey, CultureInfo culture)
        {
            return DefaultProvider.GetObjectResource(resCategory, resourceKey, culture);
        }

        #endregion
    }
}
