using System;
using System.Configuration.Provider;

using CWX.Core.Common.Resource;

namespace CWX.Core.Common.Resource
{
    /// <summary>
    /// Represents a collection of provider objects that inherit from <see cref="ProviderCollection" />.
    /// </summary>
    public class CWXResourceProviderCollection : ProviderCollection
    {
        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("The provider parameter cannot be null.");

            if (!(provider is CWXResourceProviderBase))
                throw new ArgumentException("The provider parameter must be of type CWXResourceProviderBase.");

            base.Add(provider);
        }

        new public CWXResourceProviderBase this[string name]
        {
            get { return (CWXResourceProviderBase)base[name]; }
        }

        public void CopyTo(CWXResourceProviderBase[] array, int index)
        {
            base.CopyTo(array, index);
        }
    }
}
