using System;
using System.Web.Compilation;
using System.Web.Configuration;
using System.Configuration;
using System.Configuration.Provider;

namespace CWX.Core.Common.Resource
{

    /// <summary>
    /// Provider factory implementation for external resources. Only supports global resources. 
    /// </summary>
    public class CWXResourceProviderFactory : ResourceProviderFactory
    {

        /// <summary>
        /// Creates a default resource provider.
        /// </summary>
        /// <returns>Return an instance of <see cref="CWXResourceProviderBase"/>.</returns>
        public CWXResourceProviderBase Create()
        {
            return Create(null);
        }

        /// <summary>
        /// Creates a global resource provider.
        /// </summary>
        /// <param name="providerName"></param>
        /// <returns>Return an instance of <see cref="CWXResourceProviderBase"/>.</returns>
        public CWXResourceProviderBase Create(string providerName)
        {
            CWXResourceConfiguration resourceConfiguration = CWXResourceConfiguration.Instance;

            if (string.IsNullOrEmpty(providerName))
                providerName = resourceConfiguration.DefaultProvider;

            CWXResourceProviderCollection providerCollection = CreateCollection();
            providerCollection.SetReadOnly();
            CWXResourceProviderBase resourceProvider = providerCollection[providerName];
            
            if (resourceProvider == null)
            {
                throw new ConfigurationErrorsException(
                    "You must specify a default provider for the feature.",
                    resourceConfiguration.ElementInformation.Properties["defaultProvider"].Source,
                    resourceConfiguration.ElementInformation.Properties["defaultProvider"].LineNumber);
            }
            return resourceProvider;
        }

        /// <summary>
        /// Create global resource provider collection.
        /// </summary>
        /// <returns></returns>
        public CWXResourceProviderCollection CreateCollection()
        {
            CWXResourceConfiguration resourceConfiguration = CWXResourceConfiguration.Instance;

            CWXResourceProviderCollection providerCollection = new CWXResourceProviderCollection();
            ProvidersHelper.InstantiateProviders(
                resourceConfiguration.Providers,
                providerCollection,
                typeof(CWXResourceProviderBase)
                );

            return providerCollection;
        }

        #region Override Methods

        /// <summary>
        /// Creates a global resource provider.
        /// </summary>
        /// <param name="classKey">The name of the resource class.</param>
        /// <returns>Return an instance of <see cref="IResourceProvider"/>.</returns>
        public override IResourceProvider CreateGlobalResourceProvider(string classKey)
        {
            CWXResourceProviderBase resourceProvider = Create();
            resourceProvider.ClassKey = classKey;
            return (IResourceProvider)resourceProvider;
        }

        /// <summary>
        /// Creates a local resource provider
        /// </summary>
        /// <param name="virtualPath">The path to a resource file.</param>
        /// <returns></returns>
        public override IResourceProvider CreateLocalResourceProvider(string virtualPath)
        {
            throw new NotSupportedException("CWXResourceProviderFactory does not support local resources.");
        }

        #endregion
    }
}