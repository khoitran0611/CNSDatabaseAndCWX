using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Resource
{
    /// <summary>
    /// Specifies the resource category.
    /// </summary>
    public enum ResourceCategory
    {
        Strings,
        Errors,
        Glossary,
        Config,
        Glossary_MC,
		Glossary_CDL,
		Strings_CDL,
		Errors_CDL
    }
}
