using System;
using System.Configuration;
using System.Configuration.Provider;

namespace CWX.Core.Common.Resource
{
    /// <summary>
    /// Represents a CWXResources section within a configuration file.
    /// </summary>
    internal class CWXResourceConfiguration : ConfigurationSection
    {
        private static object syncObj = new object();

        private static CWXResourceConfiguration _instance;
        /// <summary>
        /// Get instance of CWXResourceConfiguration in section "system.web/CWXResourceManager".
        /// </summary>
        public static CWXResourceConfiguration Instance
        {
            get
            {
                // apply for thread-safe
                lock (syncObj)
                {
                    if (_instance == null)
                    {
                        _instance = (CWXResourceConfiguration)ConfigurationManager.GetSection("system.web/CWXResourceManager");

                        if (_instance.DefaultProvider == null || _instance.Providers == null || _instance.Providers.Count == 0)
                            throw new InvalidOperationException("You must specify a valid default provider.");
                    }
                }
                return _instance;
            }
        }

        [ConfigurationProperty("providers")]
        public ProviderSettingsCollection Providers
        {
            get
            {
                return (ProviderSettingsCollection)base["providers"];
            }
        }

        [ConfigurationProperty("defaultProvider", DefaultValue = "CWXXmlResourceProvider")]
        [StringValidator(MinLength = 1)]
        public string DefaultProvider
        {
            get
            {
                return (string)base["defaultProvider"];
            }
            set
            {
                base["defaultProvider"] = value;
            }
        }
    }
}
