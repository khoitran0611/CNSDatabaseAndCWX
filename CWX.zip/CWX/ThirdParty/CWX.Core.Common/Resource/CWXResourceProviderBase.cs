using System;
using System.Configuration.Provider;
using System.Resources;
using System.Globalization;
using System.Web.Compilation;

namespace CWX.Core.Common.Resource
{

    /// <summary>
    /// Resource provider for accessing external resources. 
    /// </summary>
    public abstract class CWXResourceProviderBase : ProviderBase, IResourceProvider
    {
        /// <summary>
        /// Get or set class key of resource file.
        /// </summary>
        public abstract string ClassKey
        {
            get;
            set;
        }

        /// <summary>
        /// Retrieves object resource.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <returns>The resource value if found.</returns>
        public abstract object GetObjectResource(ResourceCategory resCategory, string resourceKey);

        /// <summary>
        /// Retrieves object resource.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <param name="culture">The culture to find.</param>
        /// <returns>The resource value if found.</returns>
        public abstract object GetObjectResource(ResourceCategory resCategory, string resourceKey, CultureInfo culture);
        
        /// <summary>
        /// Retrieves string resource.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <returns>The resource value if found.</returns>
        public abstract string GetStringResource(ResourceCategory resCategory, string resourceKey);

        /// <summary>
        /// Retrieves string resource.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <param name="culture">The culture to find.</param>
        /// <returns>The resource value if found.</returns>
        public abstract string GetStringResource(ResourceCategory resCategory, string resourceKey, CultureInfo culture);
        
        /// <summary>
        /// Retrieves string resource.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <param name="culture">The culture to find.</param>
        /// <param name="stringParams">A string array containing zero or more strings to format.</param>
        /// <returns>The resource value if found.</returns>
        public abstract string GetStringResource(ResourceCategory resCategory, string resourceKey, CultureInfo culture, params object[] objParams);

        #region IResourceProvider Members

        /// <summary>
        /// Returns a resource object for the key and culture.
        /// </summary>
        /// <param name="resourceKey">The key identifying a particular resource.</param>
        /// <param name="culture">The culture identifying a localized value for the resource.</param>
        /// <returns>
        /// An System.Object that contains the resource value for the resourceKey and culture.
        /// </returns>
        public abstract object GetObject(string resourceKey, CultureInfo culture);

        /// <summary>
        /// Implicit expressions are not supported by this provider 
        /// therefore a ResourceReader need not be implemented.
        /// Throws a NotSupportedException.
        /// </summary>
        IResourceReader IResourceProvider.ResourceReader
        {
            get
            {
                throw new NotSupportedException();
            }
        }

        #endregion
    }

}