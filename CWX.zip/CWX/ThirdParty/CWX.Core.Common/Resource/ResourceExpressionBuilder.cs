using System;
using System.Web.Compilation;
using System.Globalization;
using System.ComponentModel;
using System.Web.UI;
using System.CodeDom;
using System.Web;
using System.Threading;
using System.Diagnostics;

namespace CWX.Core.Common.Resource
{
    /// <summary>
    /// Custom expression builder support for $Resources expressions.
    /// </summary>
    /// <history>
    ///     2008/02/27  [Binh Truong]   Init version
    /// </history>
    public class ResourceExpressionBuilder : ExpressionBuilder
    {

        public override object EvaluateExpression(object target, BoundPropertyEntry entry, object parsedData, ExpressionBuilderContext context)
        {
            ResourceExpressionFields fields = parsedData as ResourceExpressionFields;
            return CWXResourceManager.GetObject(fields.ResourceKey, fields.ClassKey);
        }

        public override CodeExpression GetCodeExpression(BoundPropertyEntry entry, object parsedData, ExpressionBuilderContext context)
        {
            ResourceExpressionFields fields = parsedData as ResourceExpressionFields;
            CodeMethodInvokeExpression exp = new CodeMethodInvokeExpression(
                new CodeTypeReferenceExpression(typeof(ResourceExpressionBuilder)), 
                "GetGlobalResourceObject", 
                new CodePrimitiveExpression(fields.ClassKey), 
                new CodePrimitiveExpression(fields.ResourceKey)
                );

            return exp;
        }

        public override object ParseExpression(string expression, Type propertyType, ExpressionBuilderContext context)
        {
            if (string.IsNullOrEmpty(expression))
                throw new ArgumentException("CWXResource expression missing", "expression");

            ResourceExpressionFields fields = null;
            string classKey = null;
            string resourceKey = null;

            string[] expParams = expression.Split(new char[] { ',' });
            if (expParams.Length > 2)
                throw new ArgumentException("Too many parameters", expression);
            
            if (expParams.Length == 1)
            {
                throw new ArgumentException("Too few parametters", expression);
            }
            else
            {
                classKey = expParams[0].Trim();
                resourceKey = expParams[1].Trim();
            }

            fields = new ResourceExpressionFields(classKey, resourceKey);

            return fields;
        }

        public static object GetGlobalResourceObject(string classKey, string resourceKey)
        {
            return CWXResourceManager.GetObject(classKey, resourceKey);
        }

        /// <summary>
        /// Represents resource expression fields.
        /// </summary>
        /// <history>
        ///     2008/02/27  [Binh Truong]   Init version
        /// </history>
        internal class ResourceExpressionFields
        {

            private string _classKey;
            internal string ClassKey
            {
                get
                {
                    return _classKey;
                }
            }

            private string _resourceKey;
            internal string ResourceKey
            {
                get
                {
                    return _resourceKey;
                }
            }

            internal ResourceExpressionFields(string classKey, string resourceKey)
            {
                _classKey = classKey;
                _resourceKey = resourceKey;
            }
        }
    }
}

