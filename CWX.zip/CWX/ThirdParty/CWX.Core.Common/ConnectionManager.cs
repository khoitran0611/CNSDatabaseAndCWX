using System;
using System.Threading;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Configuration;

using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;

using CWX.Core.Common.Configuration;
using System.Collections.ObjectModel;
using CWX.Core.Common.Data;
using System.Data;
using CWX.Core.Common.Security;

namespace CWX.Core.Common
{
    /// <summary>
    /// Manages all connection strings that is using in CWX system.
    /// </summary>
    public class ConnectionManager
    {
        #region Instant members
        private bool _isLoaded = false;
        private static object _lockObject = new object();

        private ConnectionManager()
        {
            Initialize();
        }

        private string _coreDatabaseName;
        private string InternalCoreDatabaseName
        {
            get
            {
                return _coreDatabaseName;
            }
        }

        private string _coreConnectionString;
        private string InternalCoreConnectionString
        {
            get
            {
                return _coreConnectionString;
            }
        }

        private void Initialize()
        {
            if (!_isLoaded)
            {
                lock (_lockObject)
                {
                    if (!_isLoaded)
                    {
                        CWXConfigurationSection cwxConfiguration = ConfigurationManager.GetSection("cwx") as CWXConfigurationSection;
                        if (cwxConfiguration == null)
                            throw new Exception("The 'cwx' section does not exist in the config file.");

                        _coreDatabaseName = cwxConfiguration.Connections.CoreConnectionStringName;

                        DatabaseConfigurationView configurationView = new DatabaseConfigurationView(ConfigurationSourceFactory.Create());
                        ConnectionStringSettings coreConnectionStringSettings = configurationView.GetConnectionStringSettings(_coreDatabaseName);

                        _coreConnectionString = coreConnectionStringSettings.ConnectionString;

                        _cwxDbConnectionStringBuilder = new DbConnectionStringBuilder();
                        _coreDbConnectionStringBuilder = new DbConnectionStringBuilder();
                        _isLoaded = true;
                    }
                }
            }
        }
        #endregion

        #region Static Members
        private static ConnectionManager _soleInstance;
        private static ConnectionManager SoleIntance
        {
            get
            {
                if (_soleInstance == null)
                    _soleInstance = new ConnectionManager();
                return _soleInstance;
            }
        }

        /// <summary>
        /// Provide the CWX Core database element name (element in CWXELConfiguration.config file)
        /// </summary>
        public static string CoreDatabaseElementName
        {
            get
            {
                return SoleIntance.InternalCoreDatabaseName;
            }
        }

        /// <summary>
        /// Provide the CWX Main database element name (element in CWXELConfiguration.config file)
        /// </summary>
        public static string CWXDatabaseName
        {
            get
            {
                CWXIdentity cwxIdentity = Thread.CurrentPrincipal.Identity as CWXIdentity;
                if (cwxIdentity != null)
                    return cwxIdentity.DbConnectionName;

                return string.Empty;
            }
        }

        public static string MCDatabaseName
        {
            get
            {
                return "MC_CWorksDB";
            }
        }

        public static string Load1DatabaseName
        {
            get
            {
                return "Load1DB";
            }
        }

        public static string OLEDBCWorksDatabaseName
        {
            get
            {
                return "OLEDB_CWorksDB";
            }
        }

        public static string OLEDBLoad1DatabaseName
        {
            get
            {
                return "OLEDB_Load1DB";
            }
        }
        /// <summary>
        /// Provide the CWX Main database element name (element in CWXELConfiguration.config file)
        /// </summary>
        public static string CWXConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(CWXDatabaseName))
                    return string.Empty;

                DatabaseConfigurationView configurationView = new DatabaseConfigurationView(ConfigurationSourceFactory.Create());
                ConnectionStringSettings cwxConnectionStringSettings = configurationView.GetConnectionStringSettings(CWXDatabaseName);
                return cwxConnectionStringSettings.ConnectionString;
            }
        }

        public static string MCConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(MCDatabaseName))
                    return string.Empty;

                DatabaseConfigurationView configurationView = new DatabaseConfigurationView(ConfigurationSourceFactory.Create());
                ConnectionStringSettings cwxConnectionStringSettings = configurationView.GetConnectionStringSettings(MCDatabaseName);
                return cwxConnectionStringSettings.ConnectionString;
            }
        }

        public static string OLEDBCWorksConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(OLEDBCWorksDatabaseName))
                    return string.Empty;

                DatabaseConfigurationView configurationView = new DatabaseConfigurationView(ConfigurationSourceFactory.Create());
                ConnectionStringSettings cwxConnectionStringSettings = configurationView.GetConnectionStringSettings(OLEDBCWorksDatabaseName);
                return cwxConnectionStringSettings.ConnectionString;
            }
        }

        public static string OLEDBLoad1ConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(OLEDBLoad1DatabaseName))
                    return string.Empty;

                DatabaseConfigurationView configurationView = new DatabaseConfigurationView(ConfigurationSourceFactory.Create());
                ConnectionStringSettings cwxConnectionStringSettings = configurationView.GetConnectionStringSettings(OLEDBLoad1DatabaseName);
                return cwxConnectionStringSettings.ConnectionString;
            }
        }

        #region CWork ConnectionString

        private static DbConnectionStringBuilder _cwxDbConnectionStringBuilder;
        private static DbConnectionStringBuilder InternalCWXDbConnectionStringBuilder
        {
            get
            {
                _cwxDbConnectionStringBuilder.ConnectionString = CWXConnectionString.ToString();
                return _cwxDbConnectionStringBuilder;
            }
        }

        /// <summary>
        /// Username is used to authenticate to connect to CWX database. 
        /// </summary>
        public static string CWXUserName
        {
            get
            {
                object username = null;
                if (!InternalCWXDbConnectionStringBuilder.TryGetValue("user id", out username))
                    InternalCWXDbConnectionStringBuilder.TryGetValue("uid", out username);

                return username.ToString();
            }
        }

        /// <summary>
        /// Password is used to authenticate to connect to CWX database.
        /// </summary>
        public static string CWXPassword
        {
            get
            {
                object password = null;
                if (!InternalCWXDbConnectionStringBuilder.TryGetValue("password", out password))
                    InternalCWXDbConnectionStringBuilder.TryGetValue("pwd", out password);

                return password.ToString();
            }
        }

        /// <summary>
        /// Name/IP of server which contains CWX Database.
        /// </summary>
        public static string CWXServer
        {
            get
            {
                object server = null;
                if (!InternalCWXDbConnectionStringBuilder.TryGetValue("data source", out server))
                    InternalCWXDbConnectionStringBuilder.TryGetValue("Server", out server);

                return server.ToString();
            }
        }

        /// <summary>
        /// Name of default CWX database.
        /// </summary>
        public static string CWXDataBase
        {
            get
            {
                object database = null;
                if (!InternalCWXDbConnectionStringBuilder.TryGetValue("initial catalog", out database))
                    InternalCWXDbConnectionStringBuilder.TryGetValue("database", out database);

                return database.ToString();
            }
        } 

        #endregion

        #region Core ConnectionString

        private static DbConnectionStringBuilder _coreDbConnectionStringBuilder;
        private static DbConnectionStringBuilder InternalCoreDbConnectionStringBuilder
        {
            get
            {
                _coreDbConnectionStringBuilder.ConnectionString = CoreConnectionString.ToString();
                return _coreDbConnectionStringBuilder;
            }
        }

        /// <summary>
        /// Provides the CWX Core database connection string
        /// </summary>
        public static string CoreConnectionString
        {
            get
            {
                return SoleIntance.InternalCoreConnectionString;
            }
        }

        /// <summary>
        /// Username is used to authenticate to connect to CWX database. 
        /// </summary>
        public static string CoreUserName
        {
            get
            {
                object username = null;
                if (!InternalCoreDbConnectionStringBuilder.TryGetValue("user id", out username))
                    InternalCoreDbConnectionStringBuilder.TryGetValue("uid", out username);

                return username.ToString();
            }
        }

        /// <summary>
        /// Password is used to authenticate to connect to CWX database.
        /// </summary>
        public static string CorePassword
        {
            get
            {
                object password = null;
                if (!InternalCoreDbConnectionStringBuilder.TryGetValue("password", out password))
                    InternalCoreDbConnectionStringBuilder.TryGetValue("pwd", out password);

                return password.ToString();
            }
        }

        /// <summary>
        /// Name/IP of server which contains CWX Database.
        /// </summary>
        public static string CoreServer
        {
            get
            {
                object server = null;
                if (!InternalCoreDbConnectionStringBuilder.TryGetValue("data source", out server))
                    InternalCoreDbConnectionStringBuilder.TryGetValue("Server", out server);

                return server.ToString();
            }
        }

        /// <summary>
        /// Name of default CWX database.
        /// </summary>
        public static string CoreDataBase
        {
            get
            {
                object database = null;
                if (!InternalCoreDbConnectionStringBuilder.TryGetValue("initial catalog", out database))
                    InternalCoreDbConnectionStringBuilder.TryGetValue("database", out database);

                return database.ToString();
            }
        }

        #endregion

		/// <summary>
		/// Get all connection string settings from file CWXELConfiguration.config
		/// </summary>
		public static ConnectionStringSettingsCollection CWXConnectionStringList
		{
			get
			{
				ConnectionStringsSection section = (ConnectionStringsSection)ConfigurationSourceFactory.Create().GetSection("connectionStrings");
				ConnectionStringSettingsCollection result = new ConnectionStringSettingsCollection();
				for (int i = 1; i < section.ConnectionStrings.Count; i++)
				{
					if (!section.ConnectionStrings[i].Name.Equals(CoreDatabaseElementName, StringComparison.InvariantCultureIgnoreCase)
                        && !section.ConnectionStrings[i].Name.StartsWith("MC_",StringComparison.InvariantCultureIgnoreCase)
                        && !section.ConnectionStrings[i].Name.StartsWith("Workflow", StringComparison.InvariantCultureIgnoreCase)
                        && !section.ConnectionStrings[i].Name.StartsWith("OLEDB", StringComparison.InvariantCultureIgnoreCase)
                        && !section.ConnectionStrings[i].Name.StartsWith("Load1", StringComparison.InvariantCultureIgnoreCase))
						result.Add(section.ConnectionStrings[i]);
				}
				return result; ;
			}
		}

		public static bool TestConnectToDatabase(string databaseName)
		{
			try
			{
				IDataProvider provider = new DataProviderFactory().Create(databaseName);
				DbConnection connection = provider.CreateConnection();
				if (connection.State == ConnectionState.Open)
					connection.Close();
				connection.Open();
				connection.Close();
				return true;
			}
			catch
			{
				return false;
			}
		}
        #endregion
    }
}
