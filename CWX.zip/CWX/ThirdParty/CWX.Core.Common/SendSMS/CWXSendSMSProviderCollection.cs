﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration.Provider;

namespace CWX.Core.Common.SendSMS
{
    /// <summary>
    /// Represents a collection of provider objects that inherit from <see cref="ProviderCollection" />.
    /// </summary>
    public class CWXSendSMSProviderCollection : ProviderCollection
    {
        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("The provider parameter cannot be null.");

            if (!(provider is CWXSendSMSProvider))
                throw new ArgumentException("The provider parameter must be of type CWXSendSMSProvider.");

            base.Add(provider);
        }

        new public CWXSendSMSProvider this[string name]
        {
            get { return (CWXSendSMSProvider)base[name]; }
        }

        public void CopyTo(CWXSendSMSProvider[] array, int index)
        {
            base.CopyTo(array, index);
        }
    }
}
