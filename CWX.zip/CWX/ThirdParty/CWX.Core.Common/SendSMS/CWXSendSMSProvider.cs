﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration.Provider;

namespace CWX.Core.Common.SendSMS
{
    public abstract class CWXSendSMSProvider : ProviderBase
    {
        public abstract bool Send(string mobilePhone, string message);
    }
}
