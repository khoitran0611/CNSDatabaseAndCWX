﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Configuration.Provider;
using System.Web.Configuration;

namespace CWX.Core.Common.SendSMS
{
    public class CWXSendSMSManager
    {
        //Initialization related variables and logic
        private static bool _isInitialized = false;
        private static Exception _initializationException;
        private static object _initializationLock;

        private static CWXSendSMSProvider _defaultProvider;
        private static CWXSendSMSProviderCollection _providerCollection;

        public static CWXSendSMSProvider Provider
        {
            get { return _defaultProvider; }
        }

        public static CWXSendSMSProviderCollection Providers
        {
            get { return _providerCollection; }
        }

        static CWXSendSMSManager()
        {
            _initializationLock = new object();
            Initialize();
        }

        private static void Initialize()
        {
            if (_isInitialized)
            {
                if (_initializationException != null)
                {
                    throw _initializationException;
                }
            }
            else
            {
                lock (_initializationLock)
                {
                    try
                    {
                        //Get the feature's configuration info
                        CWXSendSMSConfiguration sendSMSConfiguration =
                            (CWXSendSMSConfiguration)ConfigurationManager.GetSection("system.web/CWXSendSMSConfiguration");

                        if (sendSMSConfiguration.DefaultProvider == null || sendSMSConfiguration.Providers == null || sendSMSConfiguration.Providers.Count < 1)
                        {
                            throw new ProviderException("You must specify a valid default provider.");
                        }

                        //Instantiate the providers
                        _providerCollection = new CWXSendSMSProviderCollection();
                        ProvidersHelper.InstantiateProviders(sendSMSConfiguration.Providers, _providerCollection, typeof(CWXSendSMSProvider));
                        _providerCollection.SetReadOnly();
                        _defaultProvider = _providerCollection[sendSMSConfiguration.DefaultProvider];
                        if (_defaultProvider == null)
                        {
                            throw new ConfigurationErrorsException(
                                "You must specify a default provider for the feature.",
                                sendSMSConfiguration.ElementInformation.Properties["defaultProvider"].Source,
                                sendSMSConfiguration.ElementInformation.Properties["defaultProvider"].LineNumber);
                        }
                    }
                    catch (Exception ex)
                    {
                        _initializationException = ex;
                        _isInitialized = true;
                        throw ex;
                    }

                    _isInitialized = true;
                }
                if (_initializationException != null)
                {
                    throw _initializationException;
                }
            }
        }

        //Public feature API
        #region Csen SMS-related Public Methods
        /// <summary>
        /// Send SMS message to gateway
        /// </summary>
        /// <param name="mobilePhone"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public static bool Send(string mobilePhone, string message)
        {
            return Provider.Send(mobilePhone, message);
        }

        #endregion
    }
}
