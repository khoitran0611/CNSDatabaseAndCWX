using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Xml;
using System.Globalization;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.Reflection;

using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling.Logging;
using CWX.Core.Common.Configuration;

namespace CWX.Core.Common
{
    /// <summary>
    /// CWXUtilities content utility static methods. Use for get request value, manipulate string, ect.
    /// </summary>
    public sealed class CWXUtilities
    {
        #region Window API

        public const int LOGON32_LOGON_INTERACTIVE = 2;
        public const int LOGON32_PROVIDER_DEFAULT = 0;

        [DllImport("advapi32.dll")]
        public static extern int LogonUserA(string lpszUserName,
            string lpszDomain,
            string lpszPassword,
            int dwLogonType,
            int dwLogonProvider,
            ref IntPtr phToken);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern int DuplicateToken(IntPtr hToken,
            int impersonationLevel,
            ref IntPtr hNewToken);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool RevertToSelf();

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public static extern bool CloseHandle(IntPtr handle);

        /// <summary>
        /// Try to impersonate a domainAccount to able to print.
        /// </summary>
        public static bool ImpersonateValidUser(string userName, string domain, string password, out WindowsImpersonationContext impersonationContext)
        {
            impersonationContext = null;
            WindowsIdentity tempWindowsIdentity;
            IntPtr token = IntPtr.Zero;
            IntPtr tokenDuplicate = IntPtr.Zero;

            if (RevertToSelf())
            {
                if (LogonUserA(userName, domain, password, LOGON32_LOGON_INTERACTIVE,
                    LOGON32_PROVIDER_DEFAULT, ref token) != 0)
                {
                    if (DuplicateToken(token, 2, ref tokenDuplicate) != 0)
                    {
                        tempWindowsIdentity = new WindowsIdentity(tokenDuplicate);
                        impersonationContext = tempWindowsIdentity.Impersonate();
                        if (impersonationContext != null)
                        {
                            CloseHandle(token);
                            CloseHandle(tokenDuplicate);
                            return true;
                        }
                    }
                }
            }
            if (token != IntPtr.Zero)
                CloseHandle(token);
            if (tokenDuplicate != IntPtr.Zero)
                CloseHandle(tokenDuplicate);
            return false;
        }

        /// <summary>
        /// Ensure impersonation is reverted.
        /// </summary>
        public static void UndoImpersonation(WindowsImpersonationContext impersonationContext)
        {
            impersonationContext.Undo();
        }

        #endregion

        #region Public Static Methods
        /// <summary>
        /// Get request value through HttpRequest object.
        /// </summary>
        /// <param name="fieldName">Request field name.</param>
        public static string GetRequestValue(string fieldName)
        {
            string request = HttpContext.Current.Request[fieldName];
            if (string.IsNullOrEmpty(request))
                return string.Empty;

            return request;
        }

        /// <summary>
        /// Get request value through HttpRequest object.
        /// </summary>
        /// <typeparam name="T">Object type.</typeparam>
        /// <param name="fieldName">Request field name.</param>
        /// <param name="defaultValue">Default value if the request value is null or empty.</param>
        public static T GetRequestValue<T>(string fieldName, T defaultValue)
        {
            try
            {
                string request = HttpContext.Current.Request[fieldName];
                if (string.IsNullOrEmpty(request))
                    return defaultValue;

				//TypeConverter objectConverter = TypeDescriptor.GetConverter(typeof(T));
				//object objValue = objectConverter.ConvertTo(request, typeof(T));
				//return (T)objValue;

				return ConvertToValue<T>(request);
            }
            catch
            {
                return defaultValue;
            }
        }

        /// <summary>
        /// Get request value through HttpRequest object.
        /// </summary>
        /// <param name="fieldName">Request field name.</param>
        public static T GetRequestValue<T>(string fieldName)
        {
            return GetRequestValue<T>(fieldName, default(T));
        }

        /// <summary>
        /// Convert an object to value.
        /// </summary>
        /// <typeparam name="T">Object type.</typeparam>
        /// <param name="fieldName">Request field name.</param>
        /// <param name="defaultValue">Default value if the request value is null or empty.</param>
        public static T ConvertToValue<T>(object value, T defaultValue)
        {
            try
            {
				object objValue;
                TypeConverter objectConverter = TypeDescriptor.GetConverter(typeof(T));
				if (objectConverter is BooleanConverter)
				{
					objValue = Convert.ToBoolean(value);
				}
				else if (objectConverter is DateTimeConverter)
				{
					objValue = Convert.ToDateTime(value);
				}
				else
				{
					objValue = objectConverter.ConvertTo(value, typeof(T));					
				}
				return (T)objValue;
            }
            catch
            {
                return defaultValue;
            }
        }

        /// <summary>
        /// Convert an object to value.
        /// </summary>
        /// <typeparam name="T">Object type.</typeparam>
        /// <param name="fieldName">Request field name.</param>
        public static T ConvertToValue<T>(object value)
        {
            return ConvertToValue<T>(value, default(T));
        }

		/// <summary>
		/// Convert an object to enum value.
		/// </summary>
		/// <typeparam name="T">Enum type.</typeparam>
		/// <param name="fieldName">Request field name.</param>
		/// <param name="defaultValue">Default enum value if the request value is null or empty.</param>
		public static T ConvertToEnum<T>(object value, T defaultValue)
		{
			try
			{
				return (T)Enum.Parse(typeof(T), value.ToString());
			}
			catch
			{
				return defaultValue;
			}

		}

        /// <summary>
        /// Log the exception.
        /// </summary>
        public static void LogException(Exception ex)
        {
            ExceptionPolicy.HandleException(ex, "Handled Exception");
        }

        /// <summary>
        /// Process the searching wildcards
        /// </summary>
        /// <param name="criteria">String that will be processed.</param>
        /// <returns></returns>
        public static string ProcessSearchingWildcards(string criteria)
        {
            criteria = criteria.Replace("[", "[[]");
            criteria = criteria.Replace("%", "[%]");
            criteria = criteria.Replace("_", "[_]");
            criteria = criteria.Replace("*", "[*]");
            criteria = criteria.Replace("?", "[?]");
            criteria = criteria.Replace("'", "['']");
            return criteria;
        }

        /// <summary>
        /// Adds a string to the current url determining the correct seperator character.
        /// </summary>
        /// <param name="url">Url to append query string.</param>
        /// <param name="querystring">Query string to append.</param>
        public static string AppendQuerystring(string url, string querystring)
        {
            return AppendQuerystring(url, querystring, false);
        }

        /// <summary>
        /// Adds a string to the current url determining the correct seperator character.
        /// </summary>
        /// <param name="url">Url to append query string.</param>
        /// <param name="querystring">Query string to append.</param>
        /// <param name="urlEncoded">Is url encoded?</param>
        public static string AppendQuerystring(string url, string querystring, bool urlEncoded)
        {
            string seperator = "?";
            if (url.IndexOf('?') > -1)
            {
                if (!urlEncoded)
                    seperator = "&";
                else
                    seperator = "&amp;";
            }
            return string.Concat(url, seperator, querystring);
        }

        /// <summary>
        /// ConvertDataReaderToXmlElement
        /// </summary>
        /// <param name="dataReader"></param>
        /// <param name="xmlDoc"></param>
        /// <param name="topLevelNodeName"></param>
        /// <param name="rowNodeName"></param>
        /// <returns>XmlElement</returns>
        public static XmlElement ConvertDataReaderToXmlElement(IDataReader dataReader, string topLevelNodeName, string rowNodeName, CultureInfo cultureInfo, bool applyTimeFormat)
        {
            //int aryRows, curRowIdx, curFieldIdx, numFields, numRows;
            if (dataReader == null)
                return null;

            //xmlDoc.PreserveWhitespace = true;
            XmlElement xmlRoot;
            XmlElement xmlRow;
            XmlElement xmlField;

            CreateXmlDocument(topLevelNodeName, rowNodeName, out xmlRoot, out xmlRow, out xmlField);

            XmlNodeList xmlNodeList;
            int fieldColumns = dataReader.FieldCount;
            bool allowAppendChild = false;

            if (!string.IsNullOrEmpty(rowNodeName))
            {
                while (dataReader.Read())
                {
                    xmlNodeList = xmlRow.GetElementsByTagName("field");

                    //Will check if the current element has children
                    allowAppendChild = xmlNodeList.Count == 0 ? true : false;
                    for (int currentFieldIndex = 0; currentFieldIndex < fieldColumns; currentFieldIndex++)
                    {
                        //At first time, xmlRow do not have structure, so create structure for xmlRow
                        if (!string.IsNullOrEmpty(rowNodeName) && allowAppendChild)
                        {
                            xmlField.SetAttribute("name", dataReader.GetName(currentFieldIndex).ToUpper());
                            xmlRow.AppendChild(xmlField);

                            BindDataToXmlFields(cultureInfo, xmlField, dataReader.GetValue(currentFieldIndex), dataReader.GetFieldType(currentFieldIndex).ToString(), applyTimeFormat);
                            xmlField = (XmlElement)xmlField.CloneNode(true);
                        }
                        else
                            BindDataToXmlFields(cultureInfo, (XmlElement)xmlNodeList[currentFieldIndex], dataReader.GetValue(currentFieldIndex), dataReader.GetFieldType(currentFieldIndex).ToString(), applyTimeFormat);
                    }
                    if (!string.IsNullOrEmpty(topLevelNodeName))
                        xmlRoot.AppendChild(xmlRow);

                    //Copy the current row to give it a new memory address (copy children too)
                    if (!string.IsNullOrEmpty(rowNodeName))
                        xmlRow = (XmlElement)xmlRow.CloneNode(true);
                }
            }

            if (!string.IsNullOrEmpty(topLevelNodeName))
                return xmlRoot;
            else if (!string.IsNullOrEmpty(rowNodeName))
                return xmlRow;
            else
                return xmlField;
        }

        /// <summary>
        /// ConvertDataTableToXmlElement
        /// </summary>
        /// <param name="dataTable"></param>
        /// <param name="xmlDoc"></param>
        /// <param name="topLevelNodeName"></param>
        /// <param name="rowNodeName"></param>
        /// <param name="shortDateFormat"></param>
        /// <param name="timeFormat"></param>
        /// <param name="currencyFormat"></param>
        /// <returns>XmlElement</returns>
        public static XmlElement ConvertDataTableToXmlElement(DataTable dataTable, string topLevelNodeName, string rowNodeName, CultureInfo cultureInfo, bool applyTimeFormat)
        {
            //int aryRows, curRowIdx, curFieldIdx, numFields, numRows;
            if (dataTable == null)
                return null;

            XmlElement xmlRoot;
            XmlElement xmlRow;
            XmlElement xmlField;

            CreateXmlDocument(topLevelNodeName, rowNodeName, out xmlRoot, out xmlRow, out xmlField);

            int fieldColumns = dataTable.Columns.Count;
            XmlNodeList xmlNodeList;
            bool allowAppendChild = false;

            if (!string.IsNullOrEmpty(rowNodeName))
            {
                foreach (DataRow dr in dataTable.Rows) //foreach 2
                {
                    xmlNodeList = xmlRow.GetElementsByTagName("field");

                    //Will check if the current element has children
                    allowAppendChild = xmlNodeList.Count == 0 ? true : false;
                    for (int currentFieldIndex = 0; currentFieldIndex < fieldColumns; currentFieldIndex++) // begin for
                    {
                        //At first time, xmlRow do not have structure, so create structure for xmlRow
                        if (!string.IsNullOrEmpty(rowNodeName) && allowAppendChild)
                        {
                            xmlField.SetAttribute("name", dataTable.Columns[currentFieldIndex].ColumnName.ToUpper());
                            xmlRow.AppendChild(xmlField);

                            BindDataToXmlFields(cultureInfo, xmlField, dr[currentFieldIndex], dataTable.Columns[currentFieldIndex].DataType.ToString(), applyTimeFormat);
                            xmlField = (XmlElement)xmlField.CloneNode(true);
                        }
                        else
                            BindDataToXmlFields(cultureInfo, (XmlElement)xmlNodeList[currentFieldIndex], dr[currentFieldIndex], dataTable.Columns[currentFieldIndex].DataType.ToString(), applyTimeFormat);
                    }//end for
                    if (!string.IsNullOrEmpty(topLevelNodeName))
                        xmlRoot.AppendChild(xmlRow);
                    //Copy the current row to give it a new memory address (copy children too)
                    if (!string.IsNullOrEmpty(rowNodeName))
                        xmlRow = (XmlElement)xmlRow.CloneNode(true);

                }// end foreach 2
            }
            if (!string.IsNullOrEmpty(topLevelNodeName))
                return xmlRoot;
            else if (!string.IsNullOrEmpty(rowNodeName))
                return xmlRow;
            else
                return xmlField;
        }

        /// <summary>
        /// GetNotesFromXmlDocument
        /// </summary>
        /// <param name="xmlDoc"></param>
        /// <returns>List<XmlNode></returns>
        public static List<XmlNode> GetNotesFromXmlDocument(XmlDocument xmlDoc, int numberNotes)
        {
            XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes("//Notes/Note");
            List<XmlNode> returnedNodeList = new List<XmlNode>();
            for (int index = 0; index < nodeList.Count && index < numberNotes; index++)
            {
                returnedNodeList.Add(nodeList[index]);
            }
            return returnedNodeList;
        }

        /// <summary>
        /// GetHotNoteFromXmlDocument
        /// </summary>
        /// <param name="xmlDoc"></param>
        /// <returns>string</returns>
        //public static string GetHotNoteFromXmlDocument(XmlDocument xmlDoc)
        //{ 
        //    XmlNode xmlNode = xmlDoc.SelectSingleNode("Debtor");
        //    string hotNote = string.Empty;
        //    if (xmlNode.SelectSingleNode("field[@name='HOTNOTE']/value") != null)
        //        hotNote = xmlNode.SelectSingleNode("field[@name='HOTNOTE']/value").InnerText;
        //    return hotNote;
        //}
        public static XmlNode GetHotNoteFromXmlDocument(XmlDocument xmlDoc)
        {
            XmlElement xmlNode = xmlDoc.DocumentElement;
            return xmlNode.SelectSingleNode("field[@name='HOTNOTE']");
        }

        /// <summary>
        /// Get property value.
        /// </summary>
        /// <param name="propertyName">Indicates property name which want to get value.</param>
        /// <param name="objectInstance">An instance of object.</param>
        /// <returns>Property value if found, else return null.</returns>
        public static object GetPropertyValue(string propertyName, object objectInstance)
        {
            object propertyValue = null;
            PropertyInfo[] properties = objectInstance.GetType().GetProperties();
            foreach (PropertyInfo property in properties)
            {
                if (property.Name.Equals(propertyName))
                {
                    Type propType = property.PropertyType;
                    propertyValue = property.GetValue(objectInstance, null);
                    break;
                }
            }
            return propertyValue;
        }

        public static string ConvertCurrencyToString(object val, CultureInfo ci)
        {
            decimal d;
            decimal.TryParse(val.ToString(), out d);
            return d.ToString("c", ci.NumberFormat);
        }

		public static T GetDataRowValue<T>(DataRow row, string columnName, T defaultValue)
		{
			try
			{
				return ConvertToValue<T>(row[columnName], defaultValue);
			}
			catch
			{
				return defaultValue;
			}
		}

		public static object GetDefaultValue(Type type)
		{
			if (type == typeof(byte)
				|| type == typeof(sbyte)
				|| type == typeof(short)
				|| type == typeof(int)
				|| type == typeof(long)
				|| type == typeof(uint)
				|| type == typeof(ushort)
				|| type == typeof(ulong))
				return 0;
			else if (type == typeof(float))
				return default(float);
			else if (type == typeof(double))
				return default(double);
			else if (type == typeof(decimal))
				return default(decimal);
			else if (type == typeof(bool))
				return false;
			else if (type == typeof(DateTime))
				return new DateTime(1900, 1, 1);
			else
				return string.Empty;
		}
        #endregion


        #region ListControl

        public static void InitListControl(ListControl listControl, int minValue, int maxValue, int defSelectedValue)
        {
            for (int i = minValue; i <= maxValue; i++)
            {
                listControl.Items.Add(new ListItem(i.ToString(), i.ToString()));
            }
            listControl.Items.FindByValue(defSelectedValue.ToString()).Selected = true;
        }

        /// <summary>
        /// Bind object datasource to ListControl.
        /// </summary>
        /// <param name="listControl">ListControl to bind.</param>
        /// <param name="dataSource">Datasource</param>
        /// <param name="dataValueField">Name of value field.</param>
        /// <param name="dataTextField">Name of text field to show.</param>
        public static void BindDataSourceToListControl(ListControl listControl, object dataSource, string dataValueField, string dataTextField)
        {
            CWXUtilities.BindDataSourceToListControl(listControl, dataSource, dataValueField, dataTextField, null, null);
        }

        /// <summary>
        /// Bind object datasource to ListControl.
        /// </summary>
        /// <param name="listControl">ListControl to bind.</param>
        /// <param name="dataSource">Datasource</param>
        /// <param name="dataValueField">Name of value field.</param>
        /// <param name="dataTextField">Name of text field to show.</param>
        /// <param name="firstText">First default text. Set null to ignore this param.</param>
        /// <param name="firstValue">First default value. Set null to ignore this param.</param>
        public static void BindDataSourceToListControl(ListControl listControl, object dataSource, string dataValueField, string dataTextField, string firstValue, string firstText)
        {
            listControl.Items.Clear();
            if (firstText != null && firstValue != null)
            {
                listControl.AppendDataBoundItems = true;
                listControl.Items.Add(new ListItem(firstText, firstValue));
            }
            listControl.DataSource = dataSource;
            listControl.DataValueField = dataValueField;
            listControl.DataTextField = dataTextField;
            listControl.DataBind();
        }

        /// <summary>
        /// Set selected item which has the given value and defaultSearchingType in a ListControl
        /// </summary>
        /// <param name="ddl"><see cref="ListControl"/>/></param>
        /// <param name="defaultSearchingType">Enum DefaultSearchingType</param>
        public static void SetItemSelected(ListControl listControl, string value)
        {
            SetItemSelected(listControl, value, DefaultSearchingType.Value);
        }

        /// <summary>
        /// Set selected item which has the given value and defaultSearchingType in a ListControl 
        /// </summary>
        /// <param name="ddl"><see cref="ListControl"/></param>
        /// <param name="value">System.String</param>
        /// <param name="defaultSearchingType">Enum DefaultSearchingType</param>
        public static void SetItemSelected(ListControl listControl, string value, DefaultSearchingType defaultSearchingType)
        {
            if (listControl == null || value == null)
                return;

            listControl.ClearSelection();

            foreach (ListItem item in listControl.Items)
            {
                if (defaultSearchingType == DefaultSearchingType.Text)
                {
                    if (item.Text.ToUpper().Equals(value.ToUpper()))
                    {
                        item.Selected = true;
                        break;
                    }
                }
                else if (defaultSearchingType == DefaultSearchingType.Value)
                {
                    if (item.Value.ToUpper().Equals(value.ToUpper()))
                    {
                        item.Selected = true;
                        break;
                    }
                }
            }
        }

        #endregion ListControl

        #region Private Methods

        /// <summary>
        /// BindDataToXmlFields
        /// </summary>
        /// <param name="cultureInfo"></param>
        /// <param name="xmlField"></param>
        /// <param name="xmlFieldValue"></param>
        /// <param name="xmlNodeList"></param>
        /// <param name="currentFieldIndex"></param>
        /// <param name="dataObject"></param>
        private static void BindDataToXmlFields(CultureInfo cultureInfo, XmlElement xmlField, object dataObject, string dataType, bool applyTimeFormat)
        {
            //xmlField = (XmlElement)xmlNodeList.Item(currentFieldIndex);
            XmlNode xmlFieldValue = xmlField.FirstChild;
            if (dataObject == null || DBNull.Value.Equals(dataObject))
            {
                switch (dataType)
                {
                    case "System.Int32": // integer
                        xmlFieldValue.InnerText = 0.ToString(cultureInfo);
                        break;
                    case "System.Float": // float
                        xmlFieldValue.InnerText = 0F.ToString(cultureInfo);
                        break;
                    case "System.Double": // double, currency
                        xmlFieldValue.InnerText = 0e.ToString(cultureInfo);
                        break;
                    case "System.Byte": // boolean
                        xmlFieldValue.InnerText = 0.ToString(cultureInfo);
                        break;
                    case "System.Decimal": // currency
                        xmlFieldValue.InnerText = 0d.ToString(cultureInfo);
                        break;
                    case "System.Boolean": // bit
                        xmlFieldValue.InnerText = 0.ToString(cultureInfo);
                        break;
                    default: // default
                        xmlFieldValue.InnerText = string.Empty;
                        break;

                }
            }
            else
            {
                switch (dataType)
                {
                    case "System.DateTime": // date
                        if ((DateTime)dataObject == DateTime.MinValue || ((DateTime)dataObject).Year == 1900)
                            xmlFieldValue.InnerText = string.Empty;
                        else
                        {
                            //Donot apply time format for QueueDate
                            if (string.Equals(xmlField.GetAttribute("name"), "QUEUEDATE", StringComparison.InvariantCultureIgnoreCase) || !applyTimeFormat)
                                xmlFieldValue.InnerText = Convert.ToDateTime(dataObject).ToString("d", cultureInfo.DateTimeFormat);
                            else
                                xmlFieldValue.InnerText = Convert.ToDateTime(dataObject).ToString(cultureInfo);

                        }
                        break;
                    case "System.Decimal": // currency
                        xmlFieldValue.InnerText = Convert.ToDecimal(dataObject).ToString("C", cultureInfo);
                        break;
                    case "System.Boolean": // bit
                        xmlFieldValue.InnerText = Convert.ToInt32(dataObject).ToString();
                        break;
                    default: // default                                    
                        xmlFieldValue.InnerText = dataObject.ToString();
                        break;
                }
            }
        }

        /// <summary>
        /// CreateXmlDocument
        /// </summary>
        /// <param name="topLevelNodeName"></param>
        /// <param name="rowNodeName"></param>
        /// <param name="xmlRoot"></param>
        /// <param name="xmlRow"></param>
        /// <param name="xmlField"></param>
        /// <param name="xmlFieldValue"></param>
        private static void CreateXmlDocument(string topLevelNodeName, string rowNodeName, out XmlElement xmlRoot, out XmlElement xmlRow, out XmlElement xmlField)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlRoot = xmlDoc.DocumentElement;
            xmlRow = xmlDoc.DocumentElement;
            if (!string.IsNullOrEmpty(topLevelNodeName))
            {
                //Create the root element and append it to the XML document.
                xmlRoot = xmlDoc.CreateElement(topLevelNodeName);
                xmlDoc.AppendChild(xmlRoot);
            }
            if (!string.IsNullOrEmpty(rowNodeName))
            {
                //Create the Row and Field elements            
                xmlRow = xmlDoc.CreateElement(rowNodeName);
                if (string.IsNullOrEmpty(topLevelNodeName))
                {
                    xmlDoc.AppendChild(xmlRow);
                }
            }
            xmlField = xmlDoc.CreateElement("field");

            //Build the Field element including its attribute and child

            XmlAttribute xmlFieldName = xmlDoc.CreateAttribute("name");
            //XmlAttribute xmlFieldType = xmlDoc.CreateAttribute("type");
            XmlNode xmlFieldValue = xmlDoc.CreateElement("value");

            xmlField.SetAttributeNode(xmlFieldName);
            //xmlField.SetAttributeNode(xmlFieldType);
            xmlField.AppendChild(xmlFieldValue);
        }

        public static string GetDebtorLabel(DebtorLabelFor labelFor)
        {
            string label = string.Empty;
            switch (labelFor)
            { 
                case DebtorLabelFor.Debt:
                    label = CWXConfigurationManager.AppSettings.ConfigDebtAs;
                    break;
                case DebtorLabelFor.Debtor:
                    label = CWXConfigurationManager.AppSettings.ConfigDebtorAs;
                    break;
                case DebtorLabelFor.DebtorMenu:
                    label = CWXConfigurationManager.AppSettings.ConfigDebtorMenuAs;
                    break;
            }
            return label;
        }
        #endregion

        
    }

    public sealed class CWXGuidGenerator
    {
        public static Guid GenerateNewGuid()
        {
            return Guid.NewGuid();
        }
        public static Guid ConvertFromString(string guidString)
        {
            if (String.IsNullOrEmpty(guidString))
                return Guid.NewGuid();
            return new Guid(guidString);
        }
    }

    public enum DefaultSearchingType
    {
        Text,
        Value
    }

    public enum DebtorLabelFor
    { 
        Debtor,
        Debt,
        DebtorMenu
    }
}