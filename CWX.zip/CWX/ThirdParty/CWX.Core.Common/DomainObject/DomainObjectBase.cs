using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Reflection;
using CWX.Core.Common.Data;
using CWX.Core.Common.Exceptions;
using CWX.Core.Common.Resource;

namespace CWX.Core.Common.DomainObject
{
    /// <summary>
    /// Represents a domain object base.
    /// </summary>
    /// <remarks>
    /// Implements the INotifyPropertyChanged interface and exposes a RaisePropertyChanged method for 
    /// derived classes to raise the PropertyChange event.
    /// </remarks>
    /// <history>
    ///     2008/05/20  [Binh Truong]   Init version.
    /// </history>
    [Serializable]
    public abstract class DomainObjectBase : IDomainObject, INotifyPropertyChanging, INotifyPropertyChanged
    {
        #region Declarations
        

        private const string STRING_END_LOADING_NEVER_CALLED = "EndLoading never called after a BeginLoading call was made.  No operations are permitted until EndLoading has been called.";
        /// <summary>
        /// Indicates whether the business object is being loaded from a database.
        /// </summary>
        private bool _isLoading = false;

        #endregion

        #region Property Set and Change Notification Methods

        /// <summary>
        /// Raises the PropertyChanging event.
        /// </summary>
        /// <param name="propertyName">The property which was changed.</param>
        protected virtual void OnPropertyChanging(string propertyName)
        {
            if (PropertyChanging != null)
                PropertyChanging(this, new PropertyChangingEventArgs(propertyName));
        }

        /// <summary>
        /// Raises the PropertyChanged event.
        /// </summary>
        /// <param name="propertyName">The property which was changed.</param>
        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        public void SetProperty(string propertyName, object value)
        {
            object result = null;
            PropertyInfo pinfo = this.GetType().GetProperty(propertyName);
            TypeConverter converter = null;
            if (pinfo != null)
            {
                converter = TypeDescriptor.GetConverter(pinfo.PropertyType);
            }
            else
            {
                throw new CWXException(string.Format(CWXResourceManager.GetString(ResourceCategory.Errors, "WebCommon_PropertyNameIncorrect"),propertyName));
            }

			try
			{
				if (value != null)
					result = converter.ConvertFrom(value.ToString());
				else if (!(converter is NullableConverter))
				{
					result = CWXUtilities.GetDefaultValue(pinfo.PropertyType);
				}
			}
			catch
			{
				result = CWXUtilities.GetDefaultValue(pinfo.PropertyType);
			}

			try
			{                
				pinfo.SetValue(this, result, null); 
			}
            catch //in case result = null and set to a property must not nullable, it will throw exception
			{                
			}
        }

		public object GetProperty(string propertyName)
		{
			PropertyInfo pinfo = this.GetType().GetProperty(propertyName);
			try
			{
				return pinfo.GetValue(this, null);
			}
			catch
			{
				return null;
			}
		}

        /// <summary>
        /// Called by business entity sub-classes in their property setters to set the value of the property.
        /// If the business object is not in a loading state, this method performs saving original value on the property for auditing.
        /// <example>Example:
        /// <code>
        /// set 
        /// {
        ///    base.SetPropertyValue("Fullname", _fullname, value);
        /// }
        /// </code>
        /// </example>
        /// </summary>
        /// <typeparam name="T">Property Type</typeparam>
        /// <param name="propertyName">Property Name</param>
        /// <param name="currentValue">Variable that holds the current value of the property</param>
        /// <param name="newValue">Is the Value parameter from the Setter Set.</param>
        protected void SetPropertyValue<T>(string propertyName, ref T currentValue, T newValue)
        {
            if (currentValue == null)
            {
                if (newValue == null)
                    return;
            }
            else if (newValue != null)
            {
                if (typeof(T) == typeof(string)) // ignore blank with String value
                {
                    if (currentValue.ToString().Trim().Equals(newValue.ToString().Trim()))
                        return;
                }
                else
                    if(currentValue.Equals(newValue))
                        return;
            }

            if (!_isLoading)
            {
                _isDirty = true;
                OnPropertyChanging(propertyName);
                SaveChangedPropertyValue(propertyName, currentValue, newValue);
                currentValue = newValue;
                OnPropertyChanged(propertyName);

            }
            else
            {
                //if we are loading the object then just assign the value
                currentValue = newValue;
            }
        }

        /// <summary>
        /// This method will add all properties to ChangedPropertyValues with
        ///     orginalValue = default value, newValue = current value
        /// </summary>
        public void SetOnChangedForAllProperties()
        {
            PropertyInfo[] proInfos = this.GetType().GetProperties();
            if (proInfos != null || proInfos.Length > 3)
            {
                _changedPropertyValues = new Dictionary<string, object[]>();
                for (int i = 0; i < proInfos.Length; i++)
                {
                    //Remove the IsDirty, IsNew and ChangedPropertyValues
                    if (!string.Equals(proInfos[i].Name, "IsDirty")
                        && !string.Equals(proInfos[i].Name, "IsNew")
                        && !string.Equals(proInfos[i].Name, "ChangedPropertyValues"))
                    {
                        object orginalValue = proInfos[i].GetType().IsValueType ? Activator.CreateInstance(proInfos[i].GetType()) : null;
                        object newValue = proInfos[i].GetValue(this, null);
                        
                        _changedPropertyValues.Add(
                            proInfos[i].Name,
                            new object[] { orginalValue, newValue }
                            );
                    }
                }
            }
        }

        #endregion

        #region Object Loading, Complete Loading & Persisted Methods

        /// <summary>
        /// Called when the business object is being loaded from a database.
        /// This saves time and processing; by passing property setter logic during loading. After the business object has been loaded the EndLoading MUST be called.
        /// </summary>
        public void BeginLoading()
        {
            _isNew = false;
            _isLoading = true;
        }

        /// <summary>
        /// After a business object has been loaded and the BeginLoading method was called, developers must call this method, EndLoading.
        /// This method marks the entity IsDirty = false.
        /// </summary>
        public void EndLoading()
        {
            _isLoading = false;
            _isDirty = false;
        }

        /// <summary>
        /// This method should be called by the business layer after a Valid business object has been persisted to a database, web service, etc.  
        /// Calling this method, marks this business object as Not Dirty and reset original property values for auditing.  
        /// </summary>
        public void ObjectPersisted()
        {
            _isDirty = false;
            if (_changedPropertyValues != null)
                _changedPropertyValues.Clear();
        }

        #endregion

        #region IDomainObject Members

        private bool _isDirty = false;
        /// <summary>
        /// Gets a value indicating whether the object 
        /// is dirty (changed) since it is loaded or last saved.
        /// Default is false.
        /// </summary>
        /// <remarks>
        /// This is automatically kept track of by this base class.
        /// </remarks>
        [Browsable(false)]
        public bool IsDirty
        {
            get
            {
                EnsureEndLoadingCalled();
                return _isDirty;
            }
        }

        private bool _isNew = true;
        /// <summary>
        /// Gets or sets a value indicating whether the object is new.
        /// Default is true.
        /// </summary>
        [Browsable(false)]
        public virtual bool IsNew
        {
            get
            {
                EnsureEndLoadingCalled();
                return _isNew;
            }
            set
            {
                _isNew = value;
            }
        }

        private Dictionary<string, object[]> _changedPropertyValues;
        /// <summary>
        /// Gets changed property values list.
        /// </summary>
        /// <returns>
        /// List of changed property values. 
        /// Value of property will be in array. First: original value, second: new value.
        /// </returns>
        [Browsable(false)]
        public Dictionary<string, object[]> ChangedPropertyValues
        {
            get
            {
                if (_changedPropertyValues == null)
                    _changedPropertyValues = new Dictionary<string, object[]>();
                return _changedPropertyValues;
            }
        }

        #endregion

        #region INotifyPropertyChanging, INotifyPropertyChanged Members

        /// <summary>
        /// Raised just before a public property of this object is set.
        /// </summary>
        public event PropertyChangingEventHandler PropertyChanging;

        /// <summary>
        /// Raised when a public property of this object is set.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region Private Methods

        private void EnsureEndLoadingCalled()
        {
            if (_isLoading)
                throw new InvalidOperationException(STRING_END_LOADING_NEVER_CALLED);
        }

        /// <summary>
        /// Save original property value of changed property.
        /// </summary>
        /// <typeparam name="T">Property Type</typeparam>
        private void SaveChangedPropertyValue<T>(string propertyName, T originalValue, T newValue)
        {
            if (_changedPropertyValues == null)
            {
                _changedPropertyValues = new Dictionary<string, object[]>();
                _changedPropertyValues.Add(
                    propertyName, 
                    new object[] { originalValue, newValue }
                    );
            }
            else
            {
                if (!_changedPropertyValues.ContainsKey(propertyName))
                    _changedPropertyValues.Add(
                        propertyName, 
                        new object[] { originalValue, newValue }
                        );
            }
        }

        #endregion
    }
}
