using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.DomainObject
{

    /// <summary>
    /// Provides properties indicate status of domain object.
    /// </summary>
    /// <history>
    ///     2008/05/19  [Binh Truong]   Init version.
    /// </history>
    public interface IDomainObject
    {
        /// <summary>
        /// Indicates whether the object is dirty (changed) since it is loaded or last saved.
        /// </summary>
        bool IsDirty{ get; }
        
        /// <summary>
        /// Indicates whether the object is new. 
        /// </summary>
        bool IsNew {get; set;}

        /// <summary>
        /// Gets changed property values list.
        /// </summary>
        /// <returns>
        /// List of changed property values. 
        /// Value of property will be in array. First: original value, second: new value.
        /// </returns>
        /// <history>
        ///     2008/05/20  [Binh Truong]   Init version.
        ///     2008/05/22  [Binh Truong]   Edit property which was stored only original 
        ///                                 value to store both original value and new value.
        /// </history>
        Dictionary<string, object[]> ChangedPropertyValues { get;}
    }
}
