using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.UI.SiteMap
{
    /// <summary>
    /// Holds information for a <see cref="System.Web.SiteMapNode"/> published by a module.
    /// </summary>
    public class SiteMapNodeInfo
    {
        private string _key;
        private string _url;
        private string _title;
        private string _description;
        private IList _roles;
        private NameValueCollection _attributes;
        private NameValueCollection _explicitResourcesKey;
        private string _implicitResourceKey;

        /// <summary>
        /// Initializes a new instance of <see cref="SiteMapNodeInfo"/> using the specified key to identify the page the node represents.
        /// </summary>
        /// <param name="key">The lookup key.</param>
        public SiteMapNodeInfo(string key)
            : this(key, null, null, null, null, null, null, null)
        {
        }

        /// <summary>
        /// Initializes a new instance of <see cref="SiteMapNodeInfo"/> using the specified url and key to identify the page the node represents.
        /// </summary>
        /// <param name="key">The lookup key.</param>
        /// <param name="url">The url of the page that the node represents.</param>
        public SiteMapNodeInfo(string key, string url)
            : this(key, url, null, null, null, null, null, null)
        {
        }

        /// <summary>
        /// Initializes a new instance of <see cref="SiteMapNodeInfo"/> using the specified title, url and the key to identify the page the node represents.
        /// </summary>
        /// <param name="key">The lookup key.</param>
        /// <param name="url">The url of the page that the node represents.</param>
        /// <param name="title">The title for the node.</param>
        public SiteMapNodeInfo(string key, string url, string title)
            : this(key, url, title, null, null, null, null, null)
        {
        }

        /// <summary>
        /// Initializes a new instance of <see cref="SiteMapNodeInfo"/> using the specified description, title, url and the key to identify the page the node represents.
        /// </summary>
        /// <param name="key">The lookup key.</param>
        /// <param name="url">The url of the page that the node represents.</param>
        /// <param name="title">The title for the node.</param>
        /// <param name="description">A description of the page the node represents.</param>
        public SiteMapNodeInfo(string key, string url, string title, string description)
            : this(key, url, title, description, null, null, null, null)
        {
        }

        /// <summary>
        /// Initializes a new instance of <see cref="SiteMapNodeInfo"/> using the specified roles, additional attributes,
        /// explicit and implicit resource keys for localization, description, title, url and the key to identify the page the node represents.
        /// </summary>
        /// <param name="key">The lookup key.</param>
        /// <param name="url">The url of the page that the node represents.</param>
        /// <param name="title">The title for the node.</param>
        /// <param name="description">A description of the page the node represents.</param>
        /// <param name="roles">An <see cref="IList"/> of roles allowed to view the page the node represents.</param>
        /// <param name="attributes">A <see cref="NameValueCollection"/> of additional values to initialize the node.</param>
        /// <param name="explicitResourceKeys">A <see cref="NameValueCollection"/> of explicit resource keys used for localization.</param>
        /// <param name="implicitResourceKey">An implicit resource key used for localization.</param>
        public SiteMapNodeInfo(string key, string url, string title, string description, IList roles,
            NameValueCollection attributes, NameValueCollection explicitResourceKeys, string implicitResourceKey)
        {
            _key = key;
            _url = url;
            _title = title;
            _description = description;
            _roles = roles;
            _attributes = attributes;
            _explicitResourcesKey = explicitResourceKeys;
            _implicitResourceKey = implicitResourceKey;
        }

        /// <summary>
        /// Gets or sets the implicit resource key used for localization.
        /// </summary>
        public string ImplicitResourceKey
        {
            get { return _implicitResourceKey; }
            set { _implicitResourceKey = value; }
        }

        /// <summary>
        /// Gets or sets a <see cref="NameValueCollection"/> of explicit resource keys used for localization.
        /// </summary>
        public NameValueCollection ExplicitResourcesKey
        {
            get { return _explicitResourcesKey; }
            set { _explicitResourcesKey = value; }
        }

        /// <summary>
        /// Gets or sets a <see cref="NameValueCollection"/> of additional values to initialize the node.
        /// </summary>
        public NameValueCollection Attributes
        {
            get { return _attributes; }
            set { _attributes = value; }
        }

        /// <summary>
        /// Gets or sets and <see cref="IList"/> of the roles allowed to view the page represented by the node.
        /// </summary>
        public IList Roles
        {
            get { return _roles; }
            set { _roles = value; }
        }

        /// <summary>
        /// Gets or sets the node description.
        /// </summary>
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        /// <summary>
        /// Gets or sets the node Title.
        /// </summary>
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        /// <summary>
        /// Gets or sets the url of the page represented by the node.
        /// </summary>
        public string Url
        {
            get { return _url; }
            set { _url = value; }
        }

        /// <summary>
        /// Gets or sets the lookup key for the node.
        /// </summary>
        public string Key
        {
            get { return _key; }
            set { _key = value; }
        }
    }
}
