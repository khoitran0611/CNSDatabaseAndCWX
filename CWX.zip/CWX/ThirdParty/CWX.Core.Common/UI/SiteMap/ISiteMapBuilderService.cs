using System.Collections.ObjectModel;

namespace CWX.Core.Common.UI.SiteMap
{
    /// <summary>
    /// Defines a service used to register <see cref="SiteMapNodeInfo"/> objects.
    /// </summary>
    /// <remarks>This service allows the dynamic creation of a <see cref="System.Web.SiteMap"/> during the
    /// module load stage. This service is consumed by the <see cref="Microsoft.Practices.CompositeWeb.Providers.ModuleSiteMapProvider"/> when building
    /// the <see cref="System.Web.SiteMap"/>.</remarks>
    public interface ISiteMapBuilderService
    {
        /// <summary>
        /// Gets the site map root node.
        /// </summary>
        SiteMapNodeInfo RootNode { get; }

        /// <summary>
        /// Adds a node as child of the root node.
        /// </summary>
        /// <param name="node">The node to add.</param>
        void AddNode(SiteMapNodeInfo node);

        /// <summary>
        /// Adds a node as a child of the root node and sets the order with which the node should be displayed.
        /// </summary>
        /// <param name="node">The node to add.</param>
        /// <param name="preferredDisplayOrder">The node display order.</param>
        void AddNode(SiteMapNodeInfo node, int preferredDisplayOrder);

        /// <summary>
        /// Adds a node as a child of another node.
        /// </summary>
        /// <param name="node">The node to add.</param>
        /// <param name="parent">The node under which to add the new node.</param>
        void AddNode(SiteMapNodeInfo node, SiteMapNodeInfo parent);

        /// <summary>
        /// Adds a node as a child of another node, and sets the order with which to display the node.
        /// </summary>
        /// <param name="node">The node to add.</param>
        /// <param name="parent">The node under which to add the new node.</param>
        /// <param name="preferredDisplayOrder">The node display order.</param>
        void AddNode(SiteMapNodeInfo node, SiteMapNodeInfo parent, int preferredDisplayOrder);

        /// <summary>
        /// Gets the children of the specified node.
        /// </summary>
        /// <param name="nodeKey">The key of the parent node.</param>
        /// <returns>A <see cref="ReadOnlyCollection{T}"/> collection of the child nodes.</returns>
        ReadOnlyCollection<SiteMapNodeInfo> GetChildren(string nodeKey);

    }
}
