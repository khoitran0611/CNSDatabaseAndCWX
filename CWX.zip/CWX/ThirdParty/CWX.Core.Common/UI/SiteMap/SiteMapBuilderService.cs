using System.Collections.Generic;
using System.Collections.ObjectModel;

using CWX.Core.Common.Exceptions;
using CWX.Core.Common.Resource;

namespace CWX.Core.Common.UI.SiteMap
{
    /// <summary>
    /// Service implementing the site map information needed to later build the site map.
    /// </summary>
    public class SiteMapBuilderService : ISiteMapBuilderService
    {
        private Dictionary<string, SiteMapNodeInfo> _keyIndex;
        private Dictionary<string, List<SiteMapNodeInfo>> _childNodes;
        private Dictionary<string, int> _nodePreferredOrder;
        private SiteMapNodeInfo _rootNode;


        // We need to replace all calls to _childNodes.Add() to the add sorted method

        /// <summary>
        /// Initialize a new instance of <see cref="SiteMapBuilderService"/>.
        /// </summary>
        public SiteMapBuilderService()
        {
            _rootNode = new SiteMapNodeInfo(CWXResourceManager.GetString(ResourceCategory.Config, "SiteMapRootNodeKey"));
            _keyIndex = new Dictionary<string, SiteMapNodeInfo>();
            _childNodes = new Dictionary<string, List<SiteMapNodeInfo>>();
            _nodePreferredOrder = new Dictionary<string, int>();

            _childNodes.Add(_rootNode.Key, new List<SiteMapNodeInfo>());

        }

        /// <summary>
        /// Gets the current root node.
        /// </summary>
        public SiteMapNodeInfo RootNode
        {
            get { return _rootNode; }
        }

        /// <summary>
        /// Adds a node as child of the root node.
        /// </summary>
        /// <param name="node">The node to add.</param>
        public void AddNode(SiteMapNodeInfo node)
        {
            AddNode(node, int.MaxValue);
            //_childNodes[RootNode.Key].Add(node);
        }

        /// <summary>
        /// Adds a node as a child of the root node and sets the order with which the node should be displayed.
        /// </summary>
        /// <param name="node">The node to add.</param>
        /// <param name="preferredDisplayOrder">The node display order.</param>
        public void AddNode(SiteMapNodeInfo node, int preferredDisplayOrder)
        {

            SafeAddNode(node);
            AddNodeWithOrder(RootNode.Key, node, preferredDisplayOrder);
        }

        /// <summary>
        /// Adds a node as a child of another node.
        /// </summary>
        /// <param name="node">The node to add.</param>
        /// <param name="parent">The node under which to add the new node.</param>
        public void AddNode(SiteMapNodeInfo node, SiteMapNodeInfo parent)
        {
            AddNode(node, parent, int.MaxValue);
        }

        /// <summary>
        /// Adds a node as a child of another node, and sets the order with which to display the node.
        /// </summary>
        /// <param name="node">The node to add.</param>
        /// <param name="parent">The node under which to add the new node.</param>
        /// <param name="preferredDisplayOrder">The node display order.</param>
        public void AddNode(SiteMapNodeInfo node, SiteMapNodeInfo parent, int preferredDisplayOrder)
        {
            SafeAddNode(node);

            if (!_childNodes.ContainsKey(parent.Key))
            {
                _childNodes.Add(parent.Key, new List<SiteMapNodeInfo>());
            }

            AddNodeWithOrder(parent.Key, node, preferredDisplayOrder);
        }
   
        /// <summary>
        /// Gets the children of the specified node.
        /// </summary>
        /// <param name="parentNodeKey">The key of the parent node.</param>
        /// <returns>A <see cref="ReadOnlyCollection{T}"/> collection of the child nodes.</returns>
        public ReadOnlyCollection<SiteMapNodeInfo> GetChildren(string parentNodeKey)
        {
            if (_childNodes.ContainsKey(parentNodeKey))
            {
                return _childNodes[parentNodeKey].AsReadOnly();
            }

            return new List<SiteMapNodeInfo>().AsReadOnly();
        }

        private void SafeAddNode(SiteMapNodeInfo node)
        {
            if (_keyIndex.ContainsKey(node.Key))
            {
                throw new CWXException(CWXResourceManager.GetString(ResourceCategory.Errors, "SiteMap_DuplicateKey"));
            }

            _keyIndex.Add(node.Key, node);
        }

        private void AddNodeWithOrder(string parentKey, SiteMapNodeInfo node, int preferredDisplayOrder)
        {
            _nodePreferredOrder.Add(node.Key, preferredDisplayOrder);
            for (int i = 0; i < _childNodes[parentKey].Count; i++)
            {
                string key = _childNodes[parentKey][i].Key;
                if (_nodePreferredOrder[key] > preferredDisplayOrder)
                {
                    _childNodes[parentKey].Insert(i, node);
                    return;
                }
            }

            _childNodes[parentKey].Add(node);
        }

    }
}
