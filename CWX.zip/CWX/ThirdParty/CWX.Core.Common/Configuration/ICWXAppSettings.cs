﻿using System;
namespace CWX.Core.Common.Configuration
{
    /// <summary>
    /// Represents CWX application setting interface.
    /// </summary>
    /// <history>
    ///     2008/07/03  [Binh Truong]   Init version.
    ///     2008/12/16  [Alvin Marable] Add IsWorkflowServiceAvailable and WorkflowModelSourcePath. 
    /// </history>
    public interface ICWXAppSettings
    {
        /// <summary>
        /// Gets Domain of NetworkAccount.
        /// </summary>
        string AccountDomain { get; }

        /// <summary>
        /// Gets network account to use resources in local area network. 
        /// String format: username|password
        /// </summary>
        string NetworkAccount { get; }

        /// <summary>
        /// Gets global page size in a list.
        /// </summary>
        int PageSize { get; }

        /// <summary>
        /// Gets printer name which will be used to print for CWX web application.
        /// </summary>
        string PrinterName { get; }

        /// <summary>
        /// Gets or sets a boolean indicating show friendly error when an exception throw.
        /// </summary>
        bool ShowFriendlyError { get; }

        /// <summary>
        /// User permission siliding expiration time in minutes.
        /// </summary>
        int UserPermissionSlidingExpiration { get; }

        /// <summary>
        /// Time to update user online status.
        /// </summary>
        int UserOnlineTimeout { get;}

		/// <summary>
		/// Gets the base path for storing image
		/// </summary>
		string ImageStorePath { get;}

        /// <summary>
        /// Gets the base path for helping files
        /// </summary>
        string HelpFileStorePath { get;}

        string CollateralImageStorePath { get;}

        
        

        #region Workflow

        /// <summary>
        /// Gets if workflow service is available.
        /// </summary>
        bool IsWorkflowServiceAvailable { get; }

        /// <summary>
        /// Gets the base path of workflow models (xoml files).
        /// </summary>
        string WorkflowModelSourcePath { get; }

        #endregion

        #region Letter Generator

        /// <summary>
        /// Gets the letter generator exe path.
        /// </summary>
        string LetterGeneratorExePath { get; }

        /// <summary>
        /// Gets if CWX will wait for letter generator to finish.
        /// </summary>
        bool WaitLetterGenerator { get; }

        #endregion

        #region SSIS App

        /// <summary>
        /// Gets the SSIS App exe path.
        /// </summary>
        string SSISAppExePath { get; }

        /// <summary>
        /// Gets if CWX will wait for SSIS App to finish.
        /// </summary>
        bool WaitSSISApp { get; }

        string ConfigAdhocPaymentMenuAs { get; }

        #endregion

        #region AdHoc Payment App

        /// <summary>
        /// Gets the AdHoc Payment App exe path.
        /// </summary>
        string AdHocPaymentAppExePath { get; }

        /// <summary>
        /// Gets if CWX will wait for AdHoc Payment App to finish.
        /// </summary>
        bool WaitAdHocPaymentApp { get; }

        #endregion

        #region Exported Letter Path

        /// <summary>
        /// Gets the exported letter path.
        /// </summary>
        string ExportedLetterPath { get; }


        #endregion

        #region Config Debtor
        string ConfigDebtorAs { get; }
        string ConfigDebtAs { get; }
        string ConfigDebtorMenuAs { get; } 
        #endregion

		#region Client Data Load
		string CDLSourceFileStorePath { get; }
		#endregion

		string DBServerExportLetterPath { get; }

        bool SendMailViaSQLServer {get; }

        long MaxFileLength { get; }
        string PostCodeLabel { get; }
        string CountryAddressLabel { get; }

    }
}
