using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CWX.Core.Common.Configuration
{
    public sealed class CWXConfigurationManager
    {
        private static ICWXAppSettings _appSettings;
        /// <summary>
        /// Gets CWX application settings.
        /// </summary>
        public static ICWXAppSettings AppSettings
        {
            get 
            {
                if (_appSettings == null)
                    _appSettings = new CWXAppSettings();

                return _appSettings; 
            }
        }

        private static CWXConfigurationSection _cwxConfiguarationInstance;
        /// <summary>
        /// Gets instance of CWXConfigurationSection.
        /// </summary>
        public static CWXConfigurationSection CWXConfiguarationInstance
        {
            get
            {
                if (_cwxConfiguarationInstance == null)
                {
                    _cwxConfiguarationInstance = ConfigurationManager.GetSection("cwx") as CWXConfigurationSection;
                    if (_cwxConfiguarationInstance == null)
                        throw new Exception("The 'cwx' section does not exist in web.config.");
                }
                return _cwxConfiguarationInstance;
            }
        }
    }

    /// <summary>
    /// Represents CWX application settings.
    /// </summary>
    /// <history>
    ///     08/07/03    [Binh Truong]   Init version.
    /// </history>
    internal sealed class CWXAppSettings : ICWXAppSettings
    {
        /// <summary>
        /// Init CWX application setting data.
        /// </summary>
        public CWXAppSettings()
        {
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["PageSize"]))
                int.TryParse(ConfigurationManager.AppSettings["PageSize"], out _pageSize);

            if (ConfigurationManager.AppSettings["NetworkAccount"] != null)
                _networkAccount = ConfigurationManager.AppSettings["NetworkAccount"];

            if (ConfigurationManager.AppSettings["Domain"] != null)
                _accountDomain = ConfigurationManager.AppSettings["Domain"];

            if (ConfigurationManager.AppSettings["PrinterName"] != null)
                _printerName = ConfigurationManager.AppSettings["PrinterName"];

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["ShowFriendlyError"]))
                bool.TryParse(ConfigurationManager.AppSettings["ShowFriendlyError"], out _showFriendlyError);

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["UserPermissionSlidingExpiration"]))
                int.TryParse(ConfigurationManager.AppSettings["UserPermissionSlidingExpiration"], out _userPermissionSlidingExpiration);

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["UserOnlineTimeout"]))
                int.TryParse(ConfigurationManager.AppSettings["UserOnlineTimeout"], out _userOnlineTimeout);

			if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["ImageStorePath"]))
				_imageStorePath = ConfigurationManager.AppSettings["ImageStorePath"];

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["HelpFileStorePath"]))
                _helpFileStorePath = ConfigurationManager.AppSettings["HelpFileStorePath"];

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["CollateralImageStorePath"]))
                _collateralImageStorePath = ConfigurationManager.AppSettings["CollateralImageStorePath"];

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["IsWorkflowServiceAvailable"]))
                bool.TryParse(ConfigurationManager.AppSettings["IsWorkflowServiceAvailable"], out _isWorkflowServiceAvailable);

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["WorkflowModelStorePath"]))
                _workflowModelSourcePath = ConfigurationManager.AppSettings["WorkflowModelStorePath"];

            //  Leter Generator
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["LetterGeneratorExePath"]))
                _letterGeneratorExePath = ConfigurationManager.AppSettings["LetterGeneratorExePath"];

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["WaitLetterGenerator"]))
                bool.TryParse(ConfigurationManager.AppSettings["WaitLetterGenerator"], out _waitLetterGenerator);

            //  SSIS App
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["SSISAppExePath"]))
                _sSISAppExePath = ConfigurationManager.AppSettings["SSISAppExePath"];

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["WaitSSISApp"]))
                bool.TryParse(ConfigurationManager.AppSettings["WaitSSISApp"], out _waitSSISApp);

            //  AdHoc Payment App
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["AdHocPaymentAppExePath"]))
                _adHocPaymentAppExePath = ConfigurationManager.AppSettings["AdHocPaymentAppExePath"];

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["WaitAdHocPaymentApp"]))
                bool.TryParse(ConfigurationManager.AppSettings["WaitAdHocPaymentApp"], out _waitAdHocPaymentApp);

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["ConfigAdhocPaymentMenuAs"]))
                _configAdhocPaymentMenuAs = ConfigurationManager.AppSettings["ConfigAdhocPaymentMenuAs"];
            //  Exported Letter Path
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["ExportedLetterPath"]))
                _exportedLetterPath = ConfigurationManager.AppSettings["ExportedLetterPath"];
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["ConfigDebtorAs"]))
                _configDebtorAs = ConfigurationManager.AppSettings["ConfigDebtorAs"];

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["ConfigDebtAs"]))
                _configDebtAs = ConfigurationManager.AppSettings["ConfigDebtAs"];

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["ConfigDebtorMenuAs"]))
                _configDebtorMenuAs = ConfigurationManager.AppSettings["ConfigDebtorMenuAs"];

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["DBServerExportLetterPath"]))
                _DBServerExportLetterPath = ConfigurationManager.AppSettings["DBServerExportLetterPath"];

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["SendMailViaSQLServer"]))
                bool.TryParse(ConfigurationManager.AppSettings["SendMailViaSQLServer"], out _SendMailViaSQLServer);

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["MaxFileLength"]))
                long.TryParse(ConfigurationManager.AppSettings["MaxFileLength"], out _MaxFileLength);
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["PostCodeLabel"]))
                _postCodeLabel = ConfigurationManager.AppSettings["PostCodeLabel"];

            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["CountryAddressLabel"]))
                _countryAddressLabel = ConfigurationManager.AppSettings["CountryAddressLabel"];

			if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["CDLSourceFileStorePath"]))
				_CDLSourceFileStorePath = ConfigurationManager.AppSettings["CDLSourceFileStorePath"];
        }

        private int _pageSize;
        /// <summary>
        /// Gets global page size in a list.
        /// </summary>
        public int PageSize
        {
            get { return _pageSize; }
        }

        private string _networkAccount = string.Empty;
        /// <summary>
        /// Gets network account to use resources in local area network. 
        /// String format: username|password
        /// </summary>
        public string NetworkAccount
        {
            get { return _networkAccount; }
        }

        private string _accountDomain = string.Empty;
        /// <summary>
        /// Gets Domain of NetworkAccount.
        /// </summary>
        public string AccountDomain
        {
            get { return _accountDomain; }
        }

        private string _printerName = string.Empty;
        /// <summary>
        /// Gets printer name which will be used to print for CWX web application.
        /// </summary>
        public string PrinterName
        {
            get { return _printerName; }
        }

        private bool _showFriendlyError;
        /// <summary>
        /// Gets or sets a boolean indicating show friendly error when an exception throw.
        /// </summary>
        public bool ShowFriendlyError
        {
            get { return _showFriendlyError; }
        }

        private int _userPermissionSlidingExpiration;
        /// <summary>
        /// User permission siliding expiration time in minutes.
        /// </summary>
        public int UserPermissionSlidingExpiration
        {
            get { return _userPermissionSlidingExpiration; }
        }

        private int _userOnlineTimeout;
        /// <summary>
        /// Time to update user online status.
        /// </summary>
        public int UserOnlineTimeout
        {
            get { return _userOnlineTimeout; }
        }

		private string _imageStorePath;
		/// <summary>
		/// Gets the base path for storing image
		/// </summary>
		public string ImageStorePath
		{
			get { return _imageStorePath; }
		}

        private string _helpFileStorePath;
        /// <summary>
        /// Gets the base path for storing help file
        /// </summary>
        public string HelpFileStorePath
        {
            get { return _helpFileStorePath; }
        }

        private string _collateralImageStorePath;
        public string CollateralImageStorePath
        {
            get { return _collateralImageStorePath; }
        }

        #region Config Debtor
        private string _configDebtorAs;
        public string ConfigDebtorAs
        {
            get { return _configDebtorAs; }
        }

        private string _configDebtAs;
        public string ConfigDebtAs
        {
            get { return _configDebtAs; }
        }
        private string _configDebtorMenuAs;
        public string ConfigDebtorMenuAs
        {
            get { return _configDebtorMenuAs; }
        } 
        #endregion

        #region Workflow
        private bool _isWorkflowServiceAvailable;
        /// <summary>
        /// Gets if workflow service is available.
        /// </summary>
        public bool IsWorkflowServiceAvailable
        {
            get { return _isWorkflowServiceAvailable; }
        }

        private string _workflowModelSourcePath = string.Empty;
        /// <summary>
        /// Gets the base path of workflow models (xoml files).
        /// </summary>
        public string WorkflowModelSourcePath
        {
            get { return _workflowModelSourcePath; }
        }

        #endregion

        #region Letter Generator

        private bool _waitLetterGenerator;
        /// <summary>
        /// Gets if CWX will wait for letter generator to finish.
        /// </summary>
        public bool WaitLetterGenerator
        {
            get { return _waitLetterGenerator; }
        }

        private string _letterGeneratorExePath = string.Empty;
        /// <summary>
        /// Gets the letter generator exe path.
        /// </summary>
        public string LetterGeneratorExePath
        {
            get { return _letterGeneratorExePath; }
        }

        #endregion

        #region SSIS App

        private bool _waitSSISApp;
        /// <summary>
        /// Gets if CWX will wait for SSIS App to finish.
        /// </summary>
        public bool WaitSSISApp
        {
            get { return _waitSSISApp; }
        }

        private string _sSISAppExePath = string.Empty;
        /// <summary>
        /// Gets the SSIS app exe path.
        /// </summary>
        public string SSISAppExePath
        {
            get { return _sSISAppExePath; }
        }

        #endregion

        #region AdHoc Payment App

        private bool _waitAdHocPaymentApp;
        /// <summary>
        /// Gets if CWX will wait for AdHoc Payment App to finish.
        /// </summary>
        public bool WaitAdHocPaymentApp
        {
            get { return _waitAdHocPaymentApp; }
        }

        private string _adHocPaymentAppExePath = string.Empty;
        /// <summary>
        /// Gets the AdHoc Payment app exe path.
        /// </summary>
        public string AdHocPaymentAppExePath
        {
            get { return _adHocPaymentAppExePath; }
        }

        private string _configAdhocPaymentMenuAs = string.Empty;
        /// <summary>
        /// Gets the AdHoc Payment app menu name.
        /// </summary>
        public string ConfigAdhocPaymentMenuAs
        {
            get { return _configAdhocPaymentMenuAs; }
        }
        #endregion

        #region Exported Letter Path

        private string _exportedLetterPath = string.Empty;
        /// <summary>
        /// Gets the exported letter path.
        /// </summary>
        public string ExportedLetterPath 
        {
            get { return _exportedLetterPath; }
        }


        #endregion

		#region Client Data Load
		private string _CDLSourceFileStorePath;
		public string CDLSourceFileStorePath
		{
			get { return _CDLSourceFileStorePath; }
		} 
		#endregion

		private string _DBServerExportLetterPath;
        public string DBServerExportLetterPath
        {
            get { return _DBServerExportLetterPath; }
        }

        private bool _SendMailViaSQLServer;
        public bool SendMailViaSQLServer
        {
            get { return _SendMailViaSQLServer; }
        }

        private long _MaxFileLength;
        public long MaxFileLength
        {
            get { return _MaxFileLength; }
        }

        private string _countryAddressLabel;
        public string CountryAddressLabel
        {
            get { return _countryAddressLabel; }
        }

        private string _postCodeLabel;
        public string PostCodeLabel
        {
            get { return _postCodeLabel; }
        }
    }
}
