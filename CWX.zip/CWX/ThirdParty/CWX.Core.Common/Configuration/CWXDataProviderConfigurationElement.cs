using System;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;

namespace CWX.Core.Common.Configuration
{
    public class CWXDataProviderConfigurationElement : ConfigurationElement
    {
        [ConfigurationProperty("name", IsRequired = true)]
        public string Name
        {
            get
            {
                return (string)this["name"];
            }
            set
            {
                this["name"] = value;
            }
        }

        [ConfigurationProperty("type", IsRequired = true)]
        [TypeConverter(typeof(AssemblyQualifiedTypeNameConverter))]
        public Type Type
        {
            get
            {
                return (Type)this["type"];
            }
            set
            {
                this["type"] = value;
            }
        }
    }
}
