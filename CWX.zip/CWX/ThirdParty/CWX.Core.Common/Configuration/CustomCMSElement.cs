using System;
using System.Configuration;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Configuration
{

    #region CustomCMSElement

    public class CustomCMSElement : ConfigurationElement
    {

        public CustomCMSElement() { }

        /// <summary>
        /// Gets or sets the custom CMS name.
        /// </summary>
        /// <value>Custom CMS name.</value>
        [ConfigurationProperty("name", IsRequired = true)]
        public string Name
        {
            get
            {
                return (string)base["name"];
            }
            set
            {
                base["name"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the custom CMS description.
        /// </summary>
        /// <value>Custom CMS description.</value>
        [ConfigurationProperty("description", IsRequired = true)]
        public string Description
        {
            get
            {
                return (string)base["description"];
            }
            set
            {
                base["description"] = value;
            }
        }

        /// <summary>
        /// Gets or sets property indicate enable or disable element.
        /// </summary>
        /// <value>Boolean value.</value>
        [ConfigurationProperty("enabled", IsRequired = true)]
        public bool Enabled
        {
            get
            {
                return Convert.ToBoolean(base["enabled"]);
            }
            set
            {
                base["enabled"] = value;
            }
        }



    } 
    #endregion

    #region CustomCMSElementCollection
    /// <summary>
    /// The custom CMS name collection
    /// </summary>
    public class CustomCMSElementCollection : ConfigurationElementCollection
    {
        protected override ConfigurationElement CreateNewElement()
        {
            return new CustomCMSElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((CustomCMSElement)element).Name;
        }


        /// <summary>
        /// Gets or sets the <see cref="T:CustomCMSElement"/> at the specified index.
        /// </summary>
        /// <value></value>
        public CustomCMSElement this[int index]
        {
            get { return (CustomCMSElement)base.BaseGet(index); }
            set
            {
                if (base.BaseGet(index) != null)
                    base.BaseRemoveAt(index);
                this.BaseAdd(index, value);
            }
        }
        /// <summary>
        /// Determines whether [contains] [the specified name].
        /// </summary>
        /// <param name="name">The custom CMS name</param>
        /// <returns>
        /// 	<c>true</c> if [contains] [the specified path]; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(string name)
        {
            foreach (CustomCMSElement customCMSElement in this)
            {
                if (customCMSElement.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }
    } 
    #endregion
}
