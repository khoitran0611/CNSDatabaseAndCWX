using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CWX.Core.Common.Configuration
{
    public class CWXConnectionDBConfigurationElement : ConfigurationElement
    {
        [ConfigurationProperty("cwxConnectionStringName", IsRequired = true)]
        public string CWXConnectionStringName
        {
            get
            {
                return (string)this["cwxConnectionStringName"];
            }
            set
            {
                this["cwxConnectionStringName"] = value;
            }
        }

        [ConfigurationProperty("coreConnectionStringName", IsRequired = true)]
        public string CoreConnectionStringName
        {
            get
            {
                return (string)this["coreConnectionStringName"];
            }
            set
            {
                this["coreConnectionStringName"] = value;
            }
        }

    }
}
