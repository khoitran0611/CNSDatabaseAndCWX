using System;
using System.Configuration;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Common.Configuration
{
    public class CWXConfigurationSection : ConfigurationSection
    {
        [ConfigurationProperty("dataMapping",IsRequired=true)]
        public CWXDataMappingConfigurationElement DataMapping
        {
            get 
            {
                return (CWXDataMappingConfigurationElement)this["dataMapping"];
            }
            set
            {
                this["dataMapping"] = value;
            }
        }

        [ConfigurationProperty("dataProvider", IsRequired=true)]
        public CWXDataProviderConfigurationElement DataProvider
        {
            get
            {
                return (CWXDataProviderConfigurationElement)this["dataProvider"];
            }
            set
            {
                this["dataProvider"] = value;
            }
        }

        [ConfigurationProperty("connectionStrings", IsRequired = true)]
        public CWXConnectionDBConfigurationElement Connections
        {
            get
            {
                return (CWXConnectionDBConfigurationElement)this["connectionStrings"];
            }
            set
            {
                this["connectionStrings"] = value;
            }
        }

        /// <summary>
        /// Gets the custom CMS defined list.
        /// </summary>
        /// <value>Custom CMSs.</value>
        [ConfigurationProperty("CustomCMSs", IsDefaultCollection = false)]
        public CustomCMSElementCollection CustomCMSs
        {
            get
            {
                return (CustomCMSElementCollection)base["CustomCMSs"];
            }
        }
    }
}
