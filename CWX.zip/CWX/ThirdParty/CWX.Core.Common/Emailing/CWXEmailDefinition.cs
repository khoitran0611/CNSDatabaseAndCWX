﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace CWX.Core.Common.Emailing
{
    public enum BodyFormat
    {
        Html = 0,
        PlainText = 1
    }

    public class CWXEmailDefinition
    {
        private string _From;
        /// <summary>
        /// The email address appears in the from field
        /// </summary>
        public string From
        {
            get { return _From; }
            set { _From = value; }
        }

        private string _ReplyTo;
        /// <summary>
        /// Reply to address
        /// </summary>
        public string ReplyTo
        {
            get { return _ReplyTo; }
            set { _ReplyTo = value; }
        }

        private string _Subject;
        /// <summary>
        /// The subject of the email
        /// </summary>
        public string Subject
        {
            get { return _Subject; }
            set { _Subject = value; }
        }

        private string _Comment;
        /// <summary>
        /// Any comment to the recipients, if set, otherwise an empty string
        /// </summary>
        public string Comment
        {
            get { return _Comment; }
            set { _Comment = value; }
        }

        private string _BodyPlainText;
        /// <summary>
        /// The body plain text of the email
        /// Appends Comment if any
        /// </summary>
        public string BodyPlainText
        {
            get { return BareLFHandling(_BodyPlainText + (!string.IsNullOrEmpty(Comment) ? ("\n" + Comment) : "")); }
            set { _BodyPlainText = value; }
        }

        /// <summary>
        /// Every line in an Internet mail message is required to end with CR LF.
        /// Ref.:http://cr.yp.to/docs/smtplf.html
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        private string BareLFHandling(string text)
        {
            if (!string.IsNullOrEmpty(text))
            {
                if (!text.EndsWith("\n"))
                    text += "\n";

                text = text.Replace("\n", "\r\n");
                text = text.Replace("\r\r", "\r\n");
                text = text.Replace("\n\n", "\r\n");

            }
            return text;
        }

        private string _BodyHtml;
        /// <summary>
        /// The html body text of the email
        /// Appends Comment if any
        /// </summary>
        public string BodyHtml
        {
            get { return BareLFHandling(_BodyHtml + (!string.IsNullOrEmpty(Comment) ? ("<br><br>" + Comment) : "")); }
            set { _BodyHtml = value; }
        }

        private BodyFormat _BodyFormat;
        /// <summary>
        /// HTML(0), Text(1)
        /// </summary>
        public BodyFormat BodyFormat
        {
            get { return _BodyFormat; }
            set { _BodyFormat = value; }
        }

        private Encoding _Encoding;
        /// <summary>
        /// The encoding of the email
        /// </summary>
        public Encoding Encoding
        {
            get { return _Encoding; }
            set { _Encoding = value; }
        }

        /// <summary>
        /// The email address appears in the recipient field
        /// </summary>
        /// <param name="to"></param>
        public void AddRecipient(string to)
        {
            if (!string.IsNullOrEmpty(to))
            {
                // Support addding of comma and semicolon sep emails in one string
                string[] emails = to.Replace(";", ",").Split(char.Parse(","));
                foreach (string s in emails)
                {
                    if (!string.IsNullOrEmpty(s))
                        _Recipients.Add(s);
                }
            }
        }

        private List<string> _Recipients=new List<string>();
        /// <summary>
        /// List of strings with the email recipients
        /// </summary>
        public List<string> Recipients
        {
            get { return _Recipients; }
        }

        /// <summary>
        /// The email address appears in the recipient CC (Carbon Copy) field
        /// </summary>
        /// <param name="to"></param>
        public void AddRecipientCc(string toCc)
        {
            if (!string.IsNullOrEmpty(toCc))
            {
                // Support addding of comma and semicolon sep emails in one string
                string[] emails = toCc.Replace(";", ",").Split(char.Parse(","));
                foreach (string s in emails)
                {
                    if (!string.IsNullOrEmpty(s))
                        _RecipientsCc.Add(s);
                }
            }
        }

        private List<string> _RecipientsCc=new List<string>();
        /// <summary>
        /// List of strings with the email recipients CC (Carbon Copy)
        /// </summary>
        public List<string> RecipientsCc
        {
            get { return _RecipientsCc; }
        }

        /// <summary>
        /// The email address appears in the recipient field BCC (Blind Carbon Copy)
        /// </summary>
        /// <param name="to"></param>
        public void AddRecipientBcc(string toBcc)
        {
            if (!string.IsNullOrEmpty(toBcc))
            {
                // Support addding of comma and semicolon sep emails in one string
                string[] emails = toBcc.Replace(";", ",").Split(char.Parse(","));
                foreach (string s in emails)
                {
                    if (!string.IsNullOrEmpty(s))
                        _RecipientsBcc.Add(s);
                }
            }
        }

        private List<string> _RecipientsBcc=new List<string>();
        /// <summary>
        /// List of strings with the email recipients BCC (Blind Carbon Copy)
        /// </summary>
        public List<string> RecipientsBcc
        {
            get { return _RecipientsBcc; }
        }

        /// <summary>
        /// The path of the attached file
        /// </summary>
        /// <param name="path"></param>
        public void AddAttachmentPath(string path)
        {
            _AttachmentPaths.Add(path);
        }

        private List<string> _AttachmentPaths = new List<string>();
        /// <summary>
        /// List of strings with the paths of attached files
        /// </summary>
        public List<string> AttachmentPaths
        {
            get { return _AttachmentPaths; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="path"></param>
        public void AddAttachment(string name, Stream value)
        {
            _Attachments.Add(name, value);
        }

        Dictionary<string, Stream> _Attachments = new Dictionary<string, Stream>();
        /// <summary>
        /// List of strings with the paths of attached files
        /// </summary>
        public Dictionary<string, Stream> Attachments
        {
            get { return _Attachments; }
        }

        /// <summary>
        /// The mail header
        /// </summary>
        /// <param name="header"></param>
        public void AddHeader(string name, string value)
        {
            _Headers.Add(name, value);
        }

        Dictionary<string, string> _Headers = new Dictionary<string, string>();
        /// <summary>
        /// List of strings with the email headers
        /// </summary>
        public Dictionary<string, string> Headers
        {
            get { return _Headers; }
        }
    }
}
