﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;

namespace CWX.Core.Common.Emailing
{
    public class CWXMailer
    {
        /// <summary>
        /// Local enum to distinguish recipient types
        /// </summary>
        private enum RecipientType
        {
            To,
            BCC,
            CC,
        }

        public void Send(CWXEmailDefinition emailDefinition, string smtpServer,
            int smtpPort, string userName, string password, bool enableSSL)
        {
            MailMessage mailMessage = new MailMessage();
            // Create a MailMessage object and assign its properties from CWXEmailDefinition
            CreateMailMessage(emailDefinition, mailMessage);
            // Create an instance of the SmtpClient class () and specify details about the SMTP server to use
            SmtpClient smtpClient = CreateSmtpClient(emailDefinition, smtpServer, smtpPort, userName, password, enableSSL);

            smtpClient.Send(mailMessage);
        }

        private SmtpClient CreateSmtpClient(CWXEmailDefinition emailDefinition, string smtpServer, 
            int smtpPort, string userName, string password, bool enableSSL)
        {
            SmtpClient smtpClient = new SmtpClient();
            smtpClient.Host = smtpServer;
            smtpClient.Port = smtpPort;
            if (!string.IsNullOrEmpty(userName))
            {
                smtpClient.Credentials = new NetworkCredential(userName, password);
            }
            smtpClient.EnableSsl = enableSSL;
            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.Timeout = 300000;

            return smtpClient;
        }

        private void CreateMailMessage(CWXEmailDefinition emailDefinition, MailMessage mailMessage)
        {
            if (string.IsNullOrEmpty(emailDefinition.From))
            {
                throw new ArgumentException("'From' is not allowed empty");
            }
            if (!string.IsNullOrEmpty(emailDefinition.ReplyTo))
            {
                mailMessage.ReplyTo = GetMailAddress(emailDefinition.ReplyTo.Trim(),emailDefinition.Encoding);
            }
            mailMessage.From = GetMailAddress( emailDefinition.From.ToString(),emailDefinition.Encoding);
            mailMessage.Subject = emailDefinition.Subject;
            if (EncodeString(emailDefinition.Subject))
                mailMessage.SubjectEncoding = emailDefinition.Encoding;

            CreateRecipients(emailDefinition, mailMessage);
            CreateBody(emailDefinition, mailMessage);
            CreateHeaders(emailDefinition, mailMessage);
            CreateAttachment(emailDefinition, mailMessage);
        }

        /// <summary>
        /// Adds Attachment(s) to email.
        /// </summary>
        /// <param name="ced"></param>
        private void CreateAttachment(CWXEmailDefinition emailDefinition, MailMessage mailMessage)
        {
            Attachment attatch;
            mailMessage.Attachments.Clear();
            foreach (string item in emailDefinition.AttachmentPaths)
            {                
                attatch = new Attachment(item.Trim());
                mailMessage.Attachments.Add(attatch);
            }
            foreach (KeyValuePair<string, Stream> item in emailDefinition.Attachments)
            {
                attatch = new Attachment(item.Value, item.Key);
                mailMessage.Attachments.Add(attatch);
            }
        }

        /// <summary>
        /// Adds custom headers to email
        /// </summary>
        /// <param name="ced"></param>
        private void CreateHeaders(CWXEmailDefinition emailDefinition, MailMessage mailMessage)
        {
            mailMessage.Headers.Clear();
            foreach (KeyValuePair<string, string> header in emailDefinition.Headers)
                mailMessage.Headers.Add(header.Key, header.Value);
        }

        /// <summary>
        /// Creates the email body based on bodyFormat.
        /// </summary>
        /// <param name="ced"></param>
        private void CreateBody(CWXEmailDefinition emailDefinition, MailMessage mailMessage)
        {
            mailMessage.BodyEncoding = emailDefinition.Encoding;
            string bodyHtml = emailDefinition.BodyHtml;
            string bodyPlainText = emailDefinition.BodyPlainText;

            if (emailDefinition.BodyFormat == BodyFormat.Html)
            {
                mailMessage.Body = bodyHtml;
                mailMessage.IsBodyHtml = true;
            }
            else
                mailMessage.Body = bodyPlainText;            
        }

        private void CreateRecipients(CWXEmailDefinition emailDefinition, MailMessage mailMessage)
        {
            mailMessage.To.Clear();
            mailMessage.CC.Clear();
            mailMessage.Bcc.Clear();
            if (emailDefinition.Recipients.Count > 0)
                AddRecipients(RecipientType.To, emailDefinition.Recipients, emailDefinition.Encoding,mailMessage);
            else
                throw new ArgumentNullException("No email recipient was specified");
            if (emailDefinition.RecipientsBcc.Count > 0)
                AddRecipients(RecipientType.BCC, emailDefinition.RecipientsBcc, emailDefinition.Encoding, mailMessage);
            if (emailDefinition.RecipientsCc.Count > 0)
                AddRecipients(RecipientType.CC, emailDefinition.RecipientsCc, emailDefinition.Encoding, mailMessage);
        }

        /// <summary>
        /// Adds recipients based on RecipientType (To, BCC, CC) to the MailMessage
        /// </summary>
        /// <param name="type"></param>
        /// <param name="recipients"></param>
        /// <param name="enc"></param>
        private void AddRecipients(RecipientType type, List<string> recipients, Encoding enc, MailMessage mailMessage)
        {
            MailAddressCollection addresses = GetMailAddresses(recipients, enc);
            foreach (MailAddress address in addresses)
            {
                switch (type)
                {
                    case RecipientType.To:
                        mailMessage.To.Add(address);
                        break;
                    case RecipientType.BCC:
                        mailMessage.Bcc.Add(address);
                        break;
                    case RecipientType.CC:
                        mailMessage.CC.Add(address);
                        break;
                }
            }
        }

        /// <summary>
        /// Creates collection of MailAddress based on List of strings
        /// </summary>
        /// <param name="addresses"></param>
        /// <param name="enc"></param>
        /// <returns></returns>
        private MailAddressCollection GetMailAddresses(List<string> addresses, Encoding enc)
        {
            MailAddressCollection mailAddresses = new MailAddressCollection();
            foreach (string address in addresses)
                mailAddresses.Add(GetMailAddress(address, enc));

            return mailAddresses;
        }

        /// <summary>
        /// Creates a MailAddress based on a string
        /// </summary>
        /// <param name="address"></param>
        /// <param name="enc"></param>
        /// <returns></returns>
        private MailAddress GetMailAddress(string address, Encoding encoding)
        {
            MailAddress mailAddress;
            bool encodeAddress = EncodeString(address);

            string[] addressSplit = address.Split(new char[1] { '<' });
            if (addressSplit.Length == 2)
            {
                string name = addressSplit[0].Trim();
                string email = addressSplit[1].Substring(0, addressSplit[1].Length - 1).Trim().ToLower();
                if (encodeAddress)
                    mailAddress = new MailAddress(email, name, encoding);
                else
                    mailAddress = new MailAddress(email, name);
            }
            else
                mailAddress = new MailAddress(address);

            return mailAddress;
        }

        /// <summary>
        /// Checks if the string of the email should be encoded.
        /// </summary>
        /// <param name="address"></param>
        /// <returns></returns>
        private bool EncodeString(string text)
        {
            // If string contains non-ASCII characters, the iso-8859-1 character set 
            // is default used for the string encoding. 
            // We would like to use the same encoding as the rest of the email,
            // so we need to find if the string contains any non-ASCII chars
            // If a string contains only the characters from ASCII 32 (oct 40)
            // to ASCII 126 (oct 176), then the string should not be encoded
            string strRegexp = @"^([\040-\176]+)$";
            Regex re = new Regex(strRegexp);
            if (re.IsMatch(text))
                return false;
            else
                return true;
        }
    }
}
