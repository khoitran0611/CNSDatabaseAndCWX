﻿using System;
using System.Collections.Generic;
using System.Text;
using CWX.Core.Common.SendSMS;
using System.Configuration.Provider;
using CWX.Core.Common.Data;
using System.Data;
using CWX.Core.Common.Emailing;

namespace CWX.Core.SMSProviders.Clickatell.SMTP
{
    public class CWXSendSMSViaSMTPProvider : CWXSendSMSProvider
    {
        private string _CurrentApi_id;
        private string _ConnectionStringName;        
        private Dictionary<string, object> smsSetting = new Dictionary<string, object>();

        #region Properties

        private IDataProvider _dataProvider;

        public IDataProvider DataProvider
        {
            get
            {
                if (_dataProvider == null)
                    _dataProvider = new DataProviderFactory().Create(_ConnectionStringName);
                return _dataProvider;
            }
            set { _dataProvider = value; }
        }

        #endregion

        /// <summary>
        /// Initialize the provider.
        /// </summary>
        /// <param name="name">Name of the provider.</param>
        /// <param name="config">Configuration settings.</param>
        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            if ((config == null) || (config.Count == 0))
                throw new ArgumentNullException("You must supply a valid configuration dictionary.");

            //Let ProviderBase perform the basic initialization
            base.Initialize(name, config);

            //Perform feature-specific provider initialization here            

            if (String.IsNullOrEmpty(config["api_id"]))
                throw new ProviderException("You must specify a api_id attribute.");

            _CurrentApi_id = config["api_id"];
            config.Remove("api_id");

            //Get the connection string            
            if (String.IsNullOrEmpty( config["connectionStringName"]))
                throw new ProviderException("You must specify a connectionStringName attribute.");

            _ConnectionStringName = config["connectionStringName"];
            config.Remove("connectionStringName");            

            //Check to see if unexpected attributes were set in configuration
            if (config.Count > 0)
            {
                string extraAttribute = config.GetKey(0);
                if (!String.IsNullOrEmpty(extraAttribute))
                    throw new ProviderException("The following unrecognized attribute was found in " + Name + "'s configuration: '" +
                                                extraAttribute + "'");
                else
                    throw new ProviderException("An unrecognized attribute was found in the provider's configuration.");
            }
        }

        public override bool Send(string mobilePhone, string message)
        {
            GetSMSSetting();

            object smsUserName;
            smsSetting.TryGetValue("SMS_UserName", out smsUserName);
            object smsPassword;
            smsSetting.TryGetValue("SMS_Password", out smsPassword);
            string smsMessage = BuildSMSMessage(mobilePhone, message, smsUserName.ToString(), smsPassword.ToString());

            CWXEmailDefinition emailDefinition = BuildEmailDefinition(smsMessage);
            CWXMailer mailer = new CWXMailer();

            object smtpUerName;
            smsSetting.TryGetValue("SMTP_UserName", out smtpUerName);
            object smtpPassword;
            smsSetting.TryGetValue("SMTP_Password", out smtpPassword);
            object enableSSL;
            smsSetting.TryGetValue("SMTP_EnableSSL",out enableSSL);
            object smtpServer;
            smsSetting.TryGetValue("ServerName",out smtpServer);
            object smtpPort;
            smsSetting.TryGetValue("Port",out smtpPort);
            mailer.Send(emailDefinition, smtpServer.ToString(), int.Parse(smtpPort.ToString()), smtpUerName.ToString(), smtpPassword.ToString(), bool.Parse(enableSSL.ToString()));

            return true;
        }

        private void GetSMSSetting()
        {
            smsSetting = new Dictionary<string, object>();
            using (IDataExecutionContext dataContext = DataProvider.BeginExecution())
            {
                string sql = @"SELECT top 1 ServerName, Port, EmailAddress, SMTP_UserName, 
                    SMTP_Password, SMTP_EnableSSL, SMS_Gateway, SMS_UserName, SMS_Password 
                    FROM [dbo].[CWX_SMTP_SMS_Settings] ";
                dataContext.SetCommandText(sql);
                using (IDataReader reader = dataContext.RunReader())
                {
                    while (reader.Read())
                    {
                        smsSetting.Add("ServerName", reader.GetString(reader.GetOrdinal("ServerName")));
                        smsSetting.Add("Port", reader.GetInt32(reader.GetOrdinal("Port")));
                        smsSetting.Add("EmailAddress", reader.GetString(reader.GetOrdinal("EmailAddress")));
                        smsSetting.Add("SMTP_UserName", reader.GetString(reader.GetOrdinal("SMTP_UserName")));
                        smsSetting.Add("SMTP_Password", reader.GetString(reader.GetOrdinal("SMTP_Password")));
                        smsSetting.Add("SMTP_EnableSSL", reader.GetBoolean(reader.GetOrdinal("SMTP_EnableSSL")));
                        smsSetting.Add("SMS_Gateway", reader.GetString(reader.GetOrdinal("SMS_Gateway")));
                        smsSetting.Add("SMS_UserName", reader.GetString(reader.GetOrdinal("SMS_UserName")));
                        smsSetting.Add("SMS_Password", reader.GetString(reader.GetOrdinal("SMS_Password")));
                        break;
                    }
                }

            }
        }

        private CWXEmailDefinition BuildEmailDefinition(string message)
        {
            object emailFrom;
            smsSetting.TryGetValue("EmailAddress", out emailFrom);
            object recipient;
            smsSetting.TryGetValue("SMS_Gateway", out recipient);

            CWXEmailDefinition emailDefinition = new CWXEmailDefinition();
            emailDefinition.From = emailFrom.ToString();            
            emailDefinition.AddRecipient(recipient.ToString());
            emailDefinition.Subject = "CWX";
            emailDefinition.BodyFormat = BodyFormat.PlainText;
            emailDefinition.BodyPlainText = message;
            return emailDefinition;
        }

        private string BuildSMSMessage(string mobilePhone, string message, string userName, string password)
        {
            string smsMessage = "api_id:" + _CurrentApi_id;
            smsMessage += Environment.NewLine;
            smsMessage += "user:" + userName;
            smsMessage += Environment.NewLine;
            smsMessage += "password:" + password;
            smsMessage += Environment.NewLine;
            smsMessage += "to:" + mobilePhone;
            smsMessage += Environment.NewLine;
            smsMessage += "text:" + message;

            return smsMessage;
        }
    }
}
