-- Scripts 2.4.2:

/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Get]    Script Date: 08/13/2008 13:51:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LoginLog_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Get]    Script Date: 08/13/2008 13:51:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get login log infomation.
-- History:
--	2008/08/13	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LoginLog_Get]
(
	@UserID int,
	@DbConnectionName nvarchar(500)
)
	
AS
	SET NOCOUNT ON
	SELECT  CWX_LoginLog.UserID, CWX_LoginLog.LoginTime, CWX_LoginLog.LogoutTime, CWX_LoginLog.MinutesLoggedIn, 
				CWX_LoginLog.DBConnectionName, CWX_User.SignOn
	FROM    CWX_LoginLog INNER JOIN
				CWX_User ON CWX_LoginLog.UserID = CWX_User.UserID
	WHERE   (CWX_LoginLog.UserID = @UserID) AND 
			(CWX_LoginLog.DBConnectionName = @DBConnectionName)
' 
END
GO


-- Scripts 2.4.4:

-- =============================================
-- Description:	Get login log infomation.
-- History:
--	2008/08/13	[Binh Truong]	Init version.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_LoginLog_Get]
(
	@UserID int,
	@DbConnectionName nvarchar(500)
)
	
AS
	SET NOCOUNT ON
	SELECT  CWX_LoginLog.UserID, CWX_LoginLog.LoginTime, CWX_LoginLog.LogoutTime, CWX_LoginLog.MinutesLoggedIn, 
				CWX_LoginLog.DBConnectionName, CWX_User.SignOn
	FROM    CWX_LoginLog INNER JOIN
				CWX_User ON CWX_LoginLog.UserID = CWX_User.UserID
	WHERE   (CWX_LoginLog.UserID = @UserID) AND 
			(CWX_LoginLog.DBConnectionName = @DBConnectionName)
	ORDER BY CWX_LoginLog.LoginTime DESC

-- Scripts 2.4.5:

/****** Object:  StoredProcedure [dbo].[CWX_Role_GetList]    Script Date: 08/14/2008 16:43:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Role_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_GetList]    Script Date: 08/14/2008 16:43:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_GetList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get role paging list
-- History:
--	2008/02/25	[LongNguyen]	Init version.
--	2008/08/14	[Binh Truong]	Status = ''A'' >>> Status <> ''R''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Role_GetList] 
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT
		ROW_NUMBER() OVER (ORDER BY RoleOrder) AS RowNumber,
		RoleID,
		RoleName,
		RoleOrder
	INTO #Temp
	FROM
		CWX_Role
	WHERE
		Status <> ''R''

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Role_MoveDown]    Script Date: 08/14/2008 16:49:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_MoveDown]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Role_MoveDown]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_MoveDown]    Script Date: 08/14/2008 16:49:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_MoveDown]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/02/25	[LongNguyen]	Init version.
--	2008/08/14	[Binh Truong]	Status = ''A'' >>> Status <> ''R''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Role_MoveDown]
	@RoleID int
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RoleOrder int
	SELECT @RoleOrder = RoleOrder FROM CWX_Role WHERE RoleID = @RoleID

	DECLARE @NextRoleID int
	SELECT
		@NextRoleID = RoleID
	FROM
		CWX_Role
	WHERE
		RoleOrder = (SELECT MIN(RoleOrder) FROM CWX_Role WHERE RoleOrder > @RoleOrder AND Status <> ''R'')

	IF @NextRoleID IS NOT NULL
	BEGIN
		DECLARE @NextOrder int
		SELECT @NextOrder = RoleOrder FROM CWX_Role WHERE RoleID = @NextRoleID AND Status <> ''R''

		DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		UPDATE CWX_Role
		SET RoleOrder = @NextOrder
		WHERE  RoleID = @RoleID
		IF( @@ERROR <> 0)
			GOTO Cleanup

		UPDATE CWX_Role
		SET RoleOrder = @RoleOrder
		WHERE  RoleID = @NextRoleID
		IF( @@ERROR <> 0)
			GOTO Cleanup

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END

END



' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Role_MoveUp]    Script Date: 08/14/2008 16:51:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_MoveUp]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Role_MoveUp]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_MoveUp]    Script Date: 08/14/2008 16:51:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_MoveUp]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/02/25	[LongNguyen]	Init version.
--	2008/08/14	[Binh Truong]	Status = ''A'' >>> Status <> ''R''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Role_MoveUp]
	@RoleID int
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RoleOrder int
	SELECT @RoleOrder = RoleOrder FROM CWX_Role WHERE RoleID = @RoleID

	DECLARE @PreviousRoleID int
	SELECT
		@PreviousRoleID = RoleID
	FROM
		CWX_Role
	WHERE
		RoleOrder = (SELECT MAX(RoleOrder) FROM CWX_Role WHERE RoleOrder < @RoleOrder AND Status <> ''R'')

	IF @PreviousRoleID IS NOT NULL
	BEGIN
		DECLARE @PreviousRoleOrder int
		SELECT @PreviousRoleOrder = RoleOrder FROM CWX_Role WHERE RoleID = @PreviousRoleID AND Status <> ''R''

		DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		UPDATE CWX_Role
		SET RoleOrder = @PreviousRoleOrder
		WHERE  RoleID = @RoleID
		IF( @@ERROR <> 0)
			GOTO Cleanup

		UPDATE CWX_Role
		SET RoleOrder = @RoleOrder
		WHERE  RoleID = @PreviousRoleID
		IF( @@ERROR <> 0)
			GOTO Cleanup

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END

END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByPermission]    Script Date: 08/14/2008 16:54:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByPermission]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByPermission]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByPermission]    Script Date: 08/14/2008 16:54:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByPermission]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/03/21	[Binh Truong]	Init version.
--	2008/08/14	[Binh Truong]	UserStatus = ''A''  >>>  UserStatus <> ''R''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_SelectByPermission] 
(
	@PermissionID int
)
AS
BEGIN
	SELECT     CWX_User.UserID, CWX_User.FullName
	FROM         CWX_User INNER JOIN
						  CWX_UserPermission ON CWX_User.UserID = CWX_UserPermission.UserID
	WHERE     (CWX_UserPermission.PermissionID = @PermissionID) AND (CWX_User.UserStatus <> ''R'')
	ORDER BY CWX_User.FullName
END

' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_GetList]    Script Date: 08/15/2008 18:11:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_GetList]    Script Date: 08/15/2008 18:11:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Long Nguyen
-- Create date: Aug 14, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AuditTrail_GetList]
	-- Add the parameters for the stored procedure here
	@EmployeeID int = 0,
	@ChangeTable varchar(50) = '',
	@FromDate smalldatetime = NULL,
	@ToDate smalldatetime = NULL,
	@ActionID tinyint = 0,
	@RowID varchar(20) = '',
	@DBConnectionName nvarchar(100) = '',
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount=COUNT(AuditID)
	FROM CWX_AuditTrail
	WHERE
		(@EmployeeID = 0 OR EmployeeID = @EmployeeID)
		AND (@ChangeTable = '' OR ChangeTable = @ChangeTable)
		AND (@FromDate = NULL OR CONVERT(VARCHAR(10),AuditDateTime,121) >= CONVERT(VARCHAR(10),@FromDate,121))
		AND (@ToDate = NULL OR CONVERT(VARCHAR(10),AuditDateTime,121) <= CONVERT(VARCHAR(10),@ToDate,121))
		AND (@ActionID = 0 OR ActionID = @ActionID)
		AND (@RowID = '' OR RowID = @RowID)
		AND (DBConnectionName = @DBConnectionName);

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER(ORDER BY AuditID) as RowNumber,
			*
		FROM CWX_AuditTrail
		WHERE
			(@EmployeeID = 0 OR EmployeeID = @EmployeeID)
			AND (@ChangeTable = '' OR ChangeTable = @ChangeTable)
			AND (@FromDate = NULL OR CONVERT(VARCHAR(10),AuditDateTime,121) >= CONVERT(VARCHAR(10),@FromDate,121))
			AND (@ToDate = NULL OR CONVERT(VARCHAR(10),AuditDateTime,121) <= CONVERT(VARCHAR(10),@ToDate,121))
			AND (@ActionID = 0 OR ActionID = @ActionID)
			AND (@RowID = '' OR RowID = @RowID)
			AND (DBConnectionName = @DBConnectionName)
	)

	SELECT * FROM Temp WHERE (@PageSize <= 0) OR (RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize)

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_User_DeactiveByUserID]    Script Date: 08/15/2008 16:43:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_DeactiveByUserID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_DeactiveByUserID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_DeactiveByUserID]    Script Date: 08/15/2008 16:43:04 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_DeactiveByUserID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/08/15	[Binh Truong]	Init version.
-- =============================================
create PROCEDURE dbo.CWX_User_DeactiveByUserID
	@UserID int
AS
BEGIN
	UPDATE CWX_User
	SET
		UserStatus = ''D''
	WHERE
		UserID = @UserID
END
' 
END
GO


-- Scripts 2.4.7:

/****** Object:  StoredProcedure [dbo].[CWX_User_ActiveByUserID]    Script Date: 08/19/2008 15:09:08 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_ActiveByUserID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_ActiveByUserID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_ActiveByUserID]    Script Date: 08/19/2008 15:09:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_ActiveByUserID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/08/18	[Binh Truong]	Init version.
-- =============================================
create PROCEDURE dbo.CWX_User_ActiveByUserID
	@UserID int
AS
BEGIN
	UPDATE CWX_User
	SET
		UserStatus = ''A''
	WHERE
		UserID = @UserID
END
' 
END
GO

--Add new permission 'Mark account pending'
IF NOT EXISTS (SELECT PermissionID FROM CWX_Permission WHERE PermissionID=71)
	INSERT INTO CWX_Permission VALUES(71, 'Mark account pending', 4)
GO

-- Scripts 2.4.8:

/****** Object:  StoredProcedure [dbo].[CWX_User_ActiveAll]    Script Date: 08/19/2008 16:03:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_ActiveAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_ActiveAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_ActiveAll]    Script Date: 08/19/2008 16:03:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_ActiveAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/08/19	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_ActiveAll] 
	
AS
BEGIN
	UPDATE CWX_User	SET UserStatus = ''A'' WHERE UserStatus = ''D''
END' 
END
GO

-- Scripts 2.4.10:

IF NOT EXISTS(SELECT * FROM CWX_AuditTables WHERE ID=29)
BEGIN
	INSERT INTO CWX_AuditTables (ID, ClassName, Description, Audited)
	VALUES (29, 'Score Cards', 'Score Cards', 1)
	
	INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName)
	VALUES (29, 'Scorecard')
	
	INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName)
	VALUES (29, 'ScorecardRiskFactor')
	
	INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName)
	VALUES (29, 'ScorecardRiskFactorGroup')
	
	INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName)
	VALUES (29, 'ScorecardRiskFactorRule')
END

-- Scripts 2.4.12:
IF NOT EXISTS (SELECT PermissionID FROM CWX_Permission WHERE PermissionID=8)
	INSERT INTO CWX_Permission VALUES(8, 'Access Management Console', 1)
GO

-- Scripts 2.4.14: