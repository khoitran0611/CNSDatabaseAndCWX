  -- Script is applied on version 2.6.3, 2.6.9, 2.6.11, 2.6.26
 
 -- Scripts 2.6.3
 
 -- Added by Thuy Nguyen on 12-Sept-2008 --
 
 If not exists (select * from CWX_Permission where PermissionID = 74)
	Insert into CWX_Permission values(74, 'Make Change To Closed Account', 4)

------------	

-- Scripts 2.6.9

--- Thuy Nguyen 15-Sept-2008 --

if not exists(select * from CWX_Permission where PermissionID = 75)
	insert into CWX_Permission values(75, 'Edit System Phone Details', 4)

if not exists(select * from CWX_Permission where PermissionID = 76)
	insert into CWX_Permission values(76, 'Edit System Address Details', 4)
	
---

-- Script 2.6.11:

-- Thuy Nguyen 16-Sep-2008 ---

if not exists (select * from CWX_Permission where PermissionDescription='Make Change To Closed Account')
	insert into CWX_Permission values(74, 'Work Debtor Closed Account', 4)
else
	update CWX_Permission set PermissionDescription='Work Debtor Closed Account' where PermissionDescription='Make Change To Closed Account'
	
	
-- Scripts 2.6.26:
GO
IF NOT EXISTS (SELECT PermissionID FROM CWX_Permission WHERE PermissionID = 77)
	INSERT INTO CWX_Permission VALUES(77, 'Add/Edit CoBorrower', 4)
GO

