alter table CWX_AuditTrail add RowID varchar(20)
GO

/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Insert]    Script Date: 06/30/2008 16:04:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Insert]    Script Date: 06/30/2008 16:04:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--		2008/05/22	[Binh Truong]	Remove AccountID, DebtorID field.
--									Add OriginalData field.
--		2008/05/24	[Binh Truong]	Add @ChangeField default value = NULL
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AuditTrail_Insert] 
(
	@EmployeeID INT,
	@ActionID TINYINT,
	@ChangeTable VARCHAR(50),
	@RowID VARCHAR(20),
	@ChangeField VARCHAR(50) = NULL,
	@OriginalData NVARCHAR(MAX) = NULL,
	@ChangeData NVARCHAR(MAX) = NULL
)
AS
	INSERT INTO		CWX_AuditTrail
	                (EmployeeID,ActionID,ChangeTable,RowID,ChangeField,OriginalData,ChangeData,AuditDateTime)
	VALUES			(@EmployeeID,@ActionID,@ChangeTable,@RowID,@ChangeField,@OriginalData,@ChangeData,GETUTCDATE())' 
END
GO


UPDATE CWX_Permission SET PermissionDescription = 'Create and View Ticket' WHERE PermissionID=54
GO  