-- Script is applied on version 2.2.1:

/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 07/14/2008 15:59:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Profiles_UpdateLastActivity]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_UpdateUserOnlineStatus]    Script Date: 07/14/2008 15:59:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_UpdateUserOnlineStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_UpdateUserOnlineStatus]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 07/14/2008 15:59:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Profiles_UpdateLastActivity]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
(
	@UserName nvarchar(50)
)
AS
BEGIN

	SET NOCOUNT ON;
	UPDATE CWX_Profiles 
	SET LastActivity = GetUTCDate() 
	WHERE UserName = @Username

END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_User_UpdateUserOnlineStatus]    Script Date: 07/14/2008 15:59:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_UpdateUserOnlineStatus]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-------------------------------------
-- Description: Update user online status.
-- History:
--	2008/07/11	[Binh Truong]	Init version.
-------------------------------------
CREATE PROCEDURE dbo.CWX_User_UpdateUserOnlineStatus 
(
	@Username varchar(50),
	@UserIsOnlineTimeWindow int = 0,
	@IsForceSetStatus int = 0,
	@IsSignOn int = 0
)
AS
	SET NOCOUNT ON
	IF @IsForceSetStatus = 0
	BEGIN
		DECLARE @LastActivity datetime
		
		SELECT	@LastActivity = LastActivity
		FROM    CWX_Profiles
		WHERE	Username = @Username
		
		IF DATEADD(minute, @UserIsOnlineTimeWindow, @LastActivity) < GetUTCDate() 
		BEGIN
			UPDATE  CWX_User
			SET		SignOn = 0
			WHERE	Username = @Username
		END
		
	END
	ELSE
	BEGIN
		UPDATE  CWX_User
		SET		SignOn = @IsSignOn
		WHERE	Username = @Username
	END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserID]    Script Date: 07/14/2008 17:23:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByUserID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserNameAndPassword]    Script Date: 07/14/2008 17:23:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserNameAndPassword]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByUserNameAndPassword]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserName]    Script Date: 07/14/2008 17:23:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByUserName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserID]    Script Date: 07/14/2008 17:23:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/08	[Long Nguyen]	Init version.
--	2008/07/14	[Binh Truong]	Add Profiles table fields.
-- =============================================
CREATE PROCEDURE dbo.CWX_User_SelectByUserID 
	-- Add the parameters for the stored procedure here
	@UserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT  CWX_User.*, CWX_Profiles.*
	FROM    CWX_User INNER JOIN
				CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE
			(CWX_User.UserID = @UserID)
			AND (ISNULL(CWX_User.UserStatus, '''') <> ''R'')
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserNameAndPassword]    Script Date: 07/14/2008 17:23:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserNameAndPassword]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/08	[Long Nguyen]	Init version.
--	2008/07/14	[Binh Truong]	Add Profiles table fields.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_SelectByUserNameAndPassword] 
	-- Add the parameters for the stored procedure here
	@UserName varchar(10),
	@Password varchar(250)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT     CWX_User.*, CWX_Profiles.*
	FROM         CWX_User INNER JOIN
	                      CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE     (CWX_User.UserName = @UserName) AND (CWX_User.Password = @Password) AND (ISNULL(CWX_User.UserStatus, '''') <> ''R'')
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserName]    Script Date: 07/14/2008 17:23:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserName]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/08	[Long Nguyen]	Init version.
--	2008/07/14	[Binh Truong]	Add Profiles table fields.
-- =============================================
CREATE PROCEDURE dbo.CWX_User_SelectByUserName 
	-- Add the parameters for the stored procedure here
	@UserName varchar(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT  CWX_User.*, CWX_Profiles.*
	FROM    CWX_User INNER JOIN
	            CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE
			(CWX_User.UserName = @UserName)
			AND (ISNULL(UserStatus, '''') <> ''R'')
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 07/15/2008 10:01:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Profiles_UpdateLastActivity]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 07/15/2008 10:01:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Profiles_UpdateLastActivity]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'---------------------------------------------------
-- Description: Update LastActivity and SignOn status of specific user.
-- History:
--	2008/07/14	[Binh Truong]	Init version
---------------------------------------------------
CREATE PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
(
	@UserName nvarchar(50),
	@ApplicationName nvarchar(50)
)
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE	CWX_Profiles 
	SET		LastActivity = GetUTCDate()
	WHERE	UserName = @Username AND
			ApplicationName = @ApplicationName
			
	UPDATE		CWX_User
	SET			SignOn = 1
	WHERE		UserName = @Username
END
' 
END
GO

/******  Script Closed  ******/ 

-- Script is applied on version 2.2.8 

/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 07/18/2008 18:50:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Profiles_UpdateLastActivity]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserID]    Script Date: 07/18/2008 18:50:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByUserID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserName]    Script Date: 07/18/2008 18:50:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByUserName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserNameAndPassword]    Script Date: 07/18/2008 18:50:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserNameAndPassword]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByUserNameAndPassword]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_Insert]    Script Date: 07/18/2008 18:50:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 07/18/2008 18:50:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Profiles_UpdateLastActivity]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'---------------------------------------------------
-- Description: Update LastActivity and SignOn status of specific user.
-- History:
--	2008/07/14	[Binh Truong]	Init version
---------------------------------------------------
CREATE PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
(
	@UserName nvarchar(50),
	@ApplicationName nvarchar(50)
)
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE	CWX_Profiles 
	SET		LastActivity = GetUTCDate()
	WHERE	UserName = @Username AND
			ApplicationName = @ApplicationName
			
	UPDATE		CWX_User
	SET			SignOn = 1
	WHERE		UserName = @Username
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserID]    Script Date: 07/18/2008 18:50:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/08	[Long Nguyen]	Init version.
--	2008/07/14	[Binh Truong]	Add Profiles table fields.
-- =============================================
CREATE PROCEDURE dbo.CWX_User_SelectByUserID 
	-- Add the parameters for the stored procedure here
	@UserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT  CWX_User.*, CWX_Profiles.*
	FROM    CWX_User LEFT OUTER JOIN
				CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE
			(CWX_User.UserID = @UserID)
			AND (ISNULL(CWX_User.UserStatus, '''') <> ''R'')
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserName]    Script Date: 07/18/2008 18:50:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserName]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/08	[Long Nguyen]	Init version.
--	2008/07/14	[Binh Truong]	Add Profiles table fields.
-- =============================================
CREATE PROCEDURE dbo.CWX_User_SelectByUserName 
	-- Add the parameters for the stored procedure here
	@UserName varchar(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT  CWX_User.*, CWX_Profiles.*
	FROM    CWX_User LEFT OUTER JOIN
	            CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE
			(CWX_User.UserName = @UserName)
			AND (ISNULL(UserStatus, '''') <> ''R'')
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserNameAndPassword]    Script Date: 07/18/2008 18:50:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserNameAndPassword]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/08	[Long Nguyen]	Init version.
--	2008/07/14	[Binh Truong]	Add Profiles table fields.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_SelectByUserNameAndPassword] 
	-- Add the parameters for the stored procedure here
	@UserName varchar(10),
	@Password varchar(250)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT     CWX_User.*, CWX_Profiles.*
	FROM         CWX_User LEFT OUTER JOIN
	                      CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE     (CWX_User.UserName = @UserName) AND (CWX_User.Password = @Password) AND (ISNULL(CWX_User.UserStatus, '''') <> ''R'')
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_Insert]    Script Date: 07/18/2008 18:50:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Insert new user
-- History:
--	2008/01/08	[LongNguyen]	Init version.
--	2008/07/18	[Binh Truong]	Insert Profile data.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_Insert] 
	-- Add the parameters for the stored procedure here
	@UserID int,
	@UserName varchar(10),
	@Password varchar(250),
	@FullName varchar(50),
	@Email varchar(50),
	@Comment varchar(225),
	@RoleID int,
	@Salt nchar (10),
	@CreatedDate datetime
AS
BEGIN
	DECLARE @profileID int

	INSERT INTO CWX_User
	(
		UserID,
		UserName,
		Password,
		FullName,
		Email,
		Comment,
		RoleID,
		IsLockedOut,
		UserStatus,
		Salt,
		CreatedDate
	)
	VALUES
	(
		@UserID,
		@UserName,
		@Password,
		@FullName,
		@Email,
		@Comment,
		@RoleID,
		0,
		''A'',
		@Salt,
		@CreatedDate
	)
	
	/*Insert the profile data.*/
	EXECUTE CWX_Profiles_Insert @profileID output, @userName, ''CWX'', 0
	INSERT CWX_ProfileData
	(
		ProfileID,
		Culture
	)
	VALUES
	(
		@profileID,
		''en-US''
	)
END

' 
END
GO
/******  Script Closed  ******/

-- Script is applied on version 2.2.11, 2.2.15, 2.2.16, 2.2.17, 2.2.18, 2.2.19


-- Author: Thuy Nguyen
-- Update CWX_LoginLog, CWX_AuditTrail table to store the working DB for multi DB function
alter table CWX_LoginLog add DBConnectionName nvarchar(100)
alter table CWX_AuditTrail add DBConnectionName nvarchar(100)



-- Scripts 2.2.15:


-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 25, 2008
-- Description:		Add column DbConnectionName
-- Effected table:	CWX_ProfileData
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_ProfileData' and c.name = 'DbConnectionName')
BEGIN
	ALTER TABLE CWX_ProfileData
	ADD DbConnectionName nvarchar(100) NULL
		CONSTRAINT [CWX_ProfileData_DbConnectionName] DEFAULT ''
		
	UPDATE CWX_ProfileData SET DbConnectionName = '' WHERE DbConnectionName is NULL
END
GO


-- Author: Thao Nguyen
-- Update date: Jul 25, 2008

/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Select]    Script Date: 07/25/2008 10:01:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Select]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProfileData_Select]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Update]    Script Date: 07/25/2008 10:01:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProfileData_Update]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Select]    Script Date: 07/25/2008 10:01:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Select]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_ProfileData_Select]
(
	@userName nvarchar(50),
	@applicationName nvarchar(50),
	@isAnonymous bit
)
As
BEGIN

	Declare @activity datetime
	Set @activity=GetUTCDate()
	
	/*Update date/time profile had activity.*/
	Execute CWX_Profiles_Activity_Update @userName, @applicationName, @isAnonymous, @activity, null

	Select Culture, DbConnectionName
	From CWX_Profiles
	Inner Join CWX_ProfileData On CWX_Profiles.ProfileID=CWX_ProfileData.ProfileID
	Where (UserName=@userName) 
	And (ApplicationName=@applicationName) 
	And (IsAnonymous=@isAnonymous)

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Update]    Script Date: 07/25/2008 10:01:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Update]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_ProfileData_Update]
(
	@userName nvarchar(50),
	@applicationName nvarchar(50),
	@isAnonymous bit,
	@culture nvarchar(200),
	@dbConnectionName nvarchar(100)
)
As
BEGIN

	SET NOCOUNT ON;

	Declare @activity datetime
	Set @activity=GetUTCDate()

	/*Determine if a profile exists, if not create one.*/
	Declare @profileID int
	Execute CWX_Profiles_GetProfileID @profileID output, @userName, @applicationName, @isAnonymous

	If @profileID Is Null Begin
		Execute CWX_Profiles_Insert @profileID output, @userName, @applicationName, @isAnonymous
	End

	/*Insert the profile data.*/
	Declare @profileDataID int
	Set @profileDataID=(Select ProfileDataID From CWX_ProfileData Where (ProfileID=@profileID))
	If @profileDataID Is Null Begin
		Insert CWX_ProfileData
		(
		ProfileID,
		Culture,
		DbConnectionName
		)
		Values
		(
		@profileID,
		@culture,
		@dbConnectionName
		)
	End Else Begin
		Update CWX_ProfileData 
		Set Culture=@culture, DbConnectionName=@dbConnectionName
		Where ProfileID=@profileID
	End

	/*Update date/time profile had activity and was updated.*/
	Execute CWX_Profiles_Activity_Update @userName, @applicationName, @isAnonymous, @activity, @activity

END
' 
END
GO

-- Scripts 2.2.19:
-- Author: Thao Nguyen
-- Update date: Jul 28, 2008

/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Insert]    Script Date: 07/28/2008 10:59:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LoginLog_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Update]    Script Date: 07/28/2008 10:59:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LoginLog_Update]
GO
/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Insert]    Script Date: 07/28/2008 10:59:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Binh Truong
-- Create date: Jun 12, 2008
-- Description:	Insert a new login log.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LoginLog_Insert]
(
	@UserID int,
	@LoginTime datetime,
	@LogoutTime datetime,
	@MinutesLoggedIn int,
	@DbConnectionName nvarchar(100) = ''''
)
	
AS
	SET NOCOUNT ON
	INSERT INTO CWX_LoginLog
				(UserID, LoginTime, LogoutTime, MinutesLoggedIn, DbConnectionName)
	VALUES		(@UserID,@LoginTime,@LogoutTime,@MinutesLoggedIn, @DbConnectionName)
	RETURN
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Update]    Script Date: 07/28/2008 10:59:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Update]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		khoadang
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LoginLog_Update]
	@UserID int,
	@LoginTime datetime,
	@LogoutTime datetime,
	@MinutesLoggedIn int,
	@DbConnectionName nvarchar(100) = ''''
AS
BEGIN
	IF @DbConnectionName is NULL OR @DbConnectionName = ''''
		SELECT @DbConnectionName = [DbConnectionName]
		FROM [CWX_LoginLog]
		WHERE UserID=@UserID and LoginTime=@LoginTime

	UPDATE [CWX_LoginLog]
	   SET [UserID] = @UserID
	  ,[LoginTime] = @LoginTime
	  ,[LogoutTime] = @LogoutTime
	  ,[MinutesLoggedIn] = @MinutesLoggedIn
	  ,[DbConnectionName] = @DbConnectionName
	WHERE UserID=@UserID and LoginTime=@LoginTime
END
' 
END
GO

/******  Script Closed. Go next: Step012_4  ******/


-- Script is applied on version 2.2.21, 2.2.22, 2.2.26

/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Insert]    Script Date: 07/30/2008 10:25:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Insert]    Script Date: 07/30/2008 10:25:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--		2008/05/22	[Binh Truong]	Remove AccountID, DebtorID field.
--									Add OriginalData field.
--		2008/05/24	[Binh Truong]	Add @ChangeField default value = NULL
--		2008/07/30	[Binh Truong]	Add @DBConnectionName parameter.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AuditTrail_Insert] 
(
	@EmployeeID INT,
	@ActionID TINYINT,
	@DBConnectionName VARCHAR(100),
	@ChangeTable VARCHAR(50),
	@RowID VARCHAR(20),
	@ChangeField VARCHAR(50) = NULL,
	@OriginalData NVARCHAR(MAX) = NULL,
	@ChangeData NVARCHAR(MAX) = NULL
)
AS
	INSERT INTO		CWX_AuditTrail
	                (EmployeeID, ActionID, DBConnectionName, ChangeTable, RowID, ChangeField, OriginalData, ChangeData, AuditDateTime)
	VALUES			(@EmployeeID,@ActionID,@DBConnectionName,@ChangeTable,@RowID,@ChangeField,@OriginalData,@ChangeData,GETUTCDATE())' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Update]    Script Date: 07/30/2008 10:28:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTable_Update]
GO

/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Delete]    Script Date: 07/30/2008 10:31:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Delete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_Delete]
GO

/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Search]    Script Date: 07/30/2008 11:43:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTable_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Search]    Script Date: 07/30/2008 11:45:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_AuditTable_Search]
(
	@ID INT = NULL,
	@ClassName NVARCHAR(100) = NULL,
	@Audited INT = NULL,
	@PageSize INT = 10,
	@PageIndex INT = 0
	
)
AS
	DECLARE @StartRow INT
	DECLARE @EndRow INT	
	DECLARE @SQL 	NVARCHAR(MAX)
	DECLARE @Order 	NVARCHAR(1000)
	DECLARE @parms 	NVARCHAR(1000)
	DECLARE @TotalRow INT

	SET @StartRow = @PageIndex * @PageSize + 1
	SET @EndRow = (@PageIndex + 1) * @PageSize

	IF @Audited = 2
		SET @Audited = NULL

	SET @Order = 'ORDER BY ClassName'

	SET @SQL = N'
		SELECT	*, ROW_NUMBER() OVER ('+@Order+') AS RowNumber 
		INTO	#AuditTablesTemp
		FROM	CWX_AuditTables
		WHERE	1=1 
		'
	IF @ID IS NOT NULL
		SET @SQL = @SQL + 'AND [ID] = @ID '
	IF @ClassName IS NOT NULL
		SET @SQL = @SQL + 'AND ClassName LIKE ''%''+@ClassName+''%'' '
	IF @Audited IS NOT NULL
		SET @SQL = @SQL + 'AND Audited = @Audited '	

	SET @sql = @sql + N'SELECT @TotalRow = @@ROWCOUNT
						SELECT * FROM #AuditTablesTemp 
						WHERE RowNumber BETWEEN @StartRow AND @EndRow 
						DROP TABLE #AuditTablesTemp 
						 '

	SET @parms = '
		@ID INT = NULL,
		@ClassName NVARCHAR(100) = NULL,
		@Audited INT = NULL,
		@StartRow INT = 10,
		@EndRow INT = 0,
		@TotalRow INT OUTPUT
		'

	EXECUTE sp_executesql @sql, @parms, 
				@ID,
				@ClassName,
				@Audited,
				@StartRow,
				@EndRow,
				@TotalRow OUTPUT
	IF @TotalRow IS NULL
		RETURN 0
	ELSE
		RETURN @TotalRow
GO

UPDATE CWX_AuditTables SET Description = 'Reports and Letters details (Document Definitions and Report Schedules)' WHERE ID=24
GO

UPDATE CWX_AuditTables SET ClassName = 'Audit Options' WHERE ID=5
GO

-- Scripts 2.2.22:

/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Search]    Script Date: 07/30/2008 18:10:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTable_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Search]    Script Date: 07/30/2008 18:10:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Search]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.CWX_AuditTable_Search
(
	@ID INT = NULL,
	@ClassName NVARCHAR(100) = NULL,
	@Audited INT = NULL,
	@PageSize INT = 10,
	@PageIndex INT = 0
	
)
AS
DECLARE @StartRow INT
DECLARE @EndRow INT	
DECLARE @SQL 	NVARCHAR(MAX)
DECLARE @Order 	NVARCHAR(1000)
DECLARE @parms 	NVARCHAR(1000)
DECLARE @TotalRow INT

SET @StartRow = @PageIndex * @PageSize + 1
SET @EndRow = (@PageIndex + 1) * @PageSize

IF @Audited = 2
	SET @Audited = NULL

SET @Order = ''ORDER BY ClassName''

SET @SQL = N''
	SELECT	*, ROW_NUMBER() OVER (''+@Order+'') AS RowNumber 
	INTO	#AuditTablesTemp
	FROM	CWX_AuditTables
	WHERE	1=1 
	''
IF @ID IS NOT NULL
	SET @SQL = @SQL + ''AND [ID] = @ID ''
IF @ClassName IS NOT NULL
	SET @SQL = @SQL + ''AND ClassName LIKE ''''%''''+@ClassName+''''%'''' ''
IF @Audited IS NOT NULL
	SET @SQL = @SQL + ''AND Audited = @Audited ''	

SET @sql = @sql + N''SELECT @TotalRow = @@ROWCOUNT
					SELECT * FROM #AuditTablesTemp 
					WHERE RowNumber BETWEEN @StartRow AND @EndRow 
					DROP TABLE #AuditTablesTemp 
					 ''

SET @parms = ''
	@ID INT = NULL,
	@ClassName NVARCHAR(100) = NULL,
	@Audited INT = NULL,
	@StartRow INT = 10,
	@EndRow INT = 0,
	@TotalRow INT OUTPUT
	''

EXECUTE sp_executesql @sql, @parms, 
			@ID,
			@ClassName,
			@Audited,
			@StartRow,
			@EndRow,
			@TotalRow OUTPUT
IF @TotalRow IS NULL
	RETURN 0
ELSE
	RETURN @TotalRow' 
END
GO


