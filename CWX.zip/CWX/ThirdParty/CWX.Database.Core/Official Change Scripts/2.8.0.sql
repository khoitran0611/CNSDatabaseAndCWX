-- Scripts 2.7.2:
-- =============================================================
-- Author:		Minh Dam
-- Create date: Otc 06, 2008
-- Description:	Drop unused tables and store procedures.
-- =============================================================
delete CWX_AuditTables where ClassName = 'AccountLegal' 	
delete CWX_AuditTableInfo where TableName = 'LegalProcess'
delete CWX_AuditTableInfo where TableName = 'LegalProcessItems'
GO