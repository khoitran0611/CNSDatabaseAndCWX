-- Script is applied on version 2.2.11, 2.2.15, 2.2.16, 2.2.17, 2.2.18, 2.2.19


-- Author: Thuy Nguyen
-- Update CWX_LoginLog, CWX_AuditTrail table to store the working DB for multi DB function
alter table CWX_LoginLog add DBConnectionName nvarchar(100)
alter table CWX_AuditTrail add DBConnectionName nvarchar(100)



-- Scripts 2.2.15:


-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 25, 2008
-- Description:		Add column DbConnectionName
-- Effected table:	CWX_ProfileData
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_ProfileData' and c.name = 'DbConnectionName')
BEGIN
	ALTER TABLE CWX_ProfileData
	ADD DbConnectionName nvarchar(100) NULL
		CONSTRAINT [CWX_ProfileData_DbConnectionName] DEFAULT ''
		
	UPDATE CWX_ProfileData SET DbConnectionName = '' WHERE DbConnectionName is NULL
END
GO


-- Author: Thao Nguyen
-- Update date: Jul 25, 2008

/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Select]    Script Date: 07/25/2008 10:01:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Select]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProfileData_Select]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Update]    Script Date: 07/25/2008 10:01:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProfileData_Update]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Select]    Script Date: 07/25/2008 10:01:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Select]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_ProfileData_Select]
(
	@userName nvarchar(50),
	@applicationName nvarchar(50),
	@isAnonymous bit
)
As
BEGIN

	Declare @activity datetime
	Set @activity=GetUTCDate()
	
	/*Update date/time profile had activity.*/
	Execute CWX_Profiles_Activity_Update @userName, @applicationName, @isAnonymous, @activity, null

	Select Culture, DbConnectionName
	From CWX_Profiles
	Inner Join CWX_ProfileData On CWX_Profiles.ProfileID=CWX_ProfileData.ProfileID
	Where (UserName=@userName) 
	And (ApplicationName=@applicationName) 
	And (IsAnonymous=@isAnonymous)

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Update]    Script Date: 07/25/2008 10:01:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Update]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_ProfileData_Update]
(
	@userName nvarchar(50),
	@applicationName nvarchar(50),
	@isAnonymous bit,
	@culture nvarchar(200),
	@dbConnectionName nvarchar(100)
)
As
BEGIN

	SET NOCOUNT ON;

	Declare @activity datetime
	Set @activity=GetUTCDate()

	/*Determine if a profile exists, if not create one.*/
	Declare @profileID int
	Execute CWX_Profiles_GetProfileID @profileID output, @userName, @applicationName, @isAnonymous

	If @profileID Is Null Begin
		Execute CWX_Profiles_Insert @profileID output, @userName, @applicationName, @isAnonymous
	End

	/*Insert the profile data.*/
	Declare @profileDataID int
	Set @profileDataID=(Select ProfileDataID From CWX_ProfileData Where (ProfileID=@profileID))
	If @profileDataID Is Null Begin
		Insert CWX_ProfileData
		(
		ProfileID,
		Culture,
		DbConnectionName
		)
		Values
		(
		@profileID,
		@culture,
		@dbConnectionName
		)
	End Else Begin
		Update CWX_ProfileData 
		Set Culture=@culture, DbConnectionName=@dbConnectionName
		Where ProfileID=@profileID
	End

	/*Update date/time profile had activity and was updated.*/
	Execute CWX_Profiles_Activity_Update @userName, @applicationName, @isAnonymous, @activity, @activity

END
' 
END
GO

-- Scripts 2.2.19:
-- Author: Thao Nguyen
-- Update date: Jul 28, 2008

/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Insert]    Script Date: 07/28/2008 10:59:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LoginLog_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Update]    Script Date: 07/28/2008 10:59:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LoginLog_Update]
GO
/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Insert]    Script Date: 07/28/2008 10:59:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Binh Truong
-- Create date: Jun 12, 2008
-- Description:	Insert a new login log.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LoginLog_Insert]
(
	@UserID int,
	@LoginTime datetime,
	@LogoutTime datetime,
	@MinutesLoggedIn int,
	@DbConnectionName nvarchar(100) = ''''
)
	
AS
	SET NOCOUNT ON
	INSERT INTO CWX_LoginLog
				(UserID, LoginTime, LogoutTime, MinutesLoggedIn, DbConnectionName)
	VALUES		(@UserID,@LoginTime,@LogoutTime,@MinutesLoggedIn, @DbConnectionName)
	RETURN
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Update]    Script Date: 07/28/2008 10:59:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Update]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		khoadang
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LoginLog_Update]
	@UserID int,
	@LoginTime datetime,
	@LogoutTime datetime,
	@MinutesLoggedIn int,
	@DbConnectionName nvarchar(100) = ''''
AS
BEGIN
	IF @DbConnectionName is NULL OR @DbConnectionName = ''''
		SELECT @DbConnectionName = [DbConnectionName]
		FROM [CWX_LoginLog]
		WHERE UserID=@UserID and LoginTime=@LoginTime

	UPDATE [CWX_LoginLog]
	   SET [UserID] = @UserID
	  ,[LoginTime] = @LoginTime
	  ,[LogoutTime] = @LogoutTime
	  ,[MinutesLoggedIn] = @MinutesLoggedIn
	  ,[DbConnectionName] = @DbConnectionName
	WHERE UserID=@UserID and LoginTime=@LoginTime
END
' 
END
GO

/******  Script Closed. Go next: Step012_4  ******/