 -- Script is applied on version 1.9.15
 
/****** Object:  StoredProcedure [dbo].[CWX_PasswordPolicy_ValidatePreviousPasswordsAreSame]    Script Date: 06/16/2008 11:26:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_PasswordPolicy_ValidatePreviousPasswordsAreSame]
	@UserID int,
	@NewEncriptedPassword varchar(500),
	@Times int --how many times to get from PasswordHistory 	
AS
BEGIN	
	IF EXISTS (SELECT Password FROM CWX_User WHERE UserID = @UserID AND Password = @NewEncriptedPassword)		
	 	SELECT Result = 1 --SET @Result = 1	
	ELSE
	BEGIN--0
		CREATE TABLE #TempPwdHistory
		(
			OldPassword varchar(500)
		)

		DECLARE @sql nvarchar(2000)
		SET @sql = 'INSERT INTO #TempPwdHistory SELECT TOP ' + CAST(@Times as varchar(10)) + ' OldPassword ' 
		SET @sql = @sql + ' FROM CWX_PasswordHistory WHERE UserID = ' + CAST(@UserID as varchar(10)) + ' ORDER BY PasswordHistoryID DESC'		
		
		PRINT @sql
		EXEC(@sql)

		DECLARE @OldPassword varchar(1000)
		DECLARE OldPasswordCursor CURSOR FOR
		SELECT OldPassword FROM #TempPwdHistory
		OPEN OldPasswordCursor
		FETCH NEXT FROM OldPasswordCursor INTO @OldPassword
		
		DECLARE @Result int
		SET @Result = 0
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF (@NewEncriptedPassword = @OldPassword)
			Begin
				Print @Result
				SET	@Result = 1
				BREAK
			End
			FETCH NEXT FROM OldPasswordCursor INTO @OldPassword
		END		
		SELECT Result = @Result
		CLOSE OldPasswordCursor;
		DEALLOCATE OldPasswordCursor;
		DROP TABLE #TempPwdHistory
	END--0
	
END
GO
 
 
alter table CWX_LoginAttemptsLog drop column UserID
GO
alter table CWX_LoginAttemptsLog add LoginUser varchar(16)
GO


 /****** Object:  StoredProcedure [dbo].[CWX_LoginAttemptsLog_Insert]    Script Date: 06/16/2008 13:22:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginAttemptsLog_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LoginAttemptsLog_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_LoginAttemptsLog_Insert]    Script Date: 06/16/2008 13:22:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginAttemptsLog_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		khoadang
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LoginAttemptsLog_Insert]
	@LoginUser varchar(16),
	@LoginDateTime smalldatetime,
	@IPAddress varchar(50),
	@LoginStatus varchar(50),
	@Reason varchar(250)
AS
BEGIN
	INSERT INTO [CWX_LoginAttemptsLog]
           ([LoginUser]
           ,[LoginDateTime]
           ,[IPAddress]
           ,[LoginStatus]
           ,[Reason])
     VALUES
           (@LoginUser
           ,@LoginDateTime
           ,@IPAddress
           ,@LoginStatus
           ,@Reason)
END
' 
END
GO



/****** Object:  StoredProcedure [dbo].[CWX_UserNotInUse]    Script Date: 06/16/2008 14:37:53 ******/

ALTER PROCEDURE [dbo].[CWX_UserNotInUse] 	
	@UserName varchar(10),
	@AvailableDays int

AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @LoginUser varchar(16)	
	DECLARE @Result int
	IF EXISTS (SELECT * FROM CWX_User WHERE UserName = @UserName 
					AND UserID NOT IN (SELECT UserID FROM CWX_LoginLog)
					AND (GETDATE() - CreatedDate) > @AvailableDays)
		SET @Result= 1
	ELSE
    BEGIN
	
		DECLARE @LastChangeDate DATETIME
		DECLARE @LastLoginDate DATETIME

		SET @LastChangeDate = (SELECT TOP 1 ChangeDate FROM CWX_PasswordHistory a LEFT JOIN CWX_User b ON a.UserID = b.UserID
									WHERE b.UserName = @UserName ORDER BY ChangeDate DESC)


		SET @LastLoginDate = (SELECT TOP 1 LoginTime FROM CWX_LoginLog a LEFT JOIN CWX_User b ON a.UserID = b.UserID
									WHERE b.UserName = @UserName ORDER BY LoginTime DESC)

		IF (@LastChangeDate IS NOT NULL AND @LastLoginDate IS NOT NULL AND (@LastChangeDate - @LastLoginDate) > @AvailableDays)
			SET @Result = 1	
		ELSE 
			SET @Result = 0
	END

	SELECT @Result
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Update]    Script Date: 06/16/2008 15:06:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LoginLog_Update]
GO
/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Update]    Script Date: 06/16/2008 15:06:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Update]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		khoadang
-- =============================================
CREATE PROCEDURE dbo.CWX_LoginLog_Update
	@UserID int,
	@LoginTime datetime,
	@LogoutTime datetime,
	@MinutesLoggedIn int
AS
BEGIN
	UPDATE [CWX_LoginLog]
	   SET [UserID] = @UserID
      ,[LoginTime] = @LoginTime
      ,[LogoutTime] = @LogoutTime
      ,[MinutesLoggedIn] = @MinutesLoggedIn
	WHERE UserID=@UserID and LoginTime=@LoginTime
END
' 
END
GO

/******  Script Closed. Go next: Step009_6  ******/