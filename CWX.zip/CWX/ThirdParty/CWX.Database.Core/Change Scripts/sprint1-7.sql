-- Thuy Nguyen added on 06-March-2009 --

if not exists (select * from CWX_Permission where PermissionDescription = 'Access to Debt and Debtor Management')
	insert into CWX_Permission(PermissionID,PermissionDescription, GroupID) values(79, 'Access to Debt and Debtor Management', 1)
go

-- End of Thuy Nguyen added on 06-March-2009 --

-- Thuy Nguyen added on 14-April-2009 --

if not exists (select * from CWX_Permission where PermissionDescription = 'Add New Account')
	insert into CWX_Permission(PermissionID,PermissionDescription, GroupID) values(80, 'Add New Account', 4)
go

-- End of Thuy Nguyen added on 14-April-2009 --
 -- Thuy Nguyen added on 22-April-2009 --

if not exists (select * from CWX_Permission where PermissionDescription = 'Edit full details primary customer and accounts')
	insert into CWX_Permission(PermissionID,PermissionDescription, GroupID) values(81, 'Edit full details primary customer and accounts', 4)
go

if not exists (select * from CWX_Permission where PermissionDescription = 'Access to Debt and Debtor Management')
	insert into CWX_Permission(PermissionID,PermissionDescription, GroupID) values(82, 'Access to Debt and Debtor Management', 1)
else
	update 	CWX_Permission set PermissionID = 82 where PermissionDescription = 'Access to Debt and Debtor Management'
go

-- End of Thuy Nguyen added on 22-April-2009 --
----------- Script to include in 3.6.8.sql received from Sathya on 12-May-2009 -------------

-- Script is applied on version 3.6.8:

PRINT 'Start of Scripts 3.6.8'
GO

--make sure the CWX_DBVersion table exists
IF(NOT EXISTS (SELECT (1) from dbo.sysobjects 
  WHERE id = object_id(N'[dbo].[CWX_DBVersion]') AND 
  OBJECTPROPERTY(id, N'IsUserTable') = 1))
BEGIN
 print N'Building the foundation ''CWX_DBVersion'' Table'

	CREATE TABLE CWX_DBVersion (
	[DBVersionID] int NOT NULL ,
	[Description] varchar (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ExecutionDate] datetime NOT NULL
	)
	
	INSERT INTO CWX_DBVersion values (100,'Build the CWX_DBVersion Table', getDate())

END

GO

IF(Select Count(*) from CWX_PasswordPolicy Where PasswordPolicyName='Before password expiry warning')=0
	INSERT INTO CWX_PasswordPolicy values ('Before password expiry warning', 5, 12)

GO

PRINT 'Completed execution of Scripts 3.6.8'
GO 

----------- End of Script to include in 3.6.8.sql received from Sathya on 12-May-2009 -------------

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO 

IF NOT EXISTS (SELECT 1 FROM CWX_Permission WHERE PermissionID = 83)
BEGIN
	INSERT INTO CWX_Permission (PermissionID, PermissionDescription, GroupID) VALUES (83, 'Search accounts in the user assigned clients', 4)
END
GO

IF NOT EXISTS (SELECT 1 FROM CWX_Permission WHERE PermissionID = 84)
BEGIN
	INSERT INTO CWX_Permission (PermissionID, PermissionDescription, GroupID) VALUES (84, 'Edit/Delete transactions', 4)
END
GO

IF NOT EXISTS (SELECT 1 FROM CWX_Permission WHERE PermissionID = 85)
BEGIN
	INSERT INTO CWX_Permission (PermissionID, PermissionDescription, GroupID) VALUES (85, 'Send Email/SMS', 4)
END 
GO