-- =============================================
-- Author:		Tuan Luong
-- Create date: Jan 12th, 2008
-- Description:	Select the granted permissions by userID and PermissionGroupID
-- =============================================
CREATE PROCEDURE CWX_UserPermission_SelectGrantedPermissionsByGroup
	@UserID int, 
	@PermissionGroupID int
AS
BEGIN	
	SET NOCOUNT ON;	
	SELECT [PermissionID], [PermissionDescription] FROM CWX_Permission 
	WHERE GroupID = @PermissionGroupID 
		  AND PermissionID in (SELECT [PermissionID] FROM [CWX_UserPermission] WHERE [UserID] = @UserID)
	ORDER BY [PermissionID]
	SET NOCOUNT OFF;
END
GO

-- ====================================================
-- Author:		Tuan Luong
-- Create date: Jan 14th, 2008
-- Description:	Select available permissions of an user
-- ====================================================
CREATE PROCEDURE CWX_UserPermission_SelectAvailPermissions
	@UserID int
AS
BEGIN	
	SET NOCOUNT ON;
	IF(@UserID = 0)
		SELECT [PermissionID], [GroupID] FROM CWX_Permission
		ORDER BY [GroupID], [PermissionID]
	ELSE
		SELECT [PermissionID], [GroupID] FROM CWX_Permission 
		WHERE PermissionID not in (SELECT [PermissionID] FROM [CWX_UserPermission] WHERE [UserID] = @UserID)
		ORDER BY [GroupID], [PermissionID]
	SET NOCOUNT OFF;
END
GO

-- ==================================================
-- Author:		Tuan Luong
-- Create date: Jan 14th, 2008
-- Description:	Select granted permissions of an user
-- ==================================================
CREATE PROCEDURE CWX_UserPermission_SelectGrantedPermissions
	@UserID int
AS
BEGIN	
	SET NOCOUNT ON;	
		SELECT [PermissionID], [GroupID] FROM CWX_Permission 
		WHERE PermissionID in (SELECT [PermissionID] FROM [CWX_UserPermission] WHERE [UserID] = @UserID)
		ORDER BY [GroupID], [PermissionID]
	SET NOCOUNT OFF;
END
GO

 /* PREVIOUS ORDER:
15	Change Status	3
16	Change Delinquency Officer Flag	3
17	Delete Promises Taken	3
18	Display in Management	3
19	Edit Legal Module	3
20	Order Batch Letter	3
21	Send Broadcast Message	3
22	Print Letters	3
23	Send Message Between Collector	3
24	Stop Letter	3
25	S. I. F. Bills	3
26	Work Debtors	3
27	Power Of Attorney	2
28	Search All Accounts	3
29	Allow Queue Picking	3
30	Add New and Edit Phone Details	3
31	Add New and Edit Address Details	3
*/

-- ==============================================================================
-- Author:		Tuan Luong
-- Create date: Jan 17th, 2008
-- Description:	TO MAKE PERMISSIONIDS SAME FROM ENUM INDEXES IN CORE APPLICATION
-- ==============================================================================
DELETE CWX_Permission
WHERE PermissionID in (15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31)
GO
INSERT INTO CWX_Permission VALUES(15,'Power Of Attorney', 2)
INSERT INTO CWX_Permission VALUES(16,'Change Status', 3)
INSERT INTO CWX_Permission VALUES(17,'Change Delinquency Officer Flag', 3)
INSERT INTO CWX_Permission VALUES(18,'Delete Promises Taken', 3)
INSERT INTO CWX_Permission VALUES(19,'Display in Management', 3)
INSERT INTO CWX_Permission VALUES(20,'Edit Legal Module', 3)
INSERT INTO CWX_Permission VALUES(21,'Send Letters', 3)
INSERT INTO CWX_Permission VALUES(22,'Send Broadcast Message', 3)
INSERT INTO CWX_Permission VALUES(23,'Print Letters', 3)
INSERT INTO CWX_Permission VALUES(24,'Send Message Between Collector', 3)
INSERT INTO CWX_Permission VALUES(25,'Stop Letter', 3)
INSERT INTO CWX_Permission VALUES(26,'S. I. F. Bills', 3)
INSERT INTO CWX_Permission VALUES(27,'Work Debtors', 3)
INSERT INTO CWX_Permission VALUES(28,'Search All Accounts', 3)
INSERT INTO CWX_Permission VALUES(29,'Add New and Edit Phone Details', 3)
INSERT INTO CWX_Permission VALUES(30,'Add New and Edit Address Details', 3)
INSERT INTO CWX_Permission VALUES(31,'Allow Queue Picking', 3)
GO



-- ==========================================================================
-- Author:		Tuan Luong
-- Create date: Jan 17th, 2008
-- Description:	Result = 1: new encripted password and old password are same
-- ==========================================================================
CREATE PROCEDURE CWX_PasswordPolicy_ValidatePreviousPasswordsAreSame
	@UserID int,
	@NewEncriptedPassword varchar(250),
	@Times int --how many times to get from PasswordHistory 	
AS
BEGIN	
	IF EXISTS (SELECT Password FROM CWX_User WHERE UserID = @UserID AND Password = @NewEncriptedPassword)		
	 	SELECT Result = 1 --SET @Result = 1	
	ELSE
	BEGIN--0
		CREATE TABLE #TempPwdHistory
		(
			OldPassword varchar(16)
		)

		DECLARE @sql nvarchar(2000)
		SET @sql = 'INSERT INTO #TempPwdHistory SELECT TOP ' + CAST(@Times as varchar(10)) + ' OldPassword ' 
		SET @sql = @sql + ' FROM CWX_PasswordHistory WHERE UserID = ' + CAST(@UserID as varchar(10)) + ' ORDER BY ChangeDate DESC'		
		
		PRINT @sql
		EXEC(@sql)

		DECLARE @OldPassword varchar(16)
		DECLARE OldPasswordCursor CURSOR FOR
		SELECT OldPassword FROM #TempPwdHistory
		OPEN OldPasswordCursor
		FETCH NEXT FROM OldPasswordCursor INTO @OldPassword
		
		DECLARE @Result int
		SET @Result = 0
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF (@NewEncriptedPassword = @OldPassword)
			Begin
				Print @Result
				SET	@Result = 1
				BREAK
			End
			FETCH NEXT FROM OldPasswordCursor INTO @OldPassword
		END		
		SELECT Result = @Result
		CLOSE OldPasswordCursor;
		DEALLOCATE OldPasswordCursor;
		DROP TABLE #TempPwdHistory
	END--0
	
END
GO