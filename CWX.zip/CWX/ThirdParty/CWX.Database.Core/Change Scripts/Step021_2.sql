﻿
-- Script is applied on release 3.6.6

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- =============================================
-- Author:		LongNguyen
-- Create date: Jan 08, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_User_UnlockByUserID] 
	@UserID int
AS
BEGIN
	UPDATE CWX_User
	SET
		IsLockedOut = 0
	WHERE
		UserID = @UserID


	IF EXISTS (SELECT * FROM CWX_User WHERE UserID = @UserID
					AND UserID NOT IN (SELECT UserID FROM CWX_LoginLog)
					AND ((GETDATE() - CreatedDate) > (select convert(int,PasswordPolicyValue) from
									CWX_PasswordPolicy where PasswordPolicyType = 11)))
	Begin
		Update CWX_User set CreatedDate = GETDATE() where UserID = @UserID
	end

END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- =============================================
-- Author:		LongNguyen
-- Create date: Jan 31, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_User_UnlockAll] 
	
AS
BEGIN
	UPDATE
		CWX_User
	SET
		IsLockedOut = 0

	IF EXISTS (SELECT * FROM CWX_User WHERE UserID NOT IN (SELECT UserID FROM CWX_LoginLog)
					AND ((GETDATE() - CreatedDate) > (select convert(int,PasswordPolicyValue) from
									CWX_PasswordPolicy where PasswordPolicyType = 11)))
	Begin
		Update CWX_User set CreatedDate = GETDATE() 
		where UserID in (SELECT UserID FROM CWX_User WHERE UserID NOT IN (SELECT UserID FROM CWX_LoginLog)
					AND ((GETDATE() - CreatedDate) > (select convert(int,PasswordPolicyValue) from
									CWX_PasswordPolicy where PasswordPolicyType = 11)))
	end

END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- =============================================
-- Author:		LongNguyen
-- Create date: Jan 08, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_User_UnlockByUserName] 
	@UserName varchar(10)
AS
BEGIN
	UPDATE CWX_User
	SET
		IsLockedOut = 0
	WHERE
		UserName = @UserName

	IF EXISTS (SELECT * FROM CWX_User WHERE upper(UserName) = upper(RTrim(@UserName))
					AND UserID NOT IN (SELECT UserID FROM CWX_LoginLog)
					AND ((GETDATE() - CreatedDate) > (select convert(int,PasswordPolicyValue) from
									CWX_PasswordPolicy where PasswordPolicyType = 11)))
	Begin
		Update CWX_User set CreatedDate = GETDATE() where upper(UserName) = upper(RTrim(@UserName))
	end

END

GO

PRINT 'Completed execution of Update Scripts 3.6.5 Build 2'
GO