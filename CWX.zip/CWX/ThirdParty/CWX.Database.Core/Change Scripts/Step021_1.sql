﻿ GO
/****** Object:  Table [dbo].[CWX_WorkflowProcess]    Script Date: 01/22/2009 10:54:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WorkflowProcess]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_WorkflowProcess]

GO
/****** Object:  Table [dbo].[CWX_WorkflowRequest]    Script Date: 01/22/2009 10:55:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WorkflowRequest]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_WorkflowRequest]

GO
/****** Object:  Table [dbo].[CWX_WorkflowProcess]    Script Date: 01/22/2009 10:55:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CWX_WorkflowProcess](
	[ProcessID] [numeric](13, 0) IDENTITY(1,1) NOT NULL,
	[ProcessName] [varchar](50) NOT NULL,
	[ProcessDescription] [varchar](250) NULL,
	[Type] [int] NULL,
	[URL] [varchar](250) NULL,
	[UserID] [varchar](50) NULL,
	[Status] [int] NOT NULL,
	[ProcessContextItems] [image] NOT NULL,
	[RequestID] [numeric](13, 0) NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[CreatedDate] [datetime] NOT NULL CONSTRAINT [DF_CM_R_Activity_CreatedDate]  DEFAULT (getdate()),
	[ModifiedBy] [varchar](50) NULL,
	[ModifiedDate] [datetime] NULL,
	[Remarks] [varchar](max) NULL,
	[Display] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_PADDING OFF

GO
/****** Object:  Table [dbo].[CWX_WorkflowRequest]    Script Date: 01/22/2009 10:55:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CWX_WorkflowRequest](
	[RequestID] [numeric](13, 0) IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[RequestCode] [varchar](10) NOT NULL,
	[RequestReferenceID] [numeric](13, 0) NOT NULL,
	[RequestReference] [varchar](500) NOT NULL,
	[Remarks] [text] NOT NULL,
	[Status] [int] NOT NULL,
	[WorkflowInstanceID] [varchar](50) NOT NULL,
	[WorkflowContextItems] [image] NOT NULL,
	[CustomContextItems] [image] NOT NULL,
	[CreatedBy] [varchar](15) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[ModifiedBy] [varchar](15) NULL,
	[ModifiedDate] [datetime] NULL,
 CONSTRAINT [PK_Request] PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_PADDING OFF