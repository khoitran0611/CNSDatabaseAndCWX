-- Script is applied on version 2.2.8 

/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 07/18/2008 18:50:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Profiles_UpdateLastActivity]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserID]    Script Date: 07/18/2008 18:50:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByUserID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserName]    Script Date: 07/18/2008 18:50:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByUserName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserNameAndPassword]    Script Date: 07/18/2008 18:50:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserNameAndPassword]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByUserNameAndPassword]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_Insert]    Script Date: 07/18/2008 18:50:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 07/18/2008 18:50:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Profiles_UpdateLastActivity]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'---------------------------------------------------
-- Description: Update LastActivity and SignOn status of specific user.
-- History:
--	2008/07/14	[Binh Truong]	Init version
---------------------------------------------------
CREATE PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
(
	@UserName nvarchar(50),
	@ApplicationName nvarchar(50)
)
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE	CWX_Profiles 
	SET		LastActivity = GetUTCDate()
	WHERE	UserName = @Username AND
			ApplicationName = @ApplicationName
			
	UPDATE		CWX_User
	SET			SignOn = 1
	WHERE		UserName = @Username
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserID]    Script Date: 07/18/2008 18:50:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/08	[Long Nguyen]	Init version.
--	2008/07/14	[Binh Truong]	Add Profiles table fields.
-- =============================================
CREATE PROCEDURE dbo.CWX_User_SelectByUserID 
	-- Add the parameters for the stored procedure here
	@UserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT  CWX_User.*, CWX_Profiles.*
	FROM    CWX_User LEFT OUTER JOIN
				CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE
			(CWX_User.UserID = @UserID)
			AND (ISNULL(CWX_User.UserStatus, '''') <> ''R'')
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserName]    Script Date: 07/18/2008 18:50:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserName]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/08	[Long Nguyen]	Init version.
--	2008/07/14	[Binh Truong]	Add Profiles table fields.
-- =============================================
CREATE PROCEDURE dbo.CWX_User_SelectByUserName 
	-- Add the parameters for the stored procedure here
	@UserName varchar(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT  CWX_User.*, CWX_Profiles.*
	FROM    CWX_User LEFT OUTER JOIN
	            CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE
			(CWX_User.UserName = @UserName)
			AND (ISNULL(UserStatus, '''') <> ''R'')
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserNameAndPassword]    Script Date: 07/18/2008 18:50:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserNameAndPassword]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/08	[Long Nguyen]	Init version.
--	2008/07/14	[Binh Truong]	Add Profiles table fields.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_SelectByUserNameAndPassword] 
	-- Add the parameters for the stored procedure here
	@UserName varchar(10),
	@Password varchar(250)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT     CWX_User.*, CWX_Profiles.*
	FROM         CWX_User LEFT OUTER JOIN
	                      CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE     (CWX_User.UserName = @UserName) AND (CWX_User.Password = @Password) AND (ISNULL(CWX_User.UserStatus, '''') <> ''R'')
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_Insert]    Script Date: 07/18/2008 18:50:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Insert new user
-- History:
--	2008/01/08	[LongNguyen]	Init version.
--	2008/07/18	[Binh Truong]	Insert Profile data.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_Insert] 
	-- Add the parameters for the stored procedure here
	@UserID int,
	@UserName varchar(10),
	@Password varchar(250),
	@FullName varchar(50),
	@Email varchar(50),
	@Comment varchar(225),
	@RoleID int,
	@Salt nchar (10),
	@CreatedDate datetime
AS
BEGIN
	DECLARE @profileID int

	INSERT INTO CWX_User
	(
		UserID,
		UserName,
		Password,
		FullName,
		Email,
		Comment,
		RoleID,
		IsLockedOut,
		UserStatus,
		Salt,
		CreatedDate
	)
	VALUES
	(
		@UserID,
		@UserName,
		@Password,
		@FullName,
		@Email,
		@Comment,
		@RoleID,
		0,
		''A'',
		@Salt,
		@CreatedDate
	)
	
	/*Insert the profile data.*/
	EXECUTE CWX_Profiles_Insert @profileID output, @userName, ''CWX'', 0
	INSERT CWX_ProfileData
	(
		ProfileID,
		Culture
	)
	VALUES
	(
		@profileID,
		''en-US''
	)
END

' 
END
GO
/******  Script Closed  ******/