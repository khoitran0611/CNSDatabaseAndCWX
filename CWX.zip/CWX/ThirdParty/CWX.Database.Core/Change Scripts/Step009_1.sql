-- Script is applied on version 1.9.6
INSERT INTO CWX_PermissionGroup(GroupID, GroupName) VALUES (4, 'Collector Functions')
GO
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (32, 'Change Password', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (33, 'Export To Excel', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (34, 'Change Delinquency Officer Flag', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (35, 'Access Quick Search', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (36, 'Change Collector', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (37, 'Change Status', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (38, 'Change Queue Date', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (39, 'Change Refer To', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (40, 'Change Next Action', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (41, 'Change Call Result', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (42, 'Change Reason', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (43, 'Access Standard Notes', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (44, 'Order On Demand Letter', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (45, 'Order Batch Letter', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (46, 'Stop Letter', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (47, 'Apply Fees', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (48, 'Stop Fees', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (49, 'Edit Hot note', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (50, 'Delete Promises Taken', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (51, 'Edit Phone Details', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (52, 'Edit Address Details', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (53, 'Access Receive Payment and Add Other Charges', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (54, 'Create New Ticket', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (55, 'Access Legal Module', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (56, 'Send Message Between Collector', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (57, 'Send Broadcast Message', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (58, 'Access Imaging', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (59, 'Access Print Options', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (60, 'Access Help Module', 4)

INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (61, 'Search All Accounts', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (62, 'Allow Queue Picking', 4)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (63, 'Work Debtors', 4)
GO

/****** Object:  StoredProcedure [dbo].[CWX_PermissionGroup_SelectAll]    Script Date: 06/11/2008 15:19:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PermissionGroup_SelectAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PermissionGroup_SelectAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PermissionGroup_SelectAll]    Script Date: 06/11/2008 15:19:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PermissionGroup_SelectAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_PermissionGroup_SelectAll] 		 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT * FROM CWX_PermissionGroup ORDER BY GroupName
	SET NOCOUNT OFF;
END
' 
END
GO

/****** Object:  [dbo].[CWX_PasswordPolicy]    Script Date: 06/11/2008 15:19:51 ******/

 IF NOT EXISTS (SELECT * FROM CWX_PasswordPolicy WHERE PasswordPolicyType=10)
	INSERT INTO CWX_PasswordPolicy(PasswordPolicyName, PasswordPolicyValue, PasswordPolicyType) VALUES('Force X previous passwords check', '0', 10)

IF NOT EXISTS (SELECT * FROM CWX_PasswordPolicy where PasswordPolicyType=11)
	INSERT INTO CWX_PasswordPolicy(PasswordPolicyName, PasswordPolicyValue, PasswordPolicyType) VALUES('Force disable user ID X days not in use.', '0', 11)	
	
IF NOT EXISTS (SELECT * FROM CWX_PasswordPolicy where PasswordPolicyType=12)
	INSERT INTO CWX_PasswordPolicy(PasswordPolicyName, PasswordPolicyValue, PasswordPolicyType) VALUES('Force change after X days of user creating.', '0', 12)		


/****** Object:  StoredProcedure [dbo].[CWX_PasswordPolicy_ValidatePreviousPasswordsAreSame]    Script Date: 06/11/2008 17:11:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_PasswordPolicy_ValidatePreviousPasswordsAreSame]
	@UserID int,
	@NewEncriptedPassword varchar(500),
	@Times int --how many times to get from PasswordHistory 	
AS
BEGIN	
	IF EXISTS (SELECT Password FROM CWX_User WHERE UserID = @UserID AND Password = @NewEncriptedPassword)		
	 	SELECT Result = 1 --SET @Result = 1	
	ELSE
	BEGIN--0
		CREATE TABLE #TempPwdHistory
		(
			OldPassword varchar(500)
		)

		DECLARE @sql nvarchar(2000)
		SET @sql = 'INSERT INTO #TempPwdHistory SELECT TOP ' + CAST(@Times as varchar(10)) + ' OldPassword ' 
		SET @sql = @sql + ' FROM CWX_PasswordHistory WHERE UserID = ' + CAST(@UserID as varchar(10)) + ' ORDER BY ChangeDate DESC'		
		
		PRINT @sql
		EXEC(@sql)

		DECLARE @OldPassword varchar(1000)
		DECLARE OldPasswordCursor CURSOR FOR
		SELECT OldPassword FROM #TempPwdHistory
		OPEN OldPasswordCursor
		FETCH NEXT FROM OldPasswordCursor INTO @OldPassword
		
		DECLARE @Result int
		SET @Result = 0
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF (@NewEncriptedPassword = @OldPassword)
			Begin
				Print @Result
				SET	@Result = 1
				BREAK
			End
			FETCH NEXT FROM OldPasswordCursor INTO @OldPassword
		END		
		SELECT Result = @Result
		CLOSE OldPasswordCursor;
		DEALLOCATE OldPasswordCursor;
		DROP TABLE #TempPwdHistory
	END--0
	
END
/******  Script Closed. Go next: Step009_2  ******/