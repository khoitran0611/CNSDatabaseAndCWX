-- Script is applied on version 2.4.10, 2.4.12, 2.4.14

-- Scripts 2.4.10:

IF NOT EXISTS(SELECT * FROM CWX_AuditTables WHERE ID=29)
BEGIN
	INSERT INTO CWX_AuditTables (ID, ClassName, Description, Audited)
	VALUES (29, 'Score Cards', 'Score Cards', 1)
	
	INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName)
	VALUES (29, 'Scorecard')
	
	INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName)
	VALUES (29, 'ScorecardRiskFactor')
	
	INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName)
	VALUES (29, 'ScorecardRiskFactorGroup')
	
	INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName)
	VALUES (29, 'ScorecardRiskFactorRule')
END

-- Scripts 2.4.12:
IF NOT EXISTS (SELECT PermissionID FROM CWX_Permission WHERE PermissionID=8)
	INSERT INTO CWX_Permission VALUES(8, 'Access Management Console', 1)
GO

/******  Script Closed. Go next: Step015_1  ******/