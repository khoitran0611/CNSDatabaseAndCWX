-- Script apply on version 1.2 build 1
 
 /****** Object:  StoredProcedure [dbo].[CWX_Role_MoveDown]    Script Date: 03/11/2008 16:32:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_MoveDown]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Role_MoveDown]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_MoveUp]    Script Date: 03/11/2008 16:32:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_MoveUp]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Role_MoveUp]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_MoveDown]    Script Date: 03/11/2008 16:32:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 25, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Role_MoveDown]
	-- Add the parameters for the stored procedure here
	@RoleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RoleOrder int
	SELECT @RoleOrder = RoleOrder FROM CWX_Role WHERE RoleID = @RoleID

	DECLARE @NextRoleID int
	SELECT
		@NextRoleID = RoleID
	FROM
		CWX_Role
	WHERE
		RoleOrder = (SELECT MIN(RoleOrder) FROM CWX_Role WHERE RoleOrder > @RoleOrder AND Status = 'A')

	IF @NextRoleID IS NOT NULL
	BEGIN
		DECLARE @NextOrder int
		SELECT @NextOrder = RoleOrder FROM CWX_Role WHERE RoleID = @NextRoleID AND Status = 'A'

		DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		UPDATE CWX_Role
		SET RoleOrder = @NextOrder
		WHERE  RoleID = @RoleID
		IF( @@ERROR <> 0)
			GOTO Cleanup

		UPDATE CWX_Role
		SET RoleOrder = @RoleOrder
		WHERE  RoleID = @NextRoleID
		IF( @@ERROR <> 0)
			GOTO Cleanup

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END

END



GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_MoveUp]    Script Date: 03/11/2008 16:32:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 25, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Role_MoveUp]
	-- Add the parameters for the stored procedure here
	@RoleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RoleOrder int
	SELECT @RoleOrder = RoleOrder FROM CWX_Role WHERE RoleID = @RoleID

	DECLARE @PreviousRoleID int
	SELECT
		@PreviousRoleID = RoleID
	FROM
		CWX_Role
	WHERE
		RoleOrder = (SELECT MAX(RoleOrder) FROM CWX_Role WHERE RoleOrder < @RoleOrder AND Status = 'A')

	IF @PreviousRoleID IS NOT NULL
	BEGIN
		DECLARE @PreviousRoleOrder int
		SELECT @PreviousRoleOrder = RoleOrder FROM CWX_Role WHERE RoleID = @PreviousRoleID AND Status = 'A'

		DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		UPDATE CWX_Role
		SET RoleOrder = @PreviousRoleOrder
		WHERE  RoleID = @RoleID
		IF( @@ERROR <> 0)
			GOTO Cleanup

		UPDATE CWX_Role
		SET RoleOrder = @RoleOrder
		WHERE  RoleID = @PreviousRoleID
		IF( @@ERROR <> 0)
			GOTO Cleanup

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END

END