-- Script is applied on version 1.6.1

 /****** Object:  Table [dbo].[CWX_AuditTables]    Script Date: 05/15/2008 17:36:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTables]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_AuditTables]
GO
/****** Object:  Table [dbo].[CWX_AuditTables]    Script Date: 05/15/2008 17:36:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTables]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_AuditTables](
	[ID] [int] NOT NULL,
	[ClassName] [varchar](50) NOT NULL,
	[Description] [nvarchar](100) NULL,
	[Audited] [bit] NOT NULL,
 CONSTRAINT [PK_CWX_AuditTables] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO


INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (1,'Account','Account Information',1)
-- Account

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (2,'AccountPromise','Account Promise',1)
-- dbo.AccountPromise

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (3,'AccountMemo','Account Memo',1)
--dbo.AccountMemo

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (4,'AccountLegal','Account Legal Process and Items,Forwarders and Legal Actions',1)
--dbo.LegalProcess
--dbo.LegalProcessItems
--dbo.LegalAction
--dbo.Referrals

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (5,'AccountAudit','Audit Options',1)
--dbo.CWX_AuditTables

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (6,'AvailableActions','Account Action Codes',1)
--dbo.AvailableActions


INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (7,'Transactions','Account Add Other Charges and Recieve Payment Transactions',1)
--dbo.Transactions

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (8,'AccountStatus','User Defined Account Status',1)
--dbo.AccountStatus

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (9,'AccountCodeMaster','Promise Giver,Campaign,Next Action,Call Result,Reason,Type and Stage',1)
--dbo.AccountCodeMaster

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (10,'AccountAllocationSort','Account Allocation Sort',1)
--dbo.AllocationSortMaster

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (11,'ClientInformation','Product Information',1)
--dbo.ClientInformation

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (12,'Collateral','Account Collateral',1)
--dbo.Collateral

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (13,'DebtorInformation','Debtor Information (Hot Note)',1)
-- dbo.DebtorInformation

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (14,'EmployeeDept','Department,Languages and Nationality',1)
--dbo.EmployeeDepartment
--dbo.Nationality_Master
--dbo.Languages

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (15,'Employee','Employee Information',1)
--dbo.Employee

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (16,'Rules','Extraction,Business and Result Processing Rules',1)
--dbo.RuleTable
--dbo.RulesAllocUsers
--dbo.RuleOthers
--dbo.RuleCriteria

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (17,'Productivity','Employee Productvity Goals',1)
--dbo.EmployeeGoals

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (18,'Fees','Fee Definition',1)
--dbo.DefineFees

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (19,'InformationTable','Global Settings,Password Settings,Promise Frequency and Standard Notes',1)
--dbo.InformationTable

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (20,'HolidayCal','Holiday Calendar',1)
--dbo.BlackOutDates

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (21,'Imaging','Account Imaging',1)
--dbo.Image (Need to store the image in image table/disk?)
--dbo.DefineImageType

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (22,'PhoneAddress','Phone and Address Details',1)
--dbo.PersonPhone
--dbo.PersonAddress

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (23,'QueuePriority','Queue Priority',1)
--dbo.QueueSortMaster
--dbo.QueueSortORder

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (24,'Report','Report Information(Document Definitions and Schedules',1)
--dbo.DefineLetters
--dbo.ReportScheduleDate
--dbo.ReportSchedulelog
--dbo.ReportScheduleTable


INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (25,'Roles','Role Definition',1)
--dbo.RoleDefinition


INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (26,'Messages','Remainder and Broadcast Messages',1)
--dbo.BroadCast
--dbo.Messages


INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (27,'TracerCustomFields','Tracer & Custom Defined Fields',1)
--dbo.CWX_CustomDefinedFields

INSERT INTO CWX_AuditTables([ID],[ClassName],[Description],[Audited])
VALUES (28,'Ticket','Ticket,Ticket Definition,Ticket Stages and Settlement',1)
--dbo.Ticket
--dbo.TicketDefinition
--dbo.TicketStages

/******  Script Closed  ******/