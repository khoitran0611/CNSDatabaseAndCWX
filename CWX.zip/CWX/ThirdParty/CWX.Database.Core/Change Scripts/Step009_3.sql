-- Script is applied on version 1.9.11
update CWX_Permission set PermissionDescription='Edit Hot Note' where PermissionID=49
GO

/****** Object:  Table [dbo].[CWX_LoginAttemptsLog]    Script Date: 06/12/2008 17:00:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginAttemptsLog]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_LoginAttemptsLog](
		[LogID] [int] IDENTITY(1,1) NOT NULL,
		[UserID] [int] NULL,
		[LoginDateTime] [smalldatetime] NULL,
		[IPAddress] [varchar](50) NULL,
		[LoginStatus] [varchar](50) NULL,
		[Reason] [varchar](250) NULL
	) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[CWX_LoginLog]    Script Date: 06/12/2008 17:00:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_LoginLog](
		[UserID] [int] NOT NULL,
		[LoginTime] [varchar](50) NULL,
		[LogoutTime] [varchar](50) NULL,
		[MinutesLoggedIn] [int] NULL
	) ON [PRIMARY]
END	
GO
SET ANSI_PADDING OFF
  
  /****** Object:  StoredProcedure [dbo].[CWX_UserNotInUse]    Script Date: 06/12/2008 16:22:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_UserNotInUse]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Check whether user is not in use X days after first creation or password reset.
-- Parameters:
--		@UserName: current logged in user
--		@AvailableDays: X days allowed
-- History:
--		2008/06/12	[Thuy Nguyen]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_UserNotInUse] 	
	@UserName varchar(10),
	@AvailableDays int

AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @LoginUser varchar(16)	
	DECLARE @Result int
	IF EXISTS (SELECT * FROM CWX_User WHERE UserName = @UserName 
					AND UserID NOT IN (SELECT UserID FROM CWX_LoginAttemptsLog)
					AND (GETDATE() - CreatedDate) > @AvailableDays)
		SET @Result= 1
	ELSE
    BEGIN
	
		DECLARE @LastChangeDate DATETIME
		DECLARE @LastLoginDate DATETIME

		SET @LastChangeDate = (SELECT ChangeDate FROM CWX_PasswordHistory a LEFT JOIN CWX_User b ON a.UserID = b.UserID
									WHERE b.UserName = @UserName AND ChangeDate > = (SELECT MAX(ChangeDate) FROM CWX_PasswordHistory))


		SET @LastLoginDate = (SELECT LoginDateTime FROM CWX_LoginAttemptsLog a LEFT JOIN CWX_User b ON a.UserID = b.UserID
									WHERE b.UserName = @UserName AND LoginDateTime > = (SELECT MAX(LoginDateTime) FROM CWX_LoginAttemptsLog))

		IF (@LastChangeDate IS NOT NULL AND @LastLoginDate IS NOT NULL AND (@LastChangeDate - @LastLoginDate) > @AvailableDays)
			SET @Result = 1	
		ELSE 
			SET @Result = 0
	END

	SELECT @Result
END
'
END


/****** Object:  StoredProcedure [dbo].[CWX_Role_SoftDeleteAll]    Script Date: 06/12/2008 17:52:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_SoftDeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Role_SoftDeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_SoftDeleteAll]    Script Date: 06/12/2008 17:52:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_SoftDeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- ===================================================================================
-- Author:		Binh Truong
-- Create date: Jun 12, 2008
-- Description:	Soft delete all roles
-- ===================================================================================
create PROCEDURE [dbo].[CWX_Role_SoftDeleteAll]
AS
BEGIN
	UPDATE	CWX_Role
	SET     Status = ''R''
END
' 
END
GO

ALTER TABLE CWX_LoginLog ALTER COLUMN LoginTime datetime
ALTER TABLE CWX_LoginLog ALTER COLUMN LogoutTime datetime

GO

/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Insert]    Script Date: 06/12/2008 18:13:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LoginLog_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_LoginLog_Insert]    Script Date: 06/12/2008 18:13:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoginLog_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Binh Truong
-- Create date: Jun 12, 2008
-- Description:	Insert a new login log.
-- =============================================
CREATE PROCEDURE dbo.CWX_LoginLog_Insert
(
	@UserID int,
	@LoginTime datetime,
	@LogoutTime datetime,
	@MinutesLoggedIn int
)
	
AS
	SET NOCOUNT ON
	INSERT INTO CWX_LoginLog
				(UserID, LoginTime, LogoutTime, MinutesLoggedIn)
	VALUES		(@UserID,@LoginTime,@LogoutTime,@MinutesLoggedIn)
	RETURN
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_UserNotInUse]    Script Date: 06/13/2008 09:16:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_NeedChangePassword]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Check whether user is not in use X days after first creation or password reset.
-- Parameters:
--		@UserName: current logged in user
--		@AvailableDays: X days allowed
-- History:
--		2008/06/13	[Thuy Nguyen]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_NeedChangePassword] 	
	@UserName varchar(10),
	@AvailableDays int

AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @Result int
	IF EXISTS (SELECT * FROM CWX_User 
					WHERE (ChangePwdDate IS NULL AND (GETDATE() - CreatedDate) > @AvailableDays)
						OR (ChangePwdDate IS NOT NULL AND (GETDATE() - ChangePwdDate) > @AvailableDays))
		SET @Result= 1
	ELSE
		SET @Result = 0	

	SELECT @Result
END
'
END
GO

delete from CWX_Permission where PermissionID in (16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31)
GO

INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (70, 'Override Min Acceptable Promise Amount Percent', 3)
GO

/******  Script Closed. Go next: Step009_4  ******/