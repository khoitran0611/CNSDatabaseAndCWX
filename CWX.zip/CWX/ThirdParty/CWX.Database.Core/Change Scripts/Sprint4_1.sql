﻿ -- Thuy Nguyen added on 22-April-2009 --

if not exists (select * from CWX_Permission where PermissionDescription = 'Edit full details primary customer and accounts')
	insert into CWX_Permission(PermissionID,PermissionDescription, GroupID) values(81, 'Edit full details primary customer and accounts', 4)
go

if not exists (select * from CWX_Permission where PermissionDescription = 'Access to Debt and Debtor Management')
	insert into CWX_Permission(PermissionID,PermissionDescription, GroupID) values(82, 'Access to Debt and Debtor Management', 1)
else
	update 	CWX_Permission set PermissionID = 82 where PermissionDescription = 'Access to Debt and Debtor Management'
go

-- End of Thuy Nguyen added on 22-April-2009 --