-- Script is applied on version 2.5.3, 2.5.4, 2.5.8, 2.5.14, 2.5.16

-- Scripts 2.5.3:

/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Insert]    Script Date: 08/26/2008 10:15:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Insert]    Script Date: 08/26/2008 10:15:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--		2008/05/22	[Binh Truong]	Remove AccountID, DebtorID field.
--									Add OriginalData field.
--		2008/05/24	[Binh Truong]	Add @ChangeField default value = NULL
--		2008/07/30	[Binh Truong]	Add @DBConnectionName parameter.
--		2008/08/26	[Binh Truong]	Add @AuditDateTime parameter.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AuditTrail_Insert] 
(
	@EmployeeID INT,
	@ActionID TINYINT,
	@DBConnectionName VARCHAR(100),
	@ChangeTable VARCHAR(50),
	@RowID VARCHAR(20),
	@ChangeField VARCHAR(50) = NULL,
	@OriginalData NVARCHAR(MAX) = NULL,
	@ChangeData NVARCHAR(MAX) = NULL,
	@AuditDateTime DATETIME
)
AS
	INSERT INTO		CWX_AuditTrail
	                (EmployeeID, ActionID, DBConnectionName, ChangeTable, RowID, ChangeField, OriginalData, ChangeData, AuditDateTime)
	VALUES			(@EmployeeID,@ActionID,@DBConnectionName,@ChangeTable,@RowID,@ChangeField,@OriginalData,@ChangeData,@AuditDateTime)' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Update]    Script Date: 08/26/2008 10:20:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_Update]
GO


/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Update]    Script Date: 08/26/2008 14:05:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProfileData_Update]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Update]    Script Date: 08/26/2008 14:05:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Update]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_ProfileData_Update]
(
	@userName nvarchar(50),
	@applicationName nvarchar(50),
	@isAnonymous bit,
	@culture nvarchar(200),
	@dbConnectionName nvarchar(500) = ''''
)
As
BEGIN

	SET NOCOUNT ON;

	Declare @activity datetime
	Set @activity=GetUTCDate()

	/*Determine if a profile exists, if not create one.*/
	Declare @profileID int
	Execute CWX_Profiles_GetProfileID @profileID output, @userName, @applicationName, @isAnonymous

	If @profileID Is Null Begin
		Execute CWX_Profiles_Insert @profileID output, @userName, @applicationName, @isAnonymous
	End

	/*Insert the profile data.*/
	Declare @profileDataID int
	Set @profileDataID=(Select ProfileDataID From CWX_ProfileData Where (ProfileID=@profileID))
	If @profileDataID Is Null Begin
		Insert CWX_ProfileData
		(
		ProfileID,
		Culture,
		DbConnectionName
		)
		Values
		(
		@profileID,
		@culture,
		@dbConnectionName
		)
	End Else Begin
		Update CWX_ProfileData 
		Set Culture=@culture, DbConnectionName=@dbConnectionName
		Where ProfileID=@profileID
	End

	/*Update date/time profile had activity and was updated.*/
	Execute CWX_Profiles_Activity_Update @userName, @applicationName, @isAnonymous, @activity, @activity

END
' 
END
GO

-- Scripts 2.5.4:

IF NOT EXISTS (SELECT PermissionID FROM CWX_Permission WHERE PermissionID = 72)
BEGIN
	INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (72, 'Access Dialer', 4)
END

-- Scripts 2.5.8:
IF NOT EXISTS (SELECT PermissionID FROM CWX_Permission WHERE PermissionID=73)
	INSERT INTO CWX_Permission VALUES(73, 'Create Group Account', 4)
GO

-- Scripts 2.5.14

/****** Object:  StoredProcedure [dbo].[CWX_User_GetLoggedInUser]    Script Date: 09/08/2008 11:05:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_GetLoggedInUser]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_GetLoggedInUser]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_GetLoggedInUser]    Script Date: 09/08/2008 11:05:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_GetLoggedInUser]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <6 September 2008>
-- Description:	<Get userid logged in on current date>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_GetLoggedInUser]
	@EmployeeIDString varchar(1000) = '''',
	@IsGetBySupervisor bit = 0,
	@DBConnectionName varchar(100) = ''''
AS
BEGIN
	
	IF @EmployeeIDString = ''''
		SET @EmployeeIDString = ''0''
	IF @IsGetBySupervisor = 1
		BEGIN
			DECLARE @querystring varchar(500)
			SET @querystring = 
			''SELECT DISTINCT UserID FROM CWX_LoginLog 
			WHERE CONVERT(varchar(10), LoginTime, 121) = CONVERT(varchar(10), GETDATE(), 121)
			AND UserID IN ('' + @EmployeeIDString +'')
			AND DBConnectionName = '''''' + @DBConnectionName + ''''''''
			EXEC (@querystring)
		END
	
	ELSE
		BEGIN
			SELECT DISTINCT UserID FROM CWX_LoginLog 
			WHERE CONVERT(varchar(10), LoginTime, 121) = CONVERT(varchar(10), GETDATE(), 121)
			AND DBConnectionName = @DBConnectionName
		END	
END
' 
END
GO

/******  Script Closed. Go next: Step016_1  ******/