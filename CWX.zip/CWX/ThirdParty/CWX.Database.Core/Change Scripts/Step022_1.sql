﻿-- Script is applied on version 3.6.6:

PRINT 'Start of Scripts 3.6.6'
GO

/****** Object:  StoredProcedure [dbo].[CWX_UserNotInUse]    Script Date: 04/09/2009 16:09:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_UserNotInUse]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_UserNotInUse]
GO

/****** Object:  StoredProcedure [dbo].[CWX_UserNotInUse]    Script Date: 04/09/2009 16:09:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_UserNotInUse]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE PROCEDURE [CWX_UserNotInUse] 	
	@UserName varchar(10),
	@AvailableDays int

AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @LoginUser varchar(16)	
	DECLARE @Result int
	IF EXISTS (SELECT * FROM CWX_User WHERE UserName = @UserName 
					AND UserID NOT IN (SELECT UserID FROM CWX_LoginLog)
					AND (GETDATE() - CreatedDate) > @AvailableDays)
		SET @Result= 1
	ELSE
    BEGIN
		DECLARE @LastChangeDate DATETIME
		DECLARE @LastLoginDate DATETIME

		SET @LastChangeDate = (SELECT TOP 1 ChangeDate FROM CWX_PasswordHistory a LEFT JOIN CWX_User b ON a.UserID = b.UserID
									WHERE b.UserName = @UserName ORDER BY ChangeDate DESC)


		SET @LastLoginDate = (SELECT TOP 1 LoginTime FROM CWX_LoginLog a LEFT JOIN CWX_User b ON a.UserID = b.UserID
									WHERE b.UserName = @UserName ORDER BY LoginTime DESC)

		SET @Result = 0	
		
		IF (@LastLoginDate IS NOT NULL AND (datediff(d,@LastLoginDate,getdate())) > @AvailableDays)
			SET @Result = 1	

		--IF (@LastChangeDate IS NOT NULL AND @LastLoginDate IS NOT NULL AND (datediff(d,@LastChangeDate,@LastLoginDate)) > @AvailableDays)
			--SET @Result = 1	

		IF (@LastChangeDate IS NOT NULL) and (datediff(d,@LastChangeDate,getdate()) <= @AvailableDays)
			SET @Result = 0

	END

	SELECT @Result
END

' 
END
GO

PRINT 'Completed execution of Update Scripts 3.6.6'
GO
