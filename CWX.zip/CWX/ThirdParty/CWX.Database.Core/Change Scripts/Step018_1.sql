-- Script is applied on version 2.9.11, 2.9.12, 2.9.13, 2.9.14, 2.9.15, 2.9.16, 2.9.17, 2.9.19, 2.9.22

-- Scripts 2.9.11:

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.CWX_ProfileData ADD
	CmsID varchar(30) NULL
GO
COMMIT
GO

/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Select]    Script Date: 11/17/2008 11:49:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Select]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProfileData_Select]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Update]    Script Date: 11/17/2008 11:49:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProfileData_Update]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Select]    Script Date: 11/17/2008 11:49:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Select]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Select profile data.
-- History:
--	2008/11/17	[Binh Truong]	Remove update activity time.
--								Add CmsID field.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ProfileData_Select]
(
	@userName nvarchar(50),
	@applicationName nvarchar(50),
	@isAnonymous bit
)
As
BEGIN	
	/*Update date/time profile had activity.*/
	-- No need to update activity time since we have UpdateUserOnline function to do that.
	-- Execute CWX_Profiles_Activity_Update @userName, @applicationName, @isAnonymous, GetUTCDate(), null

	SELECT	
			Culture, DbConnectionName, CmsID
	FROM	
			CWX_Profiles
			INNER JOIN CWX_ProfileData On CWX_Profiles.ProfileID=CWX_ProfileData.ProfileID
	WHERE	
			UserName=@userName AND 
			ApplicationName=@applicationName AND
			IsAnonymous=@isAnonymous
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_Update]    Script Date: 11/17/2008 11:49:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_Update]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Select profile data.
-- History:
--	2008/11/17	[Binh Truong]	Remove update activity time.
--								Add CmsID parameter and update CmsID field.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ProfileData_Update]
(
	@userName nvarchar(50),
	@applicationName nvarchar(50),
	@isAnonymous bit,
	@culture nvarchar(200),
	@dbConnectionName nvarchar(500) = '''',
	@CmsID varchar(30) = NULL
)
As
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @profileID int
	DECLARE @profileDataID int

	/*Determine if a profile exists, if not create one.*/
	
	EXECUTE CWX_Profiles_GetProfileID @profileID OUTPUT, @userName, @applicationName, @isAnonymous

	IF @profileID IS NULL 
	BEGIN
		EXECUTE CWX_Profiles_Insert @profileID OUTPUT, @userName, @applicationName, @isAnonymous
	End

	/*Insert the profile data.*/	
	SET @profileDataID = (SELECT ProfileDataID FROM CWX_ProfileData WHERE ProfileID = @profileID)
	IF @profileDataID IS NULL
	BEGIN
		INSERT CWX_ProfileData
			(
			ProfileID,
			Culture,
			DbConnectionName,
			CmsID
			)
		VALUES
			(
			@profileID,
			@culture,
			@dbConnectionName,
			@CmsID
			)
	END
	ELSE
	BEGIN
		UPDATE	
				CWX_ProfileData 
		SET 
				Culture = @culture, 
				DbConnectionName = @dbConnectionName,
				CmsID = @CmsID
		WHERE 
				ProfileID = @profileID
	END

	-- No need to update activity time since we have UpdateUserOnline function to do that.
	/*Update date/time profile had activity and was updated.*/
	--Execute CWX_Profiles_Activity_Update @userName, @applicationName, @isAnonymous, GetUTCDate(), @activity
END
' 
END
GO

-- Scripts 2.9.12:

/****** Object:  StoredProcedure [dbo].[CWX_Role_ApplyNewRolePermissions]    Script Date: 11/18/2008 17:10:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_ApplyNewRolePermissions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Role_ApplyNewRolePermissions]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_ApplyNewRolePermissions]    Script Date: 11/18/2008 17:10:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_ApplyNewRolePermissions]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Long Nguyen
-- Create date: 2008-11-18
-- Description:	Apply role permissions for all user
-- =============================================
CREATE PROCEDURE dbo.CWX_Role_ApplyNewRolePermissions
	-- Add the parameters for the stored procedure here
	@RoleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.

	DECLARE @ReturnValue bit
	SET @ReturnValue=0

	IF EXISTS (SELECT RoleID FROM CWX_User WHERE RoleID=@RoleID)
	BEGIN
		DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		--Delete all user permission, that has selected role
		DELETE FROM CWX_UserPermission
		WHERE UserID IN (SELECT UserID FROM CWX_User WHERE RoleID=@RoleID)
		IF( @@ERROR <> 0)
			GOTO Cleanup

		--Add new permission for user
		DECLARE UserIDsCrsr CURSOR FOR
		SELECT UserID FROM CWX_User WHERE RoleID=@RoleID

		OPEN UserIDsCrsr
		DECLARE @UserID int
		FETCH NEXT FROM UserIDsCrsr INTO @UserID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			INSERT INTO CWX_UserPermission
			SELECT @UserID, PermissionID
			FROM CWX_RolePermission
			WHERE RoleID=@RoleID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM UserIDsCrsr INTO @UserID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @ReturnValue=1
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

		Cleanup:

		CLOSE UserIDsCrsr
		DEALLOCATE UserIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			ROLLBACK TRANSACTION
		END
	END

	RETURN @ReturnValue
END
' 
END
GO


-- Scripts 2.9.13:

IF NOT EXISTS (SELECT PermissionID FROM CWX_Permission WHERE PermissionID=78)
	INSERT INTO CWX_Permission VALUES(78, 'Allow promise on not assigned accounts', 4)
GO

-- Scripts 2.9.14:
/****** Object:  StoredProcedure [dbo].[CWX_User_Insert]    Script Date: 11/19/2008 17:38:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Insert new user
-- History:
--	2008/01/08	[LongNguyen]	Init version.
--	2008/07/18	[Binh Truong]	Insert Profile data.
--  2008/11/19	[Minh Dam]		Insert Change Password Date
-- =============================================
ALTER PROCEDURE [dbo].[CWX_User_Insert] 
	-- Add the parameters for the stored procedure here
	@UserID int,
	@UserName varchar(10),
	@Password varchar(250),
	@FullName varchar(50),
	@Email varchar(50),
	@Comment varchar(225),
	@RoleID int,
	@Salt nchar (10),
	@CreatedDate datetime
AS
BEGIN
	DECLARE @profileID int

	INSERT INTO CWX_User
	(
		UserID,
		UserName,
		Password,
		FullName,
		Email,
		Comment,
		RoleID,
		IsLockedOut,
		UserStatus,
		Salt,
		CreatedDate,
		ChangePwdDate
	)
	VALUES
	(
		@UserID,
		@UserName,
		@Password,
		@FullName,
		@Email,
		@Comment,
		@RoleID,
		0,
		'A',
		@Salt,
		@CreatedDate,
		@CreatedDate
	)
	
	/*Insert the profile data.*/
	EXECUTE CWX_Profiles_Insert @profileID output, @userName, 'CWX', 0
	INSERT CWX_ProfileData
	(
		ProfileID,
		Culture
	)
	VALUES
	(
		@profileID,
		'en-US'
	)
END
GO

-- Scripts 2.9.15:

-- Author:	Minh Dam
-- Date:	Nov-20-2008
-- Description: Delete Password Policy: Force Change Password After X Days
DELETE CWX_PasswordPolicy WHERE PasswordPolicyType=12
GO


-- Scripts 2.9.16:

-- =============================================
-- Author:		Minh Dam
-- Create date: 21-Nov-2008
-- Description:	Get the last agency status
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_GetLastAgencyStatus]    Script Date: 11/21/2008 15:21:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_GetLastAgencyStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_GetLastAgencyStatus]
GO

/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_GetLastAgencyStatus]    Script Date: 11/21/2008 14:43:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_AuditTrail_GetLastAgencyStatus]
	-- Add the parameters for the stored procedure here	
	@AccountID varchar(20),
	@DBConnectionName nvarchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	SELECT	TOP 1 OriginalData
	FROM	CWX_AuditTrail
	WHERE	RowID = @AccountID
		AND DBConnectionName = @DBConnectionName
		AND ChangeTable = 'Account'
		AND ChangeField = 'AgencyStatusID'
		AND ActionID = 2
	ORDER BY AuditDateTime DESC
END
GO

-- Scripts 2.9.17:
/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 11/21/2008 15:08:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
---------------------------------------------------
-- Description: Update LastActivity and SignOn status of specific user.
-- History:
--	2008/07/14	[Binh Truong]	Init version
--	2008/11/21	[Minh Dam]		Add parameter @Today
--								REM "UPDATE CWX_User SET SignOn=1 WHERE UserName=@UserName"
---------------------------------------------------
ALTER PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
(
	@UserName nvarchar(50),
	@ApplicationName nvarchar(50),
	@Today datetime
)
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE	CWX_Profiles 
	SET		LastActivity = @Today
	WHERE	UserName = @Username AND
			ApplicationName = @ApplicationName
			
--	UPDATE		CWX_User
--	SET			SignOn = 1
--	WHERE		UserName = @Username
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_User_UpdateUserOnlineStatus]    Script Date: 11/21/2008 15:16:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-------------------------------------
-- Description: Update user online status.
-- History:
--	2008/07/11	[Binh Truong]	Init version.
--  2008/11/21	[Minh Dam]		Add parameter @Today
-------------------------------------
ALTER PROCEDURE [dbo].[CWX_User_UpdateUserOnlineStatus] 
(
	@Username varchar(50),
	@UserIsOnlineTimeWindow int = 0,
	@IsForceSetStatus int = 0,
	@IsSignOn int = 0,
	@Today datetime
)
AS
BEGIN
	SET NOCOUNT ON
	IF @IsForceSetStatus = 0
	BEGIN
		DECLARE @LastActivity datetime
		
		SELECT	@LastActivity = LastActivity
		FROM    CWX_Profiles
		WHERE	Username = @Username
		
		IF DATEADD(minute, @UserIsOnlineTimeWindow, @LastActivity) < @Today 
		BEGIN
			UPDATE  CWX_User
			SET		SignOn = 0
			WHERE	Username = @Username
		END
		
	END
	ELSE
	BEGIN
		UPDATE  CWX_User
		SET		SignOn = @IsSignOn
		WHERE	Username = @Username
	END
END
GO

-- 2008-11-21	[Minh Dam]	Change permission descripton from 'Add/Edit CoBorrower' to 'Add/Edit Related Parties'
UPDATE CWX_Permission 
SET PermissionDescription='Add/Edit Related Parties' 
WHERE PermissionID=77
GO

-- Scripts 2.9.17:
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByRole]    Script Date: 11/24/2008 17:49:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByRole]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByRole]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByRole]    Script Date: 11/24/2008 17:49:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByRole]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get a collection of users by roll
-- History:
--	2008/11/24	[Long Nguyen]	Init version.
-- =============================================
CREATE PROCEDURE dbo.CWX_User_SelectByRole
	-- Add the parameters for the stored procedure here
	@RoleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT  CWX_User.*, CWX_Profiles.*
	FROM    CWX_User LEFT OUTER JOIN
				CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE
			(CWX_User.RoleID = @RoleID)
			AND (ISNULL(CWX_User.UserStatus, '''') <> ''R'')
END
' 
END
GO

-- Scripts 2.9.19:

/****** Object:  UserDefinedFunction [dbo].[CWX_FnSplitString]    Script Date: 11/27/2008 10:25:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_FnSplitString]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CWX_FnSplitString]
GO
/****** Object:  UserDefinedFunction [dbo].[CWX_FnSplitString]    Script Date: 11/27/2008 10:25:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_FnSplitString]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Binh Truong
-- Create date: March 25th, 2008
-- Description:	
-- =============================================
CREATE FUNCTION [dbo].[CWX_FnSplitString]
(
	@Text TEXT,
	@Delimiter char(1) = '',''
)
RETURNS @table_variable TABLE 
		(
			ID BIGINT IDENTITY(1,1), 
			SplitedText VARCHAR(8000)
		)
AS
	BEGIN
		DECLARE @SplitedText VARCHAR(8000)
		DECLARE @Size BIGINT
		DECLARE @Start BIGINT
		SET @Size = 1
		SET @Start = 1

		WHILE (@Start < DATALENGTH(@Text) + 1) 
		BEGIN
			SET @Size = CHARINDEX(@Delimiter, SUBSTRING(@Text, @Start, DATALENGTH(@Text)), 1)
			IF @Size = 0 
				SET @Size = DATALENGTH(@Text) - @Start + 1
				
			SET @SplitedText = SUBSTRING(SUBSTRING(@Text, @Start, DATALENGTH(@Text)), 1, @Size)
			SET @SplitedText = REPLACE(@SplitedText,@Delimiter,'''')
			INSERT INTO @table_variable(SplitedText) VALUES(@SplitedText)
			SET @Start = @Start + @Size
		END
	RETURN 
	END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_AssignCMS]    Script Date: 11/25/2008 16:52:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_AssignCMS]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProfileData_AssignCMS]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProfileData_AssignCMS]    Script Date: 11/25/2008 16:52:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProfileData_AssignCMS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Long Nguyen
-- Create date: 2008-11-25
-- Description:	Assign CMS for a collection of users
-- =============================================
CREATE PROCEDURE dbo.CWX_ProfileData_AssignCMS
	-- Add the parameters for the stored procedure here
	@UserIDs varchar(8000),
	@CmsID varchar(30)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    IF @UserIDs IS NOT NULL AND @UserIDs <> ''''
	BEGIN
		DECLARE @TranStarted bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE UserIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS UserID
		FROM CWX_FnSplitString(@UserIDs, ''|'')

		OPEN UserIDsCrsr
		DECLARE @UserID int
		FETCH NEXT FROM UserIDsCrsr INTO @UserID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			UPDATE CWX_ProfileData
			SET CmsID = @CmsID
			WHERE
				ProfileDataID = (
									SELECT TOP 1 ProfileDataID
									FROM CWX_ProfileData pd
									INNER JOIN CWX_Profiles p ON p.ProfileID=pd.ProfileID
									INNER JOIN CWX_User u ON u.UserName=p.UserName
									WHERE u.UserID=@UserID
								)

			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM UserIDsCrsr INTO @UserID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE UserIDsCrsr
		DEALLOCATE UserIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END
' 
END
GO

-- Script closed.