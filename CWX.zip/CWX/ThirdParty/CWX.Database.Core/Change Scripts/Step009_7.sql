-- Script is applied on version 1.9.17, 1.9.18
/****** Object:  StoredProcedure [dbo].[CWX_User_UnlockAll]    Script Date: 06/17/2008 16:42:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_UnlockAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_UnlockAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_UnlockAll]    Script Date: 06/17/2008 16:42:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_UnlockAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		LongNguyen
-- Create date: Jan 31, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_UnlockAll] 
	
AS
BEGIN
	UPDATE
		CWX_User
	SET
		IsLockedOut = 0
END' 
END
GO
 
DELETE FROM CWX_Permission WHERE PermissionID=32
GO

/******  Script Closed  ******/