﻿if not exists (select * from CWX_Permission where PermissionDescription = 'View and Upload Letter')
	insert into CWX_Permission(PermissionID,PermissionDescription, GroupID) values(86, 'View and Upload Letter', 1)
go

