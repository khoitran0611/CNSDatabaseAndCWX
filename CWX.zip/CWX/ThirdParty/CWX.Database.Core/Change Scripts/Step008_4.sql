-- Script is applied on version 1.6.4 
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_User_ResetPassword]
	@UserID int,
	@NewPassword varchar(500),
	@UpdateByUserID int
AS
BEGIN
	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @OldPassword varchar(500)

	SELECT @OldPassword = Password		
	FROM CWX_User
	WHERE UserID = @UserID

	--UPDATE USER PASSWORD
	UPDATE CWX_User
	SET
		Password = @NewPassword,
		ChangePwdDate = NULL,
		ChangePwdCount = 0
	WHERE
		UserID = @UserID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--INSERT INTO PASSWORD HISTORY
	INSERT INTO CWX_PasswordHistory
	VALUES
	(
		@UserID,
		@OldPassword,
		@NewPassword,
		GETDATE(),
		@UpdateByUserID
	)

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_PasswordPolicy_ValidatePreviousPasswordsAreSame]
	@UserID int,
	@NewEncriptedPassword varchar(500),
	@Times int --how many times to get from PasswordHistory 	
AS
BEGIN	
	IF EXISTS (SELECT Password FROM CWX_User WHERE UserID = @UserID AND Password = @NewEncriptedPassword)		
	 	SELECT Result = 1 --SET @Result = 1	
	ELSE
	BEGIN--0
		CREATE TABLE #TempPwdHistory
		(
			OldPassword varchar(500)
		)

		DECLARE @sql nvarchar(2000)
		SET @sql = 'INSERT INTO #TempPwdHistory SELECT TOP ' + CAST(@Times as varchar(10)) + ' OldPassword ' 
		SET @sql = @sql + ' FROM CWX_PasswordHistory WHERE UserID = ' + CAST(@UserID as varchar(10)) + ' ORDER BY ChangeDate DESC'		
		
		PRINT @sql
		EXEC(@sql)

		DECLARE @OldPassword varchar(16)
		DECLARE OldPasswordCursor CURSOR FOR
		SELECT OldPassword FROM #TempPwdHistory
		OPEN OldPasswordCursor
		FETCH NEXT FROM OldPasswordCursor INTO @OldPassword
		
		DECLARE @Result int
		SET @Result = 0
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF (@NewEncriptedPassword = @OldPassword)
			Begin
				Print @Result
				SET	@Result = 1
				BREAK
			End
			FETCH NEXT FROM OldPasswordCursor INTO @OldPassword
		END		
		SELECT Result = @Result
		CLOSE OldPasswordCursor;
		DEALLOCATE OldPasswordCursor;
		DROP TABLE #TempPwdHistory
	END--0
	
END
GO

/******  Script Closed  ******/