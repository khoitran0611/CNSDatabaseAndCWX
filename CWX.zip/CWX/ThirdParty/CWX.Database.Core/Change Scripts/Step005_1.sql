ALTER TABLE CWX_Role DROP COLUMN RolePermissions
GO

ALTER TABLE CWX_Role ADD Status char(1) NULL CONSTRAINT RoleStatusDefault DEFAULT 'A' WITH VALUES
GO

/****** Object:  Table [dbo].[CWX_RolePermission]    Script Date: 02/27/2008 11:25:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CWX_RolePermission](
	[RoleID] [int] NOT NULL,
	[PermissionID] [int] NOT NULL,
 CONSTRAINT [PK_CWX_RolePermission] PRIMARY KEY CLUSTERED 
(
	[RoleID] ASC,
	[PermissionID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_GetList]    Script Date: 02/27/2008 11:27:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Role_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_MoveDown]    Script Date: 02/27/2008 11:27:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_MoveDown]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Role_MoveDown]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_MoveUp]    Script Date: 02/27/2008 11:27:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Role_MoveUp]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Role_MoveUp]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RolePermission_SelectAvailPermissions]    Script Date: 02/27/2008 11:27:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RolePermission_SelectAvailPermissions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RolePermission_SelectAvailPermissions]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RolePermission_SelectAvailPermissionsByGroup]    Script Date: 02/27/2008 11:27:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RolePermission_SelectAvailPermissionsByGroup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RolePermission_SelectAvailPermissionsByGroup]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RolePermission_SelectGrantedPermissions]    Script Date: 02/27/2008 11:27:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RolePermission_SelectGrantedPermissions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RolePermission_SelectGrantedPermissions]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RolePermission_SelectGrantedPermissionsByGroup]    Script Date: 02/27/2008 11:27:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RolePermission_SelectGrantedPermissionsByGroup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RolePermission_SelectGrantedPermissionsByGroup]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_GetList]    Script Date: 02/27/2008 11:28:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 25, 2008
-- Description:	Get role paging list
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Role_GetList] 
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SELECT
		ROW_NUMBER() OVER (ORDER BY RoleOrder) AS RowNumber,
		RoleID,
		RoleName,
		RoleOrder
	INTO #Temp
	FROM
		CWX_Role
	WHERE
		Status = 'A'

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_MoveDown]    Script Date: 02/27/2008 11:28:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 25, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Role_MoveDown]
	-- Add the parameters for the stored procedure here
	@RoleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RoleOrder int
	SELECT @RoleOrder = RoleOrder FROM CWX_Role WHERE RoleID = @RoleID

	DECLARE @NextRoleID int
	SELECT
		@NextRoleID = RoleID
	FROM
		CWX_Role
	WHERE
		RoleOrder = (SELECT MIN(RoleOrder) FROM CWX_Role WHERE RoleOrder > @RoleOrder)
		AND Status = 'A'

	IF @NextRoleID IS NOT NULL
	BEGIN
		DECLARE @NextOrder int
		SELECT @NextOrder = RoleOrder FROM CWX_Role WHERE RoleID = @NextRoleID

		DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		UPDATE CWX_Role
		SET RoleOrder = @NextOrder
		WHERE  RoleID = @RoleID
		IF( @@ERROR <> 0)
			GOTO Cleanup

		UPDATE CWX_Role
		SET RoleOrder = @RoleOrder
		WHERE  RoleID = @NextRoleID
		IF( @@ERROR <> 0)
			GOTO Cleanup

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END

END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Role_MoveUp]    Script Date: 02/27/2008 11:28:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 25, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Role_MoveUp]
	-- Add the parameters for the stored procedure here
	@RoleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RoleOrder int
	SELECT @RoleOrder = RoleOrder FROM CWX_Role WHERE RoleID = @RoleID

	DECLARE @PreviousRoleID int
	SELECT
		@PreviousRoleID = RoleID
	FROM
		CWX_Role
	WHERE
		RoleOrder = (SELECT MAX(RoleOrder) FROM CWX_Role WHERE RoleOrder < @RoleOrder)
		AND Status = 'A'

	IF @PreviousRoleID IS NOT NULL
	BEGIN
		DECLARE @PreviousRoleOrder int
		SELECT @PreviousRoleOrder = RoleOrder FROM CWX_Role WHERE RoleID = @PreviousRoleID

		DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		UPDATE CWX_Role
		SET RoleOrder = @PreviousRoleOrder
		WHERE  RoleID = @RoleID
		IF( @@ERROR <> 0)
			GOTO Cleanup

		UPDATE CWX_Role
		SET RoleOrder = @RoleOrder
		WHERE  RoleID = @PreviousRoleID
		IF( @@ERROR <> 0)
			GOTO Cleanup

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END

END


GO
/****** Object:  StoredProcedure [dbo].[CWX_RolePermission_SelectAvailPermissions]    Script Date: 02/27/2008 11:28:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Long Nguyen
-- Create date: Feb 26th, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RolePermission_SelectAvailPermissions]
	@RoleID int
AS
BEGIN	
	SET NOCOUNT ON;
	IF(@RoleID = 0)
		SELECT [PermissionID], [GroupID] FROM CWX_Permission
		ORDER BY [GroupID], [PermissionID]
	ELSE
		SELECT [PermissionID], [GroupID] FROM CWX_Permission 
		WHERE PermissionID not in (SELECT [PermissionID] FROM [CWX_RolePermission] WHERE [RoleID] = @RoleID)
		ORDER BY [GroupID], [PermissionID]
	SET NOCOUNT OFF;
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_RolePermission_SelectAvailPermissionsByGroup]    Script Date: 02/27/2008 11:28:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Long Nguyen
-- Create date: Feb 27th, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RolePermission_SelectAvailPermissionsByGroup]
	@RoleID int, 
	@PermissionGroupID int
AS
BEGIN	
	SET NOCOUNT ON;
	IF(@RoleID = 0)
		SELECT [PermissionID], [PermissionDescription] FROM CWX_Permission WHERE GroupID = @PermissionGroupID
		ORDER BY [PermissionID]
	ELSE
		SELECT [PermissionID], [PermissionDescription] FROM CWX_Permission 
		WHERE GroupID = @PermissionGroupID 
			  AND PermissionID not in (SELECT [PermissionID] FROM [CWX_RolePermission] WHERE [RoleID] = @RoleID)
		ORDER BY [PermissionID]
	SET NOCOUNT OFF;
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_RolePermission_SelectGrantedPermissions]    Script Date: 02/27/2008 11:28:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Long Nguyen
-- Create date: Feb 27th, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RolePermission_SelectGrantedPermissions]
	@RoleID int
AS
BEGIN	
	SET NOCOUNT ON;	
		SELECT [PermissionID], [GroupID] FROM CWX_Permission 
		WHERE PermissionID in (SELECT [PermissionID] FROM [CWX_RolePermission] WHERE [RoleID] = @RoleID)
		ORDER BY [GroupID], [PermissionID]
	SET NOCOUNT OFF;
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_RolePermission_SelectGrantedPermissionsByGroup]    Script Date: 02/27/2008 11:28:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Long Nguyen
-- Create date: Feb 27th, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RolePermission_SelectGrantedPermissionsByGroup]
	@RoleID int, 
	@PermissionGroupID int
AS
BEGIN	
	SET NOCOUNT ON;	
	SELECT [PermissionID], [PermissionDescription] FROM CWX_Permission 
	WHERE GroupID = @PermissionGroupID 
		  AND PermissionID in (SELECT [PermissionID] FROM [CWX_RolePermission] WHERE [RoleID] = @RoleID)
	ORDER BY [PermissionID]
	SET NOCOUNT OFF;
END

-- ================================================================================
-- Author:		  Tuan Luong
-- Create date:   Feb 27, 2008
-- Description:	  Reset password, changed password date and changed password count
-- Database:      CWX.Core
-- ================================================================================
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CWX_User_ResetPassword]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_ResetPassword]
GO
CREATE PROCEDURE [dbo].[CWX_User_ResetPassword]
	@UserID int,
	@NewPassword varchar(250),
	@UpdateByUserID int
AS
BEGIN
	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @OldPassword varchar(250)

	SELECT @OldPassword = Password		
	FROM CWX_User
	WHERE UserID = @UserID

	--UPDATE USER PASSWORD
	UPDATE CWX_User
	SET
		Password = @NewPassword,
		ChangePwdDate = NULL,
		ChangePwdCount = 0
	WHERE
		UserID = @UserID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--INSERT INTO PASSWORD HISTORY
	INSERT INTO CWX_PasswordHistory
	VALUES
	(
		@UserID,
		@OldPassword,
		@NewPassword,
		GETDATE(),
		@UpdateByUserID
	)

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END
GO