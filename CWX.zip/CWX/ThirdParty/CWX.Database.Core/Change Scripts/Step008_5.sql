-- Script is applied on version 1.6.6 & 1.6.7 & 1.7.0

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

-- =============================================
-- Description:	Change size of following column: CWX_PasswordHistory.OldPassword, 
--				CWX_PasswordHistory.NewPassword, CWX_User.Password
-- History:
--		2008/05/24	[Binh Truong]	Init version.
-- =============================================

IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_PasswordHistory' and c.name = 'OldPassword')
BEGIN
	ALTER TABLE [dbo].[CWX_PasswordHistory]
	ALTER COLUMN  OldPassword	varchar (500) NULL
END
GO

IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_PasswordHistory' and c.name = 'NewPassword')
BEGIN
	ALTER TABLE [dbo].[CWX_PasswordHistory]
	ALTER COLUMN  NewPassword	varchar (500) NULL
END
GO

IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_User' and c.name = 'Password' )
BEGIN
	ALTER TABLE [dbo].[CWX_User]
	ALTER COLUMN [Password] varchar(500) NULL
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Insert]    Script Date: 05/24/2008 18:03:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Insert]    Script Date: 05/24/2008 18:03:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--		2008/05/22	[Binh Truong]	Remove AccountID, DebtorID field.
--									Add OriginalData field.
--		2008/05/24	[Binh Truong]	Add @ChangeField default value = NULL
-- =============================================
CREATE PROCEDURE dbo.CWX_AuditTrail_Insert 
(
	@EmployeeID INT,
	@ActionID TINYINT,
	@ChangeTable VARCHAR(50),
	@ChangeField VARCHAR(50) = NULL,
	@OriginalData NVARCHAR(MAX) = NULL,
	@ChangeData NVARCHAR(MAX) = NULL
)
AS
	INSERT INTO		CWX_AuditTrail
	                (EmployeeID, ActionID, ChangeTable, ChangeField, OriginalData, ChangeData, AuditDateTime)
	VALUES			(@EmployeeID,@ActionID,@ChangeTable,@ChangeField,@OriginalData,@ChangeData,GETUTCDATE())' 
END
GO

/******  Script Closed  ******/