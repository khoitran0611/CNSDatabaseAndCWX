-- Script is applied on version 1.6.3 
/****** Object:  StoredProcedure [dbo].[CWX_User_GetSalt_By_UserID]    Script Date: 05/22/2008 16:51:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_GetSalt_By_UserID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_GetSalt_By_UserID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_ChangePassword]    Script Date: 05/22/2008 16:51:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_ChangePassword]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_ChangePassword]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_GetSalt_By_UserID]    Script Date: 05/22/2008 16:51:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_GetSalt_By_UserID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDuong
-- Create date: May 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_GetSalt_By_UserID] 
	@UserID int
AS
BEGIN
	SELECT
		Salt
	FROM
		CWX_User
	WHERE
		UserID = @UserID
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_ChangePassword]    Script Date: 05/22/2008 16:51:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_ChangePassword]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		  LongNguyen
-- Create date:   Jan 09, 2008
-- Modified date: Feb 20, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_ChangePassword] 
	@UserID int,
	@NewPassword varchar(1000),
	@ChangePwdDate smalldatetime,
	@UpdateByUserID int
AS
BEGIN
	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @OldPassword varchar(1000)
	DECLARE @ChangePwdCount int
	DECLARE @LastChangePwdDate smalldatetime

	SELECT
		@OldPassword = Password,
		@ChangePwdCount = ISNULL(ChangePwdCount, 0),
		@LastChangePwdDate = ChangePwdDate
	FROM
		CWX_User
	WHERE
		UserID = @UserID

	--Caculate ChangePwdCount
	IF DATEDIFF(day, @LastChangePwdDate, @ChangePwdDate) = 0
		SET @ChangePwdCount = @ChangePwdCount + 1
	ELSE
		SET @ChangePwdCount = 0

	--Update User Password
	UPDATE CWX_User
	SET
		Password = @NewPassword,
		ChangePwdDate = @ChangePwdDate,
		ChangePwdCount = @ChangePwdCount
	WHERE
		UserID = @UserID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Insert into PasswordHistory
	INSERT INTO CWX_PasswordHistory
	VALUES
	(
		@UserID,
		@OldPassword,
		@NewPassword,
		@ChangePwdDate,
		@UpdateByUserID
	)

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END


' 
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_PasswordHistory')
BEGIN
	ALTER TABLE [dbo].[CWX_PasswordHistory]
	DROP COLUMN OldPassword	
END

GO
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_PasswordHistory')
BEGIN
	ALTER TABLE [dbo].[CWX_PasswordHistory]
	DROP COLUMN NewPassword	
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_PasswordHistory' and c.name = 'OldPassword')
BEGIN
	ALTER TABLE [dbo].[CWX_PasswordHistory]
	ADD  OldPassword	[varchar] (500) NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_PasswordHistory' and c.name = 'NewPassword')
BEGIN
	ALTER TABLE [dbo].[CWX_PasswordHistory]
	ADD  NewPassword	[varchar] (500) NULL
END
GO
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_User')
BEGIN
	ALTER TABLE [dbo].[CWX_User]
	DROP COLUMN Password
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_User' and c.name = 'Password' )
BEGIN
	ALTER TABLE [dbo].[CWX_User]
	ADD Password [varchar](500) NULL
END
GO



/****** Object:  Table [dbo].[CWX_AuditTableInfo]    Script Date: 05/21/2008 16:25:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTableInfo]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_AuditTableInfo]
GO
/****** Object:  Table [dbo].[CWX_AuditTableInfo]    Script Date: 05/21/2008 16:25:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTableInfo]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_AuditTableInfo](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AuditTableID] [int] NULL,
	[TableName] [varchar](50) NULL,
 CONSTRAINT [PK_CWX_AuditTableInfo] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Index [IX_CWX_AuditTableInfo]    Script Date: 05/21/2008 16:25:07 ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTableInfo]') AND name = N'IX_CWX_AuditTableInfo')
CREATE NONCLUSTERED INDEX [IX_CWX_AuditTableInfo] ON [dbo].[CWX_AuditTableInfo] 
(
	[AuditTableID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
GO

DELETE CWX_AuditTableInfo -- Clear old data

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (1, 'Account')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (2, 'AccountPromise')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (3, 'AccountMemo')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (4, 'LegalProcess')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (4, 'LegalProcessItems')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (4, 'LegalAction')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (4, 'Referrals')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (5, 'CWX_AuditTables')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (6, 'AvailableActions')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (7, 'Transactions')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (8, 'AccountStatus')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (9, 'AccountCodeMaster')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (10, 'AllocationSortMaster')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (11, 'ClientInformation')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (12, 'Collateral')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (13, 'DebtorInformation')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (14, 'EmployeeDepartment')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (14, 'Nationality_Master')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (14, 'Languages')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (15, 'Employee')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (16, 'RuleTable')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (16, 'RulesAllocUsers')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (16, 'RuleOthers')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (16, 'RuleCriteria')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (17, 'EmployeeGoals')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (18, 'DefineFees')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (19, 'InformationTable')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (20, 'BlackOutDates')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (21, 'Image')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (21, 'DefineImageType')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (22, 'PersonPhone')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (22, 'PersonAddress')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (23, 'QueueSortMaster')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (23, 'QueueSortORder')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (24, 'DefineLetters')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (24, 'ReportScheduleDate')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (24, 'ReportSchedulelog')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (24, 'ReportScheduleTable')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (25, 'RoleDefinition')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (26, 'BroadCast')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (26, 'Messages')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (27, 'CWX_CustomDefinedFields')

INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (28, 'Ticket')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (28, 'TicketDefinition')
INSERT INTO CWX_AuditTableInfo (AuditTableID, TableName) VALUES (28, 'TicketStages')
 
GO

/****** Object:  StoredProcedure [dbo].[CWX_User_Insert]   Script Date: 05/21/2008 17:30:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_Insert]    Script Date: 05/21/2008 17:30:18 ******/
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		KhoaDuong
-- Create date: May 21, 2008
-- Description:	Alter Store [CWX_User_Insert]
-- =============================================
create PROCEDURE [dbo].[CWX_User_Insert] 
	-- Add the parameters for the stored procedure here
	@UserID int,
	@UserName varchar(10),
	@Password varchar(250),
	@FullName varchar(50),
	@Email varchar(50),
	@Comment varchar(225),
	@RoleID int,
	@Salt nchar (10)
AS
BEGIN
	INSERT INTO CWX_User
	(
		UserID,
		UserName,
		Password,
		FullName,
		Email,
		Comment,
		RoleID,
		IsLockedOut,
		UserStatus,
		Salt
	)
	VALUES
	(
		@UserID,
		@UserName,
		@Password,
		@FullName,
		@Email,
		@Comment,
		@RoleID,
		0,
		'A',
		@Salt
	)
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_CanAudit]    Script Date: 05/21/2008 18:05:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CanAudit]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CanAudit]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CanAudit]    Script Date: 05/21/2008 18:05:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CanAudit]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE proc [dbo].[CWX_CanAudit]
	@tableName varchar(50)
AS
	select a.Audited from CWX_AuditTables a inner join CWX_AuditTableInfo i on a.ID = i.AuditTableID
		where i.TableName = @tableName
' 
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_AuditTrail' and c.name = 'OriginalData')
BEGIN
	ALTER TABLE CWX_AuditTrail ADD OriginalData nvarchar(max) NULL
END

GO

IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_AuditTrail' and c.name = 'DebtorID')
BEGIN
	ALTER TABLE CWX_AuditTrail 
	DROP COLUMN DebtorID
END

GO 

IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_AuditTrail' and c.name = 'AccountID')
BEGIN
	ALTER TABLE CWX_AuditTrail 
	DROP COLUMN AccountID
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Update]    Script Date: 05/22/2008 16:04:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_Update]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Search]    Script Date: 05/22/2008 16:04:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Insert]    Script Date: 05/22/2008 16:04:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Update]    Script Date: 05/22/2008 16:04:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Update]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--		2008/05/22	[Binh Truong]	Remove AccountID, DebtorID field.
--									Add OriginalData field.
-- =============================================
CREATE PROCEDURE dbo.CWX_AuditTrail_Update
(
	@AuditID INT,
	@EmployeeID INT,
	@ActionID TINYINT,
	@ChangeTable VARCHAR(50),
	@ChangeField VARCHAR(50),
	@OriginalData NVARCHAR(MAX) = NULL,
	@ChangeData NVARCHAR(MAX) = NULL	
)
AS
	UPDATE	CWX_AuditTrail
	SET     
			EmployeeID = @EmployeeID, 
			ActionID = @ActionID, 
			ChangeTable = @ChangeTable, 
			ChangeField = @ChangeField, 
			OriginalData = @OriginalData, 
			ChangeData = @ChangeData, 
			AuditDateTime = GETUTCDATE()
	WHERE	
			AuditID = @AuditID' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Search]    Script Date: 05/22/2008 16:04:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Search]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--		2008/05/22	[Binh Truong]	Remove AccountID, DebtorID field.
-- =============================================
CREATE PROCEDURE dbo.CWX_AuditTrail_Search
(
	@TrailID INT = NULL,
	@EmployeeID INT = NULL,
	@ActionID TINYINT = NULL,
	@ChangeTable VARCHAR(50) = NULL,
	@ChangeField VARCHAR(50) = NULL,
	@AuditFrom DATETIME = NULL,
	@AuditTo DATETIME = NULL,
	@PageSize int = 10,
	@PageIndex int = 0
	
)
AS
DECLARE @StartRow INT
DECLARE @EndRow INT	
DECLARE @SQL 	NVARCHAR(MAX)
DECLARE @Order 	NVARCHAR(1000)
DECLARE @parms 	NVARCHAR(1000)
DECLARE @TotalRow INT

SET @StartRow = @PageIndex * @PageSize + 1
SET @EndRow = (@PageIndex + 1) * @PageSize

IF @ChangeTable = ''''
	SET @ChangeTable = NULL
IF @ChangeField = ''''
	SET @ChangeField = NULL

SET @Order = ''ORDER BY AuditID DESC''

SET @SQL = N''
	SELECT	*, ROW_NUMBER() OVER (''+@Order+'') AS RowNumber 
	INTO	#AuditTrailTemp
	FROM	CWX_AuditTrail
	WHERE	1=1 
	''
IF @TrailID IS NOT NULL
	SET @SQL = @SQL + ''AND AuditID = @TrailID ''
IF @EmployeeID IS NOT NULL
	SET @SQL = @SQL + ''AND EmployeeID = @EmployeeID ''
IF @ActionID IS NOT NULL
	SET @SQL = @SQL + ''AND ActionID = @ActionID ''
IF @ChangeField IS NOT NULL
	SET @SQL = @SQL + ''AND ChangeField LIKE ''''%'''' + @ChangeField + ''''%'''' ''
IF (@AuditFrom IS NOT NULL AND @AuditTo IS NOT NULL)
	SET @SQL = @SQL + ''AND AuditDateTime BETWEEN @AuditFrom AND @AuditTo ''

SET @sql = @sql + N''SELECT @TotalRow = @@ROWCOUNT 
					SELECT * FROM #AuditTrailTemp 
					WHERE RowNumber BETWEEN @StartRow AND @EndRow 
					DROP TABLE #AuditTrailTemp 
					''

SET @parms = ''
	@TrailID INT = NULL,
	@EmployeeID INT = NULL,
	@ActionID TINYINT = NULL,
	@ChangeField VARCHAR(50) = NULL,
	@AuditFrom DATETIME = NULL,
	@AuditTo DATETIME = NULL,
	@StartRow INT,
	@EndRow INT,
	@TotalRow INT OUTPUT
	''

EXECUTE sp_executesql @sql, @parms, 
			@TrailID,
			@EmployeeID,
			@ActionID,
			@ChangeField,
			@AuditFrom,
			@AuditTo,
			@StartRow,
			@EndRow,
			@TotalRow OUTPUT

IF @TotalRow IS NULL
	RETURN 0
ELSE
	RETURN @TotalRow' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Insert]    Script Date: 05/22/2008 16:04:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--		2008/05/22	[Binh Truong]	Remove AccountID, DebtorID field.
--									Add OriginalData field.
-- =============================================
CREATE PROCEDURE dbo.CWX_AuditTrail_Insert 
(
	@EmployeeID INT,
	@ActionID TINYINT,
	@ChangeTable VARCHAR(50),
	@ChangeField VARCHAR(50),
	@OriginalData NVARCHAR(MAX) = NULL,
	@ChangeData NVARCHAR(MAX) = NULL
)
AS
	INSERT INTO		CWX_AuditTrail
	                (EmployeeID, ActionID, ChangeTable, ChangeField, OriginalData, ChangeData, AuditDateTime)
	VALUES			(@EmployeeID,@ActionID,@ChangeTable,@ChangeField,@OriginalData,@ChangeData,GETUTCDATE())' 
END
GO


/******  Script Closed  ******/