﻿-- Thuy Nguyen added on 06-March-2009 --

if not exists (select * from CWX_Permission where PermissionDescription = 'Access to Debt and Debtor Management')
	insert into CWX_Permission(PermissionID,PermissionDescription, GroupID) values(79, 'Access to Debt and Debtor Management', 1)
go

-- End of Thuy Nguyen added on 06-March-2009 --