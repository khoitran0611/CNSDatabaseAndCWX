-- Script is applied on version 2.2.21, 2.2.22

/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Insert]    Script Date: 07/30/2008 10:25:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Insert]    Script Date: 07/30/2008 10:25:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--		2008/05/22	[Binh Truong]	Remove AccountID, DebtorID field.
--									Add OriginalData field.
--		2008/05/24	[Binh Truong]	Add @ChangeField default value = NULL
--		2008/07/30	[Binh Truong]	Add @DBConnectionName parameter.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AuditTrail_Insert] 
(
	@EmployeeID INT,
	@ActionID TINYINT,
	@DBConnectionName VARCHAR(100),
	@ChangeTable VARCHAR(50),
	@RowID VARCHAR(20),
	@ChangeField VARCHAR(50) = NULL,
	@OriginalData NVARCHAR(MAX) = NULL,
	@ChangeData NVARCHAR(MAX) = NULL
)
AS
	INSERT INTO		CWX_AuditTrail
	                (EmployeeID, ActionID, DBConnectionName, ChangeTable, RowID, ChangeField, OriginalData, ChangeData, AuditDateTime)
	VALUES			(@EmployeeID,@ActionID,@DBConnectionName,@ChangeTable,@RowID,@ChangeField,@OriginalData,@ChangeData,GETUTCDATE())' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Update]    Script Date: 07/30/2008 10:28:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTable_Update]
GO

/****** Object:  StoredProcedure [dbo].[CWX_AuditTrail_Delete]    Script Date: 07/30/2008 10:31:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTrail_Delete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTrail_Delete]
GO

/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Search]    Script Date: 07/30/2008 11:43:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTable_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Search]    Script Date: 07/30/2008 11:45:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_AuditTable_Search]
(
	@ID INT = NULL,
	@ClassName NVARCHAR(100) = NULL,
	@Audited INT = NULL,
	@PageSize INT = 10,
	@PageIndex INT = 0
	
)
AS
	DECLARE @StartRow INT
	DECLARE @EndRow INT	
	DECLARE @SQL 	NVARCHAR(MAX)
	DECLARE @Order 	NVARCHAR(1000)
	DECLARE @parms 	NVARCHAR(1000)
	DECLARE @TotalRow INT

	SET @StartRow = @PageIndex * @PageSize + 1
	SET @EndRow = (@PageIndex + 1) * @PageSize

	IF @Audited = 2
		SET @Audited = NULL

	SET @Order = 'ORDER BY ClassName'

	SET @SQL = N'
		SELECT	*, ROW_NUMBER() OVER ('+@Order+') AS RowNumber 
		INTO	#AuditTablesTemp
		FROM	CWX_AuditTables
		WHERE	1=1 
		'
	IF @ID IS NOT NULL
		SET @SQL = @SQL + 'AND [ID] = @ID '
	IF @ClassName IS NOT NULL
		SET @SQL = @SQL + 'AND ClassName LIKE ''%''+@ClassName+''%'' '
	IF @Audited IS NOT NULL
		SET @SQL = @SQL + 'AND Audited = @Audited '	

	SET @sql = @sql + N'SELECT @TotalRow = @@ROWCOUNT
						SELECT * FROM #AuditTablesTemp 
						WHERE RowNumber BETWEEN @StartRow AND @EndRow 
						DROP TABLE #AuditTablesTemp 
						 '

	SET @parms = '
		@ID INT = NULL,
		@ClassName NVARCHAR(100) = NULL,
		@Audited INT = NULL,
		@StartRow INT = 10,
		@EndRow INT = 0,
		@TotalRow INT OUTPUT
		'

	EXECUTE sp_executesql @sql, @parms, 
				@ID,
				@ClassName,
				@Audited,
				@StartRow,
				@EndRow,
				@TotalRow OUTPUT
	IF @TotalRow IS NULL
		RETURN 0
	ELSE
		RETURN @TotalRow
GO

UPDATE CWX_AuditTables SET Description = 'Reports and Letters details (Document Definitions and Report Schedules)' WHERE ID=24
GO

UPDATE CWX_AuditTables SET ClassName = 'Audit Options' WHERE ID=5
GO

-- Scripts 2.2.22:

/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Search]    Script Date: 07/30/2008 18:10:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTable_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Search]    Script Date: 07/30/2008 18:10:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Search]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.CWX_AuditTable_Search
(
	@ID INT = NULL,
	@ClassName NVARCHAR(100) = NULL,
	@Audited INT = NULL,
	@PageSize INT = 10,
	@PageIndex INT = 0
	
)
AS
DECLARE @StartRow INT
DECLARE @EndRow INT	
DECLARE @SQL 	NVARCHAR(MAX)
DECLARE @Order 	NVARCHAR(1000)
DECLARE @parms 	NVARCHAR(1000)
DECLARE @TotalRow INT

SET @StartRow = @PageIndex * @PageSize + 1
SET @EndRow = (@PageIndex + 1) * @PageSize

IF @Audited = 2
	SET @Audited = NULL

SET @Order = ''ORDER BY ClassName''

SET @SQL = N''
	SELECT	*, ROW_NUMBER() OVER (''+@Order+'') AS RowNumber 
	INTO	#AuditTablesTemp
	FROM	CWX_AuditTables
	WHERE	1=1 
	''
IF @ID IS NOT NULL
	SET @SQL = @SQL + ''AND [ID] = @ID ''
IF @ClassName IS NOT NULL
	SET @SQL = @SQL + ''AND ClassName LIKE ''''%''''+@ClassName+''''%'''' ''
IF @Audited IS NOT NULL
	SET @SQL = @SQL + ''AND Audited = @Audited ''	

SET @sql = @sql + N''SELECT @TotalRow = @@ROWCOUNT
					SELECT * FROM #AuditTablesTemp 
					WHERE RowNumber BETWEEN @StartRow AND @EndRow 
					DROP TABLE #AuditTablesTemp 
					 ''

SET @parms = ''
	@ID INT = NULL,
	@ClassName NVARCHAR(100) = NULL,
	@Audited INT = NULL,
	@StartRow INT = 10,
	@EndRow INT = 0,
	@TotalRow INT OUTPUT
	''

EXECUTE sp_executesql @sql, @parms, 
			@ID,
			@ClassName,
			@Audited,
			@StartRow,
			@EndRow,
			@TotalRow OUTPUT
IF @TotalRow IS NULL
	RETURN 0
ELSE
	RETURN @TotalRow' 
END
GO

/******  Script Closed. Go next: Step013_1  ******/