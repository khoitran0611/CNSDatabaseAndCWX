-- Script is applied on version 2.3.2, 2.3.4, 2.3.7, 2.3.8

-- Scripts 2.3.2:

UPDATE CWX_AuditTables SET Description = 'Legal Process Details' WHERE ID=4
GO 

-- Scripts 2.3.4:

/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Update]    Script Date: 08/04/2008 10:59:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTable_Update]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Update]    Script Date: 08/04/2008 10:59:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Update]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.CWX_AuditTable_Update
(
	@ID INT,
	@ClassName VARCHAR(50),
	@Description NVARCHAR(100),
	@Audited BIT
)
AS
	UPDATE    CWX_AuditTables
	SET              ClassName = @ClassName, Description = @Description, Audited = @Audited
	WHERE     (ID = @ID)' 
END
GO

-- Scripts 2.3.7:
ALTER TABLE dbo.CWX_User ADD CONSTRAINT
PK_CWX_User PRIMARY KEY CLUSTERED 
(
	UserID
) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


/****** Object:  StoredProcedure [dbo].[CWX_Profiles_Insert]    Script Date: 08/07/2008 17:05:49 Added by Thuy Nguyen ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Profiles_Insert]
(
	@profileID int output,
	@userName nvarchar(50),
	@applicationName nvarchar(50),
	@isAnonymous bit
)
AS
BEGIN

	SET NOCOUNT ON;

	Declare @activity datetime
	Set @activity=GetUTCDate()

	/* Make sure user name is unique in CWX_Profiles */
	If Exists (Select ProfileID from CWX_Profiles where UserName = @userName)
		Delete from CWX_Profiles where UserName = @userName
	/****/

	/*Insert a new profile for a user.*/
	Insert CWX_Profiles
	(
	UserName,
	ApplicationName,
	IsAnonymous,
	LastActivity,
	LastUpdated
	)
	Values
	(
	@userName,
	@applicationName,
	@isAnonymous,
	@activity,
	@activity
	)

	Set @profileID=Scope_Identity()

END

-- Scripts 2.3.8:

--Script to truncate data in DBCore
truncate table dbo.CWX_AuditTrail
truncate table dbo.CWX_LoginAttemptsLog
truncate table dbo.CWX_LoginLog
truncate table dbo.CWX_PasswordHistory
truncate table dbo.CWX_ProfileData

delete dbo.CWX_Profiles where ProfileID not in (1,2)
delete dbo.CWX_User where UserID not in (1001,1002)
delete dbo.CWX_UserPermission where UserID not in (1001,1002)

/******  Script Closed. ******/