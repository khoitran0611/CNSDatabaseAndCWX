-- Script is applied on version 1.9.12 

update CWX_Permission set PermissionDescription='Access Employee Setup' where PermissionID=2
update CWX_Permission set PermissionDescription='Access Application Setup' where PermissionID=3
update CWX_Permission set PermissionDescription='Access Employee Activity Report' where PermissionID=7
delete from CWX_Permission where PermissionID in(8,9,10)
GO
delete from CWX_Permission where PermissionID in(13,14,15)
GO

/****** Object:  StoredProcedure [dbo].[CWX_User_GetSalt]    Script Date: 06/14/2008 12:50:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_GetSalt]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_GetSalt]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_GetSalt]    Script Date: 06/14/2008 12:50:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		KhoaDuong
-- Create date: May 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_GetSalt] 
	@UserName varchar(10)
AS
BEGIN
	SELECT
		Salt
	FROM
		CWX_User
	WHERE
		UserName = @UserName
		AND UserStatus <> 'R'
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_User_GetSalt_By_UserID]    Script Date: 06/14/2008 12:51:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_GetSalt_By_UserID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_GetSalt_By_UserID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_GetSalt_By_UserID]    Script Date: 06/14/2008 12:51:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		KhoaDuong
-- Create date: May 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_GetSalt_By_UserID] 
	@UserID int
AS
BEGIN
	SELECT
		Salt
	FROM
		CWX_User
	WHERE
		UserID = @UserID
		AND UserStatus <> 'R'
END
GO

/******  Script Closed. Go next: Step009_5  ******/