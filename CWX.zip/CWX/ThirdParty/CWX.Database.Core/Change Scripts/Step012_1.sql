-- Script is applied on version 2.2.1:

/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 07/14/2008 15:59:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Profiles_UpdateLastActivity]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_UpdateUserOnlineStatus]    Script Date: 07/14/2008 15:59:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_UpdateUserOnlineStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_UpdateUserOnlineStatus]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 07/14/2008 15:59:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Profiles_UpdateLastActivity]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
(
	@UserName nvarchar(50)
)
AS
BEGIN

	SET NOCOUNT ON;
	UPDATE CWX_Profiles 
	SET LastActivity = GetUTCDate() 
	WHERE UserName = @Username

END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_User_UpdateUserOnlineStatus]    Script Date: 07/14/2008 15:59:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_UpdateUserOnlineStatus]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-------------------------------------
-- Description: Update user online status.
-- History:
--	2008/07/11	[Binh Truong]	Init version.
-------------------------------------
CREATE PROCEDURE dbo.CWX_User_UpdateUserOnlineStatus 
(
	@Username varchar(50),
	@UserIsOnlineTimeWindow int = 0,
	@IsForceSetStatus int = 0,
	@IsSignOn int = 0
)
AS
	SET NOCOUNT ON
	IF @IsForceSetStatus = 0
	BEGIN
		DECLARE @LastActivity datetime
		
		SELECT	@LastActivity = LastActivity
		FROM    CWX_Profiles
		WHERE	Username = @Username
		
		IF DATEADD(minute, @UserIsOnlineTimeWindow, @LastActivity) < GetUTCDate() 
		BEGIN
			UPDATE  CWX_User
			SET		SignOn = 0
			WHERE	Username = @Username
		END
		
	END
	ELSE
	BEGIN
		UPDATE  CWX_User
		SET		SignOn = @IsSignOn
		WHERE	Username = @Username
	END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserID]    Script Date: 07/14/2008 17:23:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByUserID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserNameAndPassword]    Script Date: 07/14/2008 17:23:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserNameAndPassword]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByUserNameAndPassword]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserName]    Script Date: 07/14/2008 17:23:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByUserName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserID]    Script Date: 07/14/2008 17:23:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/08	[Long Nguyen]	Init version.
--	2008/07/14	[Binh Truong]	Add Profiles table fields.
-- =============================================
CREATE PROCEDURE dbo.CWX_User_SelectByUserID 
	-- Add the parameters for the stored procedure here
	@UserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT  CWX_User.*, CWX_Profiles.*
	FROM    CWX_User INNER JOIN
				CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE
			(CWX_User.UserID = @UserID)
			AND (ISNULL(CWX_User.UserStatus, '''') <> ''R'')
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserNameAndPassword]    Script Date: 07/14/2008 17:23:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserNameAndPassword]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/08	[Long Nguyen]	Init version.
--	2008/07/14	[Binh Truong]	Add Profiles table fields.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_SelectByUserNameAndPassword] 
	-- Add the parameters for the stored procedure here
	@UserName varchar(10),
	@Password varchar(250)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT     CWX_User.*, CWX_Profiles.*
	FROM         CWX_User INNER JOIN
	                      CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE     (CWX_User.UserName = @UserName) AND (CWX_User.Password = @Password) AND (ISNULL(CWX_User.UserStatus, '''') <> ''R'')
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByUserName]    Script Date: 07/14/2008 17:23:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByUserName]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/08	[Long Nguyen]	Init version.
--	2008/07/14	[Binh Truong]	Add Profiles table fields.
-- =============================================
CREATE PROCEDURE dbo.CWX_User_SelectByUserName 
	-- Add the parameters for the stored procedure here
	@UserName varchar(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT  CWX_User.*, CWX_Profiles.*
	FROM    CWX_User INNER JOIN
	            CWX_Profiles ON CWX_User.UserName = CWX_Profiles.UserName
	WHERE
			(CWX_User.UserName = @UserName)
			AND (ISNULL(UserStatus, '''') <> ''R'')
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 07/15/2008 10:01:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Profiles_UpdateLastActivity]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Profiles_UpdateLastActivity]    Script Date: 07/15/2008 10:01:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Profiles_UpdateLastActivity]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'---------------------------------------------------
-- Description: Update LastActivity and SignOn status of specific user.
-- History:
--	2008/07/14	[Binh Truong]	Init version
---------------------------------------------------
CREATE PROCEDURE [dbo].[CWX_Profiles_UpdateLastActivity]
(
	@UserName nvarchar(50),
	@ApplicationName nvarchar(50)
)
AS
BEGIN
	SET NOCOUNT ON;
	
	UPDATE	CWX_Profiles 
	SET		LastActivity = GetUTCDate()
	WHERE	UserName = @Username AND
			ApplicationName = @ApplicationName
			
	UPDATE		CWX_User
	SET			SignOn = 1
	WHERE		UserName = @Username
END
' 
END
GO

/******  Script Closed  ******/