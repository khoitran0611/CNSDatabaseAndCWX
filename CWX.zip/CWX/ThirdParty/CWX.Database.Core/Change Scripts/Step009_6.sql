-- Script is applied on version 1.9.16

/****** Object:  StoredProcedure [dbo].[CWX_NeedChangePassword]    Script Date: 06/17/2008 13:32:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Check whether user is not in use X days after first creation or password reset.
-- Parameters:
--		@UserName: current logged in user
--		@AvailableDays: X days allowed
-- History:
--		2008/06/13	[Thuy Nguyen]	Init version.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_NeedChangePassword] 	
	@UserName varchar(10),
	@AvailableDays int

AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @Result int
		IF EXISTS (SELECT * FROM CWX_User 
					WHERE ((ChangePwdDate IS NULL AND (GETDATE() - CreatedDate) > @AvailableDays)
						OR (ChangePwdDate IS NOT NULL AND (GETDATE() - ChangePwdDate) > @AvailableDays))
						AND UserName = @UserName)
		SET @Result= 1
	ELSE
		SET @Result = 0	

	SELECT @Result
END
/******  Script Closed. Go next: Step009_7  ******/