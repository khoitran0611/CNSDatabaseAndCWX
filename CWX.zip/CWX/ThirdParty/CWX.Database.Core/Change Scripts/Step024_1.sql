﻿
-- Script is applied on version 3.7.3:

PRINT 'Start of Core Scripts 3.7.3 '
GO

/****** Object:  Index [IDX_WorkflowProcess_ProcessID]    Script Date: 06/26/2009 17:03:04 ******/
CREATE NONCLUSTERED INDEX [IDX_WorkflowProcess_ProcessID] ON [dbo].[CWX_WorkflowProcess] 
(
	[ProcessID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

GO
/****** Object:  Index [IDX_WorkflowProcess_RequestID]    Script Date: 06/26/2009 17:03:10 ******/
CREATE NONCLUSTERED INDEX [IDX_WorkflowProcess_RequestID] ON [dbo].[CWX_WorkflowProcess] 
(
	[RequestID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY] 
GO

PRINT 'Completed execution of Core Scripts 3.7.3 '
GO