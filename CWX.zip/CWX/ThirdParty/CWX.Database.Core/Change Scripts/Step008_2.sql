-- Script is applied on version 1.6.2 
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_User' and c.name = 'Salt')
BEGIN
	ALTER TABLE [dbo].[CWX_User]
	ADD Salt [nchar](10) NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_User')
BEGIN
	ALTER TABLE [dbo].[CWX_User]
	DROP COLUMN Password
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_User' and c.name = 'Password' )
BEGIN
	ALTER TABLE [dbo].[CWX_User]
	ADD Password [varchar](1000) NULL
END
GO
Update CWX_User  Set Password= 'nnBeIq6XVqYvuAWROR5LXieYxHk=' , Salt = '1234'
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_GetSalt]    Script Date: 05/21/2008 11:04:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_GetSalt] ') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_GetSalt] 
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_GetSalt]     Script Date: 05/21/2008 11:04:18 ******/
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		KhoaDuong
-- Create date: May 21, 2008
-- Description:	Get Salt by User name
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_GetSalt] 
	@UserName varchar(10)
AS
BEGIN
	SELECT
		Salt
	FROM
		CWX_User
	WHERE
		UserName = @UserName
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_GetSalt_By_UserID]   Script Date: 05/21/2008 11:04:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_GetSalt_By_UserID] ') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_GetSalt_By_UserID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_GetSalt_By_UserID]     Script Date: 05/21/2008 11:04:18 ******/
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		KhoaDuong
-- Create date: May 21, 2008
-- Description:	Get Salt by User name
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_GetSalt_By_UserID]
	@UserID int
AS
BEGIN
	SELECT
		Salt
	FROM
		CWX_User
	WHERE
		UserID = @UserID
END
GO

/******  Script Closed  ******/