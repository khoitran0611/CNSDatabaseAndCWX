-- Script is applied on version 1.9.10

INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (64, 'Access Global Settings', 3)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (65, 'Access Password Settings', 3)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (66, 'Access Business Rules Manager', 3)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (67, 'Execute Rules Assignments', 3)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (68, 'Configure Pool', 3)
INSERT INTO CWX_Permission(PermissionID, PermissionDescription, GroupID) VALUES (69, 'Process Print and Post Letters', 3)
GO

/****** Object:  [dbo].[CWX_User]    Script Date: 06/12/2008 13:36:21 ******/

IF NOT EXISTS (SELECT * FROM dbo.syscolumns WHERE name='CreatedDate' and id = (SELECT id FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[CWX_User]') and OBJECTPROPERTY(id, N'IsUserTable') = 1))
ALTER TABLE CWX_User ADD CreatedDate DateTime
GO

/****** Object:  StoredProcedure [dbo].[CWX_User_Insert]    Script Date: 06/12/2008 11:42:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_User_Insert] 
	-- Add the parameters for the stored procedure here
	@UserID int,
	@UserName varchar(10),
	@Password varchar(250),
	@FullName varchar(50),
	@Email varchar(50),
	@Comment varchar(225),
	@RoleID int,
	@Salt nchar (10),
	@CreatedDate datetime
AS
BEGIN
	INSERT INTO CWX_User
	(
		UserID,
		UserName,
		Password,
		FullName,
		Email,
		Comment,
		RoleID,
		IsLockedOut,
		UserStatus,
		Salt,
		CreatedDate
	)
	VALUES
	(
		@UserID,
		@UserName,
		@Password,
		@FullName,
		@Email,
		@Comment,
		@RoleID,
		0,
		'A',
		@Salt,
		@CreatedDate
	)
END

/******  Script Closed. Go next: Step009_3  ******/