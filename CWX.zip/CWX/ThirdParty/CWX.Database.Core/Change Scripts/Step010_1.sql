-- Script is applied on version 2.0.2
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByPermission]    Script Date: 06/25/2008 14:02:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByPermission]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByPermission]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByPermission]    Script Date: 06/25/2008 14:02:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Binh Truong
-- Create date: Mar 21th, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_User_SelectByPermission] 
(
	@PermissionID int
)
AS
BEGIN
	SELECT     CWX_User.UserID, CWX_User.FullName
	FROM         CWX_User INNER JOIN
						  CWX_UserPermission ON CWX_User.UserID = CWX_UserPermission.UserID
	WHERE     (CWX_UserPermission.PermissionID = @PermissionID) AND (CWX_User.UserStatus = 'A')
	ORDER BY CWX_User.FullName
END
GO
/******  Script Closed  ******/