﻿-- Script is applied on version 3.6.8:

PRINT 'Start of Scripts 3.6.8'
GO

--make sure the CWX_DBVersion table exists
IF(NOT EXISTS (SELECT (1) from dbo.sysobjects 
  WHERE id = object_id(N'[dbo].[CWX_DBVersion]') AND 
  OBJECTPROPERTY(id, N'IsUserTable') = 1))
BEGIN
 print N'Building the foundation ''CWX_DBVersion'' Table'

	CREATE TABLE CWX_DBVersion (
	[DBVersionID] int NOT NULL ,
	[Description] varchar (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ExecutionDate] datetime NOT NULL
	)
	
	INSERT INTO CWX_DBVersion values (100,'Build the CWX_DBVersion Table', getDate())

END
GO

IF(Select Count(*) from CWX_PasswordPolicy Where PasswordPolicyName='Before password expiry warning')=0
	INSERT INTO CWX_PasswordPolicy values ('Before password expiry warning', 5, 12)

GO

PRINT 'Completed execution of Scripts 3.6.8'
GO