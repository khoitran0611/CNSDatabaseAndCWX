-- Script is applied on version 1.2 build 3

/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByPermission]    Script Date: 03/21/2008 09:41:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByPermission]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_User_SelectByPermission]
GO
/****** Object:  StoredProcedure [dbo].[CWX_User_SelectByPermission]    Script Date: 03/21/2008 09:41:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_User_SelectByPermission]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Binh Truong
-- Create date: Mar 21th, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE dbo.CWX_User_SelectByPermission 
(
	@PermissionID int
)
AS
SELECT     CWX_User.UserID, CWX_User.FullName
FROM         CWX_User INNER JOIN
                  CWX_UserPermission ON CWX_User.UserID = CWX_UserPermission.UserID
WHERE     (CWX_UserPermission.PermissionID = @PermissionID)
' 
END
GO