﻿-- Thuy Nguyen added on 14-April-2009 --

if not exists (select * from CWX_Permission where PermissionDescription = 'Add New Account')
	insert into CWX_Permission(PermissionID,PermissionDescription, GroupID) values(80, 'Add New Account', 4)
go

-- End of Thuy Nguyen added on 14-April-2009 --