﻿USE [CWX_Core]
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO 

IF NOT EXISTS (SELECT 1 FROM CWX_Permission WHERE PermissionID = 83)
BEGIN
	INSERT INTO CWX_Permission (PermissionID, PermissionDescription, GroupID) VALUES (83, 'Search accounts in the user assigned clients', 4)
END

IF NOT EXISTS (SELECT 1 FROM CWX_Permission WHERE PermissionID = 84)
BEGIN
	INSERT INTO CWX_Permission (PermissionID, PermissionDescription, GroupID) VALUES (84, 'Edit/Delete transactions', 4)
END
