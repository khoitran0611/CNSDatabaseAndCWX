/*
Script By: Binh Truong
Changed store procedures relate to CWX_AuditTables & CWX_AuditTrail in Step 2
*/
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Update]    Script Date: 01/22/2008 19:59:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTable_Update]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Insert]    Script Date: 01/22/2008 19:59:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTable_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Search]    Script Date: 01/22/2008 19:59:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTable_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_SelectByClassName]    Script Date: 01/22/2008 19:59:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_SelectByClassName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTable_SelectByClassName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_SelectByID]    Script Date: 01/22/2008 19:59:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_SelectByID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AuditTable_SelectByID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Update]    Script Date: 01/22/2008 19:59:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Update]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.CWX_AuditTable_Update
(
	@ID INT,
	@ClassName VARCHAR(50),
	@Description NVARCHAR(100),
	@Audited BIT
)
AS
	UPDATE    CWX_AuditTables
	SET              ClassName = @ClassName, Description = @Description, Audited = @Audited
	WHERE     (ID = @ID)' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Insert]    Script Date: 01/22/2008 19:59:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.CWX_AuditTable_Insert 
(
	@ClassName VARCHAR(50),
	@Description NVARCHAR(100),
	@Audited BIT
)
AS
	INSERT INTO	CWX_AuditTables
	            (ClassName, Description, Audited)
	VALUES		(@ClassName,@Description,@Audited)' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_Search]    Script Date: 01/22/2008 19:59:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_Search]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.CWX_AuditTable_Search
(
	@ID INT = NULL,
	@ClassName NVARCHAR(100) = NULL,
	@Audited INT = NULL,
	@PageSize INT = 10,
	@PageIndex INT = 0
	
)
AS
DECLARE @StartRow INT
DECLARE @EndRow INT	
DECLARE @SQL 	NVARCHAR(MAX)
DECLARE @Order 	NVARCHAR(1000)
DECLARE @parms 	NVARCHAR(1000)
DECLARE @TotalRow INT

SET @StartRow = @PageIndex * @PageSize + 1
SET @EndRow = (@PageIndex + 1) * @PageSize

IF @Audited = 2
	SET @Audited = NULL

SET @Order = ''ORDER BY ID''

SET @SQL = N''
	SELECT	*, ROW_NUMBER() OVER (''+@Order+'') AS RowNumber 
	INTO	#AuditTablesTemp
	FROM	CWX_AuditTables
	WHERE	1=1 
	''
IF @ID IS NOT NULL
	SET @SQL = @SQL + ''AND [ID] = @ID ''
IF @ClassName IS NOT NULL
	SET @SQL = @SQL + ''AND ClassName LIKE ''''%''''+@ClassName+''''%'''' ''
IF @Audited IS NOT NULL
	SET @SQL = @SQL + ''AND Audited = @Audited ''	

SET @sql = @sql + N''SELECT @TotalRow = @@ROWCOUNT
					SELECT * FROM #AuditTablesTemp 
					WHERE RowNumber BETWEEN @StartRow AND @EndRow 
					DROP TABLE #AuditTablesTemp 
					 ''

SET @parms = ''
	@ID INT = NULL,
	@ClassName NVARCHAR(100) = NULL,
	@Audited INT = NULL,
	@StartRow INT = 10,
	@EndRow INT = 0,
	@TotalRow INT OUTPUT
	''

EXECUTE sp_executesql @sql, @parms, 
			@ID,
			@ClassName,
			@Audited,
			@StartRow,
			@EndRow,
			@TotalRow OUTPUT
IF @TotalRow IS NULL
	RETURN 0
ELSE
	RETURN @TotalRow' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_SelectByClassName]    Script Date: 01/22/2008 19:59:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_SelectByClassName]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'create PROCEDURE dbo.CWX_AuditTable_SelectByClassName
(
	@ClassName VARCHAR(50)
)
AS
	SELECT     *
	FROM         CWX_AuditTables
	WHERE     (ClassName = @ClassName)' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AuditTable_SelectByID]    Script Date: 01/22/2008 19:59:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AuditTable_SelectByID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'create PROCEDURE dbo.CWX_AuditTable_SelectByID
(
	@ID INT = NULL
)
AS
	SELECT     CWX_AuditTables.*
	FROM         CWX_AuditTables
	WHERE [ID] = @ID' 
END
GO
