﻿IF NOT EXISTS (SELECT 1 FROM CWX_Permission WHERE PermissionID = 85)
BEGIN
	INSERT INTO CWX_Permission (PermissionID, PermissionDescription, GroupID) VALUES (85, 'Send Email/SMS', 4)
END 

GO

IF EXISTS (SELECT * FROM CWX_Permission WHERE PermissionID = 81 AND PermissionDescription = 'Edit full details primary customer and accounts')
BEGIN
	UPDATE CWX_Permission
	SET PermissionDescription = 'Edit Full Details of Primary Debtor and Accounts'
	WHERE PermissionID = 81 AND PermissionDescription = 'Edit full details primary customer and accounts'
END	
GO