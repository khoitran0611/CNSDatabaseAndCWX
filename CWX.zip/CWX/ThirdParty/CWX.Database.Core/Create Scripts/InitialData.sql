/* Initialize Permission Group data */
INSERT INTO [CWX_PermissionGroup]
VALUES(1, N'Access Module')

INSERT INTO [CWX_PermissionGroup]
VALUES(2, N'Administrator Functions')

INSERT INTO [CWX_PermissionGroup]
VALUES(3, N'Other Functions')

/* Initialize Permission data */
INSERT INTO [CWX_Permission]
VALUES(1,N'Access Customer Management',1)

INSERT INTO [CWX_Permission]
VALUES(2,N'Access Employee Management',1)

INSERT INTO [CWX_Permission]
VALUES(3,N'Access System Setup',1)

INSERT INTO [CWX_Permission]
VALUES(4,N'Access Account Management',1)

INSERT INTO [CWX_Permission]
VALUES(5,N'Access Report Management',1)

INSERT INTO [CWX_Permission]
VALUES(6,N'Access Product Management',1)

INSERT INTO [CWX_Permission]
VALUES(7,N'Access Productivity Management',1)

INSERT INTO [CWX_Permission]
VALUES(8,N'Access System Management',1)

INSERT INTO [CWX_Permission]
VALUES(9,N'Access OA Management',1)

INSERT INTO [CWX_Permission]
VALUES(10,N'Access Transaction Management',1)

INSERT INTO [CWX_Permission]
VALUES(11,N'CWX System Administrator',2)

INSERT INTO [CWX_Permission]
VALUES(12,N'Supervisor',2)

INSERT INTO [CWX_Permission]
VALUES(13,N'Authorise Employee Management',2)

INSERT INTO [CWX_Permission]
VALUES(14,N'Authorize System Setup',2)

INSERT INTO [CWX_Permission]
VALUES(15,N'Change Status',3)

INSERT INTO [CWX_Permission]
VALUES(16,N'Change Delinquency Officer Flag',3)

INSERT INTO [CWX_Permission]
VALUES(17,N'Delete Promises Taken',3)

INSERT INTO [CWX_Permission]
VALUES(18,N'Display in Management',3)

INSERT INTO [CWX_Permission]
VALUES(19,N'Edit Legal Module',3)

INSERT INTO [CWX_Permission]
VALUES(20,N'Order Batch Letter',3)

INSERT INTO [CWX_Permission]
VALUES(21,N'Send Broadcast Message',3)

INSERT INTO [CWX_Permission]
VALUES(22,N'Print Letters',3)

INSERT INTO [CWX_Permission]
VALUES(23,N'Send Message Between Collector',3)

INSERT INTO [CWX_Permission]
VALUES(24,N'Stop Letter',3)

INSERT INTO [CWX_Permission]
VALUES(25,N'S. I. F. Bills',3)

INSERT INTO [CWX_Permission]
VALUES(26,N'Work Debtors',3)

INSERT INTO [CWX_Permission]
VALUES(27,N'Power Of Attorney',3)

INSERT INTO [CWX_Permission]
VALUES(28,N'Search All Accounts',3)

INSERT INTO [CWX_Permission]
VALUES(29,N'Allow Queue Picking',3)

INSERT INTO [CWX_Permission]
VALUES(30,N'Add New and Edit Phone Details',3)

INSERT INTO [CWX_Permission]
VALUES(31,N'Add New and Edit Address Details',3)

/* Initialize Role data */
INSERT INTO [CWX_Role]
VALUES(1,'Bucket Manager',1,null)

INSERT INTO [CWX_Role]
VALUES(2,'Supervisor',2,null)

/* Initialize User data */
INSERT INTO [CWX_User]
VALUES(1001,'Manager','(MDGA8bb','manager',0,0,0,GETDATE(),0,1,'A','binh.truong@harveynash.vn',NULL)
INSERT INTO [CWX_User]
VALUES(1002,'Supervisor','(MDGA8bb','supervisor',0,0,0,GETDATE(),0,2,'A','binhtruong@harveynash.vn',NULL)

INSERT INTO [CWX_UserPermission]
VALUES(1001,1)

INSERT INTO [CWX_UserPermission]
VALUES(1001,2)

INSERT INTO [CWX_UserPermission]
VALUES(1001,3)

INSERT INTO [CWX_UserPermission]
VALUES(1001,4)

INSERT INTO [CWX_UserPermission]
VALUES(1001,5)

INSERT INTO [CWX_UserPermission]
VALUES(1001,6)

INSERT INTO [CWX_UserPermission]
VALUES(1001,7)

INSERT INTO [CWX_UserPermission]
VALUES(1001,8)

INSERT INTO [CWX_UserPermission]
VALUES(1001,9)

INSERT INTO [CWX_UserPermission]
VALUES(1001,10)

INSERT INTO [CWX_UserPermission]
VALUES(1001,11)

INSERT INTO [CWX_UserPermission]
VALUES(1001,12)

INSERT INTO [CWX_UserPermission]
VALUES(1001,13)

INSERT INTO [CWX_UserPermission]
VALUES(1001,14)

INSERT INTO [CWX_UserPermission]
VALUES(1001,15)

INSERT INTO [CWX_UserPermission]
VALUES(1001,16)

INSERT INTO [CWX_UserPermission]
VALUES(1001,17)

INSERT INTO [CWX_UserPermission]
VALUES(1001,18)

INSERT INTO [CWX_UserPermission]
VALUES(1001,19)

INSERT INTO [CWX_UserPermission]
VALUES(1001,20)

INSERT INTO [CWX_UserPermission]
VALUES(1001,21)

INSERT INTO [CWX_UserPermission]
VALUES(1001,22)

INSERT INTO [CWX_UserPermission]
VALUES(1001,23)

INSERT INTO [CWX_UserPermission]
VALUES(1001,24)

INSERT INTO [CWX_UserPermission]
VALUES(1001,25)

INSERT INTO [CWX_UserPermission]
VALUES(1001,26)

INSERT INTO [CWX_UserPermission]
VALUES(1001,27)

INSERT INTO [CWX_UserPermission]
VALUES(1001,28)

INSERT INTO [CWX_UserPermission]
VALUES(1001,29)

INSERT INTO [CWX_UserPermission]
VALUES(1001,30)

INSERT INTO [CWX_UserPermission]
VALUES(1001,31)

INSERT INTO dbo.CWX_PasswordPolicy VALUES('Minimum password length', 6, 1)
INSERT INTO dbo.CWX_PasswordPolicy VALUES('Force at least one numeric', 0, 2)
INSERT INTO dbo.CWX_PasswordPolicy VALUES('Force at least one alphabet', 1, 3)
INSERT INTO dbo.CWX_PasswordPolicy VALUES('Force at least 4 different characters', 0, 4)
INSERT INTO dbo.CWX_PasswordPolicy VALUES('Force change of password on first logon', 1, 5)
INSERT INTO dbo.CWX_PasswordPolicy VALUES('Renew password every', 99, 6)
INSERT INTO dbo.CWX_PasswordPolicy VALUES('Lock out after failed login attempts', 6, 7)
INSERT INTO dbo.CWX_PasswordPolicy VALUES('Force change password only twice in a day', 1, 8)
INSERT INTO dbo.CWX_PasswordPolicy VALUES('Force at least one lower and one upper case alpha', 0, 9)
 
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('CWXSqlProfileProvider','Account Information',0)                                                                                                                                         
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('AgencyDefinedField','Agency Defined Fields',1)                                                                                                                                          
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('ClientInformation','Client Information',1)                                                                                                                                              
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('DebtorInformation','Debtor Information',1)                                                                                                                                              
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('Debtor;Co-owner','Debtor, Co-owner, ect. Address Information',1)                                                                                                                        
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('EmployeeRepository','Employee Information',0)                                                                                                                                          
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('AccountTransaction','Encapsulates the Account Transactions',0)                                                                                                                         
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('AllocationRule','Encapsulates the Allocation Rules',0)                                                                                                                                 
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('ProcessingRule','Encapsulates Automatic Processing Rules',0)                                                                                                                           
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('ExtractionRule','Encapsulates the Extraction Rules',0)                                                                                                                                 
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('PromiseRepository','Encapsulates the Promise Functions for Collection Works',0)                                                                                                        
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('Status','Encapsulates the Status Functions',1)                                                                                                                                         
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('SystemSetup','Encapsulates the System Setup Functions',1)                                                                                                                              
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('TransactionSetup','Encapsulates the Transaction Setup Functions',0)                                                                                                                    
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('FeeInformation','Fee Information',1)                                                                                                                                                   
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('FeeLetterInformation','Fee Letter Information',0)                                                                                                                                      
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('ScreenItem','Information Screens Items',1)                                                                                                                                             
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('LetterInformation','Letter Information',0)                                                                                                                                             
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('Note','Notes with Collection Works',0)                                                                                                                                                 
 INSERT CWX_AuditTables ( ClassName,Description,Audited )  VALUES ('AutomaticProcessingRule','Used to Create, Load, and Save the Grid in Automatic Processing Rules',1) 
 
 