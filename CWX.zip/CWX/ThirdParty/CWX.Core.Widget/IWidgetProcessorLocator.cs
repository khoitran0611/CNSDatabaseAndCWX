using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Collections.ObjectModel;

namespace CWX.Core.Widget
{
    public interface IWidgetProcessorLocator
    {
        IWidgetProcessor GetProcessor(string interfaceName);
    }
}
