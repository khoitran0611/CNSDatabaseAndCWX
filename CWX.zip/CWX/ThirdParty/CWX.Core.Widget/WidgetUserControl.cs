using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Collections.ObjectModel;

namespace CWX.Core.Widget
{
    public class WidgetUserControl : UserControl, IWidget
    {
        private Dictionary<string, WidgetParameter> _paramsLookup = new Dictionary<string,WidgetParameter>();
        private bool _isBuiltLookup = false;

        #region Utility
        protected WidgetParameter GetWidgetParameter(string parameterName)
        {
            EnsureLookup();

            if (_paramsLookup.ContainsKey(parameterName))
                return _paramsLookup[parameterName];
            return null;
        }
        #endregion

        #region Private Helpers
        private void EnsureLookup()
        {
            if (Parameters == null)
                throw new InvalidOperationException("Widget parameters must be set");
            if (!_isBuiltLookup)
            {
                _isBuiltLookup = true;
                foreach (WidgetParameter param in Parameters)
                {
                    _paramsLookup.Add(param.ParameterName, param);
                }
            }
        }
        #endregion

        #region IWidget Members
        private Collection<WidgetParameter> _params;
        public Collection<WidgetParameter> Parameters
        {
            get{ return _params; }
            set { _params = value; }
        }

        private string _interfaceName;
        public string InterfaceName
        {
            get
            {
                return _interfaceName;
            }
            set
            {
                _interfaceName = value;
            }
        }

        private string _widgetName;
        public string WidgetName
        {
            get { return _widgetName; }
            set { _widgetName = value; }
        }

        private string _XslFileName;
        public string XslFileName
        {
            get { return _XslFileName; }
            set { _XslFileName = value; }
        }

        private WidgetType _widgetType;
        public WidgetType WidgetType
        {
            get { return _widgetType; }
            set { _widgetType = value; }
        }

        public string _interfacePath;
        public string InterfacePath
        {
            get { return _interfacePath; }
            set { _interfacePath = value; }
        }
        #endregion
    }
}
