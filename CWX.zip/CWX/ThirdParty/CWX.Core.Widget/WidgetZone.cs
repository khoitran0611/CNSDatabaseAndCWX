using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Collections.ObjectModel;
using System.Drawing.Design;

namespace CWX.Core.Widget
{
    //[ParseChildren(true)]
    [DefaultProperty("WidgetParameters")]
    [ParseChildren(true,"WidgetParameters")]
    [PersistChildren(true)]
    [ToolboxData("<{0}:WidgetZone runat=server></{0}:WidgetZone>")]
    public class WidgetZone : CompositeControl
    {
        private Collection<WidgetParameter> _parameters;

        [Browsable(true)]
        [Category("Appearance")]
        public string InterfaceName
        {
            get { return (string)ViewState["__WidgetZoneInterfaceName"]; }
            set { ViewState["__WidgetZoneInterfaceName"] = value; }
        }

        [Browsable(true)]
        [Category("Appearance")]
        public string WidgetName
        {
            get { return (string)ViewState["__WidgetZoneWidgetName"]; }
            set { ViewState["__WidgetZoneWidgetName"] = value; }
        }
        [Browsable(true)]
        [Category("Appearance")]
        public string XslFileName
        {
            get { return (string)ViewState["__WidgetZoneXslFileName"]; }
            set { ViewState["__WidgetZoneXslFileName"] = value; }
        }
        [Browsable(true)]
        [Category("Appearance")]
        public WidgetType WidgetType
        {
            get 
            {
                if (ViewState["__WidgetZoneForAccount"] == null)
                    ViewState["__WidgetZoneForAccount"] = WidgetType.None;

                return (WidgetType)ViewState["__WidgetZoneForAccount"];
            }
            set { ViewState["__WidgetZoneForAccount"] = value; }
        }

        [Browsable(true)]
        [PersistenceMode(PersistenceMode.InnerDefaultProperty)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Editor(typeof(WidgetParametersEditor),typeof(UITypeEditor))]
        public Collection<WidgetParameter> WidgetParameters
        {
            get
            {
                if (_parameters == null)
                    _parameters = new Collection<WidgetParameter>();
                return _parameters;
            }
        }

        protected override void CreateChildControls()
        {
            WidgetUserControl widgetInstance = WidgetManager.LoadWidget(InterfaceName, WidgetName, XslFileName, WidgetType, WidgetParameters);
            this.Controls.Add(widgetInstance);
        }
    }
}
