using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Collections.ObjectModel;

namespace CWX.Core.Widget
{
    public interface IWidgetProcessor
    {
        string WidgetUserControlPath { get; set; }

        WidgetUserControl LoadWidget(string interfaceName, string widgetName, string xslFileName, WidgetType widgetType, Collection<WidgetParameter> parameters);
    }
}
