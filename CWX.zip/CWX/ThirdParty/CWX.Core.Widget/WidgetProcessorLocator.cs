using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Collections.ObjectModel;
using CWX.Core.Widget.Configuration;
using System.Configuration;
using CWX.Core.Common.Exceptions;

namespace CWX.Core.Widget
{
    public class WidgetProcessorLocator : IWidgetProcessorLocator
    {
        #region IWidgetProcessorLocator Members

        public IWidgetProcessor GetProcessor(string interfaceName)
        {
            Type processorType = WidgetConfigurationManager.GetProcessorOfInterface(interfaceName);
            if (processorType == null)
                throw new CWXException("Can't find " + interfaceName);
        
            IWidgetProcessor processor = (IWidgetProcessor)Activator.CreateInstance(processorType);
            processor.WidgetUserControlPath = WidgetConfigurationManager.GetWidgetUserControlPath(interfaceName);

            return processor;
        }

        #endregion
    }
}
