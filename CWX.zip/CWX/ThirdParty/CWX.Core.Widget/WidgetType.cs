using System;
using System.Collections.Generic;
using System.Text;

namespace CWX.Core.Widget
{
    public enum WidgetType
    {
        None,
        Account,
        Debtor,
        AdditionalInfo
    }
}
