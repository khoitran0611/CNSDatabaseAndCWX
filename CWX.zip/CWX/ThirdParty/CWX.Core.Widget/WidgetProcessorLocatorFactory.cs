using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Configuration;
using CWX.Core.Widget.Configuration;
using System.Runtime.Remoting;

namespace CWX.Core.Widget
{
    public sealed class WidgetProcessorLocatorFactory
    {
        public static IWidgetProcessorLocator Create()
        {
            Type locatorType = WidgetConfigurationManager.GetServiceType();

            return (IWidgetProcessorLocator)Activator.CreateInstance(locatorType);
        }
    }
}
