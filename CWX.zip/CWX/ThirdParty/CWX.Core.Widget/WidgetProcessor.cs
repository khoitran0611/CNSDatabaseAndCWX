using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using System.IO;
using System.Web;

using CWX.Core.Widget.Configuration;
using System.Threading;

namespace CWX.Core.Widget
{
    public abstract class WidgetProcessor : IWidgetProcessor
    {
        #region IWidgetProcessor Members
        private string _widgetUserControlPath;
        public string WidgetUserControlPath
        {
            get
            {
                return _widgetUserControlPath;
            }
            set
            {
                _widgetUserControlPath = value;
            }
        }

        public WidgetUserControl LoadWidget(string interfaceName, string widgetName, string xslFileName, WidgetType widgetType, Collection<WidgetParameter> parameters)
        {
            WidgetUserControl widget = ProcessWidget(interfaceName, parameters);
            return SetParametersToWidgetUserControl(interfaceName, widgetName, xslFileName, widgetType, parameters, widget);
        }

        #endregion

        protected abstract WidgetUserControl ProcessWidget(string interfaceName, Collection<WidgetParameter> parameters);

        /// <summary>
        /// Set parameters to widget usercontrol.
        /// </summary>
        protected WidgetUserControl SetParametersToWidgetUserControl(string interfaceName, string widgetName, string xslFileName, WidgetType widgetType, Collection<WidgetParameter> parameters, WidgetUserControl widgetUserControl)
        {
            if (widgetUserControl == null)
                throw new ArgumentNullException("widgetUserControl");

            widgetUserControl.WidgetName = widgetName;
            widgetUserControl.XslFileName = xslFileName;
            widgetUserControl.WidgetType = widgetType;
            widgetUserControl.InterfaceName = interfaceName;
            widgetUserControl.InterfacePath = GetInterfacePath(interfaceName);
            widgetUserControl.Parameters = parameters;

            return widgetUserControl;
        }

        private string GetInterfacePath(string interfaceName)
        {
            string cultureName = Thread.CurrentThread.CurrentUICulture.Name;
            if (!string.IsNullOrEmpty(cultureName) && !string.Equals(cultureName, "en-US", StringComparison.InvariantCultureIgnoreCase))
                cultureName = "." + cultureName;
            else
                cultureName = string.Empty;

            //if interface does not exist, use the default
            string interfacePath = string.Format(WidgetConfigurationManager.GetInterfacePath(interfaceName), cultureName);
            interfacePath = HttpContext.Current.Server.MapPath(interfacePath);
            if (Directory.Exists(interfacePath))
                return string.Format(WidgetConfigurationManager.GetInterfacePath(interfaceName), cultureName);
            else
                return string.Format(WidgetConfigurationManager.GetInterfacePath(interfaceName), string.Empty);
        }
    }
}
