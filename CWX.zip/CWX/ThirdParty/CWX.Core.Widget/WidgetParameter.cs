using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.ComponentModel;

namespace CWX.Core.Widget
{
    public class WidgetParameter
    {
        #region Properties

        private string _parameterName;
        public string ParameterName
        {
            get { return _parameterName; }
            set { _parameterName = value; }
        }

        private string _parameterValue;
        public string ParameterValue
        {
            get { return _parameterValue; }
            set { _parameterValue = value; }
        }

        #endregion

        #region Constructors

        public WidgetParameter()
        {

        }

        public WidgetParameter(string parameterName, string parameterValue)
        {
            _parameterName = parameterName;
            _parameterValue = parameterValue;
        }

        #endregion
    }
}
