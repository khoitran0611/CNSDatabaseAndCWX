using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;

namespace CWX.Core.Widget
{
    public interface IWidget
    {
        string InterfaceName { get; set; }

        string WidgetName { get; set; }

        string InterfacePath { get; set; }

        Collection<WidgetParameter> Parameters { get; set;}
    }
}
