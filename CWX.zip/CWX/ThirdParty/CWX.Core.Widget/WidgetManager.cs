using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Collections.ObjectModel;

namespace CWX.Core.Widget
{
    public class WidgetManager
    {
        private static object _objectLock = new object();
        private static WidgetManager _instance;

        private IWidgetProcessorLocator _locator;
        private WidgetManager()
        {
            _locator = WidgetProcessorLocatorFactory.Create();
        }

        private static WidgetManager Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_objectLock)
                    {
                        if (_instance == null)
                            _instance = new WidgetManager();
                    }
                }
                return _instance;
            }
        }

        public static WidgetUserControl LoadWidget(string interfaceName, string widgetName, string xslFileName, WidgetType widgetType, Collection<WidgetParameter> parameters)
        {
            IWidgetProcessor processor = Instance._locator.GetProcessor(interfaceName);
            return processor.LoadWidget(interfaceName, widgetName, xslFileName, widgetType, parameters);
        }
    }
}
