using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections.ObjectModel;
using System.Collections;

namespace CWX.Core.Widget
{
    public class WidgetParametersEditor : CollectionEditor
    {
        public WidgetParametersEditor(Type type)
            : base(type)
        { 
        }

        protected override bool CanSelectMultipleInstances()
        {
            return false;
        }

        protected override Type CreateCollectionItemType()
        {
            return typeof(WidgetParameter);
        }
    }
}
