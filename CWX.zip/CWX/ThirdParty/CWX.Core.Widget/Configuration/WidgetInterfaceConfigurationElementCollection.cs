using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CWX.Core.Widget.Configuration
{
    [ConfigurationCollection(typeof(WidgetInterfaceConfigurationElement))]
    public class WidgetInterfaceConfigurationElementCollection : ConfigurationElementCollection
    {
        protected override ConfigurationElement CreateNewElement()
        {
            return new WidgetInterfaceConfigurationElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((WidgetInterfaceConfigurationElement)element).Name;
        }
    }
}
