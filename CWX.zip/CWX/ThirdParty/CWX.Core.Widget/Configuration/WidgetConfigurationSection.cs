using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CWX.Core.Widget.Configuration
{
    public class WidgetConfigurationSection : ConfigurationSection
    {
        [ConfigurationProperty("service", IsRequired = true)]
        public WidgetServiceConfigurationElement Service
        {
            get
            {
                return this["service"] as WidgetServiceConfigurationElement;
            }
            set
            {
                this["service"] = value;
            }
        }
    }
}
