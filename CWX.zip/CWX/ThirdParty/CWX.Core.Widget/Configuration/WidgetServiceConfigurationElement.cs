using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.ComponentModel;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;

namespace CWX.Core.Widget.Configuration
{
    public class WidgetServiceConfigurationElement: ConfigurationElement
    {
        public WidgetServiceConfigurationElement()
            : base()
        { 
        }

        [ConfigurationProperty("name", IsRequired=true)]
        public string Name
        {
            get
            {
                return (string)this["name"];
            }
            set
            {
                this["name"] = value;
            }
        }

        [ConfigurationProperty("type", IsRequired=true)]
        [TypeConverter(typeof(AssemblyQualifiedTypeNameConverter))]
        public Type Type
        {
            get
            {
                return (Type)this["type"];
            }
            set
            {
                this["type"] = value;
            }
        }

        [ConfigurationProperty("processors", IsRequired = true)]
        public WidgetProcessorConfigurationElementCollection processors
        {
            get
            {
                return (WidgetProcessorConfigurationElementCollection)this["processors"];
            }
            set
            {
                this["processors"] = value;
            }
        }

        [ConfigurationProperty("interfaces", IsRequired=true)]
        public WidgetInterfaceConfigurationElementCollection Interfaces
        {
            get
            {
                return (WidgetInterfaceConfigurationElementCollection)this["interfaces"];
            }
            set
            {
                this["interfaces"] = value;
            }
        }
    }
}
