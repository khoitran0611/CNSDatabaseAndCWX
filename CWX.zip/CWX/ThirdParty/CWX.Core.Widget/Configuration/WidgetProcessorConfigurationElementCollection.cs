using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CWX.Core.Widget.Configuration
{
    [ConfigurationCollection(typeof(WidgetProcessorConfigurationElement))]
    public class WidgetProcessorConfigurationElementCollection : ConfigurationElementCollection
    {
        protected override ConfigurationElement CreateNewElement()
        {
            return new WidgetProcessorConfigurationElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            if (element == null)
                throw new ArgumentNullException("element");

            return ((WidgetProcessorConfigurationElement)element).Name;
        }
    }
}
