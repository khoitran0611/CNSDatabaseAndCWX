using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace CWX.Core.Widget.Configuration
{
    public class WidgetInterfaceConfigurationElement : ConfigurationElement
    {
        [ConfigurationProperty("name", IsRequired=true, IsKey=true)]
        public string Name
        {
            get
            {
                return (string)this["name"];
            }
            set
            {
                this["name"] = value;
            }
        }

        [ConfigurationProperty("processor", IsRequired=true)]
        public string Processor
        {
            get
            {
                return (string)this["processor"];
            }
            set
            {
                this["processor"] = value;
            }
        }

        [ConfigurationProperty("path", IsRequired = true)]
        public string InterfacePath
        {
            get
            {
                return (string)this["path"];
            }
            set
            {
                this["path"] = value;
            }
        }
    }
}
