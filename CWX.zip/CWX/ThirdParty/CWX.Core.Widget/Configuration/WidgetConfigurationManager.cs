using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Configuration;
using System.IO;
using System.Web;

namespace CWX.Core.Widget.Configuration
{
    public sealed class WidgetConfigurationManager
    {
        public static Type GetServiceType()
        {
            WidgetConfigurationSection section = ConfigurationManager.GetSection("system.web/CWXWidgetService") as WidgetConfigurationSection;
            return section.Service.Type;
        }

        public static Type GetProcessorType(string processorName)
        {
            WidgetConfigurationSection section = ConfigurationManager.GetSection("system.web/CWXWidgetService") as WidgetConfigurationSection;

            WidgetProcessorConfigurationElementCollection processors = section.Service.processors;
            IEnumerator iterator = processors.GetEnumerator();
            while (iterator.MoveNext())
            {
                WidgetProcessorConfigurationElement element = (WidgetProcessorConfigurationElement)iterator.Current;
                if (element.Name.Equals(processorName, StringComparison.OrdinalIgnoreCase))
                    return element.Type;
            }
            return null;
        }

        public static string GetProcessorUserControlPath(string processorName)
        {
            WidgetConfigurationSection section = ConfigurationManager.GetSection("system.web/CWXWidgetService") as WidgetConfigurationSection;

            WidgetProcessorConfigurationElementCollection processors = section.Service.processors;
            IEnumerator iterator = processors.GetEnumerator();
            while (iterator.MoveNext())
            {
                WidgetProcessorConfigurationElement element = (WidgetProcessorConfigurationElement)iterator.Current;
                if (element.Name.Equals(processorName, StringComparison.OrdinalIgnoreCase))
                    return element.WidgetUserControlPath;
            }
            return string.Empty;
        }

        public static Type GetProcessorOfInterface(string interfaceName)
        {
            WidgetConfigurationSection section = ConfigurationManager.GetSection("system.web/CWXWidgetService") as WidgetConfigurationSection;

            WidgetInterfaceConfigurationElementCollection intefaces = section.Service.Interfaces;
            IEnumerator iterator = intefaces.GetEnumerator();
            while (iterator.MoveNext())
            {
                WidgetInterfaceConfigurationElement element = (WidgetInterfaceConfigurationElement)iterator.Current;
                if (element.Name.Equals(interfaceName, StringComparison.OrdinalIgnoreCase))
                {
                    return GetProcessorType(element.Processor);
                }
            }
            return null;
        }

        public static string GetWidgetUserControlPath(string interfaceName)
        {
            WidgetConfigurationSection section = ConfigurationManager.GetSection("system.web/CWXWidgetService") as WidgetConfigurationSection;

            WidgetInterfaceConfigurationElementCollection intefaces = section.Service.Interfaces;
            IEnumerator iterator = intefaces.GetEnumerator();
            while (iterator.MoveNext())
            {
                WidgetInterfaceConfigurationElement element = (WidgetInterfaceConfigurationElement)iterator.Current;
                if (element.Name.Equals(interfaceName, StringComparison.OrdinalIgnoreCase))
                {
                    return GetProcessorUserControlPath(element.Processor);
                }
            }
            return string.Empty;
        }

        public static string GetInterfacePath(string interfaceName)
        {
            string interfacePath = string.Empty;

            WidgetConfigurationSection section = ConfigurationManager.GetSection("system.web/CWXWidgetService") as WidgetConfigurationSection;
            WidgetInterfaceConfigurationElementCollection intefaces = section.Service.Interfaces;
            IEnumerator iterator = intefaces.GetEnumerator();
            while (iterator.MoveNext())
            {
                WidgetInterfaceConfigurationElement element = (WidgetInterfaceConfigurationElement)iterator.Current;
                if (element.Name.Equals(interfaceName, StringComparison.OrdinalIgnoreCase))
                    interfacePath = element.InterfacePath;   
            }
            return interfacePath;
        }
    }
}
