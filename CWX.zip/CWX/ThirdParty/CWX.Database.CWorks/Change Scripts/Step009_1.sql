 -- Scripts are applied on version 1.4 build 1
 
/****** Object:  StoredProcedure [dbo].[CWX_PersonPhone_Get]    Script Date: 04/11/2008 10:31:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonPhone_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonPhone_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonPhone_Get]    Script Date: 04/11/2008 10:31:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonPhone_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Triet Pham
-- Create date: Mar 26th, 2008
-- Description:	Retrieve all personal phone details
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_PersonPhone_Get]	
	@DebtorID int
AS
BEGIN
	Select 
		ph.PhoneID,
		ph.PersonID,
		ph.PhoneType,
		ph.PhoneNumber,
		ph.PhoneExtension,
		ph.PhoneStatus,
		ph.Description,
		ph.EmployeeID,
		ph.CreateDate,
		ph.UpdateDate
	From PersonPhone AS ph INNER JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	Where d.DebtorID = @DebtorID and ph.PhoneType in (8,9)	
END


SET ANSI_NULLS ON
' 
END
GO



/****** Object:  StoredProcedure [dbo].[CWX_IdentityFields_GetIdentityTableValue]    Script Date: 04/11/2008 10:33:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_IdentityFields_GetIdentityTableValue]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_IdentityFields_GetIdentityTableValue]
GO
/****** Object:  StoredProcedure [dbo].[CWX_IdentityFields_GetIdentityTableValue]    Script Date: 04/11/2008 10:33:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_IdentityFields_GetIdentityTableValue]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TaiLy
-- Create date: April 04, 2008
-- Description:	Insert and return FieldValue in IdentityFields table
-- =============================================
CREATE PROCEDURE [dbo].[CWX_IdentityFields_GetIdentityTableValue]
(	
	@TableName varchar(50)
)
AS
BEGIN
	SET NOCOUNT ON;	

	-- Declare the return variable here
	DECLARE @FieldValue int	

	-- Add the T-SQL statements to compute the return value here
	DECLARE @FieldName	varchar(50)

	DECLARE TableCursor CURSOR FOR
	SELECT	* 	
	FROM	[dbo].[IdentityFields]
	WHERE	TableName = @TableName	

	OPEN TableCursor
	FETCH NEXT FROM TableCursor INTO @FieldName, @FieldValue	

	-- Return the result of the function
	IF @@FETCH_STATUS <> 0
	BEGIN
		INSERT INTO [dbo].[IdentityFields] VALUES(@TableName, 0)
		
		SELECT @FieldValue = 0	
	END

	CLOSE TableCursor
	DEALLOCATE TableCursor

	SET NOCOUNT OFF

	RETURN @FieldValue
END

' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountActions_Get]    Script Date: 04/11/2008 10:34:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountActions_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountActions_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountActions_Get]    Script Date: 04/11/2008 10:34:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountActions_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TaiLy
-- Create date: April 04, 2008
-- Description:	Get information in AccountAction
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountActions_Get]
	-- Add the parameters for the stored procedure here
	@AccountID	int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	TOP 1 DateCompleted, ResponsibleParty
	FROM	[dbo].[AccountActions]
	WHERE	AccountID = @AccountID AND ActionID IN (	SELECT	ActionID
														FROM	[dbo].[AvailableActions]
														WHERE	Category IN (1,2) AND
																ProductivityID IN (1,2)
													)
	ORDER BY	DateCompleted DESC
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_PromiseToPay]    Script Date: 04/11/2008 10:35:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_PromiseToPay]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_PromiseToPay]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_PromiseToPay]    Script Date: 04/11/2008 10:35:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_PromiseToPay]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TaiLy
-- Create date: April 04, 2008
-- Description:	Get number of rows in AccountPromise which have AccountID = @AccountID
-- =============================================
CREATE PROCEDURE CWX_AccountPromise_Count
	-- Add the parameters for the stored procedure here
	@AccountID	int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	COUNT(*) AS PromiseCnt
	FROM	[dbo].[AccountPromise]
	WHERE	AccountID = @AccountID
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_PromiseKept]    Script Date: 04/11/2008 10:36:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_PromiseKept]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_PromiseKept]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_PromiseKept]    Script Date: 04/11/2008 10:36:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_PromiseKept]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TaiLy
-- Create date: April 04, 2008
-- Description:	Get number of rows which have Status = 1 or 2 And accountId = input accountid
-- =============================================
CREATE PROCEDURE CWX_AccountPromise_PromiseKept
	-- Add the parameters for the stored procedure here
	@AccountID	int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	COUNT(*) AS PromiseKept
	FROM	AccountPromise
	WHERE	Status IN (1,2) AND AccountID = @AccountID
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_PromiseBroken]    Script Date: 04/11/2008 10:36:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_PromiseBroken]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_PromiseBroken]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_PromiseBroken]    Script Date: 04/11/2008 10:36:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_PromiseBroken]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_PromiseBroken]
	-- Add the parameters for the stored procedure here
	@AccountID	int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	COUNT(*)
	FROM	AccountPromise
	WHERE	Status = 3 AND AccountID = @AccountID
END
' 
END
GO



/****** Object:  StoredProcedure [dbo].[CWX_AccountActions_OutgoingCall]    Script Date: 04/11/2008 10:37:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountActions_OutgoingCall]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountActions_OutgoingCall]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountActions_OutgoingCall]    Script Date: 04/11/2008 10:37:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountActions_OutgoingCall]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TaiLy
-- Create date: April 04, 2008
-- Description:	Get OutgoingCall
-- =============================================
CREATE PROCEDURE CWX_AccountActions_OutgoingCall
	-- Add the parameters for the stored procedure here
	@AccountID	int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	COUNT(*) AS OutgoingCall
	FROM	[dbo].[AccountActions]
	WHERE	AccountID = @AccountID AND ActionID IN	(	SELECT	ActionID
														FROM	[dbo].[AvailableActions]
														WHERE	Category = 2
													)
END
' 
END
GO



/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetName]    Script Date: 04/11/2008 10:37:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetName]    Script Date: 04/11/2008 10:37:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetName]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TaiLy
-- Create date: April 04, 2008
-- Description:	Get all employee name which have employeeID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_GetName]
	-- Add the parameters for the stored procedure here
	@EmployeeID	int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	EmployeeName
	FROM	[dbo].[Employee]
	WHERE	EmployeeID = @EmployeeID
END
' 
END
GO



/****** Object:  StoredProcedure [dbo].[CWX_Notes_Get]    Script Date: 04/04/2008 16:36:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Notes_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Notes_Get]
GO
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Notes_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_Notes_Get] 	
	@DebtorID int, @AccountID int	
AS
BEGIN
	Declare @IdentityTableValue int
	Set @IdentityTableValue = (Select FieldValue from IdentityFields where TableName = ''NotesDisplayByAccount'')
	if (@IdentityTableValue < 0 )
		begin 
			Insert into IdentityFields values(''NotesDisplayByAccount'',0)
			select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
			where n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID Order By n.NoteDateTime desc, n.NoteID			
		end
	else if (@IdentityTableValue = 0 )
		begin 
			select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
			where n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID Order By n.NoteDateTime desc, n.NoteID			
		end
	else		
		begin
			select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
			where n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID Order By n.NoteDateTime desc, n.NoteID
		end	
END		
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Spouse_Get]    Script Date: 04/11/2008 10:39:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Spouse_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Spouse_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Spouse_Get]    Script Date: 04/11/2008 10:39:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Spouse_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TrietPham
-- Create date: April 04,2008
-- Description:	Retrieve the spouse personal information of the debtor
-- =============================================
CREATE PROCEDURE CWX_Spouse_Get 
	@SpouseID int
AS
BEGIN
	SET NOCOUNT ON;
	Select 
		s.FirstName as SPOUSEFIRSTNAME, 
		s.MiddleName as SPOUSEMIDDLENAME, 
		s.LastName as SPOUSELASTNAME, 
		s.AlternateID1Name as SPOUSEALTERNATEIDNAME, 
		s.AlternateID2Name as SPOUSEALTERNATEID2NAME, 
		s.AlternateID1 as SPOUSEALTERNATEID1, 
		s.AlternateID2 as SPOUSEALTERNATEID2, 
		s.DriversLicenseNumber as SPOUSEDRIVERSLICENSE,
		s.MobilPhone as SPOUSEMOBILE, 
		s.Employment as SPOUSEEMP, 
		s.EmploymentPhone as SPOUSEEMPPHONE, 
		s.EmploymentPhoneExtension as SPOUSEEMPPHONEEXT,  
		s.Fax as SPOUSEFAX, 
		s.SocialSecurityNumber as SPOUSESOCIALSECURITYNUMBER, 
		s.DateOfBirth as SPOUSEDATEOFBIRTH, 
		s.Email as SPOUSEEMAIL		
	From PersonInformation as s INNER JOIN PersonInformation as d ON d.SpouseID = s.PersonID  
	Where s.PersonID= @SpouseID
END
' 
END
GO


-- =======================================================================
-- Author:		Long Nguyen
-- Create date: Apr 03, 2008
-- Description:	Add column 'SQL2' to 'QueryMaster'
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'QueryMaster' and c.name = 'SQL2')
BEGIN
	ALTER TABLE QueryMaster ADD SQL2 varchar(250) NULL
END
GO

UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_SearchByQueueSStat %E, %1' WHERE ID = 1
UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_SearchByQueueAStat %E, %1' WHERE ID = 2
UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_GetTickets %E, %1' WHERE ID = 3
UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_SearchDebtorByName %1, %2' WHERE ID = 11
UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_SearchByEmployeeName %1, %2' WHERE ID = 17
UPDATE QueryMaster SET SQL2 = 'EXEC SearchAccountByInvoice %1,%2' WHERE ID = 7
UPDATE QueryMaster SET SQL2 = 'EXEC SearchAccountByBill  %1,%2' WHERE ID = 10
UPDATE QueryMaster SET SQL2 = 'EXEC SearchDebtorByPhone %1,%2' WHERE ID = 12
UPDATE QueryMaster SET SQL2 = 'EXEC SearchAccountByMobile %1,%2' WHERE ID = 15
UPDATE QueryMaster SET SQL2 = 'EXEC SearchByofficePhone %1,%2' WHERE ID = 16
GO

--Update QueryParams
UPDATE QueryParams SET Format = '',			PickList = 'ALL|0|Active|5|Legal|1' WHERE QueryID = 1
UPDATE QueryParams SET Format = '',			PickList = 'Select AgencyStatus, rtrim(ShortDesc) +'' -'' + rtrim(LongDesc) As Description from AccountStatus where AgencyStatus > 0 and Status <> ''R'' order by AgencyStatus' WHERE QueryID = 2
UPDATE QueryParams SET Format = '',			PickList = 'My Ticket|0|To-do|1' WHERE QueryID = 3
UPDATE QueryParams SET Format = '',			PickList = 'select a.ID, a.Description from RuleTable a, RulesAllocUsers b where a.RuleType = 1 and a.ID = b.RuleID and b.Employees like ''%%E%''' WHERE QueryID = 4
UPDATE QueryParams SET Format = '',			PickList = '' WHERE QueryID = 5
UPDATE QueryParams SET Format = '',			PickList = 'select EmployeeID, EmployeeName from Employee where EmployeeStatus = ''A'' order by EmployeeName' WHERE QueryID = 6
UPDATE QueryParams SET Format = '^.{0,50}$',PickList = '' WHERE QueryID = 7
UPDATE QueryParams SET Format = '',			PickList = 'Low Balance (<10000)|1|Mid Balance (>=10000 and <25000)|2|Mid Balance (>=25000 and <50000)|3|High Balance (>=50000 and <150000)|4|High Balance (>150000)|5' WHERE QueryID = 8
UPDATE QueryParams SET Format = '',			PickList = 'Today|2|GE Today|0|Tomorrow|1|3 Days|3|5 Days|5' WHERE QueryID = 9
UPDATE QueryParams SET Format = '^\d{0,9}$',PickList = '' WHERE QueryID = 10
UPDATE QueryParams SET Format = '^.{0,50}$',PickList = '' WHERE QueryID = 11
UPDATE QueryParams SET Format = '^.{0,25}$',PickList = '' WHERE QueryID = 12
UPDATE QueryParams SET Format = '^\d{0,5}$',PickList = '' WHERE QueryID = 13
UPDATE QueryParams SET Format = '^\d{0,5}$',PickList = '' WHERE QueryID = 14
UPDATE QueryParams SET Format = '^.{0,25}$',PickList = '' WHERE QueryID = 15
UPDATE QueryParams SET Format = '^.{0,25}$',PickList = '' WHERE QueryID = 16
UPDATE QueryParams SET Format = '^.{0,100}$',PickList = '' WHERE QueryID = 17
UPDATE QueryParams SET Format = '^\d{0,9}$',PickList = '' WHERE QueryID = 18
UPDATE QueryParams SET Format = '',			PickList = 'Select CodeID,CodeDesc from AccountCodeMaster where CodeType = 6 and Status <> ''R'' ORDER BY CodeDesc' WHERE QueryID = 19
UPDATE QueryParams SET Format = '',			PickList = 'select EmployeeID, EmployeeName from Employee where EmployeeStatus = ''A'' order by EmployeeName' WHERE QueryID = 20
UPDATE QueryParams SET Format = '',			PickList = 'Select CodeID,CodeDesc from AccountCodeMaster where CodeType = 7 and Status <> ''R''  ORDER BY CodeDesc' WHERE QueryID = 21
UPDATE QueryParams SET Format = '',			PickList = 'Select CodeID,CodeDesc from AccountCodeMaster where CodeType = 2 and Status <> ''R''  ORDER BY CodeDesc' WHERE QueryID = 22
UPDATE QueryParams SET Format = '',			PickList = 'Select ClientID,ClientName from ClientInformation where Referral = 1 and Status <> ''R'' order by ClientName' WHERE QueryID = 23
UPDATE QueryParams SET Format = '',			PickList = '' WHERE QueryID = 24
UPDATE QueryParams SET Format = '',			PickList = 'Select CodeID,CodeDesc from AccountCodeMaster where CodeType = 2 and Status <> ''R''  ORDER BY CodeDesc' WHERE QueryID = 25
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTickets]    Script Date: 04/04/2008 17:39:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetTickets]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetTickets]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTickets]    Script Date: 04/04/2008 17:39:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetTickets] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@TicketClass int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  t.TicketID) AS RowNumber,
		CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID) + '|' + CONVERT(varchar(10), t.TicketID) AS KeyField,
		t.TicketID AS [Ticket ID],
		e.EmployeeName AS [Requester],
		f.EmployeeName AS [Assign To],
		t.CurrentStage AS [Current Stage],
		t.TotalStage AS [Total Stage],
		t.RequestDate AS [Request Date],
		t.StartDate AS [Start Date],
		t.DueDate AS [Due Date],
		s.Description AS [Ticket Status],
		CASE t.Priority
			WHEN 0 THEN 'Low'
			WHEN 1 THEN 'Medium'
			WHEN 2 THEN 'High'
		END AS Priority
	INTO #Temp
	FROM Ticket t
	INNER JOIN TicketStatus s ON s.TicketStatusID = t.TicketStatus
	INNER JOIN Employee e ON e.EmployeeID = t.Requester
	INNER JOIN Employee f ON f.EmployeeID = t.AssignedTo
	INNER JOIN Account a ON a.AccountID = t.AccountID
	WHERE
		(((@TicketClass = 1) and (t.CurrentEmployeeID = @EmployeeID)) or ((@TicketClass = 0) and (t.Requester = @EmployeeID)))
		AND t.TicketStatus <> 9

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		KeyField,
		[Ticket ID],
		[Requester],
		[Assign To],
		[Current Stage],
		[Total Stage],
		[Request Date],
		[Start Date],
		[Due Date],
		[Ticket Status],
		Priority
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByEmployeeName]    Script Date: 04/04/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByEmployeeName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByEmployeeName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByEmployeeName]    Script Date: 04/04/2008 17:39:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByEmployeeName] 
	-- Add the parameters for the stored procedure here
	@EmployeeName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
		g.EmployeeName AS [Employee Name],
		a.QueueDate AS [QueueDate],
		a.AccountAge AS [DPD],
		CAST(a.MCode AS CHAR(2)) AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		a.Minimum_due AS [Minimum Due],
		p.SocialSecurityNumber AS [ID],
		RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [ Name]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
	WHERE
		a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		KeyField,
		[Employee Name],
		[QueueDate],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Minimum Due],
		[ID],
		[ Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueAStat]    Script Date: 04/04/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByQueueAStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueAStat]    Script Date: 04/04/2008 17:39:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_AgencyStatus int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		KeyField varchar(30),
		QueueDate smalldatetime,
		DPD int,
		Bucket char(1),
		Cycle smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		Status varchar(10),
		Priority int,
		[Assignment Type] char(1),
		[ID] varchar(25),
		[Name] varchar(200)
	)

    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.AccountAge AS [DPD],'
				+ '   CAST(a.MCode AS CHAR(1)) AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN AccountOther o ON o.AccountID = a.AccountID'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId AS varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID = '+CAST(@v_AgencyStatus AS varchar(9))

	--Build OrderByClause
	SET @cStmt=@cStmt+' ORDER BY '
	DECLARE @v_SortOrder varchar(700)

	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
       Set @cStmt = @cStmt + ' "QueueDate" DESC'
    ELSE
       Set @cStmt = @cStmt + @v_SortOrder

	EXEC (@cStmt)

	DECLARE @RowCount int
	SET @RowCount = @@ROWCOUNT

	--Paging
	SELECT
		KeyField,
		QueueDate,
		DPD,
		Bucket,
		Cycle,
		[Bill Amount],
		[Bill Balance],
		Status,
		Priority,
		[Assignment Type],
		[ID],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	DROP TABLE #Temp

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 04/04/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByQueueSStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 04/04/2008 17:39:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_SystemStatus int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		KeyField varchar(30),
		QueueDate smalldatetime,
		DPD int,
		Bucket char(1),
		Cycle smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		Status varchar(10),
		Priority int,
		[Assignment Type] char(1),
		[ID] varchar(25),
		[Name] varchar(200)
	)

    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.AccountAge AS [DPD],'
				+ '   CAST(a.MCode AS CHAR(1)) AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN Accountother o ON o.AccountID = a.AccountID'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId as varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID <> 2'

	IF @v_SystemStatus = 0 
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'+''
	ELSE
		SET @cStmt=@cStmt+' AND s.SystemStatus = '+CAST(@v_SystemStatus AS char(9))+''

	--Build OrderByClause
	SET @cStmt=@cStmt+' ORDER BY '
	DECLARE @v_SortOrder varchar(700)

	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
       Set @cStmt = @cStmt + ' "QueueDate" DESC'
    ELSE
       Set @cStmt = @cStmt + @v_SortOrder

	EXEC (@cStmt)

	DECLARE @RowCount int
	SET @RowCount = @@ROWCOUNT

	--Paging
	SELECT
		KeyField,
		QueueDate,
		DPD,
		Bucket,
		Cycle,
		[Bill Amount],
		[Bill Balance],
		Status,
		Priority,
		[Assignment Type],
		[ID],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	DROP TABLE #Temp

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByName]    Script Date: 04/04/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchDebtorByName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByName]    Script Date: 04/04/2008 17:39:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchDebtorByName] 
	-- Add the parameters for the stored procedure here
	@DebtorName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
		RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) AS [Name],
		a.QueueDate AS [QueueDate],
		a.AccountAge AS [DPD],
		CAST(a.MCode AS CHAR(2)) AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		a.Minimum_due AS [Minimum Due],
		p.SocialSecurityNumber AS [ID]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		KeyField,
		[Name],
		[QueueDate],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Minimum Due],
		[ID]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[SearchAccountByBill]    Script Date: 04/08/2008 10:55:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchAccountByBill]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchAccountByBill]
GO
/****** Object:  StoredProcedure [dbo].[SearchAccountByBill]    Script Date: 04/08/2008 10:56:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/******   Script Date: 2007/04/09,sathya  ******/
CREATE PROCEDURE [dbo].[SearchAccountByBill](@AcctID INT,@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.AccountID as [Reference No.],'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'CAST(a.MCode AS CHAR(1)) as [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'a.Minimum_due  as [Minimum Due],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'p.SocialSecurityNumber as [ID],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'Accountother o,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where a.AccountID = '+Cast(@AcctID As Char(9))
	SET @cStmt=@cStmt+' and o.AccountID = a.AccountID'
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END
GO

/****** Object:  StoredProcedure [dbo].[SearchAccountByInvoice]    Script Date: 04/08/2008 11:28:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchAccountByInvoice]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchAccountByInvoice]
GO
/****** Object:  StoredProcedure [dbo].[SearchAccountByInvoice]    Script Date: 04/08/2008 11:28:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



/******   Script Date: 2007/04/09,sathya  ******/
CREATE   PROCEDURE [dbo].[SearchAccountByInvoice](@Invoice char(50),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.DebtorID As [DebtorID],'	
	SET @cStmt=@cStmt+'a.InvoiceNumber As [Account No.],'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'CAST(a.MCode AS CHAR(2)) as [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'a.Minimum_due  as [Minimum Due],'
	SET @cStmt=@cStmt+'p.SocialSecurityNumber as [ID],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where a.InvoiceNumber = '+''''+Cast(@Invoice As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END
GO

/****** Object:  StoredProcedure [dbo].[SearchDebtorByPhone]    Script Date: 04/08/2008 11:30:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchDebtorByPhone]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchDebtorByPhone]
GO
/****** Object:  StoredProcedure [dbo].[SearchDebtorByPhone]    Script Date: 04/08/2008 11:30:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/******   Script Date: 2007/04/09,sathya  ******/
CREATE PROCEDURE [dbo].[SearchDebtorByPhone](@PhoneNumber char(25),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'p.HomePhone As [Home Phone.],'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'CAST(a.MCode AS CHAR(2)) as [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'a.Minimum_due  as [Minimum Due],'
	SET @cStmt=@cStmt+'p.SocialSecurityNumber as [ID],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p'
SET @cStmt=@cStmt+' where p.HomePhone = '+''''+Cast(@PhoneNumber As Char(25))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END
GO

/****** Object:  StoredProcedure [dbo].[SearchAccountByMobile]    Script Date: 04/08/2008 11:31:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchAccountByMobile]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchAccountByMobile]
GO
/****** Object:  StoredProcedure [dbo].[SearchAccountByMobile]    Script Date: 04/08/2008 11:31:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/******   Script Date: 2007/04/09,sathya  ******/
CREATE PROCEDURE [dbo].[SearchAccountByMobile](@MobilePhone char(50),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'p.MobilPhone As [Mobile Phone No.],'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'CAST(a.MCode AS CHAR(2)) as [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'a.Minimum_due  as [Minimum Due],'
	SET @cStmt=@cStmt+'p.SocialSecurityNumber as [ID],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p'
SET @cStmt=@cStmt+' where p.MobilPhone = '+''''+Cast(@MobilePhone As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END
GO

/****** Object:  StoredProcedure [dbo].[SearchByofficePhone]    Script Date: 04/08/2008 11:32:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchByofficePhone]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchByofficePhone]
GO
/****** Object:  StoredProcedure [dbo].[SearchByofficePhone]    Script Date: 04/08/2008 11:32:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/******   Script Date: 2007/04/09,sathya  ******/
CREATE PROCEDURE [dbo].[SearchByofficePhone](@PhoneNumber char(50),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'p.EmploymentPhone As [Business Phone],'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'CAST(a.MCode AS CHAR(2)) as [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'a.Minimum_due  as [Minimum Due],'
	SET @cStmt=@cStmt+'p.SocialSecurityNumber as [ID],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p'
SET @cStmt=@cStmt+' where p.EmploymentPhone = '+''''+Cast(@PhoneNumber As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Save_Note]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Save_Note]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
-- =============================================
-- Author:		KhoaDuong
-- Create date: Apr 05, 2008
-- Description:	Save Note
-- =============================================
GO


CREATE PROCEDURE [dbo].[CWX_Save_Note] 	
	(@NoteID int, @EmployeeID int, @DebtorID int, @AccountID int, @NoteDateTime datetime, @NoteType varchar (1), @NoteText varchar(700))
AS
BEGIN

INSERT INTO [dbo].[NotesCurrent] (EmployeeID, DebtorID, BillID, NoteDateTime, NoteType, NoteText)
VALUES (@EmployeeID, @DebtorID, @AccountID, @NoteDateTime, @NoteType, @NoteText )

END
GO
SET IDENTITY_INSERT [dbo].[NotesCurrent] ON

GO



/****** Object:  UserDefinedFunction [dbo].[CWX_AvailableActions_GetNextAction]    Script Date: 04/11/2008 10:43:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AvailableActions_GetNextAction]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CWX_AvailableActions_GetNextAction]
GO
/****** Object:  UserDefinedFunction [dbo].[CWX_AvailableActions_GetNextAction]    Script Date: 04/11/2008 10:43:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AvailableActions_GetNextAction]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TaiLy
-- Create date: April 8, 2008
-- Description:	GetNextAction
-- =============================================
CREATE FUNCTION [dbo].[CWX_AvailableActions_GetNextAction] 
(
	-- Add the parameters for the function here
	@ActionID	int
)
RETURNS varchar(256)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @RET varchar(256)
	DECLARE @CallResultID int, @NextActionID int
	SET @RET = '''';	
	SET @CallResultID = -1;
	SET @NextActionID = -1;

	-- Add the T-SQL statements to compute the return value here
	SELECT	@CallResultID = CallResultId, @NextActionID = NextActionId 				
	FROM	[dbo].[AvailableActions] aActions
	WHERE	ActionID = @ActionID
	
	IF @CallResultID >= 0
	BEGIN
		SET @RET = CAST(@CallResultID as varchar(256)) + ''|'' + CAST(@NextActionID as varchar(256));		
	END

	-- Return the result of the function
	RETURN @RET

END
' 
END

GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [dbo].[CWX_TicketHistory_Get]    Script Date: 04/08/2008 18:05:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketHistory_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TicketHistory_Get]
GO

-- =============================================
-- Author:		Triet Pham
-- Create date: April 8, 2008
-- Description:	Get all ticket history of the debtor id.
-- =============================================
CREATE PROCEDURE CWX_TicketHistory_Get 
	@DebtorID int
AS
BEGIN
	
	SET NOCOUNT ON;
	Select t.TicketID as [TicketID],
		   t.TicketStatus as [StatusId],
		   d.Description as [TicketType],
		   t.RequestDate as [RequestDate],
		   s.Description as [TicketStatus],
		   g.OutDate as [OutDate],
		   e.UserID as [Requester],
		   f.UserID as [AssignTo]
	From  Ticket t, TicketStatus s, Employee e, Employee f, Account a,TicketDefinition d,TicketStages g
	Where s.TicketStatusID = t.TicketStatus
			and e.EmployeeID = t.Requester
			and f.EmployeeID = t.AssignedTo
			and a.AccountID = t.AccountID
			and d.TktDefID = t.TicketTypeID
			and t.CurrentStage = g.stage
			and t.TicketID = g.TicketID
			and a.DebtorID = @DebtorID
	Order by t.TicketID desc
    SET NOCOUNT OFF;
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_PromiseFrequency_Get]    Script Date: 04/09/2008 16:50:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PromiseFrequency_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PromiseFrequency_Get]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Triet Pham
-- Create date: April 9, 2008
-- Description:	Get promise frequencies
-- =============================================
CREATE PROCEDURE CWX_PromiseFrequency_Get
AS
BEGIN
	SET NOCOUNT ON;

    select 
		InfoKey As FrequencyKey,
		[Description],
		[Value]
	from InformationTable where InfoID = 4 AND InfoType = 1 order by InfoID, InfoType

	SET NOCOUNT OFF
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Report_PostLetters]    Script Date: 04/10/2008 10:37:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Report_PostLetters]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Report_PostLetters]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Report_PostLetters]    Script Date: 04/10/2008 10:37:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Report_PostLetters]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Binh Truong
-- Create date: April 09, 2008
-- Description:	Post letter.
-- =============================================
CREATE PROCEDURE dbo.CWX_Report_PostLetters 
AS	
	DECLARE @InTrans bit
	SET @InTrans = 0
	
	IF @@TRANCOUNT = 0
	BEGIN
		BEGIN TRANSACTION
		SET @InTrans = 1
	END
		
	INSERT INTO AccountLetter 
	SELECT AccountID, LetterID, ''S'' as LetterStatus, GETDATE() as LetterDate, RuleId, EmployeeId, AddressType, NULL 
	FROM AccountLetterQueue 
	WHERE XmitStatus = ''P''
	
	IF @@ERROR <> 0
		GOTO ProcError
		
	SET NOCOUNT ON
	DELETE FROM AccountLetterQueue
	WHERE XmitStatus = ''P''
	SET NOCOUNT OFF
	
	IF @@ERROR <> 0
		GOTO ProcError
			
	ProcExit:
		IF @InTrans = 1 
		BEGIN
			SET @InTrans = 0
			COMMIT TRANSACTION
		END
	
	ProcError:
		IF @InTrans = 1
		BEGIN
			SET @InTrans = 0
    		ROLLBACK TRANSACTION
		END
	
	' 
END
GO
