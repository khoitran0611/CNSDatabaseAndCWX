﻿IF(NOT EXISTS (SELECT (1) from dbo.sysobjects 
  WHERE id = object_id(N'[dbo].[CWX_QueueGroup]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1))
BEGIN
	CREATE TABLE [dbo].[CWX_QueueGroup](
		[GroupID] [int] IDENTITY(1,1) NOT NULL,
		[GroupName] [varchar](50) NOT NULL,
		[GroupSeparator] [varchar](50) NULL,
		[SortOrder] [tinyint] NOT NULL,
		[CreatedBy] [int] NOT NULL,
		[CreatedDate] [datetime] NOT NULL,
		[UpdatedBy] [int] NULL,
		[UpdatedDate] [datetime] NULL,
		[IsDefault] [bit] NOT NULL DEFAULT (0),
		[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_QueueGroup_Status]  DEFAULT ('A'),
	 CONSTRAINT [PK_CWX_QueueGroup] PRIMARY KEY CLUSTERED 
	(
		[GroupID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
	
	INSERT INTO [CWX_QueueGroup](GroupName, GroupSeparator, SortOrder, CreatedBy, CreatedDate, IsDefault)
		VALUES ('Default', '----------------', 3,1001, getdate(), 1)
		
	INSERT INTO [CWX_QueueGroup](GroupName, GroupSeparator, SortOrder, CreatedBy, CreatedDate)
		VALUES ('Queue', '----------------', 1,1001, getdate())
		
	INSERT INTO [CWX_QueueGroup](GroupName, GroupSeparator, SortOrder, CreatedBy, CreatedDate)
		VALUES ('Pool', '----------------', 2,1001, getdate())
END
GO

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
	WHERE TABLE_NAME = 'QueryMaster' AND COLUMN_NAME = 'SortOrder')
BEGIN
	ALTER TABLE [dbo].[QueryMaster] 
		ADD [SortOrder] int not null default 9999
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
	WHERE TABLE_NAME = 'QueryMaster' AND COLUMN_NAME = 'QueueGroupID')
BEGIN
	ALTER TABLE [dbo].[QueryMaster] 
		ADD [QueueGroupID] int not null default 1
END
GO

-- [2009-12-09] [Minh Dam]	Add "EmployeeID" column to QueueSortMaster table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'QueueSortMaster' AND COLUMN_NAME = 'EmployeeID')
BEGIN
	ALTER TABLE QueueSortMaster
		ADD EmployeeID int NULL
END
GO


-- [2009-12-09] [Minh Dam]	Alter SP CWX_QueueSortMaster_AddRemove
/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_AddRemove]    Script Date: 12/09/2009 14:20:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
--	[2009-12-08]	Minh Dam		Add parameter @EmployeeID to @QueuePriorities xml
-- =============================================
ALTER PROCEDURE [dbo].[CWX_QueueSortMaster_AddRemove] 
	@QueuePriorities xml
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @tbQueuePriority table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4),
		EmployeeID int
	)

	DECLARE @NewQueueID int
	SET @NewQueueID = 1

	DECLARE @QueueID int
	DECLARE @Description varchar(60)
	DECLARE @EmployeeID int

	DECLARE @SortID int
	IF EXISTS (SELECT QueueId FROM QueueSortMaster WHERE sortid = 0)
		SET @SortID = 0
	ELSE
		SET @SortID = @NewQueueID

	DECLARE QueuePriorityCrsr CURSOR FOR
	SELECT
		ParamValues.QueuePriority.value('./@QueueID','int') AS QueueID,
		ParamValues.QueuePriority.value('./@Description','varchar(60)') AS Description,
		ParamValues.QueuePriority.value('./@EmployeeID', 'int') AS EmployeeID
	FROM
		@QueuePriorities.nodes('/QueuePriorities/QueuePriority') as ParamValues(QueuePriority) 

	OPEN QueuePriorityCrsr

	FETCH NEXT FROM QueuePriorityCrsr
	INTO @QueueID, @Description, @EmployeeID

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @SortID > 0
			SET @SortID = @NewQueueID

		IF @QueueID = 0
			INSERT INTO @tbQueuePriority
			VALUES(@NewQueueID, @Description, '"' + @Description + '"', @SortID, 'ASC ', @EmployeeID)
		ELSE
			INSERT INTO @tbQueuePriority
			SELECT
				@NewQueueID, Description, QueueColumn, @SortID, SortDirection, @EmployeeID
			FROM
				QueueSortMaster
			WHERE
				QueueId = @QueueID AND ISNULL(EmployeeID,0) = @EmployeeID	
		
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM QueuePriorityCrsr
		INTO @QueueID, @Description, @EmployeeID
	END

	DELETE FROM QueueSortMaster WHERE ISNULL(EmployeeID,0) = @EmployeeID
	IF( @@ERROR <> 0)
		GOTO Cleanup

	INSERT INTO QueueSortMaster SELECT * FROM @tbQueuePriority
	IF( @@ERROR <> 0)
		GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE QueuePriorityCrsr
	DEALLOCATE QueuePriorityCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END
GO


-- [2009-12-09] [Minh Dam]	Alter SP CWX_QueueSortMaster_GetAvailable
/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_GetAvailable]    Script Date: 12/09/2009 14:21:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
--	[2009-12-08]	Minh Dam		Add parameter @EmployeeID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_QueueSortMaster_GetAvailable] 
	@EmployeeID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT 
		[DESCRIPTION] = SUBSTRING(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))), 1, LEN(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value])))) - 2)
	INTO #Temp
	FROM
		sys.[columns] c
		LEFT OUTER JOIN sys.[extended_properties] ex ON ex.[major_id] = c.[object_id]
	WHERE
		OBJECTPROPERTY(c.[object_id], 'IsMsShipped')=0
		AND ex.[minor_id] = c.[column_id]
		AND ex.[name] = 'MS_Description'
		AND (
				OBJECT_NAME(c.[object_id]) = 'Account'
				OR OBJECT_NAME(c.[object_id]) = 'Accountother'
				OR OBJECT_NAME(c.[object_id]) = 'DebtorInformation'
				OR OBJECT_NAME(c.[object_id]) = 'PersonInformation'
				OR OBJECT_NAME(c.[object_id]) = 'AccountStatus'
			)
		AND LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))) LIKE '%_Q'
	ORDER BY
		[Description]

	SELECT
		0 AS QueueId,
		Description,
		('"' + Description + '"') AS QueueColumn,
		0 AS sortid,
		'ASC ' AS SortDirection
	FROM
		#Temp
	WHERE
		[Description] NOT IN (SELECT Description FROM QueueSortMaster WHERE ISNULL(EmployeeID,0) = @EmployeeID)
END
GO


-- [2009-12-09] [Minh Dam]	Alter SP CWX_QueueSortMaster_UpdateList
/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_UpdateList]    Script Date: 12/09/2009 14:22:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
--	[2009-12-08]	Minh Dam		Add parameter @EmployeeID to @QueuePriorities xml
-- =============================================
ALTER PROCEDURE [dbo].[CWX_QueueSortMaster_UpdateList] 
	@QueuePriorities xml,
	@Enabled bit
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @QueueID int
	DECLARE @SortDirection char(4)
	DECLARE @SortID int
	DECLARE @EmployeeID int

	IF @Enabled = 1
		SET @SortID = 1
	ELSE
		SET @SortID = 0

	DECLARE @tbQueuePriority table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4),
		EmployeeID int
	)

	DECLARE @NewQueueID int
	SET @NewQueueID = 1

	DECLARE QueuePriorityCrsr CURSOR FOR
	SELECT
		ParamValues.QueuePriority.value('./@QueueID','int') AS QueueID,
		ParamValues.QueuePriority.value('./@SortDirection','char(4)') AS SortDirection,
		ParamValues.QueuePriority.value('./@EmployeeID', 'int') AS EmployeeID
	FROM
		@QueuePriorities.nodes('/QueuePriorities/QueuePriority') as ParamValues(QueuePriority)

	OPEN QueuePriorityCrsr

	FETCH NEXT FROM QueuePriorityCrsr
	INTO @QueueID, @SortDirection, @EmployeeID

	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO @tbQueuePriority
		SELECT
			@NewQueueID, Description, QueueColumn, @SortID, @SortDirection, @EmployeeID
		FROM
			QueueSortMaster
		WHERE
			QueueId = @QueueID AND ISNULL(EmployeeID,0) = @EmployeeID		

		IF @Enabled = 1
			SET @SortID = @SortID + 1
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM QueuePriorityCrsr
		INTO @QueueID, @SortDirection, @EmployeeID
	END

	DELETE FROM QueueSortMaster WHERE ISNULL(EmployeeID,0) = @EmployeeID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	INSERT INTO QueueSortMaster SELECT * FROM @tbQueuePriority
	IF( @@ERROR <> 0)
        GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE QueuePriorityCrsr
	DEALLOCATE QueuePriorityCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END
GO


-- [2009-12-09] [Minh Dam] Alter SP CW_SORT_ORDER
/****** Object:  StoredProcedure [dbo].[CW_SORT_ORDER]    Script Date: 12/09/2009 14:23:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/******   Script Date: 2005/07/15  ******/
-- =============================================
-- Description:	
-- History:
--	2005/07/15	[...]		Init version.
--	2009/12/09	Minh Dam	Add parameter @EmployeeID
-- =============================================
ALTER Procedure [dbo].[CW_SORT_ORDER]
(
	@EmployeeID int = 0,
	@v_SortOrder VarChar(700) OUT
)
AS
BEGIN
    Declare @SortCur Cursor , @v_Description VarChar(700)
	IF NOT EXISTS (SELECT 1 FROM QueueSortMaster WHERE EmployeeID = @EmployeeID)
		SET @EmployeeID = 0

    Set @SortCur=Cursor For Select QueueColumn +  ' ' + Rtrim(Ltrim(SortDirection) )+ ',' Description  
			      From QueueSortMaster 
			     Where SortId<>0 AND ISNULL(EmployeeID,0) = @EmployeeID
				 Order By SortId
    Set @v_SortOrder=''
    Open @SortCur
    Fetch Next From @SortCur Into @v_Description
    While @@Fetch_Status=0 
    Begin
        Set @v_SortOrder=@v_SortOrder+@v_Description
	Fetch Next From @SortCur Into @v_Description
    End
    If @v_SortOrder<>''
    Begin
       Set @v_SortOrder=SubString(@v_SortOrder,1,Len(LTrim(RTrim(@v_SortOrder)))-1)
    End
    Close @SortCur
    DeAllocate @SortCur
END
GO


-- [2009-12-09] [Minh Dam] Alter SP CWX_Account_SearchByQueueAStat
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueAStat]    Script Date: 12/09/2009 14:23:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- History:
--	[2008-04-04]	[Long Nguyen]	Init version.
--	[2009-12-09]	[Minh Dam]		Replace "EXEC CW_SORT_ORDER @v_SortOrder OUT"
--									to "EXEC CW_SORT_ORDER @v_employeeId, @v_SortOrder OUT"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_AgencyStatus int,
--	@IsPending bit = 0,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_employeeId, @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId AS varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID = '+CAST(@v_AgencyStatus AS varchar(9))
--				+ '   AND ISNULL(a.IsPending,0) = '+CAST(@IsPending AS varchar(1))


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO


-- [2009-12-09] [Minh Dam] Alter SP CWX_Account_SearchByQueueSStat
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 12/09/2009 14:25:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- History:
--	[2008-04-04]	[Long Nguyen]	Init version.
--	[2009-12-09]	[Minh Dam]		Replace "EXEC CW_SORT_ORDER @v_SortOrder OUT"
--									to "EXEC CW_SORT_ORDER @v_employeeId, @v_SortOrder OUT"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_SystemStatus int,
	@AccountAge int = -1,
	@MCode int = -1,
	@CCode int = -1,
--	@IsPending bit = 0,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_employeeId, @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId as varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID <> 2'
--				+ '   AND ISNULL(a.IsPending,0) = '+CAST(@IsPending AS varchar(1))

	IF @v_SystemStatus = 0 
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'

	IF ((@v_SystemStatus = 1) or (@v_SystemStatus = 5))
		SET @cStmt=@cStmt+' AND s.SystemStatus = '+CAST(@v_SystemStatus AS varchar(9))+''

	IF @v_SystemStatus = 2
	BEGIN
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'
		SET @cStmt=@cStmt+' AND convert(varchar(10),a.SubmissionDate,121)=convert(varchar(10),GetDate(),121)'+''
	END

	IF @v_SystemStatus = 6 --Pending account
		SET @cStmt=@cStmt+' AND a.IsPending = 1'
	
	IF @AccountAge <> -1
		SET @cStmt=@cStmt+' AND a.AccountAge = '+CAST(@AccountAge AS varchar(9))
	IF @MCode <> -1
		SET @cStmt=@cStmt+' AND a.MCode = '+CAST(@MCode AS varchar(9))
	IF @CCode <> -1
		SET @cStmt=@cStmt+' AND a.CCode = '+CAST(@CCode AS varchar(9))

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO


-- [2009-12-09] [Minh Dam] Alter SP CWX_Account_SearchByPoolPending
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByPoolPending]    Script Date: 12/09/2009 14:26:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- History:
--	[2008-04-04]	[Long Nguyen]	Init version.
--	[2009-12-09]	[Minh Dam]		Replace "EXEC CW_SORT_ORDER @v_SortOrder OUT"
--									to "EXEC CW_SORT_ORDER @v_employeeId, @v_SortOrder OUT"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByPoolPending] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@PoolID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_employeeId, @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '   AND s.SystemStatus in (1,5)'
--				+ '   AND convert(varchar(10),a.SubmissionDate,121)=convert(varchar(10),GetDate(),121)'
				+ '   AND a.OfficeID = '+CAST(@v_employeeId as varchar(9))
				+ '   AND a.EmployeeID = '+CAST(@PoolID as varchar(9))
				+ '   AND a.IsPending = 1'
				+ '	  AND a.PoolSelected = 1'

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO


-- [2009-12-09] [Minh Dam] Alter SP CWX_GetEmployeeNextPoolAccount
/****** Object:  StoredProcedure [dbo].[CWX_GetEmployeeNextPoolAccount]    Script Date: 12/09/2009 14:28:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		KhoaDang
-- History:
--	[2008-04-04]	[Khoa Dang]		Init version.
--	[2009-08-05]	[Phuong Le]		Remove update statement, we must update outside of store
--									  to fix bug, lock account when save
--	[2009-12-09]	[Minh Dam]		Replace "EXEC CW_SORT_ORDER @v_SortOrder OUT"
--									  to "EXEC CW_SORT_ORDER @v_employeeId, @v_SortOrder OUT"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount] 
	@v_currentLoginEmployeeId int,
	@v_employeeId int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_employeeId, @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt =  ' SELECT a.DebtorID, a.AccountID,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN Accountother o ON o.AccountID = a.AccountID'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND a.EmployeeID = '+CAST(@v_employeeId as varchar(9))
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID in (1,5)'
				+ '	  AND a.PoolSelected = 0'

	--Step 4: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'
	
	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	--Step 5: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT top 1 DebtorID, AccountID, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name] INTO #PoolAccount '
				   + 'FROM AccountResults '
				   + @pagingWhereClause	
				   + ' DECLARE @AccountID int '
				   + ' DECLARE @DebtorID int '
				   + ' SELECT @AccountID=AccountID, @DebtorID=DebtorID FROM #PoolAccount '				   
				   + ' SELECT (CONVERT(varchar(10), DebtorID) + ''|'' + CONVERT(varchar(10), AccountID)) AS KeyField, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name] '
				   + ' FROM #PoolAccount '

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)

	--Step 6: Execute the main SQL command.	
	EXEC (@finalStmt)
		
	if (@RowCount > 1)
		RETURN 2

	RETURN @RowCount
END
GO



/****** Object:  Table [dbo].[CWX_Employee_Queue]    Script Date: 12/11/2009 16:09:35 ******/
IF  NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Queue]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_Employee_Queue](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[EmployeeID] [int] NULL,
		[QueueID] [int] NULL,
	 CONSTRAINT [PK_CWX_Employee_Queue] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO


/****** Object:  Table [dbo].[CWX_Employee_QueueItem]    Script Date: 12/11/2009 16:10:34 ******/
IF NOT  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_QueueItem]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_Employee_QueueItem](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[EmployeeID] [int] NULL,
		[QueryMasterID] [int] NULL,
	 CONSTRAINT [PK_CWX_Employee_QueueItem] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_Employee_Queue_GetAssignedQueuesByEmployeeID]    Script Date: 12/11/2009 16:06:32 ******/
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Queue_GetAssignedQueuesByEmployeeID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_Queue_GetAssignedQueuesByEmployeeID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_Queue_GetAssignedQueuesByEmployeeID]    Script Date: 12/11/2009 16:06:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ThanhNguyen
-- Create date: 07-12-2009
-- Description:	Get queues for a employee
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_Queue_GetAssignedQueuesByEmployeeID]
	-- Add the parameters for the stored procedure here
	@EmployeeID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Select QueueID 
	From CWX_Employee_Queue 
	Where EmployeeID = @EmployeeID  
	
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_Employee_Queue_GetAvailableQueuesByEmployeeID]    Script Date: 12/11/2009 16:06:59 ******/
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Queue_GetAvailableQueuesByEmployeeID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_Queue_GetAvailableQueuesByEmployeeID]
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_Queue_GetAvailableQueuesByEmployeeID]    Script Date: 12/11/2009 16:07:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: 07-12-2009
-- Description:	Get list of queues tab that are available for assigning to Employee
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_Queue_GetAvailableQueuesByEmployeeID]
	-- Add the parameters for the stored procedure here
	@EmployeeID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Select distinct CallingApp
	From QueryMaster
	WHERE CallingApp Not in (Select QueueID From CWX_Employee_Queue Where EmployeeID = @EmployeeID)
    
	
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Employee_QueueItem_GetAssignedQueueItemsByEmployeeID]    Script Date: 12/11/2009 16:07:31 ******/
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_QueueItem_GetAssignedQueueItemsByEmployeeID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_QueueItem_GetAssignedQueueItemsByEmployeeID]
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_QueueItem_GetAssignedQueueItemsByEmployeeID]    Script Date: 12/11/2009 16:07:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: 07-12-2009
-- Description:	Get assigned queue items of a Employee
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_QueueItem_GetAssignedQueueItemsByEmployeeID]
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@QueueID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Select eqi.QueryMasterID as ID, qm.Description
	From CWX_Employee_QueueItem eqi INNER JOIN QueryMaster qm On eqi.QueryMasterID = qm.ID
	Where eqi.EmployeeID = @EmployeeID AND qm.CallingApp = @QueueID
	
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_QueueItem_GetAvailableQueueItemsByEmployeeID]    Script Date: 12/11/2009 16:08:02 ******/
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_QueueItem_GetAvailableQueueItemsByEmployeeID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_QueueItem_GetAvailableQueueItemsByEmployeeID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_QueueItem_GetAvailableQueueItemsByEmployeeID]    Script Date: 12/11/2009 16:08:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ThanhNguyen
-- Create date: 07-12-2009
-- Description:	Get available Queue items for assigning to Employee
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_QueueItem_GetAvailableQueueItemsByEmployeeID]
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@QueueID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Select qm.ID, qm.Description
	From QueryMaster qm
	WHERE qm.ID Not in (Select QueryMasterID From CWX_Employee_QueueItem Where EmployeeID = @EmployeeID)
			AND qm.CallingApp = @QueueID
	 	
END
GO


-- [2009-12-14] [Minh Dam] Create SP CWX_QueueGroup_Add
/****** Object:  StoredProcedure [dbo].[CWX_QueueGroup_Add]    Script Date: 12/14/2009 11:43:15 ******/
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_QueueGroup_Add]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_QueueGroup_Add]
GO

/****** Object:  StoredProcedure [dbo].[CWX_QueueGroup_Add]    Script Date: 12/14/2009 11:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 2009-12-11
-- Description:	Add a queue group
-- =============================================
CREATE PROCEDURE [dbo].[CWX_QueueGroup_Add]
	-- Add the parameters for the stored procedure here
	@GroupName varchar(50),
	@GroupSeparator varchar(50),
	@CreatedBy int,
	@CreatedDate datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.

    -- Insert statements for procedure here
	DECLARE @sortOrder tinyint
	SELECT @sortOrder = MAX(SortOrder)
	FROM CWX_QueueGroup

	INSERT INTO CWX_QueueGroup (GroupName, GroupSeparator, SortOrder, CreatedBy, CreatedDate, IsDefault)
	VALUES (@GroupName, @GroupSeparator, @sortOrder+1, @CreatedBy, @CreatedDate, 0)

END
GO


-- [2009-12-14] [Minh Dam] Create SP CWX_QueueGroup_Delete
/****** Object:  StoredProcedure [dbo].[CWX_QueueGroup_Delete]    Script Date: 12/14/2009 11:44:15 ******/
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_QueueGroup_Delete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_QueueGroup_Delete]
GO

/****** Object:  StoredProcedure [dbo].[CWX_QueueGroup_Delete]    Script Date: 12/14/2009 11:44:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 2009-12-14
-- Description:	Delete a queue group and move queue items of this group to default group
-- =============================================
CREATE PROCEDURE [dbo].[CWX_QueueGroup_Delete]
	-- Add the parameters for the stored procedure here
	@QueueGroupID int,
	@SoftDelete bit = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.	

    -- Insert statements for procedure here
	DECLARE @TranStarted bit
	SET @TranStarted = 0

	IF (@@TRANCOUNT = 0)
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END
	
	IF (@SoftDelete = 1)
	BEGIN
		UPDATE CWX_QueueGroup
		SET [Status] = 'R'
		WHERE GroupID = @QueueGroupID
	END
	ELSE
	BEGIN
		DELETE CWX_QueueGroup
		WHERE GroupID = @QueueGroupID
	END
	
	IF (@@ERROR <> 0)
		GOTO CleanUp

	DECLARE @DefaultGroupID int
	SET @DefaultGroupID = 0
	
	-- Get the default group ID
	SELECT TOP 1 @DefaultGroupID = GroupID
	FROM CWX_QueueGroup
	WHERE IsDefault = 1
	
	-- Re-assign queue items of the deleted group to default group
	UPDATE QueryMaster
	SET QueueGroupID = @DefaultGroupID
	WHERE QueueGroupID = @QueueGroupID

	IF (@@ERROR <> 0)
		GOTO CleanUp
	
	IF (@TranStarted = 1)
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
	END

CleanUp:

	IF (@TranStarted = 1)
	BEGIN
		SET @TranStarted = 0
		ROLLBACK TRANSACTION
	END
END
GO


-- [2009-12-14] [Minh Dam] Create SP CWX_QueueGroup_UpdateListOrders
/****** Object:  StoredProcedure [dbo].[CWX_QueueGroup_UpdateListOrders]    Script Date: 12/14/2009 11:44:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_QueueGroup_UpdateListOrders]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_QueueGroup_UpdateListOrders]
GO

/****** Object:  StoredProcedure [dbo].[CWX_QueueGroup_UpdateListOrders]    Script Date: 12/14/2009 11:45:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 2009-12-11
-- Description:	Update the orders of queue groups
-- =============================================
CREATE PROCEDURE [dbo].[CWX_QueueGroup_UpdateListOrders]
	-- Add the parameters for the stored procedure here
	@QueueGroupIDs varchar(200) -- separated by '|'
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON

    -- Insert statements for procedure here
	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END
	
	DECLARE @queueGroupID int
	DECLARE @sortOrder tinyint

	SET @sortOrder = 1

	DECLARE curQueueGroupID CURSOR FOR
		SELECT SplitedText FROM dbo.CWX_FnSplitString(@QueueGroupIDs, '|')

	OPEN curQueueGroupID
	FETCH NEXT FROM curQueueGroupID INTO @queueGroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		UPDATE CWX_QueueGroup
		SET SortOrder = @sortOrder
		WHERE GroupID = @queueGroupID

		SET @sortOrder = @sortOrder + 1

		IF( @@ERROR <> 0)
			GOTO Cleanup		
	
		FETCH NEXT FROM curQueueGroupID INTO @queueGroupID
	END

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE curQueueGroupID
	DEALLOCATE curQueueGroupID

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END	

END
GO