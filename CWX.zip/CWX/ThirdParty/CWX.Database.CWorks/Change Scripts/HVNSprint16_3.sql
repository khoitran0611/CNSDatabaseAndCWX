﻿/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateCustomField]    Script Date: 12/04/2009 11:39:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: 2009-07-28
-- Description:	Bulk update a custom field for a list of accounts
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_UpdateCustomField]
	@ChangedTable varchar(50),
	@ChangedField varchar(50),
	@CustomValue nvarchar(100),	
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
			SELECT CAST(SplitedText AS int) AS AccountID
			FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN			
			--Update account
			DECLARE @Sql nvarchar(500)
			SET @Sql = 
			'UPDATE ' + @ChangedTable +
			' SET ' + @ChangedField + ' = ''' + @CustomValue + '''' +
			' WHERE AccountID = ' + CAST(@AccountID AS varchar(10))
			
			EXEC (@Sql)
			
			IF(@@ERROR <> 0)			
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID			
			SET @NoteText = 'AcctMgmt: ' + @ChangedField + ' change to ' + @CustomValue
			
			INSERT INTO NotesCurrent(EmployeeID, DebtorID, BillID, NoteDateTime, NoteType, NoteText)
			VALUES(@CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
 	
END
GO
