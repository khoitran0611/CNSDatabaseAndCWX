﻿-- Start script for Sprint 2 -----

IF NOT EXISTS (SELECT * FROM IdentityFields WHERE TableName = 'ApplicationBy')
	INSERT INTO IdentityFields(TableName, FieldValue) VALUES ('ApplicationBy', 0)
	GO

/****** Object:  Table [dbo].[CWX_ClientType]    Script Date: 03/20/2009 10:02:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE name = 'CWX_ClientType')
BEGIN
	CREATE TABLE [dbo].[CWX_ClientType](
		[ClientTypeID] [int] IDENTITY(1,1) NOT NULL,
		[Description] [nvarchar](100) NOT NULL,
		[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientType_Status]  DEFAULT ('A'),
	CONSTRAINT [PK_CWX_ClientType] PRIMARY KEY CLUSTERED 
	(
		[ClientTypeID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF

----------------------------

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 18 Mar 2009
-- Description:	Check if an Descitpion is existed in table CWX_CLIENTYPE
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientType_IsDescriptionExisted]
	-- Add the parameters for the stored procedure here
	@ClientTypeID int,
	@Description varchar(100) = ''	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS (SELECT 1 FROM CWX_CLIENTTYPE 
				WHERE	@Description <> '' 
						AND CWX_CLIENTTYPE.Description = @Description 
						AND CWX_CLIENTTYPE.ClientTypeID <> @ClientTypeID
						AND CWX_CLIENTTYPE.Status <>'R')
		RETURN 1
	ELSE 
		RETURN 0
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: March 18, 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientType_SoftDeleteAll] 	
AS
BEGIN
	UPDATE
		CWX_CLIENTTYPE
	SET
		Status = 'R'	
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 03/19/2009 17:59:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description:	Load all accounts with debtorID
-- History:
--	08/04/03	[Tai Ly]	Init version.
--	08/06/01	[Long Nguyen]	Add and remove some fields.
--	08/06/27	[Binh Truong]	Remove BatchNumber field.	
--	08/08/25	[Long Nguyen]	Remove @AdditionalTag
--	08/09/04	[Thuy Nguyen]	Remove CoSigner table reference
--	09/03/19	[Thuy Nguyen]	Remove ClientInformation.ContactName
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int	
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/
	SELECT
			a.AccountID,
			ISNULL(l.LetterDesc, '') AS SENTBY, ISNULL(al.LetterStatus, '') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			p.AmountPromised AS FirstAmountPromised, p.PromiseFrequency AS FirstPromiseFrequency, p.Term AS FirstPromiseTerm, p.DatePromised, '' AS PROMISE,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL,
			lastpromise.LASTPROMISEDATE, lastpromise.LASTPROMISEAMOUNT, lastpromise.LASTPROMISESTATUS, lastpromise.LASTPROMISESTATUSDESC,
			(CASE ISNULL(lg.GroupedAccountID, 0) WHEN 0 THEN 0 ELSE 1 END) AS IsGroupedAccount
	INTO	#AccountTemp
	FROM	Account	 a
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN 'd' THEN 'day(s)'
						WHEN 'w' THEN 'week(s)'
						WHEN 'm' THEN 'month(s)'
						WHEN 'y' THEN 'year(s)'
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get last promise
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised AS LASTPROMISEAMOUNT,
					p2.DatePromised AS LASTPROMISEDATE,
					p2.Status AS LASTPROMISESTATUS,
					CASE p2.Status
						WHEN 0 THEN 'Not Due'
						WHEN 1 THEN 'Paid On Time'
						WHEN 2 THEN 'Paid Late'
						WHEN 3 THEN 'Broken Promise'
						WHEN 4 THEN 'Canceled'
						ELSE ''
					END AS LASTPROMISESTATUSDESC
				FROM AccountPromise p2 
				WHERE p2.PromiseID IN 
						(	SELECT TOP 1 PromiseID
							FROM (	SELECT PromiseID, DatePromised
									FROM AccountPromise 
									WHERE AccountID = p2.AccountID -- 69
							) as temp
							ORDER BY DatePromised DESC
						)) lastpromise ON lastpromise.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	--Check if account is GroupAccount
	LEFT JOIN Legal_Groups lg ON lg.GroupedAccountID = a.AccountID
	WHERE DebtorID = @DebtorID

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, nextAction.CodeDesc AS CurrentNextActionDesc, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, --ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised, #AccountTemp.FirstAmountPromised, #AccountTemp.FirstPromiseFrequency, #AccountTemp.FirstPromiseTerm
			, #AccountTemp.LASTPROMISEDATE, #AccountTemp.LASTPROMISEAMOUNT, #AccountTemp.LASTPROMISESTATUS, #AccountTemp.LASTPROMISESTATUSDESC
			, #AccountTemp.LASTCONTACTDATE, #AccountTemp.LASTCONTACTBY, #AccountTemp.PROMISETOPAY, #AccountTemp.PROMISEKEPT, #AccountTemp.PROMISEBROKEN, #AccountTemp.OUTGOINGCALL, #AccountTemp.NOACTIVITYDAYS
			, ISNULL(Account.IsPending, 0) AS IsPending
			, #AccountTemp.IsGroupedAccount
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID
			LEFT OUTER JOIN AccountCodeMaster nextAction on Account.CurrentNextAction = nextAction.CodeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END
GO

/****** Object:  Table [dbo].[ClientInformation]    Script Date: 03/20/2009 10:15:17 ******/
-- drop old table ClientInformation and create new one with generic fields --

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
	
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' AND c.name = 'CString1' )
BEGIN

	DROP TABLE [dbo].[ClientInformation]	

	/****** Object:  Table [dbo].[ClientInformation]    Script Date: 03/20/2009 10:17:31 ******/
	
	CREATE TABLE [dbo].[ClientInformation](
		[ClientID] [int] IDENTITY(1,1) NOT NULL,
		[ClientName] [nvarchar](50) NOT NULL,
		[Priority] [int] NULL,
		[Active] [bit] NOT NULL,
		[ClientTypeID] [int] NULL,
		[CurrencyID] [int] NULL,
		[ReallocationDay] [tinyint] NULL,
		[AgingForReschedule] [money] NULL,
		[AgingForDiscount] [money] NULL,
		[RescheduleAllowed] [int] NULL,
		[DiscountAllowed] [int] NULL,
		[DeptIDs] [varchar](1000) NULL,
		[LetterheadImage] [image] NULL,
		[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientInformation_Status]  DEFAULT ('A'),
		[CreditorID] [int] NULL,
		[PaymentAllocationRuleID] [int] NULL,
		[AgingForApportion] [money] NULL,
		[ApportionAllowed] [money] NULL,
		[CString1] [nvarchar](25) NULL,
		[CString2] [nvarchar](25) NULL,
		[CString3] [nvarchar](25) NULL,
		[CString4] [nvarchar](25) NULL,
		[CString5] [nvarchar](25) NULL,
		[CString6] [nvarchar](25) NULL,
		[CString7] [nvarchar](25) NULL,
		[CString8] [nvarchar](25) NULL,
		[CString9] [nvarchar](25) NULL,
		[CString10] [nvarchar](25) NULL,
		[CString11] [nvarchar](50) NULL,
		[CString12] [nvarchar](50) NULL,
		[CString13] [nvarchar](50) NULL,
		[CString14] [nvarchar](50) NULL,
		[CString15] [nvarchar](50) NULL,
		[CString16] [nvarchar](50) NULL,
		[CString17] [nvarchar](50) NULL,
		[CString18] [nvarchar](50) NULL,
		[CString19] [nvarchar](50) NULL,
		[CString20] [nvarchar](50) NULL,
		[CString21] [nvarchar](100) NULL,
		[CString22] [nvarchar](100) NULL,
		[CString23] [nvarchar](100) NULL,
		[CString24] [nvarchar](100) NULL,
		[CString25] [nvarchar](100) NULL,
		[CInt1] [int] NULL CONSTRAINT [DF_CWX_ClientInformation_CInt1]  DEFAULT ((0)),
		[CInt2] [int] NULL CONSTRAINT [DF_CWX_ClientInformation_CInt2]  DEFAULT ((0)),
		[CInt3] [int] NULL CONSTRAINT [DF_CWX_ClientInformation_CInt3]  DEFAULT ((0)),
		[CInt4] [int] NULL CONSTRAINT [DF_CWX_ClientInformation_CInt4]  DEFAULT ((0)),
		[CInt5] [int] NULL CONSTRAINT [DF_CWX_ClientInformation_CInt5]  DEFAULT ((0)),
		[CInt6] [int] NULL CONSTRAINT [DF_CWX_ClientInformation_CInt6]  DEFAULT ((0)),
		[CInt7] [int] NULL CONSTRAINT [DF_CWX_ClientInformation_CInt7]  DEFAULT ((0)),
		[CInt8] [int] NULL CONSTRAINT [DF_CWX_ClientInformation_CInt8]  DEFAULT ((0)),
		[CInt9] [int] NULL CONSTRAINT [DF_CWX_ClientInformation_CInt9]  DEFAULT ((0)),
		[CInt10] [int] NULL CONSTRAINT [DF_CWX_ClientInformation_CInt10]  DEFAULT ((0)),
		[CMoney1] [money] NULL CONSTRAINT [DF_CWX_ClientInformation_CMoney1]  DEFAULT ((0)),
		[CMoney2] [money] NULL CONSTRAINT [DF_CWX_ClientInformation_CMoney2]  DEFAULT ((0)),
		[CMoney3] [money] NULL CONSTRAINT [DF_CWX_ClientInformation_CMoney3]  DEFAULT ((0)),
		[CMoney4] [money] NULL CONSTRAINT [DF_CWX_ClientInformation_CMoney4]  DEFAULT ((0)),
		[CMoney5] [money] NULL CONSTRAINT [DF_CWX_ClientInformation_CMoney5]  DEFAULT ((0)),
		[CMoney6] [money] NULL CONSTRAINT [DF_CWX_ClientInformation_CMoney6]  DEFAULT ((0)),
		[CMoney7] [money] NULL CONSTRAINT [DF_CWX_ClientInformation_CMoney7]  DEFAULT ((0)),
		[CMoney8] [money] NULL CONSTRAINT [DF_CWX_ClientInformation_CMoney8]  DEFAULT ((0)),
		[CMoney9] [money] NULL CONSTRAINT [DF_CWX_ClientInformation_CMoney9]  DEFAULT ((0)),
		[CMoney10] [money] NULL CONSTRAINT [DF_CWX_ClientInformation_CMoney10]  DEFAULT ((0)),
		[CBit1] [bit] NULL CONSTRAINT [DF_CWX_ClientInformation_CBit1]  DEFAULT ((0)),
		[CBit2] [bit] NULL CONSTRAINT [DF_CWX_ClientInformation_CBit2]  DEFAULT ((0)),
		[CBit3] [bit] NULL CONSTRAINT [DF_CWX_ClientInformation_CBit3]  DEFAULT ((0)),
		[CBit4] [bit] NULL CONSTRAINT [DF_CWX_ClientInformation_CBit4]  DEFAULT ((0)),
		[CBit5] [bit] NULL CONSTRAINT [DF_CWX_ClientInformation_CBit5]  DEFAULT ((0)),
		[CBit6] [bit] NULL CONSTRAINT [DF_CWX_ClientInformation_CBit6]  DEFAULT ((0)),
		[CBit7] [bit] NULL CONSTRAINT [DF_CWX_ClientInformation_CBit7]  DEFAULT ((0)),
		[CBit8] [bit] NULL CONSTRAINT [DF_CWX_ClientInformation_CBit8]  DEFAULT ((0)),
		[CFLoat1] [float] NULL CONSTRAINT [DF_CWX_ClientInformation_CFLoat1]  DEFAULT ((0)),
		[CFLoat2] [float] NULL CONSTRAINT [DF_CWX_ClientInformation_CFLoat2]  DEFAULT ((0)),
		[CFLoat3] [float] NULL CONSTRAINT [DF_CWX_ClientInformation_CFLoat3]  DEFAULT ((0)),
		[CFLoat4] [float] NULL CONSTRAINT [DF_CWX_ClientInformation_CFLoat4]  DEFAULT ((0)),
		[CFLoat5] [float] NULL CONSTRAINT [DF_CWX_ClientInformation_CFLoat5]  DEFAULT ((0)),
		[CFLoat6] [float] NULL CONSTRAINT [DF_CWX_ClientInformation_CFLoat6]  DEFAULT ((0)),
		[CFLoat7] [float] NULL CONSTRAINT [DF_CWX_ClientInformation_CFLoat7]  DEFAULT ((0)),
		[CFLoat8] [float] NULL CONSTRAINT [DF_CWX_ClientInformation_CFLoat8]  DEFAULT ((0)),
		[CFLoat9] [float] NULL CONSTRAINT [DF_CWX_ClientInformation_CFLoat9]  DEFAULT ((0)),
		[CFLoat10] [float] NULL CONSTRAINT [DF_CWX_ClientInformation_CFLoat10]  DEFAULT ((0)),
	 CONSTRAINT [PK_CWX_ClientInformation] PRIMARY KEY CLUSTERED 
	(
		[ClientID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END

GO
SET ANSI_PADDING OFF
GO
--------------End creating new table ClientInformation----------

/****** Object:  Table [dbo].[CWX_Currency]    Script Date: 03/20/2009 11:11:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CWX_Currency](
	[CurrencyID] [int] IDENTITY(1,1) NOT NULL,
	[CurrencyName] [nvarchar](10) NULL,
	[Symbold] [nvarchar](5) NULL,
 CONSTRAINT [PK_CWX_Currency] PRIMARY KEY CLUSTERED 
(
	[CurrencyID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

---------------------------

IF NOT EXISTS (SELECT * FROM CWX_Currency WHERE CurrencyName='Rupi')
INSERT INTO [dbo].[CWX_Currency]([CurrencyName],[Symbold])
     VALUES ('Rupi', 'Rp')

IF NOT EXISTS (SELECT * FROM CWX_Currency WHERE CurrencyName='USD')
INSERT INTO [dbo].[CWX_Currency]([CurrencyName],[Symbold])
     VALUES ('USD', '$')

IF NOT EXISTS (SELECT * FROM CWX_Currency WHERE CurrencyName='Pound')
INSERT INTO [dbo].[CWX_Currency]([CurrencyName],[Symbold])
     VALUES ('Pound', '£')

IF NOT EXISTS (SELECT * FROM CWX_Currency WHERE CurrencyName='EUR')
INSERT INTO [dbo].[CWX_Currency]([CurrencyName],[Symbold])
     VALUES ('EUR', '€')

IF NOT EXISTS (SELECT * FROM CWX_Currency WHERE CurrencyName='JPY')
INSERT INTO [dbo].[CWX_Currency]([CurrencyName],[Symbold])
     VALUES ('JPY', '¥')

GO
--------------

/****** Object:  Table [dbo].[CWX_ClientInformation_Dict]    Script Date: 03/20/2009 11:39:04 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CWX_ClientInformation_Dict](
	[FieldName] [varchar](50) NOT NULL,
	[FieldDesc] [nvarchar](100) NOT NULL,
	[Displayed] [bit] NOT NULL CONSTRAINT [DF_CWX_ClientInformation_Dict_Displayed]  DEFAULT ((1)),
	[Editable] [bit] NOT NULL CONSTRAINT [DF_CWX_ClientInformation_Dict_Editable]  DEFAULT ((1)),
	[GroupID] [int] NOT NULL CONSTRAINT [DF_CWX_ClientInformation_Dict_GroupID]  DEFAULT ((0)),
	[GroupDesc] [nvarchar](50) NULL,
	[DisplayOrder] [int] NOT NULL CONSTRAINT [DF_CWX_ClientInformation_Dict_DisplayOrder]  DEFAULT ((0)),
	[TabID] [int] NOT NULL CONSTRAINT [DF_CWX_ClientInformation_Dict_TabID]  DEFAULT ((1)),
	[TabDesc] [nvarchar](30) NULL,
	[RangeID] [tinyint] NULL CONSTRAINT [DF_CWX_ClientInformation_Dict_RangeID]  DEFAULT ((0)),
	[DropDown] [int] NOT NULL CONSTRAINT [DF_CWX_ClientInformation_Dict_DropDowID]  DEFAULT ((0))
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

---------------------------
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_DropDownDataDictionary' and c.name = 'Listed')

BEGIN
	ALTER TABLE CWX_DropDownDataDictionary
	ADD Listed [bit] NOT NULL DEFAULT(0)
END
GO

/****** Object:  Table [dbo].[CWX_ClientEmployee]    Script Date: 03/20/2009 14:25:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CWX_ClientEmployee](
	[EmployeeID] [int] NOT NULL,
	[ClientID] [int] NOT NULL,
 CONSTRAINT [PK_CWX_ClientEmployee] PRIMARY KEY CLUSTERED 
(
	[EmployeeID] ASC,
	[ClientID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
----------------------------

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_GetAssignedClients]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientInformation_GetAssignedClients]
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 19 Mar 2009
-- Description:	Get All clients that are assigned to a @Employee parameter
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientInformation_GetAssignedClients]
	-- Add the parameters for the stored procedure here
	@EmployeeID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT ci.ClientID, ClientName
	FROM ClientInformation ci
	WHERE ci.ClientID IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID)
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 19 Mar 2009
-- Description:	Get All clients that is not assigned to a @Employee parameter
-- =============================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_GetAvailableClients]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientInformation_GetAvailableClients]
GO

CREATE PROCEDURE [dbo].[CWX_ClientInformation_GetAvailableClients]
	-- Add the parameters for the stored procedure here
	@EmployeeID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT ci.ClientID, ClientName
	FROM ClientInformation ci
	WHERE ci.ClientID not in (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID)
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 20 Mar 2009
-- Description:	Delete all clients that are assigned to this @EmployeeID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientEmployee_Delete]
	-- Add the parameters for the stored procedure here
	@EmployeeID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DELETE CWX_ClientEmployee
	WHERE EmployeeID = @EmployeeID
END
GO

-------Thuy Nguyen added on 20-March-2009-----------------


IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'CWX_CustomDefinedFields' AND c.name = 'ClientID')
BEGIN
	ALTER TABLE CWX_CustomDefinedFields ADD ClientID [int] DEFAULT 0
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'DefineFees' AND c.name = 'ClientID')
BEGIN
	ALTER TABLE DefineFees ADD ClientID [int] DEFAULT 0
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'AccountCodeMaster' AND c.name = 'ClientID')
BEGIN
	ALTER TABLE AccountCodeMaster ADD ClientID [int] DEFAULT 0
END
GO

-------End of Thuy Nguyen added on 20-March-2009-----------------

-------Thuy Nguyen added on 23-March-2009-----------------

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'RuleTable' AND c.name = 'ClientID')
BEGIN
	ALTER TABLE RuleTable ADD ClientID [int] DEFAULT 0
END

GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'DefineLetters' AND c.name = 'ClientID')
BEGIN
	ALTER TABLE DefineLetters ADD ClientID [int] DEFAULT 0
END

GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'ReportScheduleTable' AND c.name = 'ClientID')
BEGIN
	ALTER TABLE ReportScheduleTable ADD ClientID [int] DEFAULT 0
END

GO
-------End of Thuy Nguyen added on 23-March-2009-----------------

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ===================================================================================
-- Author:		Tuan Luong
-- Create date: Jan 28th, 2008
-- Description:	Delete all standard notes (InfoID = 4, InfoType = 6, InfoSubType = 0)
-- Thanh Nguyen: changed on March 26. InfoSubType = 0 no longer exist because InfoSubType is
-- reserved for storing ClientID. When delete all Standard Notes will delete records that
-- Has InfoID = 4 and InfoType = 6
-- ===================================================================================
ALTER PROCEDURE [dbo].[CWX_InformationTable_StandardNote_DeleteAll] 	
	@InfoID int = 4,
	@InfoType int = 6	
AS
BEGIN
	SET NOCOUNT ON;    
	DELETE InformationTable
	WHERE	InfoID = @InfoID
			AND	InfoType = @InfoType			
END
GO
-------------------
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT  c.name from sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_PersonInformation_Dict' AND c.name='DropDown')
	BEGIN
		ALTER TABLE CWX_PersonInformation_Dict
		ADD [DropDown] [int] NOT NULL CONSTRAINT [DF_CWX_PersonInformation_Dict_DropDown]  DEFAULT ((0))
	END
GO
------------------
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thuy Nguyen
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an person
-- History:
--	[06 Mar 2009]	Thuy Nguyen		Init version.
--	[20 Mar 2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
	@PersonID int,
	@PageNumber int = 1,
	@Client int = 0,
	@PageSize int = 10, -- it's only used for function parameter
	@PageIndex int = 0 -- it's only used for function parameter
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 			
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[Editable],			
			b.[DataType],
			b.[MaxLength],			
			a.[DropDown],
			ISNULL(c.[SQL], '') as SQLDropDown
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [GroupID], [GroupDesc], [DisplayOrder],[Editable], [DropDown] 
		FROM CWX_PersonInformation_Dict
		WHERE Displayed = 1	and PageNumber = @PageNumber and Client = @Client) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'PersonInformation' and [Type]='U')			
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'PersonID, LastName, FirstName, MiddleName, PString1'
	
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM PersonInformation WHERE PersonID = ' + Cast(@PersonID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup

	DECLARE @PageCount int
	SELECT @PageCount = MAX(PageNumber) 
	FROM CWX_PersonInformation_Dict 
	WHERE Displayed = 1 AND (@Client = 0 OR ISNULL(Client, 0) = 0 OR Client = @Client)

	RETURN @PageCount
END
GO


-- Alter stored procedure CWX_Debtor_Search
/****** Object:  StoredProcedure [dbo].[CWX_Debtor_Search]    Script Date: 03/27/2009 09:43:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 05 Mar 2009
-- Description:	Search debtor by debtor's name and group name
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Debtor_Search]
	-- Add the parameters for the stored procedure here
	@DebtorName varchar(50) = '',
	@GroupName varchar(50) = '',
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @Sql nvarchar(1000), @Params nvarchar(100)
	DECLARE @NewLine varchar(2)
	SET @NewLine = '
'

	SET @Params = '@PageSize int, @PageIndex int, @RowCount int OUTPUT'
	SET @Sql = 
'SELECT ROW_NUMBER() OVER (ORDER BY d.GroupName) as RowNumber,
		d.DebtorID, d.GroupName, 
		ISNULL(p.FirstName,'''') + '' '' + ISNULL(p.MiddleName,'''') + '' '' + ISNULL(p.LastName,'''') as FullName
INTO #temp
FROM DebtorInformation d
	INNER JOIN PersonInformation p ON d.PersonID = p.PersonID
WHERE 1=1' + @NewLine

	IF (@DebtorName <> '')
		SET @Sql = @Sql + 'AND (p.FirstName like ''@@DebtorName%'' OR p.MiddleName like ''@@DebtorName%'' OR p.LastName like ''@@DebtorName%'')' + @NewLine
	
	IF (@GroupName <> '')
		SET @Sql = @Sql + 'AND d.GroupName = ''' + @GroupName + '''' + @NewLine

	SET @Sql = @Sql + 'SELECT @RowCount = COUNT(*) FROM #temp' + @NewLine
	SET @Sql = @Sql + 
'SELECT DebtorID, GroupName, FullName FROM #temp
WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize'

	SET @Sql = REPLACE(@Sql, '@@DebtorName', @DebtorName)

	DECLARE @RowCount int
	Exec sp_executesql @Sql, @Params, @PageSize, @PageIndex, @RowCount OUTPUT

	RETURN @RowCount
END
GO


-- Create stored procedure CWX_Product_GetDynamicFields
/****** Object:  StoredProcedure [dbo].[CWX_Product_GetDynamicFields]    Script Date: 03/27/2009 09:44:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_GetDynamicFields]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Product_GetDynamicFields]    Script Date: 03/27/2009 09:45:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 17 Mar 2009
-- Description:	Get dynamic fields and data of an client
-- History:
--	[17 Mar 2009]	Minh Dam	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Product_GetDynamicFields]
	-- Add the parameters for the stored procedure here
	@ClientID int,
	@TabID int = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			b.[DataType],
			b.[MaxLength],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as SQLDropDown,
			ISNULL(c.Listed, 0) as Listed
			
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], [DisplayOrder], [DropDown], [RangeID]
		FROM CWX_ClientInformation_Dict
		WHERE Displayed = 1	AND TabID = @TabID
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'ClientInformation' AND [Type]='U')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000)
	DECLARE @FieldName varchar(50)
	SET @FieldNameList = 'ClientID,ClientName,Priority,AgingForReschedule,AgingForDiscount,RescheduleAllowed,DiscountAllowed,LetterheadImage,CreditorID,PaymentAllocationRuleID,AgingForApportion,ApportionAllowed' --ClientActive

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(1000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM ClientInformation WHERE ClientID = ' + Cast(@ClientID as varchar)
	
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

	DECLARE @PageCount int
	SELECT @PageCount = MAX(PageNumber) 
	FROM CWX_AccountInformation_Dict 
	WHERE Displayed = 1 AND (@ClientID = 0 OR ISNULL(Client,0) = 0 OR Client = @ClientID)

	RETURN @PageCount
END
GO


-- Create store procedure CWX_Product_GetAllTabs
/****** Object:  StoredProcedure [dbo].[CWX_Product_GetAllTabs]    Script Date: 03/27/2009 09:46:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetAllTabs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_GetAllTabs]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Product_GetAllTabs]    Script Date: 03/27/2009 09:46:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 17 Mar 2009
-- Description:	Get all tabs for client information
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Product_GetAllTabs]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @TabID int
	DECLARE curTab CURSOR FOR
		SELECT DISTINCT TabID
		FROM CWX_ClientInformation_Dict
		ORDER BY TabID

	CREATE TABLE #temp(TabID int, TabDesc nvarchar(30))

	OPEN curTab
	FETCH NEXT FROM curTab INTO @TabID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		INSERT INTO #temp
			SELECT TOP 1 TabID, TabDesc FROM CWX_ClientInformation_Dict WHERE TabID = @TabID
		FETCH NEXT FROM curTab INTO @TabID
	END

	CLOSE curTab
	DEALLOCATE curTab

	SELECT * FROM #temp
	DROP TABLE #temp
END
GO


-- Alter stored procedure CWX_Account_GetDynamicFields
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDynamicFields]    Script Date: 03/27/2009 09:47:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an account
-- History:
--	[06 Mar 2009]	Minh Dam		Init version.
--	[20 Mar 2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_GetDynamicFields]
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageNumber int = 1,
	@ClientID int = 0,
	@PageSize int = 1, -- it's only used for function parameter
	@PageIndex int = 0 -- it's only used for function parameter
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[TableID],
			a.[DropDown],
			b.[DataType],
			b.[MaxLength],
			CASE WHEN a.[DropDown] > 0 THEN (SELECT [SQL] FROM CWX_DropDownDataDictionary WHERE ID = a.[DropDown])
				ELSE ''
			END AS SQLDropDown
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], [DisplayOrder], [DropDown], [TableID]
		FROM CWX_AccountInformation_Dict
		WHERE Displayed = 1	AND PageNumber = @PageNumber
			AND (@ClientID = 0 OR ISNULL(Client, 0) = 0 OR Client = @ClientID)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Account' AND [Type]='U')
			OR object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'AccountOther' AND [Type]='U')
		) b 
		ON a.[FieldName] = b.[ColumnName]
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList_Account varchar(4000), @FieldNameList_AccountOther varchar(4000)
	DECLARE @FieldName varchar(50), @TableID int
	SET @FieldNameList_Account = 'AccountID,InvoiceNumber,DebtorID,EmployeeID,ClientID,QueueDate,AgencyStatusID,SystemStatusID,ActionCodeID,OfficeID,MCode,CCode,BucketMovement,SubmissionDate,LastEditDate,LastEditBy,CurrencyCode,InterfaceID,CloseDate'
	SET @FieldNameList_AccountOther = 'AccountID'

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName, TableID FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF (@TableID = 1) -- Account table
			SET @FieldNameList_Account = @FieldNameList_Account + ',' + @FieldName
		ELSE IF (@TableID = 2) -- AccountOther table
			SET @FieldNameList_AccountOther = @FieldNameList_AccountOther + ',' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql1 varchar(1000), @Sql2 varchar(1000)
	SET @Sql1 = 'SELECT ' + @FieldNameList_Account + ' FROM Account WHERE AccountID = ' + Cast(@AccountID as varchar)
	SET @Sql2 = 'SELECT ' + @FieldNameList_AccountOther + ' FROM AccountOther WHERE AccountID = ' + Cast(@AccountID as varchar)
	
	EXEC (@Sql1)
	EXEC (@Sql2)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

	DECLARE @PageCount int
	SELECT @PageCount = MAX(PageNumber) 
	FROM CWX_AccountInformation_Dict 
	WHERE Displayed = 1 AND (@ClientID = 0 OR ISNULL(Client,0) = 0 OR Client = @ClientID)

	RETURN @PageCount
END
GO


-- Alter store procedure CWX_Collateral_GetDynamicFields
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 03/27/2009 09:48:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: 15/08/2008
-- Description:	Get dynamic fields of a collateral
-- History:
--	[06 Mar 2009]	Thuy Nguyen		Init version.
--	[20 Mar 2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
-- =============================================				
ALTER PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
	@CollateralID int,
	@ClientID int = 0,
	@CollateralTypeID int = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @CollateralID <> 0 AND @CollateralTypeID IS NULL
		SELECT @CollateralTypeID = CollateralType FROM Collateral WHERE ID = @CollateralID

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			b.[DataType],
			b.[MaxLength]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], [DisplayOrder]
		FROM CWX_Collateral_Dict
		WHERE Displayed = 1	AND (@ClientID = 0 OR ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID) AND (@CollateralTypeID = 0 OR ISNULL(CollateralTypeID, 0) = 0 OR CollateralTypeID = @CollateralTypeID)) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Collateral' and [Type]='U')
			AND (c.[name] LIKE 'CInt%' OR c.[name] LIKE 'CString%' OR c.[name] LIKE 'CDate%' OR c.[name] LIKE 'CMoney%')
		) b 
		ON a.[FieldName] = b.[ColumnName]
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'ID,AccountID,HostCollateralID,EmployeeID,NextActionDate,Image,ImageFileName,'
	SET @FieldNameList = @FieldNameList + 
		'(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6) IS NOT NULL THEN CollateralType ELSE 0 END) AS CollateralType,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7) IS NOT NULL THEN CollateralStage ELSE 0 END) AS CollateralStage,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2) IS NOT NULL THEN NextAction ELSE 0 END) AS NextAction'
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM Collateral WHERE ID = ' + Cast(@CollateralID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup
END
GO


-- Alter stored procedure CWX_RuleTable_FillPagingList
/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_FillPagingList]    Script Date: 03/27/2009 09:50:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: 2008-12-29
-- Description:	
-- History:
--	[29 Dec 2008]	Long Nguyen		Init version.
--	[23 Mar 2009]	Minh Dam		Add one parameter "ClientID"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_RuleTable_FillPagingList] 
	-- Add the parameters for the stored procedure here
	@RuleType tinyint,
	@RuleID int = 0,
	@Description varchar(100) = '',
	@ClientID int = 0,
	@PageSize int,
	@PageIndex int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(ID)
	FROM RuleTable
	WHERE
		RuleType = @RuleType
		AND (@RuleID = 0 OR ID = @RuleID)
		AND Description LIKE ('%' + @Description + '%')
		AND (@ClientID = 0 OR ClientID = @ClientID)	

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER(ORDER BY Description) as RowNumber,
				*
		FROM RuleTable
		WHERE
			RuleType = @RuleType
			AND (@RuleID = 0 OR ID = @RuleID)
			AND Description LIKE ('%' + @Description + '%')
			AND (@ClientID = 0 OR ClientID = @ClientID)
	)

	SELECT 	*
	FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO


-- Alter stored procedure CWX_RuleCriteria_GetMatchingCriteriaListByCriteria
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]    Script Date: 03/27/2009 09:53:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- History:
--	[26 Mar 2009]	Minh Dam		Add one parameter "ClientID"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]
	@InterfaceDBName varchar(125),
	@TableName varchar(125),
	@ColumnName varchar(125),
	@ClientID int = 0
AS
BEGIN
	DECLARE @Sql varchar(2000)
	
	select @Sql = [SQL] from CWX_DataDictionary where ColumnName = @TableName + '.' + @ColumnName
	if (@Sql is null)
	begin
		SET @Sql = 'SELECT DISTINCT ' + @ColumnName + ' FROM ' + @InterfaceDBName + '..' + @TableName
		SET @Sql = @Sql + ' WHERE ' + @ColumnName + ' is not NULL'
		SET @Sql = @Sql + ' AND Len(' + @ColumnName + ') > 0'
		IF EXISTS (SELECT 1 FROM sys.columns WHERE [name] = 'ClientID' AND [object_id] = (SELECT [object_id] FROM sys.objects WHERE [object_id] = OBJECT_ID(@TableName) AND [type] IN (N'U')))
		   AND @ClientID > 0
			SET @Sql = @Sql + ' AND ClientID = ' + Cast(@ClientID as varchar)

		SET @Sql = @Sql + ' ORDER BY ' + @ColumnName	
	end
	
	EXEC(@Sql)
END
GO


-- Alter store procedure CWX_ReportScheduleTable_GetCustomPagingList
/****** Object:  StoredProcedure [dbo].[CWX_ReportScheduleTable_GetCustomPagingList]    Script Date: 03/27/2009 09:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- History:
--	[26 Mar 2009]	Minh Dam		Add one parameter "ClientID"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_ReportScheduleTable_GetCustomPagingList] 
	@ClientID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(ID)
	FROM ReportScheduleTable
	WHERE @ClientID = 0 OR ClientID = @ClientID

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY r.ID) AS RowNumber,
				r.ID, 
				r.ReportID, 
				r.ScheduleType, 
				r.Description, 
				r.ScheduleStatus, 
				r.ScheduledDay, 
				r.BeginDate, 
				r.EndDate, 
				d.LetterDesc
		FROM ReportScheduleTable AS r 
			INNER JOIN DefineLetters AS d ON r.ReportID = d.LetterID
		WHERE @ClientID = 0 OR r.ClientID = @ClientID
    )

	SELECT	* FROM	Temp
	WHERE	(@PageSize <= 0) OR (RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize))
	
	RETURN @RowCount

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Employee_SearchActiveEmployee]    Script Date: 03/27/2009 11:41:04 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Search employee with active status only.
-- History:
--	2008/08/15	[Binh Truong]	Init version.
--  2009/03/19  [Thanh Nguyen] Search Employees that are assinged to specific client. 
--              Results employees must be in table CWX_ClientEmployee  
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Employee_SearchActiveEmployee]
	@EmployeeID int = 0,
	@EmployeeName varchar(50) = '',
	@Department int = 0,
	@IsEmployeePool bit,
	@RoleID int = 0,
	@ClientID int = 0,	
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	--This only used in MainPage (Refer to), if employee is supervisor -> only select supervisor
	DECLARE @Supervisor bit
	IF @EmployeeID > 0
		SELECT	@Supervisor = Supervisor	
		FROM	Employee
		WHERE	EmployeeID = @EmployeeID AND EmployeeStatus = 'A'

	--Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowNumber BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '

	--Step 3: Populate the main SELECT command.
	DECLARE @cStmt varchar(4000)
	SET @cStmt = 'SELECT e.EmployeeID, e.UserID, e.EmployeeName, ISNULL(d.DeptDesc, '''') AS Department, e.RoleID, e.Description, '
			 + ' CASE e.Supervisor WHEN 1 THEN ''Y'' ELSE '''' END AS Supervisor '
			 + ' FROM Employee e LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID AND (d.Status <> ''R'') '
			 + ' WHERE (e.EmployeeName LIKE (''%' + @EmployeeName + '%'')) '
			 + ' AND (' + STR(@Department) + '= 0 OR e.Department = ' + STR(@Department) + ') '
			 + ' AND (' + STR(@RoleID) + '= 0 OR e.RoleID = ' + STR(@RoleID) + ') AND (ISNULL(EmployeeStatus, '''') = ''A'') '
			 + ' AND (' + ISNULL(STR(@Supervisor), '1') + '= 1 OR e.Supervisor = 1) '
	
	IF (@IsEmployeePool = 1)
		SET @cStmt = @cStmt + ' AND EmployeeType=''P'' '

	---Step 3_1: EmployeeIds must be belong to @ClientID of table CWX_ClientEmployee
	--@ClientID = 0 : means select all employees of all clients
	if(@ClientID > 0)
		SET @cStmt = @cStmt + ' AND e.EmployeeID IN ( SELECT EmployeeID FROM CWX_ClientEmployee WHERE ClientID = ' + STR(@ClientID) +  ' OR  0 = ' + STR(@ClientID)+ ')'
	
	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
	DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH EmployeeList AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + 'SELECT * FROM EmployeeList ' + @pagingWhereClause
	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)

	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)

	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT
	
	RETURN @RowCount
END

--- Closed ---