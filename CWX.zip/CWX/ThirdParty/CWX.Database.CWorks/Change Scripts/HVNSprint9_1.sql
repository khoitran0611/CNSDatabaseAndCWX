﻿IF(NOT EXISTS(SELECT * FROM IDENTITYFIELDS WHERE TableName = 'ShowRelatedPartiesListOfARelatedParty'))	
BEGIN	
	INSERT INTO IDENTITYFIELDS
	VALUES('ShowRelatedPartiesListOfARelatedParty',0)
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_GetRelatedPartyListOfARelatedParty]    Script Date: 07/23/2009 10:16:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_GetRelatedPartyListOfARelatedParty]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CosigneeInformation_GetRelatedPartyListOfARelatedParty]

GO

/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_GetRelatedPartyListOfARelatedParty]    Script Date: 07/23/2009 10:19:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_GetRelatedPartyListOfARelatedParty]
	@PersonID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	Declare @DebtorID int
	DECLARE @rowCount int
	SELECT @DebtorID = DebtorID
	FROM DebtorInformation
	WHERE PersonID = @PersonID
    -- Insert statements for procedure here
	SELECT	a.RowNumber, a.FullName, a.Relationship_no, a.SocialSecurityNumber, 
			a.GroupName, a.Address, a.City, a.State, a.Zip
	FROM (
			SELECT	ROW_NUMBER() OVER (ORDER BY  (p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + p.LastName)) AS RowNumber,
			c.PersonID,
			(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName,			
			(r.Code + ' - ' + r.Description) AS Relationship_no,p.SocialSecurityNumber,
            c.Relationship_no as GroupName,   
			ISNULL(pa.Address1,'') as Address,
			ISNULL(pa.City,'') as City,
			ISNULL(pa.State,'') as State,
			ISNULL(pa.Zip,'') as Zip			
		FROM CosigneeInformation c
		JOIN PersonInformation p ON c.PersonID = p.PersonID
		JOIN PersonAddress pa ON pa.PersonID = p.PersonID
		LEFT JOIN Legal_RelationshipTypes r ON CAST(r.RelationshipTypeID AS varchar(20)) = c.Relationship_Type
			WHERE pa.AddressType = 2 AND c.DebtorID = @DebtorID
	)a
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	SELECT @rowCount = count(*)
	FROM CosigneeInformation c
		JOIN PersonInformation p ON c.PersonID = p.PersonID
		JOIN PersonAddress pa ON pa.PersonID = p.PersonID
		LEFT JOIN Legal_RelationshipTypes r ON CAST(r.RelationshipTypeID AS varchar(20)) = c.Relationship_Type
	WHERE pa.AddressType = 2 AND c.DebtorID = @DebtorID 	
	RETURN @rowCount
END
GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_PersonInformation_Dict' AND COLUMN_NAME = N'Checkbox' )
BEGIN
	ALTER TABLE CWX_PersonInformation_Dict
		ADD Checkbox BIT default 0
END 

GO 

UPDATE CWX_PersonInformation_Dict SET Checkbox = 'false' WHERE Checkbox is null

GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_AccountInformation_Dict' AND COLUMN_NAME = N'Checkbox' )
BEGIN
	ALTER TABLE CWX_AccountInformation_Dict
		ADD Checkbox BIT default 0
END 
GO

UPDATE CWX_AccountInformation_Dict SET Checkbox = 'false' WHERE Checkbox is null

GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_Collateral_Dict' AND COLUMN_NAME = N'Checkbox' )
BEGIN
	ALTER TABLE CWX_Collateral_Dict
		ADD Checkbox BIT default 0
END 
GO

UPDATE CWX_Collateral_Dict SET Checkbox = 'false' WHERE Checkbox is null

GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_ClientInformation_Dict' AND COLUMN_NAME = N'Checkbox' )
BEGIN
	ALTER TABLE CWX_ClientInformation_Dict
		ADD Checkbox BIT default 0
END 
GO

UPDATE CWX_ClientInformation_Dict SET Checkbox = 'false' WHERE Checkbox is null

GO


/****** Object:  StoredProcedure [dbo].[CWX_Person_GetDynamicFields]    Script Date: 07/23/2009 10:16:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Person_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Person_GetDynamicFields]

GO

/****** Object:  StoredProcedure [dbo].[CWX_Person_GetDynamicFields]    Script Date: 07/23/2009 13:16:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thuy Nguyen
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an person
-- History:
--	[06-Mar-2009]	Thuy Nguyen		Init version.
--	[20-Mar-2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[10-Apr-2009]	Thanh Nguyen	Add parameter "@CMSEditable"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam		Rename parameter @PageNumber to @TabID
--									Rename parameter @Client to @ClientID
--									Remove parameters @PageSize, @PageIndex
--									Change from Page view to Tab view
--  [02-June-2009]	ThanhNguyen		Remove @ClientID from parameter list. Because base on Issue 68: DebtorInformation And PersonInformation don't have ClientID
--  [26-June-2009]	ThanhNguyen		Change default value of @TabID  from 1 to -1. If @TabID = -1 then first tabID will be got
--  [23-July-2009]	Phuong Le		Add "Checkbox" field
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
	@PersonID int,
	@TabID int = -1,	
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--In case dont pass TabID, first tab of ClientID will be selected
	IF(@TabID = -1)
	BEGIN
		DECLARE @AllTabsTable TABLE
		(	TabID int,
			TabDesc nvarchar(1000)	
		)

		INSERT INTO @AllTabsTable
		exec [CWX_PersonInformation_GetAllTabs]
		SELECT top 1 @TabID = TabID FROM @AllTabsTable 	
	END
	--
    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc],
			b.[DataType],
			b.[MaxLength],
			a.[Editable],
			a.[GroupID],
			a.[GroupDesc], 
			a.[DisplayOrder],			
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup],
			ISNULL(a.Checkbox,0) as [Checkbox]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], CASE WHEN @CMSEditable = 1 THEN [CMSEdit] ELSE [Editable] END as [Editable],
				[GroupID], [GroupDesc], [DisplayOrder], [RangeID], [DropDown], [Mandatory], [Checkbox]
		FROM	CWX_PersonInformation_Dict
		WHERE	Displayed = 1 AND TabID = @TabID
				AND (@CMSEditable = 0 OR (@CMSEditable = 1 AND [CMSEdit] = 1))				
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'PersonInformation' and [Type]='U')			
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'PersonID, LastName, FirstName, MiddleName, PString1'
	
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM PersonInformation WHERE PersonID = ' + Cast(@PersonID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup

END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 07/23/2009 13:31:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]

GO

/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 07/23/2009 13:31:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Minh Dam
-- Create date: 15/08/2008
-- Description:	Get dynamic fields of a collateral
-- History:
--	[06 Mar 2009]	Thuy Nguyen		Init version.
--	[20 Mar 2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory", "RangeID", "DropDown", "SQLDropDown", "Listed" field columns into returned dynamic fields tables
--	[26-Jun-2009]	ThanhNguyen		Change default value of @TabID from 1 to -1. If @TabID = -1 then get first TabID of @CLientID
--  [23-July-2009]	Phuong Le		Add "Checkbox" field
-- =============================================				
CREATE PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
	@CollateralID int,
	@TabID int = -1,
	@ClientID int = 0,
	@CollateralTypeID int = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @CollateralID > 0 AND @CollateralTypeID IS NULL
		SELECT @CollateralTypeID = CollateralType FROM Collateral WHERE ID = @CollateralID
	
	-- Get first tabID of ClientID
	IF(@TabID = -1)
	BEGIN
		DECLARE @AllTabsTable TABLE
		(	TabID int,
			TabDesc nvarchar(1000)	
		)

		INSERT INTO @AllTabsTable
		exec CWX_Collateral_GetAllTabs  @CollateralID, @ClientID,@CollateralTypeID
		SELECT top 1 @TabID = TabID FROM @AllTabsTable 	
	END

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc],
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc],
			a.[DisplayOrder],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup],
			ISNULL(a.Checkbox,0) as [Checkbox]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], 
				[DisplayOrder], [DropDown], [RangeID], [Mandatory],[Checkbox]
		FROM CWX_Collateral_Dict
		WHERE Displayed = 1 AND TabID = @TabID
			AND (@ClientID = 0 OR ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)
			AND (@CollateralTypeID = 0 OR ISNULL(CollateralTypeID, 0) = 0 OR CollateralTypeID = @CollateralTypeID)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Collateral' and [Type]='U')
			AND (c.[name] LIKE 'CInt%' OR c.[name] LIKE 'CString%' OR c.[name] LIKE 'CDate%' OR c.[name] LIKE 'CMoney%')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'ID,AccountID,HostCollateralID,EmployeeID,NextActionDate,Image,ImageFileName,'
	SET @FieldNameList = @FieldNameList + 
		'(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6) IS NOT NULL THEN CollateralType ELSE 0 END) AS CollateralType,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7) IS NOT NULL THEN CollateralStage ELSE 0 END) AS CollateralStage,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2) IS NOT NULL THEN NextAction ELSE 0 END) AS NextAction'
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM Collateral WHERE ID = ' + Cast(@CollateralID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields

	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup
END
Go

/****** Object:  StoredProcedure [dbo].[CWX_Product_GetDynamicFields]    Script Date: 07/23/2009 13:32:08 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_GetDynamicFields]

GO

/****** Object:  StoredProcedure [dbo].[CWX_Product_GetDynamicFields]    Script Date: 07/23/2009 13:32:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 17 Mar 2009
-- Description:	Get dynamic fields and data of an client
-- History:
--	[17 Mar 2009]	Minh Dam	Init version.
--	[22-Apr-2009]	Minh Dam	Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam	Remove parameters @PageSize, @PageIndex
--								Rename parameter @PageNumber to @TabID
--								Change from Page view to Tab view
--	[26-June-2009]	ThanhNguyen	Change default value of @TabID  from 1 to -1. If @TabID = -1 then get first tabID of ClientID
--  [23-July-2009]	Phuong Le		Add "Checkbox" field
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Product_GetDynamicFields]
	-- Add the parameters for the stored procedure here
	@ClientID int,
	@TabID int = -1,
	@ClientDictID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	IF(@TabID = -1)
	BEGIN
		DECLARE @AllTabsTable TABLE
		(	TabID int,
			TabDesc nvarchar(1000)	
		)

		INSERT INTO @AllTabsTable
		exec [CWX_Product_GetAllTabs] @ClientID
		SELECT top 1 @TabID = TabID FROM @AllTabsTable 	
	END
    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.[Listed], 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup],
			ISNULL(a.Checkbox,0) as [Checkbox]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], 
				[DisplayOrder], [DropDown], [RangeID], [Mandatory],[Checkbox]
		FROM CWX_ClientInformation_Dict
		WHERE Displayed = 1	AND TabID = @TabID AND (ClientID = @ClientDictID OR ISNULL(ClientID,0) = 0)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'ClientInformation' AND [Type]='U')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000)
	DECLARE @FieldName varchar(50)
	SET @FieldNameList = 'ClientID,ClientName,Priority,AgingForReschedule,AgingForDiscount,RescheduleAllowed,DiscountAllowed,LetterheadImage,CreditorID,PaymentAllocationRuleID,AgingForApportion,ApportionAllowed' --ClientActive

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(1000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM ClientInformation WHERE ClientID = ' + Cast(@ClientID as varchar)
	
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

END
Go

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDynamicFields]    Script Date: 07/23/2009 13:32:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetDynamicFields]

GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDynamicFields]    Script Date: 07/23/2009 13:32:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an account
-- History:
--	[06-Mar-2009]	Minh Dam		Init version.
--	[20-Mar-2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[10-Apr-2009]	Thanh Nguyen	Add parameter "@CMSEditable"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam		Remove parameters @PageSize, @PageIndex
--									Rename parameter @PageNumber to @TabID
--									Change from Page view to Tab view
--  [26-June-2009]	ThanhNguyen		Change default value of @TabID from 1 to -1. If @TabID = -1 Then get the first tab of ClientID
--  [23-July-2009]	Phuong Le		Add "Checkbox" field
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetDynamicFields]
	@AccountID int,
	@TabID int = -1, 
	@ClientID int = 0, -- if @ClientID <= 0 then set @ClientID equals ClientID of account
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF (@AccountID > 0 AND @ClientID <= 0)
		SELECT @ClientID = ClientID
		FROM Account
		WHERE AccountID = @AccountID
	--In case dont pass TabID, first tab will be selected
	IF(@TabID = -1)
	BEGIN
		DECLARE @AllTabsTable TABLE
		(	TabID int,
			TabDesc nvarchar(1000)	
		)

		INSERT INTO @AllTabsTable
		exec [CWX_AccountInformation_GetAllTabs] @ClientID		
		SELECT top 1 @TabID = TabID FROM @AllTabsTable 	
	END
	
    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[TableID],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup],
			ISNULL(a.Checkbox,0) as [Checkbox]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], CASE WHEN @CMSEditable = 1 THEN [CMSEdit] ELSE [Editable] END as [Editable], 
				[GroupID], [GroupDesc], [DisplayOrder], [RangeID], [DropDown], [TableID], [Mandatory],[Checkbox]
		FROM CWX_AccountInformation_Dict
		WHERE Displayed = 1	AND TabID = @TabID
			AND (@CMSEditable = 0 OR (@CMSEditable = 1 AND [CMSEdit] = 1))
			AND (ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Account' AND [Type]='U')
			OR object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'AccountOther' AND [Type]='U')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList_Account varchar(4000), @FieldNameList_AccountOther varchar(4000)
	DECLARE @FieldName varchar(50), @TableID int
	SET @FieldNameList_Account = 'AccountID,InvoiceNumber,DebtorID,EmployeeID,ClientID,QueueDate,AgencyStatusID,SystemStatusID,ActionCodeID,OfficeID,MCode,CCode,BucketMovement,SubmissionDate,LastEditDate,LastEditBy,CurrencyCode,InterfaceID,CloseDate'
	SET @FieldNameList_AccountOther = 'AccountID'

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName, TableID FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF (@TableID = 1) -- Account table
			SET @FieldNameList_Account = @FieldNameList_Account + ',' + @FieldName
		ELSE IF (@TableID = 2) -- AccountOther table
			SET @FieldNameList_AccountOther = @FieldNameList_AccountOther + ',' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql1 varchar(1000), @Sql2 varchar(1000)
	SET @Sql1 = 'SELECT ' + @FieldNameList_Account + ' FROM Account WHERE AccountID = ' + Cast(@AccountID as varchar)
	SET @Sql2 = 'SELECT ' + @FieldNameList_AccountOther + ' FROM AccountOther WHERE AccountID = ' + Cast(@AccountID as varchar)
	
	EXEC (@Sql1)
	EXEC (@Sql2)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[NotesCurrent]') AND name = N'IDX_NoteID')
BEGIN
	CREATE NONCLUSTERED INDEX [IDX_NoteID] ON [dbo].[NotesCurrent] 
	(
		[NoteID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO


-- [Minh Dam] [2009-07-24] --
-- ADD MORE COLUMNS TO Legal_GroupDebts TABLE
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Legal_GroupDebts' AND COLUMN_NAME = 'InterestRate')
BEGIN
	ALTER TABLE Legal_GroupDebts
		ADD InterestRate real NULL
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Legal_GroupDebts' AND COLUMN_NAME = 'IntStartDate')
BEGIN
	ALTER TABLE Legal_GroupDebts
		ADD IntStartDate datetime NULL
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Legal_GroupDebts' AND COLUMN_NAME = 'IntEndDate')
BEGIN
	ALTER TABLE Legal_GroupDebts
		ADD IntEndDate datetime NULL
END
GO


-- Alter procedure CWX_LegalStepFees_Dict
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtList]    Script Date: 07/24/2009 17:23:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debts with Account No.
-- History:
--	[2008-07-16]	Thao Nguyen		Init version.
--	[2009-07-21]	Minh Dam		Add a.InterestRate, a.IntStartDate, a.IntEndDate to SELECT statememt
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@AccountID int = 0,
	@ClientID int=0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    IF @groupID <> 0
		SELECT [GroupDebtID],a.[GroupID],a.[AccountID],a.[LastEditDate],a.[PaymentAllocationRuleID],a.[IsInclude], a.[IsPrimary], b.InvoiceNumber
				,CAST(0 AS bit) AS IsGrouped
				,'' AS GroupName,
				a.InterestRate, a.IntStartDate, a.IntEndDate
		FROM Legal_GroupDebts a
			JOIN Account b ON a.AccountID = b.AccountID
		WHERE a.AccountID = b.AccountID AND 
			CASE WHEN @ClientID > 0 THEN b.ClientID ELSE 0 END = @ClientID AND
			GroupID = @groupID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2
		ORDER BY a.[IsPrimary] DESC, b.AccountID
	ELSE
		SELECT	NULL AS [GroupDebtID], NULL AS [GroupID], b.[AccountID], NULL AS [LastEditDate],
				NULL AS [PaymentAllocationRuleID], 
				CAST((CASE b.AccountID WHEN @AccountID THEN 1 ELSE 0 END) AS bit) AS [IsInclude],
				CAST((CASE b.AccountID WHEN @AccountID THEN 1 ELSE 0 END) AS bit) AS [IsPrimary],
				b.InvoiceNumber,
				CAST(0 AS bit) AS IsGrouped,
				'' AS GroupName,
				0 as InterestRate, null as IntStartDate, null as IntEndDate
		FROM Account b 
		WHERE b.DebtorID = @debtorID AND 
			CASE WHEN @ClientID > 0 THEN b.ClientID ELSE 0 END = @ClientID AND
			b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2
		ORDER BY a.[IsPrimary] DESC, b.AccountID
END


-- Create table CWX_LegalStepFees_Dict
/****** Object:  Table [dbo].[CWX_LegalStepFees_Dict]    Script Date: 07/24/2009 17:24:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LegalStepFees_Dict]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_LegalStepFees_Dict](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[GroupStepID] [int] NOT NULL,
		[FeeName] [varchar](50) NOT NULL,
		[LabelDesc] [nvarchar](50) NOT NULL,
		[Displayed] [bit] NULL CONSTRAINT [DF_CWX_LegalStepFees_Dict_Displayed]  DEFAULT ((0)),
		[DisplayOrder] [int] NULL CONSTRAINT [DF_CWX_LegalStepFees_Dict_DisplayOrder]  DEFAULT ((0)),
		[TransTypeID] [int] NULL,
		[IncludeTotal] [bit] NULL CONSTRAINT [DF_CWX_LegalStepFees_Dict_IncludeTotal]  DEFAULT ((0)),
		[CreatedBy] [int] NULL,
		[CreatedDate] [datetime] NULL,
	 CONSTRAINT [PK_CWX_LegalStepFees_Dict] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO


-- Create procedure CWX_LegalStepFees_Dict_GetByGroupStepID
/****** Object:  StoredProcedure [dbo].[CWX_LegalStepFees_Dict_GetByGroupStepID]    Script Date: 07/24/2009 17:26:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LegalStepFees_Dict_GetByGroupStepID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LegalStepFees_Dict_GetByGroupStepID]
GO

/****** Object:  StoredProcedure [dbo].[CWX_LegalStepFees_Dict_GetByGroupStepID]    Script Date: 07/24/2009 17:27:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 22 Jul 2009
-- Description:	Get all legal step fees from dictionary
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LegalStepFees_Dict_GetByGroupStepID]
	@GroupStepID int = 0
AS
BEGIN
	SET NOCOUNT ON
	SELECT	a.ID, a.FeeName, a.LabelDesc as LabelDescription, 
			a.Displayed, a.DisplayOrder, a.IncludeTotal,
			CASE WHEN b.ID IS NOT NULL THEN ISNULL(b.TransactionCode,'') + ' - ' + ISNULL(b.Description,'') 
				ELSE ''
			END AS TransTypeCodeAndDescription
	FROM CWX_LegalStepFees_Dict a
		LEFT JOIN TransactionType b on a.TransTypeID = b.ID
	WHERE a.GroupStepID = @GroupStepID
	ORDER BY DisplayOrder, FeeName	
END
GO


-- Insert init data for CWX_LegalStepFees_Dict table.
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'IntAmount')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'IntAmount', 'Interest Amount', 1, 1, 0, 1);

IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'DebtAmount')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'DebtAmount', 'Debt Amount', 1, 2, 0, 1);

IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'SolicitorFee')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'SolicitorFee', 'Solicitor Fee', 1, 3, 0, 1);
	
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'ServiceFee')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'ServiceFee', 'Service Fee', 1, 4, 0, 1);
	
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'SearchFee')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'SearchFee', 'Search Fee', 1, 5, 0, 1);
	
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'CourtFee')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'CourtFee', 'Court Fee', 1, 6, 0, 1);
	
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'AttemptedFee')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'AttemptedFee', 'Attemped Service Fees', 1, 7, 0, 1);
	
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'TravelFee')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'TravelFee', 'Travel Fee', 1, 8, 0, 1);
	
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'BookKeepingFee')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'BookKeepingFee', 'Book Keeping Fee', 1, 9, 0, 1);
	
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'LeavyFee')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'LeavyFee', 'Levy Fee', 1, 10, 0, 1);
	
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'CustomFee1')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'CustomFee1', 'Custom Fee 1', 1, 11, 0, 1);
	
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'CustomFee2')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'CustomFee2',' Custom Fee 2', 1, 12, 0, 1);
	
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'CustomFee3')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'CustomFee3', 'Custom Fee 3', 1, 13, 0, 1);
	
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'CustomFee4')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'CustomFee4', 'Custom Fee 4', 1, 14, 0, 1);
	
IF NOT EXISTS (SELECT 1 FROM CWX_LegalStepFees_Dict WHERE GroupStepID = 0 AND FeeName = 'CustomFee5')
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal)
	VALUES     (0, 'CustomFee5', 'Custom Fee 5', 1, 15, 0, 1);
GO


-- Create procedure CWX_LegalStepFees_Dict_InsertFeeFields
/****** Object:  StoredProcedure [dbo].[CWX_LegalStepFees_Dict_InsertFeeFields]    Script Date: 07/24/2009 17:27:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LegalStepFees_Dict_InsertFeeFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LegalStepFees_Dict_InsertFeeFields]
GO

/****** Object:  StoredProcedure [dbo].[CWX_LegalStepFees_Dict_InsertFeeFields]    Script Date: 07/24/2009 17:28:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Description:	Insert all fee fields belong to a group step to CWX_LegalStepFee_Dict table
-- History:
--	[2009-07-24]	[Minh Dam]		Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LegalStepFees_Dict_InsertFeeFields]
	@GroupStepID int = 0,
	@CreatedBy int,
	@CreatedDate datetime
AS
BEGIN
	SET NOCOUNT ON
	DELETE FROM CWX_LegalStepFees_Dict WHERE GroupStepID = @GroupStepID
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'IntAmount', 'Interest Amount', 1, 1, 0, 1, @CreatedBy, @CreatedDate);	
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'DebtAmount', 'Debt Amount', 1, 2, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'SolicitorFee', 'Solicitor Fee', 1, 3, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'ServiceFee', 'Service Fee', 1, 4, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'SearchFee', 'Search Fee', 1, 5, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'CourtFee', 'Court Fee', 1, 6, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'AttemptedFee', 'Attemped Service Fees', 1, 7, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'TravelFee', 'Travel Fee', 1, 8, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'BookKeepingFee', 'Book Keeping Fee', 1, 9, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'LeavyFee', 'Levy Fee', 1, 10, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'CustomFee1', 'Custom Fee 1', 1, 11, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'CustomFee2',' Custom Fee 2', 1, 12, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'CustomFee3', 'Custom Fee 3', 1, 13, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'CustomFee4', 'Custom Fee 4', 1, 14, 0, 1, @CreatedBy, @CreatedDate);
	INSERT INTO CWX_LegalStepFees_Dict (GroupStepID, FeeName, LabelDesc, Displayed, DisplayOrder, TransTypeID, IncludeTotal, CreatedBy, CreatedDate)
	VALUES     (@GroupStepID, 'CustomFee5', 'Custom Fee 5', 1, 15, 0, 1, @CreatedBy, @CreatedDate);
END
GO


-- Create procedure CWX_Legal_GroupSteps_GetAll
/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupSteps_GetAll]    Script Date: 07/24/2009 17:28:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupSteps_GetAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_GroupSteps_GetAll]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupSteps_GetAll]    Script Date: 07/24/2009 17:29:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: 2009-07-24
-- Description:	Get all group steps.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_GroupSteps_GetAll]

AS
BEGIN
	SET NOCOUNT ON
	SELECT	a.GroupStepID,
			CAST(a.GroupStepID as varchar) + ' - ' + 
			CASE WHEN b.GroupStepTypeID IS NOT NULL THEN b.Code + ' - ' + b.Description
				ELSE ''				
			END AS CodeDesc
	FROM Legal_GroupSteps a 
		LEFT JOIN Legal_GroupStepTypes b ON a.GroupStepTypeID = b.GroupStepTypeID AND b.Status <> 'R'
	WHERE a.Status <> 'R'
	ORDER BY a.GroupStepID
END
GO


-- Create procedure CWX_Legal_GroupSteps_UpdateAmount
/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupSteps_UpdateAmount]    Script Date: 07/24/2009 17:29:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupSteps_UpdateAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_GroupSteps_UpdateAmount]

/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupSteps_UpdateAmount]    Script Date: 07/24/2009 17:30:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 24 Jul 2009
-- Description:	Update fee fields of a group step by an amount
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_GroupSteps_UpdateAmount]
	@GroupStepID int,
	@TransactionTypeID int,
	@Amount money
AS
BEGIN
	SET NOCOUNT ON
	
	DECLARE @Sql varchar(1000)
	DECLARE @FeeName varchar(50), @IncludeTotal bit, @TransTypeID int
	DECLARE @FeeTotalUpdateStm varchar(1000), @StepTotalUpdateStm varchar(1000)
	DECLARE curFeesDict CURSOR FOR
		SELECT FeeName, IncludeTotal, TransTypeID
		FROM CWX_LegalStepFees_Dict
		WHERE GroupStepID = @GroupStepID			
			AND Displayed = 1
			
	OPEN curFeesDict	
	FETCH NEXT FROM curFeesDict INTO @FeeName, @IncludeTotal, @TransTypeID
	SET @FeeTotalUpdateStm = 'FeeTotal = '
	SET @StepTotalUpdateStm = 'StepTotal = '
	SET @Sql = 'UPDATE Legal_GroupSteps SET '
	WHILE (@@FETCH_STATUS <> -1)
	BEGIN
		IF (@TransTypeID = @TransactionTypeID)
		BEGIN
			SET @Sql = @Sql + '@@FeeName = ISNULL(@@FeeName,0) + @@Amount, '
			SET @Sql = REPLACE(@Sql, '@@FeeName', @FeeName)
			SET @Sql = REPLACE(@Sql, '@@Amount', @Amount)
		END
		
		IF (@IncludeTotal = 1)
		BEGIN
			IF (@FeeName NOT IN ('IntAmount', 'DebtAmount'))
				SET @FeeTotalUpdateStm = @FeeTotalUpdateStm + 'ISNULL(' + @FeeName + ',0) + '
				
			SET @StepTotalUpdateStm = @StepTotalUpdateStm + 'ISNULL(' + @FeeName + ',0) + '
		END
		
		FETCH NEXT FROM curFeesDict INTO @FeeName, @IncludeTotal, @TransTypeID
	END
	CLOSE curFeeDict
	DEALLOCATE curFeeDict
	
	SET @Sql = @Sql + 'LastEditDate = GETDATE() '
	SET @Sql = @Sql + 'WHERE GroupStepID = ' + CAST(@GroupStepID AS VARCHAR(10)) + '
'
		
	SET @Sql = @Sql + 'UPDATE Legal_GroupSteps SET '
	SET @Sql = @Sql + @FeeTotalUpdateStm + '0, '
	SET @Sql = @Sql + @StepTotalUpdateStm + '0 '
	SET @Sql = @Sql + 'WHERE GroupStepID = ' + CAST(@GroupStepID AS VARCHAR(10));
		
	EXEC (@Sql)
END
GO
-- End [Minh Dam] [2009-07-24] --