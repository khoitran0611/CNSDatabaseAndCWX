﻿-- Script is applied on version 3.2.0

-- Start of Scripts 3.2.0

Update QueryParams set PickList = 
'Select SolicitorID,[Firm] from Legal_Solicitors where Status = '+ '''' + 'A' + ''''+ ' order by [Firm]'
where QueryID = 25

GO
--==============================================

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		LongNguyen
-- Create date: Jul 10, 2008
-- Description:	Get all selected pool
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Employee_GetSelectedPool]
	@EmployeeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT p.PoolID, p.EmployeeID, e.Description
	FROM EmployeePool p
	LEFT JOIN Employee e ON e.EmployeeID = p.PoolID
	WHERE
		e.EmployeeStatus <> 'R'
		AND p.EmployeeID = @EmployeeID
END
GO

set ANSI_NULLS ON
GO
set QUOTED_IDENTIFIER ON
go


ALTER PROCEDURE [dbo].[CWX_Collateral_GetPagingList]
	@AccountID int,
	@EmployeeID int	,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @RowCount int
	SELECT ROW_NUMBER() OVER (ORDER BY [CollateralType], [CollateralStage], [NextAction], [NextActionDate]) as RowNumber,
			[ID], [AccountID], [HostCollateralID], [EmployeeID], [NextActionDate],
			ISNULL(dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6),'') AS CollateralType,
			ISNULL(dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7),'') AS CollateralStage,
			ISNULL(dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2),'') AS NextAction
	INTO #Temp
	FROM [Collateral]
	WHERE [AccountID] = @AccountID --AND [EmployeeID] = @EmployeeID
	ORDER BY [CollateralType], [CollateralStage], [NextAction], [NextActionDate]
	
	
	SELECT @RowCount=COUNT(*) FROM #Temp

	SELECT [ID],[AccountID],[HostCollateralID],[EmployeeID],[NextActionDate],[CollateralType],[CollateralStage],[NextAction]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END

GO
--=======================================================
--****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 12/30/2008 16:33:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalForward] 
	@SolicitorID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
		INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
	WHERE
		a.DebtorID <> 0
        And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
			INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
		WHERE
			a.DebtorID <> 0
			And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
		INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
	WHERE
		a.DebtorID <> 0
        And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
			INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
		WHERE
			a.DebtorID <> 0
			And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END

GO
set ANSI_NULLS ON
GO
set QUOTED_IDENTIFIER ON

GO

--=================================================

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralStage]    Script Date: 12/30/2008 16:15:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralStage] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@cStageID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.CollateralStage = @cStageID 


	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.CollateralStage = @cStageID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.CollateralStage = @cStageID 


	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.CollateralStage = @cStageID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

GO

--=================================================

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralByEmployee]    Script Date: 12/30/2008 16:42:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralByEmployee] 
	@v_employeeId int,
	@cEmployeeID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.EmployeeID = @cEmployeeID 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.EmployeeID = @cEmployeeID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.EmployeeID = @cEmployeeID 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.EmployeeID = @cEmployeeID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

GO

--=================================================

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralItemType]    Script Date: 12/30/2008 16:43:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralItemType] 
	@v_employeeId int,
	@ItemID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.CollateralType = @ItemID

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.CollateralType = @ItemID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.CollateralType = @ItemID

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.CollateralType = @ItemID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END

GO

--=================================================

/****** Object:  StoredProcedure [dbo].[CWX_Account_CreateGroupAccount]    Script Date: 12/30/2008 16:56:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description:	Create a new account by group ID.
-- History:
--	2008/09/03	[LongNguyen]	Init version.
--	2008/09/19	[Binh Truong]	Delete a record in TempDebtorXml where debtorID = debtorID of created account. Purpose: clear cache.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_CreateGroupAccount]
	@GroupID int
AS
BEGIN
	DECLARE @BillBalance money
	DECLARE @BillAmount money
	
	--Increase 'Account' by one
	UPDATE IdentityFields SET FieldValue = FieldValue + 1 WHERE TableName = 'Account'

	--Insert new Account with all detail from the primary account of group	
	SELECT @BillBalance=SUM(a.BillBalance), @BillAmount=SUM(a.BillAmount)
	FROM Legal_GroupDebts g
	LEFT JOIN Account a ON a.AccountID = g.AccountID
	WHERE g.IsInclude=1 AND g.GroupID=@GroupID

	DECLARE @PrimaryAccountID int
	SELECT @PrimaryAccountID=AccountID FROM Legal_GroupDebts WHERE GroupID = @GroupID AND IsPrimary = 1

	DECLARE @AccountID int
	SELECT @AccountID=MAX(AccountID)+1 FROM Account

	INSERT INTO Account
	SELECT @AccountID
		  ,DebtorID
		  ,EmployeeID
		  ,ClientID
		  ,AgencyStatusID
		  ,SystemStatusID
		  ,ActionCodeID
		  ,OfficeID
		  ,MCode
		  ,CCode
		  ,@AccountID --,InvoiceNumber
		  ,AccountType
		  ,AccountClass
		  ,QueueDate
		  ,DateOfService
		  ,SubmissionDate
		  ,LastClientTransactionDate
		  ,RoutinePayment
		  ,PaymentPlan
		  ,PatientName
		  ,@BillAmount
		  ,@BillBalance
		  ,BillOtherCharges
		  ,ClientPaysLegalFees
		  ,AccountForwarded
		  ,CreditReported
		  ,CreditReportedDate
		  ,ClientPercent
		  ,ClientOCPercent
		  ,SplitPayment
		  ,CurrentAction
		  ,CurrentActionDate
		  ,NoLetterBefore
		  ,NoFeeBefore
		  ,MaintainOfficer
		  ,AccountAge
		  ,LastEditDate
		  ,LastEditBy
		  ,LastVerifyDate
		  ,AllocRuleID
		  ,AutoProcRuleID
		  ,LastExtractionDate
		  ,LastAllocationDate
		  ,LastAutoProcessDate
		  ,ExtractionRuleID
		  ,AccountForwardedTo
		  ,CurrencyCode
		  ,BatchNumber
		  ,InterestRate
		  ,ActionEmployee
		  ,LastPromiseBatch
		  ,CreditReportRequested
		  ,CreditReportRequestedBy
		  ,CreditReportRequestedOn
		  ,CreditReportRequestStatus
		  ,WriteOffDate
		  ,LastInterestDate
		  ,TempEmployeeID
		  ,OAManaged
		  ,InterfaceID
		  ,Delq_string
		  ,SortOrder
		  ,Allocated
		  ,BrokenCount
		  ,CARD_FILE_NO
		  ,ARREAR_PATH
		  ,BUCKET_TYPE
		  ,OLD_BUCKET_TYPE
		  ,CARD_TYPE
		  ,BRANCH_CODE
		  ,FORMULA
		  ,BANK_CODE
		  ,PAID
		  ,OtherAccountNo
		  ,TENOR
		  ,FORMULA_FLAG
		  ,MINIMUM_DUE
		  ,CURRENT_BKT_NUM
		  ,PREV_BKT_NUM
		  ,productivecount
		  ,contactcount
		  ,nocontactcount
		  ,DelqHistory
		  ,BucketMovement
		  ,DPDMovement
		  ,PreviousAllocRuleID
		  ,OnLeaveEmpID
		  ,LeaveLoadRelFlag
		  ,CurrentReason
		  ,CurrentReasonDate
		  ,CurrentNextAction
		  ,CurrentNextActionDate
		  ,CurrentCallResult
		  ,CurrentCallResultDate
		  ,CampaignId
		  ,CloseDate
		  ,MaxContact
		  ,AssignmentType
		  ,PoolSelected
		  ,IsPending
		FROM Account
		WHERE AccountID = @PrimaryAccountID

	--Delete redundant data
	--DELETE AccountOther WHERE AccountID = @AccountID
	--Insert into AccountOther
	INSERT INTO AccountOther
	SELECT @AccountID
		  ,Long1
		  ,Long2
		  ,Long3
		  ,Long4
		  ,Long5
		  ,Long6
		  ,Long7
		  ,Long8
		  ,Long9
		  ,Long10
		  ,Long11
		  ,Long12
		  ,Long13
		  ,Long14
		  ,Long15
		  ,Long16
		  ,Long17
		  ,Long18
		  ,Long19
		  ,Long20
		  ,Long21
		  ,Long22
		  ,Long23
		  ,Long24
		  ,Long25
		  ,Long26
		  ,Long27
		  ,Long28
		  ,Long29
		  ,Long30
		  ,Long31
		  ,Long32
		  ,Long33
		  ,Long34
		  ,Long35
		  ,Long36
		  ,Long37
		  ,Long38
		  ,Long39
		  ,Long40
		  ,Long41
		  ,Long42
		  ,Long43
		  ,Long44
		  ,Long45
		  ,Long46
		  ,Long47
		  ,Long48
		  ,Long49
		  ,Long50
		  ,Money1
		  ,Money2
		  ,Money3
		  ,Money4
		  ,Money5
		  ,Money6
		  ,Money7
		  ,Money8
		  ,Money9
		  ,Money10
		  ,Money11
		  ,Money12
		  ,Money13
		  ,Money14
		  ,Money15
		  ,Money16
		  ,Money17
		  ,Money18
		  ,Money19
		  ,Money20
		  ,Money21
		  ,Money22
		  ,Money23
		  ,Money24
		  ,Money25
		  ,Money26
		  ,Money27
		  ,Money28
		  ,Money29
		  ,Money30
		  ,Money31
		  ,Money32
		  ,Money33
		  ,Money34
		  ,Money35
		  ,Money36
		  ,Money37
		  ,Money38
		  ,Money39
		  ,Money40
		  ,Money41
		  ,Money42
		  ,Money43
		  ,Money44
		  ,Money45
		  ,Money46
		  ,Money47
		  ,Money48
		  ,Money49
		  ,Money50
		  ,Date1
		  ,Date2
		  ,Date3
		  ,Date4
		  ,Date5
		  ,Date6
		  ,Date7
		  ,Date8
		  ,Date9
		  ,Date10
		  ,Date11
		  ,Date12
		  ,Date13
		  ,Date14
		  ,Date15
		  ,Date16
		  ,Date17
		  ,Date18
		  ,Date19
		  ,Date20
		  ,Date21
		  ,Date22
		  ,Date23
		  ,Date24
		  ,Date25
		  ,Date26
		  ,Date27
		  ,Date28
		  ,Date29
		  ,Date30
		  ,Date31
		  ,Date32
		  ,Date33
		  ,Date34
		  ,Date35
		  ,Date36
		  ,Date37
		  ,Date38
		  ,Date39
		  ,Date40
		  ,Date41
		  ,Date42
		  ,Date43
		  ,Date44
		  ,Date45
		  ,Date46
		  ,Date47
		  ,Date48
		  ,Date49
		  ,Date50
		  ,String1
		  ,String2
		  ,String3
		  ,String4
		  ,String5
		  ,String6
		  ,String7
		  ,String8
		  ,String9
		  ,String10
		  ,String11
		  ,String12
		  ,String13
		  ,String14
		  ,String15
		  ,String16
		  ,String17
		  ,String18
		  ,String19
		  ,String20
		  ,String21
		  ,String22
		  ,String23
		  ,String24
		  ,String25
		  ,String26
		  ,String27
		  ,String28
		  ,String29
		  ,String30
		  ,String31
		  ,String32
		  ,String33
		  ,String34
		  ,String35
		  ,String36
		  ,String37
		  ,String38
		  ,String39
		  ,String40
		  ,String41
		  ,String42
		  ,String43
		  ,String44
		  ,String45
		  ,String46
		  ,String47
		  ,String48
		  ,String49
		  ,String50
		  ,Additional1
		  ,Additional2
		  ,Additional3
		  ,Additional4
		  ,ArrearsHistory
		FROM AccountOther
		WHERE AccountID = @PrimaryAccountID
		
	DELETE FROM TempDebtorXml
	WHERE DebtorID = (SELECT DebtorID FROM Account WHERE AccountID = @AccountID)

--Copy collaterals to Legal Grouped Account

Insert into Collateral
Select		@AccountID
           ,[HostCollateralID]
           ,[CollateralType]
           ,[CollateralStage]
           ,[EmployeeID]
           ,[NextAction]
           ,[NextActionDate]
           ,[CInt1]
           ,[CInt2]
           ,[CInt3]
           ,[CInt4]
           ,[CInt5]
           ,[CInt6]
           ,[CInt7]
           ,[CInt8]
           ,[CInt9]
           ,[CInt10]
           ,[CString1]
           ,[CString2]
           ,[CString3]
           ,[CString4]
           ,[CString5]
           ,[CString6]
           ,[CString7]
           ,[CString8]
           ,[CString9]
           ,[CString10]
           ,[CString11]
           ,[CString12]
           ,[CString13]
           ,[CString14]
           ,[CString15]
           ,[CString16]
           ,[CString17]
           ,[CString18]
           ,[CString19]
           ,[CString20]
           ,[CDate1]
           ,[CDate2]
           ,[CDate3]
           ,[CDate4]
           ,[CDate5]
           ,[CDate6]
           ,[CDate7]
           ,[CDate8]
           ,[CDate9]
           ,[CDate10]
           ,[CDate11]
           ,[CDate12]
           ,[CDate13]
           ,[CDate14]
           ,[CDate15]
           ,[CMoney1]
           ,[CMoney2]
           ,[CMoney3]
           ,[CMoney4]
           ,[CMoney5]
           ,[CMoney6]
           ,[CMoney7]
           ,[CMoney8]
           ,[CMoney9]
           ,[CMoney10]
           ,[CMoney11]
           ,[CMoney12]
           ,[CMoney13]
           ,[CMoney14]
           ,[CMoney15]
           ,[Image]
           ,[ImageFileName]
From Collateral
Where AccountID = @PrimaryAccountID

	SELECT @AccountID
END

GO

--=================================================

/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_FillPagingList]    Script Date: 12/29/2008 14:26:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_FillPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleTable_FillPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_FillPagingList]    Script Date: 12/29/2008 14:26:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_FillPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		LongNguyen
-- Create date: 2008-12-29
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleTable_FillPagingList] 
	-- Add the parameters for the stored procedure here
	@RuleType tinyint,
	@RuleID int = 0,
	@Description varchar(100) = '''',
	@PageSize int,
	@PageIndex int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(ID)
	FROM RuleTable
	WHERE
		RuleType = @RuleType
		AND (@RuleID = 0 OR ID = @RuleID)
		AND Description LIKE (''%'' + @Description + ''%'')

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER(ORDER BY Description) as RowNumber,
				*
		FROM RuleTable
		WHERE
			RuleType = @RuleType
			AND (@RuleID = 0 OR ID = @RuleID)
			AND Description LIKE (''%'' + @Description + ''%'')
	)

	SELECT 	*
	FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
' 
END
GO 

