 -- Script is applied on version 2.2.10, 2.2.11
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtList]    Script Date: 07/22/2008 10:06:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 07/22/2008 10:06:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupSteps_GetList]    Script Date: 07/22/2008 10:06:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupSteps_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_GroupSteps_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetList]    Script Date: 07/22/2008 10:06:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 07/22/2008 10:06:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupSteps_GetList]    Script Date: 07/22/2008 10:06:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupSteps_GetList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-18
-- Description:	Get list of Group Steps ordered by Step Type
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_GroupSteps_GetList]
	-- Add the parameters for the stored procedure here
	@groupID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT Code, [Description], a.* 
	FROM Legal_GroupSteps a LEFT JOIN Legal_GroupStepTypes b ON a.GroupStepTypeID = b.GroupStepTypeID
	WHERE a.GroupID = @groupID AND a.Status <> ''R''
	ORDER BY Code, [Description]
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetList]    Script Date: 07/22/2008 10:06:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-18
-- Description:	Get all Legal Group by Debtor
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetList] 
	-- Add the parameters for the stored procedure here
	@debtorID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT a.*
	FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebtors b ON a.GroupID = b.GroupID AND DebtorID is not NULL
	WHERE  a.Status <> ''R'' and b.DebtorID = @debtorID
	ORDER BY Code, [Description]
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 07/22/2008 10:06:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-14
-- Description:	Get the list of Groups of selecting customer
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
	-- Add the parameters for the stored procedure here
	@debtorID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
    SELECT
		ROW_NUMBER() OVER (ORDER BY G.Code) AS RowNumber,
		G.*	
	INTO #Temp
	FROM (SELECT DISTINCT
		a.GroupID,
		a.Code,
		a.[Description],
		Case When d.GroupID is not null then 1 else 0 end HasStep
		FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
			LEFT JOIN Account c ON b.AccountID = c.AccountID
			LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> ''R'') d ON a.GroupID = d.GroupID
		WHERE  a.Status <> ''R'' and c.DebtorID = @debtorID) G
	ORDER BY G.Code	

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT *
		FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtList]    Script Date: 07/22/2008 10:06:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debts with Account No.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    IF @groupID <> 0
		SELECT a.[GroupDebtID],a.[GroupID],a.[AccountID],a.[LastEditDate],a.[PaymentAllocationRuleID],a.[IsInclude], a.[IsPrimary], b.InvoiceNumber
				,Case When c.IsInclude is not NULL Then 1 Else 0 End IsGrouped
				,GroupName
		FROM Legal_GroupDebts a
			JOIN Account b ON a.AccountID = b.AccountID
			LEFT JOIN (Select AccountID, IsInclude, (b.Code+'' - ''+b.Description) as GroupName 
						From Legal_GroupDebts a, Legal_Groups b where a.GroupID=b.GroupID and a.GroupID <> @groupID 
									and IsInclude = 1 and b.Status <> ''R'') c ON a.AccountID = c.AccountID
		WHERE a.AccountID = b.AccountID AND GroupID = @groupID
	ELSE
		SELECT a.[GroupDebtID],a.[GroupID],b.[AccountID],a.[LastEditDate],a.[PaymentAllocationRuleID],IsNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrimary], 0) [IsPrimary], b.InvoiceNumber
				,Case When c.IsInclude is not NULL Then 1 Else 0 End IsGrouped
				,GroupName
		FROM Account b 
			LEFT JOIN (SELECT * FROM Legal_GroupDebts WHERE GroupID = 0) a ON a.AccountID = b.AccountID
			LEFT JOIN (Select AccountID, IsInclude, (b.Code+'' - ''+b.Description) as GroupName 
						From Legal_GroupDebts a, Legal_Groups b where a.GroupID=b.GroupID and IsInclude = 1 and b.Status <> ''R'') c ON b.AccountID = c.AccountID
		WHERE b.DebtorID = @debtorID

END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 07/22/2008 10:06:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debtors with Account No. and Customer ''s fullName
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate] ,a.[RelationshipTypeID] ,a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				JOIN PersonInformation p ON a.PersonID = p.PersonID
				JOIN Account b ON a.AccountID = b.AccountID
		WHERE a.GroupID = @groupID
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	ELSE
	Begin
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,a.[RelationshipTypeID] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				JOIN PersonInformation p ON g.PersonID = p.PersonID
				JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a 
				ON g.PersonID = a.PersonID
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate] ,a.[RelationshipTypeID] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a 
				ON g.PersonID = a.PersonID
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID)
		
		ORDER BY Seq, b.AccountID, FullName
	End
END
' 
END
GO

-- Scripts 2.2.11: 

-- =======================================================================
-- Author:			Tuan Luong
-- Create date:		Jul 22, 2008
-- Description:		Add column 'HearingTypeID'
-- Effected table:	Legal_Hearings
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Hearings' and c.name = 'HearingTypeID')
BEGIN
	ALTER TABLE Legal_Hearings
	ADD HearingTypeID int NOT NULL		
END
GO

-- =======================================================================
-- Author:			Tuan Luong
-- Create date:		Jul 22, 2008
-- Description:		Drop column 'GroupID' then Add column 'GroupStepID'
-- Effected table:	Legal_Hearings
-- =======================================================================
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Hearings' and c.name = 'GroupID')
BEGIN
	ALTER TABLE Legal_Hearings DROP COLUMN GroupID
	ALTER TABLE Legal_Hearings ADD GroupStepID int NOT NULL
END
GO
-- Scripts 2.2.11: 
/****** Object:  StoredProcedure [dbo].[SearchByLegalGroupCode]    Script Date: 07/22/2008 11:18:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchByLegalGroupCode]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchByLegalGroupCode]
GO
/****** Object:  StoredProcedure [dbo].[SearchByLegalGroupCode]    Script Date: 07/22/2008 11:18:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchByLegalGroupCode]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
CREATE PROCEDURE [dbo].[SearchByLegalGroupCode]
	@GroupID int
AS
BEGIN
DECLARE @cStmt NVARCHAR(4000)
DECLARE @v_SortOrder VarChar(700)
SET @cStmt=''Select  convert(varchar(10), a.DebtorID) + ''''|'''' + convert(varchar(10), a.AccountID) as KeyField,''
	SET @cStmt=@cStmt+''convert(char(10), a.QueueDate, 111) as [QueueDate],''
	SET @cStmt=@cStmt+''a.AccountAge as [DPD],''
	SET @cStmt=@cStmt+''CAST(a.MCode AS CHAR(2)) as [Bucket],''
	SET @cStmt=@cStmt+''a.CCode as [Cycle],''
	SET @cStmt=@cStmt+''a.BillAmount  as [Bill Amount],''
	SET @cStmt=@cStmt+''a.BillBalance  as [Bill Balance],''
	SET @cStmt=@cStmt+''s.ShortDesc as [Status],''
	SET @cStmt=@cStmt+''s.SortPriority as [Priority],''
	SET @cStmt=@cStmt+''a.AssignmentType as [Assignment Type],''
	SET @cStmt=@cStmt+''p.SocialSecurityNumber as [ID],''
	SET @cStmt=@cStmt+''rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName) As [ Name]''
SET @cStmt=@cStmt+'' from ''
	SET @cStmt=@cStmt+''Account a,''
	SET @cStmt=@cStmt+''AccountStatus s,''
	SET @cStmt=@cStmt+''Legal_GroupDebts gd,''
	SET @cStmt=@cStmt+''dbo.Legal_Groups g,''
	SET @cStmt=@cStmt+''DebtorInformation d,''
	SET @cStmt=@cStmt+''PersonInformation p''

	SET @cStmt=@cStmt+'' where a.AccountID = gd.AccountID''
	SET @cStmt=@cStmt+'' and gd.GroupID = g.GroupID''
	SET @cStmt=@cStmt+'' and s.AgencyStatus = a.AgencyStatusID''
	SET @cStmt=@cStmt+'' and d.DebtorID = a.DebtorID''
	SET @cStmt=@cStmt+'' and p.PersonID = d.PersonID''
	SET @cStmt=@cStmt+'' and a.DebtorID <> 0 and gd.IsInclude=1 and g.GroupID='' + STR(@GroupID)
	SET @cStmt=@cStmt+'' order by ''
    Exec CW_SORT_ORDER @v_SortOrder Out 
    if @v_SortOrder='''' 
       Set @cStmt=@cStmt+'' "QueueDate" DESC''
    Else
       Set @cStmt=@cStmt+Replace(@v_SortOrder,''Delq_String'',''StrOrder'')
	
Exec SP_ExecuteSQL @cStmt
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_GetPromisesForReceivePayment]    Script Date: 07/22/2008 11:36:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetPromisesForReceivePayment]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <21 July 2008>
-- Description:	<Get first not due promise for receive payment>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetPromisesForReceivePayment]
	@AccountID int
AS
BEGIN

	SET NOCOUNT ON;
	
	SELECT TOP 1 (AmountPromised - AmountPaid) as AmountPromised, DatePromised
    FROM AccountPromise
	WHERE AccountID = @AccountID AND Status = 0 ORDER BY DatePromised

END
' 
END
GO

/****** Object:  new table for ticket  [CWX_TicketAddressChange]  Script Date: 07/22/2008 11:36:30 ******/

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CWX_TicketAddressChange]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[CWX_TicketAddressChange]
GO

CREATE TABLE [dbo].[CWX_TicketAddressChange] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[DebtorID] [int] default 0,
	[EmployeeID] [int] default 0 ,
	[Requester] [int] default 0 ,
	[RequestDate] [smalldatetime] NULL ,
	[AddressType] [tinyint] default 0 ,
	[Address1] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Address2] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Address3] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[City] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[State] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Zip] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Remark] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[AssignedTo] [int] default 0,
	[AssignDate] [smalldatetime] NULL ,
	[ApprovedBy] [int] default 0 ,
	[ApprovedDate] [smalldatetime] NULL ,
	[Approved] [int] default 0,
	[CloseCase] [bit] default 0,
	[CloseBy] [int] NULL ,
	[CloseDate] [smalldatetime] NULL 
) ON [PRIMARY]
GO
/****** Object:  new table for ticket  [CWX_TicketPhoneChange]  Script Date: 07/22/2008 11:36:30 ******/

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CWX_TicketPhoneChange]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[CWX_TicketPhoneChange]
GO

CREATE TABLE [dbo].[CWX_TicketPhoneChange] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[DebtorID] [int] default 0 ,
	[EmployeeID] [int] default 0 ,
	[Requester] [int] default 0 ,
	[RequestDate] [smalldatetime] NULL ,
	[PhoneType] [tinyint] default 0 ,
	[PhoneNumber] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PhoneExtension] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PhoneStatus] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Description] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[AssignedTo] [int] default 0 ,
	[AssignDate] [smalldatetime] NULL ,
	[ApprovedBy] [int] default 0 ,
	[ApprovedDate] [smalldatetime] NULL ,
	[Approved] [int] default 0 ,
	[CloseCase] [bit] default 0 ,
	[CloseBy] [int] default 0 ,
	[CloseDate] [smalldatetime] NULL 
) ON [PRIMARY]
GO

-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 22, 2008
-- Description:		Add column 'Website'
-- Effected table:	Legal_Solicitors
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Solicitors' and c.name = 'Website')
BEGIN
	ALTER TABLE Legal_Solicitors ADD Website nvarchar(100) NULL
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetAmountPromised]    Script Date: 07/22/2008 14:48:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetAmountPromised]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetAmountPromised]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetAmountPromised]    Script Date: 07/22/2008 14:48:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetAmountPromised]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get total outstanding, amount promised, amount remain money of an account.
-- Parameters:
--	@AccountID: indicates get amount promised by input AccountID. NULL value: Get amount promised of all accounts.
--  @ConsolidateType:
--		0: Consolidate by Account (default).
--		1: Consolidate by Debtor.
--		2: Consolidate by Interface.
-- History:
--	2008/05/06	[Binh Truong]	Init version.
--	2008/05/07	[Binh Truong]	Remove Amount Paid information.
--	2008/05/09	[Binh Truong]	Add ISNULL check. 
--									Add try catch to fix Arithmetic overflow error converting expression.
--	2008/07/17	[Binh Truong]	Add @ConsolidateType parameter. Calculate @TotalOutstanding by Debtor or Interface.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetAmountPromised]
(
	@AccountID int = NULL,
	@ConsolidateType int = 0
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @CurrentAmountPromised decimal(18,2)
	-- DECLARE @AmountPaid decimal(18,2)
	DECLARE @TotalOutstanding decimal(18,2)
	DECLARE @RemainingAccount decimal(18,2)
	DECLARE @DebtorID int
	DECLARE @InterfaceID int
	DECLARE @ErrorNumber int
	DECLARE @ArithmeticOverflowErrorNumber int
	
	SET @ArithmeticOverflowErrorNumber = 8115 -- Arithmetic overflow error converting expression to data type money
	SET @CurrentAmountPromised = 0
	SET @TotalOutstanding = 0
	SET @RemainingAccount = 0
	
	IF @ConsolidateType = 0
	BEGIN
		BEGIN TRY
			SELECT	@TotalOutstanding = SUM(ISNULL(BillBalance,0))
			FROM	Account
			WHERE	(ISNULL(@AccountID, 0) = 0 OR AccountID = @AccountID) AND 
					AgencyStatusID <> 2 AND SystemStatusID <> 2 -- Not closed
		END TRY
		BEGIN CATCH
			SELECT @ErrorNumber = ERROR_NUMBER()
			IF @ErrorNumber = @ArithmeticOverflowErrorNumber  
				SET @TotalOutstanding = -1
		END CATCH;
	END
	ELSE
	BEGIN
		IF @AccountID IS NOT NULL
		BEGIN
			SELECT	@DebtorID = DebtorID
			FROM	Account
			WHERE	AccountID = @AccountID			
			
			IF @ConsolidateType = 1 -- Consolidate by Debtor
			BEGIN
				IF @DebtorID IS NOT NULL 
				BEGIN	
					BEGIN TRY
						SELECT	@TotalOutstanding = SUM(ISNULL(BillBalance,0))
						FROM	Account
						WHERE	DebtorID = @DebtorID AND 
								AgencyStatusID <> 2 AND SystemStatusID <> 2 -- Not closed
					END TRY
					BEGIN CATCH
						SELECT @ErrorNumber = ERROR_NUMBER()
						IF @ErrorNumber = @ArithmeticOverflowErrorNumber  
							SET @TotalOutstanding = -1
					END CATCH;
				END
			END
			ELSE IF @ConsolidateType = 2 -- Consolidate by Interface
			BEGIN					
				IF @DebtorID IS NOT NULL 
				BEGIN
					SELECT	@InterfaceID = InterfaceID
					FROM	Account
					WHERE	AccountID = @AccountID
					
					BEGIN TRY
						SELECT	@TotalOutstanding = SUM(ISNULL(BillBalance,0))
						FROM	Account
						WHERE	DebtorID = @DebtorID AND InterfaceID = @InterfaceID AND 
								AgencyStatusID <> 2 AND SystemStatusID <> 2 -- Not closed
					END TRY
					BEGIN CATCH
						SELECT @ErrorNumber = ERROR_NUMBER()
						IF @ErrorNumber = @ArithmeticOverflowErrorNumber  
							SET @TotalOutstanding = -1
					END CATCH;
				END
			END			
		END		
	END
	
	BEGIN TRY
		SELECT	@CurrentAmountPromised = ISNULL(SUM(AmountPromised), 0) - ISNULL(SUM(AmountPaid), 0)
		FROM	AccountPromise
		WHERE	(ISNULL(@AccountID, 0) = 0 OR AccountID = @AccountID) AND
				Status = 0 -- Not due
	END TRY
	BEGIN CATCH
		SELECT @ErrorNumber = ERROR_NUMBER()
		IF @ErrorNumber = @ArithmeticOverflowErrorNumber
			SET @CurrentAmountPromised = -1
	END CATCH;	
	
	BEGIN TRY
		SET @RemainingAccount = ISNULL(@TotalOutstanding - @CurrentAmountPromised, 0)
	END TRY
	BEGIN CATCH
		SELECT @ErrorNumber = ERROR_NUMBER()
		IF @ErrorNumber = @ArithmeticOverflowErrorNumber
			SET @RemainingAccount = -1
	END CATCH;	
					
	SELECT	ISNULL(@TotalOutstanding, 0) as TotalOutstanding,
			ISNULL(@CurrentAmountPromised, 0) as CurrentAmountPromised,
			@RemainingAccount as RemainingAmount
	
END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupSteps_GetList]    Script Date: 07/22/2008 16:21:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupSteps_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_GroupSteps_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 07/22/2008 16:21:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupSteps_GetList]    Script Date: 07/22/2008 16:21:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupSteps_GetList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-18
-- Description:	Get list of Group Steps ordered by Step Type
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_GroupSteps_GetList]
	-- Add the parameters for the stored procedure here
	@groupID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT Code +'' - ''+[Description] as CodeDesc, a.* 
	FROM Legal_GroupSteps a 
		LEFT JOIN Legal_GroupStepTypes b ON a.GroupStepTypeID = b.GroupStepTypeID AND b.Status <> ''R''
	WHERE a.GroupID = @groupID AND a.Status <> ''R''
	ORDER BY a.GroupStepID
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 07/22/2008 16:21:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-14
-- Description:	Get the list of Groups of selecting customer
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
	-- Add the parameters for the stored procedure here
	@debtorID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
    SELECT
		ROW_NUMBER() OVER (ORDER BY G.Code) AS RowNumber,
		G.*	
	INTO #Temp
	FROM (SELECT DISTINCT
		a.GroupID,
		a.Code,
		a.[Description],
		Case When d.GroupID is not null then 1 else 0 end HasStep
		FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
			LEFT JOIN Account c ON b.AccountID = c.AccountID
			LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> ''R'') d ON a.GroupID = d.GroupID
		WHERE  a.Status <> ''R'' and c.DebtorID = @debtorID) G
	ORDER BY G.GroupID	

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT *
		FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
	
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_DebtorInfomation_Get_PhoneEmailFax]    Script Date: 07/22/2008 16:51:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInfomation_Get_PhoneEmailFax]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DebtorInfomation_Get_PhoneEmailFax]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInfomation_Get_PhoneEmailFax]    Script Date: 07/22/2008 16:51:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInfomation_Get_PhoneEmailFax]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get mobile phone number, e-mail, fax number of specific debtor.
-- History:
--	2008/07/22	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DebtorInfomation_Get_PhoneEmailFax]
	@DebtorID int	
AS
BEGIN
	SELECT  PersonInformation.MobilPhone, PersonInformation.Email, PersonInformation.Fax
	FROM    DebtorInformation INNER JOIN
	            PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID
	WHERE	DebtorInformation.DebtorID = @DebtorID
END

' 
END
GO

UPDATE QueryDebtorInfoMaster SET Sql = 'Exec CWX_DebtorInfomation_Get %D, %P' WHERE InfoType = 1
UPDATE QueryDebtorInfoMaster SET Sql = 'Exec CWX_PersonAddress_Get %D, %P' WHERE InfoType = 2
UPDATE QueryDebtorInfoMaster SET Sql = 'Exec CWX_PersonPhone_Get %D, %P' WHERE InfoType = 3
UPDATE QueryDebtorInfoMaster SET Sql = 'Exec CWX_Spouse_GetByDebtor %D, %P' WHERE InfoType = 4
GO

/****** Object:  StoredProcedure [dbo].[CWX_DebtorInfomation_Get]    Script Date: 07/22/2008 18:39:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInfomation_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DebtorInfomation_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInfomation_Get]    Script Date: 07/22/2008 18:39:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		Triet Pham
-- Create date: 03/26/2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DebtorInfomation_Get]
	@DebtorID int,
	@PersonID int = 0
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		TOP 1
		DebtorID, 
		PString3, 
		DebtorInformation.PersonID, 
		CompanyName, 
		DoingBusinessAs, 
		GroupName, 
		HotNote, 
		ZipDelPoint, 
		ZipCart, 
		ReturnedMail, 
		HoldLetters, 
		HoldHomeCalls, 
		HoldWorkCalls, 
		PullCreditReport, 
		SendReminderLetters, 
		DateOfLastCreditReportPull, 
		CreditReportFileName, 
		LastEditDate, 
		LastEditBy, 
		LockedByID, 
		LockedBy, 
		PString1, 
		PString2, 
		PString4, 
		PString5, 
		PString6, 
		PString7, 
		PString8, 
		PString9, 
		PString10, 
		PString11, 
		PString12, 
		PString13, 
		PString14, 
		PString15, 
		PString16, 
		PString17, 
		PString18, 
		PString19, 
		PString20, 
		PString21, 
		PString22, 
		PString23, 
		PString24, 
		PString25, 
		PString26, 
		PString27, 
		PString28, 
		PString29, 
		PString30, 
		PString31, 
		PString32, 
		PString33, 
		PString34, 
		PString35, 
		PString36, 
		PString37, 
		PString38, 
		PString39, 
		PString40, 
		PString41, 
		PString42, 
		PString43, 
		PString44, 
		PString45,
		PMoney1, 
		PMoney2, 
		PMoney3, 
		PMoney4, 
		PMoney5, 
		PMoney6, 
		PMoney7, 
		PMoney8, 
		PMoney9, 
		PMoney10, 
		PMoney11, 
		PMoney12, 
		PMoney13, 
		PMoney14, 
		PMoney15, 
		PMoney16, 
		PMoney17, 
		PMoney18, 
		PMoney19, 
		PMoney20, 
		PMoney21, 
		PMoney22, 
		PMoney23, 
		PMoney24, 
		PMoney25, 
		PLong1, 
		PLong2, 
		PLong3, 
		PLong4, 
		PLong5, 
		PLong6, 
		PLong7, 
		PLong8, 
		PLong9, 
		PLong10, 
		PLong11, 
		PLong12, 
		PLong13, 
		PLong14, 
		PLong15, 
		PLong16, 
		PLong17, 
		PLong18, 
		PLong19, 
		PLong20,
		PLong21, 
		PLong22, 
		PLong23, 
		PLong24, 
		PLong25, 
		PLong26, 
		PLong27, 
		PLong28, 
		PLong29, 
		PLong30, 
		PLong31, 
		PLong32, 
		PLong33, 
		PLong34, 
		PLong35, 
		PLong36, 
		PLong37, 
		PLong38, 
		PLong39, 
		PLong40, 
		PLong41, 
		PLong42, 
		PLong43, 
		PLong44, 
		PLong45, 
		PLong46, 
		PLong47, 
		PLong48, 
		PLong49, 
		PLong50, 
		PString46, 
		PString47, 
		PString48, 
		PString49, 
		PString50, 
		PMoney26, 
		PMoney27, 
		PMoney28, 
		PMoney29, 
		PMoney30, 
		PMoney31, 
		PMoney32, 
		PMoney33, 
		PMoney34, 
		PMoney35, 
		PMoney36, 
		PMoney37, 
		PMoney38, 
		PMoney39, 
		PMoney40, 
		PMoney41, 
		PMoney42, 
		PMoney43, 
		PMoney44, 
		PMoney45, 
		PMoney46, 
		PMoney47, 
		PMoney48, 
		PMoney49, 
		PMoney50, 
		PDate1, 
		PDate2, 
		PDate3, 
		PDate4, 
		PDate5, 
		PDate6, 
		PDate7, 
		PDate8, 
		PDate9, 
		PDate10, 
		LastName, 
		FirstName, 
		MiddleName, 
		Suffix, 
		SocialSecurityNumber, 
		AlternateID1Name, 
		AlternateID1, 
		AlternateID2Name, 
		AlternateID2, 
		DriversLicenseNumber, 
		DateOfBirth, 
		HomePhone, 
		MobilPhone, 
		Employment, 
		EmploymentPhone, 
		EmploymentPhoneExtension, 
		Fax, 
		Email, 
		CallAfter, 
		BankRuptDate, 
		BankRuptType, 
		[Language],
		SpouseID, 
		TimeZone, 
		GMTOffset, 
		Nationality, 
		Other_Phone_Number, 
		Other_Phone_Number1, 
		Home_PO_Box, 
		Nearest_Landmark, 
		NO_Of_Years_Resi, 
		Business_Type, 
		Position, 
		Profession, 
		Department, 
		Employee_Number, 
		Title, 
		Employer_Code, 
		FriendName, 
		Friend_Off_Phone, 
		Friend_Res_Phone, 
		Friend_FaxNo,
		(SELECT COUNT(Account.AccountID) FROM Account WHERE Account.DebtorID = DebtorInformation.DebtorID) AS ACCOUNTCOUNT,
		(SELECT SUM(Account.BillBalance) FROM Account WHERE Account.DebtorID = DebtorInformation.DebtorID) AS ACCOUNTBALANCE
	FROM DebtorInformation
	LEFT JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID
	WHERE
		(@PersonID = 0 AND DebtorInformation.DebtorID = @DebtorID) OR (DebtorInformation.PersonID = @PersonID)
	SET NOCOUNT OFF
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonAddress_Get]    Script Date: 07/22/2008 18:42:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonAddress_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonAddress_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonAddress_Get]    Script Date: 07/22/2008 18:42:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================================
-- Author:		Triet Pham
-- Create date: Mar 26th, 2008
-- Description:	Retrieve all personal addresses
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_PersonAddress_Get]	
	@DebtorID int,
	@PersonID int = 0
AS
BEGIN

	SET NOCOUNT ON	
	
	DECLARE @HomeAddress1 varchar(255)
	DECLARE @HomeAddress2 varchar(255)
	DECLARE @HomeAddress3 varchar(255)
	DECLARE @HomeCity varchar(255)
	DECLARE @HomeState varchar(50)
	DECLARE @HomeZip varchar(25)
	DECLARE @HomeCountry varchar(50)
	DECLARE @HomeTerritory varchar(50)
	DECLARE @HomeRegion varchar(50)
	DECLARE @HomeMailingAddress bit

	DECLARE @PostalAddress1 varchar(255)
	DECLARE @PostalAddress2 varchar(255)
	DECLARE @PostalAddress3 varchar(255)
	DECLARE @PostalCity varchar(255)
	DECLARE @PostalState varchar(50)
	DECLARE @PostalZip varchar(25)
	DECLARE @PostalCountry varchar(50)
	DECLARE @PostalTerritory varchar(50)
	DECLARE @PostalRegion varchar(50)
	DECLARE @PostalMailingAddress bit

	DECLARE @EmploymentAddress1 varchar(255)
	DECLARE @EmploymentAddress2 varchar(255)
	DECLARE @EmploymentAddress3 varchar(255)
	DECLARE @EmploymentCity varchar(255)
	DECLARE @EmploymentState varchar(50)
	DECLARE @EmploymentZip varchar(25)
	DECLARE @EmploymentCountry varchar(50)
	DECLARE @EmploymentTerritory varchar(50)
	DECLARE @EmploymentRegion varchar(50)
	DECLARE @EmploymentMailingAddress bit

	DECLARE @OtherAddress1 varchar(255)
	DECLARE @OtherAddress2 varchar(255)
	DECLARE @OtherAddress3 varchar(255)
	DECLARE @OtherCity varchar(255)
	DECLARE @OtherState varchar(50)
	DECLARE @OtherZip varchar(25)
	DECLARE @OtherCountry varchar(50)
	DECLARE @OtherTerritory varchar(50)
	DECLARE @OtherRegion varchar(50)
	DECLARE @OtherMailingAddress bit

	SELECT
		@HomeAddress1 = p.Address1,
		@HomeAddress2 = p.Address2,
		@HomeAddress3 = p.Address3,
		@HomeCity = p.City,
		@HomeState = p.State,
		@HomeZip = p.Zip,
		@HomeCountry = p.Country,
		@HomeTerritory = p.Territory,
		@HomeRegion = p.Region,
		@HomeMailingAddress = p.MailingAddress
	FROM PersonAddress p 
	INNER JOIN DebtorInformation d ON p.PersonID = d.PersonID
	WHERE 
		(@PersonID = 0 AND d.DebtorID = @DebtorID) OR (d.PersonID = @PersonID)
		AND p.AddressType = 1

	SELECT
		@EmploymentAddress1 = p.Address1,
		@EmploymentAddress2 = p.Address2,
		@EmploymentAddress3 = p.Address3,
		@EmploymentCity = p.City,
		@EmploymentState = p.State,
		@EmploymentZip = p.Zip,
		@EmploymentCountry = p.Country,
		@EmploymentTerritory = p.Territory,
		@EmploymentRegion = p.Region,
		@EmploymentMailingAddress = p.MailingAddress
	FROM PersonAddress p 
	INNER JOIN DebtorInformation d ON p.PersonID = d.PersonID
	WHERE 
		(@PersonID = 0 AND d.DebtorID = @DebtorID) OR (d.PersonID = @PersonID)
		AND p.AddressType = 2

	SELECT
		@PostalAddress1 = p.Address1,
		@PostalAddress2 = p.Address2,
		@PostalAddress3 = p.Address3,
		@PostalCity = p.City,
		@PostalState = p.State,
		@PostalZip = p.Zip,
		@PostalCountry = p.Country,
		@PostalTerritory = p.Territory,
		@PostalRegion = p.Region,
		@PostalMailingAddress = p.MailingAddress
	FROM PersonAddress p 
	INNER JOIN DebtorInformation d ON p.PersonID = d.PersonID
	WHERE 
		(@PersonID = 0 AND d.DebtorID = @DebtorID) OR (d.PersonID = @PersonID)
		AND p.AddressType = 3

	SELECT
		@OtherAddress1 = p.Address1,
		@OtherAddress2 = p.Address2,
		@OtherAddress3 = p.Address3,
		@OtherCity = p.City,
		@OtherState = p.State,
		@OtherZip = p.Zip,
		@OtherCountry = p.Country,
		@OtherTerritory = p.Territory,
		@OtherRegion = p.Region,
		@OtherMailingAddress = p.MailingAddress
	FROM PersonAddress p 
	INNER JOIN DebtorInformation d ON p.PersonID = d.PersonID
	WHERE 
		(@PersonID = 0 AND d.DebtorID = @DebtorID) OR (d.PersonID = @PersonID)
		AND p.AddressType = 4

	SELECT 
		@HomeAddress1 AS HomeAddress1,
		@HomeAddress2 AS HomeAddress2,
		@HomeAddress3 AS HomeAddress3,
		@HomeCity AS HomeCity,
		@HomeState AS HomeState,
		@HomeZip AS HomeZip,
		@HomeCountry AS HomeCountry,
		@HomeTerritory AS HomeTerritory,
		@HomeRegion AS HomeRegion,
		@HomeMailingAddress AS HomeMailingAddress,

		@PostalAddress1 AS PostalAddress1,
		@PostalAddress2 AS PostalAddress2,
		@PostalAddress3 AS PostalAddress3,
		@PostalCity AS PostalCity,
		@PostalState AS PostalState,
		@PostalZip AS PostalZip,
		@PostalCountry AS PostalCountry,
		@PostalTerritory AS PostalTerritory,
		@PostalRegion AS PostalRegion,
		@PostalMailingAddress AS PostalMailingAddress,

		@EmploymentAddress1 AS EmploymentAddress1,
		@EmploymentAddress2 AS EmploymentAddress2,
		@EmploymentAddress3 AS EmploymentAddress3,
		@EmploymentCity AS EmploymentCity,
		@EmploymentState AS EmploymentState,
		@EmploymentZip AS EmploymentZip,
		@EmploymentCountry AS EmploymentCountry,
		@EmploymentTerritory AS EmploymentTerritory,
		@EmploymentRegion AS EmploymentRegion,
		@EmploymentMailingAddress AS EmploymentMailingAddress,

		@OtherAddress1 AS OtherAddress1,
		@OtherAddress2 AS OtherAddress2,
		@OtherAddress3 AS OtherAddress3,
		@OtherCity AS OtherCity,
		@OtherState AS OtherState,
		@OtherZip AS OtherZip,
		@OtherCountry AS OtherCountry,
		@OtherTerritory AS OtherTerritory,
		@OtherRegion AS OtherRegion,
		@OtherMailingAddress AS OtherMailingAddress

	SET NOCOUNT OFF
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonPhone_Get]    Script Date: 07/22/2008 18:43:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonPhone_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonPhone_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonPhone_Get]    Script Date: 07/22/2008 18:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================================
-- Author:		Triet Pham
-- Create date: Mar 26th, 2008
-- Description:	Retrieve all personal phone details
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_PersonPhone_Get]	
	@DebtorID int,
	@PersonID int = 0
AS
BEGIN
	SET NOCOUNT ON	

	DECLARE @TYPE8PHONENO varchar(50)
	DECLARE @TYPE8PHONEDESC varchar(255)
	DECLARE @TYPE9PHONENO varchar(50)
	DECLARE @TYPE9PHONEXT varchar(25)

	SELECT 
		@TYPE8PHONENO = PhoneNumber,
		@TYPE8PHONEDESC = Description
	FROM PersonPhone AS ph INNER JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (d.PersonID = @PersonID))
		AND ph.PhoneType = 8

	SELECT 
		@TYPE9PHONENO = PhoneNumber,
		@TYPE9PHONEXT = PhoneExtension
	FROM PersonPhone AS ph INNER JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (d.PersonID = @PersonID))
		AND ph.PhoneType = 9

	SELECT
		@TYPE8PHONENO AS TYPE8PHONENO,
		@TYPE8PHONEDESC AS TYPE8PHONEDESC,
		@TYPE9PHONENO AS TYPE9PHONENO,
		@TYPE9PHONEXT AS TYPE9PHONEXT 
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Spouse_GetByDebtor]    Script Date: 07/22/2008 18:44:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Spouse_GetByDebtor]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Spouse_GetByDebtor]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Spouse_GetByDebtor]    Script Date: 07/22/2008 18:44:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: May 15,2008
-- Description:	Retrieve the spouse personal information of the debtor
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Spouse_GetByDebtor] 
	@DebtorID int,
	@PersonID int = 0
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		s.FirstName as SPOUSEFIRSTNAME, 
		s.MiddleName as SPOUSEMIDDLENAME, 
		s.LastName as SPOUSELASTNAME, 
		s.AlternateID1Name as SPOUSEALTERNATEIDNAME, 
		s.AlternateID2Name as SPOUSEALTERNATEID2NAME, 
		s.AlternateID1 as SPOUSEALTERNATEID1, 
		s.AlternateID2 as SPOUSEALTERNATEID2, 
		s.DriversLicenseNumber as SPOUSEDRIVERSLICENSE,
		s.MobilPhone as SPOUSEMOBILE, 
		s.Employment as SPOUSEEMP, 
		s.EmploymentPhone as SPOUSEEMPPHONE, 
		s.EmploymentPhoneExtension as SPOUSEEMPPHONEEXT,  
		s.Fax as SPOUSEFAX, 
		s.SocialSecurityNumber as SPOUSESOCIALSECURITYNUMBER, 
		s.DateOfBirth as SPOUSEDATEOFBIRTH, 
		s.Email as SPOUSEEMAIL		
	FROM PersonInformation as s
	INNER JOIN DebtorInformation di on di.PersonID = s.PersonID
	INNER JOIN PersonInformation as d ON d.PersonID = s.SpouseID
	WHERE
		(@PersonID = 0 AND di.DebtorID = @DebtorID) OR (di.PersonID = @PersonID)
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]    Script Date: 07/22/2008 18:45:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetTotalQueueStatsByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]    Script Date: 07/22/2008 18:45:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		<Long Nguyen>
-- Create date: <Jul 11, 2008>
-- Description:	<Get Queue Statistic by Collector for the datagrid>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int
AS
BEGIN

	DECLARE @AccountCount int
	DECLARE @Touched int
	DECLARE @Actioned int
	DECLARE @Worked int
	DECLARE @Contacted int
	DECLARE @Promised int
	DECLARE @AccountBalance money

	IF (@ReportTime = 0)
		BEGIN

			SELECT
				@AccountCount = ISNULL(COUNT(DISTINCT AccountID),0),
				@AccountBalance = ISNULL(SUM(BillBalance),0)
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
								AND CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
								AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
								AND SystemStatusID in (1,5))

			SELECT
				@Touched = ISNULL(COUNT(DISTINCT AccountID),0)
					FROM AccountActions 
					where CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
						AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
						AND ResponsibleParty = @EmployeeID
						AND AccountID not in 
							(SELECT DISTINCT AccountID FROM AccountActions where ActionId <> 8
							AND CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
							AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
							AND ResponsibleParty = @EmployeeID)

			SELECT
				@Actioned = ISNULL(COUNT(DISTINCT AccountID),0)
			from AccountActions
			where CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ActionID <> 8
				AND ResponsibleParty = @EmployeeID

			SELECT
				@Worked = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)				AND ac.ActionID <> 8
				AND av.ConsiderWorked = 1
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Contacted = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)				AND ac.ActionID <> 8
				AND ac.ActionID <> 8
				AND av.ProductivityID = 2
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Promised = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)				AND ac.ActionID <> 8
				AND ac.ActionID <> 8
				AND av.ProductivityID = 1
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@AccountCount AS AccountCount,
				@Touched AS Touched,
				@Actioned AS Actioned,
				@Worked AS Worked,
				@Contacted AS Contacted,
				@Promised AS Promised,
				@AccountBalance AS AccountBalance
		END
	ELSE
		BEGIN
			SELECT
				@AccountCount = ISNULL(COUNT(DISTINCT AccountID),0),
				@AccountBalance = ISNULL(SUM(BillBalance),0)
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
									  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID in (1,5)

			SELECT
				@Touched = ISNULL(COUNT(DISTINCT AccountID),0)
			from AccountActions
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ResponsibleParty = @EmployeeID
				AND AccountID not in 
					(SELECT DISTINCT AccountID FROM AccountActions where ActionId <> 8
					AND CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
					AND ResponsibleParty = @EmployeeID)

			SELECT
				@Actioned = ISNULL(COUNT(DISTINCT AccountID),0)
			from AccountActions
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ActionID <> 8
				AND ResponsibleParty = @EmployeeID

			SELECT
				@Worked = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ac.ActionID <> 8
				AND av.ConsiderWorked = 1
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Contacted = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 2
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Promised = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 1
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@AccountCount AS AccountCount,
				@Touched AS Touched,
				@Actioned AS Actioned,
				@Worked AS Worked,
				@Contacted AS Contacted,
				@Promised AS Promised,
				@AccountBalance AS AccountBalance
		END
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 07/22/2008 18:46:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetQueueStatsByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 07/22/2008 18:46:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <17 June 2008>
-- Description:	<Get Queue Statistic by Collector for chart>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int
	
AS
BEGIN

	DECLARE @BeforeDays INT
	DECLARE @AfterDays INT

	IF (@ReportTime = 0)
		BEGIN
			DECLARE @QueueDate smalldatetime
			DECLARE @AccountCount int
			DECLARE @AccountBalance money

			DECLARE @Temp table
			(
				EmployeeID int,
				QueueDate smalldatetime,
				AccountCount int,
				AccountBalance money
			)

			DECLARE @Index int
			SET @Index = -7

			WHILE @Index < 7
			BEGIN
				SET @QueueDate = GETDATE() + @Index
				SET @AccountCount = 0
				SET @AccountBalance = 0

				SELECT
					@AccountCount = ISNULL(COUNT(AccountID),0),
					@AccountBalance = ISNULL(SUM(BillBalance),0)
				FROM Account
				WHERE 
					CONVERT(VARCHAR(10),QueueDate,121) = CONVERT(VARCHAR(10),@QueueDate,121)
					AND SystemStatusID in (1,5)
					AND EmployeeID = @EmployeeID
				GROUP BY EmployeeID, CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
				ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))

				INSERT INTO @Temp VALUES(@EmployeeID, @QueueDate, @AccountCount, @AccountBalance)

				SET @Index = @Index + 1
			END

			SELECT * FROM @Temp
		END
	ELSE
		BEGIN
			SELECT EmployeeID, CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) as QueueDate, ISNULL(COUNT(AccountID),0) AS AccountCount, ISNULL(SUM(BillBalance),0) AS AccountBalance 
			FROM Account 
			WHERE 
				SystemStatusID in (1,5)
				AND AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))

			GROUP BY EmployeeID, CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
			ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))
		END
END

GO
/******  Script Closed. Go next: Step016_4  ******/