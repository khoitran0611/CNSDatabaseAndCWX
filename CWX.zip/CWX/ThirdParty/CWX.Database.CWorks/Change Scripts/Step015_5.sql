-- Script is applied on version 2.1.10, 2.1.11

/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]    Script Date: 07/10/2008 16:54:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetEmployeePortfolio]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]    Script Date: 07/10/2008 16:54:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetEmployeePortfolio]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get employee portfolio.
-- Parameters: 
--		0: Queue Active
--		Other number: All accounts
-- History:
--		2008/04/17	[Binh Truong]	Init version.
--		2008/05/15	[Binh Truong]	Cast BillBalance field to decimal(18,2) to fix Arithmetic overflow error converting expression.
--		2008/07/10	[Binh Truong]	Fix BillBalance NULL returned values.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]
	@PorfolioType smallint = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @TotalAccStatement NVARCHAR(1000)
	DECLARE @TotalDollarValueStatement NVARCHAR(1000)
	DECLARE @MainStatement NVARCHAR(4000)
	DECLARE @RowCount INT
	
	SET @Conditions = ''''	

	IF @PorfolioType = 0		
		SET @Conditions = ''
			AND SystemStatusId = 5 
			AND AgencyStatusID <> 2 
			AND QueueDate <= GETDATE()
			''
	
	DECLARE @ParmDefinition NVARCHAR(500);
	DECLARE @TotalAccount INT;
	DECLARE @TotalDollarValue DECIMAL(18,2);

	SET @TotalAccStatement = N''SELECT @TotalAccountOUT = COUNT(*) FROM Account WHERE (1=1) '';
	SET @TotalAccStatement = @TotalAccStatement + @Conditions
	SET @ParmDefinition = N''@TotalAccountOUT INT OUTPUT'';

	EXECUTE sp_executesql @TotalAccStatement, @ParmDefinition, @TotalAccountOUT=@TotalAccount OUTPUT;

	SET @TotalDollarValueStatement = N''SELECT @TotalDollarValueOUT = SUM(cast(ISNULL(BillBalance,0) as decimal)) FROM Account WHERE (1=1)'';
	SET @TotalDollarValueStatement = @TotalDollarValueStatement + @Conditions
	SET @ParmDefinition = N''@TotalDollarValueOUT DECIMAL(18,2) OUTPUT'';

	EXECUTE sp_executesql @TotalDollarValueStatement, @ParmDefinition, @TotalDollarValueOUT=@TotalDollarValue OUTPUT;
	
	--Build the MainStatement
	SET @MainStatement = ''INSERT INTO #Temp SELECT Employee.EmployeeID, Employee.EmployeeName, ''

	SET @MainStatement = @MainStatement + '' (SELECT COUNT(EmployeeID) AS Expr1
						FROM          Account AS AT
						WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalAccount, ''
	
	SET @MainStatement = @MainStatement + '' (SELECT CAST(((COUNT(EmployeeID) * 100) / CAST('' + CAST(@TotalAccount AS VARCHAR(30)) + '' AS DECIMAL(18,2))) AS DECIMAL(18,2)) AS Expr1
						FROM          Account AS AT
						WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalAccountPercent, ''
    
	SET @MainStatement = @MainStatement + '' (SELECT     CAST(SUM(cast(ISNULL(BillBalance,0) as decimal)) as decimal(18,2)) 
                    FROM        Account AS AT
                    WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalDollarValue, ''

	SET @MainStatement = @MainStatement + '' (SELECT     CAST(SUM(cast(ISNULL(BillBalance,0) as decimal)) as decimal(18,2)) * 100 / CAST('' + CAST(@TotalDollarValue AS VARCHAR(30)) + ''AS DECIMAL(18,2)) AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalDollarValuePercent, ''

	SET @MainStatement = @MainStatement + '' (SELECT     COUNT(TempEmployeeID) AS Expr1
					FROM          Account AS AT
					WHERE      (AT.TempEmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.TempEmployeeID) AS TotalAccountTemp, '' 

	SET @MainStatement = @MainStatement + '' (SELECT     SUM(cast(ISNULL(BillBalance,0) as decimal)) AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.TempEmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.TempEmployeeID) AS TotalDollarValueAccountTemp ''

	SET @MainStatement = @MainStatement +	'' FROM  Employee WHERE EmployeeStatus = ''''A'''''' 

	CREATE TABLE #Temp
	(
		Idx int IDENTITY,
		EmployeeID int,
		EmployeeName varchar(50),
		TotalAccount int,
		TotalAccountPercent DECIMAL(18,0),
		TotalDollarValue DECIMAL(18,2),
		TotalDollarValuePercent DECIMAL(18,0),
		TotalAccountTemp int,
		TotalDollarValueAccountTemp DECIMAL(18,2)		
	)

	EXEC dbo.sp_executesql @MainStatement
	
	SELECT @RowCount = Count(Idx) FROM #Temp

	SELECT  EmployeeName,
			EmployeeID,
			ISNULL(TotalAccount, 0) AS TotalAccount,
			CAST(ISNULL(TotalAccountPercent, 0) as varchar(50)) AS TotalAccountPercent,
			ISNULL(TotalDollarValue, 0) AS TotalDollarValue,
			CAST(ISNULL(TotalDollarValuePercent, 0) as varchar(50)) AS TotalDollarValuePercent,
			ISNULL(TotalAccountTemp, 0) AS TotalAccountTemp,
			ISNULL(TotalDollarValueAccountTemp, 0) AS TotalDollarValueAccountTemp
			
	FROM #Temp WHERE Idx between (@PageIndex)*@PageSize + 1 and (@PageIndex + 1)*@PageSize

	DROP TABLE #Temp
	
	RETURN @RowCount
END


' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetAvailablePool]    Script Date: 07/10/2008 17:30:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetAvailablePool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetAvailablePool]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetAvailablePool]    Script Date: 07/10/2008 17:30:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






-- =============================================
-- Author:		LongNguyen
-- Create date: Jul 10, 2008
-- Description:	Get all avalable pool
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_GetAvailablePool]
	@EmployeeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT EmployeeID AS PoolID, EmployeeID, Description
	FROM Employee
	WHERE
		EmployeeStatus <> 'R' AND EmployeeType = 'P'
		AND EmployeeID NOT IN (SELECT PoolID FROM EmployeePool WHERE EmployeeID = @EmployeeID)
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetSelectedPool]    Script Date: 07/10/2008 17:31:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetSelectedPool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetSelectedPool]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetSelectedPool]    Script Date: 07/10/2008 17:31:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






-- =============================================
-- Author:		LongNguyen
-- Create date: Jul 10, 2008
-- Description:	Get all selected pool
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_GetSelectedPool]
	@EmployeeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT p.PoolID, e.EmployeeID, e.Description
	FROM EmployeePool p
	LEFT JOIN Employee e ON e.EmployeeID = p.PoolID
	WHERE
		e.EmployeeStatus <> 'R'
		AND p.EmployeeID = @EmployeeID
END
GO

-- Scripts 2.1.11:
--Thuy Nguyen added on 11-July-2008
alter table SiteVisit add PaymentType smallint, PaymentMode smallint,CheckNumber varchar(50)
alter table SiteVisit drop column Requester, RequestDate, AssignedTo, CloseBy, CloseDate, ApprovedBy, ApprovedDate, SubmitTo, SiteVisitType
-------------
GO

update TicketStatus set Description='Cancelled' where TicketStatusID=5
GO

/****** Object:  StoredProcedure [dbo].[CWX_TicketStage_Get]    Script Date: 07/11/2008 10:56:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketStage_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TicketStage_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TicketStage_Get]    Script Date: 07/11/2008 10:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketStage_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
CREATE proc [dbo].[CWX_TicketStage_Get]
	@TicketID int
As
BEGIN
	select TicketStageID,Stage,InDate,DueDate,OutDate,s.Description as StageStatus,e.EmployeeName
		from TicketStages t inner join Employee e on t.EmployeeID=e.EmployeeID
		left join TicketStatus s on t.StageStatus=s.TicketStatusID
		where TicketID=@TicketID
		order by Stage asc
END' 
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByEmployeeName] 
	-- Add the parameters for the stored procedure here
	@EmployeeName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
	WHERE
		a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			g.EmployeeName AS [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID 
		WHERE
			a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END


set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go




-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_AgencyStatus int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId AS varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID = '+CAST(@v_AgencyStatus AS varchar(9))


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


Update QueryParams set PickList = 'ALL|0|Active|5|New|2|Legal|1' where QueryID = 1

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go








-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_SystemStatus int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId as varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID <> 2'

	IF @v_SystemStatus = 0 
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'+''

	IF ((@v_SystemStatus = 1) or (@v_SystemStatus = 5))
		SET @cStmt=@cStmt+' AND s.SystemStatus = '+CAST(@v_SystemStatus AS char(9))+''

	IF @v_SystemStatus = 2
	BEGIN
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'+''
		SET @cStmt=@cStmt+' AND convert(varchar(10),a.SubmissionDate,121)=convert(varchar(10),GetDate(),121)'+''
	END

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go




-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchDebtorByName] 
	-- Add the parameters for the stored procedure here
	@DebtorName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 10, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SVByEmployee] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@CollectorID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
	INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
	WHERE
		e.Supervisor = 1
		AND (a.EmployeeID = @CollectorID OR a.TempEmployeeID = @CollectorID)
		AND a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND a.AgencyStatusID <> 2

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.QueueDate desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
		INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
		WHERE
			e.Supervisor = 1
			AND (a.EmployeeID = @CollectorID OR a.TempEmployeeID = @CollectorID)
			AND a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchAccountByBill](@AcctID INT,@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where a.AccountID = '+Cast(@AcctID As Char(9))
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END


set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- Script is applied on version 1.9.23

ALTER   PROCEDURE [dbo].[SearchAccountByInvoice](@Invoice char(50),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name],'
	SET @cStmt=@cStmt+'a.DebtorID As [DebtorID]'	
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where a.InvoiceNumber = '+''''+Cast(@Invoice As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchAccountByMobile](@MobilePhone char(50),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
SET @cStmt=@cStmt+'a.CCode as [Cycle],'
SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where p.MobilPhone = '+''''+Cast(@MobilePhone As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchDebtorByPhone](@PhoneNumber char(25),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where p.HomePhone = '+''''+Cast(@PhoneNumber As Char(25))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'

	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchByofficePhone](@PhoneNumber char(50),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where p.EmploymentPhone = '+''''+Cast(@PhoneNumber As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchReviewAccounts] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeID
	WHERE
		a.ActionEmployee = @v_EmployeeId
		AND a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND a.AgencyStatusID <> 2

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			e.EmployeeName [Referred From]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeID
		WHERE
			a.ActionEmployee = @v_EmployeeId
			AND a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Referred From]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/******  Script Closed. Go next: Step015_6  ******/