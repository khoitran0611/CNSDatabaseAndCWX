﻿ IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
	WHERE TABLE_NAME = 'QueryParams' AND COLUMN_NAME = 'ParaType')
BEGIN
	ALTER TABLE [dbo].[QueryParams] 
		ADD [ParaType] varchar(10) not null default 'text'
END
GO


-- [2009-12-21] [Minh Dam] Alter SP CWX_QueueSortMaster_AddRemove
/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_AddRemove]    Script Date: 12/21/2009 14:20:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
--	[2009-12-08]	Minh Dam		Add parameter @EmployeeID to @QueuePriorities xml
-- =============================================
ALTER PROCEDURE [dbo].[CWX_QueueSortMaster_AddRemove] 
	@QueuePriorities xml
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @tbQueuePriority table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4),
		EmployeeID int
	)

	DECLARE @NewQueueID int
	SET @NewQueueID = 1

	DECLARE @QueueID int
	DECLARE @Description varchar(60)
	DECLARE @EmployeeID int

	DECLARE @SortID int
	IF EXISTS (SELECT QueueId FROM QueueSortMaster WHERE sortid = 0)
		SET @SortID = 0
	ELSE
		SET @SortID = @NewQueueID

	DECLARE QueuePriorityCrsr CURSOR FOR
	SELECT
		ParamValues.QueuePriority.value('./@QueueID','int') AS QueueID,
		ParamValues.QueuePriority.value('./@Description','varchar(60)') AS Description,
		ParamValues.QueuePriority.value('./@EmployeeID', 'int') AS EmployeeID
	FROM
		@QueuePriorities.nodes('/QueuePriorities/QueuePriority') as ParamValues(QueuePriority) 

	OPEN QueuePriorityCrsr

	FETCH NEXT FROM QueuePriorityCrsr
	INTO @QueueID, @Description, @EmployeeID

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @SortID > 0
			SET @SortID = @NewQueueID

		IF @QueueID = 0
			INSERT INTO @tbQueuePriority
			VALUES(@NewQueueID, @Description, '"' + @Description + '"', @SortID, 'ASC ', @EmployeeID)
		ELSE IF @QueueID > 0
			INSERT INTO @tbQueuePriority
			SELECT
				@NewQueueID, Description, QueueColumn, @SortID, SortDirection, @EmployeeID
			FROM
				QueueSortMaster
			WHERE
				QueueId = @QueueID AND ISNULL(EmployeeID,0) = @EmployeeID	
		
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM QueuePriorityCrsr
		INTO @QueueID, @Description, @EmployeeID
	END

	DELETE FROM QueueSortMaster WHERE ISNULL(EmployeeID,0) = @EmployeeID
	IF( @@ERROR <> 0)
		GOTO Cleanup

	INSERT INTO QueueSortMaster SELECT * FROM @tbQueuePriority
	IF( @@ERROR <> 0)
		GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE QueuePriorityCrsr
	DEALLOCATE QueuePriorityCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END
GO


-- [2009-12-21] [Minh Dam] Insert new records for submission date search
IF NOT EXISTS (SELECT 1 FROM QueryMaster WHERE ID = 29)
BEGIN
	INSERT INTO QueryMaster(ID, DatabaseID, Description, SQL,  CallingApp, SQL2, SortOrder, QueueGroupID)
	VALUES (29, 1, 'Submission Date', '',  0, 'EXEC CWX_Account_SearchBySubmissionDate %E, %1', 1, 1)
END
GO

IF NOT EXISTS (SELECT 1 FROM QueryParams WHERE QueryID = 29 AND ParamID = 1)
BEGIN
	INSERT INTO QueryParams(QueryID, ParamID, Text, Format, PickList, ParaType)
	VALUES (29, 1, 'Submission Date', '', '', 'date')
END
GO


-- [2009-12-21] [Minh Dam] Create SP CWX_Account_SearchBySubmissionDate
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchBySubmissionDate]    Script Date: 12/21/2009 14:52:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchBySubmissionDate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchBySubmissionDate]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchBySubmissionDate]    Script Date: 12/21/2009 14:52:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 2009-12-21
-- Description:	Search account by submission date
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchBySubmissionDate]
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_submissionDate datetime,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_employeeId, @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'				
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId AS varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND DATEDIFF(day, a.SubmissionDate, ''' + convert(varchar(20), @v_submissionDate, 111) + ''')=0' 

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO