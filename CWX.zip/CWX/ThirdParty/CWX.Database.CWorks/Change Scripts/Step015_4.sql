-- Script is applied on version 2.1.8, 2.1.9
-- =======================================================================
-- Author:		Minh Dam
-- Create date: Jul 09, 2008
-- Description:	Create table Legal_AgentOccupations
-- Effected table:	Legal_AgentOccupations
-- =======================================================================
/****** Object:  Table [dbo].[Legal_AgentOccupations]    Script Date: 06/17/2008 09:29:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_AgentOccupations](
	[AgentOccupationID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Seq] [int] NOT NULL CONSTRAINT [DF_Legal_AgentOccupations_Seq]  DEFAULT ((0)),
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_AgentOccupations_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_AgentOccupations] PRIMARY KEY CLUSTERED 
(
	[AgentOccupationID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Jul 09, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_AgentOccupations
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_AgentOccupations' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_AgentOccupations
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_AgentOccupations_RowStatus] DEFAULT 'A'
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingList]    Script Date: 07/09/2008 14:32:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Contacts_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingList]    Script Date: 07/09/2008 14:32:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Contacts_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-08
-- Description:	Get paging list of LegalContacts, alphabetically ascending order by 
-- ''Parent Contact Employee Name'' group by ''Parent Contact Type''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingList]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT
		ROW_NUMBER() OVER (ORDER BY a.ParentType, Coalesce(b.Code, c.Code, d.Code)) AS RowNumber,
		a.ContactID,
		a.ParentType, 
		Coalesce(b.Code, c.Code, d.Code) Code, 
		Coalesce(b.Name, c.CommonName, d.Name) [Name],
		IsNull(Title,'''') Title, IsNull(FirstName, '''') FirstName, IsNull(LastName, '''') LastName, 
		a.[Description]		
	INTO #Temp
	FROM Legal_Contacts a
		LEFT JOIN Legal_Solicitors b ON a.ParentID = b.SolicitorID AND ParentType = ''1''
		LEFT JOIN Legal_Creditors c ON a.ParentID = c.CreditorID AND ParentType = ''3''
		LEFT JOIN Legal_Agents d ON a.ParentID = d.AgentID AND ParentType = ''2''
	WHERE  a.Status <> ''R''
	ORDER BY a.ParentType, Code	

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT ContactID, ParentType, Code + Case When [Name]<>'''' Then '' - '' + [Name] Else '''' End CodeAndName, 
			LTRIM(Case When Title<>'''' Then Title Else '''' End + Case When FirstName<>'''' Then '' ''+FirstName Else '''' End + 
				Case When LastName<>'''' Then '' '' + LastName Else '''' End) ContactName,
			[Description]
	FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
' 
END
GO

-- Scripts 2.1.9:

/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]    Script Date: 07/10/2008 10:19:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]    Script Date: 07/10/2008 10:19:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Get total active account and bill balance of collector
-- History:
--	2008/04/17	[Binh Truong]	Init version.
--	2008/04/23	[Binh Truong]	Cast BillBalance field to decimal to fix Arithmetic overflow error converting expression.
--	2008/07/10	[Binh Truong]	Fix NULL returned values.
-- Parameters: 
--	@PorfolioType	0: Queue Active
--					Other number: All accounts
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]
	@PorfolioType AS SMALLINT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Select NVARCHAR(1000)
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @Statement NVARCHAR(2000)
	DECLARE @Parms NVARCHAR(500)
	
	SET @Conditions = '' WHERE (Employee.EmployeeStatus = ''''A'''') ''	
	
	SET @Select = ''
		SELECT	COUNT(Account.AccountID) AS TotalAccount,
				ISNULL(SUM(CAST(Account.BillBalance as decimal)),0) as TotalDollarValue 
		FROM         Account INNER JOIN
                      Employee ON Account.EmployeeID = Employee.EmployeeID     
		'' 		
		
	IF @PorfolioType = 0		
		SET @Conditions = @Conditions + ''
					AND SystemStatusId = 5 
					AND AgencyStatusID <> 2 
					AND QueueDate <= GETDATE()
			''
		
	SET @Statement = @Select + @Conditions
	
	EXEC dbo.sp_executesql @Statement
		
	SET @Select = ''
		SELECT	COUNT(Account.TempEmployeeID ) AS TotalTempAccount,
				ISNULL(SUM(CAST(BillBalance as decimal)),0) as TotalTempDollarValue 
		FROM         Account INNER JOIN
                      Employee ON Account.TempEmployeeID = Employee.EmployeeID     
		'' 		
		
	SET @Statement = @Select + @Conditions
	
	EXEC dbo.sp_executesql @Statement
	
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Ticket_ViewTicket]    Script Date: 07/10/2008 14:11:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Khoa Dang
ALTER PROCEDURE [dbo].[CWX_Ticket_ViewTicket]
	@accountID int,
	@pageSize int,
	@pageIndex int
AS
BEGIN
	declare @startRow int, @endRow int
	declare @totalRow int
	set @startRow = @pageIndex * @pageSize + 1
	set @endRow = (@pageIndex + 1) * @pageSize

	select row_number() over (order by t.RequestDate desc) as RowNumber, t.TicketID, t.TicketTypeID, d.Description, STR(t.CurrentStage) + '/' + STR(t.TotalStage) as Stage, t.RequestDate, t.StartDate,
		t.DueDate, (select Description from TicketStatus where TicketStatusID=t.TicketStatus) as TicketStatus,
		(select EmployeeName from Employee where EmployeeID=t.Requester) as RequesterName,
		(select EmployeeName from Employee where EmployeeID=t.AssignedTo) as AssignedTo,
		t.AttachmentID
	into #TicketView
	from Ticket t inner join TicketDefinition d on t.TicketTypeID=d.TktDefID
	where t.AccountID=@AccountID
	
	select @totalRow=@@RowCount
	select * from #TicketView where RowNumber between @startRow and @endRow
	select @totalRow as TotalRow
END

/******  Script Closed. Go next: Step015_5  ******/