-- Script is applied on version 2.2.16, 2.2.17
/************* Update InformationTable to add 2 new product setting *************/
IF NOT EXISTS (SELECT * FROM InformationTable WHERE InfoID=6 AND InfoSubType=17)
BEGIN
	DECLARE ProductSettingCrsr CURSOR FOR
	SELECT DISTINCT InfoType FROM InformationTable WHERE InfoID=6

	OPEN ProductSettingCrsr
	DECLARE @InfoType int

	FETCH NEXT FROM ProductSettingCrsr INTO @InfoType

	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO InformationTable VALUES(6, @InfoType, 17, '0', 'MaximumDiscountAmount',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 17, '1', 'MaximumDiscountAmount',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 17, '2', 'MaximumDiscountAmount',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 17, '3', 'MaximumDiscountAmount',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 17, '4', 'MaximumDiscountAmount',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 17, '5', 'MaximumDiscountAmount',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 17, '6', 'MaximumDiscountAmount',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 17, '6+','MaximumDiscountAmount',	'50', '', 'A')

		INSERT INTO InformationTable VALUES(6, @InfoType, 18, '0', 'MaximumDiscountPercentage',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 18, '1', 'MaximumDiscountPercentage',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 18, '2', 'MaximumDiscountPercentage',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 18, '3', 'MaximumDiscountPercentage',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 18, '4', 'MaximumDiscountPercentage',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 18, '5', 'MaximumDiscountPercentage',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 18, '6', 'MaximumDiscountPercentage',	'50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @InfoType, 18, '6+','MaximumDiscountPercentage',	'50', '', 'A')

		FETCH NEXT FROM ProductSettingCrsr INTO @InfoType
	END

	CLOSE ProductSettingCrsr
	DEALLOCATE ProductSettingCrsr
END
/************* End Update InformationTable to add 2 new product setting *************/

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Jul 24, 2008
-- Description:		Create store procedure 'Legal_Snapshots_GetPagingList
-- =======================================================================
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Snapshots_GetPagingList]    Script Date: 07/24/2008 18:24:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Snapshots_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Snapshots_GetPagingList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Snapshots_GetPagingList]    Script Date: 07/24/2008 18:24:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Legal_Snapshots_GetPagingList]
	@GroupStepID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	SELECT ROW_NUMBER() OVER(ORDER BY b.[Code]) as RowNumber,
			a.[SnapshotID], a.[DateCreated], a.[DebtAmount],
			b.[Code] + ' - ' + b.[Description] as SnapshotType
	INTO #temp
	FROM Legal_Snapshots a
		LEFT JOIN Legal_SnapshotTypes b ON a.[SnapshotTypeID] = b.[SnapshotTypeID] AND b.[Status] <> 'R'
	WHERE a.GroupStepID = @GroupStepID
	ORDER BY RowNumber
	
	Declare @RowCount int
	Set @RowCount = @@ROWCOUNT	

	SELECT 	[SnapshotID], [SnapshotType], [DateCreated], [DebtAmount]
	FROM #temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/******  Script Closed. Go next: Step016_7  ******/