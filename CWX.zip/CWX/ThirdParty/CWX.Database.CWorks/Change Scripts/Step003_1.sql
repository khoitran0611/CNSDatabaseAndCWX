-- =============================================
-- Author:		LongNguyen
-- Create date: Dec 27, 2007
-- Description:	Transfer all accounts of employeeFrom, all employees who are managed by employeeFrom, and all rules assigned to the employeeFrom to the employeeTo
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Employee_Delete]
	@EmployeeID int,
	@TransferEmployeeID int,
	@ReassignSupervisorID int = 0
AS
BEGIN
	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	--Transfer accounts
	UPDATE dbo.Account
	SET
		EmployeeID = @TransferEmployeeID
	WHERE
		EmployeeID = @EmployeeID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Transfer rules
	UPDATE dbo.RulesAllocUsers
	SET
		Employees = REPLACE(Employees, ',' + CAST(@EmployeeID AS varchar) + ',', ',' + CAST(@TransferEmployeeID AS varchar) + ',')
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Transfer employees
	IF @ReassignSupervisorID = 0
		SET @ReassignSupervisorID = @TransferEmployeeID

	IF EXISTS(SELECT * FROM Employee WHERE EmployeeID = @ReassignSupervisorID)
	BEGIN
		EXEC CWX_Employee_Reassign @EmployeeID, @ReassignSupervisorID
		IF( @@ERROR <> 0)
			GOTO Cleanup
	END

	--Mark employee as deleted
	UPDATE dbo.Employee
	SET
		EmployeeStatus = 'R'
	WHERE
		EmployeeID = @EmployeeID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END
GO

 /****** Object:  StoredProcedure [dbo].[CWX_InformationTable_Search]    Script Date: 01/25/2008 10:22:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_InformationTable_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_Search]    Script Date: 01/25/2008 10:22:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_Search]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Binh Truong
-- Create date: Jan 23, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_InformationTable_Search]
	@InfoID INT = NULL, 
	@InfoType INT = NULL,
	@InfoSubType INT = NULL,
	@InfoKey VARCHAR(50) = NULL,
	@OrderByClause VARCHAR(200),
	@PageSize INT = 10,
	@PageIndex INT	 = 0
AS

-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON	

DECLARE @StartRow INT
DECLARE @EndRow INT	
DECLARE @SQL 	NVARCHAR(MAX)
DECLARE @parms 	NVARCHAR(1000)
DECLARE @TotalRow INT

IF @InfoKey = ''''
	SET @InfoKey = NULL

SET @StartRow = @PageIndex * @PageSize + 1
SET @EndRow = (@PageIndex + 1) * @PageSize

SET @SQL = N''
	SELECT	*, ROW_NUMBER() OVER (ORDER BY ''+@OrderByClause+'') AS RowNumber 
	INTO	#InformationTableTemp
	FROM	InformationTable
	WHERE	Status=''''A''''
	''
IF @InfoID IS NOT NULL
	SET @SQL = @SQL + ''AND InfoID = @InfoID ''
IF @InfoType IS NOT NULL
	SET @SQL = @SQL + ''AND InfoType = @InfoType ''
IF @InfoSubType IS NOT NULL
	SET @SQL = @SQL + ''AND InfoSubType = @InfoSubType ''	
IF @InfoKey IS NOT NULL
	SET @SQL = @SQL + ''AND InfoKey = @InfoKey ''
	
SET @SQL = @SQL + N''SELECT @TotalRow = @@ROWCOUNT 
					SELECT * FROM #InformationTableTemp 
					WHERE RowNumber BETWEEN @StartRow AND @EndRow 
					DROP TABLE #InformationTableTemp 
					''
SET @parms = ''
	@InfoID INT = NULL, 
	@InfoType INT = NULL,
	@InfoSubType INT = NULL,
	@InfoKey VARCHAR(50) = NULL,
	@StartRow INT,
	@EndRow INT,
	@TotalRow INT OUTPUT
	''
EXECUTE sp_executesql @sql, @parms, 
			@InfoID, 
			@InfoType,
			@InfoSubType,
			@InfoKey,
			@StartRow,
			@EndRow,
			@TotalRow OUTPUT

SET NOCOUNT OFF

IF @TotalRow IS NULL
	RETURN 0
ELSE
	RETURN @TotalRow
' 
END
GO


-- =======================================================================
-- Author:		Tuan Luong
-- Create date: Jan 31, 2007
-- Description:	Add column 'Status' with default value 'A'
--			    use this field to mark the row is active 'A' or retire 'R'
-- =======================================================================
ALTER TABLE ClientInformation
ADD Status char(1) NOT NULL
	CONSTRAINT [ClientInformation_RowStatus] DEFAULT 'A'
GO

-- =====================================================
-- Author:		Tuan Luong
-- Create date: Jan 26th, 2008
-- Description:	Delete all attorney firm (Referral = 1)
-- Parameters: 
--	@Type: 'S' - Soft delete
--		   'P' - Permanently delete
-- =====================================================
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_Attorney_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientInformation_Attorney_DeleteAll]
GO
CREATE PROCEDURE [dbo].[CWX_ClientInformation_Attorney_DeleteAll]
	@Referral int = 1,
	@Type char(1) = 'S'	
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Type) = 'S'
	BEGIN
		UPDATE ClientInformation
		SET [Status] = 'R'
		WHERE [Status] = 'A' AND Referral = @Referral
	END
	ELSE IF UPPER(@Type) = 'P'
	BEGIN    
		DELETE ClientInformation
		WHERE Referral = @Referral
	END
END
GO

-- ===================================================================================
-- Author:		Tuan Luong
-- Create date: Jan 28th, 2008
-- Description:	Delete all standard notes (InfoID = 4, InfoType = 6, InfoSubType = 0)
-- ===================================================================================
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CWX_InformationTable_StandardNote_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_InformationTable_StandardNote_DeleteAll]
GO
CREATE PROCEDURE [dbo].[CWX_InformationTable_StandardNote_DeleteAll]
	@InfoID int = 4,
	@InfoType int = 6,
	@InfoSubType int = 0	
AS
BEGIN
	SET NOCOUNT ON;    
	DELETE InformationTable
	WHERE	InfoID = @InfoID
			AND	InfoType = @InfoType
			AND InfoSubType = @InfoSubType
END
GO

-- =======================================================================
-- Author:		Tuan Luong
-- Create date: Feb 1, 2007
-- Description:	Add column 'Status' with default value 'A'
--			    use this field to mark the row is active 'A' or retire 'R'
-- =======================================================================
ALTER TABLE AgencyDefinedMaster
ADD Status char(1) NOT NULL
	CONSTRAINT [AgencyDefinedMaster_RowStatus] DEFAULT 'A'
GO

-- =============================================================
-- Author:		Tuan Luong
-- Create date: Jan 30th, 2008
-- Description:	Delete all records in AgencyDefinedMaster Table
-- Parameters: 
--	@Type: 'S' - Soft delete
--		   'P' - Permanently delete
-- =============================================================
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CWX_AgencyDefinedMaster_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AgencyDefinedMaster_DeleteAll]
GO
CREATE PROCEDURE [dbo].[CWX_AgencyDefinedMaster_DeleteAll] 	
	@Status char(1) = 'S'		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = 'S'
	BEGIN
		UPDATE AgencyDefinedMaster
		SET [Status] = 'R'
		WHERE [Status] = 'A'
	END
	ELSE IF UPPER(@Status) = 'P'
	BEGIN    
		DELETE AgencyDefinedMaster
	END
END
GO

-- =======================================================================
-- Author:		Binh Truong
-- Create date: Feb 05, 2007
-- Description:	Add column 'Status' with default value 'A'
--			    use this field to mark the row is active 'A' or retire 'R'
-- =======================================================================
ALTER TABLE EmployeeDepartment
ADD Status char(1) NOT NULL
	CONSTRAINT [EmployeeDepartment_RowStatus] DEFAULT 'A'
GO


-- =============================================================
-- Author:		Binh Truong
-- Create date: Feb 05, 2008
-- Description:	Delete all records in EmployeeDepartment Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- =============================================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Department_DeleteAll]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[CWX_Department_DeleteAll]
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Department_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
	EXEC dbo.sp_executesql @statement = N'-- =============================================================
	-- Author:		Binh Truong
	-- Create date: Feb 05, 2008
	-- Description:	Delete all records in EmployeeDepartment Table
	-- Parameters: 
	--	@Type: ''S'' - Soft delete
	--		   ''P'' - Permanently delete
	-- =============================================================
	create PROCEDURE CWX_Department_DeleteAll 	
		@Type char(1) = ''S''		
	AS
	BEGIN
		SET NOCOUNT ON;
		IF UPPER(@Type) = ''S''
		BEGIN
			UPDATE EmployeeDepartment
			SET [Status] = ''R''
			WHERE [Status] = ''A''
		END
		ELSE IF UPPER(@Type) = ''P''
		BEGIN    
			DELETE EmployeeDepartment
		END
	END
	' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountCodeMaster_DeleteAll]    Script Date: 02/13/2008 17:12:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountCodeMaster_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountCodeMaster_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountCodeMaster_DeleteAll]    Script Date: 02/13/2008 17:12:46 ******/
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountCodeMaster_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Binh Truong
-- Create date: Feb 13, 2008
-- Description:	Delete all records in AccountCodeMaster Table
-- Parameters: 
--  @CodeType: Account code type
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- =============================================================
CREATE PROCEDURE CWX_AccountCodeMaster_DeleteAll
	@CodeType int,
	@Type char(1) = ''S''
AS
BEGIN
	SET NOCOUNT ON
	IF UPPER(@Type) = ''S''
	BEGIN
		UPDATE AccountCodeMaster
		SET [Status] = ''R''
		WHERE CodeType = @CodeType AND [Status] = ''A''
	END
	ELSE IF UPPER(@Type) = ''P''
	BEGIN    
		DELETE AccountCodeMaster
		WHERE CodeType = @CodeType
	END
	
	SET NOCOUNT OFF
END
' 
END
GO

-- =======================================================================
-- Author:		Tuan Luong
-- Create date: Mar 6, 2008
-- Description:	Delete all records in AccountCodeMaster Table (NextAction)
-- Parameters: 
--	@Type: 'S' - Soft delete
--		   'P' - Permanently delete
-- =======================================================================
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].CWX_AccountCodeMaster_NextAction_DeleteAll') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].CWX_AccountCodeMaster_NextAction_DeleteAll
GO
CREATE PROCEDURE [dbo].CWX_AccountCodeMaster_NextAction_DeleteAll 	
	@Status char(1) = 'S'		
AS
BEGIN
	EXEC CWX_AccountCodeMaster_DeleteAll 2, @Status
END
GO