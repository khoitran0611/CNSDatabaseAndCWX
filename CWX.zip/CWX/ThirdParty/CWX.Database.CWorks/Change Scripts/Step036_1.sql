﻿-- Script is applied on version 3.6.7:

PRINT 'Start of Scripts 3.6.7'
GO


/****** Object:  ForeignKey [FK_MC_QueryColumns_queryId_MC_Queries_id]    Script Date: 04/14/2009 16:26:23 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_MC_QueryColumns_queryId_MC_Queries_id]') AND parent_object_id = OBJECT_ID(N'[MC_QueryColumns]'))
ALTER TABLE [MC_QueryColumns] DROP CONSTRAINT [FK_MC_QueryColumns_queryId_MC_Queries_id]
GO
/****** Object:  ForeignKey [FK_MC_QueryCriteria_queryId_MC_Queries_id]    Script Date: 04/14/2009 16:26:26 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_MC_QueryCriteria_queryId_MC_Queries_id]') AND parent_object_id = OBJECT_ID(N'[MC_QueryCriteria]'))
ALTER TABLE [MC_QueryCriteria] DROP CONSTRAINT [FK_MC_QueryCriteria_queryId_MC_Queries_id]
GO
/****** Object:  Table [dbo].[MC_QueryColumns]    Script Date: 04/14/2009 16:26:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_QueryColumns]') AND type in (N'U'))
DROP TABLE [MC_QueryColumns]
GO
/****** Object:  Table [dbo].[MC_QueryCriteria]    Script Date: 04/14/2009 16:26:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_QueryCriteria]') AND type in (N'U'))
DROP TABLE [MC_QueryCriteria]
GO
/****** Object:  Table [dbo].[MC_Queries]    Script Date: 04/14/2009 16:26:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_Queries]') AND type in (N'U'))
DROP TABLE [MC_Queries]
GO
/****** Object:  ForeignKey [FK_MC_QueryColumns_queryId_MC_Queries_id]    Script Date: 04/14/2009 16:24:02 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_MC_QueryColumns_queryId_MC_Queries_id]') AND parent_object_id = OBJECT_ID(N'[MC_QueryParameters]'))
ALTER TABLE [MC_QueryParameters] DROP CONSTRAINT [FK_MC_QueryColumns_queryId_MC_Queries_id]
GO
/****** Object:  Table [dbo].[MC_Queries]    Script Date: 04/14/2009 16:23:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_Queries]') AND type in (N'U'))
DROP TABLE [MC_Queries]
GO
/****** Object:  Table [dbo].[MC_QueryParameters]    Script Date: 04/14/2009 16:24:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_QueryParameters]') AND type in (N'U'))
DROP TABLE [MC_QueryParameters]
GO
/****** Object:  Table [dbo].[MC_Queries]    Script Date: 04/14/2009 16:23:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_Queries]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_Queries](
	[QueryID] [int] IDENTITY(1,1) NOT NULL,
	[QueryName] [nvarchar](50) NOT NULL,
	[UserID] [int] NOT NULL,
	[lastModified] [datetime] NOT NULL CONSTRAINT [DF_MC_Queries_lastModified]  DEFAULT (getdate()),
 CONSTRAINT [PK_Queries] PRIMARY KEY CLUSTERED 
(
	[QueryID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[MC_QueryParameters]    Script Date: 04/14/2009 16:24:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_QueryParameters]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_QueryParameters](
	[QueryParameterID] [int] IDENTITY(1,1) NOT NULL,
	[ParameterName] [int] NOT NULL,
	[ParameterValue] [nvarchar](100) NOT NULL,
	[QueryID] [int] NOT NULL,
	[lastModified] [datetime] NOT NULL CONSTRAINT [DF_MC_QueryColumns_lastModified]  DEFAULT (getdate()),
 CONSTRAINT [PK_QueryColumns] PRIMARY KEY CLUSTERED 
(
	[QueryParameterID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  ForeignKey [FK_MC_QueryColumns_queryId_MC_Queries_id]    Script Date: 04/14/2009 16:24:02 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_MC_QueryColumns_queryId_MC_Queries_id]') AND parent_object_id = OBJECT_ID(N'[MC_QueryParameters]'))
ALTER TABLE [MC_QueryParameters]  WITH NOCHECK ADD  CONSTRAINT [FK_MC_QueryColumns_queryId_MC_Queries_id] FOREIGN KEY([QueryID])
REFERENCES [MC_Queries] ([QueryID])
GO
ALTER TABLE [MC_QueryParameters] CHECK CONSTRAINT [FK_MC_QueryColumns_queryId_MC_Queries_id]
GO

ALTER TABLE CWX_DynamicEditableFields
ADD SequenceNumber INT NULL
GO

/****** Object:  StoredProcedure [dbo].[CWX_GetDynamicEditableFields]    Script Date: 04/17/2009 14:05:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_GetDynamicEditableFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_GetDynamicEditableFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetDynamicEditableFields]    Script Date: 04/17/2009 14:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_GetDynamicEditableFields]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Khoa Dang
CREATE PROCEDURE [CWX_GetDynamicEditableFields]
	@TableID smallint,
	@RowID int
AS
BEGIN
	DECLARE @TableName varchar(20)
	DECLARE @TableName2 varchar(20)
	DECLARE @TableID2 int
	DECLARE @PrimaryKey varchar(20)
	IF @TableID = 1
	BEGIN
		SET @TableName = ''PersonInformation''
		SET @PrimaryKey = ''PersonID''
	END
	ELSE 
		IF @TableID = 2
		BEGIN
			SET @TableName = ''AccountOther''
			SET @TableName2 = ''Account''
			SET @PrimaryKey = ''AccountID''
			--SET 3 for Account Table
			SET @TableID2 = 3
		END

	/* DataTable 1: get FieldName and Description of DynamicEditableFields table depends on Type field */
	SELECT f.FieldName, f.Description, t.Name as DataType, c.max_length as MaxLength, c.precision, c.is_nullable AS IsNullable INTO #DynamicFields 
		FROM ((sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id)
			INNER JOIN sys.types t ON t.system_type_id = c.system_type_id)
			INNER JOIN CWX_DynamicEditableFields f ON c.Name = f.FieldName
		WHERE o.Name=@TableName AND f.TableID=@TableID
		Order BY f.SequenceNumber
	
	SELECT * FROM #DynamicFields

	/* DataTable 2: return the structure of table that needs to update */
	DECLARE @FieldName varchar(100)
	DECLARE @FieldNames varchar(1000)
	DECLARE DynamicFieldsCursor CURSOR FOR SELECT FieldName FROM #DynamicFields
	OPEN DynamicFieldsCursor
	FETCH NEXT FROM DynamicFieldsCursor INTO @FieldName

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF LEN(@FieldNames) > 0
			SET @FieldNames = @FieldNames + '','' + @FieldName
		ELSE
			SET @FieldNames = @FieldName

		FETCH NEXT FROM DynamicFieldsCursor INTO @FieldName
	END

	CLOSE DynamicFieldsCursor
	DEALLOCATE DynamicFieldsCursor

	DECLARE @sql varchar(2000)
	SET @sql = ''SELECT '' + @FieldNames + '' FROM '' + @TableName + '' WHERE '' + @PrimaryKey + ''='' + Str(@RowID)
	EXEC (@sql)

	/* DataTable 3: primary key */
	SELECT @PrimaryKey as PrimaryKey


	IF @TableID = 2
		BEGIN
			/* DataTable 4: get FieldName and Description of DynamicEditableFields table depends on Type field */
		SELECT f.FieldName, f.Description, t.Name as DataType, c.max_length as MaxLength, c.precision, c.is_nullable AS IsNullable INTO #DynamicFields2 
		FROM ((sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id)
			INNER JOIN sys.types t ON t.system_type_id = c.system_type_id)
			INNER JOIN CWX_DynamicEditableFields f ON c.Name = f.FieldName
		WHERE o.Name=@TableName2 AND f.TableID=@TableID2
		Order BY f.SequenceNumber

		SELECT * FROM #DynamicFields2

		SET @FieldNames = ''''
		DECLARE DynamicFieldsCursor CURSOR FOR SELECT FieldName FROM #DynamicFields2
		OPEN DynamicFieldsCursor
		FETCH NEXT FROM DynamicFieldsCursor INTO @FieldName

		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF LEN(@FieldNames) > 0
				SET @FieldNames = @FieldNames + '','' + @FieldName
			ELSE
				SET @FieldNames = @FieldName

			FETCH NEXT FROM DynamicFieldsCursor INTO @FieldName
		END

		CLOSE DynamicFieldsCursor
		DEALLOCATE DynamicFieldsCursor
		If LEN(@FieldNames) > 0
			BEGIN
				SET @sql = ''SELECT '' + @FieldNames + '' FROM '' + @TableName2 + '' WHERE '' + @PrimaryKey + ''='' + Str(@RowID)
				EXEC (@sql)
			END
		END

END

' 
END
GO

/****** Object:  View [dbo].[MC_AccountsView]    Script Date: 04/20/2009 01:11:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER VIEW [dbo].[MC_AccountsView]
AS
SELECT     TOP (100000) dbo.Account.AccountID, dbo.Account.ClientID AS ProductID, dbo.Account.MCode AS BucketID, 'Bucket ' + CAST(dbo.Account.MCode AS varchar(10)) 
                      AS BucketName, dbo.Account.BillAmount, dbo.Account.BillBalance, dbo.Account.AgencyStatusID, dbo.Account.CCode AS CycleID, 
                      'Cycle ' + CAST(dbo.Account.CCode AS varchar(10)) AS CycleName, dbo.Account.DebtorID, dbo.Account.QueueDate, dbo.Account.AccountAge, 
                      dbo.Account.InvoiceNumber, dbo.Account.DateOfService, dbo.Account.RoutinePayment, dbo.Account.WriteOffDate, dbo.Account.PAID, 
                      dbo.Account.MINIMUM_DUE AS MinimumDue, dbo.Account.TENOR, dbo.Account.EmployeeID, dbo.Account.LastAllocationDate, 
                      dbo.Account.AllocRuleID AS AllocationRuleID, dbo.Account.MaintainOfficer, dbo.Account.SubmissionDate, dbo.Account.OAManaged AS AgencyManaged, 
                      dbo.AccountStatus.ShortDesc AS AccountStatus, dbo.AccountStatus.LongDesc AS AccountStatusLong, dbo.ClientInformation.ClientName AS ProductName, 
                      dbo.ClientInformation.Referral, dbo.PersonInformation.SocialSecurityNumber, dbo.PersonInformation.Title, dbo.PersonInformation.Email, 
                      dbo.PersonInformation.HomePhone, dbo.PersonInformation.EmploymentPhone, dbo.PersonInformation.MobilPhone AS MobilePhone, dbo.PersonInformation.PersonID, 
                      dbo.PersonInformation.Employment, dbo.PersonInformation.DateOfBirth AS DebtorBirthDate, dbo.PersonInformation.PString3 AS DebtorMaritalStatus, 
                      dbo.PersonInformation.PString2 AS DebtorGender, dbo.Employee.EmployeeName, dbo.EmployeeDepartment.DeptID AS DepartmentId, 
                      RTRIM(dbo.PersonInformation.FirstName) + ' ' + RTRIM(dbo.PersonInformation.MiddleName) + ' ' + RTRIM(dbo.PersonInformation.LastName) AS FullName,
                          (SELECT     COUNT(Status) AS Expr1
                            FROM          dbo.AccountPromise
                            WHERE      (Status = 3) AND (AccountID = dbo.Account.AccountID)
                            GROUP BY AccountID, Status) AS BrokenPromises
FROM         dbo.Account LEFT OUTER JOIN
                      dbo.ClientInformation ON dbo.ClientInformation.ClientID = dbo.Account.ClientID LEFT OUTER JOIN
                      dbo.AccountStatus ON dbo.Account.AgencyStatusID = dbo.AccountStatus.AgencyStatus LEFT OUTER JOIN
                      dbo.DebtorInformation ON dbo.Account.DebtorID = dbo.DebtorInformation.DebtorID LEFT OUTER JOIN
                      dbo.PersonInformation ON dbo.DebtorInformation.PersonID = dbo.PersonInformation.PersonID LEFT OUTER JOIN
                      dbo.Employee ON dbo.Account.EmployeeID = dbo.Employee.EmployeeID LEFT OUTER JOIN
                      dbo.EmployeeDepartment ON dbo.Employee.Department = dbo.EmployeeDepartment.DeptID
GO

PRINT 'Completed execution of Update Scripts 3.6.7'
GO