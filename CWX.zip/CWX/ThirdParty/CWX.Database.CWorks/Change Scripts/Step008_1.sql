 -- Scripts are applied on version 1.3 build 1
 
 /****** Object:  UserDefinedFunction [dbo].[CWX_FnSplitString]    Script Date: 03/25/2008 09:45:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_FnSplitString]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CWX_FnSplitString]
GO
/****** Object:  UserDefinedFunction [dbo].[CWX_FnSplitString]    Script Date: 03/25/2008 09:45:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_FnSplitString]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Binh Truong
-- Create date: March 25th, 2008
-- Description:	
-- =============================================
CREATE FUNCTION dbo.CWX_FnSplitString
(
	@Text TEXT,
	@Delimiter char(1) = '',''
)
RETURNS @table_variable TABLE 
		(
			ID BIGINT IDENTITY(1,1), 
			SplitedText VARCHAR(8000)
		)
AS
	BEGIN
		DECLARE @SplitedText VARCHAR(8000)
		DECLARE @Size BIGINT
		DECLARE @Start BIGINT
		SET @Size = 1
		SET @Start = 1

		WHILE (@Start < DATALENGTH(@Text) + 1) 
		BEGIN
			SET @Size = CHARINDEX(@Delimiter, SUBSTRING(@Text, @Start, DATALENGTH(@Text)), 1)
			IF @Size = 0 
				SET @Size = DATALENGTH(@Text) - @Start + 1
				
			SET @SplitedText = SUBSTRING(SUBSTRING(@Text, @Start, DATALENGTH(@Text)), 1, @Size)
			SET @SplitedText = REPLACE(@SplitedText,@Delimiter,'''')
			INSERT INTO @table_variable(SplitedText) VALUES(@SplitedText)
			SET @Start = @Start + @Size
		END
	RETURN 
	END
' 
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByRuleID]    Script Date: 03/25/2008 09:50:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByRuleID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByRuleID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByRuleID]    Script Date: 03/25/2008 09:50:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByRuleID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Binh Truong
-- Create date: March 24th, 2008
-- Description:	
-- =============================================
create PROCEDURE [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByRuleID] 	
	@RuleID INT
AS
BEGIN
	SET NOCOUNT ON
	
	DECLARE @AssignedEmployees VARCHAR(8000)
	
	SELECT  @AssignedEmployees=Employees
	FROM    RulesAllocUsers
	WHERE	RuleID = @RuleID
		
	SELECT EmployeeID, EmployeeName 
	FROM dbo.CWX_FnSplitString(@AssignedEmployees, ''|''), Employee
	WHERE EmployeeID = SplitedText 
	
	SET NOCOUNT OFF
END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 03/26/2008 09:48:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetListByRule]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 03/26/2008 09:48:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 24, 2008
-- Description:	Retrieve records that match the rulecriterias of a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetListByRule] 
	-- Add the parameters for the stored procedure here
	@RuleID int,
	@PageSize int = 10,
	@PageIndex int = 0,
	@ProcessedAccountIDs varchar(4000) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat
		FROM RuleCriteria
		WHERE RuleID = @RuleID

	DECLARE @SQLFormat varchar(100)
	DECLARE @WhereClause varchar(2000)

	OPEN RuleCriteriaCrsr

	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @WhereClause = ' AND ' + @SQLFormat

		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat
	END

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr

	--Remove the Account that was processed
	IF @ProcessedAccountIDs IS NOT NULL AND @ProcessedAccountIDs <> ''
	BEGIN
		SELECT CAST(SplitedText AS int) AS AccountID
		INTO #ProcessedAccountIDs
		FROM CWX_FnSplitString(@ProcessedAccountIDs, '|')

		SET @WhereClause = ' AND Account.AccountId NOT IN (SELECT AccountID FROM #ProcessedAccountIDs)'
	END

	--This is used for AllocationRule, if RuleType=1, append condition <Account.MAINTAINOFFICER = 0>
	DECLARE @RuleType tinyint
	SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID
	IF @RuleType = 1
		SET @WhereClause = ' AND Account.MAINTAINOFFICER = 0' + @WhereClause

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY PRIMARY KEY,
		AccountId int,
		DebtorId int,
		FirstName varchar(50),
		MiddleName varchar(50),
		LastName varchar(50),
		BillBalance money,
		BillAmount money,
		InvoiceNumber varchar(50)
	)

	DECLARE @Sql varchar(4000)

	SET @Sql = 'INSERT INTO #Temp'
				+ ' SELECT'
				+ ' Account.AccountId,Account.DebtorId,PersonInformation.FirstName,PersonInformation.MiddleName,PersonInformation.LastName,Account.BillBalance,Account.BillAmount,Account.InvoiceNumber'
				+ ' FROM Account'
				+ ' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID'
				+ ' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID'
				+ ' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID'
				+ ' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID'
				+ ' WHERE (PersonAddress.MailingAddress = 1)'
				+ @WhereClause
				+ ' ORDER BY Account.AccountId'

	EXEC (@Sql)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	DROP TABLE #Temp

	RETURN @RowCount
END
GO

ALTER PROCEDURE [dbo].[CWX_TicketDefinition_DeleteAll]
	@Status char(1) = 'S'		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = 'S'
	BEGIN
		UPDATE TicketDefinition
		SET [Status] = 'R'
		WHERE [Status] = 'A' and TicketType <> 'S' 
		  and TktDefID not in (Select DISTINCT TicketTypeID From Ticket)
	END
	ELSE IF UPPER(@Status) = 'P'
	BEGIN    
		DELETE TicketDefinition
		WHERE TicketType <> 'S' and TktDefID not in (Select DISTINCT TicketTypeID From Ticket)
	END
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_PermanentReassign]    Script Date: 03/31/2008 14:58:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_PermanentReassign]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_PermanentReassign]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_PermanentReassign]    Script Date: 03/31/2008 14:58:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 27, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_PermanentReassign] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@MaintainOfficer bit = 0,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				AssignmentType = 'P',
				EmployeeID = @EmployeeID,
				MaintainOfficer = @MaintainOfficer
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @CurrentUserID
			SET @NoteText = 'AcctMgmt: Permanent Reassignment to ' + @EmployeeName + ' with MaintainOfficer '
			IF @MaintainOfficer = 0
				SET @NoteText = @NoteText + 'unchecked'
			ELSE
				SET @NoteText = @NoteText + 'checked'

			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByAssignedEmployeesString]    Script Date: 03/26/2008 16:19:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByAssignedEmployeesString]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByAssignedEmployeesString]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByAssignedEmployeesString]    Script Date: 03/26/2008 16:19:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByAssignedEmployeesString]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Binh Truong
-- Create date: March 24th, 2008
-- Description:	
-- =============================================
create PROCEDURE [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByAssignedEmployeesString] 	
	@AssignedEmployees TEXT
AS
BEGIN
	SET NOCOUNT ON
		
	SELECT Employee.*
	FROM dbo.CWX_FnSplitString(@AssignedEmployees, ''|''), Employee
	WHERE EmployeeID = SplitedText
	
	SET NOCOUNT OFF
END' 
END
GO

-- =======================================================================
-- Author:		  LongNguyen
-- Create date:   Mar 19, 2008
-- Modified date: Mar 27, 2008 (Tuan Luong)
-- Description:	  if someone want to change this store procedure
--				  plz double check CWX_RuleCriteria_GetCriteriaByRuleType
-- =======================================================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetList]
GO
CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetList]
	@RuleID int
AS
BEGIN	
	SET NOCOUNT ON;
	CREATE TABLE #Temp
	(
		COLUMN_NAME varchar(125),
		DESCRIPTION varchar(125),
		DATA_TYPE varchar(125),
		[DATABASE] varchar(125)		
	)

	DECLARE @RuleType tinyint
    SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID	

	IF @RuleType <> 3
	BEGIN
		CREATE TABLE #TempTableInfoList
		(
			TableID int,
			TableName varchar(125)
		)
		DECLARE @InterfaceDBName varchar(125)
		SET @InterfaceDBName = ''	

		IF (@RuleType = 1 or @RuleType = 4) -- Allocation Rule or Temporary Rule
		BEGIN
			DECLARE @AllocationTables VARCHAR(2000)		
			SET @AllocationTables = 'Account,AccountOther,DebtorInformation,PersonInformation,PersonAddress'
			
			INSERT #TempTableInfoList
			SELECT object_id, SplitedText		
			FROM CWX_FnSplitString (@AllocationTables,',')
			INNER JOIN sys.objects
			ON name = SplitedText
		END
		ELSE IF (@RuleType = 2) -- Extraction Rule
		BEGIN	
			DECLARE @AccountTableName varchar(125)		
			SELECT TOP 1 @InterfaceDBName = InterfaceDBName, @AccountTableName = AccountTable
			FROM Interface WHERE AccountTable is not NULL or AccountTable <> ''
			ORDER BY InterfaceID

			SET @InterfaceDBName = @InterfaceDBName + '.'
			SET @AccountTableName = @AccountTableName + ','

			DECLARE @SelectTableInfoStatement varchar(2000)
			SET @SelectTableInfoStatement = 'INSERT #TempTableInfoList SELECT object_id, SplitedText FROM CWX_FnSplitString (''' + @AccountTableName + ''','','')  
											INNER JOIN ' + @InterfaceDBName + 'sys.objects o 
											ON o.name = SplitedText'
			EXEC(@SelectTableInfoStatement)
		END
		
		DECLARE @SelectDescriptionStatement varchar(2000)
		SET @SelectDescriptionStatement = 'INSERT #Temp '
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + 
			'SELECT [COLUMN_NAME] = o.name + ''.'' + ltrim(rtrim(c.name)),		  
			[DESCRIPTION] = dbo.CWX_RuleCriteria_FnProcessDescription (ltrim(rtrim(convert(varchar(125), ex.value)))),  
			[DATA_TYPE] = upper(ty.name), 
			[DATABASE] = '''
		IF @InterfaceDBName <> ''	
			SET @SelectDescriptionStatement = @SelectDescriptionStatement + SUBSTRING(@InterfaceDBName, 1, DATALENGTH(@InterfaceDBName) - 1) + ''''
		ELSE
			SET @SelectDescriptionStatement = @SelectDescriptionStatement + ''''	
		  
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + ' FROM ' +
			@InterfaceDBName + 'sys.objects o 
		INNER JOIN ' +  
			@InterfaceDBName + 'sys.columns c 
		ON 
			o.object_id = c.object_id  
		LEFT OUTER JOIN ' +
			@InterfaceDBName + 'sys.extended_properties ex  
		ON  
			ex.major_id = c.object_id  
			AND ex.minor_id = c.column_id  
			AND ex.name = ''MS_Description''  
		LEFT OUTER JOIN ' + 
			@InterfaceDBName + 'sys.types ty  
		ON  
			ty.system_type_id = c.system_type_id		 		 
		WHERE  
			OBJECTPROPERTY(c.object_id, ''IsMsShipped'') = 0  
			AND c.object_id in (SELECT TableID FROM #TempTableInfoList)
			AND ex.value is not NULL AND ex.value <> ''''
		ORDER  
			BY [DESCRIPTION]'
		
		EXEC (@SelectDescriptionStatement)		
		
		SELECT r.*, t.DESCRIPTION
		FROM RuleCriteria r
		INNER JOIN #Temp t ON r.Criteria = t.COLUMN_NAME
		WHERE RuleID = @RuleID		

		DROP TABLE #TempTableInfoList
		DROP TABLE #Temp
	END
	ELSE --Result Processing Rule
	BEGIN
		SELECT *, Criteria AS DESCRIPTION
		FROM RuleCriteria
		WHERE RuleID = @RuleID
	END
END
GO

-- ================================================================
-- Author:		  Tuan Luong
-- Create date:   Mar 18, 2008
-- Modified date: Mar 27, 2008 (Tuan Luong)
-- Description:	  if someone want to change this store procedure
--				  plz double check CWX_RuleCriteria_GetList
-- ================================================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]
GO
CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]
	@RuleType int		
AS
BEGIN
	SET NOCOUNT ON;

	CREATE TABLE #TempTableInfoList
	(
		TableID int,
		TableName varchar(125)
	)
	DECLARE @InterfaceDBName varchar(125)
	SET @InterfaceDBName = ''	

	IF (@RuleType = 1 or @RuleType = 4) -- Allocation Rule or Temporary Rule
	BEGIN
		DECLARE @AllocationTables VARCHAR(2000)		
		SET @AllocationTables = 'Account,AccountOther,DebtorInformation,PersonInformation,PersonAddress'
		
		INSERT #TempTableInfoList
		SELECT object_id, SplitedText		
		FROM CWX_FnSplitString (@AllocationTables,',')
		INNER JOIN sys.objects
		ON name = SplitedText
	END
	ELSE IF (@RuleType = 2) -- Extraction Rule
	BEGIN	
		DECLARE @AccountTableName varchar(125)		
		SELECT TOP 1 @InterfaceDBName = InterfaceDBName, @AccountTableName = AccountTable
		FROM Interface WHERE AccountTable is not NULL or AccountTable <> ''
		ORDER BY InterfaceID

		SET @InterfaceDBName = @InterfaceDBName + '.'
		SET @AccountTableName = @AccountTableName + ','

		DECLARE @SelectTableInfoStatement varchar(2000)
		SET @SelectTableInfoStatement = 'INSERT #TempTableInfoList SELECT object_id, SplitedText FROM CWX_FnSplitString (''' + @AccountTableName + ''','','')  
										INNER JOIN ' + @InterfaceDBName + 'sys.objects o 
										ON o.name = SplitedText'
		EXEC(@SelectTableInfoStatement)
	END

	DECLARE @SelectDescriptionStatement varchar(2000)
	SET @SelectDescriptionStatement = 'SELECT [COLUMN_NAME] = o.name + ''.'' + ltrim(rtrim(c.name)),		  
		[DESCRIPTION] = dbo.CWX_RuleCriteria_FnProcessDescription (ltrim(rtrim(convert(varchar(125), ex.value)))),  
		[DATA_TYPE] = upper(ty.name), 
		[DATABASE] = '''
	IF @InterfaceDBName <> ''	
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + SUBSTRING(@InterfaceDBName, 1, DATALENGTH(@InterfaceDBName) - 1) + ''''
	ELSE
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + ''''	
	  
	SET @SelectDescriptionStatement = @SelectDescriptionStatement + ' FROM ' +
		@InterfaceDBName + 'sys.objects o 
	INNER JOIN ' +  
		@InterfaceDBName + 'sys.columns c 
	ON 
		o.object_id = c.object_id  
	LEFT OUTER JOIN ' +
		@InterfaceDBName + 'sys.extended_properties ex  
	ON  
		ex.major_id = c.object_id  
		AND ex.minor_id = c.column_id  
		AND ex.name = ''MS_Description''  
	LEFT OUTER JOIN ' + 
		@InterfaceDBName + 'sys.types ty  
	ON  
		ty.system_type_id = c.system_type_id  
	WHERE  
		OBJECTPROPERTY(c.object_id, ''IsMsShipped'') = 0  
		AND c.object_id in (SELECT TableID FROM #TempTableInfoList)
		AND ex.value is not NULL AND ex.value <> ''''
	ORDER  
		BY [DESCRIPTION]'
	
	EXEC (@SelectDescriptionStatement)
	DROP TABLE #TempTableInfoList
END
GO

-- ===========================================================================================
-- Author:		  Tuan Luong
-- Create date:   Mar 13, 2008
-- Modified date: Mar 27, 2008
-- Description:	  Selects all records on the given @InterfaceDBNam, @ColumnName and @TableName 
-- Parameters:
--  @InterfaceDBName 
--	@TableName
--	@ColumnName		     
-- Database:    CWorks
-- ===========================================================================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]
GO
CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]
	@InterfaceDBName varchar(125),
	@TableName varchar(125),
	@ColumnName varchar(125)		
AS
BEGIN
	DECLARE @Sql varchar(2000)
	SET @Sql = 'SELECT DISTINCT ' + @ColumnName + ' FROM ' + @InterfaceDBName + '..' + @TableName		
	SET @Sql = @Sql + ' WHERE ' + @ColumnName + ' is not NULL'
	SET @Sql = @Sql + ' AND ' + @ColumnName + ' <> '''''
	SET @Sql = @Sql + ' ORDER BY ' + @ColumnName	

	EXEC(@Sql)
END
GO

--The below two functions are not use anymore
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Interface_FnGetCriteriaTableNames]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CWX_Interface_FnGetCriteriaTableNames]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_FnGetCriteriaByRuleType]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CWX_RuleCriteria_FnGetCriteriaByRuleType]