-- Script is applied on version 2.7.1, 2.7.2, 2.7.3, 2.7.4, 2.7.5, 2.7.6

-- Scripts 2.7.1:

--Change AccountActions to has identity
--DELETE FROM AccountActions
--GO
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.AccountActions
	DROP CONSTRAINT DF_AccountActions_UnitCost
GO
CREATE TABLE dbo.Tmp_AccountActions
	(
	RecordID int NOT NULL IDENTITY (1, 1),
	Status int NULL,
	ResponsibleParty int NULL,
	Deadline smalldatetime NULL,
	ActionID int NULL,
	DateCompleted smalldatetime NULL,
	CompletedBy int NULL,
	AccountID int NULL,
	AdditionalData char(128) NULL,
	UnitCost money NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_AccountActions ADD CONSTRAINT
	DF_AccountActions_UnitCost DEFAULT (0) FOR UnitCost
GO
SET IDENTITY_INSERT dbo.Tmp_AccountActions ON
GO
IF EXISTS(SELECT * FROM dbo.AccountActions)
	 EXEC('INSERT INTO dbo.Tmp_AccountActions (RecordID, Status, ResponsibleParty, Deadline, ActionID, DateCompleted, CompletedBy, AccountID, AdditionalData, UnitCost)
		SELECT RecordID, Status, ResponsibleParty, Deadline, ActionID, DateCompleted, CompletedBy, AccountID, AdditionalData, UnitCost FROM dbo.AccountActions WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_AccountActions OFF
GO
DROP TABLE dbo.AccountActions
GO
EXECUTE sp_rename N'dbo.Tmp_AccountActions', N'AccountActions', 'OBJECT' 
GO
ALTER TABLE dbo.AccountActions ADD CONSTRAINT
	PK_AccountActions PRIMARY KEY NONCLUSTERED 
	(
	RecordID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE CLUSTERED INDEX IX_ACGR ON dbo.AccountActions
	(
	DateCompleted,
	ActionID,
	ResponsibleParty
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_AccountActions_ActionID ON dbo.AccountActions
	(
	ActionID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_AccountActions_AccountID ON dbo.AccountActions
	(
	AccountID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_ACCTACT ON dbo.AccountActions
	(
	AccountID,
	ActionID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO

/****** Object:  StoredProcedure [dbo].[CWX_PersonAddress_Get]    Script Date: 10/01/2008 11:00:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonAddress_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonAddress_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonAddress_Get]    Script Date: 10/01/2008 11:00:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================================
-- Author:		Triet Pham
-- Create date: Mar 26th, 2008
-- Description:	Retrieve all personal addresses
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_PersonAddress_Get]	
	@DebtorID int,
	@PersonID int = 0
AS
BEGIN

	SET NOCOUNT ON	
	
	DECLARE @HomeAddress1 varchar(255)
	DECLARE @HomeAddress2 varchar(255)
	DECLARE @HomeAddress3 varchar(255)
	DECLARE @HomeCity varchar(255)
	DECLARE @HomeState varchar(50)
	DECLARE @HomeZip varchar(25)
	DECLARE @HomeCountry varchar(50)
	DECLARE @HomeTerritory varchar(50)
	DECLARE @HomeRegion varchar(50)
	DECLARE @HomeMailingAddress bit

	DECLARE @PostalAddress1 varchar(255)
	DECLARE @PostalAddress2 varchar(255)
	DECLARE @PostalAddress3 varchar(255)
	DECLARE @PostalCity varchar(255)
	DECLARE @PostalState varchar(50)
	DECLARE @PostalZip varchar(25)
	DECLARE @PostalCountry varchar(50)
	DECLARE @PostalTerritory varchar(50)
	DECLARE @PostalRegion varchar(50)
	DECLARE @PostalMailingAddress bit

	DECLARE @EmploymentAddress1 varchar(255)
	DECLARE @EmploymentAddress2 varchar(255)
	DECLARE @EmploymentAddress3 varchar(255)
	DECLARE @EmploymentCity varchar(255)
	DECLARE @EmploymentState varchar(50)
	DECLARE @EmploymentZip varchar(25)
	DECLARE @EmploymentCountry varchar(50)
	DECLARE @EmploymentTerritory varchar(50)
	DECLARE @EmploymentRegion varchar(50)
	DECLARE @EmploymentMailingAddress bit

	DECLARE @OtherAddress1 varchar(255)
	DECLARE @OtherAddress2 varchar(255)
	DECLARE @OtherAddress3 varchar(255)
	DECLARE @OtherCity varchar(255)
	DECLARE @OtherState varchar(50)
	DECLARE @OtherZip varchar(25)
	DECLARE @OtherCountry varchar(50)
	DECLARE @OtherTerritory varchar(50)
	DECLARE @OtherRegion varchar(50)
	DECLARE @OtherMailingAddress bit

	SELECT
		@HomeAddress1 = p.Address1,
		@HomeAddress2 = p.Address2,
		@HomeAddress3 = p.Address3,
		@HomeCity = p.City,
		@HomeState = p.State,
		@HomeZip = p.Zip,
		@HomeCountry = p.Country,
		@HomeTerritory = p.Territory,
		@HomeRegion = p.Region,
		@HomeMailingAddress = p.MailingAddress
	FROM PersonAddress p 
	LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
	WHERE 
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (p.PersonID = @PersonID))
		AND p.AddressType = 1

	SELECT
		@EmploymentAddress1 = p.Address1,
		@EmploymentAddress2 = p.Address2,
		@EmploymentAddress3 = p.Address3,
		@EmploymentCity = p.City,
		@EmploymentState = p.State,
		@EmploymentZip = p.Zip,
		@EmploymentCountry = p.Country,
		@EmploymentTerritory = p.Territory,
		@EmploymentRegion = p.Region,
		@EmploymentMailingAddress = p.MailingAddress
	FROM PersonAddress p 
	LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
	WHERE 
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (p.PersonID = @PersonID))
		AND p.AddressType = 2

	SELECT
		@PostalAddress1 = p.Address1,
		@PostalAddress2 = p.Address2,
		@PostalAddress3 = p.Address3,
		@PostalCity = p.City,
		@PostalState = p.State,
		@PostalZip = p.Zip,
		@PostalCountry = p.Country,
		@PostalTerritory = p.Territory,
		@PostalRegion = p.Region,
		@PostalMailingAddress = p.MailingAddress
	FROM PersonAddress p 
	LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
	WHERE 
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (p.PersonID = @PersonID))
		AND p.AddressType = 3

	SELECT
		@OtherAddress1 = p.Address1,
		@OtherAddress2 = p.Address2,
		@OtherAddress3 = p.Address3,
		@OtherCity = p.City,
		@OtherState = p.State,
		@OtherZip = p.Zip,
		@OtherCountry = p.Country,
		@OtherTerritory = p.Territory,
		@OtherRegion = p.Region,
		@OtherMailingAddress = p.MailingAddress
	FROM PersonAddress p 
	LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
	WHERE 
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (p.PersonID = @PersonID))
		AND p.AddressType = 4

	SELECT 
		@HomeAddress1 AS HomeAddress1,
		@HomeAddress2 AS HomeAddress2,
		@HomeAddress3 AS HomeAddress3,
		@HomeCity AS HomeCity,
		@HomeState AS HomeState,
		@HomeZip AS HomeZip,
		@HomeCountry AS HomeCountry,
		@HomeTerritory AS HomeTerritory,
		@HomeRegion AS HomeRegion,
		@HomeMailingAddress AS HomeMailingAddress,

		@PostalAddress1 AS PostalAddress1,
		@PostalAddress2 AS PostalAddress2,
		@PostalAddress3 AS PostalAddress3,
		@PostalCity AS PostalCity,
		@PostalState AS PostalState,
		@PostalZip AS PostalZip,
		@PostalCountry AS PostalCountry,
		@PostalTerritory AS PostalTerritory,
		@PostalRegion AS PostalRegion,
		@PostalMailingAddress AS PostalMailingAddress,

		@EmploymentAddress1 AS EmploymentAddress1,
		@EmploymentAddress2 AS EmploymentAddress2,
		@EmploymentAddress3 AS EmploymentAddress3,
		@EmploymentCity AS EmploymentCity,
		@EmploymentState AS EmploymentState,
		@EmploymentZip AS EmploymentZip,
		@EmploymentCountry AS EmploymentCountry,
		@EmploymentTerritory AS EmploymentTerritory,
		@EmploymentRegion AS EmploymentRegion,
		@EmploymentMailingAddress AS EmploymentMailingAddress,

		@OtherAddress1 AS OtherAddress1,
		@OtherAddress2 AS OtherAddress2,
		@OtherAddress3 AS OtherAddress3,
		@OtherCity AS OtherCity,
		@OtherState AS OtherState,
		@OtherZip AS OtherZip,
		@OtherCountry AS OtherCountry,
		@OtherTerritory AS OtherTerritory,
		@OtherRegion AS OtherRegion,
		@OtherMailingAddress AS OtherMailingAddress

	SET NOCOUNT OFF
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonPhone_Get]    Script Date: 10/01/2008 11:01:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonPhone_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonPhone_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonPhone_Get]    Script Date: 10/01/2008 11:01:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================================
-- Author:		Triet Pham
-- Create date: Mar 26th, 2008
-- Description:	Retrieve all personal phone details
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_PersonPhone_Get]	
	@DebtorID int = 0,
	@PersonID int = 0
AS
BEGIN
	SET NOCOUNT ON	

	DECLARE @TYPE8PHONENO varchar(50)
	DECLARE @TYPE8PHONEDESC varchar(255)
	DECLARE @TYPE9PHONENO varchar(50)
	DECLARE @TYPE9PHONEXT varchar(25)

	SELECT 
		@TYPE8PHONENO = PhoneNumber,
		@TYPE8PHONEDESC = Description
	FROM PersonPhone AS ph
	LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (ph.PersonID = @PersonID))
		AND ph.PhoneType = 8

	SELECT 
		@TYPE9PHONENO = PhoneNumber,
		@TYPE9PHONEXT = PhoneExtension
	FROM PersonPhone AS ph
	LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (ph.PersonID = @PersonID))
		AND ph.PhoneType = 9

	SELECT
		@TYPE8PHONENO AS TYPE8PHONENO,
		@TYPE8PHONEDESC AS TYPE8PHONEDESC,
		@TYPE9PHONENO AS TYPE9PHONENO,
		@TYPE9PHONEXT AS TYPE9PHONEXT 
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'AccountPromise' and c.name = 'Bucket')
BEGIN
	ALTER TABLE AccountPromise ADD Bucket smallint
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'AccountPromise' and c.name = 'DPD')
BEGIN
	ALTER TABLE AccountPromise ADD DPD smallint
END
GO

-- 2008/10/02	[Binh Truong]	
-- Change AccountMemo.AccountText varchar to nvarchar datatype
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
CREATE TABLE dbo.Tmp_AccountMemo
	(
	AccountID int NOT NULL,
	AccountText nvarchar(250) NULL
	)  ON [PRIMARY]
GO
IF EXISTS(SELECT * FROM dbo.AccountMemo)
	 EXEC('INSERT INTO dbo.Tmp_AccountMemo (AccountID, AccountText)
		SELECT AccountID, CONVERT(nvarchar(250), AccountText) FROM dbo.AccountMemo WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.AccountMemo
GO
EXECUTE sp_rename N'dbo.Tmp_AccountMemo', N'AccountMemo', 'OBJECT' 
GO
CREATE CLUSTERED INDEX Idx_accountId ON dbo.AccountMemo
	(
	AccountID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO

-- Change CollateralNotes.NoteText varchar to nvarchar datatype
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
CREATE TABLE dbo.Tmp_CollateralNotes
	(
	NoteID int NOT NULL IDENTITY (1, 1),
	CollateralID int NOT NULL,
	EmployeeID int NOT NULL,
	NoteDateTime datetime NULL,
	NoteType varchar(1) NULL,
	NoteText nvarchar(700) NULL
	)  ON [PRIMARY]
GO
SET IDENTITY_INSERT dbo.Tmp_CollateralNotes ON
GO
IF EXISTS(SELECT * FROM dbo.CollateralNotes)
	 EXEC('INSERT INTO dbo.Tmp_CollateralNotes (NoteID, CollateralID, EmployeeID, NoteDateTime, NoteType, NoteText)
		SELECT NoteID, CollateralID, EmployeeID, NoteDateTime, NoteType, CONVERT(nvarchar(700), NoteText) FROM dbo.CollateralNotes WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_CollateralNotes OFF
GO
DROP TABLE dbo.CollateralNotes
GO
EXECUTE sp_rename N'dbo.Tmp_CollateralNotes', N'CollateralNotes', 'OBJECT' 
GO
ALTER TABLE dbo.CollateralNotes ADD CONSTRAINT
	PK_CollateralNotes PRIMARY KEY CLUSTERED 
	(
	NoteID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX Idx_CollateralID_DateTime ON dbo.CollateralNotes
	(
	CollateralID,
	NoteDateTime
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO

-- Change DebtorInformation.HotNote varchar to nvarchar datatype
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
CREATE TABLE dbo.Tmp_DebtorInformation
	(
	DebtorID int NOT NULL,
	PersonID int NOT NULL,
	CompanyName varchar(50) NULL,
	DoingBusinessAs varchar(50) NULL,
	GroupName varchar(50) NULL,
	HotNote nvarchar(255) NULL,
	ZipDelPoint char(3) NULL,
	ZipCart char(4) NULL,
	ReturnedMail bit NOT NULL,
	HoldLetters bit NOT NULL,
	HoldHomeCalls bit NOT NULL,
	HoldWorkCalls bit NOT NULL,
	PullCreditReport bit NOT NULL,
	SendReminderLetters bit NOT NULL,
	DateOfLastCreditReportPull varchar(16) NULL,
	CreditReportFileName varchar(16) NULL,
	LastEditDate smalldatetime NULL,
	LastEditBy int NULL,
	LockedByID int NULL,
	LockedBy varchar(50) NULL
	)  ON [PRIMARY]
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_DebtorInformation.ReturnedMail'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_DebtorInformation.HoldLetters'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_DebtorInformation.HoldHomeCalls'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_DebtorInformation.HoldWorkCalls'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_DebtorInformation.PullCreditReport'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_DebtorInformation.SendReminderLetters'
GO
IF EXISTS(SELECT * FROM dbo.DebtorInformation)
	 EXEC('INSERT INTO dbo.Tmp_DebtorInformation (DebtorID, PersonID, CompanyName, DoingBusinessAs, GroupName, HotNote, ZipDelPoint, ZipCart, ReturnedMail, HoldLetters, HoldHomeCalls, HoldWorkCalls, PullCreditReport, SendReminderLetters, DateOfLastCreditReportPull, CreditReportFileName, LastEditDate, LastEditBy, LockedByID, LockedBy)
		SELECT DebtorID, PersonID, CompanyName, DoingBusinessAs, GroupName, CONVERT(nvarchar(255), HotNote), ZipDelPoint, ZipCart, ReturnedMail, HoldLetters, HoldHomeCalls, HoldWorkCalls, PullCreditReport, SendReminderLetters, DateOfLastCreditReportPull, CreditReportFileName, LastEditDate, LastEditBy, LockedByID, LockedBy FROM dbo.DebtorInformation WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.DebtorInformation
GO
EXECUTE sp_rename N'dbo.Tmp_DebtorInformation', N'DebtorInformation', 'OBJECT' 
GO
CREATE CLUSTERED INDEX DebtorInformation4 ON dbo.DebtorInformation
	(
	DebtorID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX DebtorInformation13 ON dbo.DebtorInformation
	(
	LockedByID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_DEBPERID ON dbo.DebtorInformation
	(
	PersonID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO

-- Change NotesHistory.NoteText varchar to nvarchar datatype
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
CREATE TABLE dbo.Tmp_NotesHistory
	(
	NoteID int NOT NULL,
	EmployeeID int NOT NULL,
	DebtorID int NOT NULL,
	BillID int NOT NULL,
	NoteDateTime datetime NULL,
	NoteType varchar(1) NULL,
	NoteText nvarchar(1000) NULL
	)  ON [PRIMARY]
GO
IF EXISTS(SELECT * FROM dbo.NotesHistory)
	 EXEC('INSERT INTO dbo.Tmp_NotesHistory (NoteID, EmployeeID, DebtorID, BillID, NoteDateTime, NoteType, NoteText)
		SELECT NoteID, EmployeeID, DebtorID, BillID, NoteDateTime, NoteType, CONVERT(nvarchar(1000), NoteText) FROM dbo.NotesHistory WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.NotesHistory
GO
EXECUTE sp_rename N'dbo.Tmp_NotesHistory', N'NotesHistory', 'OBJECT' 
GO
COMMIT
GO

-- Change TicketNotes.NoteText varchar to nvarchar datatype
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
CREATE TABLE dbo.Tmp_TicketNotes
	(
	NoteID int NOT NULL IDENTITY (1, 1),
	TicketID int NOT NULL,
	EmployeeID int NOT NULL,
	NoteDateTime datetime NULL,
	NoteType varchar(1) NULL,
	NoteText nvarchar(700) NULL
	)  ON [PRIMARY]
GO
SET IDENTITY_INSERT dbo.Tmp_TicketNotes ON
GO
IF EXISTS(SELECT * FROM dbo.TicketNotes)
	 EXEC('INSERT INTO dbo.Tmp_TicketNotes (NoteID, TicketID, EmployeeID, NoteDateTime, NoteType, NoteText)
		SELECT NoteID, TicketID, EmployeeID, NoteDateTime, NoteType, CONVERT(nvarchar(700), NoteText) FROM dbo.TicketNotes WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_TicketNotes OFF
GO
DROP TABLE dbo.TicketNotes
GO
EXECUTE sp_rename N'dbo.Tmp_TicketNotes', N'TicketNotes', 'OBJECT' 
GO
ALTER TABLE dbo.TicketNotes ADD CONSTRAINT
	PK_TicketNotes PRIMARY KEY CLUSTERED 
	(
	NoteID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX Idx_TicketID_DateTime ON dbo.TicketNotes
	(
	TicketID,
	NoteDateTime
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO

-- Change RuleOthers.Value text to ntext datatype
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
CREATE TABLE dbo.Tmp_RuleOthers
	(
	RuleId int NULL,
	OptionType int NULL,
	Value ntext NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
IF EXISTS(SELECT * FROM dbo.RuleOthers)
	 EXEC('INSERT INTO dbo.Tmp_RuleOthers (RuleId, OptionType, Value)
		SELECT RuleId, OptionType, CONVERT(ntext, Value) FROM dbo.RuleOthers WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.RuleOthers
GO
EXECUTE sp_rename N'dbo.Tmp_RuleOthers', N'RuleOthers', 'OBJECT' 
GO
CREATE CLUSTERED INDEX IDX_RULEOPTION ON dbo.RuleOthers
	(
	RuleId,
	OptionType
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_RULEID ON dbo.RuleOthers
	(
	RuleId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO

-- Change InformationTable.Value varchar to nvarchar datatype
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.InformationTable
	DROP CONSTRAINT InformationTable_RowStatus
GO
CREATE TABLE dbo.Tmp_InformationTable
	(
	InfoID int NOT NULL,
	InfoType tinyint NOT NULL,
	InfoSubType tinyint NOT NULL,
	InfoKey varchar(50) NULL,
	Description varchar(50) NULL,
	Value nvarchar(50) NULL,
	ValueFormat varchar(48) NULL,
	Status char(1) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_InformationTable ADD CONSTRAINT
	InformationTable_RowStatus DEFAULT ('A') FOR Status
GO
IF EXISTS(SELECT * FROM dbo.InformationTable)
	 EXEC('INSERT INTO dbo.Tmp_InformationTable (InfoID, InfoType, InfoSubType, InfoKey, Description, Value, ValueFormat, Status)
		SELECT InfoID, InfoType, InfoSubType, InfoKey, Description, CONVERT(nvarchar(50), Value), ValueFormat, Status FROM dbo.InformationTable WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.InformationTable
GO
EXECUTE sp_rename N'dbo.Tmp_InformationTable', N'InformationTable', 'OBJECT' 
GO
CREATE CLUSTERED INDEX IX_InfoID ON dbo.InformationTable
	(
	InfoID,
	InfoKey
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_InfoID1 ON dbo.InformationTable
	(
	InfoID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_Info ON dbo.InformationTable
	(
	InfoID,
	InfoType,
	InfoSubType,
	InfoKey
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO

-- Change Employee. Comment1, Comment2, Comment3 varchar to nvarchar datatype
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Employee
	DROP CONSTRAINT DF_Employee_SignOn
GO
ALTER TABLE dbo.Employee
	DROP CONSTRAINT DF_Employee_Blocked
GO
ALTER TABLE dbo.Employee
	DROP CONSTRAINT DF_Employee_Department
GO
ALTER TABLE dbo.Employee
	DROP CONSTRAINT DF_Employee_RoleID
GO
ALTER TABLE dbo.Employee
	DROP CONSTRAINT DF__Employee__Employ__3E923B2D
GO
ALTER TABLE dbo.Employee
	DROP CONSTRAINT DF__Employee__PoolRi__10416098
GO
ALTER TABLE dbo.Employee
	DROP CONSTRAINT DF__Employee__Employ__113584D1
GO
CREATE TABLE dbo.Tmp_Employee
	(
	EmployeeID int NOT NULL,
	EmployeeName varchar(50) NULL,
	DateOfBirth varchar(10) NULL,
	Phone varchar(16) NULL,
	Address varchar(30) NULL,
	Street varchar(30) NULL,
	City varchar(16) NULL,
	State varchar(16) NULL,
	Zip varchar(16) NULL,
	UserID varchar(10) NULL,
	Description varchar(100) NULL,
	PayDraw float(53) NULL,
	PayNormalPercent real NOT NULL,
	PayOCPercent real NOT NULL,
	NormalPercAfterDayx smallint NOT NULL,
	Supervisor bit NOT NULL,
	MaxNoPromise smallint NULL,
	MaxWithProm smallint NULL,
	Extension char(4) NULL,
	AutoAssign bit NOT NULL,
	MimDailyAmt money NOT NULL,
	AssColStart char(5) NULL,
	AssColEnd char(5) NULL,
	Goal money NOT NULL,
	SuperVisorId int NULL,
	Nationality varchar(50) NULL,
	Language_Id varchar(100) NULL,
	Prior_Exp int NULL,
	Date_Of_Joining datetime NULL,
	Daily_Cap int NULL,
	Comment1 nvarchar(225) NULL,
	Comment2 nvarchar(225) NULL,
	Comment3 nvarchar(225) NULL,
	SignOn bit NULL,
	Blocked bit NULL,
	Department int NULL,
	RoleID int NULL,
	EmployeeStatus char(1) NULL,
	PoolRight int NULL,
	EmployeeType char(1) NULL,
	CreatedDate datetime NULL
	)  ON [PRIMARY]
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Employee.PayNormalPercent'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Employee.PayOCPercent'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Employee.NormalPercAfterDayx'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Employee.Supervisor'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Employee.AutoAssign'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Employee.MimDailyAmt'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Employee.Goal'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Employee.SuperVisorId'
GO
ALTER TABLE dbo.Tmp_Employee ADD CONSTRAINT
	DF_Employee_SignOn DEFAULT (0) FOR SignOn
GO
ALTER TABLE dbo.Tmp_Employee ADD CONSTRAINT
	DF_Employee_Blocked DEFAULT (0) FOR Blocked
GO
ALTER TABLE dbo.Tmp_Employee ADD CONSTRAINT
	DF_Employee_Department DEFAULT (0) FOR Department
GO
ALTER TABLE dbo.Tmp_Employee ADD CONSTRAINT
	DF_Employee_RoleID DEFAULT (0) FOR RoleID
GO
ALTER TABLE dbo.Tmp_Employee ADD CONSTRAINT
	DF__Employee__Employ__3E923B2D DEFAULT ('A') FOR EmployeeStatus
GO
ALTER TABLE dbo.Tmp_Employee ADD CONSTRAINT
	DF__Employee__PoolRi__10416098 DEFAULT ((0)) FOR PoolRight
GO
ALTER TABLE dbo.Tmp_Employee ADD CONSTRAINT
	DF__Employee__Employ__113584D1 DEFAULT ('U') FOR EmployeeType
GO
IF EXISTS(SELECT * FROM dbo.Employee)
	 EXEC('INSERT INTO dbo.Tmp_Employee (EmployeeID, EmployeeName, DateOfBirth, Phone, Address, Street, City, State, Zip, UserID, Description, PayDraw, PayNormalPercent, PayOCPercent, NormalPercAfterDayx, Supervisor, MaxNoPromise, MaxWithProm, Extension, AutoAssign, MimDailyAmt, AssColStart, AssColEnd, Goal, SuperVisorId, Nationality, Language_Id, Prior_Exp, Date_Of_Joining, Daily_Cap, Comment1, Comment2, Comment3, SignOn, Blocked, Department, RoleID, EmployeeStatus, PoolRight, EmployeeType, CreatedDate)
		SELECT EmployeeID, EmployeeName, DateOfBirth, Phone, Address, Street, City, State, Zip, UserID, Description, PayDraw, PayNormalPercent, PayOCPercent, NormalPercAfterDayx, Supervisor, MaxNoPromise, MaxWithProm, Extension, AutoAssign, MimDailyAmt, AssColStart, AssColEnd, Goal, SuperVisorId, Nationality, Language_Id, Prior_Exp, Date_Of_Joining, Daily_Cap, CONVERT(nvarchar(225), Comment1), CONVERT(nvarchar(225), Comment2), CONVERT(nvarchar(225), Comment3), SignOn, Blocked, Department, RoleID, EmployeeStatus, PoolRight, EmployeeType, CreatedDate FROM dbo.Employee WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.Employee
GO
EXECUTE sp_rename N'dbo.Tmp_Employee', N'Employee', 'OBJECT' 
GO
CREATE UNIQUE NONCLUSTERED INDEX IX_EmployeeID ON dbo.Employee
	(
	EmployeeID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_SuperID ON dbo.Employee
	(
	SuperVisorId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_DeptID ON dbo.Employee
	(
	Department
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_RoleID ON dbo.Employee
	(
	RoleID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO


IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_GroupSteps' and c.name = 'CaseNumber')
BEGIN
	ALTER TABLE Legal_GroupSteps ADD CaseNumber varchar(30) NULL
END
GO


-- 2008/10/03	[Binh Truong]	Set identity to DefineLetters.LetterID
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.DefineLetters
	DROP CONSTRAINT DF__DefineLet__Clien__713DB68B
GO
CREATE TABLE dbo.Tmp_DefineLetters
	(
	LetterID int NOT NULL IDENTITY (1, 1),
	LetterDesc varchar(50) NULL,
	LetterType tinyint NULL,
	FileName varchar(255) NULL,
	Destination tinyint NULL,
	Copies tinyint NOT NULL,
	Parameters varchar(255) NULL,
	AccountSpecific bit NOT NULL,
	Narration varchar(255) NULL,
	DocumentPath varchar(250) NULL,
	EmailAddress varchar(250) NULL,
	ClientID int NULL
	)  ON [PRIMARY]
GO
EXECUTE sp_bindefault N'dbo.def_value_true', N'dbo.Tmp_DefineLetters.Copies'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_DefineLetters.AccountSpecific'
GO
ALTER TABLE dbo.Tmp_DefineLetters ADD CONSTRAINT
	DF__DefineLet__Clien__713DB68B DEFAULT ((0)) FOR ClientID
GO
SET IDENTITY_INSERT dbo.Tmp_DefineLetters ON
GO
IF EXISTS(SELECT * FROM dbo.DefineLetters)
	 EXEC('INSERT INTO dbo.Tmp_DefineLetters (LetterID, LetterDesc, LetterType, FileName, Destination, Copies, Parameters, AccountSpecific, Narration, DocumentPath, EmailAddress, ClientID)
		SELECT LetterID, LetterDesc, LetterType, FileName, Destination, Copies, Parameters, AccountSpecific, Narration, DocumentPath, EmailAddress, ClientID FROM dbo.DefineLetters WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_DefineLetters OFF
GO
DROP TABLE dbo.DefineLetters
GO
EXECUTE sp_rename N'dbo.Tmp_DefineLetters', N'DefineLetters', 'OBJECT' 
GO
COMMIT
GO

-- 2008/10/03	[Binh Truong]	Add unique index on AccountOther.AccountID
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
DROP INDEX IX_AccountID ON dbo.AccountOther
GO
CREATE UNIQUE NONCLUSTERED INDEX IX_AccountID ON dbo.AccountOther
	(
	AccountID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Groups' and c.name = 'StateServiced')
BEGIN
	ALTER TABLE Legal_Groups ADD StateServiced varchar(30) NULL
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Save_Note]    Script Date: 10/03/2008 11:38:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Save_Note]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Save_Note]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Save_Note]    Script Date: 10/03/2008 11:38:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Save_Note]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-----------------------------------------------
-- Description: Save note.
-- History:
--	2008/10/03	[Binh Truong]	Update NoteText from varchar to nvarchar datatype.
--								Update NoteText length from 700 to 1000.
-----------------------------------------------
CREATE PROCEDURE [dbo].[CWX_Save_Note] 	
(	
	@EmployeeID int, 
	@DebtorID int, 
	@AccountID int, 
	@NoteDateTime datetime, 
	@NoteType varchar (1), 
	@NoteText nvarchar(1000)
)
AS
BEGIN

INSERT INTO [dbo].[NotesCurrent] (EmployeeID, DebtorID, BillID, NoteDateTime, NoteType, NoteText)
VALUES (@EmployeeID, @DebtorID, @AccountID, @NoteDateTime, @NoteType, @NoteText )

SELECT @@IDENTITY

END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_UpdateList]    Script Date: 10/03/2008 11:39:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_UpdateList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProductSetting_UpdateList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_UpdateList]    Script Date: 10/03/2008 11:39:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_UpdateList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/24	[LongNguyen]	Init version.
--	2008/10/03	[Binh Truong]	Update @Value varchar to nvarchar datatype.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ProductSetting_UpdateList]
	@ProductSettings xml
AS
BEGIN
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE ProductSettingCrsr CURSOR FOR
    SELECT
		ParamValues.ProductSetting.value(''./@InfoID'',''int'') AS InfoID,
		ParamValues.ProductSetting.value(''./@InfoType'',''int'') AS InfoType,
		ParamValues.ProductSetting.value(''./@InfoSubType'',''int'') AS InfoSubType,
		ParamValues.ProductSetting.value(''./@InfoKey'',''varchar(50)'') AS InfoKey,
		ParamValues.ProductSetting.value(''./@Value'',''varchar(50)'') AS [Value]
	FROM
		@ProductSettings.nodes(''/ProductSettings/ProductSetting'') as ParamValues(ProductSetting) 

	OPEN ProductSettingCrsr

	DECLARE @InfoID int
	DECLARE @InfoType int
	DECLARE @InfoSubType int
	DECLARE @InfoKey varchar(50)
	DECLARE @Value nvarchar(50)

	FETCH NEXT FROM ProductSettingCrsr
	INTO @InfoID, @InfoType, @InfoSubType, @InfoKey, @Value

	WHILE @@FETCH_STATUS = 0
	BEGIN
		UPDATE InformationTable
		SET
			[Value] = @Value
		WHERE
			(InfoID = @InfoID)
			AND (InfoType = @InfoType)
			AND (InfoSubType = @InfoSubType)
			AND (InfoKey = @InfoKey)

		IF( @@ERROR <> 0)
			GOTO Cleanup

		FETCH NEXT FROM ProductSettingCrsr
		INTO @InfoID, @InfoType, @InfoSubType, @InfoKey, @Value
	END

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE ProductSettingCrsr
	DEALLOCATE ProductSettingCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END

' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Notes_GetWithType]    Script Date: 10/03/2008 11:34:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Notes_GetWithType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Notes_GetWithType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Notes_GetWithType]    Script Date: 10/03/2008 11:34:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Notes_GetWithType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get notes from database
-- History:
--	2008/05/08	[Tai Ly]		Init version.
--	2008/10/03	[Binh Truong]	Update NoteText varchar to nvarchar datatype.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Notes_GetWithType]
	@DebtorID	int,
	@AccountID	int,
	@NoteText	nvarchar(1000) = '''',
	@NoteType	varchar(1) = '' '',	
	@Month		int = -1,
	@Day		int = -1,
	@FromDate	datetime = ''1753-01-01'',
	@ToDate		datetime = ''9999-12-31'',
	@SearchHistory bit = 0,
	@SearchByAccount bit = 0,
	@PageSize	int = 10,
	@PageIndex	int = 0
AS
BEGIN
	DECLARE @TempTableVar table(
		RowNumber		int,
		NoteDateTime	datetime,
		NoteText		nvarchar(1000),
		NoteType		varchar(1),
		UserID			varchar(10)
	);

	IF @Month >= 0
	BEGIN
		SET @FromDate = DATEADD(month, -1*@Month, GETDATE())
		SET @ToDate = GETDATE()
	END
	ELSE IF @Day >= 0
	BEGIN
		SET @FromDate = DATEADD(day, -1*@Day, GETDATE())
		SET @ToDate = GETDATE()
	END

	SELECT @NoteText = ''%'' + @NoteText + ''%'';

	IF @SearchHistory = 0
		INSERT INTO @TempTableVar
		SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID
		FROM		NotesCurrent n, Employee e
		WHERE		((@SearchByAccount = 0 AND n.DebtorID = @DebtorID) OR n.BillID = @AccountID)
					AND n.EmployeeID *= e.EmployeeID 
					AND (@NoteType = '' '' OR UPPER(NoteType) = UPPER(@NoteType))
					AND n.NoteText LIKE @NoteText
					AND (DATEDIFF(day, @FromDate, n.NoteDateTime)>=0 AND DATEDIFF(day, n.NoteDateTime, @ToDate)>=0)
	ELSE
		INSERT INTO @TempTableVar
		SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID
		FROM		NotesHistory n, Employee e
		WHERE		((@SearchByAccount = 0 AND n.DebtorID = @DebtorID) OR n.BillID = @AccountID)
					AND n.EmployeeID *= e.EmployeeID 
					AND (@NoteType = '' '' OR UPPER(NoteType) = UPPER(@NoteType))
					AND n.NoteText LIKE @NoteText
					AND (DATEDIFF(day, @FromDate, n.NoteDateTime)>=0 AND DATEDIFF(day, n.NoteDateTime, @ToDate)>=0)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
	ELSE
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
		WHERE	RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize)		

	RETURN @RowCount

END
' 
END
GO

-- Scripts 2.7.2:
-- =============================================================
-- Author:		Minh Dam
-- Create date: Otc 06, 2008
-- Description:	Drop unused tables and store procedures.
-- =============================================================
-- Drop Tables
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AccountLegal]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	drop table AccountLegal
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FunctionRiskDetails]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)	
	drop table FunctionRiskDetails
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FunctionRiskMaster]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)	
	drop table FunctionRiskMaster 
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[LegalProcess]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)	
	drop table LegalProcess
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[LegalProcessItems]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)	
	drop table LegalProcessItems
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Region_Master]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)	
	drop table Region_Master 
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransactionTypeOld]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)	
	drop table TransactionTypeOld 
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TempAlloc]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)	
	drop table TempAlloc 
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EmployeeCallSetup]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)	
	drop table EmployeeCallSetup 
GO
-- Drop Stored Procedures
drop procedure CheckBlackoutDate 
drop procedure fn_Locate 
drop procedure CW_Automatic_Processing 
drop procedure GetAutoProcessDef 
drop procedure GetHousehold 
drop procedure GetHouseholdForEdit 
drop procedure GetHouseholdForHistory
drop procedure Instr 
drop procedure LoadPhoenixPayments 
drop procedure LockDebtor 
drop procedure OAMoveToOAMain 

drop procedure OA_Inventory_p 
drop procedure OA_Spindown_p 
drop procedure OAAccountByRound 
drop procedure OAAccountByRoundIndia 
drop procedure OAChangeEmployee 
drop procedure OAConfirmSubmit 
drop procedure OACreateSubmitList 
drop procedure OADaysFromOAID 
drop procedure OADaysFromWriteOff 
drop procedure OADaysPastDue 
drop procedure OAImportReturnList 
drop procedure OAInitialLoad 
drop procedure OAMoveAccountsIntoOA 
drop procedure OAMoveToOAAROA 
drop procedure OAMoveToOACORP 
drop procedure OAMoveToOAVIP 
drop procedure OAPrepareAccountsForSubmit
drop procedure OASpinDownP 
drop procedure OASubmitListToConfirm 
drop procedure OASubmitListToConfirmIndia 
drop procedure OAVintageP 
drop procedure PullAccountsBasedOnStatute 
drop procedure PullAccountsToReport 
drop procedure PullLetters 
drop procedure Queue_NoCallBack 
drop procedure QueueBrokenPTP 
drop procedure QueueByBucket 
drop procedure QueueByCycle 
drop procedure QueueByScore 
drop procedure QueueUnifund 
drop procedure QueueUnifundRedo 
drop procedure QueueUnifundRedoByEmployee 
drop procedure QueueUnifundSpecial 
drop procedure rptDebtorInfo 
drop procedure rptDebtorNotes 
drop procedure rptInformationByDebtor 
drop procedure SVActionToday 

drop procedure SvByActionCode 
drop procedure SvByAlloc 

drop procedure SvByAmtRange 

drop procedure SvByBucket 
drop procedure SvByCycle 
drop procedure SVByEmployee
drop procedure SvByScore 
drop procedure SvByStatus 
drop procedure SvDeceased 
drop procedure SvSkip 
drop procedure UnifundReport 
drop procedure UpdateAccountAge 
drop procedure SearchAccountByPatientName 
drop procedure SearchAccountByTicketNumber 
drop procedure SearchBillByBill 
drop procedure SearchByAllocQueue 
drop procedure SearchByQueue 
drop procedure SearchBySavingAcctNo 

drop procedure SearchDebtorByID 
drop procedure SearchDebtorByRIM 
drop procedure SearchByLegalEmployee 
drop procedure SearchByLegalForward
drop procedure SearchByLegalNextAction 

drop procedure SearchCollateralByEmployee 
drop procedure SearchCollateralItemType 
drop procedure SearchCollateralNextAction 
drop procedure SearchCollateralStage 
drop procedure SearchByEmployeeName 

drop procedure Queue_NoActivityInXDays 
drop procedure Queue_NoContactInXDays 

drop procedure SearchDebtorByName 
drop procedure QueueFuture 
drop procedure QueueByAmtRange 
drop procedure SearchReviewAccounts 
drop procedure GetTickets 
drop procedure SearchByQueueAStat 
drop procedure SearchByQueueSStat
GO
-- Scripts 2.7.3:

/****** Object:  StoredProcedure [dbo].[CWX_PersonAddress_Get]    Script Date: 10/06/2008 15:58:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonAddress_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonAddress_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonAddress_Get]    Script Date: 10/06/2008 15:58:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================================
-- Author:		Triet Pham
-- Create date: Mar 26th, 2008
-- Description:	Retrieve all personal addresses
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_PersonAddress_Get]	
	@DebtorID int,
	@PersonID int = 0
AS
BEGIN

	SET NOCOUNT ON	
	
	DECLARE @HomeAddress1 varchar(255)
	DECLARE @HomeAddress2 varchar(255)
	DECLARE @HomeAddress3 varchar(255)
	DECLARE @HomeCity varchar(255)
	DECLARE @HomeState varchar(50)
	DECLARE @HomeZip varchar(25)
	DECLARE @HomeCountry varchar(50)
	DECLARE @HomeTerritory varchar(50)
	DECLARE @HomeRegion varchar(50)
	DECLARE @HomeMailingAddress bit

	DECLARE @PostalAddress1 varchar(255)
	DECLARE @PostalAddress2 varchar(255)
	DECLARE @PostalAddress3 varchar(255)
	DECLARE @PostalCity varchar(255)
	DECLARE @PostalState varchar(50)
	DECLARE @PostalZip varchar(25)
	DECLARE @PostalCountry varchar(50)
	DECLARE @PostalTerritory varchar(50)
	DECLARE @PostalRegion varchar(50)
	DECLARE @PostalMailingAddress bit

	DECLARE @EmploymentAddress1 varchar(255)
	DECLARE @EmploymentAddress2 varchar(255)
	DECLARE @EmploymentAddress3 varchar(255)
	DECLARE @EmploymentCity varchar(255)
	DECLARE @EmploymentState varchar(50)
	DECLARE @EmploymentZip varchar(25)
	DECLARE @EmploymentCountry varchar(50)
	DECLARE @EmploymentTerritory varchar(50)
	DECLARE @EmploymentRegion varchar(50)
	DECLARE @EmploymentMailingAddress bit

	DECLARE @OtherAddress1 varchar(255)
	DECLARE @OtherAddress2 varchar(255)
	DECLARE @OtherAddress3 varchar(255)
	DECLARE @OtherCity varchar(255)
	DECLARE @OtherState varchar(50)
	DECLARE @OtherZip varchar(25)
	DECLARE @OtherCountry varchar(50)
	DECLARE @OtherTerritory varchar(50)
	DECLARE @OtherRegion varchar(50)
	DECLARE @OtherMailingAddress bit

	SELECT
		@HomeAddress1 = p.Address1,
		@HomeAddress2 = p.Address2,
		@HomeAddress3 = p.Address3,
		@HomeCity = p.City,
		@HomeState = p.State,
		@HomeZip = p.Zip,
		@HomeCountry = p.Country,
		@HomeTerritory = p.Territory,
		@HomeRegion = p.Region,
		@HomeMailingAddress = p.MailingAddress
	FROM PersonAddress p 
	LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
	WHERE 
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (p.PersonID = @PersonID))
		AND p.AddressType = 1

	SELECT
		@EmploymentAddress1 = p.Address1,
		@EmploymentAddress2 = p.Address2,
		@EmploymentAddress3 = p.Address3,
		@EmploymentCity = p.City,
		@EmploymentState = p.State,
		@EmploymentZip = p.Zip,
		@EmploymentCountry = p.Country,
		@EmploymentTerritory = p.Territory,
		@EmploymentRegion = p.Region,
		@EmploymentMailingAddress = p.MailingAddress
	FROM PersonAddress p 
	LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
	WHERE 
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (p.PersonID = @PersonID))
		AND p.AddressType = 3

	SELECT
		@PostalAddress1 = p.Address1,
		@PostalAddress2 = p.Address2,
		@PostalAddress3 = p.Address3,
		@PostalCity = p.City,
		@PostalState = p.State,
		@PostalZip = p.Zip,
		@PostalCountry = p.Country,
		@PostalTerritory = p.Territory,
		@PostalRegion = p.Region,
		@PostalMailingAddress = p.MailingAddress
	FROM PersonAddress p 
	LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
	WHERE 
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (p.PersonID = @PersonID))
		AND p.AddressType = 2

	SELECT
		@OtherAddress1 = p.Address1,
		@OtherAddress2 = p.Address2,
		@OtherAddress3 = p.Address3,
		@OtherCity = p.City,
		@OtherState = p.State,
		@OtherZip = p.Zip,
		@OtherCountry = p.Country,
		@OtherTerritory = p.Territory,
		@OtherRegion = p.Region,
		@OtherMailingAddress = p.MailingAddress
	FROM PersonAddress p 
	LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
	WHERE 
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (p.PersonID = @PersonID))
		AND p.AddressType = 4

	SELECT 
		@HomeAddress1 AS HomeAddress1,
		@HomeAddress2 AS HomeAddress2,
		@HomeAddress3 AS HomeAddress3,
		@HomeCity AS HomeCity,
		@HomeState AS HomeState,
		@HomeZip AS HomeZip,
		@HomeCountry AS HomeCountry,
		@HomeTerritory AS HomeTerritory,
		@HomeRegion AS HomeRegion,
		@HomeMailingAddress AS HomeMailingAddress,

		@PostalAddress1 AS PostalAddress1,
		@PostalAddress2 AS PostalAddress2,
		@PostalAddress3 AS PostalAddress3,
		@PostalCity AS PostalCity,
		@PostalState AS PostalState,
		@PostalZip AS PostalZip,
		@PostalCountry AS PostalCountry,
		@PostalTerritory AS PostalTerritory,
		@PostalRegion AS PostalRegion,
		@PostalMailingAddress AS PostalMailingAddress,

		@EmploymentAddress1 AS EmploymentAddress1,
		@EmploymentAddress2 AS EmploymentAddress2,
		@EmploymentAddress3 AS EmploymentAddress3,
		@EmploymentCity AS EmploymentCity,
		@EmploymentState AS EmploymentState,
		@EmploymentZip AS EmploymentZip,
		@EmploymentCountry AS EmploymentCountry,
		@EmploymentTerritory AS EmploymentTerritory,
		@EmploymentRegion AS EmploymentRegion,
		@EmploymentMailingAddress AS EmploymentMailingAddress,

		@OtherAddress1 AS OtherAddress1,
		@OtherAddress2 AS OtherAddress2,
		@OtherAddress3 AS OtherAddress3,
		@OtherCity AS OtherCity,
		@OtherState AS OtherState,
		@OtherZip AS OtherZip,
		@OtherCountry AS OtherCountry,
		@OtherTerritory AS OtherTerritory,
		@OtherRegion AS OtherRegion,
		@OtherMailingAddress AS OtherMailingAddress

	SET NOCOUNT OFF
END
GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
CREATE TABLE dbo.Tmp_NotesCurrent
	(
	NoteID int NOT NULL IDENTITY (1, 1),
	SequenceID tinyint NOT NULL,
	EmployeeID int NOT NULL,
	DebtorID int NOT NULL,
	BillID int NOT NULL,
	NoteDateTime datetime NULL,
	NoteType varchar(1) NULL,
	NoteText nvarchar(1000) NULL
	)  ON [PRIMARY]
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_NotesCurrent.SequenceID'
GO
SET IDENTITY_INSERT dbo.Tmp_NotesCurrent ON
GO
IF EXISTS(SELECT * FROM dbo.NotesCurrent)
	 EXEC('INSERT INTO dbo.Tmp_NotesCurrent (NoteID, SequenceID, EmployeeID, DebtorID, BillID, NoteDateTime, NoteType, NoteText)
		SELECT NoteID, SequenceID, EmployeeID, DebtorID, BillID, NoteDateTime, NoteType, CONVERT(nvarchar(1000), NoteText) FROM dbo.NotesCurrent WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_NotesCurrent OFF
GO
DROP TABLE dbo.NotesCurrent
GO
EXECUTE sp_rename N'dbo.Tmp_NotesCurrent', N'NotesCurrent', 'OBJECT' 
GO
CREATE NONCLUSTERED INDEX IDX_DebtorID ON dbo.NotesCurrent
	(
	DebtorID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_NDNT ON dbo.NotesCurrent
	(
	NoteDateTime DESC,
	NoteType
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO

-- Scripts 2.7.4:
-- =============================================================
-- Author:		Minh Dam
-- Create date: Oct 07, 2008
-- Description:	Add new column "CreatedBy" to table Legal_GroupSteps
-- =============================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_GroupSteps' and c.name = 'CreatedBy')
BEGIN
	ALTER TABLE Legal_GroupSteps
		ADD CreatedBy int NULL
END
GO

-- =============================================================
-- Author:		Minh Dam
-- Create date: Oct 07, 2008
-- Description:	Update SP CWX_Legal_GroupSteps_GetList
-- =============================================================
/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupSteps_GetList]    Script Date: 10/07/2008 14:48:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[CWX_Legal_GroupSteps_GetList]
	@groupID int
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
			b.Code +' - '+ b.Description as CodeDesc, a.*, c.Description as CourtDesc, d.Description as AgentDesc,
			e.EmployeeName as CreatedByName
	FROM	
			Legal_GroupSteps a 
				LEFT JOIN Legal_GroupStepTypes b ON a.GroupStepTypeID = b.GroupStepTypeID AND b.Status <> 'R'
				LEFT JOIN Legal_Courts c ON a.CourtID = c.CourtID
				LEFT JOIN Legal_Agents d ON a.AgentID = d.AgentID
				LEFT JOIN Employee e ON a.CreatedBy = e.EmployeeID
	WHERE 
			a.GroupID = @groupID AND a.Status <> 'R'
	ORDER BY a.GroupStepID
	
	
	SELECT     SUM(DebtAmount) as TotalDebt, SUM(IntAmount) as TotalInterest
	FROM         Legal_GroupSteps
	WHERE     (GroupID = @groupID) AND (Status <> 'R') 
	
END
GO

-- =============================================================
-- Author:		Minh Dam
-- Create date: Oct 07, 2008
-- Description:	Drop table LegalAction and LegalBillDetails
-- =============================================================
/****** Object:  Table [dbo].[LegalAction]    Script Date: 10/07/2008 15:40:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LegalAction]') AND type in (N'U'))
DROP TABLE [dbo].[LegalAction]
GO

/****** Object:  Table [dbo].[LegalBillDetails]    Script Date: 10/07/2008 15:41:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LegalBillDetails]') AND type in (N'U'))
DROP TABLE [dbo].[LegalBillDetails]
GO

-- Scripts 2.7.5:

IF NOT EXISTS (SELECT * FROM IdentityFields WHERE TableName='SearchID')
	INSERT INTO IdentityFields VALUES('SearchID', 0)
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_Collateral_Dict' and c.name = 'CollateralTypeID')
BEGIN
	ALTER TABLE CWX_Collateral_Dict ADD CollateralTypeID int NULL
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 10/09/2008 18:25:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 10/09/2008 18:25:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		Minh Dam
-- Create date: 15/08/2008
-- Description:	
-- =============================================				
CREATE PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
	@CollateralID int,
	@ClientID int = 0,
	@CollateralTypeID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @CollateralID <> 0 AND @CollateralTypeID = 0
		SELECT @CollateralTypeID = CollateralType FROM Collateral WHERE ID = @CollateralID

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			b.[DataType],
			b.[MaxLength]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], [DisplayOrder]
		FROM CWX_Collateral_Dict
		WHERE Displayed = 1	AND (@ClientID = 0 OR ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID) AND (@CollateralTypeID = 0 OR ISNULL(CollateralTypeID, 0) = 0 OR CollateralTypeID = @CollateralTypeID)) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], c.[max_length] as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Collateral' and [Type]='U')
			AND (c.[name] LIKE 'CInt%' OR c.[name] LIKE 'CString%' OR c.[name] LIKE 'CDate%' OR c.[name] LIKE 'CMoney%')
		) b 
		ON a.[FieldName] = b.[ColumnName]
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'ID,AccountID,HostCollateralID,EmployeeID,NextActionDate,Image,ImageFileName,'
	SET @FieldNameList = @FieldNameList + 
		'(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6) IS NOT NULL THEN CollateralType ELSE 0 END) AS CollateralType,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7) IS NOT NULL THEN CollateralStage ELSE 0 END) AS CollateralStage,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2) IS NOT NULL THEN NextAction ELSE 0 END) AS NextAction'
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM Collateral WHERE ID = ' + Cast(@CollateralID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup
END
GO

-- Scripts 2.7.6:

-- 2008/10/10	[Binh Truong]	Add GroupedAccountID field.
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Legal_Groups ADD
	GroupedAccountID int NULL
GO
COMMIT
GO

/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_GetSettingByAccountID]    Script Date: 10/10/2008 16:27:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_GetSettingByAccountID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProductSetting_GetSettingByAccountID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_GetSettingByAccountID]    Script Date: 10/10/2008 16:27:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_GetSettingByAccountID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get product settings by Account ID.
-- History:
--	2008/05/08	[Binh Truong]	Init version.
--	2008/10/10	[Binh Truong]	Fix bug MCode > 6
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ProductSetting_GetSettingByAccountID]
(
	@AccountID int
)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @ProductInfo int
	DECLARE @Bucket varchar(10)
	DECLARE @ProductID int 
	DECLARE @strMaxBucket varchar(10)
	DECLARE @MaxBucket int
	
	SET @ProductInfo = 6
	
	SELECT  @Bucket=MCode, @ProductID=ClientID
	FROM	Account
	WHERE	AccountID = @AccountID
	
	SELECT  TOP(1) @strMaxBucket=InfoKey
	FROM	InformationTable
	WHERE	InfoID = @ProductInfo AND 
			InfoKey LIKE ''%+''
	
	IF @strMaxBucket IS NULL
	BEGIN
		SELECT  @MaxBucket=MAX(InfoKey)
		FROM	InformationTable
		WHERE	InfoID = @ProductInfo
	END
	ELSE
	BEGIN
		SET @MaxBucket = CAST(REPLACE(@strMaxBucket, ''+'', '''') AS int)
	END
	
	IF @Bucket > @MaxBucket
		SET @Bucket = @strMaxBucket
	
	SELECT  InformationTable.*
	FROM    InformationTable
	WHERE	(InfoID = @ProductInfo) AND 
			(InfoKey = @Bucket) AND 
			(InfoType = @ProductID)
	
END' 
END
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Otc 10, 2008
-- Description:		Add column 'Type' with default value 'D'
--					This field has 3 values: D (System Defined Status), S (System Status), U (User Defined Status)
-- Effected table:	AccountStatus
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'AccountStatus' and c.name = 'Type')
BEGIN
	ALTER TABLE AccountStatus
	ADD [Type] char(1) NOT NULL
		CONSTRAINT [AccountStatus_Type] DEFAULT 'D'
END
GO

UPDATE AccountStatus SET [Type] = 'U' WHERE AgencyStatus > 100
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Otc 10, 2008
-- Description:		Create store procedure CWX_AccountStatus_GetPagingList
-- =======================================================================
/****** Object:  StoredProcedure [dbo].[CWX_AccountStatus_GetPagingList]    Script Date: 10/10/2008 16:25:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountStatus_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountStatus_GetPagingList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_AccountStatus_GetPagingList]    Script Date: 10/10/2008 16:24:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_AccountStatus_GetPagingList]
	-- Add the parameters for the stored procedure here
	@IsUserDefinedStatus bit,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @RowCount int, @type1 char(1), @type2 char(1)
	SET @type1 = 'D'
	SET @type2 = 'S'
	IF (@IsUserDefinedStatus = 1) 
	BEGIN
		SET @type1 = 'U'
		SET @type2 = 'U'
	END

	SELECT ROW_NUMBER() OVER (ORDER BY	a.AgencyStatus ASC) as RowNumber,
			a.AgencyStatus as UserDefinedStatusID,
			a.ShortDesc as ShortDescription, 
			a.LongDesc as LongDescription, a.SortPriority,
			a.LoadInProductID, a.Type,
			ISNULL(b.ShortDesc,'') as SystemStatus
			, a.SupReq, a.AcceptPartPay
--			a.ReportToCreditBureau, a.PIF_Status, a.LettersAllowed,
--			a.LoadInDialer, a.PrintOnReports, a.LoadInQueue, 
--			a.CalcInBalance, a.ChargeInterest, a.OverrideDateAdvancement,
--			a.SpecialProcessingStatus,a.CreditReportAction,
	INTO #temp
	FROM AccountStatus a
		LEFT JOIN AccountStatus b ON a.SystemStatus = b.AgencyStatus
	WHERE a.Status <> 'R' AND (a.[Type] = @type1 OR a.[Type] = @type2)

	SELECT @RowCount = @@ROWCOUNT

	SELECT *
	FROM #temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Otc 10, 2008
-- Description:		Alter procedure CWX_AccountStatus_SoftDeleteAll
-- =======================================================================
/****** Object:  StoredProcedure [dbo].[CWX_AccountStatus_SoftDeleteAll]    Script Date: 10/10/2008 16:26:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [dbo].[CWX_AccountStatus_SoftDeleteAll]    Script Date: 10/10/2008 16:26:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER Procedure [dbo].[CWX_AccountStatus_SoftDeleteAll]
(
	@IsUserDefinedStatus bit
)
AS
BEGIN	
	DECLARE @type char(1)
	IF (@IsUserDefinedStatus = 1)	
		SET @type = 'U'
	ELSE
		SET @type = 'S'

	UPDATE	AccountStatus
	SET		[Status] = 'R'
	WHERE	[Type] = @type
END	
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Otc 10, 2008
-- Description:		Change data type of column SystemStatus from tinyint to int
-- Affected table: AccountStatus
-- =======================================================================
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.AccountStatus
	DROP CONSTRAINT AccountStatus_RowStatus
GO
ALTER TABLE dbo.AccountStatus
	DROP CONSTRAINT AccountStatus_LoadInProductID_Default
GO
ALTER TABLE dbo.AccountStatus
	DROP CONSTRAINT AccountStatus_Type
GO
CREATE TABLE dbo.Tmp_AccountStatus
	(
	AgencyStatus int NOT NULL,
	ShortDesc varchar(10) NULL,
	LongDesc varchar(50) NULL,
	SystemStatus int NOT NULL,
	SupReq bit NOT NULL,
	AcceptPartPay bit NOT NULL,
	ReportToCreditBureau bit NOT NULL,
	PIF_Status tinyint NOT NULL,
	LettersAllowed bit NOT NULL,
	LoadInDialer bit NOT NULL,
	PrintOnReports bit NOT NULL,
	LoadInQueue bit NOT NULL,
	CalcInBalance bit NOT NULL,
	ChargeInterest bit NOT NULL,
	OverrideDateAdvancement bit NOT NULL,
	SpecialProcessingStatus bit NOT NULL,
	CreditReportAction tinyint NULL,
	SortPriority int NULL,
	Status char(1) NULL,
	LoadInProductID int NULL,
	Type char(1) NOT NULL
	)  ON [PRIMARY]
GO
DECLARE @v sql_variant 
SET @v = N'Priority_Q'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_AccountStatus', N'COLUMN', N'SortPriority'
GO
EXECUTE sp_bindefault N'dbo.def_value_true', N'dbo.Tmp_AccountStatus.SystemStatus'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_AccountStatus.SupReq'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_AccountStatus.AcceptPartPay'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_AccountStatus.ReportToCreditBureau'
GO
EXECUTE sp_bindefault N'dbo.def_val_four', N'dbo.Tmp_AccountStatus.PIF_Status'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_AccountStatus.LettersAllowed'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_AccountStatus.LoadInDialer'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_AccountStatus.PrintOnReports'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_AccountStatus.LoadInQueue'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_AccountStatus.CalcInBalance'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_AccountStatus.ChargeInterest'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_AccountStatus.OverrideDateAdvancement'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_AccountStatus.SpecialProcessingStatus'
GO
ALTER TABLE dbo.Tmp_AccountStatus ADD CONSTRAINT
	AccountStatus_RowStatus DEFAULT ('A') FOR Status
GO
ALTER TABLE dbo.Tmp_AccountStatus ADD CONSTRAINT
	AccountStatus_LoadInProductID_Default DEFAULT ((0)) FOR LoadInProductID
GO
ALTER TABLE dbo.Tmp_AccountStatus ADD CONSTRAINT
	AccountStatus_Type DEFAULT ('D') FOR Type
GO
IF EXISTS(SELECT * FROM dbo.AccountStatus)
	 EXEC('INSERT INTO dbo.Tmp_AccountStatus (AgencyStatus, ShortDesc, LongDesc, SystemStatus, SupReq, AcceptPartPay, ReportToCreditBureau, PIF_Status, LettersAllowed, LoadInDialer, PrintOnReports, LoadInQueue, CalcInBalance, ChargeInterest, OverrideDateAdvancement, SpecialProcessingStatus, CreditReportAction, SortPriority, Status, LoadInProductID, Type)
		SELECT AgencyStatus, ShortDesc, LongDesc, CONVERT(int, SystemStatus), SupReq, AcceptPartPay, ReportToCreditBureau, PIF_Status, LettersAllowed, LoadInDialer, PrintOnReports, LoadInQueue, CalcInBalance, ChargeInterest, OverrideDateAdvancement, SpecialProcessingStatus, CreditReportAction, SortPriority, Status, LoadInProductID, Type FROM dbo.AccountStatus WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.AccountStatus
GO
EXECUTE sp_rename N'dbo.Tmp_AccountStatus', N'AccountStatus', 'OBJECT' 
GO
CREATE NONCLUSTERED INDEX IDX_AGID ON dbo.AccountStatus
	(
	AgencyStatus
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_SPriority ON dbo.AccountStatus
	(
	SortPriority
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Otc 10, 2008
-- Description:		Change data type of column SystemStatusID from tinyint to int
-- Effective table: Account
-- =======================================================================
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_EmployeeID
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_ClientID
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_AgencyStatusID
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_OfficeID
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_MCode
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_CCode
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_RoutinePayment
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_PaymentPlan
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_BillOtherCharges
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_CurrentAction
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_AllocRuleID
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_AutoProcRuleID
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_AccountForwardedTo
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_ActionEmployee
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_CreditReportRequestedBy
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_TempEmployeeID
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_OAManaged
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_InterfaceID
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_SortOrder
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_Allocated
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_BrokenCount
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_productivecount
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_contactcount
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_nocontactcount
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_BucketMovement
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_DPDMovement
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_PreviousAllocRuleID
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_OnLeaveFlag
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF__Account__Current__44801EAD
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF__Account__Current__457442E6
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF__Account__Current__4668671F
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF__Account__Campaig__597B3B93
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF__Account__MaxCont__742F31CF
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF__Account__Assignm__3D9E16F4
GO
CREATE TABLE dbo.Tmp_Account
	(
	AccountID int NOT NULL,
	DebtorID int NOT NULL,
	EmployeeID int NULL,
	ClientID int NULL,
	AgencyStatusID int NULL,
	SystemStatusID int NULL,
	ActionCodeID tinyint NULL,
	OfficeID smallint NULL,
	MCode smallint NULL,
	CCode smallint NULL,
	InvoiceNumber varchar(50) NULL,
	AccountType varchar(100) NULL,
	AccountClass varchar(100) NULL,
	QueueDate smalldatetime NULL,
	DateOfService smalldatetime NULL,
	SubmissionDate smalldatetime NULL,
	LastClientTransactionDate smalldatetime NULL,
	RoutinePayment money NOT NULL,
	PaymentPlan tinyint NULL,
	PatientName varchar(50) NULL,
	BillAmount money NOT NULL,
	BillBalance money NOT NULL,
	BillOtherCharges money NOT NULL,
	ClientPaysLegalFees bit NOT NULL,
	AccountForwarded bit NOT NULL,
	CreditReported bit NOT NULL,
	CreditReportedDate smalldatetime NULL,
	ClientPercent real NOT NULL,
	ClientOCPercent real NOT NULL,
	SplitPayment bit NOT NULL,
	CurrentAction tinyint NULL,
	CurrentActionDate smalldatetime NULL,
	NoLetterBefore smalldatetime NULL,
	NoFeeBefore smalldatetime NULL,
	MaintainOfficer bit NOT NULL,
	AccountAge int NOT NULL,
	LastEditDate smalldatetime NOT NULL,
	LastEditBy char(10) NOT NULL,
	LastVerifyDate smalldatetime NULL,
	AllocRuleID int NULL,
	AutoProcRuleID int NULL,
	LastExtractionDate smalldatetime NULL,
	LastAllocationDate smalldatetime NULL,
	LastAutoProcessDate smalldatetime NULL,
	ExtractionRuleID int NULL,
	AccountForwardedTo int NULL,
	CurrencyCode varchar(3) NULL,
	BatchNumber varchar(12) NULL,
	InterestRate real NULL,
	ActionEmployee int NULL,
	LastPromiseBatch varchar(12) NULL,
	CreditReportRequested bit NULL,
	CreditReportRequestedBy int NULL,
	CreditReportRequestedOn smalldatetime NULL,
	CreditReportRequestStatus int NULL,
	WriteOffDate smalldatetime NULL,
	LastInterestDate smalldatetime NULL,
	TempEmployeeID int NULL,
	OAManaged bit NOT NULL,
	InterfaceID int NULL,
	Delq_string varchar(6) NULL,
	SortOrder int NULL,
	Allocated bit NULL,
	BrokenCount int NULL,
	CARD_FILE_NO varchar(35) NULL,
	ARREAR_PATH varchar(10) NULL,
	BUCKET_TYPE varchar(30) NULL,
	OLD_BUCKET_TYPE varchar(30) NULL,
	CARD_TYPE varchar(35) NULL,
	BRANCH_CODE varchar(10) NULL,
	FORMULA varchar(10) NULL,
	BANK_CODE varchar(35) NULL,
	PAID varchar(25) NULL,
	OtherAccountNo varchar(50) NULL,
	TENOR varchar(10) NULL,
	FORMULA_FLAG varchar(10) NULL,
	MINIMUM_DUE money NULL,
	CURRENT_BKT_NUM decimal(8, 2) NULL,
	PREV_BKT_NUM decimal(8, 2) NULL,
	productivecount int NULL,
	contactcount int NULL,
	nocontactcount int NULL,
	DelqHistory varchar(50) NULL,
	BucketMovement int NULL,
	DPDMovement int NULL,
	PreviousAllocRuleID int NULL,
	OnLeaveEmpID int NULL,
	LeaveLoadRelFlag varchar(1) NULL,
	CurrentReason int NULL,
	CurrentReasonDate smalldatetime NULL,
	CurrentNextAction int NULL,
	CurrentNextActionDate smalldatetime NULL,
	CurrentCallResult int NULL,
	CurrentCallResultDate smalldatetime NULL,
	CampaignId int NULL,
	CloseDate smalldatetime NULL,
	MaxContact int NULL,
	AssignmentType char(1) NULL,
	PoolSelected bit NULL,
	IsPending bit NULL
	)  ON [PRIMARY]
GO
DECLARE @v sql_variant 
SET @v = N'EmployeeId'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'EmployeeID'
GO
DECLARE @v sql_variant 
SET @v = N'ClientID'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'ClientID'
GO
DECLARE @v sql_variant 
SET @v = N'AgencyStatusID'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'AgencyStatusID'
GO
DECLARE @v sql_variant 
SET @v = NULL
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'ActionCodeID'
GO
DECLARE @v sql_variant 
SET @v = N'Bucket_Q'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'MCode'
GO
DECLARE @v sql_variant 
SET @v = N'Cycle_Q'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'CCode'
GO
DECLARE @v sql_variant 
SET @v = N'Account Number'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'InvoiceNumber'
GO
DECLARE @v sql_variant 
SET @v = NULL
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'QueueDate'
GO
DECLARE @v sql_variant 
SET @v = N''
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'SubmissionDate'
GO
DECLARE @v sql_variant 
SET @v = N'Bill Amount_Q'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'BillAmount'
GO
DECLARE @v sql_variant 
SET @v = N'Bill Balance_Q'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'BillBalance'
GO
DECLARE @v sql_variant 
SET @v = N'MDO'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'MaintainOfficer'
GO
DECLARE @v sql_variant 
SET @v = N'DPD_Q'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'AccountAge'
GO
DECLARE @v sql_variant 
SET @v = N'AllocRuleID'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'AllocRuleID'
GO
DECLARE @v sql_variant 
SET @v = N'ReferTo'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'ActionEmployee'
GO
DECLARE @v sql_variant 
SET @v = N'TempEmployee'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'TempEmployeeID'
GO
DECLARE @v sql_variant 
SET @v = N'OAManaged'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'OAManaged'
GO
DECLARE @v sql_variant 
SET @v = N'InterfaceID'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'InterfaceID'
GO
DECLARE @v sql_variant 
SET @v = NULL
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'Delq_string'
GO
DECLARE @v sql_variant 
SET @v = N'Branch Code'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'BRANCH_CODE'
GO
DECLARE @v sql_variant 
SET @v = N'Bank Code'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'BANK_CODE'
GO
DECLARE @v sql_variant 
SET @v = N'Tenor'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'TENOR'
GO
DECLARE @v sql_variant 
SET @v = NULL
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'LeaveLoadRelFlag'
GO
DECLARE @v sql_variant 
SET @v = N'Campaign Id'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'CampaignId'
GO
DECLARE @v sql_variant 
SET @v = N'Close Date'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Account', N'COLUMN', N'CloseDate'
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_EmployeeID DEFAULT ((0)) FOR EmployeeID
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_ClientID DEFAULT ((0)) FOR ClientID
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_AgencyStatusID DEFAULT ((0)) FOR AgencyStatusID
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_OfficeID DEFAULT ((0)) FOR OfficeID
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_MCode DEFAULT ((0)) FOR MCode
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_CCode DEFAULT ((0)) FOR CCode
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_RoutinePayment DEFAULT ((0)) FOR RoutinePayment
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_PaymentPlan DEFAULT ((0)) FOR PaymentPlan
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Account.BillAmount'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Account.BillBalance'
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_BillOtherCharges DEFAULT ((0)) FOR BillOtherCharges
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Account.ClientPaysLegalFees'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Account.AccountForwarded'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Account.CreditReported'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Account.ClientPercent'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Account.ClientOCPercent'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Account.SplitPayment'
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_CurrentAction DEFAULT ((0)) FOR CurrentAction
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Account.MaintainOfficer'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Account.AccountAge'
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_AllocRuleID DEFAULT ((0)) FOR AllocRuleID
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_AutoProcRuleID DEFAULT ((0)) FOR AutoProcRuleID
GO
EXECUTE sp_bindefault N'dbo.def_getdate', N'dbo.Tmp_Account.LastExtractionDate'
GO
EXECUTE sp_bindefault N'dbo.def_getdate', N'dbo.Tmp_Account.LastAllocationDate'
GO
EXECUTE sp_bindefault N'dbo.def_getdate', N'dbo.Tmp_Account.LastAutoProcessDate'
GO
EXECUTE sp_bindefault N'dbo.def_value_false', N'dbo.Tmp_Account.ExtractionRuleID'
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_AccountForwardedTo DEFAULT ((0)) FOR AccountForwardedTo
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_ActionEmployee DEFAULT ((0)) FOR ActionEmployee
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_CreditReportRequestedBy DEFAULT ((0)) FOR CreditReportRequestedBy
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_TempEmployeeID DEFAULT ((0)) FOR TempEmployeeID
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_OAManaged DEFAULT ((0)) FOR OAManaged
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_InterfaceID DEFAULT ((0)) FOR InterfaceID
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_SortOrder DEFAULT ((0)) FOR SortOrder
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_Allocated DEFAULT ((0)) FOR Allocated
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_BrokenCount DEFAULT ((0)) FOR BrokenCount
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_productivecount DEFAULT ((0)) FOR productivecount
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_contactcount DEFAULT ((0)) FOR contactcount
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_nocontactcount DEFAULT ((0)) FOR nocontactcount
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_BucketMovement DEFAULT ((0)) FOR BucketMovement
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_DPDMovement DEFAULT ((0)) FOR DPDMovement
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_PreviousAllocRuleID DEFAULT ((0)) FOR PreviousAllocRuleID
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_OnLeaveFlag DEFAULT ((0)) FOR OnLeaveEmpID
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF__Account__Current__44801EAD DEFAULT ((0)) FOR CurrentReason
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF__Account__Current__457442E6 DEFAULT ((0)) FOR CurrentNextAction
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF__Account__Current__4668671F DEFAULT ((0)) FOR CurrentCallResult
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF__Account__Campaig__597B3B93 DEFAULT ((0)) FOR CampaignId
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF__Account__MaxCont__742F31CF DEFAULT ((0)) FOR MaxContact
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF__Account__Assignm__3D9E16F4 DEFAULT ('A') FOR AssignmentType
GO
IF EXISTS(SELECT * FROM dbo.Account)
	 EXEC('INSERT INTO dbo.Tmp_Account (AccountID, DebtorID, EmployeeID, ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, ClientPercent, ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, NoLetterBefore, NoFeeBefore, MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, BatchNumber, InterestRate, ActionEmployee, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, SortOrder, Allocated, BrokenCount, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM, productivecount, contactcount, nocontactcount, DelqHistory, BucketMovement, DPDMovement, PreviousAllocRuleID, OnLeaveEmpID, LeaveLoadRelFlag, CurrentReason, CurrentReasonDate, CurrentNextAction, CurrentNextActionDate, CurrentCallResult, CurrentCallResultDate, CampaignId, CloseDate, MaxContact, AssignmentType, PoolSelected, IsPending)
		SELECT AccountID, DebtorID, EmployeeID, ClientID, AgencyStatusID, CONVERT(int, SystemStatusID), ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, ClientPercent, ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, NoLetterBefore, NoFeeBefore, MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, BatchNumber, InterestRate, ActionEmployee, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, SortOrder, Allocated, BrokenCount, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM, productivecount, contactcount, nocontactcount, DelqHistory, BucketMovement, DPDMovement, PreviousAllocRuleID, OnLeaveEmpID, LeaveLoadRelFlag, CurrentReason, CurrentReasonDate, CurrentNextAction, CurrentNextActionDate, CurrentCallResult, CurrentCallResultDate, CampaignId, CloseDate, MaxContact, AssignmentType, PoolSelected, IsPending FROM dbo.Account WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.Account
GO
EXECUTE sp_rename N'dbo.Tmp_Account', N'Account', 'OBJECT' 
GO
CREATE UNIQUE CLUSTERED INDEX Account2 ON dbo.Account
	(
	AccountID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_DebtorID ON dbo.Account
	(
	DebtorID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_EmployeeID ON dbo.Account
	(
	EmployeeID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_ClientID ON dbo.Account
	(
	ClientID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_AgencyStatusID ON dbo.Account
	(
	AgencyStatusID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_InvoiceNumber ON dbo.Account
	(
	InvoiceNumber
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_SystemStID ON dbo.Account
	(
	SystemStatusID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_StatusID ON dbo.Account
	(
	AccountID,
	AgencyStatusID,
	SystemStatusID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_DPD ON dbo.Account
	(
	AccountAge
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_MAINALLOC ON dbo.Account
	(
	MaintainOfficer,
	Allocated
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_GR1 ON dbo.Account
	(
	EmployeeID,
	AgencyStatusID,
	SystemStatusID,
	QueueDate
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_GR2 ON dbo.Account
	(
	EmployeeID,
	AgencyStatusID,
	SystemStatusID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_GR3 ON dbo.Account
	(
	TempEmployeeID,
	AgencyStatusID,
	SystemStatusID,
	QueueDate
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_GR4 ON dbo.Account
	(
	TempEmployeeID,
	AgencyStatusID,
	SystemStatusID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDXASSIGNMENT ON dbo.Account
	(
	AssignmentType
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_CreditReported ON dbo.Account
	(
	CreditReported
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_CARDFILENO ON dbo.Account
	(
	CARD_FILE_NO
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IDX_Formulaflag ON dbo.Account
	(
	FORMULA_FLAG
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 10/13/2008 16:20:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 10/13/2008 16:20:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-14
-- Description:	Get the list of Groups of selecting customer
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
	-- Add the parameters for the stored procedure here
	@debtorID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(G.GroupID)
	FROM 
		(SELECT DISTINCT a.GroupID
		FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
			LEFT JOIN Account c ON b.AccountID = c.AccountID
			LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> 'R') d ON a.GroupID = d.GroupID
		WHERE  a.Status <> 'R' and c.DebtorID = @debtorID) G

	WITH Temp AS
	(	
		SELECT
			ROW_NUMBER() OVER (ORDER BY G.Code) AS RowNumber,
			G.*	
		FROM (SELECT DISTINCT
			a.GroupID,
			a.Code,
			a.[Description],
			ISNULL(a.GroupedAccountID, 0) AS GroupedAccountID,
			Case When d.GroupID is not null then 1 else 0 end HasStep
			FROM Legal_Groups a
				LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
				LEFT JOIN Account c ON b.AccountID = c.AccountID
				LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> 'R') d ON a.GroupID = d.GroupID
			WHERE  a.Status <> 'R' and c.DebtorID = @debtorID) G
	)

	SELECT * FROM Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
	
END
GO

-- 2008/10/13	[Binh Truong]	Change Message field datatype from varchar to nvarchar
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
CREATE TABLE dbo.Tmp_Messages
	(
	ID int NOT NULL IDENTITY (1, 1),
	ToEmployee int NOT NULL,
	FromEmployee int NOT NULL,
	FromName varchar(50) NOT NULL,
	DebtorID int NOT NULL,
	AccountID int NULL,
	DisplayOn smalldatetime NOT NULL,
	Message nvarchar(250) NOT NULL,
	EntryDate smalldatetime NOT NULL,
	Active bit NOT NULL,
	EmployeeRead bit NOT NULL
	)  ON [PRIMARY]
GO
SET IDENTITY_INSERT dbo.Tmp_Messages ON
GO
IF EXISTS(SELECT * FROM dbo.Messages)
	 EXEC('INSERT INTO dbo.Tmp_Messages (ID, ToEmployee, FromEmployee, FromName, DebtorID, AccountID, DisplayOn, Message, EntryDate, Active, EmployeeRead)
		SELECT ID, ToEmployee, FromEmployee, FromName, DebtorID, AccountID, DisplayOn, CONVERT(nvarchar(250), Message), EntryDate, Active, EmployeeRead FROM dbo.Messages WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_Messages OFF
GO
DROP TABLE dbo.Messages
GO
EXECUTE sp_rename N'dbo.Tmp_Messages', N'Messages', 'OBJECT' 
GO
COMMIT
GO

/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 10/13/2008 17:27:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 10/13/2008 17:27:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Minh Dam
-- Create date: 15/08/2008
-- Description:	
-- =============================================				
CREATE PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
	@CollateralID int,
	@ClientID int = 0,
	@CollateralTypeID int = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @CollateralID <> 0 AND @CollateralTypeID IS NULL
		SELECT @CollateralTypeID = CollateralType FROM Collateral WHERE ID = @CollateralID

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			b.[DataType],
			b.[MaxLength]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], [DisplayOrder]
		FROM CWX_Collateral_Dict
		WHERE Displayed = 1	AND (@ClientID = 0 OR ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID) AND (@CollateralTypeID = 0 OR ISNULL(CollateralTypeID, 0) = 0 OR CollateralTypeID = @CollateralTypeID)) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], c.[max_length] as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Collateral' and [Type]='U')
			AND (c.[name] LIKE 'CInt%' OR c.[name] LIKE 'CString%' OR c.[name] LIKE 'CDate%' OR c.[name] LIKE 'CMoney%')
		) b 
		ON a.[FieldName] = b.[ColumnName]
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'ID,AccountID,HostCollateralID,EmployeeID,NextActionDate,Image,ImageFileName,'
	SET @FieldNameList = @FieldNameList + 
		'(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6) IS NOT NULL THEN CollateralType ELSE 0 END) AS CollateralType,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7) IS NOT NULL THEN CollateralStage ELSE 0 END) AS CollateralStage,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2) IS NOT NULL THEN NextAction ELSE 0 END) AS NextAction'
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM Collateral WHERE ID = ' + Cast(@CollateralID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup
END
GO
-- Script closed.
