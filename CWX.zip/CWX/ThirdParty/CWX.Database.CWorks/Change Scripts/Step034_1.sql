﻿--Script 3.6.5 Build 2

/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetColumnName]    Script Date: 04/09/2009 16:30:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_Employee_GetColumnName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Employee_GetColumnName]
GO

CREATE PROCEDURE [dbo].[CWX_Employee_GetColumnName]
	-- Add the parameters for the stored procedure here	
	@tablename varchar(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @columname varchar(20)
    DECLARE @count int
	SELECT @count = count(*) FROM INFORMATION_SCHEMA.COLUMNS
	WHERE TABLE_NAME = @tablename AND COLUMN_NAME = 'ACCOUNTID'

	IF @count > 0
		BEGIN
			Select 'AccountID' as name
		END
	else
		BEGIN
			Select top 1 name  from
			(SELECT IsIdentity=COLUMNPROPERTY(id, name, 'IsIdentity'),name, id
					FROM syscolumns WHERE OBJECT_NAME(id) = @tablename) as s
			where isIdentity = 1
		END

	
END

GO