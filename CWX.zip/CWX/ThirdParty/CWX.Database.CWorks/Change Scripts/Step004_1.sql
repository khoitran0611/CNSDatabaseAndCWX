-- Tuan Luong: Store Procedure [dbo].[CWX_InformationTable_Search] was moved to step3.sql

--Alter table
INSERT INTO InformationTable VALUES(1, 0, 0, '', 'UserSignOn', '', 'True')
INSERT INTO InformationTable VALUES(1, 1, 0, '', 'RelationshipCollection', '', 'True')
INSERT INTO InformationTable VALUES(1, 2, 0, '', 'DateFormat', '', 'M/d/yyyy')
INSERT INTO InformationTable VALUES(1, 3, 0, '', 'TimeFormat', '', 'h:mm:ss tt')
INSERT INTO InformationTable VALUES(1, 4, 0, '', 'CurrencySymbol', '', '$')
INSERT INTO InformationTable VALUES(1, 5, 0, '', 'NoDigitsAfterDecimal', '', '2')
INSERT INTO InformationTable VALUES(1, 6, 0, '', 'PositiveCurrencyFormat', '', '$1.1')
INSERT INTO InformationTable VALUES(1, 7, 0, '', 'DigitGroupingSymbol', '', ',')
INSERT INTO InformationTable VALUES(1, 8, 0, '', 'NegativeCurrencyFormat', '', '($1.1)')
INSERT INTO InformationTable VALUES(1, 9, 0, '', 'DigitGrouping', '', '123456789')
INSERT INTO InformationTable VALUES(1, 10, 0, '', 'DecimalSymbol', '', '.')


ALTER TABLE AccountCodeMaster ADD Status char(1) NULL CONSTRAINT AccountCodeMasterStatusDefault DEFAULT 'A' WITH VALUES
GO
UPDATE AccountCodeMaster SET Status='A'

ALTER TABLE InformationTable ADD Status char(1) NULL CONSTRAINT InformationTableStatusDefault DEFAULT 'A' WITH VALUES
GO
UPDATE InformationTable SET Status='A'

--Update SPs
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_UpdateList]    Script Date: 02/18/2008 13:27:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_UpdateList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProductSetting_UpdateList]

GO
/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_UpdateList]    Script Date: 02/18/2008 13:27:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Jan 24, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ProductSetting_UpdateList] 
	-- Add the parameters for the stored procedure here
	@ProductSettings xml
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE ProductSettingCrsr CURSOR FOR
    SELECT
		ParamValues.ProductSetting.value('./@InfoID','int') AS InfoID,
		ParamValues.ProductSetting.value('./@InfoType','int') AS InfoType,
		ParamValues.ProductSetting.value('./@InfoSubType','int') AS InfoSubType,
		ParamValues.ProductSetting.value('./@InfoKey','varchar(50)') AS InfoKey,
		ParamValues.ProductSetting.value('./@Value','varchar(50)') AS [Value]
	FROM
		@ProductSettings.nodes('/ProductSettings/ProductSetting') as ParamValues(ProductSetting) 

	OPEN ProductSettingCrsr

	DECLARE @InfoID int
	DECLARE @InfoType int
	DECLARE @InfoSubType int
	DECLARE @InfoKey varchar(50)
	DECLARE @Value varchar(50)

	FETCH NEXT FROM ProductSettingCrsr
	INTO @InfoID, @InfoType, @InfoSubType, @InfoKey, @Value

	WHILE @@FETCH_STATUS = 0
	BEGIN
		UPDATE InformationTable
		SET
			[Value] = @Value
		WHERE
			(InfoID = @InfoID)
			AND (InfoType = @InfoType)
			AND (InfoSubType = @InfoSubType)
			AND (InfoKey = @InfoKey)

		IF( @@ERROR <> 0)
			GOTO Cleanup

		FETCH NEXT FROM ProductSettingCrsr
		INTO @InfoID, @InfoType, @InfoSubType, @InfoKey, @Value
	END

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE ProductSettingCrsr
	DEALLOCATE ProductSettingCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_Search]    Script Date: 02/15/2008 13:20:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_Search]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_Search]    Script Date: 02/15/2008 13:21:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Dec 15, 2007
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_Search]
	@EmployeeName varchar(50) = '',
	@Department int = 0,
	@RoleID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT
		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber,
		e.EmployeeID,
		e.UserID,
		e.EmployeeName,
		ISNULL(d.DeptDesc, '') AS Department,
		e.RoleID,
		--r.[Role],
		e.Description,
		CASE e.Supervisor WHEN 1 THEN 'Y' ELSE '' END AS Supervisor
	INTO #Temp
	FROM Employee e
	LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID AND (d.Status <> 'R')
	WHERE
		(e.EmployeeName LIKE ('%' + @EmployeeName + '%'))
		AND (@Department = 0 OR e.Department = @Department)
		AND (@RoleID = 0 OR e.RoleID = @RoleID)
		AND (ISNULL(EmployeeStatus, '') <> 'R')

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountCodeMaster_SoftDeleteAll]    Script Date: 02/15/2008 13:21:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountCodeMaster_SoftDeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountCodeMaster_SoftDeleteAll]

GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountCodeMaster_SoftDeleteAll]    Script Date: 02/15/2008 13:21:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Jan 31, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountCodeMaster_SoftDeleteAll] 
	@CodeType int
AS
BEGIN
	UPDATE
		AccountCodeMaster
	SET
		Status = 'R'
	WHERE
		CodeType = @CodeType
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Document_CanDelete]    Script Date: 02/18/2008 11:37:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Document_CanDelete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Document_CanDelete]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Document_CanDelete]    Script Date: 02/18/2008 11:37:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 18, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Document_CanDelete] 
	-- Add the parameters for the stored procedure here
	@DocumentID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @CanDelete bit
    IF EXISTS(SELECT ID FROM RuleTable WHERE Letter = @DocumentID)
		SET @CanDelete = 0
	ELSE
		SET @CanDelete = 1
	SELECT @CanDelete
END

