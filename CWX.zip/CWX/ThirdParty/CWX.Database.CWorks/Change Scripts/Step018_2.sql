-- Script is applied on version 2.4.5 

-- Scripts 2.4.5:

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalAgent]    Script Date: 08/14/2008 17:15:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalAgent]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByLegalAgent]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalAgent]    Script Date: 08/14/2008 17:15:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalAgent]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/04/21	[Sathya]		Init version.
--	2008/08/14	[Binh Truong]	la.Status = ''A''  >>>  la.Status <> ''R''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalAgent] 
	@AgentId int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
		INNER JOIN Legal_Agents la ON la.Status <> ''R'' and la.AgentID = lg.AgentID
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '''') = '''' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '','')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
			INNER JOIN Legal_Agents la ON la.Status <> ''R'' and la.AgentID = lg.AgentID
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '''') = '''' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '','')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 08/14/2008 17:18:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalForward]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByLegalForward]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 08/14/2008 17:18:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalForward]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/04/21	[LongNguyen]	Init version.
--	2008/08/14	[Binh Truong]	ls.Status = ''A''  >>>  ls.Status <> ''R''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalForward] 
	@SolicitorID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
		INNER JOIN Legal_Solicitors ls ON ls.Status <> ''R'' and ls.SolicitorID = lg.SolicitorID
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '''') = '''' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '','')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
			INNER JOIN Legal_Solicitors ls ON ls.Status <> ''R'' and ls.SolicitorID = lg.SolicitorID
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '''') = '''' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '','')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END


set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountCodeMaster_DeleteAll]    Script Date: 08/14/2008 17:21:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountCodeMaster_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountCodeMaster_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountCodeMaster_DeleteAll]    Script Date: 08/14/2008 17:21:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountCodeMaster_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in AccountCodeMaster Table
-- Parameters: 
--  @CodeType: Account code type
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- History:
--	2008/02/13	[Binh Truong]	Init version.
--	2008/08/14	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE CWX_AccountCodeMaster_DeleteAll
	@CodeType int,
	@Type char(1) = ''S''
AS
BEGIN
	SET NOCOUNT ON
	IF UPPER(@Type) = ''S''
	BEGIN
		UPDATE AccountCodeMaster
		SET [Status] = ''R''
		WHERE CodeType = @CodeType AND [Status] <> ''R''
	END
	ELSE IF UPPER(@Type) = ''P''
	BEGIN    
		DELETE AccountCodeMaster
		WHERE CodeType = @CodeType
	END
	
	SET NOCOUNT OFF
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AgencyDefinedMaster_DeleteAll]    Script Date: 08/14/2008 17:23:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AgencyDefinedMaster_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AgencyDefinedMaster_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AgencyDefinedMaster_DeleteAll]    Script Date: 08/14/2008 17:23:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AgencyDefinedMaster_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in AgencyDefinedMaster Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- History:
--	2008/01/30	[Tuan Luong]	Init version.
--	2008/08/14	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE CWX_AgencyDefinedMaster_DeleteAll 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE AgencyDefinedMaster
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE AgencyDefinedMaster
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_ClientInformation_Attorney_DeleteAll]    Script Date: 08/14/2008 17:25:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_Attorney_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientInformation_Attorney_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientInformation_Attorney_DeleteAll]    Script Date: 08/14/2008 17:25:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_Attorney_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =====================================================
-- Description:	Delete all attorney firm (Referral = 1)
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- History:
--	2008/01/26	[Tuan Luong]	Init version.
--	2008/08/14	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =====================================================
CREATE PROCEDURE CWX_ClientInformation_Attorney_DeleteAll 	
	@Referral int = 1,
	@Type char(1) = ''S''	
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Type) = ''S''
	BEGIN
		UPDATE ClientInformation
		SET [Status] = ''R''
		WHERE [Status] <> ''R'' AND Referral = @Referral
	END
	ELSE IF UPPER(@Type) = ''P''
	BEGIN    
		DELETE ClientInformation
		WHERE Referral = @Referral
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Department_DeleteAll]    Script Date: 08/14/2008 17:26:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Department_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Department_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Department_DeleteAll]    Script Date: 08/14/2008 17:26:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Department_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in EmployeeDepartment Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- History:
--	2008/02/05	[Binh Truong]	Init version.
--	2008/08/14	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE CWX_Department_DeleteAll 	
	@Type char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Type) = ''S''
	BEGIN
		UPDATE EmployeeDepartment
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Type) = ''P''
	BEGIN    
		DELETE EmployeeDepartment
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetTotalEmployee]    Script Date: 08/14/2008 17:30:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetTotalEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetTotalEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetTotalEmployee]    Script Date: 08/14/2008 17:30:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetTotalEmployee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	
-- History:
--	2008/04/17	[Binh Truong]	Init version.
--	2008/08/14	[Binh Truong]	EmployeeStatus = ''A''  >>>  EmployeeStatus <> ''R''
-- =============================================================
CREATE PROCEDURE CWX_Employee_GetTotalEmployee
AS
BEGIN
	SET NOCOUNT ON;
	SELECT COUNT(*) FROM Employee WHERE EmployeeStatus <> ''R''
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetWorkDetails]    Script Date: 08/14/2008 17:52:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetWorkDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetWorkDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetWorkDetails]    Script Date: 08/14/2008 17:52:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetWorkDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Get employee working details.
-- History:
--	2008/08/13	[Binh Truong]	Init version.
--	2008/08/14	[Binh Truong]	E.EmployeeStatus = ''A''  >>> E.EmployeeStatus <> ''R''
-- =============================================================
CREATE PROCEDURE CWX_Employee_GetWorkDetails
	@SupervisorID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;
                      
	DECLARE @EmployeeID int
	DECLARE @EmployeeName varchar(50)
	DECLARE @RowCount int
	DECLARE @RecordIndex int
	
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END
	
	DECLARE @TempTableVar table(
			EmployeeID			int,
			EmployeeName		varchar(50),
			AccountIDViewing	int,
			ViewedNo			int
		);
		
	SELECT	@RowCount = COUNT(DISTINCT E.EmployeeID)
	FROM	AccountActions as A, Employee as E
	WHERE	A.CompletedBy = E.EmployeeID AND
			(@SupervisorID = 0 OR E.SuperVisorId = @SupervisorID) AND
			E.EmployeeStatus <> ''R'' AND A.ActionID = 8 AND 
			CONVERT(varchar(10), A.DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)

	DECLARE AccountActions_cursor CURSOR DYNAMIC READ_ONLY FOR
	SELECT	DISTINCT E.EmployeeID, E.EmployeeName 
	FROM	AccountActions as A, Employee as E
	WHERE	A.CompletedBy = E.EmployeeID AND
			(@SupervisorID = 0 OR E.SuperVisorId = @SupervisorID) AND
			E.EmployeeStatus <> ''R'' AND A.ActionID = 8 AND 
			CONVERT(varchar(10), A.DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
	ORDER BY E.EmployeeID

	OPEN AccountActions_cursor
	
	FETCH RELATIVE @BeginIndex FROM AccountActions_cursor 
	INTO @EmployeeID, @EmployeeName

	WHILE @PageSize > 0 AND @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO @TempTableVar
		SELECT	TOP 1	@EmployeeID, 
						@EmployeeName,
						AccountID,
						(SELECT	COUNT(CompletedBy)
						FROM	AccountActions
						WHERE   CompletedBy = @EmployeeID AND ActionID = 8 AND (CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121))) as ViewedNo
		FROM	AccountActions
		WHERE CompletedBy = @EmployeeID
		ORDER BY DateCompleted DESC
		
		FETCH NEXT FROM AccountActions_cursor
		INTO @EmployeeID, @EmployeeName
		
		SET @PageSize = @PageSize - 1
	END
	
	CLOSE AccountActions_cursor
	DEALLOCATE AccountActions_cursor

	SELECT * FROM @TempTableVar
	
	RETURN @RowCount
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_LoadCollectorReferral]    Script Date: 08/14/2008 18:05:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_LoadCollectorReferral]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_LoadCollectorReferral]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_LoadCollectorReferral]    Script Date: 08/14/2008 18:05:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_LoadCollectorReferral]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Khoa Duong
-- Create date: May 5, 2008
-- Description:	Alter Store Procedure Get collector or referral for main page
-- History:
--	2008/05/05	[Khoa Duong]	Init version.
--	2008/08/14	[Binh Truong]	EmployeeStatus = ''A''  >>>  EmployeeStatus <> ''R''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_LoadCollectorReferral]
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@LoadAll bit = 1,
	@EmployeeName varchar(50) = '''',
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;	

	DECLARE @RowCount int
	CREATE TABLE #Temp
	(
		RowNumber int,	
		EmployeeID int,
		EmployeeName varchar(50),
		UserID		varchar(10)
	)

    -- Insert statements for procedure here
	IF (@LoadAll = 1)	-- collector
	BEGIN
		IF @EmployeeName = ''''	-- No employee name input
		BEGIN
			INSERT		INTO #Temp
				SELECT		ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber, EmployeeID, EmployeeName, UserID		
				FROM		[dbo].[Employee]
				WHERE		EmployeeStatus <> ''R''
				ORDER BY	employeename		
		END
		ELSE
		BEGIN
			INSERT		INTO #Temp
				SELECT		ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber, EmployeeID, EmployeeName, UserID		
				FROM		[dbo].[Employee]
				WHERE		EmployeeStatus <> ''R'' AND EmployeeName LIKE (''%'' + @EmployeeName + ''%'')
				ORDER BY	employeename			
		END	
		
	END
	ELSE	-- referral case
	BEGIN
		DECLARE @Supervisor bit

		SELECT	@Supervisor = Supervisor	
		FROM	[dbo].[Employee]		
		WHERE	EmployeeID = @EmployeeID

		IF @EmployeeName = ''''	-- No employee name input
		BEGIN
			IF @Supervisor = 1	-- Input Employee is the supervisor
			BEGIN
				INSERT		INTO #Temp
					SELECT		ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber, EmployeeID, EmployeeName, UserID
					FROM		[dbo].[Employee]
					WHERE		EmployeeStatus <> ''R'' AND EmployeeID <> @EmployeeID									

				
			END
			ELSE
			BEGIN
				INSERT INTO #Temp
					SELECT		ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber,EmployeeID, EmployeeName, UserID					
					FROM		[dbo].[Employee]
					WHERE		EmployeeStatus <> ''R'' AND EmployeeID <> @EmployeeID														
								AND Supervisor = 1
			END
		END						
		ELSE	-- WITH EmployeeName input
		BEGIN
			IF @Supervisor = 1	-- Input Employee is the supervisor
			BEGIN
				INSERT		INTO #Temp
					SELECT		ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber, EmployeeID, EmployeeName, UserID				
					FROM		[dbo].[Employee]
					WHERE		EmployeeStatus <> ''R'' AND EmployeeID <> @EmployeeID AND EmployeeName LIKE (''%'' + @EmployeeName + ''%'')									
			END
			ELSE
			BEGIN
				INSERT		INTO #Temp				
					SELECT		ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber, EmployeeID, EmployeeName, UserID				
					FROM		[dbo].[Employee]
					WHERE		EmployeeStatus <> ''R'' AND EmployeeID <> @EmployeeID														
								AND Supervisor = 1   AND EmployeeID <> @EmployeeID AND EmployeeName LIKE (''%'' + @EmployeeName + ''%'')
			END			
		END
		
	END	

	SELECT @RowCount = @@ROWCOUNT

	IF @PageSize <= 0
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	RETURN @RowCount	
	
END

' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]    Script Date: 08/14/2008 18:07:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetEmployeePortfolio]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]    Script Date: 08/14/2008 18:07:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetEmployeePortfolio]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get employee portfolio.
-- Parameters: 
--		0: Queue Active
--		Other number: All accounts
-- History:
--		2008/04/17	[Binh Truong]	Init version.
--		2008/05/15	[Binh Truong]	Cast BillBalance field to decimal(18,2) to fix Arithmetic overflow error converting expression.
--		2008/07/10	[Binh Truong]	Fix BillBalance NULL returned values.
--		2008/08/14	[Binh Truong]	EmployeeStatus = ''A''  >>>  EmployeeStatus <> ''R'' 
-- =============================================
CREATE PROCEDURE [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]
	@PorfolioType smallint = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @TotalAccStatement NVARCHAR(1000)
	DECLARE @TotalDollarValueStatement NVARCHAR(1000)
	DECLARE @MainStatement NVARCHAR(4000)
	DECLARE @RowCount INT
	
	SET @Conditions = ''''	

	IF @PorfolioType = 0		
		SET @Conditions = ''
			AND SystemStatusId = 5 
			AND AgencyStatusID <> 2 
			AND QueueDate <= GETDATE()
			''
	
	DECLARE @ParmDefinition NVARCHAR(500);
	DECLARE @TotalAccount INT;
	DECLARE @TotalDollarValue DECIMAL(18,2);

	SET @TotalAccStatement = N''SELECT @TotalAccountOUT = COUNT(*) FROM Account WHERE (1=1) '';
	SET @TotalAccStatement = @TotalAccStatement + @Conditions
	SET @ParmDefinition = N''@TotalAccountOUT INT OUTPUT'';

	EXECUTE sp_executesql @TotalAccStatement, @ParmDefinition, @TotalAccountOUT=@TotalAccount OUTPUT;

	SET @TotalDollarValueStatement = N''SELECT @TotalDollarValueOUT = SUM(cast(ISNULL(BillBalance,0) as decimal)) FROM Account WHERE (1=1)'';
	SET @TotalDollarValueStatement = @TotalDollarValueStatement + @Conditions
	SET @ParmDefinition = N''@TotalDollarValueOUT DECIMAL(18,2) OUTPUT'';

	EXECUTE sp_executesql @TotalDollarValueStatement, @ParmDefinition, @TotalDollarValueOUT=@TotalDollarValue OUTPUT;
	
	--Build the MainStatement
	SET @MainStatement = ''INSERT INTO #Temp SELECT Employee.EmployeeID, Employee.EmployeeName, ''

	SET @MainStatement = @MainStatement + '' (SELECT COUNT(EmployeeID) AS Expr1
						FROM          Account AS AT
						WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalAccount, ''
	
	SET @MainStatement = @MainStatement + '' (SELECT CAST(((COUNT(EmployeeID) * 100) / CAST('' + CAST(@TotalAccount AS VARCHAR(30)) + '' AS DECIMAL(18,2))) AS DECIMAL(18,2)) AS Expr1
						FROM          Account AS AT
						WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalAccountPercent, ''
    
	SET @MainStatement = @MainStatement + '' (SELECT     CAST(SUM(cast(ISNULL(BillBalance,0) as decimal)) as decimal(18,2)) 
                    FROM        Account AS AT
                    WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalDollarValue, ''

	SET @MainStatement = @MainStatement + '' (SELECT     CAST(SUM(cast(ISNULL(BillBalance,0) as decimal)) as decimal(18,2)) * 100 / CAST('' + CAST(@TotalDollarValue AS VARCHAR(30)) + ''AS DECIMAL(18,2)) AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalDollarValuePercent, ''

	SET @MainStatement = @MainStatement + '' (SELECT     COUNT(TempEmployeeID) AS Expr1
					FROM          Account AS AT
					WHERE      (AT.TempEmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.TempEmployeeID) AS TotalAccountTemp, '' 

	SET @MainStatement = @MainStatement + '' (SELECT     SUM(cast(ISNULL(BillBalance,0) as decimal)) AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.TempEmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.TempEmployeeID) AS TotalDollarValueAccountTemp ''

	SET @MainStatement = @MainStatement +	'' FROM  Employee WHERE EmployeeStatus <> ''''R'''''' 

	CREATE TABLE #Temp
	(
		Idx int IDENTITY,
		EmployeeID int,
		EmployeeName varchar(50),
		TotalAccount int,
		TotalAccountPercent DECIMAL(18,0),
		TotalDollarValue DECIMAL(18,2),
		TotalDollarValuePercent DECIMAL(18,0),
		TotalAccountTemp int,
		TotalDollarValueAccountTemp DECIMAL(18,2)		
	)

	EXEC dbo.sp_executesql @MainStatement
	
	SELECT @RowCount = Count(Idx) FROM #Temp

	SELECT  EmployeeName,
			EmployeeID,
			ISNULL(TotalAccount, 0) AS TotalAccount,
			CAST(ISNULL(TotalAccountPercent, 0) as varchar(50)) AS TotalAccountPercent,
			ISNULL(TotalDollarValue, 0) AS TotalDollarValue,
			CAST(ISNULL(TotalDollarValuePercent, 0) as varchar(50)) AS TotalDollarValuePercent,
			ISNULL(TotalAccountTemp, 0) AS TotalAccountTemp,
			ISNULL(TotalDollarValueAccountTemp, 0) AS TotalDollarValueAccountTemp
			
	FROM #Temp WHERE Idx between (@PageIndex)*@PageSize + 1 and (@PageIndex + 1)*@PageSize

	DROP TABLE #Temp
	
	RETURN @RowCount
END


' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]    Script Date: 08/14/2008 18:08:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]    Script Date: 08/14/2008 18:08:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Get total active account and bill balance of collector
-- Parameters: 
--	@PorfolioType	0: Queue Active
--					Other number: All accounts
-- History:
--	2008/04/17	[Binh Truong]	Init version.
--	2008/04/23	[Binh Truong]	Cast BillBalance field to decimal to fix Arithmetic overflow error converting expression.
--	2008/07/10	[Binh Truong]	Fix NULL returned values.
--	2008/08/14	[Binh Truong]	EmployeeStatus = ''A''  >>>  EmployeeStatus <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]
	@PorfolioType AS SMALLINT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Select NVARCHAR(1000)
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @Statement NVARCHAR(2000)
	DECLARE @Parms NVARCHAR(500)
	
	SET @Conditions = '' WHERE (Employee.EmployeeStatus <> ''''R'''') ''	
	
	SET @Select = ''
		SELECT	COUNT(Account.AccountID) AS TotalAccount,
				ISNULL(SUM(CAST(Account.BillBalance as decimal)),0) as TotalDollarValue 
		FROM         Account INNER JOIN
                      Employee ON Account.EmployeeID = Employee.EmployeeID     
		'' 		
		
	IF @PorfolioType = 0		
		SET @Conditions = @Conditions + ''
					AND SystemStatusId = 5 
					AND AgencyStatusID <> 2 
					AND QueueDate <= GETDATE()
			''
		
	SET @Statement = @Select + @Conditions
	
	EXEC dbo.sp_executesql @Statement
		
	SET @Select = ''
		SELECT	COUNT(Account.TempEmployeeID ) AS TotalTempAccount,
				ISNULL(SUM(CAST(BillBalance as decimal)),0) as TotalTempDollarValue 
		FROM         Account INNER JOIN
                      Employee ON Account.TempEmployeeID = Employee.EmployeeID     
		'' 		
		
	SET @Statement = @Select + @Conditions
	
	EXEC dbo.sp_executesql @Statement
	
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_Search]    Script Date: 08/15/2008 09:30:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_InformationTable_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_Search]    Script Date: 08/15/2008 09:30:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_Search]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	
-- History:
--	2008/01/23	[Binh Truong]	Init version.
--	2008/08/15	[Binh Truong]	Status=''A'' >>> Status<>''R''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_InformationTable_Search]
	@InfoID INT = NULL, 
	@InfoType INT = NULL,
	@InfoSubType INT = NULL,
	@InfoKey VARCHAR(50) = NULL,
	@OrderByClause VARCHAR(200),
	@PageSize INT = 10,
	@PageIndex INT	 = 0
AS

-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON	

DECLARE @StartRow INT
DECLARE @EndRow INT	
DECLARE @SQL 	NVARCHAR(MAX)
DECLARE @parms 	NVARCHAR(1000)
DECLARE @TotalRow INT

IF @InfoKey = ''''
	SET @InfoKey = NULL

SET @StartRow = @PageIndex * @PageSize + 1
SET @EndRow = (@PageIndex + 1) * @PageSize

SET @SQL = N''
	SELECT	*, ROW_NUMBER() OVER (ORDER BY ''+@OrderByClause+'') AS RowNumber 
	INTO	#InformationTableTemp
	FROM	InformationTable
	WHERE	Status<>''''R''''
	''
IF @InfoID IS NOT NULL
	SET @SQL = @SQL + ''AND InfoID = @InfoID ''
IF @InfoType IS NOT NULL
	SET @SQL = @SQL + ''AND InfoType = @InfoType ''
IF @InfoSubType IS NOT NULL
	SET @SQL = @SQL + ''AND InfoSubType = @InfoSubType ''	
IF @InfoKey IS NOT NULL
	SET @SQL = @SQL + ''AND InfoKey = @InfoKey ''
	
SET @SQL = @SQL + N''SELECT @TotalRow = @@ROWCOUNT 
					SELECT * FROM #InformationTableTemp 
					WHERE RowNumber BETWEEN @StartRow AND @EndRow 
					DROP TABLE #InformationTableTemp 
					''
SET @parms = ''
	@InfoID INT = NULL, 
	@InfoType INT = NULL,
	@InfoSubType INT = NULL,
	@InfoKey VARCHAR(50) = NULL,
	@StartRow INT,
	@EndRow INT,
	@TotalRow INT OUTPUT
	''
EXECUTE sp_executesql @sql, @parms, 
			@InfoID, 
			@InfoType,
			@InfoSubType,
			@InfoKey,
			@StartRow,
			@EndRow,
			@TotalRow OUTPUT

SET NOCOUNT OFF

IF @TotalRow IS NULL
	RETURN 0
ELSE
	RETURN @TotalRow
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Languages_DeleteAll]    Script Date: 08/15/2008 09:33:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Languages_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Languages_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Languages_DeleteAll]    Script Date: 08/15/2008 09:33:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Languages_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Languages Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- History:
--	2008/02/15	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status = ''R''
-- =============================================================
CREATE PROCEDURE CWX_Languages_DeleteAll 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Languages
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Languages
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Legal_Countries_DeleteAll]    Script Date: 08/15/2008 09:34:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Countries_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Countries_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Countries_DeleteAll]    Script Date: 08/15/2008 09:34:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Countries_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Legal_Countries Table
-- Parameters: 
--	@Type: ''''S'''' - Soft delete
--		   ''''P'''' - Permanently delete
-- History:
--	2008/06/24	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_Countries_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_Countries
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_Countries
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Legal_Courts_DeleteAll]    Script Date: 08/15/2008 09:35:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Courts_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Courts_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Courts_DeleteAll]    Script Date: 08/15/2008 09:35:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Courts_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Legal_Courts Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- History:
--	2008/06/23	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_Courts_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_CommPoints
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
		
		UPDATE Legal_CommPointAddresses
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	
		UPDATE Legal_Courts
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_CommPoints
		
		DELETE Legal_CommPointAddresses
		
		DELETE Legal_Courts		
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Legal_Creditors_DeleteAll]    Script Date: 08/15/2008 09:37:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Creditors_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Creditors_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Creditors_DeleteAll]    Script Date: 08/15/2008 09:37:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Creditors_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Legal_Creditors Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- History:
--	2008/06/26	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_Creditors_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_Creditors
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_Creditors		
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Legal_CreditorTypes_DeleteAll]    Script Date: 08/15/2008 09:38:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_CreditorTypes_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_CreditorTypes_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_CreditorTypes_DeleteAll]    Script Date: 08/15/2008 09:38:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_CreditorTypes_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Legal_CreditorTypes Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- History:
--	2008/06/23	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_CreditorTypes_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_CreditorTypes
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_CreditorTypes		
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFieldTypes_DeleteAll]    Script Date: 08/15/2008 10:00:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_CustomFieldTypes_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_CustomFieldTypes_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFieldTypes_DeleteAll]    Script Date: 08/15/2008 10:00:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_CustomFieldTypes_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Legal_CustomFieldTypes Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- History:
--	2008/06/11	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_CustomFieldTypes_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_CustomFieldTypes
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_CustomFieldTypes
	END
END

' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Legal_DebtCauses_DeleteAll]    Script Date: 08/15/2008 10:01:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_DebtCauses_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_DebtCauses_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_DebtCauses_DeleteAll]    Script Date: 08/15/2008 10:01:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_DebtCauses_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Legal_DebtCauses Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- History:
--	2008/06/23	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_DebtCauses_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_DebtCauses
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_DebtCauses		
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupStepTypes_DeleteAll]    Script Date: 08/15/2008 10:02:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupStepTypes_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_GroupStepTypes_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupStepTypes_DeleteAll]    Script Date: 08/15/2008 10:02:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupStepTypes_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Legal_GroupStepTypes Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- History:
--	2008/06/12	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_GroupStepTypes_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_GroupStepTypes
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_GroupStepTypes
	END
END


' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Legal_Localities_DeleteAll]    Script Date: 08/15/2008 10:04:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Localities_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Localities_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Localities_DeleteAll]    Script Date: 08/15/2008 10:04:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Localities_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Legal_Localities Table
-- Parameters: 
--	@Type: ''''S'''' - Soft delete
--		   ''''P'''' - Permanently delete
-- History:
--	2008/06/13	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_Localities_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_Localities
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_Localities
	END
END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Regions_DeleteAll]    Script Date: 08/15/2008 10:07:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Regions_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Regions_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Regions_DeleteAll]    Script Date: 08/15/2008 10:07:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Regions_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Legal_Regions Table
-- Parameters: 
--	@Type: ''''S'''' - Soft delete
--		   ''''P'''' - Permanently delete
-- History:
--	2008/06/13	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_Regions_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_Regions
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_Regions
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Legal_RelationshipTypes_DeleteAll]    Script Date: 08/15/2008 10:06:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_RelationshipTypes_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_RelationshipTypes_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_RelationshipTypes_DeleteAll]    Script Date: 08/15/2008 10:06:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_RelationshipTypes_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Legal_RelationshipTypes Table
-- Parameters: 
--	@Type: ''''S'''' - Soft delete
--		   ''''P'''' - Permanently delete
-- History:
--	2008/06/24	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_RelationshipTypes_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_RelationshipTypes
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_RelationshipTypes
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Legal_SnapshotTypes_DeleteAll]    Script Date: 08/15/2008 10:08:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_SnapshotTypes_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_SnapshotTypes_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_SnapshotTypes_DeleteAll]    Script Date: 08/15/2008 10:08:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_SnapshotTypes_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Legal_SnapshotTypes Table
-- Parameters: 
--	@Type: ''''S'''' - Soft delete
--		   ''''P'''' - Permanently delete
-- History:
--	2008/06/24	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_SnapshotTypes_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_SnapshotTypes
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_SnapshotTypes
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Nationality_DeleteAll]    Script Date: 08/15/2008 10:10:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Nationality_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Nationality_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Nationality_DeleteAll]    Script Date: 08/15/2008 10:10:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Nationality_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in Languages Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- History:
--	2008/02/18	[Tuan Luong]	Init version.
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE CWX_Nationality_DeleteAll 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Nationality_Master
		SET [Status] = ''R''
		WHERE [Status] <> ''R''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Nationality_Master
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_TicketDefinition_DeleteAll]    Script Date: 08/15/2008 10:14:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketDefinition_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TicketDefinition_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TicketDefinition_DeleteAll]    Script Date: 08/15/2008 10:14:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketDefinition_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Delete all records in TicketDefinition Table
-- Parameters: 
--	@Type: ''''S'''' - Soft delete
--		   ''''P'''' - Permanently delete
-- History:
--	2008/08/15	[Binh Truong]	Status = ''A''  >>>  Status <> ''R''
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_TicketDefinition_DeleteAll]
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE TicketDefinition
		SET [Status] = ''R''
		WHERE [Status] <> ''R'' and TicketType <> ''S'' 
		  and TktDefID not in (Select DISTINCT TicketTypeID From Ticket)
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE TicketDefinition
		WHERE TicketType <> ''S'' and TktDefID not in (Select DISTINCT TicketTypeID From Ticket)
	END
END

' 
END
GO


/******  Script Closed. Go next: Step018_3  ******/