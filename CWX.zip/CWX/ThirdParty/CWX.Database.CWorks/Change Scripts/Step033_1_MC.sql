﻿-- Script is applied on version 3.6.6:

-- Start of Scripts 3.6.6: 
PRINT 'Start of Script 3.6.6 for MC'
GO
PRINT 'Creating MC Tables'
GO
/****** Object:  ForeignKey [FK_EmployeeGoals_Employee]    Script Date: 03/24/2009 13:50:40 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_EmployeeGoals_Employee]') AND parent_object_id = OBJECT_ID(N'[EmployeeGoals]'))
ALTER TABLE [EmployeeGoals] DROP CONSTRAINT [FK_EmployeeGoals_Employee]
GO
/****** Object:  Table [dbo].[EmployeeGoals]    Script Date: 03/24/2009 13:50:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[EmployeeGoals]') AND type in (N'U'))
DROP TABLE [EmployeeGoals]
GO
 /****** Object:  ForeignKey [FK_DataDictionary_id_DataDictionary_parentId]    Script Date: 03/23/2009 18:28:24 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_DataDictionary_id_DataDictionary_parentId]') AND parent_object_id = OBJECT_ID(N'[DataDictionary]'))
ALTER TABLE [DataDictionary] DROP CONSTRAINT [FK_DataDictionary_id_DataDictionary_parentId]
GO
/****** Object:  ForeignKey [FK_PortfolioViewDetails_portfolioViewId_PortfolioViews_id]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_PortfolioViewDetails_portfolioViewId_PortfolioViews_id]') AND parent_object_id = OBJECT_ID(N'[MC_PortfolioViewDetails]'))
ALTER TABLE [MC_PortfolioViewDetails] DROP CONSTRAINT [FK_PortfolioViewDetails_portfolioViewId_PortfolioViews_id]
GO
/****** Object:  ForeignKey [FK_MC_QueryColumns_queryId_MC_Queries_id]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_MC_QueryColumns_queryId_MC_Queries_id]') AND parent_object_id = OBJECT_ID(N'[MC_QueryColumns]'))
ALTER TABLE [MC_QueryColumns] DROP CONSTRAINT [FK_MC_QueryColumns_queryId_MC_Queries_id]
GO
/****** Object:  ForeignKey [FK_MC_QueryCriteria_queryId_MC_Queries_id]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_MC_QueryCriteria_queryId_MC_Queries_id]') AND parent_object_id = OBJECT_ID(N'[MC_QueryCriteria]'))
ALTER TABLE [MC_QueryCriteria] DROP CONSTRAINT [FK_MC_QueryCriteria_queryId_MC_Queries_id]
GO
/****** Object:  ForeignKey [FK_SecurityRolePermissions_permissionId_SecurityPermissions_id]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_SecurityRolePermissions_permissionId_SecurityPermissions_id]') AND parent_object_id = OBJECT_ID(N'[MC_SecurityRolePermissions]'))
ALTER TABLE [MC_SecurityRolePermissions] DROP CONSTRAINT [FK_SecurityRolePermissions_permissionId_SecurityPermissions_id]
GO
/****** Object:  ForeignKey [FK_SecurityRolePermissions_roleId_SecurityRoles_id]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_SecurityRolePermissions_roleId_SecurityRoles_id]') AND parent_object_id = OBJECT_ID(N'[MC_SecurityRolePermissions]'))
ALTER TABLE [MC_SecurityRolePermissions] DROP CONSTRAINT [FK_SecurityRolePermissions_roleId_SecurityRoles_id]
GO
/****** Object:  ForeignKey [FK_SecurityUserRoles_roleId_SecurityRoles_id]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_SecurityUserRoles_roleId_SecurityRoles_id]') AND parent_object_id = OBJECT_ID(N'[MC_SecurityUserRoles]'))
ALTER TABLE [MC_SecurityUserRoles] DROP CONSTRAINT [FK_SecurityUserRoles_roleId_SecurityRoles_id]
GO
/****** Object:  ForeignKey [FK_SecurityUserRoles_userId_Users_id]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_SecurityUserRoles_userId_Users_id]') AND parent_object_id = OBJECT_ID(N'[MC_SecurityUserRoles]'))
ALTER TABLE [MC_SecurityUserRoles] DROP CONSTRAINT [FK_SecurityUserRoles_userId_Users_id]
GO
/****** Object:  Check [CK_Identifiers_lastId]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_Identifiers_lastId]') AND parent_object_id = OBJECT_ID(N'[MC_Identifiers]'))
ALTER TABLE [MC_Identifiers] DROP CONSTRAINT [CK_Identifiers_lastId]
GO
/****** Object:  Table [dbo].[DataDictionary]    Script Date: 03/23/2009 18:28:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[DataDictionary]') AND type in (N'U'))
DROP TABLE [DataDictionary]
GO
/****** Object:  Table [dbo].[MC_Log]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_Log]') AND type in (N'U'))
DROP TABLE [MC_Log]
GO
/****** Object:  Table [dbo].[MC_ApplicationParameters]    Script Date: 03/23/2009 18:28:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_ApplicationParameters]') AND type in (N'U'))
DROP TABLE [MC_ApplicationParameters]
GO
/****** Object:  Table [dbo].[MC_Identifiers]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_Identifiers]') AND type in (N'U'))
DROP TABLE [MC_Identifiers]
GO
/****** Object:  Table [dbo].[MC_PromiseStatuses]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_PromiseStatuses]') AND type in (N'U'))
DROP TABLE [MC_PromiseStatuses]
GO
/****** Object:  Table [dbo].[MC_QueryColumns]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_QueryColumns]') AND type in (N'U'))
DROP TABLE [MC_QueryColumns]
GO
/****** Object:  Table [dbo].[MC_QueryCriteria]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_QueryCriteria]') AND type in (N'U'))
DROP TABLE [MC_QueryCriteria]
GO
/****** Object:  Table [dbo].[MC_SecurityRolePermissions]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_SecurityRolePermissions]') AND type in (N'U'))
DROP TABLE [MC_SecurityRolePermissions]
GO
/****** Object:  Table [dbo].[MC_SecurityUserRoles]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_SecurityUserRoles]') AND type in (N'U'))
DROP TABLE [MC_SecurityUserRoles]
GO
/****** Object:  Table [dbo].[MC_PortfolioViewDetails]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_PortfolioViewDetails]') AND type in (N'U'))
DROP TABLE [MC_PortfolioViewDetails]
GO
/****** Object:  Table [dbo].[MC_Queries]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_Queries]') AND type in (N'U'))
DROP TABLE [MC_Queries]
GO
/****** Object:  Table [dbo].[MC_SecurityPermissions]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_SecurityPermissions]') AND type in (N'U'))
DROP TABLE [MC_SecurityPermissions]
GO
/****** Object:  Table [dbo].[MC_SecurityRoles]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_SecurityRoles]') AND type in (N'U'))
DROP TABLE [MC_SecurityRoles]
GO
/****** Object:  Table [dbo].[MC_Users]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_Users]') AND type in (N'U'))
DROP TABLE [MC_Users]
GO
/****** Object:  Table [dbo].[MC_AddressTypes]    Script Date: 03/23/2009 18:28:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_AddressTypes]') AND type in (N'U'))
DROP TABLE [MC_AddressTypes]
GO
/****** Object:  Table [dbo].[MC_AvailableActions]    Script Date: 03/23/2009 18:28:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_AvailableActions]') AND type in (N'U'))
DROP TABLE [MC_AvailableActions]
GO
/****** Object:  Table [dbo].[MC_Buckets]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_Buckets]') AND type in (N'U'))
DROP TABLE [MC_Buckets]
GO
/****** Object:  Table [dbo].[MC_Cycles]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_Cycles]') AND type in (N'U'))
DROP TABLE [MC_Cycles]
GO
/****** Object:  Table [dbo].[MC_PortfolioViews]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_PortfolioViews]') AND type in (N'U'))
DROP TABLE [MC_PortfolioViews]
GO
/****** Object:  Table [dbo].[MC_PortfolioType]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_PortfolioType]') AND type in (N'U'))
DROP TABLE [MC_PortfolioType]
GO
/****** Object:  Table [dbo].[MC_LetterTypes]    Script Date: 03/23/2009 18:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_LetterTypes]') AND type in (N'U'))
DROP TABLE [MC_LetterTypes]
GO
/****** Object:  Table [dbo].[EmployeeGoals]    Script Date: 03/24/2009 13:50:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[EmployeeGoals]') AND type in (N'U'))
BEGIN
CREATE TABLE [EmployeeGoals](
	[GoalID] [int] IDENTITY(1,1) NOT NULL,
	[ActionID] [int] NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[GoalCount] [int] NOT NULL,
	[GoalAmount] [money] NOT NULL,
	[StartDate] [datetime] NULL,
 CONSTRAINT [PK_EmployeeGoals] PRIMARY KEY CLUSTERED 
(
	[GoalID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[MC_AvailableActions]    Script Date: 03/23/2009 18:20:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_AvailableActions]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_AvailableActions](
	[ActionID] [varchar](10) NOT NULL,
	[Description] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[MC_DataDictionary]    Script Date: 03/23/2009 18:20:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_DataDictionary]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_DataDictionary](
	[id] [int] NOT NULL,
	[parentId] [int] NOT NULL,
	[metaName] [nvarchar](50) NOT NULL,
	[physicalName] [nvarchar](50) NOT NULL,
	[caption] [nvarchar](50) NOT NULL,
	[itemType] [int] NOT NULL,
	[dotNetType] [nvarchar](50) NULL,
	[dbType] [nvarchar](50) NULL,
	[isPrimaryKey] [bit] NULL,
	[isRequired] [bit] NULL,
	[isSystem] [bit] NOT NULL,
	[isConcurrencyFlag] [bit] NULL,
	[defaultValue] [nvarchar](50) NULL,
	[lastModified] [datetime] NOT NULL CONSTRAINT [DF_MC_DataDictionary_lastModified]  DEFAULT (getdate()),
 CONSTRAINT [PK_MC_DataDictionary] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
 CONSTRAINT [UQ_MC_DataDictionary_metaName] UNIQUE NONCLUSTERED 
(
	[metaName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[MC_AddressTypes]    Script Date: 03/23/2009 18:20:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_AddressTypes]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_AddressTypes](
	[id] [int] NOT NULL,
	[name] [nvarchar](50) NOT NULL,
	[lastModified] [datetime] NOT NULL CONSTRAINT [DF_MC_AddressTypes_lastModified]  DEFAULT (getdate()),
 CONSTRAINT [PK_MC_AddressTypes] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[MC_LetterTypes]    Script Date: 03/23/2009 18:20:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_LetterTypes]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_LetterTypes](
	[id] [int] NOT NULL,
	[name] [nvarchar](50) NOT NULL,
	[lastModified] [datetime] NOT NULL CONSTRAINT [DF_MC_LetterTypes_lastModified]  DEFAULT (getdate()),
 CONSTRAINT [PK_MC_LetterTypes] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[MC_PortfolioViews]    Script Date: 03/24/2009 14:35:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_PortfolioViews]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_PortfolioViews](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](50) NOT NULL,
	[lastModified] [datetime] NOT NULL CONSTRAINT [DF_MC_PortfolioViews_lastModified]  DEFAULT (getdate()),
 CONSTRAINT [PK_PortfolioViews] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[MC_PromiseStatuses]    Script Date: 03/23/2009 18:20:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_PromiseStatuses]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_PromiseStatuses](
	[id] [int] NOT NULL,
	[name] [nvarchar](50) NOT NULL,
	[lastModified] [datetime] NOT NULL CONSTRAINT [DF_PromiseStatus_lastModified]  DEFAULT (getdate()),
 CONSTRAINT [PK_PromiseStatus] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[MC_Queries]    Script Date: 03/23/2009 18:20:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_Queries]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_Queries](
	[id] [int] NOT NULL,
	[name] [nvarchar](50) NOT NULL,
	[tableMetaName] [nvarchar](100) NOT NULL,
	[lastModified] [datetime] NOT NULL CONSTRAINT [DF_MC_Queries_lastModified]  DEFAULT (getdate()),
 CONSTRAINT [PK_Queries] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[MC_PortfolioType]    Script Date: 03/23/2009 18:20:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_PortfolioType]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_PortfolioType](
	[ID] [int] NOT NULL,
	[GroupByValue] [varchar](50) NOT NULL,
	[GroupByMetaName] [varchar](50) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[MC_PortfolioViewDetails]    Script Date: 03/23/2009 18:20:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_PortfolioViewDetails]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_PortfolioViewDetails](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[portfolioViewId] [int] NOT NULL,
	[groupByField] [nvarchar](50) NOT NULL,
	[sequence] [int] NOT NULL,
	[lastModified] [datetime] NOT NULL CONSTRAINT [DF_MC_PortfolioViewDetails_lastModified]  DEFAULT (getdate()),
 CONSTRAINT [PK_PortfolioViewDetails] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[MC_QueryColumns]    Script Date: 03/23/2009 18:20:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_QueryColumns]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_QueryColumns](
	[id] [int] NOT NULL,
	[sequence] [int] NOT NULL,
	[columnMetaName] [nvarchar](100) NOT NULL,
	[visible] [bit] NOT NULL,
	[sortType] [int] NOT NULL,
	[sortOrder] [int] NOT NULL,
	[queryId] [int] NOT NULL,
	[lastModified] [datetime] NOT NULL CONSTRAINT [DF_MC_QueryColumns_lastModified]  DEFAULT (getdate()),
 CONSTRAINT [PK_QueryColumns] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[MC_QueryCriteria]    Script Date: 03/23/2009 18:20:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_QueryCriteria]') AND type in (N'U'))
BEGIN
CREATE TABLE [MC_QueryCriteria](
	[id] [int] NOT NULL,
	[sequence] [int] NOT NULL,
	[logicalOperatorType] [int] NOT NULL,
	[columnMetaName] [nvarchar](100) NOT NULL,
	[comparisonOperatorType] [int] NOT NULL,
	[filterValue] [nvarchar](200) NOT NULL,
	[filterText] [nvarchar](200) NOT NULL,
	[queryId] [int] NOT NULL,
	[lastModified] [datetime] NOT NULL CONSTRAINT [DF_MC_QueryCriteria_lastModified]  DEFAULT (getdate()),
 CONSTRAINT [PK_QueryCriteria] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  ForeignKey [FK_EmployeeGoals_Employee]    Script Date: 03/24/2009 13:50:40 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_EmployeeGoals_Employee]') AND parent_object_id = OBJECT_ID(N'[EmployeeGoals]'))
ALTER TABLE [EmployeeGoals]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeGoals_Employee] FOREIGN KEY([EmployeeID])
REFERENCES [Employee] ([EmployeeID])
GO
ALTER TABLE [EmployeeGoals] CHECK CONSTRAINT [FK_EmployeeGoals_Employee]
GO
/****** Object:  ForeignKey [FK_MC_DataDictionary_id_MC_DataDictionary_parentId]    Script Date: 03/23/2009 18:20:19 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_MC_DataDictionary_id_MC_DataDictionary_parentId]') AND parent_object_id = OBJECT_ID(N'[MC_DataDictionary]'))
ALTER TABLE [MC_DataDictionary]  WITH NOCHECK ADD  CONSTRAINT [FK_MC_DataDictionary_id_MC_DataDictionary_parentId] FOREIGN KEY([parentId])
REFERENCES [MC_DataDictionary] ([id])
GO
ALTER TABLE [MC_DataDictionary] CHECK CONSTRAINT [FK_MC_DataDictionary_id_MC_DataDictionary_parentId]
GO
/****** Object:  ForeignKey [FK_PortfolioViewDetails_portfolioViewId_PortfolioViews_id]    Script Date: 03/23/2009 18:20:26 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_PortfolioViewDetails_portfolioViewId_PortfolioViews_id]') AND parent_object_id = OBJECT_ID(N'[MC_PortfolioViewDetails]'))
ALTER TABLE [MC_PortfolioViewDetails]  WITH NOCHECK ADD  CONSTRAINT [FK_PortfolioViewDetails_portfolioViewId_PortfolioViews_id] FOREIGN KEY([portfolioViewId])
REFERENCES [MC_PortfolioViews] ([id])
GO
ALTER TABLE [MC_PortfolioViewDetails] CHECK CONSTRAINT [FK_PortfolioViewDetails_portfolioViewId_PortfolioViews_id]
GO
/****** Object:  ForeignKey [FK_MC_QueryColumns_queryId_MC_Queries_id]    Script Date: 03/23/2009 18:20:33 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_MC_QueryColumns_queryId_MC_Queries_id]') AND parent_object_id = OBJECT_ID(N'[MC_QueryColumns]'))
ALTER TABLE [MC_QueryColumns]  WITH NOCHECK ADD  CONSTRAINT [FK_MC_QueryColumns_queryId_MC_Queries_id] FOREIGN KEY([queryId])
REFERENCES [MC_Queries] ([id])
GO
ALTER TABLE [MC_QueryColumns] CHECK CONSTRAINT [FK_MC_QueryColumns_queryId_MC_Queries_id]
GO
/****** Object:  ForeignKey [FK_MC_QueryCriteria_queryId_MC_Queries_id]    Script Date: 03/23/2009 18:20:37 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[FK_MC_QueryCriteria_queryId_MC_Queries_id]') AND parent_object_id = OBJECT_ID(N'[MC_QueryCriteria]'))
ALTER TABLE [MC_QueryCriteria]  WITH NOCHECK ADD  CONSTRAINT [FK_MC_QueryCriteria_queryId_MC_Queries_id] FOREIGN KEY([queryId])
REFERENCES [MC_Queries] ([id])
GO
ALTER TABLE [MC_QueryCriteria] CHECK CONSTRAINT [FK_MC_QueryCriteria_queryId_MC_Queries_id]
GO

PRINT 'Done Creating MC Tables'
GO


PRINT 'Creating VIEWS for MC'
GO

/****** Object:  View [dbo].[MC_AccountInformationView]    Script Date: 03/23/2009 19:10:48 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_AccountInformationView]'))
DROP VIEW [MC_AccountInformationView]
GO
/****** Object:  View [dbo].[MC_BillingInformationView]    Script Date: 03/23/2009 19:10:49 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_BillingInformationView]'))
DROP VIEW [MC_BillingInformationView]
GO
/****** Object:  View [dbo].[MC_BucketInformationView]    Script Date: 03/23/2009 19:10:49 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_BucketInformationView]'))
DROP VIEW [MC_BucketInformationView]
GO
/****** Object:  View [dbo].[MC_PromiseInformationView]    Script Date: 03/23/2009 19:10:51 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_PromiseInformationView]'))
DROP VIEW [MC_PromiseInformationView]
GO
/****** Object:  View [dbo].[MC_CallSummaryView]    Script Date: 03/23/2009 19:10:49 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_CallSummaryView]'))
DROP VIEW [MC_CallSummaryView]
GO
/****** Object:  View [dbo].[MC_DebtorPhonesView]    Script Date: 03/23/2009 19:10:50 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_DebtorPhonesView]'))
DROP VIEW [MC_DebtorPhonesView]
GO
/****** Object:  View [dbo].[MC_DebtorNotesView]    Script Date: 03/23/2009 19:10:50 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_DebtorNotesView]'))
DROP VIEW [MC_DebtorNotesView]
GO
/****** Object:  View [dbo].[MC_DebtorAddressView]    Script Date: 03/23/2009 19:10:49 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_DebtorAddressView]'))
DROP VIEW [MC_DebtorAddressView]
GO
/****** Object:  View [dbo].[MC_ContactInformationView]    Script Date: 03/23/2009 19:10:49 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_ContactInformationView]'))
DROP VIEW [MC_ContactInformationView]
GO
/****** Object:  View [dbo].[MC_DebtorInformationView]    Script Date: 03/23/2009 19:10:50 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_DebtorInformationView]'))
DROP VIEW [MC_DebtorInformationView]
GO
/****** Object:  View [dbo].[MC_AccountStatusView]    Script Date: 03/23/2009 19:10:48 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_AccountStatusView]'))
DROP VIEW [MC_AccountStatusView]
GO
/****** Object:  View [dbo].[MC_DebtorLinkedAccountsView]    Script Date: 03/23/2009 19:10:50 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_DebtorLinkedAccountsView]'))
DROP VIEW [MC_DebtorLinkedAccountsView]
GO
/****** Object:  View [dbo].[CWX_MC_AccountsView]    Script Date: 03/23/2009 19:10:48 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[CWX_MC_AccountsView]'))
DROP VIEW [CWX_MC_AccountsView]
GO
/****** Object:  View [dbo].[MC_PortfolioView]    Script Date: 03/23/2009 19:10:51 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_PortfolioView]'))
DROP VIEW [MC_PortfolioView]
GO
/****** Object:  View [dbo].[MC_AccountsView]    Script Date: 03/23/2009 19:10:49 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_AccountsView]'))
DROP VIEW [MC_AccountsView]
GO
/****** Object:  View [dbo].[MC_AccountLettersView]    Script Date: 03/23/2009 19:10:48 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_AccountLettersView]'))
DROP VIEW [MC_AccountLettersView]
GO
/****** Object:  View [dbo].[MC_DpdInformationView]    Script Date: 03/23/2009 19:10:50 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_DpdInformationView]'))
DROP VIEW [MC_DpdInformationView]
GO
/****** Object:  View [dbo].[MC_PaymentInformationView]    Script Date: 03/23/2009 19:10:51 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_PaymentInformationView]'))
DROP VIEW [MC_PaymentInformationView]
GO
/****** Object:  View [dbo].[MC_AccountDelinquencyView]    Script Date: 03/23/2009 19:10:48 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_AccountDelinquencyView]'))
DROP VIEW [MC_AccountDelinquencyView]
GO
/****** Object:  View [dbo].[MC_PhoneInformationView]    Script Date: 03/23/2009 19:10:51 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_PhoneInformationView]'))
DROP VIEW [MC_PhoneInformationView]
GO
/****** Object:  View [dbo].[MC_LetterHistoryView]    Script Date: 03/23/2009 19:10:51 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_LetterHistoryView]'))
DROP VIEW [MC_LetterHistoryView]
GO
/****** Object:  View [dbo].[MC_AccountsView]    Script Date: 03/23/2009 19:10:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_AccountsView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_AccountsView]
AS
SELECT     dbo.Account.AccountID, dbo.Account.ClientID AS ProductID, dbo.Account.MCode AS BucketID, CAST(dbo.Account.BillAmount AS decimal(38, 7)) AS BillAmount, 
                      dbo.Account.AgencyStatusID, dbo.Account.CCode AS CycleID, dbo.Account.DebtorID, dbo.Account.QueueDate, dbo.Account.AccountAge, dbo.Account.BillBalance, 
                      dbo.Account.InvoiceNumber, dbo.Account.DateOfService, dbo.Account.RoutinePayment, dbo.Account.WriteOffDate, dbo.Account.PAID, 
                      dbo.Account.MINIMUM_DUE AS MinimumDue, dbo.Account.TENOR, dbo.Account.EmployeeID, dbo.Employee.EmployeeName, 
                      ''Bucket'' + CAST(dbo.Account.MCode AS varchar(10)) AS BucketName, ''Cycle'' + CAST(dbo.Account.CCode AS varchar(10)) AS CycleName, 
                      dbo.ClientInformation.ClientName AS ProductName, dbo.AccountStatus.ShortDesc AS AccountStatus, dbo.AccountStatus.LongDesc AS AccountStatusLong, 
                      dbo.PersonInformation.SocialSecurityNumber, dbo.PersonInformation.Title, RTRIM(dbo.PersonInformation.FirstName) 
                      + '' '' + RTRIM(dbo.PersonInformation.MiddleName) + '' '' + RTRIM(dbo.PersonInformation.LastName) AS FullName, dbo.PersonInformation.Email, 
                      dbo.PersonInformation.HomePhone, dbo.PersonInformation.EmploymentPhone, dbo.PersonInformation.MobilPhone AS MobilePhone, dbo.Account.LastAllocationDate, 
                      dbo.Account.AllocRuleID AS AllocationRuleID, dbo.PersonInformation.PersonID, dbo.ClientInformation.Referral, dbo.Account.OAManaged AS AgencyManaged, 
                      dbo.Account.MaintainOfficer, dbo.PersonInformation.Employment, dbo.PersonInformation.DateOfBirth AS DebtorBirthDate, 
                      dbo.PersonInformation.PString3 AS DebtorMaritalStatus, dbo.PersonInformation.PString2 AS DebtorGender, dbo.EmployeeDepartment.DeptID AS DepartmentId, 
                      dbo.Account.SubmissionDate
FROM         dbo.Account LEFT OUTER JOIN
                      dbo.ClientInformation ON dbo.ClientInformation.ClientID = dbo.Account.ClientID LEFT OUTER JOIN
                      dbo.AccountStatus ON dbo.Account.AgencyStatusID = dbo.AccountStatus.AgencyStatus LEFT OUTER JOIN
                      dbo.AccountOther ON dbo.Account.AccountID = dbo.AccountOther.AccountID LEFT OUTER JOIN
                      dbo.DebtorInformation ON dbo.Account.DebtorID = dbo.DebtorInformation.DebtorID LEFT OUTER JOIN
                      dbo.PersonInformation ON dbo.DebtorInformation.PersonID = dbo.PersonInformation.PersonID LEFT OUTER JOIN
                      dbo.Employee ON dbo.Account.EmployeeID = dbo.Employee.EmployeeID LEFT OUTER JOIN
                      dbo.EmployeeDepartment ON dbo.Employee.Department = dbo.EmployeeDepartment.DeptID
'
GO
/****** Object:  View [dbo].[MC_AccountLettersView]    Script Date: 03/23/2009 19:10:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_AccountLettersView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_AccountLettersView]
AS
SELECT LetterDate, AddressType
FROM AccountLetter
'
GO
/****** Object:  View [dbo].[MC_AccountDelinquencyView]    Script Date: 03/23/2009 19:10:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_AccountDelinquencyView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_AccountDelinquencyView]
AS
SELECT AccountID, DelqSeq AS Sequence, EnterDate, ExitDate,
EnterAmt AS EnterAmount, EnterBal AS EnterBalance, 
(SELECT COUNT(*) FROM DelinquencyHistory WHERE AccountID = a.AccountId) AS Total
FROM DelinquencyHistory a
'
GO
/****** Object:  View [dbo].[MC_DpdInformationView]    Script Date: 03/23/2009 19:10:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_DpdInformationView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_DpdInformationView]
AS
SELECT
	accountId, Long5 AS dpd1, Long6 AS dpd2, Long7 AS dpd3, Long8 AS dpd4, Long9 AS dpd5, Long10 AS dpd6
FROM
	AccountOther
'
GO
/****** Object:  View [dbo].[MC_PaymentInformationView]    Script Date: 03/23/2009 19:10:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_PaymentInformationView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_PaymentInformationView]
AS
SELECT
	accountId, Date18 AS paymentDate, Money1 AS paymentAmount, Money20 AS savingAccountBalance, Money50 AS depositAmount
FROM
	AccountOther
'
GO
/****** Object:  View [dbo].[MC_PhoneInformationView]    Script Date: 03/23/2009 19:10:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_PhoneInformationView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_PhoneInformationView]
AS
SELECT x.PhoneType, x.PhoneNumber, x.PhoneExtension, x.Description
FROM MC_AccountsView v
INNER JOIN PersonPhone x
ON v.PersonID = x.PersonId
'
GO
/****** Object:  View [dbo].[MC_LetterHistoryView]    Script Date: 03/23/2009 19:10:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_LetterHistoryView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_LetterHistoryView]
AS
SELECT al.id, al.AccountId, dl.LetterDesc AS letterName, lt.name AS letterType, al.LetterDate, at.name AS addressType
FROM 
	AccountLetter al 
	LEFT OUTER JOIN DefineLetters dl ON al.LetterId = dl.LetterID
	LEFT OUTER JOIN MC_LetterTypes lt ON lt.id = dl.letterType
	LEFT OUTER JOIN MC_AddressTypes at ON at.id = al.AddressType
where dl.LetterId in (32, 33, 34, 35, 36)
'
GO
/****** Object:  View [dbo].[MC_PromiseInformationView]    Script Date: 03/23/2009 19:10:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_PromiseInformationView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_PromiseInformationView]
AS
SELECT
	a.accountId, (SELECT COUNT(*) FROM AccountPromise WHERE accountId = a.accountId) AS promiseTotal,
	(SELECT COUNT(*) FROM AccountPromise WHERE [status] IN (1,2) AND accountId = a.accountId) AS keptPromiseTotal,  
	(SELECT COUNT(*) FROM AccountPromise WHERE [status] = 3 AND accountId = a.accountId) AS brokenPromiseTotal,
	(SELECT COUNT(*) FROM AccountPromise WHERE [status] = 0 AND accountId = a.accountId) AS notDuePromiseTotal,
	(SELECT SUM(AmountPromised) FROM AccountPromise WHERE accountId = a.accountId) AS promiseTotalValue,
	(SELECT SUM(AmountPaid) FROM AccountPromise WHERE [status] IN (1,2) AND accountId = a.accountId) AS keptPromiseTotalValue,
	(SELECT SUM(AmountPromised) FROM AccountPromise WHERE [status] = 3 AND accountId = a.accountId) AS brokenPromiseTotalValue,
	(SELECT SUM(AmountPromised) FROM AccountPromise WHERE [status] = 0 AND accountId = a.accountId) AS notDuePromiseTotalValue,
	ISNULL(CAST((SELECT CAST(COUNT(*) AS DECIMAL(10,4)) FROM AccountPromise WHERE [status] IN (1,2) AND accountId = a.accountId)/NULLIF((SELECT CAST(COUNT(*) AS DECIMAL(10,4)) FROM AccountPromise WHERE accountId = a.accountId), 0)*100 AS INT), 0) AS keptRatio,
	ISNULL(CAST((SELECT CAST(COUNT(*) AS DECIMAL(10,4)) FROM AccountPromise WHERE [status] = 3 AND accountId = a.accountId)/NULLIF((SELECT CAST(COUNT(*) AS DECIMAL(10,4)) FROM AccountPromise WHERE accountId = a.accountId), 0)*100 AS INT), 0) AS brokenRatio,
	ISNULL(CAST((SELECT CAST(COUNT(*) AS DECIMAL(10,4)) FROM AccountPromise WHERE [status] = 0 AND accountId = a.accountId)/NULLIF((SELECT CAST(COUNT(*) AS DECIMAL(10,4)) FROM AccountPromise WHERE accountId = a.accountId), 0)*100 AS INT), 0) AS notdueRatio,
	(SELECT COUNT(*) FROM AccountActions WHERE accountId = a.accountId AND actionId IN (SELECT actionId FROM AvailableActions WHERE category = 2)) AS totalOutgoingCalls
FROM
	Account a
'
GO
/****** Object:  View [dbo].[MC_CallSummaryView]    Script Date: 03/23/2009 19:10:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_CallSummaryView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_CallSummaryView]
AS
SELECT
	a.accountId, (SELECT MAX(dateCompleted) FROM AccountActions WHERE accountId = a.accountId AND actionId IN (SELECT actionId FROM AvailableActions WHERE category IN (1,2) AND productivityId IN (1,2))) AS lastContactDate,
	(SELECT top 1 employeeName FROM AccountActions LEFT JOIN Employee ON completedBy = employeeId WHERE accountId = a.accountId AND actionId IN (SELECT actionId FROM AvailableActions WHERE category IN (1,2) AND productivityId IN (1,2)) ORDER BY dateCompleted DESC) AS lastContactBy,
	DATEDIFF(day, (SELECT MAX(dateCompleted) FROM AccountActions WHERE accountId = a.accountId AND actionId IN (SELECT actionId FROM AvailableActions WHERE category IN (1,2) AND productivityId IN (1,2))), getdate()) AS noOfActivityDays
FROM
	Account a
'
GO
/****** Object:  View [dbo].[MC_DebtorPhonesView]    Script Date: 03/23/2009 19:10:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_DebtorPhonesView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_DebtorPhonesView]
AS
SELECT 
	a.accountId, pp.phoneType AS phoneTypeId, pp.phoneType, pp.description, pp.phoneNumber, pp.phoneExtension,
	CASE WHEN pp.phoneStatus in (0, 1, 2, 3, 4) THEN ''true'' ELSE ''false'' END AS isGood
FROM 
	Account a 
	LEFT JOIN DebtorInformation di ON a.debtorId = di.debtorId
	LEFT JOIN PersonInformation pinfo ON di.personId = pinfo.personId
	LEFT JOIN PersonPhone pp ON pp.personId = pinfo.personId
'
GO
/****** Object:  View [dbo].[CWX_MC_AccountsView]    Script Date: 03/23/2009 19:10:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[CWX_MC_AccountsView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [CWX_MC_AccountsView]
AS
SELECT     dbo.Account.AccountID, dbo.Account.ClientID AS ProductID, dbo.Account.MCode AS BucketID, CAST(ISNULL(dbo.Account.BillAmount, 0) AS decimal(38, 7)) 
                      AS BillAmount, dbo.Account.CCode AS CycleID, dbo.Account.BillBalance, dbo.Account.EmployeeID, dbo.Employee.EmployeeName, 
                      ''Bucket '' + CAST(dbo.Account.MCode AS varchar(5)) AS BucketName, ''Cycle '' + CAST(dbo.Account.CCode AS varchar(5)) AS CycleName, 
                      dbo.ClientInformation.ClientName AS ProductName, dbo.AccountStatus.ShortDesc AS AccountStatus, RTRIM(dbo.PersonInformation.FirstName) 
                      + '' '' + RTRIM(dbo.PersonInformation.MiddleName) + '' '' + RTRIM(dbo.PersonInformation.LastName) AS FullName, dbo.Account.AllocRuleID AS AllocationRuleID, 
                      dbo.EmployeeDepartment.DeptID AS DepartmentID, dbo.EmployeeDepartment.DeptCode AS DepartmentName, dbo.Employee.SuperVisorId, 
                      Supervisor.EmployeeName AS SupervisorName, dbo.Account.AgencyStatusID AS AccountStatusID, dbo.Account.AllocRuleID AS AllocationRule
FROM         dbo.Employee AS Supervisor RIGHT OUTER JOIN
                      dbo.Employee ON Supervisor.EmployeeID = dbo.Employee.SuperVisorId RIGHT OUTER JOIN
                      dbo.Account LEFT OUTER JOIN
                      dbo.ClientInformation ON dbo.ClientInformation.ClientID = dbo.Account.ClientID LEFT OUTER JOIN
                      dbo.AccountStatus ON dbo.Account.AgencyStatusID = dbo.AccountStatus.AgencyStatus LEFT OUTER JOIN
                      dbo.DebtorInformation ON dbo.Account.DebtorID = dbo.DebtorInformation.DebtorID LEFT OUTER JOIN
                      dbo.PersonInformation ON dbo.DebtorInformation.PersonID = dbo.PersonInformation.PersonID ON 
                      dbo.Employee.EmployeeID = dbo.Account.EmployeeID LEFT OUTER JOIN
                      dbo.EmployeeDepartment ON dbo.Employee.Department = dbo.EmployeeDepartment.DeptID
'
GO

/****** Object:  View [dbo].[MC_AccountStatusView]    Script Date: 03/23/2009 19:10:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_AccountStatusView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_AccountStatusView]
AS
SELECT v.AccountId, i.EmployeeName, v.accountStatusLong, v.QueueDate
FROM MC_AccountsView v
INNER JOIN Employee i
ON v.EmployeeId = i.EmployeeId
'
GO
/****** Object:  View [dbo].[MC_DebtorLinkedAccountsView]    Script Date: 03/23/2009 19:10:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_DebtorLinkedAccountsView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_DebtorLinkedAccountsView]
AS
SELECT v.DebtorID, v.AccountID, v.ProductName, v.InvoiceNumber, v.EmployeeId, i.EmployeeName,
v.accountStatusLong AS AccountStatus, v.BillAmount, v.BillBalance
FROM MC_AccountsView v LEFT JOIN Employee i
ON v.EmployeeId = i.EmployeeID
'
GO
/****** Object:  View [dbo].[MC_DebtorNotesView]    Script Date: 03/23/2009 19:10:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_DebtorNotesView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_DebtorNotesView]
AS
SELECT v.NoteId, v.DebtorID, v.BillID as AccountId, v.employeeId,
i.EmployeeName, v.NoteDateTime, v.NoteType, v.NoteText
FROM NotesCurrent v
LEFT JOIN Employee i
ON v.EmployeeID = i.EmployeeID
'
GO
/****** Object:  View [dbo].[MC_PortfolioView]    Script Date: 03/23/2009 19:10:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_PortfolioView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_PortfolioView]
AS
SELECT     dbo.Account.AccountID, dbo.Account.ClientID AS ProductID, dbo.Account.MCode AS BucketID, dbo.Account.CCode AS CycleID, dbo.Account.BillAmount, 
                      dbo.Account.BillBalance, dbo.Account.EmployeeID, dbo.Employee.EmployeeName, dbo.Account.AllocRuleID AS AllocationRuleID, dbo.Employee.SuperVisorId, 
                      dbo.Account.AgencyStatusID AS AccountStatusID, dbo.Employee.Department AS DepartmentID, dbo.Account.DebtorID
FROM         dbo.Employee RIGHT OUTER JOIN
                      dbo.Account ON dbo.Employee.EmployeeID = dbo.Account.EmployeeID
'
GO
/****** Object:  View [dbo].[MC_BucketInformationView]    Script Date: 03/23/2009 19:10:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_BucketInformationView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_BucketInformationView]
AS
SELECT
	a.accountId, a.billBalance, o.Money21 AS pastDue1, o.Money22 AS pastDue2, o.Money23 AS pastDue3, o.Money24 AS pastDue4, o.Money25 AS pastDue5, o.Money26 AS pastDue6
FROM
	Account a inner join AccountOther o ON a.AccountID = o.AccountID
'
GO
/****** Object:  View [dbo].[MC_ContactInformationView]    Script Date: 03/23/2009 19:10:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_ContactInformationView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_ContactInformationView]
AS
SELECT v.accountId, v.Title, v.fullName, v.Email,
i.Address1, i.Address2, i.Address3, i.City, i.State, i.Zip, i.Country, i.AddressType,
(
SELECT COUNT(*)
FROM Account
WHERE DebtorId = v.DebtorId
) AS Total
FROM MC_AccountsView v
INNER JOIN PersonAddress i
ON v.PersonID = i.PersonId
AND i.AddressType IN (1,2)
'
GO
/****** Object:  View [dbo].[MC_DebtorInformationView]    Script Date: 03/23/2009 19:10:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_DebtorInformationView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_DebtorInformationView]
AS
SELECT v.accountId, v.DebtorID, v.Title, v.fullName, v.Email,
i.Nationality, i.Language, CONVERT(CHAR(10), i.DateOfBirth, 103) AS DateOfBirth, i.Employment, i.Profession, i.Department, i.DriversLicenseNumber, i.SocialSecurityNumber,
(
SELECT COUNT(*)
FROM Account
WHERE DebtorId = v.DebtorId
) AS Total
FROM MC_AccountsView v
INNER JOIN PersonInformation i
ON v.PersonID = i.PersonId
'
GO
/****** Object:  View [dbo].[MC_AccountInformationView]    Script Date: 03/23/2009 19:10:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_AccountInformationView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_AccountInformationView]
AS
SELECT
	a.accountId, a.dateOfService, a.routinePayment, a.writeOffDate, a.paid, 
	o.Long16 AS flowDay, Date7 AS maturityDate, o.Date9 AS dueDate, o.Date17 AS firstInstallmentDate, 
	o.Date49 AS lastDelqDate, o.Money2 AS principal, o.Money37 AS interest, o.Money30 AS penalty,
	o.Long17 AS remainingTenor, o.Money36 AS chargeOffAmount, o.Money35 AS chargeOffPrincipal
FROM
	Account a inner join AccountOther o ON a.AccountID = o.AccountID
'
GO
/****** Object:  View [dbo].[MC_BillingInformationView]    Script Date: 03/23/2009 19:10:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_BillingInformationView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_BillingInformationView]
AS
SELECT
	a.accountId, a.accountAge, a.billAmount, a.MCode AS bucketId, a.MINIMUM_DUE AS minimumDue, 
	a.tenor, o.Money27 AS loanAmount, o.Money29 AS payoffAmount, o.String2 AS cardNumber
FROM
	Account a inner join AccountOther o ON a.AccountID = o.AccountID
'
GO
/****** Object:  View [dbo].[MC_DebtorAddressView]    Script Date: 03/23/2009 19:10:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[MC_DebtorAddressView]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [MC_DebtorAddressView]
AS
SELECT     
	v.AccountID, i.AddressType AS addressTypeId, at.name AS addressType, CASE WHEN LEN(RTRIM(LTRIM(ISNULL(i.Address1, '''')))) 
    = 0 THEN '''' ELSE RTRIM(LTRIM(i.Address1)) + char(10) + char(13) END + CASE WHEN LEN(RTRIM(LTRIM(ISNULL(i.Address2, '''')))) 
    = 0 THEN '''' ELSE RTRIM(LTRIM(i.Address2)) + char(10) + char(13) END + CASE WHEN LEN(RTRIM(LTRIM(ISNULL(i.Address3, '''')))) 
    = 0 THEN '''' ELSE RTRIM(LTRIM(i.Address3)) + char(10) + char(13) END + CASE WHEN LEN(RTRIM(LTRIM(ISNULL(i.City, '''')))) 
    = 0 THEN '''' ELSE RTRIM(LTRIM(i.City)) END + CASE WHEN LEN(RTRIM(LTRIM(ISNULL(i.State, '''')))) = 0 THEN '''' ELSE '' '' + RTRIM(LTRIM(i.State)) 
    END + CASE WHEN LEN(RTRIM(LTRIM(ISNULL(i.Zip, '''')))) = 0 THEN '''' ELSE '' '' + RTRIM(LTRIM(i.Zip)) 
    END + CASE WHEN LEN(RTRIM(LTRIM(ISNULL(i.Country, '''')))) = 0 THEN char(10) + char(13) ELSE char(10) + char(13) + RTRIM(LTRIM(i.Country)) 
    + char(10) + char(13) END AS address, CASE WHEN i.AddressStatus = 0 THEN ''true'' ELSE ''false'' END AS isGood
FROM
    dbo.MC_AccountsView AS v LEFT OUTER JOIN
    dbo.PersonAddress AS i ON v.PersonID = i.PersonID LEFT OUTER JOIN
    dbo.MC_AddressTypes AS at ON at.id = i.AddressType
'
GO

PRINT 'Done creating VIEWS for MC'
GO
