-- Script is applied on version 2.4.2, 2.4.3, 2.4.4

-- Scripts 2.4.2:

IF NOT EXISTS (SELECT ActionID FROM AvailableActions WHERE ActionID=8)
	INSERT INTO AvailableActions
						  (ActionID, Description, ConsiderWorked, ActionType, IncludeOnReport, Category, ResultType, ProductivityID, UnitCost, CallResultId, NextActionId, 
						  QueueDays, Status, LoadInProductID)
	VALUES     (8, N'Account Reviewed', 1, 'S', 0, 1, 'SYS', 2, 0, 0, 0, 0, 'A', 0)
	
GO


/****** Object:  Table [dbo].[Collateral]    Script Date: 08/10/2008 15:15:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Collateral](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AccountID] [int] NULL DEFAULT (0),
	[HostCollateralID] [int] NULL DEFAULT (0),
	[CollateralType] [int] NULL,
	[CollateralStage] [int] NULL,
	[EmployeeID] [int] NULL,
	[NextAction] [int] NULL,
	[NextActionDate] [smalldatetime] NULL,
	[CInt1] [int] NULL,
	[CInt2] [int] NULL,
	[CInt3] [int] NULL,
	[CInt4] [int] NULL,
	[CInt5] [int] NULL,
	[CInt6] [int] NULL,
	[CInt7] [int] NULL,
	[CInt8] [int] NULL,
	[CInt9] [int] NULL,
	[CInt10] [int] NULL,
	[CString1] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString2] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString3] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString4] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString5] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString6] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString7] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString8] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString9] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString10] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString11] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString12] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString13] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString14] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString15] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString16] [varchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString17] [varchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString18] [varchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString19] [varchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CString20] [varchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CDate1] [smalldatetime] NULL,
	[CDate2] [smalldatetime] NULL,
	[CDate3] [smalldatetime] NULL,
	[CDate4] [smalldatetime] NULL,
	[CDate5] [smalldatetime] NULL,
	[CDate6] [smalldatetime] NULL,
	[CDate7] [smalldatetime] NULL,
	[CDate8] [smalldatetime] NULL,
	[CDate9] [smalldatetime] NULL,
	[CDate10] [smalldatetime] NULL,
	[CDate11] [smalldatetime] NULL,
	[CDate12] [smalldatetime] NULL,
	[CDate13] [smalldatetime] NULL,
	[CDate14] [smalldatetime] NULL,
	[CDate15] [smalldatetime] NULL,
	[CMoney1] [money] NULL,
	[CMoney2] [money] NULL,
	[CMoney3] [money] NULL,
	[CMoney4] [money] NULL,
	[CMoney5] [money] NULL,
	[CMoney6] [money] NULL,
	[CMoney7] [money] NULL,
	[CMoney8] [money] NULL,
	[CMoney9] [money] NULL,
	[CMoney10] [money] NULL,
	[CMoney11] [money] NULL,
	[CMoney12] [money] NULL,
	[CMoney13] [money] NULL,
	[CMoney14] [money] NULL,
	[CMoney15] [money] NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

/****** Object:  Table [dbo].[CWX_Collateral_Dict]    Script Date: 08/10/2008 15:15:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CWX_Collateral_Dict](
	[FieldName] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FieldDesc] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Displayed] [bit] NULL,
	[Editable] [bit] NULL,
	[GroupID] [int] NULL,
	[GroupDesc] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DisplayOrder] [int] NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF


/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_GetRuleAndCriteriaList]    Script Date: 08/13/2008 12:28:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_GetRuleAndCriteriaList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleTable_GetRuleAndCriteriaList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_GetRuleAndCriteriaList]    Script Date: 08/13/2008 12:28:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 24, 2008
-- Description:	Retrieve records that match the rulecriterias of a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleTable_GetRuleAndCriteriaList] 
	-- Add the parameters for the stored procedure here
	@RuleType tinyint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @Temp table
	(
		COLUMN_NAME varchar(50),
		DESCRIPTION varchar(50),
		DATA_TYPE varchar(25),
		max_length int,
		[precision] int,
		[DATABASE] varchar(50)
	)

	INSERT INTO @Temp
	EXEC CWX_RuleCriteria_GetCriteriaByRuleType @RuleType

    SELECT
		ROW_NUMBER() OVER (ORDER BY r.Description) AS RowNumber,
		r.ID, r.Description,
		f.FeeDescription,
		l1.LetterDesc AS Letter,
		l2.LetterDesc AS SMS,
		l3.LetterDesc AS Email,
		l4.LetterDesc AS Fax,
		i.InterfaceDescription AS Interface,
		r.Priority
	FROM RuleTable r
	LEFT JOIN DefineFees f ON f.FeeID = r.Fee
	LEFT JOIN DefineLetters l1 ON l1.LetterID = r.Letter
	LEFT JOIN DefineLetters l2 ON l2.LetterID = r.SMS
	LEFT JOIN DefineLetters l3 ON l3.LetterID = r.Email
	LEFT JOIN DefineLetters l4 ON l4.LetterID = r.Fax
	LEFT JOIN Interface i ON i.InterfaceID = r.InterfaceID
	WHERE
		r.RuleType = @RuleType

	SELECT
		c.ID, c.RuleID,
		t.DESCRIPTION AS Criteria,
		c.Operator,
		c.MatchingCriteria,
		CASE c.ID
			WHEN (SELECT MAX(ID) FROM RuleCriteria WHERE RuleID = c.RuleID) THEN ''
			ELSE c.Combining
		END AS Combining,
		t.DATA_TYPE AS DataType
	FROM RuleCriteria c
	INNER JOIN RuleTable r ON c.RuleID = r.ID
	LEFT JOIN @Temp t ON t.COLUMN_NAME = c.Criteria
	WHERE r.RuleType = @RuleType
	ORDER BY r.Description
END

GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetWorkDetails]    Script Date: 08/13/2008 13:54:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetWorkDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetWorkDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetWorkDetails]    Script Date: 08/13/2008 13:54:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetWorkDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Get employee working details.
-- History:
--	2008/08/13	[Binh Truong]	Init version.
-- =============================================================
CREATE PROCEDURE CWX_Employee_GetWorkDetails
	@SupervisorID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;
                      
	DECLARE @EmployeeID int
	DECLARE @EmployeeName varchar(50)
	DECLARE @RowCount int
	DECLARE @RecordIndex int
	
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END
	
	DECLARE @TempTableVar table(
			EmployeeID			int,
			EmployeeName		varchar(50),
			AccountIDViewing	int,
			ViewedNo			int
		);
		
	SELECT	@RowCount = COUNT(DISTINCT E.EmployeeID)
	FROM	AccountActions as A, Employee as E
	WHERE	A.CompletedBy = E.EmployeeID AND
			(@SupervisorID = 0 OR E.SuperVisorId = @SupervisorID) AND
			E.EmployeeStatus = ''A'' AND A.ActionID = 8 AND 
			CONVERT(varchar(10), A.DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)

	DECLARE AccountActions_cursor CURSOR DYNAMIC READ_ONLY FOR
	SELECT	DISTINCT E.EmployeeID, E.EmployeeName 
	FROM	AccountActions as A, Employee as E
	WHERE	A.CompletedBy = E.EmployeeID AND
			(@SupervisorID = 0 OR E.SuperVisorId = @SupervisorID) AND
			E.EmployeeStatus = ''A'' AND A.ActionID = 8 AND 
			CONVERT(varchar(10), A.DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
	ORDER BY E.EmployeeID

	OPEN AccountActions_cursor
	
	FETCH RELATIVE @BeginIndex FROM AccountActions_cursor 
	INTO @EmployeeID, @EmployeeName

	WHILE @PageSize > 0 AND @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO @TempTableVar
		SELECT	TOP 1	@EmployeeID, 
						@EmployeeName,
						AccountID,
						(SELECT	COUNT(CompletedBy)
						FROM	AccountActions
						WHERE   CompletedBy = @EmployeeID AND ActionID = 8 AND (CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121))) as ViewedNo
		FROM	AccountActions
		WHERE CompletedBy = @EmployeeID
		ORDER BY DateCompleted DESC
		
		FETCH NEXT FROM AccountActions_cursor
		INTO @EmployeeID, @EmployeeName
		
		SET @PageSize = @PageSize - 1
	END
	
	CLOSE AccountActions_cursor
	DEALLOCATE AccountActions_cursor

	SELECT * FROM @TempTableVar
	
	RETURN @RowCount
END
' 
END
GO

-- Scripts 2.4.3:
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetList]    Script Date: 08/13/2008 14:25:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetList]    Script Date: 08/13/2008 14:25:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetList]
	@RuleID int
AS
BEGIN	
	SET NOCOUNT ON;

	DECLARE @RuleType int
	SELECT @RuleType=RuleType FROM RuleTable WHERE ID=@RuleID

	DECLARE @Temp table
	(
		COLUMN_NAME varchar(50),
		DESCRIPTION varchar(50),
		DATA_TYPE varchar(25),
		max_length int,
		[precision] int,
		[DATABASE] varchar(50)
	)

	INSERT INTO @Temp
	EXEC CWX_RuleCriteria_GetCriteriaByRuleType @RuleType

	SELECT
		c.ID, c.RuleID, c.Criteria, c.Operator, c.MatchingCriteria, c.SQLFormat,
		CASE c.ID
			WHEN (SELECT MAX(ID) FROM RuleCriteria WHERE RuleID = c.RuleID) THEN ''
			ELSE c.Combining
		END AS Combining,
		t.DESCRIPTION AS DESCRIPTION,
		t.DATA_TYPE AS DataType
	FROM RuleCriteria c
	LEFT JOIN @Temp t ON t.COLUMN_NAME = c.Criteria
	WHERE c.RuleID = @RuleID
	ORDER BY c.ID
END
GO

-- Scripts 2.4.4:
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Account' and c.name = 'IsPending')
BEGIN
	ALTER TABLE Account
	ADD IsPending bit NULL
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 08/14/2008 09:54:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXML]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_LoadXML]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 08/14/2008 09:54:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Description:	Load all accounts with debtorID
-- History:
--	08/04/03	[Tai Ly]	Init version.
--	08/06/01	[Long Nguyen]	Add and remove some fields.
--	08/06/27	[Binh Truong]	Remove BatchNumber field.	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int	
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/
	SELECT
			a.AccountID,
			c.COOWNERS,
			ISNULL(l.LetterDesc, '') AS SENTBY, ISNULL(al.LetterStatus, '') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			('Debtor promises to pay ' + CAST(p.AmountPromised AS varchar) + ' for ' + CAST(p.PromiseFrequency AS varchar) + ' ' + ISNULL(p.Term, '') + ', Next Payment due on ') AS PROMISE, p.DatePromised,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL,
			lastpromise.LASTPROMISEDATE, lastpromise.LASTPROMISEAMOUNT, lastpromise.LASTPROMISESTATUS, lastpromise.LASTPROMISESTATUSDESC
	INTO	#AccountTemp
	FROM	Account	 a
	--Count CoSigner for account
	LEFT JOIN (SELECT AccountID, COUNT(CoSignerID) AS COOWNERS FROM CoSigner GROUP BY AccountID) c ON c.AccountID = a.AccountID
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN 'd' THEN 'day(s)'
						WHEN 'w' THEN 'week(s)'
						WHEN 'm' THEN 'month(s)'
						WHEN 'y' THEN 'year(s)'
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get last promise
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised AS LASTPROMISEAMOUNT,
					p2.DatePromised AS LASTPROMISEDATE,
					p2.Status AS LASTPROMISESTATUS,
					CASE p2.Status
						WHEN 0 THEN 'Not Due'
						WHEN 1 THEN 'Paid On Time'
						WHEN 2 THEN 'Paid Late'
						WHEN 3 THEN 'Broken Promise'
						WHEN 4 THEN 'Canceled'
						ELSE ''
					END AS LASTPROMISESTATUSDESC
				FROM AccountPromise p2 
				WHERE p2.PromiseID IN 
						(	SELECT TOP 1 PromiseID
							FROM (	SELECT PromiseID, DatePromised
									FROM AccountPromise 
									WHERE AccountID = p2.AccountID -- 69
							) as temp
							ORDER BY DatePromised DESC
						)) lastpromise ON lastpromise.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	WHERE DebtorID = @DebtorID

	--If @AdditionalTag = 1 get additional data
	DECLARE @AdditionalTag int
	SELECT @AdditionalTag = FieldValue FROM IdentityFields WHERE TableName = 'AdditionalTag'

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, nextAction.CodeDesc AS CurrentNextActionDesc, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			, #AccountTemp.COOWNERS--, DebtorID as COOWNERS
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE--, InvoiceNumber as SENTBY, ' ' as LETTERSTATUS, QueueDate as LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised--, String1 as PROMISE
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.LASTCONTACTDATE ELSE '' END AS LASTCONTACTDATE--' ' as LASTCONTACTDATE
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.LASTCONTACTBY ELSE '' END AS LASTCONTACTBY--, ' ' as LASTCONTACTBY
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISETOPAY ELSE '' END AS PROMISETOPAY--, ' ' as PROMISETOPAY
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISEKEPT ELSE '' END AS PROMISEKEPT--, ' ' as PROMISEKEPT
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISEBROKEN ELSE '' END AS PROMISEBROKEN--, ' ' as PROMISEBROKEN
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.OUTGOINGCALL ELSE '' END AS OUTGOINGCALL--, ' ' as OUTGOINGCALL
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.NOACTIVITYDAYS ELSE '' END AS NOACTIVITYDAYS--, ' ' as NOACTIVITYDAYS
			, #AccountTemp.LASTPROMISEDATE, #AccountTemp.LASTPROMISEAMOUNT, #AccountTemp.LASTPROMISESTATUS, #AccountTemp.LASTPROMISESTATUSDESC
			, ISNULL(Account.IsPending, 0) AS IsPending
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID
			LEFT OUTER JOIN AccountCodeMaster nextAction on Account.CurrentNextAction = nextAction.CodeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END
GO

UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_SearchByQueueSStat %E, %1, %DPD, %Bucket, %Cycle, %IsPending' WHERE ID = 1
UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_SearchByQueueAStat %E, %1, %IsPending' WHERE ID = 2
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueAStat]    Script Date: 08/14/2008 11:52:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByQueueAStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat]
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueAStat]    Script Date: 08/14/2008 11:52:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_AgencyStatus int,
	@IsPending bit = 0,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId AS varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID = '+CAST(@v_AgencyStatus AS varchar(9))
				+ '   AND ISNULL(a.IsPending,0) = '+CAST(@IsPending AS varchar(1))


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 08/14/2008 11:53:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByQueueSStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 08/14/2008 11:53:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_SystemStatus int,
	@AccountAge int = -1,
	@MCode int = -1,
	@CCode int = -1,
	@IsPending bit = 0,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId as varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID <> 2'
				+ '   AND ISNULL(a.IsPending,0) = '+CAST(@IsPending AS varchar(1))

	IF @v_SystemStatus = 0 
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'+''

	IF ((@v_SystemStatus = 1) or (@v_SystemStatus = 5))
		SET @cStmt=@cStmt+' AND s.SystemStatus = '+CAST(@v_SystemStatus AS varchar(9))+''

	IF @v_SystemStatus = 2
	BEGIN
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'+''
		SET @cStmt=@cStmt+' AND convert(varchar(10),a.SubmissionDate,121)=convert(varchar(10),GetDate(),121)'+''
	END
	
	IF @AccountAge <> -1
		SET @cStmt=@cStmt+' AND a.AccountAge = '+CAST(@AccountAge AS varchar(9))
	IF @MCode <> -1
		SET @cStmt=@cStmt+' AND a.MCode = '+CAST(@MCode AS varchar(9))
	IF @CCode <> -1
		SET @cStmt=@cStmt+' AND a.CCode = '+CAST(@CCode AS varchar(9))

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_TestRule]    Script Date: 08/14/2008 15:07:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_TestRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleTable_TestRule]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_TestRule]    Script Date: 08/14/2008 15:07:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 24, 2008
-- Description:	Retrieve records that match the rulecriterias of a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleTable_TestRule] 
	-- Add the parameters for the stored procedure here
	@RuleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat, Combining
		FROM RuleCriteria
		WHERE RuleID = @RuleID

	DECLARE @SQLFormat varchar(700)
	DECLARE @Combining varchar(10)
	DECLARE @NeedCombining varchar(10)
	DECLARE @WhereClause varchar(2000)
	DECLARE @IsOpenningBracket bit
	SET @NeedCombining = 'And'
	SET @WhereClause = ''
	SET @IsOpenningBracket = 0

	OPEN RuleCriteriaCrsr
	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF (LOWER(@Combining) = 'or')
			IF (@IsOpenningBracket = 0)
			BEGIN
				SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' (' + @SQLFormat
				SET @IsOpenningBracket = 1
			END
			ELSE
				SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' ' + @SQLFormat
		ELSE
		BEGIN
			SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' ' + @SQLFormat			
			IF (@IsOpenningBracket = 1)
			BEGIN
				SET @WhereClause = @WhereClause + ') '
				SET @IsOpenningBracket = 0
			END
		END

		SET @NeedCombining = @Combining /* remember previous value */
		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	END

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr

	--This is used for AllocationRule, if RuleType=1, append condition <Account.MAINTAINOFFICER = 0>
	DECLARE @RuleType tinyint
	SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID
	IF @RuleType = 1
		SET @WhereClause = ' AND Account.MAINTAINOFFICER = 0' + @WhereClause

	DECLARE @Sql varchar(8000)
	SET @Sql = ' SELECT'
				+ ' Account.AccountId,Account.DebtorId,PersonInformation.FirstName,PersonInformation.MiddleName,PersonInformation.LastName,Account.BillBalance,Account.BillAmount,Account.InvoiceNumber'
				+ ' FROM Account'
				+ ' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID'
				+ ' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID'
				+ ' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID'
				+ ' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID'
				+ ' WHERE (PersonAddress.MailingAddress = 1)'
				+ ' AND Account.AgencyStatusID <> 2'-- Donot show closed account
				+ @WhereClause

	EXEC (@Sql)

END
GO

/******  Script Closed. Go next: Step018_2  ******/