﻿-- Script is applied on version 3.6.6:

-- Scripts 3.6.6: 
PRINT 'Scripts 3.6.6 for MC'
GO
PRINT 'Creating Stored Procedures for MC' 
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeSummaryPromiseInfo_GroupbyDateRange]    Script Date: 03/24/2009 13:35:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeSummaryPromiseInfo_GroupbyDateRange]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_EmployeeSummaryPromiseInfo_GroupbyDateRange]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeSummaryPromiseInfo]    Script Date: 03/24/2009 13:35:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeSummaryPromiseInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_EmployeeSummaryPromiseInfo]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeGoals]    Script Date: 03/24/2009 13:35:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeGoals]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_EmployeeGoals]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_GetCurrentEmployeeGoals]    Script Date: 03/24/2009 13:35:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_GetCurrentEmployeeGoals]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_GetCurrentEmployeeGoals]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeCurrentGoals_Get]    Script Date: 03/24/2009 13:35:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeCurrentGoals_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_EmployeeCurrentGoals_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeePreviousGoals_Get]    Script Date: 03/24/2009 13:35:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeePreviousGoals_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_EmployeePreviousGoals_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeActions_Get]    Script Date: 03/24/2009 13:35:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeActions_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_EmployeeActions_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_GetEmployeeActions]    Script Date: 03/24/2009 13:35:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_GetEmployeeActions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_GetEmployeeActions]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeRanking_Get]    Script Date: 03/24/2009 13:35:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeRanking_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_EmployeeRanking_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeProductivity_Get]    Script Date: 03/24/2009 13:35:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeProductivity_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_EmployeeProductivity_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeDetailPromiseInfo]    Script Date: 03/24/2009 13:35:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeDetailPromiseInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_EmployeeDetailPromiseInfo]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_Employee_Search]    Script Date: 03/24/2009 13:35:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_Employee_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_Employee_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_PortfolioViews]    Script Date: 03/24/2009 13:35:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_PortfolioViews]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_PortfolioViews]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_GetPortfolioViews]    Script Date: 03/24/2009 13:35:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_GetPortfolioViews]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_GetPortfolioViews]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_GetPortfolioViewDetails]    Script Date: 03/24/2009 13:35:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_GetPortfolioViewDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_GetPortfolioViewDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_PortfolioAccountList]    Script Date: 03/24/2009 13:35:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_PortfolioAccountList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_PortfolioAccountList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_GetPortfolioAccountViews]    Script Date: 03/24/2009 13:35:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_GetPortfolioAccountViews]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_GetPortfolioAccountViews]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_UpdatePortfolioViews]    Script Date: 03/24/2009 13:35:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_UpdatePortfolioViews]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_UpdatePortfolioViews]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_UpdatePortfolioViewDetails]    Script Date: 03/24/2009 13:35:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_UpdatePortfolioViewDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_UpdatePortfolioViewDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_AddNewPortfolioViewDetails]    Script Date: 03/24/2009 13:35:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_AddNewPortfolioViewDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_AddNewPortfolioViewDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_AddNewPortfolioViews]    Script Date: 03/24/2009 13:35:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_AddNewPortfolioViews]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_AddNewPortfolioViews]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_DeletePortfolioViewDetails]    Script Date: 03/24/2009 13:35:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_DeletePortfolioViewDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_DeletePortfolioViewDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_DeletePortfolioViews]    Script Date: 03/24/2009 13:35:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_DeletePortfolioViews]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_DeletePortfolioViews]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeSummaryPromiseInfo_GroupbyDateRange]    Script Date: 03/24/2009 13:35:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeSummaryPromiseInfo_GroupbyDateRange]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
	-- =============================================
	-- Author:		Alvin Marable
	-- Create date: Aug. 2008
	-- Description:	
	-- =============================================
	CREATE PROCEDURE [CWX_MC_EmployeeSummaryPromiseInfo_GroupbyDateRange]
		@EmployeeID int = 0,
		@DatePromisedFrom DATETIME,
		@DatePromisedTo DATETIME,
		@DatePaidFrom DATETIME,
		@DatePaidTo DATETIME,
		@Status VARCHAR(20),
		@GroupType CHAR(1)
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		DECLARE @MainStmt VARCHAR(5000)

		DECLARE @SelectStmt VARCHAR(2000)
		DECLARE @FromStmt VARCHAR(2000)
		DECLARE @GroupStmt VARCHAR(1000)
		
		DECLARE	@EmpID VARCHAR(25),
				@PromisedDateFrom VARCHAR(10),
				@PromisedDateTo VARCHAR(10),
				@PaidDateFrom VARCHAR(10),
				@PaidDateTo VARCHAR(10)

		SET @EmpID = CONVERT(VARCHAR(25), @EmployeeID)
		SET @PromisedDateFrom = CONVERT(CHAR(10),@DatePromisedFrom,110)
		SET @PromisedDateTo = CONVERT(CHAR(10),@DatePromisedTo,110)
		SET @PaidDateFrom = CONVERT(CHAR(10),@DatePaidFrom,110)
		SET @PaidDateTo = CONVERT(CHAR(10),@DatePaidTo,110)

		
		SET @SelectStmt = 
			''SELECT COUNT (PromiseID) TotalCount,
					ROUND(SUM (Amount),2) TotalAmount, [Status], '' + 
			CASE @GroupType 
				WHEN 1 THEN '' DATEADD(day, DATEDIFF(day, 0, DateValue),0) ''
				WHEN 2 THEN '' DATEADD(week, DATEDIFF(week, 0, DateValue),0) ''
				WHEN 3 THEN '' DATEADD(month, DATEDIFF(month, 0, DateValue),0) ''
			END + '' DateValue '';		
		
		SET @FromStmt = 
			'' FROM 
			(
				SELECT 
					PromiseID,
					AmountPromised Amount,
					CONVERT(DATETIME,Promise.DatePromised,110) DateValue,
					[Status]
				FROM AccountPromise Promise
				WHERE EmployeeID = '' + @EmpID + '' AND [Status] IN (0)
					AND DatePromised BETWEEN CONVERT(DATETIME,'''''' + @PromisedDateFrom + '''''',110)  AND  CONVERT(DATETIME,'''''' + @PromisedDateTo + '''''',110) '' +
			
			''	UNION  '' +
			
			''	SELECT 
					PromiseID,
					AmountPaid Amount,
					CONVERT(DATETIME,Promise.DatePaid,110) DateValue,
					1 [Status]
				FROM AccountPromise Promise
				WHERE EmployeeID = '' + @EmpID + '' AND [Status] IN (1,2)
					AND DatePaid BETWEEN CONVERT(DATETIME,'''''' + @PaidDateFrom + '''''',110)  AND  CONVERT(DATETIME,'''''' + @PaidDateTo + '''''',110) '' +

			''	UNION  '' +

			''	SELECT 
					PromiseID,
					AmountPromised Amount,
					CONVERT(DATETIME,Promise.DateBroken,110) DateValue,
					[Status]
				FROM AccountPromise Promise
				WHERE EmployeeID = '' + @EmpID + '' AND [Status] IN (3)
					AND DatePromised BETWEEN CONVERT(DATETIME,'''''' + @PromisedDateFrom + '''''',110)  AND  CONVERT(DATETIME,'''''' + @PromisedDateTo + '''''',110) '' + 

			'' )  Promises '';

		SET @GroupStmt = '' GROUP BY '' +
			CASE @GroupType 
				WHEN 1 THEN '' DATEADD(day, DATEDIFF(day, 0, DateValue),0) ''
				WHEN 2 THEN '' DATEADD(week, DATEDIFF(week, 0, DateValue),0) ''
				WHEN 3 THEN '' DATEADD(month, DATEDIFF(month, 0, DateValue),0) ''
			END + '', [Status] '';
		

		SET @MainStmt =
			@SelectStmt +  @FromStmt + @GroupStmt + '' ORDER BY DateValue, [Status]'';

		EXEC (@MainStmt);
	
	END
	' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeSummaryPromiseInfo]    Script Date: 03/24/2009 13:35:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeSummaryPromiseInfo]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
	-- Author: Alvin Marable
	-- Create date: July 2008
	-- Description:	
	-- =============================================

	CREATE PROCEDURE [CWX_MC_EmployeeSummaryPromiseInfo] 
		(
			@EmployeeIDs VARCHAR(5000) = '''',
			@DatePromisedFrom DATETIME,
			@DatePromisedTo DATETIME,
			@DatePaidFrom DATETIME,
			@DatePaidTo DATETIME,
			@Status VARCHAR(100) = ''''
		)
	AS
	BEGIN

	DECLARE @mainScript VARCHAR(5000);
	DECLARE @tableA VARCHAR(5000);
	DECLARE @criteriaA VARCHAR(5000);
	DECLARE @tableB VARCHAR(5000);
	DECLARE @criteriaB VARCHAR(5000);
	DECLARE @joinOnA VARCHAR (5000);

	/* columns to show*/
	SET @tableA =
		'' SELECT 
			Employee.EmployeeName, 
			Employee.EmployeeID,
			ISNULL(Promise.PromisesTaken,0) PromisesTaken,
			ISNULL(Promise.AmountPromised,0) AmountPromised,
			ISNULL(Promise.KPCount,0) KPCount,
			ISNULL(Promise.KPAmount,0) KPAmount, 
			ISNULL(Promise.BPCount,0) BPCount,
			ISNULL(Promise.BPAmount,0) BPAmount,
			ISNULL(Promise.NDCount,0) NDCount,
			ISNULL(Promise.NDAmount, 0) NDAmount
		  FROM Employee '';

	/* criteria to be used by main select statement */
	IF @EmployeeIDs <> '''' 
		SET @criteriaA = '' Employee.EmployeeID IN ('' + @EmployeeIDs + '')''; 

	/* relationship to be used by JOIN operation */
	SET @joinOnA = 
		'' ON Employee.EmployeeID = Promise.EmployeeID '';

	/* columns available from AccountPomise */
	SET @tableB = 
		'' SELECT  
			EmployeeID,
			COUNT (AccountID) PromisesTaken,
			ROUND(SUM (AmountPromised),2) AmountPromised,
			SUM(CASE WHEN [Status] IN (1,2)  THEN 1 ELSE 0 END) KPCount ,
			ROUND(SUM(CASE WHEN [Status] IN (1,2) THEN AmountPaid ELSE 0 END), 2) KPAmount,
			SUM(CASE WHEN [Status] = 3 THEN 1 ELSE 0 END) BPCount,
			ROUND(SUM(CASE WHEN [Status] = 3 THEN AmountPromised ELSE 0 END), 2) BPAmount,
			SUM(CASE WHEN [Status] = 0 THEN 1 ELSE 0 END) NDCount,
			ROUND(SUM(CASE WHEN [Status] = 0 THEN AmountPromised ELSE 0 END), 2) NDAmount
		  FROM AccountPromise Promise '';

	/* set available STATUS of AccountPromise */
	IF @Status = '''' 
		SET @Status = ''0,1,2,3'';
	ELSE IF @Status = ''1'' OR @Status = ''2'' 
		SET @Status = ''1,2'';
		 
	/* criteria to be used by AccountPromise */
	SET @CriteriaB =
		'' CASE 
			WHEN Promise.Status = 0 THEN DatePromised 
			WHEN Promise.Status = 1  OR Promise.Status = 2 THEN DatePaid 
			WHEN Promise.Status = 3  THEN DateBroken 
			ELSE DatePromised 
		END 
			BETWEEN  
				CASE '' +
					'' WHEN Promise.Status = 0 THEN CONVERT(DATETIME,'' + '''''''' + CONVERT(CHAR(10),@DatePromisedFrom,110) + '''''''' + '',110) '' +
					'' WHEN Promise.Status = 1  OR Promise.Status = 2 THEN CONVERT(DATETIME,'' + '''''''' + CONVERT(CHAR(10),@DatePaidFrom,110) + '''''''' + '',110) '' +
					'' WHEN Promise.Status = 3  THEN CONVERT(DATETIME,'' + '''''''' + CONVERT(CHAR(10),@DatePromisedFrom,110) + '''''''' + '',110) '' +
					'' ELSE CONVERT(DATETIME,'' + '''''''' + CONVERT(CHAR(10),@DatePromisedFrom,110) + '''''''' + '',110) '' +
				'' END  
				AND 
				CASE '' + 
					'' WHEN Promise.Status = 0 THEN CONVERT(DATETIME,'' + '''''''' + CONVERT(CHAR(10),@DatePromisedTo,110) + '''''''' + '',110) '' +
					'' WHEN Promise.Status = 1  OR Promise.Status = 2 THEN CONVERT(DATETIME,'' + '''''''' + CONVERT(CHAR(10),@DatePaidTo,110) + '''''''' + '',110) '' +
					'' WHEN Promise.Status = 3  THEN CONVERT(DATETIME,'' + '''''''' + CONVERT(CHAR(10),@DatePromisedTo,110) + '''''''' + '',110) '' +
					'' ELSE CONVERT(DATETIME,'' + '''''''' + CONVERT(CHAR(10),@DatePromisedTo,110) + '''''''' + '',110) '' + 
				'' END '' 



	/* generate main script */
	SET @mainScript =
		@tableA +  
		'' LEFT JOIN ('' + 
			@tableB + '' WHERE '' + @criteriaB + '' GROUP BY EmployeeID '' +
		'') Promise '' +
		@joinOnA + 
		'' WHERE '' + @criteriaA + '' ORDER BY Employee.EmployeeID ''; 

	/* execute main scipt */
	EXEC (@MainScript);
		
	END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeGoals]    Script Date: 03/24/2009 13:35:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeGoals]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ALVIN MARABLE
-- Create date: Aug. 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [CWX_MC_EmployeeGoals] 
	(
		@EmployeeIDs varchar(5000) = '''',
		@PageSize int = 10,
		@PageIndex int = 0
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	 
	CREATE TABLE #Employees(EmployeeID int)

	DECLARE @WhereStmt VARCHAR(2000)
	IF @EmployeeIDs = '''' 
		SET @WhereStmt = ''WHERE EmployeeStatus <> ''''R'''' ''
	ELSE 
		SET @WhereStmt = ''WHERE EmployeeStatus <> ''''R'''' AND EmployeeID IN ('' + @EmployeeIDs + '')''

	EXEC (
		''INSERT #Employees 
		SELECT EmployeeID 
		FROM Employee '' +
		@WhereStmt
		)
  
	DECLARE @RowCount int;
		SELECT
		@RowCount = COUNT(EmployeeID)
		FROM #Employees

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
		AS
		(
			SELECT
				ROW_NUMBER() OVER (ORDER BY Employee.EmployeeID) AS RowNumber,
				Employee.EmployeeID, Employee.EmployeeName
			FROM Employee
			WHERE Employee.EmployeeID IN (SELECT * FROM #Employees)
		)

	SELECT RowNumber, 
		Temp.EmployeeID, Temp.EmployeeName, 
		Goals.RecordID GoalID, Goals.ActionID, Actions.Description, 
		Goals.GoalCount, Goals.GoalAmount, Goals.StartDate
	FROM Temp
	LEFT JOIN EmployeeGoals Goals
		ON Temp.EmployeeID = Goals.EmployeeID
	LEFT JOIN MC_AvailableActions Actions
		ON Goals.ActionID = Actions.ActionID
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex
	ORDER BY RowNumber, Goals.ActionID
			
DROP TABLE #Employees

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_PortfolioViews]    Script Date: 03/24/2009 13:35:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_PortfolioViews]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Aldous Nochefranca
-- Create date: 09/04/2008
-- Description:	
-- =============================================
--CWX_MC_PortfolioViews 3,null,null,null
CREATE PROCEDURE [CWX_MC_PortfolioViews] 
	@ViewField int,
	@AccountStatusID int = null,
	@AllocationRuleID int = null,
	@BucketID int = null,
	@CycleID int = null,
	@DepartmentID int = null,
	@EmployeeID int = null, 
	@ProductID int = null,
	@SupervisorID int = null
AS
BEGIN
	SET NOCOUNT ON;

DECLARE @sqlstring nvarchar(2000)
DECLARE @params nvarchar(2000)

SET @sqlstring = N''''
SET @params = N''WHERE ''

IF @AccountStatusID >= 0
	SET @params = @params + ''AccountStatusID = '' + Cast(@AccountStatusID as varchar(50)) + '' AND ''

IF @AllocationRuleID >= 0
	SET @params = @params + ''AllocationRuleID = '' + Cast(@AllocationRuleID as varchar(50)) + '' AND ''

IF @BucketID >= 0
	SET @params = @params + ''BucketID = '' + Cast(@BucketID as varchar(50)) + '' AND ''

IF @CycleID >= 0
	SET @params = @params + ''CycleID = '' + Cast(@CycleID as varchar(50)) + '' AND ''

IF @DepartmentID >= 0
	SET @params = @params + ''DepartmentID = '' + Cast(@DepartmentID as varchar(50)) + '' AND ''

IF @EmployeeID >= 0
	SET @params = @params + ''EmployeeID = '' + Cast(@EmployeeID as varchar(50)) + '' AND ''

IF @ProductID >= 0
	SET @params = @params + ''ProductID = '' + Cast(@ProductID as varchar(50)) + '' AND ''

IF @SupervisorID >= 0
	SET @params = @params + ''SupervisorID = '' + Cast(@SupervisorID as varchar(50)) + '' AND ''

IF @ViewField = 1
	SET @sqlstring = ''AccountStatusID, AccountStatus''
IF @ViewField = 2
	SET @sqlstring = ''AllocationRuleID, AllocationRule''
IF @ViewField = 3
	SET @sqlstring = ''BucketID, BucketName''
IF @ViewField = 4
	SET @sqlstring = ''CycleID, CycleName''
IF @ViewField = 5
	SET @sqlstring = ''DepartmentID, DepartmentName''
IF @ViewField = 6
	SET @sqlstring = ''EmployeeID, EmployeeName''
IF @ViewField = 7
	SET @sqlstring = ''ProductID, ProductName''
IF @ViewField = 8
	SET @sqlstring = ''SupervisorID, SupervisorName''

IF Len(@params) > 10
	SET @params = LEFT(@params, Len(@params)-3)
ELSE
	SET @params = ''''

SET @sqlstring = N''SELECT '' + @sqlstring + 
	'', COUNT(DISTINCT AccountID) AS TotalAccounts, SUM(BillAmount) AS TotalAmount FROM CWX_MC_AccountsView '' +
	@params + ''GROUP BY '' + @sqlstring

EXEC sp_executesql @sqlstring
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_PortfolioAccountList]    Script Date: 03/24/2009 13:35:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_PortfolioAccountList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--CWX_MC_PortfolioAccountList @AccountStatusID=5, @ProductID= 1075, @BucketID=1,@PageSize=10,@PageIndex=1
--CWX_MC_PortfolioAccountList @BucketID=1,@PageSize=10,@PageIndex=1
CREATE PROCEDURE [CWX_MC_PortfolioAccountList]
	@AccountStatusID int = null,
	@AllocationRuleID int = null,
	@BucketID int = null,
	@CycleID int = null,
	@DepartmentID int = null,
	@EmployeeID int = null, 
	@ProductID int = null,
	@SupervisorID int = null,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @sqlstring nvarchar(2000)
	DECLARE @params nvarchar(2000)
	DECLARE @paramdef nvarchar(500)

	SET @sqlstring = N''''
	SET @params = N''WHERE ''
	SET @paramdef = N''@RowCountOut int OUTPUT'';
	IF @AccountStatusID >= 0
		SET @params = @params + ''dbo.Account.AgencyStatusID = '' + Cast(@AccountStatusID as varchar(50)) + '' AND ''

	IF @AllocationRuleID >= 0
		SET @params = @params + ''dbo.Account.AllocRuleID = '' + Cast(@AllocationRuleID as varchar(50)) + '' AND ''

	IF @BucketID >= 0
		SET @params = @params + ''dbo.Account.MCode = '' + Cast(@BucketID as varchar(50)) + '' AND ''

	IF @CycleID >= 0
		SET @params = @params + ''dbo.Account.CCode = '' + Cast(@CycleID as varchar(50)) + '' AND ''

	IF @DepartmentID >= 0
		SET @params = @params + ''dbo.Employee.Department = '' + Cast(@DepartmentID as varchar(50)) + '' AND ''

	IF @EmployeeID >= 0
		SET @params = @params + ''dbo.Account.EmployeeID = '' + Cast(@EmployeeID as varchar(50)) + '' AND ''

	IF @ProductID >= 0
		SET @params = @params + ''dbo.Account.ClientID = '' + Cast(@ProductID as varchar(50)) + '' AND ''

	IF @SupervisorID >= 0
		SET @params = @params + ''dbo.Employee.SuperVisorId = '' + Cast(@SupervisorID as varchar(50)) + '' AND ''

	IF Len(@params) > 10
		SET @params = LEFT(@params, Len(@params)-3)
	ELSE
		SET @params = ''''

	SET @sqlstring = N''SELECT @RowCountOut=COUNT(*) FROM dbo.Employee RIGHT OUTER JOIN
				dbo.Account ON dbo.Employee.EmployeeID = dbo.Account.EmployeeID '' + @params
	EXEC sp_executesql @sqlstring, @paramdef, @RowCountOut = @RowCount OUTPUT;

	SET @sqlstring = N''''
	SET @sqlstring = N''
		WITH Temp AS
		(
			SELECT ROW_NUMBER() OVER (ORDER BY Account.AccountID) AS RowNumber,
				dbo.Account.AccountID, dbo.Account.DebtorID, dbo.Account.ClientID AS ProductID, dbo.Account.MCode AS BucketID, dbo.Account.CCode AS CycleID, dbo.Account.BillAmount, 
				dbo.Account.BillBalance, dbo.Account.EmployeeID, dbo.Employee.EmployeeName, dbo.Account.AllocRuleID AS AllocationRuleID, dbo.Employee.SuperVisorId, 
				dbo.Account.AgencyStatusID AS AccountStatusID, dbo.Employee.Department AS DepartmentID
			FROM dbo.Employee RIGHT OUTER JOIN
				dbo.Account ON dbo.Employee.EmployeeID = dbo.Account.EmployeeID '' + @params + 
		'') 

		SELECT Temp.AccountID, Temp.SuperVisorId, Temp.AllocationRuleID, dbo.ClientInformation.ClientName AS ProductName, Temp.BucketID, Temp.CycleID, 
				Temp.BillAmount, Temp.BillBalance, Temp.EmployeeName, dbo.AccountStatus.ShortDesc AS AccountStatus, dbo.EmployeeDepartment.DeptCode AS Department, 
				dbo.PersonInformation.LastName, dbo.PersonInformation.FirstName, dbo.PersonInformation.MiddleName, dbo.DebtorInformation.CompanyName
		FROM dbo.Employee RIGHT OUTER JOIN
				dbo.ClientInformation RIGHT OUTER JOIN
				dbo.AccountStatus RIGHT OUTER JOIN
				Temp LEFT OUTER JOIN
				dbo.DebtorInformation ON Temp.DebtorID = dbo.DebtorInformation.DebtorID LEFT OUTER JOIN
				dbo.PersonInformation ON dbo.DebtorInformation.PersonID = dbo.PersonInformation.PersonID LEFT OUTER JOIN
				dbo.EmployeeDepartment ON Temp.DepartmentID = dbo.EmployeeDepartment.DeptID ON 
				dbo.AccountStatus.AgencyStatus = Temp.AccountStatusID ON dbo.ClientInformation.ClientID = Temp.ProductID ON 
				dbo.Employee.EmployeeID = Temp.EmployeeID
		WHERE RowNumber BETWEEN '' + Cast((@PageIndex * @PageSize + 1) as varchar(10)) + '' AND ('' + Cast(((@PageIndex + 1) * @PageSize) as varchar(10)) + '')
		''

	EXEC sp_executesql @sqlstring
	RETURN @RowCount
	
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_UpdatePortfolioViewDetails]    Script Date: 03/24/2009 13:35:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_UpdatePortfolioViewDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [CWX_MC_UpdatePortfolioViewDetails]
	-- Add the parameters for the stored procedure here
	@PortfolioViewDetailsID		INT
	, @GroupByValue				VarChar(50)
	, @Sequence					INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   UPDATE MC_PortfolioViewDetails
   SET GroupByField = @GroupByValue
	, Sequence = @Sequence
   WHERE ID = @PortfolioViewDetailsID

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_AddNewPortfolioViewDetails]    Script Date: 03/24/2009 13:35:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_AddNewPortfolioViewDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Suzette M. Dimasaca
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [CWX_MC_AddNewPortfolioViewDetails] 
	-- Add the parameters for the stored procedure here
	@PortfolioViewID	INT
	, @GroupByValue		VarChar(50)
	, @Sequence			INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   INSERT INTO MC_PortfolioViewDetails
	(PortfolioViewID, GroupByField, Sequence)
   VALUES
	(@PortfolioViewID, @GroupByValue, @Sequence)
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_DeletePortfolioViewDetails]    Script Date: 03/24/2009 13:35:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_DeletePortfolioViewDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [CWX_MC_DeletePortfolioViewDetails]
	@PortfolioViewDetailsID	INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DELETE FROM MC_PortfolioViewDetails
	WHERE ID = @PortfolioViewDetailsID
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeePreviousGoals_Get]    Script Date: 03/24/2009 13:35:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeePreviousGoals_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ALVIN MARABLE
-- Create date: Aug. 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [CWX_MC_EmployeePreviousGoals_Get]
	(
		@EmployeeID INT,
		@PageSize INT = 10,
		@PageIndex INT = 0
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
	SELECT
		@RowCount = COUNT(GoalID)
	FROM EmployeeGoals Goals
	WHERE Goals.GoalID NOT IN
			(
				SELECT Goals.GoalID
				FROM 
					(
						SELECT MAX(StartDate) StartDate, ActionID, MAX(GoalID) GoalID  FROM EmployeeGoals  
								WHERE EmployeeID = @EmployeeID AND StartDate <= GetDate()
								GROUP BY ActionID
					) CurrentGoals
				INNER JOIN EmployeeGoals Goals
					ON Goals.GoalID = CurrentGoals.GoalID AND Goals.EmployeeID = @EmployeeID
			) AND Goals.EmployeeID = @EmployeeID

	
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	
	WITH Temp
	AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY Goals.StartDate desc, Actions.Description ASC) AS RowNumber,
				Goals.GoalID, Goals.ActionID, Actions.Description, 
				Goals.GoalCount [Count], Goals.GoalAmount [Amount], Goals.StartDate, 
				Goals.EmployeeID
		FROM EmployeeGoals Goals
		LEFT JOIN MC_AvailableActions Actions
			ON Goals.ActionID = Actions.ActionID
		WHERE Goals.GoalID NOT IN
			(
				SELECT Goals.GoalID
				FROM 
					(
						SELECT MAX(StartDate) StartDate, ActionID, MAX(GoalID) GoalID  FROM EmployeeGoals  
								WHERE EmployeeID = @EmployeeID AND StartDate <= GetDate()
								GROUP BY ActionID
					) CurrentGoals
				INNER JOIN EmployeeGoals Goals
					ON Goals.GoalID = CurrentGoals.GoalID AND Goals.EmployeeID = @EmployeeID
			) AND Goals.EmployeeID = @EmployeeID
	)

	SELECT *
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex
	
	RETURN @RowCount

	
	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeCurrentGoals_Get]    Script Date: 03/24/2009 13:35:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeCurrentGoals_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ALVIN MARABLE
-- Create date: Aug. 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [CWX_MC_EmployeeCurrentGoals_Get] 
	(
		@EmployeeID int
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SELECT ROW_NUMBER() OVER (ORDER BY Goals.GoalID) AS RowNumber,
				Goals.GoalID, Goals.ActionID, Actions.Description, 
				Goals.GoalCount, Goals.GoalAmount, Goals.StartDate, 
				Goals.EmployeeID
	FROM MC_AvailableActions Actions
	LEFT JOIN 
		(
			SELECT MAX(StartDate) StartDate, ActionID, MAX(GoalID) GoalID  FROM EmployeeGoals 
			WHERE EmployeeID = @EmployeeID AND StartDate <= GetDate()
			GROUP BY ActionID
		) CurrentGoals
		ON Actions.ActionID = CurrentGoals.ActionID
	INNER JOIN EmployeeGoals Goals
		ON Goals.GoalID = CurrentGoals.GoalID AND Goals.EmployeeID = @EmployeeID
	WHERE Goals.EmployeeID = @EmployeeID
	ORDER BY Goals.StartDate, Actions.Description
	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_GetCurrentEmployeeGoals]    Script Date: 03/24/2009 13:35:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_GetCurrentEmployeeGoals]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ALVIN MARABLE
-- Create date: Aug. 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [CWX_MC_GetCurrentEmployeeGoals] 
	(
		@EmployeeID int
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SELECT ROW_NUMBER() OVER (ORDER BY Goals.GoalID) AS RowNumber,
				Goals.GoalID, Goals.ActionID, Actions.Description, 
				Goals.GoalCount, Goals.GoalAmount, Goals.StartDate, 
				Goals.EmployeeID
	FROM EmployeeGoals Goals
	LEFT JOIN MC_AvailableActions Actions
		ON Goals.ActionID = Actions.ActionID
	WHERE Goals.EmployeeID = @EmployeeID AND
		Goals.StartDate IN 
			(
				SELECT MAX(StartDate) StartDate  FROM EmployeeGoals 
				WHERE StartDate <= Getdate()
				GROUP BY ActionID
			)
	ORDER BY Goals.StartDate, Actions.Description
	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeActions_Get]    Script Date: 03/24/2009 13:35:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeActions_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ALVIN MARABLE
-- Create date: Aug. 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [CWX_MC_EmployeeActions_Get] 
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SELECT ActionID, [Description] FROM MC_AvailableActions
	ORDER BY [Description]
	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_GetEmployeeActions]    Script Date: 03/24/2009 13:35:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_GetEmployeeActions]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ALVIN MARABLE
-- Create date: Aug. 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [CWX_MC_GetEmployeeActions] 
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SELECT ActionID, [Description] FROM MC_AvailableActions
	ORDER BY [Description]
	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_UpdatePortfolioViews]    Script Date: 03/24/2009 13:35:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_UpdatePortfolioViews]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [CWX_MC_UpdatePortfolioViews]
	-- Add the parameters for the stored procedure here
	@PortfolioID		INT
	, @PortfolioName	VarChar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    UPDATE MC_PortfolioViews
	SET [Name] = @PortfolioName	
	WHERE ID = @PortfolioID

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_GetPortfolioViews]    Script Date: 03/24/2009 13:35:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_GetPortfolioViews]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Suzette M. Dimasaca
-- Create date: Dec. 10, 2008
-- Description:	This will get records from MC_PortfolioViews table
-- =============================================
CREATE PROCEDURE [CWX_MC_GetPortfolioViews]
	@ViewID int = null
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @ViewID < 0
		SET @ViewID = null

    SELECT ID, [Name], [LastModified] FROM MC_PortfolioViews
	Where (ID = @ViewID OR @ViewID IS NULL)
	ORDER BY [Name] ASC
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_DeletePortfolioViews]    Script Date: 03/24/2009 13:35:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_DeletePortfolioViews]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [CWX_MC_DeletePortfolioViews]
	-- Add the parameters for the stored procedure here
	@PortfolioViewsID	INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DELETE FROM MC_PortfolioViewDetails
	WHERE PortfolioViewID = @PortfolioViewsID

	DELETE FROM MC_PortfolioViews
	WHERE ID = @PortfolioViewsID

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_AddNewPortfolioViews]    Script Date: 03/24/2009 13:35:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_AddNewPortfolioViews]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [CWX_MC_AddNewPortfolioViews]
	-- Add the parameters for the stored procedure here
	@PortfolioName	VarChar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO MC_PortfolioViews
	([Name])
	Values (@PortfolioName)
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_GetPortfolioViewDetails]    Script Date: 03/24/2009 13:35:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_GetPortfolioViewDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE Procedure [CWX_MC_GetPortfolioViewDetails]
@PortfolioViewID int
AS
BEGIN
	SELECT MC_PortfolioViewDetails.id AS PortfolioDetailsID, MC_PortfolioViewDetails.portfolioViewId, MC_PortfolioViewDetails.groupByField AS DetailsGroupField, 
		MC_PortfolioViewDetails.sequence, MC_PortfolioViewDetails.lastModified, MC_PortfolioType.GroupByValue, GroupByField
	FROM MC_PortfolioViewDetails LEFT OUTER JOIN
		MC_PortfolioType ON MC_PortfolioViewDetails.groupByField = MC_PortfolioType.ID Where PortfolioViewID = @PortfolioViewID
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_GetPortfolioAccountViews]    Script Date: 03/24/2009 13:35:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_GetPortfolioAccountViews]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [CWX_MC_GetPortfolioAccountViews]
	-- Add the parameters for the stored procedure here
	@PortfolioViewID			INT
	, @Action					VarChar(10)
	, @PortfolioViewDetailsID	INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @Action = ''Insert''
	BEGIN
	    SELECT  ID
				, RTrim(Ltrim(GroupByValue)) AS GroupByValue
				, RTrim(LTrim(GroupByMetaName)) AS GroupByMetaName
		FROM MC_PortfolioType
		WHERE ID NOT IN (SELECT GroupByField FROM MC_PortfolioViewDetails
									WHERE PortfolioViewID = @PortfolioViewID)
		ORDER BY GroupByValue ASC
	END
	ELSE
	BEGIN
	    SELECT  ID
				, RTrim(Ltrim(GroupByValue)) AS GroupByValue
				, RTrim(LTrim(GroupByMetaName)) AS GroupByMetaName
		FROM MC_PortfolioType
		WHERE ID NOT IN (SELECT GroupByField FROM MC_PortfolioViewDetails
									WHERE PortfolioViewID = @PortfolioViewID)
		OR ID IN (SELECT GroupByField FROM MC_PortfolioViewDetails
							WHERE ID = @PortfolioViewDetailsID)
		ORDER BY GroupByValue ASC
	END

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeDetailPromiseInfo]    Script Date: 03/24/2009 13:35:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeDetailPromiseInfo]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
	-- Author:		Alvin Marable
	-- Create date: July 2008
	-- Description:	
	-- =============================================

	CREATE PROCEDURE [CWX_MC_EmployeeDetailPromiseInfo] 
		(
			@EmployeeID VARCHAR(25) = '''',
			@DatePromisedFrom DATETIME,
			@DatePromisedTo DATETIME,
			@DatePaidFrom DATETIME,
			@DatePaidTo DATETIME,
			@Status VARCHAR(25) = '''',
			@PageSize INT = 10,
			@PageIndex INT = 0
		
		)
	AS
	BEGIN

		DECLARE @RowCount int
		SELECT 
			@RowCount = COUNT(Account.AccountID)
		FROM Employee
		LEFT JOIN AccountPromise Promise
		ON  Employee.EmployeeID = Promise.EmployeeID
			AND 
			(
				CASE 
					WHEN Promise.Status = 0 THEN DatePromised 
					WHEN Promise.Status = 1  OR Promise.Status = 2 THEN DatePaid 
					WHEN Promise.Status = 3  THEN DateBroken 
					ELSE DatePromised 
				END 
					BETWEEN  
						CASE 
							WHEN Promise.Status = 0 THEN CONVERT(DATETIME,@DatePromisedFrom,110) 
							WHEN Promise.Status = 1  OR Promise.Status = 2 THEN CONVERT(DATETIME,@DatePaidFrom,110)
							WHEN Promise.Status = 3  THEN CONVERT(DATETIME,@DatePromisedFrom,110) 
							ELSE CONVERT(DATETIME,@DatePromisedFrom,110) 
						END  
						AND 
						CASE 
							WHEN Promise.Status = 0 THEN CONVERT(DATETIME,@DatePromisedTo,110) 
							WHEN Promise.Status = 1  OR Promise.Status = 2 THEN CONVERT(DATETIME,@DatePaidTo,110)
							WHEN Promise.Status = 3  THEN CONVERT(DATETIME,@DatePromisedTo,110) 
							ELSE CONVERT(DATETIME,@DatePromisedTo,110) 
						END  
			)
		INNER JOIN Account 
		ON Promise.AccountID = Account.AccountID
		LEFT JOIN PersonInformation Person
		ON Account.DebtorID = Person.PersonID
		WHERE Employee.EmployeeID = @EmployeeID
	

		DECLARE @BeginIndex int
		DECLARE @EndIndex int
		IF @PageSize > 0
		BEGIN
			SET @BeginIndex = @PageIndex * @PageSize + 1
			SET @EndIndex = (@PageIndex + 1) * @PageSize
		END
		ELSE
		BEGIN
			SET @BeginIndex = 1
			SET @EndIndex = @RowCount
		END

		WITH Temp
		AS
		(
			SELECT 
				ROW_NUMBER() OVER (ORDER BY Employee.EmployeeID) AS RowNumber,
				Employee.EmployeeName, 
				Employee.EmployeeID,
				Account.AccountID,
				ISNULL(Person.LastName,'''') + '', '' + ISNULL(Person.FirstName,'''') + '' '' + ISNULL(Person.MiddleName,'''') PersonName,
				Account.InvoiceNumber,
				CASE WHEN ISNULL(Promise.DateTaken,0) = 0 THEN null ELSE convert(smalldatetime,ISNULL(Promise.DateTaken,''''),102) END DateTaken,
				CASE WHEN ISNULL(Promise.DatePromised,0) = 0 THEN null ELSE convert(smalldatetime,ISNULL(Promise.DatePromised,''''),102) END DatePromised,
				ISNULL(Promise.AmountPromised,0) AmountPromised,
				Promise.Status,
				ISNULL(Promise.AmountPaid,0) AmountPaid,
				CASE WHEN ISNULL(Promise.DatePaid,0) = 0 THEN null ELSE convert(smalldatetime,ISNULL(Promise.DatePaid,''''),102) END DatePaid,
				CASE WHEN ISNULL(Promise.DateBroken,0) = 0 THEN null ELSE convert(smalldatetime,ISNULL(Promise.DateBroken,''''),102) END DateBroken
			FROM Employee
			LEFT JOIN AccountPromise Promise
			ON  Employee.EmployeeID = Promise.EmployeeID
				AND 
			(
				CASE 
					WHEN Promise.Status = 0 THEN DatePromised 
					WHEN Promise.Status = 1  OR Promise.Status = 2 THEN DatePaid 
					WHEN Promise.Status = 3  THEN DateBroken 
					ELSE DatePromised 
				END 
					BETWEEN  
						CASE 
							WHEN Promise.Status = 0 THEN CONVERT(DATETIME,@DatePromisedFrom,110) 
							WHEN Promise.Status = 1  OR Promise.Status = 2 THEN CONVERT(DATETIME,@DatePaidFrom,110)
							WHEN Promise.Status = 3  THEN CONVERT(DATETIME,@DatePromisedFrom,110) 
							ELSE CONVERT(DATETIME,@DatePromisedFrom,110) 
						END  
						AND 
						CASE 
							WHEN Promise.Status = 0 THEN CONVERT(DATETIME,@DatePromisedTo,110) 
							WHEN Promise.Status = 1  OR Promise.Status = 2 THEN CONVERT(DATETIME,@DatePaidTo,110)
							WHEN Promise.Status = 3  THEN CONVERT(DATETIME,@DatePromisedTo,110) 
							ELSE CONVERT(DATETIME,@DatePromisedTo,110) 
						END  
			)
			INNER JOIN Account 
			ON Promise.AccountID = Account.AccountID
			LEFT JOIN PersonInformation Person
			ON Account.DebtorID = Person.PersonID
			WHERE Employee.EmployeeID = @EmployeeID
		)

		SELECT *
		FROM Temp
		WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex
		
		RETURN @RowCount
	END

	' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeRanking_Get]    Script Date: 03/24/2009 13:35:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeRanking_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
	-- Author:		Aldous Nochefranca
	-- Create date: 07/16/2008
	-- Description:	Employee Ranking
	-- =============================================
	--CWX_MC_EmployeeRanking_Get ''1001,1002,1003,1004,1005,1006,1007,1008,1009'',''1/1/2006'',''9/1/2008''
	CREATE PROCEDURE [CWX_MC_EmployeeRanking_Get] 
	(
		@EmployeeIDList varchar(max),
		@StartDate datetime,
		@EndDate datetime
	)
	AS
	BEGIN

	Set @StartDate=Cast(Convert(varchar(10), @StartDate, 101) as datetime)
	Set @EndDate=Cast(Convert(varchar(10), @EndDate, 101) as datetime)

	Create Table #EmployeeProductivity(EmployeeID int, EmployeeName varchar(50), AccountsReviewed int, 
			AccountsActioned int, TotalActions int, InboundCalls int, OutboundCalls int, TotalCalls int,
			AccountsWorked int, AccountsContacted int, AccountsPromised int, PromiseAmountTaken float,
			WorkedRatio float, ContactRatio float, PromiseRatio float,
			InboundCallsTarget float, OutboundCallsTarget float, AccountsWorkedTarget float, AccountsContactedTarget float,
			AccountsPromisedTarget float, PromiseAmountTakenTarget float,
			PromiseToPay float, Contact float, NoContact float)

	DECLARE @EmployeeID varchar(10)
	DECLARE cursorEmployeeProductivity CURSOR FOR Select SplitedText From dbo.CWX_FnSplitString(@EmployeeIDList,'','') ORDER BY ID

	OPEN cursorEmployeeProductivity
	FETCH NEXT FROM cursorEmployeeProductivity INTO @EmployeeID

	WHILE @@FETCH_STATUS = 0
	BEGIN
		Declare @IsValidNumber int
		Set @IsValidNumber = (Select ISNUMERIC(@EmployeeID))
		--PRINT ''Contact Name: '' + @EmployeeID
		
		if(@IsValidNumber=1)
			Begin
				If(Select Count(*) From Employee Where EmployeeID = Cast(@EmployeeID as int))>0
				Begin
					Declare @intEmployeeID int
					Declare @EmployeeName varchar(50)
					Declare @AccountsReviewed float
					Declare @AccountsActioned float
					Declare @TotalActions float
					Declare @InboundCalls float
					Declare @OutboundCalls float
					Declare @PromiseToPay float
					Declare @Contact float
					Declare @NoContact float
					Declare @AccountsWorked float
					Declare @AccountsContacted float
					Declare @AccountsPromised float
					Declare @PromiseAmountTaken float

					Declare @InboundCallsTarget float
					Declare @OutboundCallsTarget float
					Declare @AccountsWorkedTarget float
					Declare @AccountsContactedTarget float
					Declare @AccountsPromisedTarget float
					Declare @PromiseAmountTakenTarget float

					SET @intEmployeeID = Cast(@EmployeeID as int)
					SET @EmployeeName = (SELECT EmployeeName From Employee Where EmployeeID = @intEmployeeID)
					SET @AccountsReviewed = dbo.MC_fnAccountsReviewed(@intEmployeeID, @StartDate, @EndDate)
					SET @AccountsActioned = dbo.MC_fnAccountsActioned(@intEmployeeID, @StartDate, @EndDate)
					SET @TotalActions = dbo.MC_fnTotalActions(@intEmployeeID, @StartDate, @EndDate)
					SET @InboundCalls = dbo.MC_fnInboundCalls(@intEmployeeID, @StartDate, @EndDate)
					SET @OutboundCalls = dbo.MC_fnOutboundCalls(@intEmployeeID, @StartDate, @EndDate)

					SET @PromiseToPay = (SELECT Count(Distinct AccountID) FROM AccountActions INNER JOIN AvailableActions ON AccountActions.ActionID = AvailableActions.ActionID
									Where ProductivityID=1 AND CompletedBy=@EmployeeID AND (Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)>=@StartDate AND Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)<=@EndDate))

					SET @Contact = (SELECT Count(Distinct AccountID) FROM AccountActions INNER JOIN AvailableActions ON AccountActions.ActionID = AvailableActions.ActionID
									Where ProductivityID=2 AND CompletedBy=@EmployeeID AND (Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)>=@StartDate AND Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)<=@EndDate))

					SET @NoContact = (SELECT Count(Distinct AccountID) FROM AccountActions INNER JOIN AvailableActions ON AccountActions.ActionID = AvailableActions.ActionID
									Where ProductivityID=3 AND CompletedBy=@EmployeeID AND (Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)>=@StartDate AND Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)<=@EndDate))

					SET @AccountsWorked = dbo.MC_fnAccountsWorked(@intEmployeeID, @StartDate, @EndDate)
					SET @AccountsContacted = dbo.MC_fnAccountsContacted(@intEmployeeID, @StartDate, @EndDate)
					SET @AccountsPromised = dbo.MC_fnAccountsPromised(@intEmployeeID, @StartDate, @EndDate)
					SET @PromiseAmountTaken = dbo.MC_fnTotalPromiseTaken(@intEmployeeID, @StartDate, @EndDate)

					SET @InboundCallsTarget = ISNULL((Select Top 1 Sum(GoalCount) From EmployeeGoals Where EmployeeID = @intEmployeeID And ActionID = 1001),0)
					SET @OutboundCallsTarget = ISNULL((Select Top 1 Sum(GoalCount) From EmployeeGoals Where EmployeeID = @intEmployeeID And ActionID = 1002),0)
					SET @AccountsWorkedTarget = ISNULL((Select Top 1 GoalCount From EmployeeGoals Where EmployeeID = @intEmployeeID And ActionID = 1003),0)
					SET @AccountsContactedTarget = ISNULL((Select Top 1 GoalCount From EmployeeGoals Where EmployeeID = @intEmployeeID And ActionID = 1004),0)
					SET @AccountsPromisedTarget = ISNULL((Select Top 1 GoalCount From EmployeeGoals Where EmployeeID = @intEmployeeID And ActionID = 1005),0)
					SET @PromiseAmountTakenTarget = ISNULL((Select Top 1 GoalAmount From EmployeeGoals Where EmployeeID = @intEmployeeID And ActionID = 1006),0)

					INSERT INTO #EmployeeProductivity
						(
						EmployeeID, 
						EmployeeName, 
						AccountsReviewed, 
						AccountsActioned, 
						TotalActions, 
						InboundCalls, 
						OutboundCalls, 
						TotalCalls,
						AccountsWorked, 
						AccountsContacted, 
						AccountsPromised, 
						PromiseAmountTaken,
						WorkedRatio,
						ContactRatio,
						PromiseRatio,
						InboundCallsTarget,
						OutboundCallsTarget, 
						AccountsWorkedTarget, 
						AccountsContactedTarget,
						AccountsPromisedTarget, 
						PromiseAmountTakenTarget,
						PromiseToPay,
						Contact,
						NoContact
						)
						VALUES
						(
						@intEmployeeID, 
						@EmployeeName, 
						@AccountsReviewed, 
						@AccountsActioned, 
						@TotalActions, 
						@InboundCalls, 
						@OutboundCalls, 
						@InboundCalls + @OutboundCalls,
						@AccountsWorked, 
						@AccountsContacted, 
						@AccountsPromised, 
						ISNULL(@PromiseAmountTaken,0),
						Case When @AccountsActioned = 0 Then 0 Else @AccountsWorked / @AccountsActioned End,
						Case When @AccountsWorked = 0 Then 0 Else @AccountsContacted / @AccountsWorked End,
						Case When @AccountsContacted = 0 Then 0 Else @AccountsPromised / @AccountsContacted End, 
						@InboundCallsTarget,
						@OutboundCallsTarget, 
						@AccountsWorkedTarget, 
						@AccountsContactedTarget,
						@AccountsPromisedTarget, 
						@PromiseAmountTakenTarget,
						@PromiseToPay,
						@Contact,
						@NoContact
						)
				End
			End

		FETCH NEXT FROM cursorEmployeeProductivity INTO @EmployeeID
	END

	CLOSE cursorEmployeeProductivity
	DEALLOCATE cursorEmployeeProductivity

	Select * From #EmployeeProductivity

	END
	' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeProductivity_Get]    Script Date: 03/24/2009 13:35:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeProductivity_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--CWX_MC_EmployeeProductivity_Get 1001,''1/1/2006'',''1/1/2009''
	CREATE Procedure [CWX_MC_EmployeeProductivity_Get]
	(
		@EmployeeID int,
		@StartDate datetime,
		@EndDate datetime
	)
	As
	Begin

	Set @StartDate=Cast(Convert(varchar(10), @StartDate, 101) as datetime)
	Set @EndDate=Cast(Convert(varchar(10), @EndDate, 101) as datetime)

	Create Table #EmployeeProductivity(FieldID int, metaName varchar(50), FieldName varchar(50), TotalCount float, Target float, TargetAchieved float, AveragePerDay float,
			InboundCallsTarget float, OutboundCallsTarget float, AccountsWorkedTarget float, AccountsContactedTarget float,
			AccountsPromisedTarget float, PromiseAmountTakenTarget float)

	Insert #EmployeeProductivity
		Select id as FieldID, metaName, caption as FieldName, 0 as TotalCount,null,null,null,null,null,null,null,null,null From MC_DataDictionary Where parentID=423

	IF(@EmployeeID>0 AND @StartDate IS NOT NULL AND @EndDate IS NOT NULL)
	Begin

	Declare @AccountsReviewed float
	Declare @AccountsActioned float
	Declare @TotalActions float
	Declare @TotalInbound float
	Declare @TotalOutbound float
	Declare @TotalCalls float
	Declare @AccountsWorked float
	Declare @AccountsContacted float
	Declare @AccountsPromised float
	Declare @TotalPromiseTaken float

	Declare @InboundCallsTarget float
	Declare @OutboundCallsTarget float
	Declare @TotalCallsTarget float
	Declare @AccountsWorkedTarget float
	Declare @AccountsContactedTarget float
	Declare @AccountsPromisedTarget float
	Declare @PromiseAmountTakenTarget float

	Declare @EmployeeWorkingDays float

	SET @EmployeeWorkingDays = (Select dbo.MC_fnEmployeeWorkingDays(@EmployeeID, @StartDate, @EndDate))

	SET @AccountsReviewed = dbo.MC_fnAccountsReviewed(@EmployeeID, @StartDate, @EndDate)
	SET @AccountsActioned = dbo.MC_fnAccountsActioned(@EmployeeID, @StartDate, @EndDate)
	SET @TotalActions = dbo.MC_fnTotalActions(@EmployeeID, @StartDate, @EndDate)

	SET @TotalInbound = dbo.MC_fnInboundCalls(@EmployeeID, @StartDate, @EndDate)
	SET @TotalOutbound = dbo.MC_fnOutboundCalls(@EmployeeID, @StartDate, @EndDate)
	SET @TotalCalls = @TotalInbound + @TotalOutbound
	SET @AccountsWorked = dbo.MC_fnAccountsWorked(@EmployeeID, @StartDate, @EndDate)
	SET @AccountsContacted = dbo.MC_fnAccountsContacted(@EmployeeID, @StartDate, @EndDate)
	SET @AccountsPromised = dbo.MC_fnAccountsPromised(@EmployeeID, @StartDate, @EndDate)
	SET @TotalPromiseTaken = dbo.MC_fnTotalPromiseTaken(@EmployeeID, @StartDate, @EndDate)

	SET @InboundCallsTarget = ISNULL((Select Top 1 Sum(GoalCount) From EmployeeGoals Where (StartDate>=@StartDate And StartDate<@EndDate) AND EmployeeID = @EmployeeID And ActionID = 1),0)*@EmployeeWorkingDays
	SET @OutboundCallsTarget = ISNULL((Select Top 1 Sum(GoalCount) From EmployeeGoals Where (StartDate>=@StartDate And StartDate<@EndDate) AND EmployeeID = @EmployeeID And ActionID = 2),0)*@EmployeeWorkingDays
	SET @TotalCallsTarget = ISNULL(@InboundCallsTarget + @OutboundCallsTarget,0)*@EmployeeWorkingDays
	SET @AccountsWorkedTarget = ISNULL((Select Top 1 GoalCount From EmployeeGoals Where (StartDate>=@StartDate And StartDate<@EndDate) AND EmployeeID = @EmployeeID And ActionID = 4),0)*@EmployeeWorkingDays
	SET @AccountsContactedTarget = ISNULL((Select Top 1 GoalCount From EmployeeGoals Where (StartDate>=@StartDate And StartDate<@EndDate) AND EmployeeID = @EmployeeID And ActionID = 5),0)*@EmployeeWorkingDays
	SET @AccountsPromisedTarget = ISNULL((Select Top 1 GoalCount From EmployeeGoals Where (StartDate>=@StartDate And StartDate<@EndDate) AND EmployeeID = @EmployeeID And ActionID = 6),0)*@EmployeeWorkingDays
	SET @PromiseAmountTakenTarget = ISNULL((Select Top 1 GoalAmount From EmployeeGoals Where (StartDate>=@StartDate And StartDate<@EndDate) AND EmployeeID = @EmployeeID And ActionID = 6),0)*@EmployeeWorkingDays

	-- Count Numbers
	Update #EmployeeProductivity Set TotalCount= @AccountsReviewed,
		Target=null,
		TargetAchieved=null,
		AveragePerDay=null
		Where metaName=''AccountsReviewed'' --Accounts Reviewed

	Update #EmployeeProductivity Set TotalCount= @AccountsActioned,
		Target=null,
		TargetAchieved=null,
		AveragePerDay=null
		Where metaName=''AccountsActioned'' --Accounts Actioned

	Update #EmployeeProductivity Set TotalCount= @TotalActions,
		Target=null,
		TargetAchieved=null,
		AveragePerDay=null
		Where metaName=''TotalActions'' --Actions

	Update #EmployeeProductivity Set TotalCount= @TotalCalls,
		Target=ISNULL(@TotalCallsTarget,0),
		TargetAchieved=(CASE WHEN (@InboundCallsTarget + @OutboundCallsTarget)=0 THEN 0 ELSE @TotalCalls/(@InboundCallsTarget + @OutboundCallsTarget) END),
		AveragePerDay=(CASE WHEN @EmployeeWorkingDays=0 THEN 0 ELSE @TotalCalls/@EmployeeWorkingDays END)
		Where metaName=''TotalCalls'' --Total Calls

	Update #EmployeeProductivity Set TotalCount= @AccountsWorked, 
		Target=ISNULL(@AccountsWorkedTarget,0),
		TargetAchieved=(CASE WHEN @AccountsWorkedTarget=0 THEN 0 ELSE @AccountsWorked/@AccountsWorkedTarget END),
		AveragePerDay=(CASE WHEN @EmployeeWorkingDays=0 THEN 0 ELSE @AccountsWorked/@EmployeeWorkingDays END)
		Where metaName=''AccountsWorked'' --Accounts Worked

	Update #EmployeeProductivity Set TotalCount= @AccountsContacted,
		Target=ISNULL(@AccountsContactedTarget,0),
		TargetAchieved=(CASE WHEN @AccountsContactedTarget=0 THEN 0 ELSE @AccountsContacted/@AccountsContactedTarget END),
		AveragePerDay=(CASE WHEN @EmployeeWorkingDays=0 THEN 0 ELSE @AccountsContacted/@EmployeeWorkingDays END)
		Where metaName=''AccountsContacted'' --Accounts Contacted

	Update #EmployeeProductivity Set TotalCount= @AccountsPromised,
		Target=ISNULL(@AccountsPromisedTarget,0),
		TargetAchieved=(CASE WHEN @AccountsPromisedTarget=0 THEN 0 ELSE @AccountsPromised/@AccountsPromisedTarget END),
		AveragePerDay=(CASE WHEN @EmployeeWorkingDays=0 THEN 0 ELSE @AccountsPromised/@EmployeeWorkingDays END)
		Where metaName=''AccountsPromised'' --Accounts Promised

	Update #EmployeeProductivity Set TotalCount= ISNULL(@TotalPromiseTaken,0),
		Target=ISNULL(@PromiseAmountTakenTarget,0),
		TargetAchieved=(CASE WHEN @PromiseAmountTakenTarget=0 THEN 0 ELSE @TotalPromiseTaken/@PromiseAmountTakenTarget END),
		AveragePerDay=(CASE WHEN @EmployeeWorkingDays=0 THEN 0 ELSE @TotalPromiseTaken/@EmployeeWorkingDays END)
		Where metaName=''TotalPromiseTaken'' --Total Promise Taken


	End

	Select * From #EmployeeProductivity

	End' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_Employee_Search]    Script Date: 03/24/2009 13:35:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_Employee_Search]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
	-- =============================================
	-- Author:		LongNguyen
	--				Alvin Marable
	-- Create date: Dec 15, 2007
	-- Description:	
	-- =============================================
	create PROCEDURE [CWX_MC_Employee_Search]
		@EmployeeID int = 0,
		@EmployeeName varchar(50) = '''',
		@Department int = 0,
		@SupervisorID int = 0,
		@RoleID int = 0,
		@PageSize int = 10,
		@PageIndex int = 0
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		--This only used in MainPage (Refer to), if employee is supervisor -> only select supervisor
		DECLARE @Supervisor bit
		IF @EmployeeID > 0
			SELECT	@Supervisor = Supervisor	
			FROM	Employee
			WHERE	EmployeeID = @EmployeeID

		DECLARE @RowCount int
		SELECT
			@RowCount = COUNT(e.EmployeeID)
		FROM Employee e
		LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID
		WHERE
			(e.EmployeeName LIKE (''%'' + @EmployeeName + ''%''))
			AND (@Department = 0 OR e.Department = @Department)
			AND (@RoleID = 0 OR e.RoleID = @RoleID)
			AND (ISNULL(EmployeeStatus, '''') <> ''R'')
			AND (@SupervisorID = 0 OR e.SuperVisorId = @SupervisorID)
			AND (ISNULL(@Supervisor, 1) = 1 OR e.Supervisor = 1)

		DECLARE @BeginIndex int
		DECLARE @EndIndex int
		IF @PageSize > 0
		BEGIN
			SET @BeginIndex = @PageIndex * @PageSize + 1
			SET @EndIndex = (@PageIndex + 1) * @PageSize
		END
		ELSE
		BEGIN
			SET @BeginIndex = 1
			SET @EndIndex = @RowCount
		END

		WITH Temp
		AS
		(
			SELECT
				ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber,
				e.EmployeeID,
				e.UserID,
				e.EmployeeName,
				ISNULL(d.DeptDesc, '''') AS Department,
				e.RoleID,
				e.Description,
				CASE e.Supervisor WHEN 1 THEN ''Y'' ELSE '''' END AS Supervisor
			FROM Employee e
			LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID
			WHERE
				(e.EmployeeName LIKE (''%'' + @EmployeeName + ''%''))
				AND (@Department = 0 OR e.Department = @Department)
				AND (@RoleID = 0 OR e.RoleID = @RoleID)
				AND (ISNULL(EmployeeStatus, '''') <> ''R'')
				AND (@SupervisorID = 0 OR e.SuperVisorId = @SupervisorID)
				AND (ISNULL(@Supervisor, 1) = 1 OR e.Supervisor = 1)
		)

		SELECT *
		FROM Temp
		WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex
		
		RETURN @RowCount
	END
	' 
END
GO
PRINT 'Done Creating Stored Procedures for MC'
PRINT 'Creating MC DB Functions'
GO

/****** Object:  UserDefinedFunction [dbo].[MC_fnTotalActions]    Script Date: 03/26/2009 16:02:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnTotalActions]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [MC_fnTotalActions]
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnTotalPromiseTaken]    Script Date: 03/26/2009 16:02:08 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnTotalPromiseTaken]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [MC_fnTotalPromiseTaken]
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnAccountsContacted]    Script Date: 03/26/2009 16:02:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnAccountsContacted]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [MC_fnAccountsContacted]
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnAccountsPromised]    Script Date: 03/26/2009 16:02:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnAccountsPromised]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [MC_fnAccountsPromised]
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnOutboundCalls]    Script Date: 03/26/2009 16:02:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnOutboundCalls]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [MC_fnOutboundCalls]
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnAccountsWorked]    Script Date: 03/26/2009 16:02:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnAccountsWorked]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [MC_fnAccountsWorked]
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnInboundCalls]    Script Date: 03/26/2009 16:02:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnInboundCalls]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [MC_fnInboundCalls]
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnAccountsReviewed]    Script Date: 03/26/2009 16:02:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnAccountsReviewed]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [MC_fnAccountsReviewed]
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnAccountsActioned]    Script Date: 03/26/2009 16:02:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnAccountsActioned]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [MC_fnAccountsActioned]
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnEmployeeWorkingDays]    Script Date: 03/26/2009 16:02:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnEmployeeWorkingDays]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [MC_fnEmployeeWorkingDays]
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnTotalPromiseTaken]    Script Date: 03/26/2009 16:02:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnTotalPromiseTaken]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Aldous Nochefranca
-- Create date: 7/15/2008
-- Description:	Get Total Promise Taken
-- =============================================
CREATE FUNCTION [MC_fnTotalPromiseTaken]
(
	-- Add the parameters for the function here
	@EmployeeID int,
	@StartDate datetime,
	@EndDate datetime
)
RETURNS int
AS
BEGIN
	DECLARE @Result float

	SET @Result = (SELECT SUM(ISNULL(AmountPromised,0)) FROM AccountPromise
				Where EmployeeID=@EmployeeID  AND (Cast(Convert(varchar(10),DatePromised,101) AS Datetime)>=@StartDate AND Cast(Convert(varchar(10),DatePromised,101) AS Datetime)<=@EndDate))

	RETURN @Result

END

' 
END
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnAccountsContacted]    Script Date: 03/26/2009 16:02:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnAccountsContacted]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Aldous Nochefranca
-- Create date: 7/15/2008
-- Description:	Get Total Accounts Contacted
-- =============================================
CREATE FUNCTION [MC_fnAccountsContacted]
(
	-- Add the parameters for the function here
	@EmployeeID int,
	@StartDate datetime,
	@EndDate datetime
)
RETURNS int
AS
BEGIN
	DECLARE @Result int

	SET @Result = (SELECT Count(Distinct AccountID) FROM AccountActions INNER JOIN AvailableActions ON AccountActions.ActionID = AvailableActions.ActionID
				Where ProductivityID=2 AND CompletedBy=@EmployeeID AND (Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)>=@StartDate AND Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)<=@EndDate))

	RETURN @Result

END
' 
END
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnAccountsPromised]    Script Date: 03/26/2009 16:02:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnAccountsPromised]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Aldous Nochefranca
-- Create date: 7/15/2008
-- Description:	Get Total Accounts Promised
-- =============================================
CREATE FUNCTION [MC_fnAccountsPromised]
(
	-- Add the parameters for the function here
	@EmployeeID int,
	@StartDate datetime,
	@EndDate datetime
)
RETURNS int
AS
BEGIN
	DECLARE @Result int

	SET @Result = (SELECT Count(Distinct AccountID) FROM AccountActions INNER JOIN AvailableActions ON AccountActions.ActionID = AvailableActions.ActionID
				Where ProductivityID=1 AND CompletedBy=@EmployeeID AND (Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)>=@StartDate AND Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)<=@EndDate))

	RETURN @Result

END
' 
END
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnOutboundCalls]    Script Date: 03/26/2009 16:02:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnOutboundCalls]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Aldous Nochefranca
-- Create date: 7/15/2008
-- Description:	Get Total Outbound Calls
-- =============================================
CREATE FUNCTION [MC_fnOutboundCalls]
(
	-- Add the parameters for the function here
	@EmployeeID int,
	@StartDate datetime,
	@EndDate datetime
)
RETURNS int
AS
BEGIN
	DECLARE @Result int

	SET @Result = (SELECT Count(RecordID) FROM AccountActions INNER JOIN AvailableActions ON AccountActions.ActionID = AvailableActions.ActionID
				Where Category=2 AND CompletedBy=@EmployeeID AND (Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)>=@StartDate AND Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)<=@EndDate))

	RETURN @Result

END
' 
END
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnAccountsReviewed]    Script Date: 03/26/2009 16:02:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnAccountsReviewed]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Aldous Nochefranca
-- Create date: 7/15/2008
-- Description:	Get Total Accounts Reviewed
-- =============================================
CREATE FUNCTION [MC_fnAccountsReviewed] 
(
	-- Add the parameters for the function here
	@EmployeeID int,
	@StartDate datetime,
	@EndDate datetime
)
RETURNS int
AS
BEGIN
	DECLARE @Result int

	SET @Result = (Select Count(Distinct AccountID) from AccountActions Where ActionID=8 AND ResponsibleParty=@EmployeeID  AND (Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)>=@StartDate AND Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)<=@EndDate))

	RETURN @Result

END
' 
END
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnAccountsActioned]    Script Date: 03/26/2009 16:02:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnAccountsActioned]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Aldous Nochefranca
-- Create date: 7/15/2008
-- Description:	Get Total Accounts Actioned
-- =============================================
CREATE FUNCTION [MC_fnAccountsActioned]
(
	-- Add the parameters for the function here
	@EmployeeID int,
	@StartDate datetime,
	@EndDate datetime
)
RETURNS int
AS
BEGIN
	DECLARE @Result int

	SET @Result = (Select Count(Distinct AccountID) from AccountActions Where ResponsibleParty=@EmployeeID  AND (Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)>=@StartDate AND Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)<=@EndDate))

	RETURN @Result

END
' 
END
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnTotalActions]    Script Date: 03/26/2009 16:02:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnTotalActions]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Aldous Nochefranca
-- Create date: 7/15/2008
-- Description:	Get Total Actions
-- =============================================
CREATE FUNCTION [MC_fnTotalActions]
(
	-- Add the parameters for the function here
	@EmployeeID int,
	@StartDate datetime,
	@EndDate datetime
)
RETURNS int
AS
BEGIN
	DECLARE @Result int

	SET @Result = (Select Count(AccountID) from AccountActions Where ResponsibleParty=@EmployeeID  AND (Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)>=@StartDate AND Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)<=@EndDate))

	RETURN @Result

END
' 
END
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnAccountsWorked]    Script Date: 03/26/2009 16:02:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnAccountsWorked]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Aldous Nochefranca
-- Create date: 7/15/2008
-- Description:	Get Total Accounts Worked
-- =============================================
Create FUNCTION [MC_fnAccountsWorked]
(
	-- Add the parameters for the function here
	@EmployeeID int,
	@StartDate datetime,
	@EndDate datetime
)
RETURNS int
AS
BEGIN
	DECLARE @Result int

	SET @Result = (SELECT Count(Distinct AccountID) FROM AccountActions INNER JOIN AvailableActions ON AccountActions.ActionID = AvailableActions.ActionID
				Where ConsiderWorked=1 AND CompletedBy=@EmployeeID AND (Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)>=@StartDate AND Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)<=@EndDate))

	RETURN @Result

END
' 
END
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnInboundCalls]    Script Date: 03/26/2009 16:02:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnInboundCalls]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Aldous Nochefranca
-- Create date: 7/15/2008
-- Description:	Get Total Actions
-- =============================================
CREATE FUNCTION [MC_fnInboundCalls]
(
	-- Add the parameters for the function here
	@EmployeeID int,
	@StartDate datetime,
	@EndDate datetime
)
RETURNS int
AS
BEGIN
	DECLARE @Result int

	SET @Result = (SELECT Count(RecordID) FROM AccountActions INNER JOIN AvailableActions ON AccountActions.ActionID = AvailableActions.ActionID
				Where Category=1 AND CompletedBy=@EmployeeID AND (Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)>=@StartDate AND Cast(Convert(varchar(10),DateCompleted,101) AS Datetime)<=@EndDate))

	RETURN @Result

END
' 
END
GO
/****** Object:  UserDefinedFunction [dbo].[MC_fnEmployeeWorkingDays]    Script Date: 03/26/2009 16:02:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[MC_fnEmployeeWorkingDays]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Aldous Nochefranca
-- Create date: 07/21/2008
-- Description:	Get Number of Working Days
-- =============================================
CREATE FUNCTION [MC_fnEmployeeWorkingDays] 
(
	-- Add the parameters for the function here
	@EmployeeID int,
	@StartDate datetime,
	@EndDate datetime
)
RETURNS int
AS
BEGIN
	DECLARE @Result int
	Declare @OrganizationalBlackOutDates float
	Declare @EmployeeBlackOutDates float

	Set @OrganizationalBlackOutDates = (SELECT  Count(*) FROM BlackOutDates 
		WHERE (DateToBlackOut Between @StartDate And @EndDate) AND Employee=Null)

	Set @EmployeeBlackOutDates = (SELECT  Count(*) FROM BlackOutDates 
		WHERE (DateToBlackOut Between @StartDate And @EndDate) AND Employee=@EmployeeID)

	SELECT @Result = (DateDiff(day,@StartDate,@EndDate) + 1) - (@OrganizationalBlackOutDates + @EmployeeBlackOutDates)

	RETURN @Result

END
' 
END
GO
PRINT 'Done Creating Functions'
PRINT 'Finished'
GO