﻿
-----------------------------ThanhNguyen------------------------------------------------------------------
IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientStatus]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_ClientStatus](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](100) NULL,
	[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientStatus_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_CWX_ClientStatus] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCategory]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_ClientCategory](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](100) NULL,
	[Status] [char](1) NULL CONSTRAINT [DF_CWX_ClientCategory_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_CWX_ClientCategory] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCategory_IsDescriptionExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCategory_IsDescriptionExisted]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: May 12 2009
-- Description:	Check if an Descitpion is existed in table CWX_ClientCategory
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCategory_IsDescriptionExisted]
	-- Add the parameters for the stored procedure here
	@ClientCategoryID int,
	@Description varchar(100) = ''	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS (SELECT 1 FROM CWX_ClientCategory 
				WHERE	@Description <> '' 
						AND CWX_ClientCategory.Description = @Description 
						AND CWX_ClientCategory.ID <> @ClientCategoryID
						AND CWX_ClientCategory.Status <>'R')
		RETURN 1
	ELSE 
		RETURN 0
END

GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCategory_SoftDeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCategory_SoftDeleteAll]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: May 12, 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCategory_SoftDeleteAll] 	
AS
BEGIN
	UPDATE
		CWX_ClientCategory
	SET
		Status = 'R'	
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientStatus_IsDescriptionExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientStatus_IsDescriptionExisted]

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: May 13 2009
-- Description:	Check if an Descitpion is existed in table CWX_ClientStatus
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientStatus_IsDescriptionExisted]
	-- Add the parameters for the stored procedure here
	@ClientStatusID int,
	@Description varchar(100) = ''	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS (SELECT 1 FROM CWX_ClientStatus as cs 
				WHERE	@Description <> '' 
						AND cs.Description = @Description 
						AND cs.ID <> @ClientStatusID
						AND cs.Status <>'R')
		RETURN 1
	ELSE 
		RETURN 0
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientStatus_SoftDeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientStatus_SoftDeleteAll]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: May 13, 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientStatus_SoftDeleteAll] 	
AS
BEGIN
	UPDATE
		CWX_ClientStatus
	SET
		Status = 'R'
	WHERE Status <> 'R'	
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTaxTranType_GetListBaseOnClient]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientTaxTranType_GetListBaseOnClient]
GO

-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 19, 2009
-- Description:	Get ClientTaxTranType base on ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientTaxTranType_GetListBaseOnClient]
	@ClientID int,
	@User int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	TaxTranType.ID, FT.Description as FinancialType, 
			ISNULL(TT.Description,'') as TransactionType, TaxTranType.TaxRate

	FROM	CWX_ClientTaxTranType TaxTranType LEFT JOIN CWX_FinancialType FT ON TaxTranType.FinancialTypeID = FT.FinancialTypeID
			LEFT JOIN TransactionType TT ON TaxTranType.TransactionTypeID = TT.ID

	WHERE	TaxTranType.ClientID = @ClientID AND 
			TaxTranType.UserID = @User AND
			TaxTranType.Status = 'A'			
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTaxTranType_SaveData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientTaxTranType_SaveData]
GO

-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 20, 2009
-- Description:	Save ClientTaxTranType
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientTaxTranType_SaveData]
	@ClientID int,
	@FinancialTypeID int,
	@TransactionTypeID int,
	@TaxRate decimal(19,5),
	@CreateDate datetime,
	@UpdateDate datetime,
	@UserID int,
	@ClientNoteDescription nvarchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;		
    -- Insert statements for procedure here
	IF( EXISTS(	SELECT	ID 
				FROM	CWX_ClientTaxTranType 
				WHERE	ClientID = @ClientID AND UserID = @UserID AND 
						FinancialTypeID =@FinancialTypeID AND TransactionTypeID = @TransactionTypeID AND
						[Status] = 'A'
				)
		)
	BEGIN
			UPDATE	CWX_ClientTaxTranType
			SET		TaxRate = @TaxRate, UpdateDate = @UpdateDate
			WHERE	@ClientID = @ClientID AND UserID = @UserID AND
					FinancialTypeID = @FinancialTypeID AND 
					TransactionTypeID = @TransactionTypeID AND
					[Status] = 'A'
			INSERT INTO CWX_ClientNotes VALUES(@UserID,@ClientID,@UpdateDate,@ClientNoteDescription)			
			
	END
	ELSE
	BEGIN
	IF( EXISTS(	SELECT	ID 
				FROM	CWX_ClientTaxTranType 
				WHERE	ClientID = @ClientID AND UserID = @UserID AND 
						FinancialTypeID =@FinancialTypeID AND
						[Status] = 'A'
				) 
		)
	BEGIN
		IF (@TransactionTypeID >=0)
		BEGIN			
			INSERT INTO CWX_ClientTaxTranType VALUES(@ClientID, @FinancialTypeID, @TransactionTypeID, @TaxRate, @CreateDate, @UpdateDate, @UserID, 'A')
			INSERT INTO CWX_ClientNotes VALUES(@UserID,@ClientID,@UpdateDate,@ClientNoteDescription)			
		END
		ELSE
		BEGIN			
			UPDATE	CWX_ClientTaxTranType
			SET		TaxRate = @TaxRate, UpdateDate = @UpdateDate
			WHERE	@ClientID = @ClientID AND UserID = @UserID AND
					FinancialTypeID = @FinancialTypeID AND 					
					[Status] = 'A' AND TransactionTypeID <= 0			
			INSERT INTO CWX_ClientNotes VALUES(@UserID,@ClientID,@UpdateDate,@ClientNoteDescription)			
		END
	END
	ELSE		
	BEGIN		
		INSERT INTO CWX_ClientTaxTranType VALUES(@ClientID, @FinancialTypeID, @TransactionTypeID, @TaxRate, @CreateDate, @UpdateDate, @UserID, 'A')
		INSERT INTO CWX_ClientNotes VALUES(@UserID,@ClientID,@UpdateDate,@ClientNoteDescription)			
	END	
	END		
	RETURN @@ERROR	
	
END
GO
-----------------------------End Of ThanhNguyen------------------------------------------------------------------



---------------------------------- Minh Dam: 26 May 2009 ----------------------------
-- [Minh Dam] [26 May 2009] Add additional columns for "ClientInformation" table
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'HotNote')
BEGIN
    ALTER TABLE ClientInformation
        ADD HotNote nvarchar(255) NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'MasterClientID')
BEGIN
    ALTER TABLE ClientInformation
        ADD MasterClientID int NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'ClientListedDate')
BEGIN
    ALTER TABLE ClientInformation
        ADD ClientListedDate datetime NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'ClientLastUpdatedDate')
BEGIN
    ALTER TABLE ClientInformation
        ADD ClientLastUpdatedDate datetime NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'ClientLastWorkedDate')
BEGIN
    ALTER TABLE ClientInformation
        ADD ClientLastWorkedDate datetime NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'ClientTimeZoneID')
BEGIN
    ALTER TABLE ClientInformation
        ADD ClientTimeZoneID int NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'ClientFirstReferalDate')
BEGIN
    ALTER TABLE ClientInformation
        ADD ClientFirstReferalDate datetime NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'ClientLastReferalDate')
BEGIN
    ALTER TABLE ClientInformation
        ADD ClientLastReferalDate datetime NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'ClientAgencyID')
BEGIN
    ALTER TABLE ClientInformation
        ADD ClientAgencyID varchar(50) NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'ClientRecallDays')
BEGIN
    ALTER TABLE ClientInformation
        ADD ClientRecallDays int NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'ClientCategoryID')
BEGIN
    ALTER TABLE ClientInformation
        ADD ClientCategoryID int NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'ClientStatusID')
BEGIN
    ALTER TABLE ClientInformation
        ADD ClientStatusID int NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'ClientAcknowledgementID')
BEGIN
    ALTER TABLE ClientInformation
        ADD ClientAcknowledgementID int NULL
END
GO


-- [Minh Dam] [26 May 2009]	Create "CWX_ClientNotes" table
/****** Object:  Table [dbo].[CWX_ClientNotes]    Script Date: 05/26/2009 15:57:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientNotes]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientNotes]
GO

/****** Object:  Table [dbo].[CWX_ClientNotes]    Script Date: 05/26/2009 15:57:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CWX_ClientNotes](
	[NoteID] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[ClientID] [int] NOT NULL,
	[NoteDateTime] [datetime] NULL,
	[NoteText] [nvarchar](1000) NULL,
 CONSTRAINT [PK_ClientNotes] PRIMARY KEY CLUSTERED 
(
	[NoteID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


-- [Minh Dam] [26 May 2009] Create "CWX_TimeZone" table
/****** Object:  Table [dbo].[CWX_TimeZone]    Script Date: 05/26/2009 16:00:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TimeZone]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_TimeZone]
GO

/****** Object:  Table [dbo].[CWX_TimeZone]    Script Date: 05/26/2009 16:00:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CWX_TimeZone](
	[TimeZoneID] [int] NOT NULL,
	[ZoneName] [nvarchar](200) NOT NULL,
 CONSTRAINT [PK_CWX_TimeZone] PRIMARY KEY CLUSTERED 
(
	[TimeZoneID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- [Minh Dam] [26 May 2009] Create "CWX_FinancialType" table
/****** Object:  Table [dbo].[CWX_FinancialType]    Script Date: 05/26/2009 16:01:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_FinancialType]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_FinancialType]
GO

/****** Object:  Table [dbo].[CWX_FinancialType]    Script Date: 05/26/2009 16:01:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CWX_FinancialType](
	[FinancialTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Type] [char](1) NOT NULL CONSTRAINT [DF_CWX_FinancialType_System]  DEFAULT ('S'),
	[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_FinancialType_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_CWX_FinancialType] PRIMARY KEY CLUSTERED 
(
	[FinancialTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

-- [Minh Dam] [26 May 2009] Add column "FinancialTypeID" to table "TransactionType"
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'TransactionType' and c.name = 'FinancialTypeID')
BEGIN
    ALTER TABLE TransactionType
        ADD FinancialTypeID int NULL
END
GO

-- [Minh Dam] [26 May 2009] Create "CWX_ClientNotes_GetPagingListByClientID" stored procedure
/****** Object:  StoredProcedure [dbo].[CWX_ClientNotes_GetPagingListByClientID]    Script Date: 05/26/2009 16:03:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientNotes_GetPagingListByClientID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientNotes_GetPagingListByClientID]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientNotes_GetPagingListByClientID]    Script Date: 05/26/2009 16:03:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 13 May 2009
-- Description:	Get notes by client with paging.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientNotes_GetPagingListByClientID]
	@ClientID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @RowCount int

	SELECT @RowCount = COUNT(*)
	FROM CWX_ClientNotes
	WHERE ClientID = @ClientID	

	WITH temp AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY NoteDateTime DESC) AS RowNumber,
				NoteID, a.EmployeeID, ISNULL(b.EmployeeName, '') AS EmployeeName,
				ClientID, NoteDateTime, NoteText
		FROM CWX_ClientNotes a
			LEFT JOIN Employee b ON a.EmployeeID = b.EmployeeID
		WHERE ClientID = @ClientID
	)

	SELECT NoteID, EmployeeID, EmployeeName, ClientID, NoteDateTime, NoteText
	FROM temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

-- [Minh Dam] [26 May 2009] Create "CWX_ClientCommPlanCriteria_DeleteAllByRuleID" stored procedure
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanCriteria_DeleteAllByRuleID]    Script Date: 05/26/2009 16:05:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanCriteria_DeleteAllByRuleID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlanCriteria_DeleteAllByRuleID]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanCriteria_DeleteAllByRuleID]    Script Date: 05/26/2009 16:05:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 20 May 2009
-- Description:	Delete all rule criterias belong to a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlanCriteria_DeleteAllByRuleID]
	@CommPlanRuleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DELETE CWX_ClientCommPlanCriteria
	WHERE ClientCommPlanRuleID = @CommPlanRuleID
END
GO

-- [Minh Dam] [26 May 2009] Create "CWX_ClientCommPlanCriteria_GetListByRuleID" stored procedure
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanCriteria_GetListByRuleID]    Script Date: 05/26/2009 16:06:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanCriteria_GetListByRuleID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlanCriteria_GetListByRuleID]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanCriteria_GetListByRuleID]    Script Date: 05/26/2009 16:06:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 20 May 2009
-- Description:	Gets a list of Commission Plan Rule Criteria by CommissionPlanRuleID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlanCriteria_GetListByRuleID]
	-- Add the parameters for the stored procedure here
	@CommPlanRuleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @Temp table
	(
		COLUMN_NAME varchar(50),
		DESCRIPTION varchar(50),
		DATA_TYPE varchar(25),
		max_length int,
		[precision] int,
		[DATABASE] varchar(50)
	)

	INSERT INTO @Temp
	EXEC CWX_RuleCriteria_GetCriteriaByRuleType 1 -- Account Processing Rule

	SELECT
		c.ID, c.ClientCommPlanRuleID, c.Criteria, c.Operator, c.MatchingCriteria, c.SQLFormat,
		CASE c.ID
			WHEN (SELECT MAX(ID) FROM RuleCriteria WHERE RuleID = c.ClientCommPlanRuleID) THEN ''
			ELSE c.Combining
		END AS Combining,
		t.DESCRIPTION AS DESCRIPTION,
		t.DATA_TYPE AS DataType
	FROM CWX_ClientCommPlanCriteria c
	LEFT JOIN @Temp t ON t.COLUMN_NAME = c.Criteria
	WHERE c.ClientCommPlanRuleID = @CommPlanRuleID
	ORDER BY c.ID
END
GO

-- [Minh Dam] [26 May 2009] Create "CWX_ClientCommPlanCriteria_TestRule" stored procedure
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanCriteria_TestRule]    Script Date: 05/26/2009 16:07:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanCriteria_TestRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlanCriteria_TestRule]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanCriteria_TestRule]    Script Date: 05/26/2009 16:08:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		MInh Dam
-- Create date: 21 May 2009
-- Description:	Retrieve records that match the Commission Plan Rule Criterias of a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlanCriteria_TestRule] 
	-- Add the parameters for the stored procedure here
	@CommPlanRuleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat, Combining
		FROM CWX_ClientCommPlanCriteria
		WHERE ClientCommPlanRuleID = @CommPlanRuleID
		Order By [ID]

	DECLARE @SQLFormat varchar(700)
	DECLARE @Combining varchar(10)
	DECLARE @NeedCombining varchar(10)
	DECLARE @WhereClause varchar(2000)
	DECLARE @IsOpenningBracket bit
	SET @NeedCombining = 'And'
	SET @WhereClause = ''
	SET @IsOpenningBracket = 0

	OPEN RuleCriteriaCrsr
	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF (LOWER(@Combining) = 'or')
			IF (@IsOpenningBracket = 0)
			BEGIN
				SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' (' + @SQLFormat
				SET @IsOpenningBracket = 1
			END
			ELSE
				SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' ' + @SQLFormat
		ELSE
		BEGIN
			SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' ' + @SQLFormat			
			IF (@IsOpenningBracket = 1)
			BEGIN
				SET @WhereClause = @WhereClause + ') '
				SET @IsOpenningBracket = 0
			END
		END

		SET @NeedCombining = @Combining /* remember previous value */
		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	END

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr

	--This is used for AllocationRule, if RuleType=1, append condition <Account.MAINTAINOFFICER = 0>
	DECLARE @RuleType tinyint	
	SET @WhereClause = ' AND Account.MAINTAINOFFICER = 0' + @WhereClause

	DECLARE @Sql varchar(8000)
	SET @Sql = ' SELECT'
				+ ' Account.AccountId,Account.DebtorId,PersonInformation.FirstName,PersonInformation.MiddleName,PersonInformation.LastName,Account.BillBalance,Account.BillAmount,Account.InvoiceNumber'
				+ ' FROM Account'
				+ ' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID'
				+ ' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID'
				+ ' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID'
				+ ' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID'
				+ ' WHERE (PersonAddress.MailingAddress = 1)'
				+ ' AND Account.AgencyStatusID <> 2'-- Donot show closed account
				+ @WhereClause

	EXEC (@Sql)

END
GO

-- [Minh Dam] [26 May 2009] Create "CWX_ClientCommPlanRule_Delete" stored procedure
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanRule_Delete]    Script Date: 05/26/2009 16:09:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanRule_Delete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlanRule_Delete]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanRule_Delete]    Script Date: 05/26/2009 16:09:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 21 May 2009
-- Description:	Delete a Commission Plan Rule and its Criterias
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlanRule_Delete]
	-- Add the parameters for the stored procedure here
	@CommPlanRuleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	BEGIN TRANSACTION

	-- Delete Commission Plan Rule Criterias
	DELETE CWX_ClientCommPlanCriteria
	WHERE ClientCommPlanRuleID = @CommPlanRuleID

	-- Delete Commission Plan Rule
	DELETE CWX_ClientCommPlanRule
	WHERE ID = @CommPlanRuleID
	
	IF @@ERROR = 0
		COMMIT TRANSACTION
	ELSE
		ROLLBACK TRANSACTION
END
GO

-- [Minh Dam] [26 May 2009] Create "CWX_ClientCommPlanRule_DeleteAll" stored procedure
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanRule_DeleteAll]    Script Date: 05/26/2009 16:10:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanRule_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlanRule_DeleteAll]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanRule_DeleteAll]    Script Date: 05/26/2009 16:10:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 21 May 2009
-- Description:	Delete all Commission Plan Rules and their Criterias
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlanRule_DeleteAll]
	-- Add the parameters for the stored procedure here
	@CommPlanID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	BEGIN TRANSACTION

	-- Delete Commission Plan Rule Criterias
	DELETE CWX_ClientCommPlanCriteria
	WHERE ClientCommPlanRuleID IN (SELECT ID FROM CWX_ClientCommPlanRule WHERE ClientCommPlanID = @CommPlanID)

	-- Delete Commission Plan Rule
	DELETE CWX_ClientCommPlanRule
	WHERE ClientCommPlanID = @CommPlanID
	
	IF @@ERROR = 0
		COMMIT TRANSACTION
	ELSE
		ROLLBACK TRANSACTION
END
GO

-- [Minh Dam] [26 May 2009] Create "CWX_ClientCommModel_GetPagingList" stored procedure
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommModel_GetPagingList]    Script Date: 05/26/2009 16:11:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommModel_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommModel_GetPagingList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommModel_GetPagingList]    Script Date: 05/26/2009 16:11:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 25 May 2009
-- Description:	Get list of client commission model with paging
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommModel_GetPagingList]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @RowCount int

	SELECT @RowCount = Count(*)
	FROM CWX_ClientCommModel a
		INNER JOIN ClientInformation b ON a.ClientID = b.ClientID AND b.Status <> 'R'
	WHERE a.Status <> 'R'

    -- Insert statements for procedure here
	WITH temp AS
	(
		SELECT	ROW_NUMBER() OVER (ORDER BY b.ClientName) as RowNumber,
				a.ID,
				b.ClientID, 
				b.ClientName, 
				c.Description as ClientType, 
				a.Code as ModelCode, 
				a.Description as ModelDescription
		FROM CWX_ClientCommModel a
			INNER JOIN ClientInformation b ON a.ClientID = b.ClientID AND b.Status <> 'R'
			LEFT JOIN CWX_ClientType c ON b.ClientTypeID = c.ClientTypeID AND c.Status <> 'R'
		WHERE a.Status <> 'R'
	)

	SELECT ID, ClientID, ClientName, ClientType, ModelCode, ModelDescription
	FROM temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

-- [Minh Dam] [26 May 2009] Create "CWX_ClientInformation_GetNoCommissionModelClients" stored procedure
/****** Object:  StoredProcedure [dbo].[CWX_ClientInformation_GetNoCommissionModelClients]    Script Date: 05/26/2009 16:12:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_GetNoCommissionModelClients]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientInformation_GetNoCommissionModelClients]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientInformation_GetNoCommissionModelClients]    Script Date: 05/26/2009 16:13:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 25 May 2009
-- Description:	Get a list of clients that haven't had Commission Model yet.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientInformation_GetNoCommissionModelClients]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT ClientID, ClientName, cast(ClientID as varchar) + ' - ' + ClientName as ClientIDAndName
	FROM ClientInformation
	WHERE ClientID NOT IN (SELECT ClientID FROM CWX_ClientCommModel WHERE [Status] <> 'R')
	AND [Status] <> 'R'
	ORDER BY ClientName
END
GO

-- [Minh Dam] [26 May 2009] Create "CWX_ClientCommModel_DeleteAll" stored procedure
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommModel_DeleteAll]    Script Date: 05/26/2009 16:13:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommModel_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommModel_DeleteAll]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommModel_DeleteAll]    Script Date: 05/26/2009 16:14:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 26 May 2009
-- Description:	Removes/Marks as deleted all CommissionModels in database.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommModel_DeleteAll]
	-- Add the parameters for the stored procedure here
	@IsSoftDelete bit = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF (@IsSoftDelete = 1)
		UPDATE CWX_ClientCommModel
		SET [Status] = 'R'
		WHERE [Status] <> 'R'		
	ELSE
		DELETE CWX_ClientCommModel
		WHERE [Status] <> 'R'	
END
GO

-- [Minh Dam] [26 May 2009] Create "CWX_ClientCommPlan_DeleteAll" stored procedure
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlan_DeleteAll]    Script Date: 05/26/2009 16:14:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlan_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlan_DeleteAll]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlan_DeleteAll]    Script Date: 05/26/2009 16:14:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 26 May 2009
-- Description:	Removes/Marks as deleted all CommissionPlans in database.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlan_DeleteAll]
	-- Add the parameters for the stored procedure here
	@IsSoftDelete bit = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF (@IsSoftDelete = 1)
		UPDATE CWX_ClientCommPlan
		SET [Status] = 'R'
		WHERE [Status] <> 'R'		
	ELSE
		DELETE CWX_ClientCommPlan
		WHERE [Status] <> 'R'	
END
GO

-----------------------------------------Start ThanhNguyen----------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CalculateAccount_GroupByAccountStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_CalculateAccount_GroupByAccountStatus]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_CalculateAccount_GroupByAccountStatus]    Script Date: 05/28/2009 15:40:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 26, 2009
-- Description:	Summary Account info follow format:
--	Status	Total Account		TotalListAmount		TotalBillBalance
--	Active	5					140.000				15365
--	Legal	6					150.000				165.000		
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_CalculateAccount_GroupByAccountStatus]
	@ClientID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	ast.ShortDesc as [Status], count(a.accountID) as TotalAccount, sum(a.BillAmount) as TotalListAmount, 
			sum(a.BillBalance) as TotalBillBalance

	FROM	Account a INNER JOIN AccountStatus ast ON a.AgencyStatusID = ast.AgencyStatus
	WHERE	(a.ClientID = @ClientID OR @ClientID = 0) AND ast.Type IN ('D','S')
	GROUP BY ast.ShortDesc			
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CalculateAccount_GroupByFinancialType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_CalculateAccount_GroupByFinancialType]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CWX_Account_CalculateAccount_GroupByFinancialType]
	@ClientID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	fnct.description ,sum(c.BillAmount) as TotalAmount
	FROM	account c INNER JOIN transactions t ON c.accountid = t.accountid
			INNER JOIN transactiontype tt ON t.transactiontype = tt.id
			INNER JOIN cwx_financialtype fnct ON tt.financialtypeid = fnct.financialtypeid
	WHERE	(c.clientid = @ClientID OR @ClientID = 0)
	GROUP BY fnct.Description
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetAccountListForClientDebtorsView]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetAccountListForClientDebtorsView]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetAccountListForClientDebtorsView]    Script Date: 05/28/2009 15:41:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 27, 2009
-- Description:	Get account list base on ClientID, AccountStatus, EmployeeID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetAccountListForClientDebtorsView]
	@ClientID int, 
	@AccountStatus int, 
	@EmployeeID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT b.DebtorName, b.AccountNumber, b.BillBalance, b.SubmissionDate,AccountStatus, b.UserName
	FROM (
		SELECT	ROW_NUMBER() OVER (ORDER BY (ISNULL(p.firstName, '') + ' ' + ISNULL(p.lastName,'')) DESC) AS RowNumber,
				(ISNULL(p.firstName, '') + ' ' + ISNULL(p.lastName,'')) as DebtorName,
				a.InvoiceNumber as AccountNumber, a.SubmissionDate, a.BillBalance, ast.ShortDesc as AccountStatus,
				e.EmployeeName as UserName
		FROM	Account a INNER JOIN AccountStatus ast ON a.AgencyStatusID = ast.AgencyStatus
				INNER JOIN Employee e ON a.EmployeeID = e.EmployeeID
				INNER JOIN DebtorInformation d ON a.DebtorID = d.DebtorID
				INNER JOIN PersonInformation p ON d.PersonID = p.PersonID

		WHERE	(a.ClientID = @ClientID OR @ClientID = 0) AND 
				(a.AgencyStatusID = @AccountStatus OR @AccountStatus = 0)AND
				(a.EmployeeID = @EmployeeID	OR @EmployeeID = 0)
	) b
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DECLARE @rowCount int
	SELECT @rowCount = count(*)
	FROM	Account a INNER JOIN AccountStatus ast ON a.AgencyStatusID = ast.AgencyStatus
			INNER JOIN Employee e ON a.EmployeeID = e.EmployeeID
			INNER JOIN DebtorInformation d ON a.DebtorID = d.DebtorID
			INNER JOIN PersonInformation p ON d.PersonID = p.PersonID

	WHERE	(a.ClientID = @ClientID OR @ClientID = 0) AND 
			(a.AgencyStatusID = @AccountStatus OR @AccountStatus = 0)AND
			(a.EmployeeID = @EmployeeID	OR @EmployeeID = 0)

	RETURN @rowCount
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transactons_GetTransactionList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transactons_GetTransactionList]
GO

-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 26, 2009
-- Description:	Get list of payment type (PTA or PTC)
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transactons_GetTransactionList]
	@PaymentType int,
	@ExcludeReversalTran bit,
	@ClientID int,
	@PageSize int = 10,
	@PageIndex int = 0	 	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @Rowcount int
    -- Insert statements for procedure here
	SELECT RowNumber, TransactionID, DebtorName, TransactionType, PaymentType, Amount, Description
	FROM 
	(
		SELECT	ROW_NUMBER() OVER (ORDER BY t.TransactionID DESC) AS RowNumber,
				 t.TransactionID as TransactionID, (p.FirstName + ' ' + p.LastName) as DebtorName, TT.Description as TransactionType,
				CASE 
					WHEN PaymentTypeID = 0 THEN '' 
					WHEN PaymentTypeID = 1 THEN 'PTA'
					WHEN PaymentTypeID = 2 THEN 'PTC'
				ELSE ''
				END as PaymentType,
				t.TransactionAmount as Amount, t.TransactionComment as [Description]
		FROM	Transactions t INNER JOIN Account a ON t.AccountID = a.AccountID
				INNER JOIN TransactionType tt ON t.TransactionType = tt.ID	
				INNER JOIN DebtorInformation d ON a.DebtorID = d.DebtorID
				INNER JOIN PersonInformation p ON d.PersonID = p.PersonID
		WHERE	(t.PaymentTypeID = @PaymentType OR @PaymentType = 0) AND 
				 (t.ReversedFlag <> @ExcludeReversalTran OR @ExcludeReversalTran = 0) AND
				(t.ClientID = @ClientID OR @ClientID = 0)
	) as a
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	SELECT @Rowcount = count(*)
	FROM	Transactions t INNER JOIN Account a ON t.AccountID = a.AccountID
				INNER JOIN TransactionType tt ON t.TransactionType = tt.ID	
				INNER JOIN DebtorInformation d ON a.DebtorID = d.DebtorID
				INNER JOIN PersonInformation p ON d.PersonID = p.PersonID
	WHERE	(t.PaymentTypeID = @PaymentType OR @PaymentType = 0) AND 
			(t.ReversedFlag <> @ExcludeReversalTran OR @ExcludeReversalTran = 0) AND
			(t.ClientID = @ClientID OR @ClientID = 0)

	RETURN @Rowcount			
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTranTypeProperties_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientTranTypeProperties_GetList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientTranTypeProperties_GetList]    Script Date: 05/28/2009 15:44:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen	
-- Create date: May 21, 2009
-- Description:	Get list of client tran type properties
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientTranTypeProperties_GetList]
	@ClientID int,
	@PageSize  int = 10,
	@PageIndex int = 0	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @RowCount int   
	
	SELECT	b.ID, b.ClientID, b.CalculateComm, b.CalculateTax, b.ChargeInterest, 
			b.OmitClientStatement, b.OmitClientDailyReport, b.TransactionType
	FROM
	(	
		SELECT  ROW_NUMBER() OVER (ORDER BY TTP.ID DESC) AS RowNumber,
				TTP.ID, TTP.ClientID, TTP.CalculateComm, TTP.CalculateTax,TTP.ChargeInterest,
				TTP.OmitClientStatement, TTP.OmitClientDailyReport, TT.	Description as TransactionType
		FROM	CWX_ClientTranTypeProperties TTP INNER JOIN TransactionType TT
				ON TTP.TransactionTypeID = TT.ID
		WHERE	TTP.ClientID = @ClientID AND TTP.[Status] = 'A'
	)b
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	SELECT @RowCount = count(TTP.ID)
	FROM	CWX_ClientTranTypeProperties TTP INNER JOIN TransactionType TT
			ON TTP.TransactionTypeID = TT.ID
	WHERE	TTP.ClientID = @ClientID AND TTP.[Status] = 'A'
	
	RETURN @RowCount
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTranTypeProperties_GetTransactionTypes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientTranTypeProperties_GetTransactionTypes]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientTranTypeProperties_GetTransactionTypes]    Script Date: 05/28/2009 15:50:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CWX_ClientTranTypeProperties_GetTransactionTypes]
	@ClientID int,
	@FinancialTypeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	TT.ID, TT.Description 
	FROM	CWX_ClientTranTypeProperties TTP INNER JOIN TransactionType TT
			ON TTP.TransactionTypeID = TT.ID
	WHERE	TTP.ClientID = @ClientID AND TTP.[Status] = 'A'
			AND (TT.FinancialTypeID = @FinancialTypeID OR @FinancialTypeID = 0)
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionType_AvailableTransactionTypes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TransactionType_AvailableTransactionTypes]
GO

-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 21, 2009
-- Description:	Get transaction types that does not have properties
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TransactionType_AvailableTransactionTypes]
	@ClientID int,
	@FinancialTypeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	ID, [Description]
	FROM	TransactionType 
	WHERE	ClientID = @ClientID AND [Status] = 'A' AND 
			(FinancialTypeID = @FinancialTypeID OR @FinancialTypeID = 0) AND
			ID NOT IN (SELECT TransactionTypeID FROM CWX_ClientTranTypeProperties
						WHERE [Status] = 'R' AND ClientID = @ClientID)
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionType_GetFinancialTypeByTransactionType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TransactionType_GetFinancialTypeByTransactionType]
GO

/****** Object:  StoredProcedure [dbo].[CWX_TransactionType_GetFinancialTypeByTransactionType]    Script Date: 05/28/2009 15:53:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CWX_TransactionType_GetFinancialTypeByTransactionType]
	@ClientID int,
	@TransactionType int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @FinancialTypeID int
	SELECT @FinancialTypeID = FinancialTypeID
	FROM TransactionType
	WHERE ClientID = @ClientID AND ID = @TransactionType AND [Status] = 'A'
	RETURN @FinancialTypeID
END
GO
-----------------------------------------End Of ThanhNguyen----------------------------------------------------------


/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 05/29/2009 16:14:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description:	Load all accounts with debtorID
-- History:
--	2008/04/03	[Tai Ly]		Init version.
--	2008/06/01	[Long Nguyen]	Add and remove some fields.
--	2008/06/27	[Binh Truong]	Remove BatchNumber field.	
--	2008/08/25	[Long Nguyen]	Remove @AdditionalTag
--	2008/09/04	[Thuy Nguyen]	Remove CoSigner table reference
--	2009/03/19	[Thuy Nguyen]	Remove ClientInformation.ContactName
--  2009/04/10	[Minh Dam]		Add parameter "@EmployeeID" that is the id of current login user 
--									and filter Account by ClientID belong to this user.
--	2009/05/25	[Minh Dam]		Only filter Account by ClientID when application by client
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int,
	@EmployeeID int
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/	
	DECLARE @ApplicationBy int
	SELECT @ApplicationBy = FieldValue FROM IdentityFields WHERE TableName = 'ApplicationBy'
	IF (@ApplicationBy <> 1) -- Only filter Account by ClientID when ApplicationBy = 1 (by Client)
		SET @EmployeeID = 0

	WITH ClientListTable AS
	(		
		SELECT * FROM dbo.CWX_AssignedClientIDTable(@EmployeeID)
	)

	SELECT
			a.AccountID,
			ISNULL(l.LetterDesc, '') AS SENTBY, ISNULL(al.LetterStatus, '') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			p.AmountPromised AS FirstAmountPromised, p.PromiseFrequency AS FirstPromiseFrequency, p.Term AS FirstPromiseTerm, p.DatePromised, '' AS PROMISE,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL,
			lastpromise.LASTPROMISEDATE, lastpromise.LASTPROMISEAMOUNT, lastpromise.LASTPROMISESTATUS, lastpromise.LASTPROMISESTATUSDESC,
			(CASE ISNULL(lg.GroupedAccountID, 0) WHEN 0 THEN 0 ELSE 1 END) AS IsGroupedAccount
	INTO	#AccountTemp
	FROM	Account	 a
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN 'd' THEN 'day(s)'
						WHEN 'w' THEN 'week(s)'
						WHEN 'm' THEN 'month(s)'
						WHEN 'y' THEN 'year(s)'
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get last promise
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised AS LASTPROMISEAMOUNT,
					p2.DatePromised AS LASTPROMISEDATE,
					p2.Status AS LASTPROMISESTATUS,
					CASE p2.Status
						WHEN 0 THEN 'Not Due'
						WHEN 1 THEN 'Paid On Time'
						WHEN 2 THEN 'Paid Late'
						WHEN 3 THEN 'Broken Promise'
						WHEN 4 THEN 'Canceled'
						ELSE ''
					END AS LASTPROMISESTATUSDESC
				FROM AccountPromise p2 
				WHERE p2.PromiseID IN 
						(	SELECT TOP 1 PromiseID
							FROM (	SELECT PromiseID, DatePromised
									FROM AccountPromise 
									WHERE AccountID = p2.AccountID -- 69
							) as temp
							ORDER BY DatePromised DESC
						)) lastpromise ON lastpromise.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	--Check if account is GroupAccount
	LEFT JOIN Legal_Groups lg ON lg.GroupedAccountID = a.AccountID
	WHERE DebtorID = @DebtorID
		AND (NOT EXISTS(SELECT 1 FROM ClientListTable) OR a.ClientID IN (SELECT ClientID FROM ClientListTable))

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, nextAction.CodeDesc AS CurrentNextActionDesc, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, --ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised, #AccountTemp.FirstAmountPromised, #AccountTemp.FirstPromiseFrequency, #AccountTemp.FirstPromiseTerm
			, #AccountTemp.LASTPROMISEDATE, #AccountTemp.LASTPROMISEAMOUNT, #AccountTemp.LASTPROMISESTATUS, #AccountTemp.LASTPROMISESTATUSDESC
			, #AccountTemp.LASTCONTACTDATE, #AccountTemp.LASTCONTACTBY, #AccountTemp.PROMISETOPAY, #AccountTemp.PROMISEKEPT, #AccountTemp.PROMISEBROKEN, #AccountTemp.OUTGOINGCALL, #AccountTemp.NOACTIVITYDAYS
			, ISNULL(Account.IsPending, 0) AS IsPending
			, #AccountTemp.IsGroupedAccount
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID
			LEFT OUTER JOIN AccountCodeMaster nextAction on Account.CurrentNextAction = nextAction.CodeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END

------------------------------------------------------------------------------
-- [28 May 20009]	Minh Dam	Create new tables
/****** Object:  Table [dbo].[CWX_ClientCommRate]    Script Date: 05/29/2009 17:14:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommRate]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientCommRate]
GO
/****** Object:  Table [dbo].[CWX_ClientCommRateSlab]    Script Date: 05/29/2009 17:14:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommRateSlab]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientCommRateSlab]
GO
/****** Object:  Table [dbo].[CWX_ClientPropertySettings]    Script Date: 05/29/2009 17:14:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientPropertySettings]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientPropertySettings]
GO
/****** Object:  Table [dbo].[CWX_ClientProperties]    Script Date: 05/29/2009 17:14:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientProperties]
GO
/****** Object:  Table [dbo].[CWX_ClientTax]    Script Date: 05/29/2009 17:14:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTax]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientTax]
GO
/****** Object:  Table [dbo].[CWX_ClientTranTypeProperties]    Script Date: 05/29/2009 17:14:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTranTypeProperties]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientTranTypeProperties]
GO
/****** Object:  Table [dbo].[CWX_ClientTaxTranType]    Script Date: 05/29/2009 17:14:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTaxTranType]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientTaxTranType]
GO
/****** Object:  Table [dbo].[CWX_ClientCategory]    Script Date: 05/29/2009 17:14:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCategory]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientCategory]
GO
/****** Object:  Table [dbo].[CWX_ClientStatus]    Script Date: 05/29/2009 17:14:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientStatus]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientStatus]
GO
/****** Object:  Table [dbo].[CWX_ClientCommPlanCriteria]    Script Date: 05/29/2009 17:14:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanCriteria]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientCommPlanCriteria]
GO
/****** Object:  Table [dbo].[CWX_ClientCommPlanRule]    Script Date: 05/29/2009 17:14:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanRule]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientCommPlanRule]
GO
/****** Object:  Table [dbo].[CWX_ClientCommModel]    Script Date: 05/29/2009 17:14:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommModel]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientCommModel]
GO
/****** Object:  Table [dbo].[CWX_ClientCommPlan]    Script Date: 05/29/2009 17:14:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlan]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_ClientCommPlan]
GO
/****** Object:  Table [dbo].[CWX_ClientCategory]    Script Date: 05/29/2009 17:14:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCategory]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCategory](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](100) NULL,
	[Status] [char](1) NULL CONSTRAINT [DF_CWX_ClientCategory_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_CWX_ClientCategory] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientStatus]    Script Date: 05/29/2009 17:14:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientStatus]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientStatus](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](100) NULL,
	[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientStatus_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_CWX_ClientStatus] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientCommPlanRule]    Script Date: 05/29/2009 17:14:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanRule]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommPlanRule](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientCommPlanID] [int] NOT NULL,
	[Code] [varchar](50) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[RatePercent] [decimal](19, 5) NULL CONSTRAINT [DF_CWX_ClientCommPlanRule_RatePercent]  DEFAULT ((0)),
	[FixedAmount] [money] NULL CONSTRAINT [DF_CWX_ClientCommPlanRule_FixedAmount]  DEFAULT ((0)),
	[Minimum] [money] NULL CONSTRAINT [DF_CWX_ClientCommPlanRule_Minimum]  DEFAULT ((0)),
	[Maximum] [money] NULL CONSTRAINT [DF_CWX_ClientCommPlanRule_Maximum]  DEFAULT ((0)),
 CONSTRAINT [PK_CWX_ClientCommissionPlanRule] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientCommModel]    Script Date: 05/29/2009 17:14:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommModel]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommModel](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [int] NOT NULL,
	[Code] [varchar](50) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[SetupTo] [tinyint] NOT NULL,
	[ModelType] [tinyint] NOT NULL,
	[ClientCommRateID] [int] NULL,
	[ClientCommPlanID] [int] NULL,
	[FinancialTypeID] [int] NULL,
	[SystemStatusID] [int] NULL,
	[TransactionTypeID] [int] NULL,
	[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientCommModel_Status]  DEFAULT ('A'),
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[UserID] [int] NULL,
	[IsActive] [bit] NOT NULL CONSTRAINT [DF_CWX_ClientCommModel_IsActive]  DEFAULT ((1)),
 CONSTRAINT [PK_CWX_ClientCommModel_1] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientCommPlanCriteria]    Script Date: 05/29/2009 17:14:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanCriteria]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommPlanCriteria](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientCommPlanRuleID] [int] NOT NULL,
	[Criteria] [varchar](50) NOT NULL,
	[Operator] [varchar](50) NOT NULL,
	[MatchingCriteria] [varchar](255) NOT NULL,
	[SQLFormat] [varchar](350) NULL,
	[Combining] [varchar](10) NULL,
 CONSTRAINT [PK_CWX_ClientCommissionPlanCriteria] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientTaxTranType]    Script Date: 05/29/2009 17:14:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTaxTranType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientTaxTranType](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [int] NOT NULL,
	[FinancialTypeID] [int] NULL,
	[TransactionTypeID] [int] NULL,
	[TaxRate] [decimal](19, 5) NULL,
	[CreateDate] [datetime] NULL,
	[UpdateDate] [datetime] NULL,
	[UserID] [int] NULL,
	[Status] [char](1) NULL,
 CONSTRAINT [PK_CWX_ClientTaxTranType_1] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientCommRate]    Script Date: 05/29/2009 17:14:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommRate]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommRate](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[StartDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
	[RateType] [int] NULL,
	[RateAmount] [money] NULL,
	[BaseAmount] [money] NULL,
 CONSTRAINT [PK_CWX_ClientCommissionRate] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[CWX_ClientCommRateSlab]    Script Date: 05/29/2009 17:14:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommRateSlab]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommRateSlab](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientCommRateID] [int] NULL,
	[FromValue] [money] NULL,
	[ToValue] [money] NULL,
	[RatePercent] [decimal](19, 5) NULL,
	[RateAmount] [money] NULL,
	[Minimum] [money] NULL,
	[Maximum] [money] NULL,
 CONSTRAINT [PK_CWX_ClientCommissionRateSlab] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[CWX_ClientPropertySettings]    Script Date: 05/29/2009 17:14:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientPropertySettings]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientPropertySettings](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Type] [int] NOT NULL,
	[Value] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_CWX_ClientPropertiesInformationTable] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[CWX_ClientProperties]    Script Date: 05/29/2009 17:14:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientProperties](
	[ClientID] [int] NOT NULL,
	[BillingPeriod] [int] NULL,
	[InvoiceType] [int] NULL,
	[BillCommissiontoDebtor] [bit] NULL,
	[AgingType] [int] NULL,
	[ChargeFeeToClient] [bit] NULL,
	[ChargeFeetoDebtor] [bit] NULL,
	[Currency] [int] NULL,
	[StatementCurrency] [int] NULL,
	[ExchangeRate] [decimal](18, 5) NULL,
	[DebtorStatementSortOrder] [bit] NULL,
	[AddCommissionToOwing] [bit] NULL,
	[ReferralRate] [decimal](18, 0) NULL,
	[TaxExempt] [bit] NULL,
	[DiscountID] [int] NULL,
	[Status] [char](1) NULL CONSTRAINT [DF_CWX_ClientProperties_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_CWX_ClientProperties] PRIMARY KEY CLUSTERED 
(
	[ClientID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientTax]    Script Date: 05/29/2009 17:14:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTax]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientTax](
	[ClientID] [int] NOT NULL,
	[TaxRate] [decimal](19, 5) NULL,
	[TaxType] [int] NULL,
	[CalculateTax] [bit] NULL,
	[CreateDate] [datetime] NULL,
	[UpdateDate] [datetime] NULL,
	[UserID] [int] NULL,
	[Status] [char](1) NULL,
 CONSTRAINT [PK_CWX_ClientTax] PRIMARY KEY CLUSTERED 
(
	[ClientID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientCommPlan]    Script Date: 05/29/2009 17:14:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlan]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommPlan](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](50) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Type] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientCommPlan_Type]  DEFAULT ('S'),
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[IsActive] [bit] NOT NULL CONSTRAINT [DF_CWX_ClientCommPlan_IsActive]  DEFAULT ((1)),
	[UserID] [int] NULL,
	[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientCommPlan_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_CWX_ClientCommissionPlan] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientTranTypeProperties]    Script Date: 05/29/2009 17:14:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTranTypeProperties]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientTranTypeProperties](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [int] NULL,
	[TransactionTypeID] [int] NULL,
	[CalculateComm] [bit] NULL,
	[CalculateTax] [bit] NULL,
	[ChargeInterest] [bit] NULL,
	[OmitClientStatement] [bit] NULL,
	[OmitClientDailyReport] [bit] NULL,
	[AddToOwing] [bit] NULL,
	[OriginalInterest] [decimal](19, 5) NULL,
	[InterestType] [tinyint] NULL,
	[AnnualInterest] [decimal](19, 5) NULL,
	[Period] [tinyint] NULL,
	[CalculateFromDate] [datetime] NULL,
	[ChargeToClient] [bit] NULL,
	[Status] [char](10) NOT NULL,
	[ChargeRelatedParties] [bit] NULL,
 CONSTRAINT [PK_CWX_ClientTranTypeProperties] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO


/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_LockAccounts]    Script Date: 05/29/2009 17:08:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 08 Apr 2009
-- Description:	Lock all accounts of a debtor
-- =============================================
ALTER PROCEDURE [dbo].[CWX_DebtorInformation_LockAccounts]
	@DebtorID int,
	@LockedByEmployeeID int,
	@LockedDate datetime,
	@LockedSessionID varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE DebtorInformation
	SET LockedByID = @LockedByEmployeeID,
		LockedDate = @LockedDate,
		LockedBy   = @LockedSessionID
	WHERE DebtorID = @DebtorID
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_UnlockAccounts]    Script Date: 05/29/2009 17:57:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 08 Apr 2009
-- Description:	Unlock all accounts of a debtor
-- =============================================
ALTER PROCEDURE [dbo].[CWX_DebtorInformation_UnlockAccounts]
	@DebtorID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE DebtorInformation
	SET LockedByID = null,
		LockedDate = null,
		LockedBy   = null
	WHERE DebtorID = @DebtorID
END
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_Currency' AND COLUMN_NAME = 'Symbold')
BEGIN
	EXEC sp_rename 'CWX_Currency.Symbold', 'Symbol'
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties]') AND type in (N'U'))
BEGIN
	ALTER TABLE CWX_ClientProperties
	ADD ClientFixFee Money NULL
	
	ALTER TABLE CWX_ClientProperties
	ADD DebtorFixFee Money NULL	
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Currency_GetCurrencyList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Currency_GetCurrencyList]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CWX_Currency_GetCurrencyList]	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT CurrencyID,  (CurrencyName + ' (' + Symbol + ')') as CurrencyNameAndSymbol
	FROM CWX_Currency
END

----------------------

/****** Object:  StoredProcedure [dbo].[CWX_Employee_Search]    Script Date: 06/01/2009 12:04:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Dec 15, 2007
-- Description:	
-- History:
--		2007/12/15	[Long Nguyen]	Init version.
--		2009/03/31	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Employee_Search]
	@EmployeeID int = 0,
	@EmployeeName varchar(50) = '',
	@Department int = 0,
	@IsEmployeePool bit,
	@RoleID int = 0,
	@ClientID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--This only used in MainPage (Refer to), if employee is supervisor -> only select supervisor
	DECLARE @Supervisor bit
	IF @EmployeeID > 0
		SELECT	@Supervisor = Supervisor	
		FROM	Employee
		WHERE	EmployeeID = @EmployeeID

	--Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowNumber BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '

	--Step 3: Populate the main SELECT command.
	DECLARE @cStmt varchar(4000)
	SET @cStmt = 'SELECT e.EmployeeID, e.UserID, e.EmployeeName, ISNULL(d.DeptDesc, '''') AS Department, e.RoleID, e.Description, '
			 + ' CASE e.Supervisor WHEN 1 THEN ''Y'' ELSE '''' END AS Supervisor '
			 + ' FROM Employee e LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID AND (d.Status <> ''R'') '
			 + ' WHERE (e.EmployeeName LIKE (''%' + @EmployeeName + '%'')) '
			 + ' AND (' + STR(@Department) + '= 0 OR e.Department = ' + STR(@Department) + ') '
			 + ' AND (' + STR(@RoleID) + '= 0 OR e.RoleID = ' + STR(@RoleID) + ') AND (ISNULL(EmployeeStatus, '''') <> ''R'') '
			 + ' AND (' + ISNULL(STR(@Supervisor), '1') + '= 1 OR e.Supervisor = 1) '
			 + ' AND (' + STR(@ClientID)+'= 0 OR EmployeeID IN (SELECT EmployeeID FROM CWX_ClientEmployee WHERE ClientID = ' + STR(@ClientID) + ')) '
	
	IF (@IsEmployeePool = 1)
		SET @cStmt = @cStmt + ' AND EmployeeType=''P'' '

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
	DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH EmployeeList AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + 'SELECT * FROM EmployeeList ' + @pagingWhereClause
	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)
print @finalStmt
	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)

	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT
	
	RETURN @RowCount
END
GO

-----ThanhNguyen---------
IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 1 AND [Value] = 'Monthly')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(1,'Monthly')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 1 AND [Value] = 'Weekly')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(1,'Weekly')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 1 AND [Value] = 'Daily')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(1,'Daily')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 1 AND [Value] = 'All')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(1,'All')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 2 AND [Value] = 'Net Client')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(2,'Net Client')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 2 AND [Value] = 'Gross Client')) 
BEGIN
	
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(2,'Gross Client')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 2 AND [Value] = 'Net - Bill Client' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(2,'Net - Bill Client')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 3 AND [Value] = 'DOS to submission Date')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(3,'DOS to submission Date')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 3 AND [Value] = 'DOS to Posting Date')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(3,'DOS to Posting Date')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 3 AND [Value] = 'Submisson Date to Posting Date')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(3,'Submisson Date to Posting Date')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 4 AND [Value] = 'Based on Payment Amount' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(4,'Based on Payment Amount')	
END


IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 4 AND [Value] = 'Based on Agency Part'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(4,'Based on Agency Part')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'Daily')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'Daily')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'Weekly' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'Weekly')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = '30 Days')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'30 Days')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'Monthly' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'Monthly')

END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'SemiMonthly')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'SemiMonthly')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'BiMonthly' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'BiMonthly')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'Quarterly' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'Quarterly')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'SemiAnnually' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'SemiAnnually')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'Annually' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'Annually')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'Custom' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'Custom')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] =  6 AND [Value] = 'Simple Interest' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(6,'Simple Interest')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] =  6 AND [Value] = 'Compound Interest' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(6,'Compound Interest')
END


IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '1' AND [Description] = 'Payment' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('1','Payment','S','A')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '2' AND [Description] = 'Principal' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
VALUES('2','Principal','S','A')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '3' AND [Description] = 'Interest' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('3','Interest','S','A')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '4' AND [Description] = 'Fee' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('4','Fee','S','A')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '5' AND [Description] = 'Legal' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('5','Legal','S','A')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '6' AND [Description] = 'Misc' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('6','Misc','S','A')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '7' AND [Description] = 'Other' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('7','Other','S','A')
END


IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '8' AND [Description] = 'Adjustment' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('8','Adjustment','S','A')
END
GO
-----End Of ThanhNguyen-----



