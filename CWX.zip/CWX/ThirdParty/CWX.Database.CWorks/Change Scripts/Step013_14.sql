-- Script is applied on version 1.9.23

ALTER   PROCEDURE [dbo].[SearchAccountByInvoice](@Invoice char(50),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.DebtorID As [DebtorID],'	
	SET @cStmt=@cStmt+'a.InvoiceNumber As [Account No.],'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode as [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'a.Minimum_due  as [Minimum Due],'
	SET @cStmt=@cStmt+'p.SocialSecurityNumber as [ID],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where a.InvoiceNumber = '+''''+Cast(@Invoice As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralByEmployee] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@cEmployeeID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND c.EmployeeID = @cEmployeeID 

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND c.EmployeeID = @cEmployeeID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralNextAction] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@cNextAction int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND c.NextAction = @cNextAction 

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND c.NextAction = @cNextAction
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalNextAction] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@NextAction int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
    INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND l.NextAction = @NextAction

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m.CodeDesc as [Next Action],
			l.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
		INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND l.NextAction = @NextAction
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalForward] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lClientID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
    INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND l.ClientID = @lClientID 
		AND a.EmployeeID = @v_employeeId

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m.CodeDesc as [Next Action],
			l.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
		INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND l.ClientID = @lClientID 
			AND a.EmployeeID = @v_employeeId
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalEmployee] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
    INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND l.EmployeeID = @v_employeeId

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m.CodeDesc as [Next Action],
			l.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
		INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND l.EmployeeID = @v_employeeId
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralStage] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@cStageID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND c.CollateralStage = @cStageID 

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND c.CollateralStage = @cStageID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralItemType] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@ItemID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND c.CollateralType = @ItemID

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND c.CollateralType = @ItemID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByEmployeeName] 
	-- Add the parameters for the stored procedure here
	@EmployeeName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
	WHERE
		a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			g.EmployeeName AS [Employee Name],
			a.QueueDate AS [QueueDate],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			a.Minimum_due AS [Minimum Due],
			p.SocialSecurityNumber AS [ID],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [ Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
		WHERE
			a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
	)

	SELECT
		KeyField,
		[Employee Name],
		[QueueDate],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Minimum Due],
		[ID],
		[ Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchByofficePhone](@PhoneNumber char(50),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'p.EmploymentPhone As [Business Phone],'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'a.Minimum_due  as [Minimum Due],'
	SET @cStmt=@cStmt+'p.SocialSecurityNumber as [ID],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p'
SET @cStmt=@cStmt+' where p.EmploymentPhone = '+''''+Cast(@PhoneNumber As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchAccountByMobile](@MobilePhone char(50),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'p.MobilPhone As [Mobile Phone No.],'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'a.Minimum_due  as [Minimum Due],'
	SET @cStmt=@cStmt+'p.SocialSecurityNumber as [ID],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p'
SET @cStmt=@cStmt+' where p.MobilPhone = '+''''+Cast(@MobilePhone As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_Queue_NoContactInXDays] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lNumberOfDays int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()) and ActionID in (select ActionID from AvailableActions where productivityid = 3))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			e.EmployeeName As [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()) and ActionID in (select ActionID from AvailableActions where productivityid = 3))
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_Queue_NoActivityInXDays] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lNumberOfDays int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			e.EmployeeName As [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()))
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchDebtorByPhone](@PhoneNumber char(25),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'p.HomePhone As [Home Phone.],'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'a.Minimum_due  as [Minimum Due],'
	SET @cStmt=@cStmt+'p.SocialSecurityNumber as [ID],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p'
SET @cStmt=@cStmt+' where p.HomePhone = '+''''+Cast(@PhoneNumber As Char(25))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchDebtorByName] 
	-- Add the parameters for the stored procedure here
	@DebtorName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) AS [Name],
			a.QueueDate AS [QueueDate],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			a.Minimum_due AS [Minimum Due],
			p.SocialSecurityNumber AS [ID]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
	)

	SELECT
		KeyField,
		[Name],
		[QueueDate],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Minimum Due],
		[ID]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchAccountByBill](@AcctID INT,@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.AccountID as [Reference No.],'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'a.Minimum_due  as [Minimum Due],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'p.SocialSecurityNumber as [ID],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'Accountother o,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where a.AccountID = '+Cast(@AcctID As Char(9))
	SET @cStmt=@cStmt+' and o.AccountID = a.AccountID'
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go




-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_QueueFuture] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@Days int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		[KeyField] varchar(30),
		[QueueDate] char(10),
		[Account Number] varchar(50),
		[DPD] int,
		[Bucket] smallint,
		[Cycle] smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		[Status] varchar(10),
		[Priority] int,
		[Assignment Type] char(1),
		[Name] varchar(200)
	)
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.EmployeeID = ' + CAST(@EmployeeID AS varchar(10))
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

--Today|2|GE Today|0|Tomorrow|1|3 Days|3|5 Days|5

				if (@Days = 1) or (@Days = 3) or (@Days = 5)
				Begin
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) <= dateadd(day,' + CAST(@Days AS varchar(10)) + ', getdate())'
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) >= getdate()'
				End

				if @Days = 2
				Begin
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) = getdate()'
				End

				if @Days = 0
				Begin
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) >= getdate()'
				End

				Set @cStmt = @cStmt + ' Order by a.QueueDate DESC'
				EXEC (@cStmt)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	DROP TABLE #Temp

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go




-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_QueueByAmtRange] 
	-- Add the parameters for the stored procedure here
	@v_Range int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		[KeyField] varchar(30),
		[QueueDate] char(10),
		[Account Number] varchar(50),
		[DPD] int,
		[Bucket] smallint,
		[Cycle] smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		[Status] varchar(10),
		[Priority] int,
		[Assignment Type] char(1),
		[Name] varchar(200)
	)
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate <= getDate()'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

				if ((@EmpList <> '') and (@EmpList <> 'Null'))
				Begin
					SET @cStmt=@cStmt+' AND a.EmployeeID in (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(''' + @EmpList + ''',' + '''' + ',' + '''' + '))'
				End

				if @v_Range = 1
				Begin
					SET @cStmt = @cStmt +'   AND a.BillBalance < 10000'
				End

				if @v_Range = 2
				Begin
					SET @cStmt = @cStmt +'  AND a.BillBalance >= 10000'
					SET @cStmt = @cStmt +'  AND a.BillBalance < 25000'
				End

				if @v_Range = 3
				Begin
					SET @cStmt = @cStmt +'	AND a.BillBalance >= 25000'
					SET @cStmt = @cStmt +'	AND a.BillBalance < 50000'		
				End

				if @v_Range = 4
				Begin
					SET @cStmt = @cStmt +'	AND a.BillBalance >= 50000'
					SET @cStmt = @cStmt +'	AND a.BillBalance < 150000'		
				End

				if @v_Range = 5
				Begin
					SET @cStmt = @cStmt +'	AND a.BillBalance >= 150000'
				End

				Set @cStmt = @cStmt + ' Order by a.QueueDate DESC'
				EXEC (@cStmt)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	DROP TABLE #Temp

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_AgencyStatus int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		KeyField varchar(30),
		QueueDate smalldatetime,
		DPD int,
		Bucket smallint,
		Cycle smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		Status varchar(10),
		Priority int,
		[Assignment Type] char(1),
		[ID] varchar(25),
		[Name] varchar(200)
	)

    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN AccountOther o ON o.AccountID = a.AccountID'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId AS varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID = '+CAST(@v_AgencyStatus AS varchar(9))

	--Build OrderByClause
	SET @cStmt=@cStmt+' ORDER BY '
	DECLARE @v_SortOrder varchar(700)

	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
       Set @cStmt = @cStmt + ' "QueueDate" DESC'
    ELSE
       Set @cStmt = @cStmt + @v_SortOrder

	EXEC (@cStmt)

	DECLARE @RowCount int
	SET @RowCount = @@ROWCOUNT

	DECLARE @BeginIndex int
	DECLARE @EndIndex int

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	SELECT
		KeyField,
		QueueDate,
		DPD,
		Bucket,
		Cycle,
		[Bill Amount],
		[Bill Balance],
		Status,
		Priority,
		[Assignment Type],
		[ID],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	DROP TABLE #Temp

	RETURN @RowCount
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_SystemStatus int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		KeyField varchar(30),
		QueueDate smalldatetime,
		DPD int,
		Bucket smallint,
		Cycle smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		Status varchar(10),
		Priority int,
		[Assignment Type] char(1),
		[ID] varchar(25),
		[Name] varchar(200)
	)

    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN Accountother o ON o.AccountID = a.AccountID'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId as varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID <> 2'

	IF @v_SystemStatus = 0 
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'+''
	ELSE
		SET @cStmt=@cStmt+' AND s.SystemStatus = '+CAST(@v_SystemStatus AS char(9))+''

	--Build OrderByClause
	SET @cStmt=@cStmt+' ORDER BY '
	DECLARE @v_SortOrder varchar(700)

	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
       Set @cStmt = @cStmt + ' "QueueDate" DESC'
    ELSE
       Set @cStmt = @cStmt + @v_SortOrder

	EXEC (@cStmt)

	DECLARE @RowCount int
	SET @RowCount = @@ROWCOUNT

	DECLARE @BeginIndex int
	DECLARE @EndIndex int

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	--Paging
	SELECT
		KeyField,
		QueueDate,
		DPD,
		Bucket,
		Cycle,
		[Bill Amount],
		[Bill Balance],
		Status,
		Priority,
		[Assignment Type],
		[ID],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	DROP TABLE #Temp

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 06/23/2008 17:29:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <17 June 2008>
-- Description:	<Get Queue Statistic by Collector>
-- =============================================
ALTER PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int
	
AS
BEGIN

	DECLARE @BeforeDays INT
	DECLARE @AfterDays INT

	IF (@ReportTime = 0)
		BEGIN
			SELECT EmployeeID, QueueDate, ISNULL(COUNT(AccountID),0) AS AccountCount, ISNULL(SUM(BillBalance),0) AS AccountBalance 
			FROM Account 
			WHERE CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
			AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 7,121)
			AND SystemStatusID = 5 
			AND EmployeeID = @EmployeeID		

		GROUP BY EmployeeID, QueueDate 
		ORDER BY QueueDate
		END
	ELSE
		BEGIN
			SELECT EmployeeID, QueueDate, ISNULL(COUNT(AccountID),0) AS AccountCount, ISNULL(SUM(BillBalance),0) AS AccountBalance 
			FROM Account 
			WHERE SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))

			GROUP BY EmployeeID, QueueDate 
			ORDER BY QueueDate
		END
END

/******  Script Closed. Go next: Step013_15  ******/