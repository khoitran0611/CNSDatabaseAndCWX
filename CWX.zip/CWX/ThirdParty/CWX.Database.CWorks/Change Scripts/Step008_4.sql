 -- Scripts are applied on version 1.3 build 4 
 
/****** Object:  StoredProcedure [dbo].[CWX_Letter_Select]    Script Date: 04/21/2008 18:05:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Letter_Select]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Letter_Select]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInfomation_Get]    Script Date: 04/21/2008 18:05:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInfomation_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DebtorInfomation_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Letter_Select]    Script Date: 04/21/2008 18:05:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Letter_Select]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE Procedure [dbo].[CWX_Letter_Select]
	(
		@letterType tinyint = 0	
	)
AS
BEGIN	
	SELECT * 
	FROM [dbo].[DefineLetters]
	WHERE LetterType = @letterType
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInfomation_Get]    Script Date: 04/21/2008 18:05:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInfomation_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Triet Pham
-- Create date: 03/26/2008
-- Description:	
-- =============================================
CREATE PROCEDURE [CWX_DebtorInfomation_Get]
	@DebtorID int
AS
BEGIN
	SET NOCOUNT ON;

Select 
	DebtorID, 
	PString3, 
	DebtorInformation.PersonID, 
	CompanyName, 
	DoingBusinessAs, 
	GroupName, 
	HotNote, 
	ZipDelPoint, 
	ZipCart, 
	ReturnedMail, 
	HoldLetters, 
	HoldHomeCalls, 
	HoldWorkCalls, 
	PullCreditReport, 
	SendReminderLetters, 
	DateOfLastCreditReportPull, 
	CreditReportFileName, 
	LastEditDate, 
	LastEditBy, 
	LockedByID, 
	LockedBy, 
	PString1, 
	PString2, 
	PString4, 
	PString5, 
	PString6, 
	PString7, 
	PString8, 
	PString9, 
	PString10, 
	PString11, 
	PString12, 
	PString13, 
	PString14, 
	PString15, 
	PString16, 
	PString17, 
	PString18, 
	PString19, 
	PString20, 
	PString21, 
	PString22, 
	PString23, 
	PString24, 
	PString25, 
	PString26, 
	PString27, 
	PString28, 
	PString29, 
	PString30, 
	PString31, 
	PString32, 
	PString33, 
	PString34, 
	PString35, 
	PString36, 
	PString37, 
	PString38, 
	PString39, 
	PString40, 
	PString41, 
	PString42, 
	PString43, 
	PString44, 
	PString45,
	PMoney1, 
	PMoney2, 
	PMoney3, 
	PMoney4, 
	PMoney5, 
	PMoney6, 
	PMoney7, 
	PMoney8, 
	PMoney9, 
	PMoney10, 
	PMoney11, 
	PMoney12, 
	PMoney13, 
	PMoney14, 
	PMoney15, 
	PMoney16, 
	PMoney17, 
	PMoney18, 
	PMoney19, 
	PMoney20, 
	PMoney21, 
	PMoney22, 
	PMoney23, 
	PMoney24, 
	PMoney25, 
	PLong1, 
	PLong2, 
	PLong3, 
	PLong4, 
	PLong5, 
	PLong6, 
	PLong7, 
	PLong8, 
	PLong9, 
	PLong10, 
	PLong11, 
	PLong12, 
	PLong13, 
	PLong14, 
	PLong15, 
	PLong16, 
	PLong17, 
	PLong18, 
	PLong19, 
	PLong20,
	PLong21, 
	PLong22, 
	PLong23, 
	PLong24, 
	PLong25, 
	PLong26, 
	PLong27, 
	PLong28, 
	PLong29, 
	PLong30, 
	PLong31, 
	PLong32, 
	PLong33, 
	PLong34, 
	PLong35, 
	PLong36, 
	PLong37, 
	PLong38, 
	PLong39, 
	PLong40, 
	PLong41, 
	PLong42, 
	PLong43, 
	PLong44, 
	PLong45, 
	PLong46, 
	PLong47, 
	PLong48, 
	PLong49, 
	PLong50, 
	PString46, 
	PString47, 
	PString48, 
	PString49, 
	PString50, 
	PMoney26, 
	PMoney27, 
	PMoney28, 
	PMoney29, 
	PMoney30, 
	PMoney31, 
	PMoney32, 
	PMoney33, 
	PMoney34, 
	PMoney35, 
	PMoney36, 
	PMoney37, 
	PMoney38, 
	PMoney39, 
	PMoney40, 
	PMoney41, 
	PMoney42, 
	PMoney43, 
	PMoney44, 
	PMoney45, 
	PMoney46, 
	PMoney47, 
	PMoney48, 
	PMoney49, 
	PMoney50, 
	PDate1, 
	PDate2, 
	PDate3, 
	PDate4, 
	PDate5, 
	PDate6, 
	PDate7, 
	PDate8, 
	PDate9, 
	PDate10, 
	LastName, 
	FirstName, 
	MiddleName, 
	Suffix, 
	SocialSecurityNumber, 
	AlternateID1Name, 
	AlternateID1, 
	AlternateID2Name, 
	AlternateID2, 
	DriversLicenseNumber, 
	DateOfBirth, 
	HomePhone, 
	MobilPhone, 
	Employment, 
	EmploymentPhone, 
	EmploymentPhoneExtension, 
	Fax, 
	Email, 
	CallAfter, 
	BankRuptDate, 
	BankRuptType, 
	[Language],
	SpouseID, 
	TimeZone, 
	GMTOffset, 
	Nationality, 
	Other_Phone_Number, 
	Other_Phone_Number1, 
	Home_PO_Box, 
	Nearest_Landmark, 
	NO_Of_Years_Resi, 
	Business_Type, 
	Position, 
	Profession, 
	Department, 
	Employee_Number, 
	Title, 
	Employer_Code, 
	FriendName, 
	Friend_Off_Phone, 
	Friend_Res_Phone, 
	Friend_FaxNo,
	LastName as SPOUSELASTNAME, 
	FirstName as SPOUSEFIRSTNAME, 
	MiddleName as SPOUSEMIDDLENAME, 
	SocialSecurityNumber as SPOUSESOCIALSECURITYNUMBER,
	AlternateID1Name as SPOUSEALTERNATEIDNAME, 
	AlternateID1 as SPOUSEALTERNATEID1, 
	AlternateID2Name as SPOUSEALTERNATEID2NAME, 
	AlternateID2 as SPOUSEALTERNATEID2, 
	DriversLicenseNumber as SPOUSEDRIVERSLICENSE, 
	DateOfBirth as SPOUSEDATEOFBIRTH,
	MobilPhone as SPOUSEMOBILE, 
	Employment as SPOUSEEMP, 
	EmploymentPhone as SPOUSEEMPPHONE, 
	EmploymentPhoneExtension as SPOUSEEMPPHONEEXT, 
	Fax as SPOUSEFAX, 
	Email as SPOUSEEMAIL
From DebtorInformation, PersonInformation 
Where DebtorInformation.DebtorID = @DebtorID And DebtorInformation.PersonID = PersonInformation.PersonID

SET NOCOUNT OFF
END
' 
END
GO


/*
GRANT EXEC ON Stored_Procedure_Name TO PUBLIC

GO
*/

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'CWX_AccountStatus_LoadInQueue')
	BEGIN
		DROP  Procedure  CWX_AccountStatus_LoadInQueue
	END

GO

-- =============================================
-- Author:		TaiLy
-- Create date: April 01, 2008
-- Description:	Get all accountstatus which have loadinqueue input by user
-- =============================================


CREATE Procedure CWX_AccountStatus_LoadInQueue
	(
		@LoadInQueue bit = 1		
	)
AS
BEGIN	
	SELECT * 
	FROM [dbo].[AccountStatus]
	WHERE LoadInQueue = @LoadInQueue
END	
GO

/*
GRANT EXEC ON Stored_Procedure_Name TO PUBLIC

GO
*/

/****** Object:  Table [dbo].[QueryDebtorInfoMaster]    Script Date: 04/02/2008 15:54:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QueryDebtorInfoMaster](
	[InterfaceID] [int] NOT NULL,
	[InfoType] [int] NOT NULL,
	[Sql] [nvarchar](2000) NOT NULL,
	[Description] [ntext] NULL,
 CONSTRAINT [PK_QueryDebtorInfoMaster] PRIMARY KEY CLUSTERED 
(
	[InterfaceID] ASC,
	[InfoType] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'CWX_AvailableActions_Get')
	BEGIN
		DROP  Procedure  CWX_AvailableActions_Get
	END

GO

-- =============================================
-- Author:		TaiLy
-- Create date: April 02, 2008
-- Description:	Get all AvailableActions
-- =============================================


CREATE Procedure CWX_AvailableActions_Get
AS
BEGIN	
	SELECT * 
	FROM [dbo].[AvailableActions]
	WHERE ActionType = 'U'
	ORDER BY Description
END	
GO

/*
GRANT EXEC ON Stored_Procedure_Name TO PUBLIC

GO
*/

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'CWX_CallResult_Get')
	BEGIN
		DROP  Procedure  CWX_CallResult_Get
	END

GO

-- =============================================
-- Author:		TaiLy
-- Create date: April 02, 2008
-- Description:	Get all callresult
-- =============================================


CREATE Procedure CWX_CallResult_Get
AS
BEGIN	
	SELECT * 
	FROM [dbo].[AccountCodeMaster]
	WHERE CodeType = 3
	ORDER BY CodeDesc
END		
GO

/*
GRANT EXEC ON Stored_Procedure_Name TO PUBLIC

GO
*/

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'CWX_NextAction_Get')
	BEGIN
		DROP  Procedure  CWX_NextAction_Get
	END

GO
-- =============================================
-- Author:		TaiLy
-- Create date: April 02, 2008
-- Description:	Get all NextAction
-- =============================================
CREATE Procedure CWX_NextAction_Get
AS
BEGIN
	SELECT * 
	FROM [dbo].[AccountCodeMaster]
	WHERE CodeType = 2
	ORDER BY CodeDesc
END
GO

/****** Object:  Table [dbo].[TempDebtorXml]    Script Date: 04/02/2008 17:56:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TempDebtorXml](
	[DebtorID] [int] NOT NULL,
	[DebtorXML] [xml] NOT NULL,
 CONSTRAINT [PK_TempDebtorXml] PRIMARY KEY CLUSTERED 
(
	[DebtorID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
 

/****** Object:  StoredProcedure [dbo].[CWX_Account_CosignerCNT]    Script Date: 04/22/2008 09:01:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CosignerCNT]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_CosignerCNT]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_CosignerCNT]    Script Date: 04/22/2008 09:01:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CosignerCNT]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TaiLy
-- Create date: April 03, 2008
-- Description:	Get number of Cosigner
-- =============================================
CREATE PROCEDURE CWX_Account_CosignerCNT		
	@AccountNumber int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	COUNT(*) as CNT
	FROM	[dbo].[Cosigner]
	WHERE	AccountID = @AccountNumber

	SET NOCOUNT OFF;
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_Define_Letter_Get]    Script Date: 04/22/2008 09:02:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_Define_Letter_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_Define_Letter_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_Define_Letter_Get]    Script Date: 04/22/2008 09:02:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_Define_Letter_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TaiLy
-- Create date: April 03, 2008
-- Description:	Get AccountLetter, DefineLetter Information
-- =============================================
CREATE PROCEDURE CWX_Account_Define_Letter_Get	
	@AccountNumber	int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	LetterDesc, LetterStatus, LetterDate 
	FROM	[dbo].[AccountLetter], [dbo].[DefineLetters]
	WHERE	ID = (	SELECT	MAX(ID) 
					FROM	[dbo].[AccountLetter]
					WHERE	AccountID = @AccountNumber) 
			AND AccountLetter.LetterID = DefineLetters.LetterID

	SET NOCOUNT OFF;
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_GetInterfaceID]    Script Date: 04/22/2008 09:00:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetInterfaceID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetInterfaceID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetInterfaceID]    Script Date: 04/22/2008 09:00:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetInterfaceID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TrietPham
-- Create date: 03/04/2008
-- Description:	
-- =============================================
CREATE PROCEDURE CWX_Account_GetInterfaceID 
	@AccountID int
AS
BEGIN
	SET NOCOUNT ON;
	    
	SELECT [InterfaceID]
	FROM [Account]
	WHERE [AccountID] = @AccountID

	SET NOCOUNT OFF 
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 04/22/2008 09:01:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXML]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_LoadXML]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 04/22/2008 09:01:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXML]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TaiLy
-- Create date: April-03-2008
-- Description:	Load all accounts with debtorID and serialize it to XML
-- =============================================
CREATE PROCEDURE CWX_Account_LoadXML
	@DebtorID	int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	AccountID
	INTO	#AccountTemp
	FROM	Account	
	WHERE	DebtorID = @DebtorID
	
	SELECT	ACCOUNT.AccountID, DebtorID, EmployeeID, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, NoLetterBefore, NoFeeBefore, MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, BatchNumber, InterestRate, ActionEmployee, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, CurrentCallResult, CampaignId,
			'' '' as LETTERSTATUS, BillAmount + BillBalance as BALANCE, String1 as PROMISE, QueueDate as LETTERDATE, InvoiceNumber as SENTBY, DebtorID as COOWNERS,
			'' '' as LASTCONTACTDATE, '' '' as LASTCONTACTBY, '' '' as PROMISETOPAY, '' '' as PROMISEKEPT, '' '' as PROMISEBROKEN, '' '' as OUTGOINGCALL, '' '' as NOACTIVITYDAYS, 
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction 			
			
	FROM	(((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_Get]    Script Date: 04/22/2008 09:03:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_Get]    Script Date: 04/22/2008 09:03:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		TaiLy
-- Create date: April 03, 2008
-- Description:	Get AccountPromise Information
-- =============================================
CREATE PROCEDURE CWX_AccountPromise_Get 
	@AccountNumber	int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	AmountPromised, Period, Term, DatePromised 
	FROM	[dbo].[AccountPromise] 
	WHERE	PromiseID = (	SELECT	MIN(PromiseID) 
							FROM	[dbo].[AccountPromise] 
							WHERE	AccountID = @AccountNumber AND Status IN (0, 2) 
						)

	SET NOCOUNT OFF;
END
' 
END
GO
