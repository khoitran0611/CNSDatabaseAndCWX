/****** Object:  Table [dbo].[ClientInformation]    Script Date: 03/20/2009 10:15:17 ******/

SET ANSI_NULLS ON 
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

IF(EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'ClientInformation_New') and type in (N'U')))
	DROP TABLE ClientInformation_New

CREATE TABLE [dbo].[ClientInformation_New](
	[ClientID] [int] IDENTITY(1,1) NOT NULL,
	[ClientName] [nvarchar](50) NOT NULL,
	[Priority] [int] NULL,
	[Active] [bit] NOT NULL,
	[ClientTypeID] [int] NULL,
	[CurrencyID] [int] NULL,
	[ReallocationDay] [tinyint] NULL,
	[AgingForReschedule] [money] NULL,
	[AgingForDiscount] [money] NULL,
	[RescheduleAllowed] [int] NULL,
	[DiscountAllowed] [int] NULL,
	[DeptIDs] [varchar](1000) NULL,
	[LetterheadImage] [image] NULL,
	[Status] [char](1) NOT NULL DEFAULT ('A'),
	[CreditorID] [int] NULL,
	[PaymentAllocationRuleID] [int] NULL,
	[AgingForApportion] [money] NULL,
	[ApportionAllowed] [money] NULL,
	[ClientDictID] [int] NULL DEFAULT ((0)),
	[HotNote] nvarchar(255) NULL,
	[MasterClientID] int NULL,
	[ClientListedDate] datetime NULL,
	[ClientLastUpdatedDate] datetime NULL,
	[ClientLastWorkedDate] datetime NULL,
	[ClientTimeZoneID] int NULL,
	[ClientFirstReferalDate] datetime NULL,
	[ClientLastReferalDate] datetime NULL,
	[ClientAgencyID] varchar(50) NULL,
	[ClientRecallDays] int NULL,
	[ClientCategoryID] int NULL,
	[ClientStatusID] int NULL,
	[ClientAcknowledgementID] int NULL,
	[CString1] [nvarchar](25) NULL,
	[CString2] [nvarchar](25) NULL,
	[CString3] [nvarchar](25) NULL,
	[CString4] [nvarchar](25) NULL,
	[CString5] [nvarchar](25) NULL,
	[CString6] [nvarchar](25) NULL,
	[CString7] [nvarchar](25) NULL,
	[CString8] [nvarchar](25) NULL,
	[CString9] [nvarchar](25) NULL,
	[CString10] [nvarchar](25) NULL,
	[CString11] [nvarchar](50) NULL,
	[CString12] [nvarchar](50) NULL,
	[CString13] [nvarchar](50) NULL,
	[CString14] [nvarchar](50) NULL,
	[CString15] [nvarchar](50) NULL,
	[CString16] [nvarchar](50) NULL,
	[CString17] [nvarchar](50) NULL,
	[CString18] [nvarchar](50) NULL,
	[CString19] [nvarchar](50) NULL,
	[CString20] [nvarchar](50) NULL,
	[CString21] [nvarchar](100) NULL,
	[CString22] [nvarchar](100) NULL,
	[CString23] [nvarchar](100) NULL,
	[CString24] [nvarchar](100) NULL,
	[CString25] [nvarchar](100) NULL,
	[CInt1] [int] NULL DEFAULT ((0)),
	[CInt2] [int] NULL DEFAULT ((0)),
	[CInt3] [int] NULL DEFAULT ((0)),
	[CInt4] [int] NULL DEFAULT ((0)),
	[CInt5] [int] NULL DEFAULT ((0)),
	[CInt6] [int] NULL DEFAULT ((0)),
	[CInt7] [int] NULL DEFAULT ((0)),
	[CInt8] [int] NULL DEFAULT ((0)),
	[CInt9] [int] NULL DEFAULT ((0)),
	[CInt10] [int] NULL DEFAULT ((0)),
	[CMoney1] [money] NULL DEFAULT ((0)),
	[CMoney2] [money] NULL DEFAULT ((0)),
	[CMoney3] [money] NULL DEFAULT ((0)),
	[CMoney4] [money] NULL DEFAULT ((0)),
	[CMoney5] [money] NULL DEFAULT ((0)),
	[CMoney6] [money] NULL DEFAULT ((0)),
	[CMoney7] [money] NULL DEFAULT ((0)),
	[CMoney8] [money] NULL DEFAULT ((0)),
	[CMoney9] [money] NULL DEFAULT ((0)),
	[CMoney10] [money] NULL DEFAULT ((0)),
	[CBit1] [bit] NULL DEFAULT ((0)),
	[CBit2] [bit] NULL DEFAULT ((0)),
	[CBit3] [bit] NULL DEFAULT ((0)),
	[CBit4] [bit] NULL DEFAULT ((0)),
	[CBit5] [bit] NULL DEFAULT ((0)),
	[CBit6] [bit] NULL DEFAULT ((0)),
	[CBit7] [bit] NULL DEFAULT ((0)),
	[CBit8] [bit] NULL DEFAULT ((0)),
	[CFLoat1] [float] NULL DEFAULT ((0)),
	[CFLoat2] [float] NULL DEFAULT ((0)),
	[CFLoat3] [float] NULL DEFAULT ((0)),
	[CFLoat4] [float] NULL DEFAULT ((0)),
	[CFLoat5] [float] NULL DEFAULT ((0)),
	[CFLoat6] [float] NULL DEFAULT ((0)),
	[CFLoat7] [float] NULL DEFAULT ((0)),
	[CFLoat8] [float] NULL DEFAULT ((0)),
	[CFLoat9] [float] NULL DEFAULT ((0)),
	[CFLoat10] [float] NULL DEFAULT ((0)),
 CONSTRAINT [PK_CWX_ClientInformation] PRIMARY KEY CLUSTERED 
(
	[ClientID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


SET IDENTITY_INSERT ClientInformation_New ON
INSERT INTO [dbo].[ClientInformation_New]
           ([ClientID],[ClientName],[Priority],[Active],[ClientTypeID],[CurrencyID]
           ,[ReallocationDay],[AgingForReschedule],[AgingForDiscount],[RescheduleAllowed]
           ,[DiscountAllowed],[DeptIDs],[LetterheadImage],[Status],[CreditorID]
           ,[PaymentAllocationRuleID],[AgingForApportion],[ApportionAllowed]		   	 	 
           ,[CString1],[CString2],[CString3],[CString4],[CString5],[CString6]
           ,[CString7],[CString8],[CString9],[CString10],[CString11],[CString12]
           ,[CString13],[CString14],[CString15],[CString16],[CString17]
           ,[CString18],[CString19],[CString20],[CString21],[CString22]
           ,[CString23],[CString24],[CString25]
           ,[CInt1],[CInt2],[CInt3],[CInt4],[CInt5],[CInt6],[CInt7],[CInt8],[CInt9],[CInt10]
           ,[CMoney1],[CMoney2],[CMoney3],[CMoney4],[CMoney5],[CMoney6],[CMoney7],[CMoney8]
           ,[CMoney9],[CMoney10]
           ,[CBit1],[CBit2],[CBit3],[CBit4],[CBit5],[CBit6],[CBit7],[CBit8]
           ,[CFLoat1],[CFLoat2],[CFLoat3],[CFLoat4],[CFLoat5],[CFLoat6],[CFLoat7],[CFLoat8],[CFLoat9],[CFLoat10])

SELECT		[ClientID],[ClientName],[Priority],[Active],null,null
           ,[ClientPayCycle],[AgingForReschedule],[AgingForDiscount],[RescheduleAllowed]
           ,[DiscountAllowed],[DeptIDs],[LetterheadImage],[Status],[CreditorID]
           ,[PaymentAllocationRuleID],[AgingForApportion],[ApportionAllowed]		   
           ,null, null, null, null, null, null, null, null, null, null
           ,null, null, null, null, null, null, null, null, null, null 
           ,null, null, null, null, null, null, null, null, null, null 
           ,null, null, null, null, null, null, null, null, null, null 
           ,null, null, null, null, null, null, null, null, null, null 
           ,null, null, null, null, null, null, null, null, null, null 
           ,null, null, null
		FROM ClientInformation

GO
SET IDENTITY_INSERT ClientInformation_New OFF
GO

EXECUTE sp_rename N'dbo.ClientInformation', N'ClientInformation_Old', 'OBJECT' 
EXECUTE sp_rename N'dbo.ClientInformation_New', N'ClientInformation', 'OBJECT' 
GO

------------------------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'DebtorInformation' AND COLUMN_NAME = 'LockedDate')
BEGIN
	ALTER TABLE DebtorInformation 
		ADD LockedDate datetime NULL
END
GO

------------------------------------------------------------------------------
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'CWX_CustomDefinedFields' AND c.name = 'ClientID')
BEGIN
	ALTER TABLE CWX_CustomDefinedFields ADD ClientID [int] DEFAULT 0
END
GO
------------------------------------------------------------------------------
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'DefineFees' AND c.name = 'ClientID')
BEGIN
	ALTER TABLE DefineFees ADD ClientID [int] DEFAULT 0
END
GO
------------------------------------------------------------------------------
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'AccountCodeMaster' AND c.name = 'ClientID')
BEGIN
	ALTER TABLE AccountCodeMaster ADD ClientID [int] DEFAULT 0
END
GO
------------------------------------------------------------------------------

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME		
                         FROM INFORMATION_SCHEMA.COLUMNS		
                         WHERE TABLE_NAME=N'Transactions' AND COLUMN_NAME = N'DebtorExchangeRate' )		
BEGIN		
	ALTER TABLE dbo.Transactions	
		ADD DebtorExchangeRate DECIMAL(18,5)
END		

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME		
                         FROM INFORMATION_SCHEMA.COLUMNS		
                         WHERE TABLE_NAME=N'Transactions' AND COLUMN_NAME = N'AgencyCurrency' )		
BEGIN		
	ALTER TABLE dbo.Transactions	
		ADD AgencyCurrency CHAR(3)
END		

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME		
                         FROM INFORMATION_SCHEMA.COLUMNS		
                         WHERE TABLE_NAME=N'Transactions' AND COLUMN_NAME = N'AgencyExchangeRate' )		
BEGIN		
	ALTER TABLE dbo.Transactions	
		ADD AgencyExchangeRate DECIMAL(18,5)
END		

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME		
                         FROM INFORMATION_SCHEMA.COLUMNS		
                         WHERE TABLE_NAME=N'Transactions' AND COLUMN_NAME = N'PaidAt' )		
BEGIN		
	ALTER TABLE dbo.Transactions	
		ADD PaidAt Bit not null default(0)
END		

GO	

------------------------------------------------------------------------------
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'DefineLetters' AND c.name = 'DefaultPrinter')
BEGIN
	ALTER TABLE DefineLetters ADD DefaultPrinter [varchar ](250)
END
GO
------------------------------------------------------------------------------
-------End of Thuy Nguyen added on 20-March-2009-----------------

-------Thuy Nguyen added on 23-March-2009-----------------

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'RuleTable' AND c.name = 'ClientID')
BEGIN
	ALTER TABLE RuleTable ADD ClientID [int] DEFAULT 0
END

GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'DefineLetters' AND c.name = 'ClientID')
BEGIN
	ALTER TABLE DefineLetters ADD ClientID [int] DEFAULT 0
END

GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON 
	o.object_id = c.object_id WHERE o.name = 'ReportScheduleTable' AND c.name = 'ClientID')
BEGIN
	ALTER TABLE ReportScheduleTable ADD ClientID [int] DEFAULT 0
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'AgencyDefinedMaster' AND COLUMN_NAME = 'Type')
BEGIN
	ALTER TABLE AgencyDefinedMaster 
		ADD [Type] tinyint NULL
END
GO

-- [Minh Dam] [26 May 2009] Add column "FinancialTypeID" to table "TransactionType"
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'TransactionType' and c.name = 'FinancialTypeID')
BEGIN
    ALTER TABLE TransactionType
        ADD FinancialTypeID int NULL
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountInformation_Dict]') AND type in (N'U'))
BEGIN	
	CREATE TABLE [dbo].[CWX_AccountInformation_Dict](
		[FieldName] [nvarchar](50) NULL,
		[FieldDesc] [nvarchar](100) NULL,
		[Displayed] [bit] NULL,
		[Editable] [bit] NULL,
		[GroupID] [int] NULL,
		[GroupDesc] [nvarchar](50) NULL,
		[TabID] [int] NULL DEFAULT ((1)),
		[TabDesc] [nvarchar](30) NULL,
		[DisplayOrder] [int] NULL,
		[DropDown] [int] NULL DEFAULT ((0)),
		[RangeID] [tinyint] NULL DEFAULT ((0)),
		[Mandatory] [bit] NULL DEFAULT ((0)),
		[ClientID] [int] NULL,
		[TableID] [int] NULL,
		[CMSEdit] [bit] NULL
) ON [PRIMARY]
END
GO

IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_Dict]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_ClientInformation_Dict](
	[FieldName] [nvarchar](50) NULL,
	[FieldDesc] [nvarchar](100) NULL,
	[Displayed] [bit] NULL,
	[Editable] [bit] NULL,
	[GroupID] [int] NULL,
	[GroupDesc] [nvarchar](50) NULL,
	[TabID] [int] NULL DEFAULT ((1)),
	[TabDesc] [nvarchar](30) NULL,
	[DisplayOrder] [int] NULL,
	[DropDown] [int] NULL DEFAULT ((0)),
	[RangeID] [tinyint] NULL DEFAULT ((0)),
	[Mandatory] [bit] NULL DEFAULT ((0)),
	[ClientID] [int] NULL
) ON [PRIMARY]
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_Dict_NEW]') AND type in (N'U'))
DROP TABLE [CWX_Collateral_Dict_NEW]
GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT

BEGIN TRANSACTION
GO
CREATE TABLE [dbo].[CWX_Collateral_Dict_NEW](
	[FieldName] [nvarchar](50) NULL,
	[FieldDesc] [nvarchar](100) NULL,
	[Displayed] [bit] NULL,
	[Editable] [bit] NULL,
	[GroupID] [int] NULL,
	[GroupDesc] [nvarchar](50) NULL,
	[TabID] [int] NULL  DEFAULT ((1)),
	[TabDesc] [nvarchar](30) NULL,
	[DisplayOrder] [int] NULL,
	[DropDown] [int] NULL DEFAULT ((0)),
	[RangeID] [tinyint] NULL DEFAULT ((0)),
	[Mandatory] [bit] NULL  DEFAULT ((0)),
	[ClientID] [int] NULL,
	[CollateralTypeID] [int] NULL
) ON [PRIMARY]

GO

INSERT INTO [dbo].[CWX_Collateral_Dict_NEW]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[TabID],[TabDesc],[DisplayOrder],[DropDown],[RangeID],[Mandatory],[ClientID],[CollateralTypeID])
SELECT FieldName, FieldDesc, Displayed, Editable,GroupID, GroupDesc, 1,
		'', DisplayOrder, 0, 0, 0, [ClientID], [CollateralTypeID]
FROM [dbo].[CWX_Collateral_Dict]
GO

DROP TABLE dbo.CWX_Collateral_Dict
GO

EXECUTE sp_rename N'dbo.CWX_Collateral_Dict_NEW', N'CWX_Collateral_Dict', 'OBJECT' 
GO
COMMIT
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonInformation_Dict]') AND type in (N'U'))
BEGIN	
	CREATE TABLE [dbo].[CWX_PersonInformation_Dict](
		[FieldName] [nvarchar](50) NULL,
		[FieldDesc] [nvarchar](100) NULL,
		[Displayed] [bit] NULL,
		[Editable] [bit] NULL,
		[GroupID] [int] NULL,
		[GroupDesc] [nvarchar](50) NULL,
		[TabID] [int] NULL DEFAULT ((1)),
		[TabDesc] [nvarchar](30) NULL,
		[DisplayOrder] [int] NULL,
		[DropDown] [int] NULL DEFAULT ((0)),
		[RangeID] [tinyint] NULL DEFAULT ((0)),
		[Mandatory] [bit] NULL DEFAULT ((0)),
		[CMSEdit] [bit] NULL
) ON [PRIMARY]
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDynamicFields]    Script Date: 06/05/2009 14:48:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetDynamicFields]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDynamicFields]    Script Date: 06/05/2009 14:48:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an account
-- History:
--	[06-Mar-2009]	Minh Dam		Init version.
--	[20-Mar-2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[10-Apr-2009]	Thanh Nguyen	Add parameter "@CMSEditable"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam		Remove parameters @PageSize, @PageIndex
--									Rename parameter @PageNumber to @TabID
--									Change from Page view to Tab view
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetDynamicFields]
	@AccountID int,
	@TabID int = 1, 
	@ClientID int = 0, -- if @ClientID <= 0 then set @ClientID equals ClientID of account
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF (@AccountID > 0 AND @ClientID <= 0)
		SELECT @ClientID = ClientID
		FROM Account
		WHERE AccountID = @AccountID

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[TableID],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], CASE WHEN @CMSEditable = 1 THEN [CMSEdit] ELSE [Editable] END as [Editable], 
				[GroupID], [GroupDesc], [DisplayOrder], [RangeID], [DropDown], [TableID], [Mandatory]
		FROM CWX_AccountInformation_Dict
		WHERE Displayed = 1	AND TabID = @TabID
			AND (@CMSEditable = 0 OR (@CMSEditable = 1 AND [CMSEdit] = 1))
			AND (ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Account' AND [Type]='U')
			OR object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'AccountOther' AND [Type]='U')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList_Account varchar(4000), @FieldNameList_AccountOther varchar(4000)
	DECLARE @FieldName varchar(50), @TableID int
	SET @FieldNameList_Account = 'AccountID,InvoiceNumber,DebtorID,EmployeeID,ClientID,QueueDate,AgencyStatusID,SystemStatusID,ActionCodeID,OfficeID,MCode,CCode,BucketMovement,SubmissionDate,LastEditDate,LastEditBy,CurrencyCode,InterfaceID,CloseDate'
	SET @FieldNameList_AccountOther = 'AccountID'

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName, TableID FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF (@TableID = 1) -- Account table
			SET @FieldNameList_Account = @FieldNameList_Account + ',' + @FieldName
		ELSE IF (@TableID = 2) -- AccountOther table
			SET @FieldNameList_AccountOther = @FieldNameList_AccountOther + ',' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql1 varchar(1000), @Sql2 varchar(1000)
	SET @Sql1 = 'SELECT ' + @FieldNameList_Account + ' FROM Account WHERE AccountID = ' + Cast(@AccountID as varchar)
	SET @Sql2 = 'SELECT ' + @FieldNameList_AccountOther + ' FROM AccountOther WHERE AccountID = ' + Cast(@AccountID as varchar)
	
	EXEC (@Sql1)
	EXEC (@Sql2)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 06/05/2009 14:49:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 06/05/2009 14:49:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Minh Dam
-- Create date: 15/08/2008
-- Description:	Get dynamic fields of a collateral
-- History:
--	[06 Mar 2009]	Thuy Nguyen		Init version.
--	[20 Mar 2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory", "RangeID", "DropDown", "SQLDropDown", "Listed" field columns into returned dynamic fields tables
-- =============================================				
CREATE PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
	@CollateralID int,
	@TabID int = 1,
	@ClientID int = 0,
	@CollateralTypeID int = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @CollateralID > 0 AND @CollateralTypeID IS NULL
		SELECT @CollateralTypeID = CollateralType FROM Collateral WHERE ID = @CollateralID

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc],
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc],
			a.[DisplayOrder],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], 
				[DisplayOrder], [DropDown], [RangeID], [Mandatory]
		FROM CWX_Collateral_Dict
		WHERE Displayed = 1 AND TabID = @TabID
			AND (@ClientID = 0 OR ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)
			AND (@CollateralTypeID = 0 OR ISNULL(CollateralTypeID, 0) = 0 OR CollateralTypeID = @CollateralTypeID)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Collateral' and [Type]='U')
			AND (c.[name] LIKE 'CInt%' OR c.[name] LIKE 'CString%' OR c.[name] LIKE 'CDate%' OR c.[name] LIKE 'CMoney%')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'ID,AccountID,HostCollateralID,EmployeeID,NextActionDate,Image,ImageFileName,'
	SET @FieldNameList = @FieldNameList + 
		'(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6) IS NOT NULL THEN CollateralType ELSE 0 END) AS CollateralType,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7) IS NOT NULL THEN CollateralStage ELSE 0 END) AS CollateralStage,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2) IS NOT NULL THEN NextAction ELSE 0 END) AS NextAction'
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM Collateral WHERE ID = ' + Cast(@CollateralID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields

	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Person_GetDynamicFields]    Script Date: 06/05/2009 14:50:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Person_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Person_GetDynamicFields]    Script Date: 06/05/2009 14:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thuy Nguyen
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an person
-- History:
--	[06-Mar-2009]	Thuy Nguyen		Init version.
--	[20-Mar-2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[10-Apr-2009]	Thanh Nguyen	Add parameter "@CMSEditable"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam		Rename parameter @PageNumber to @TabID
--									Rename parameter @Client to @ClientID
--									Remove parameters @PageSize, @PageIndex
--									Change from Page view to Tab view
--  [02-June-2009]	ThanhNguyen		Remove @ClientID from parameter list. Because base on Issue 68: DebtorInformation And PersonInformation don't have ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
	@PersonID int,
	@TabID int = 1,	
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc],
			b.[DataType],
			b.[MaxLength],
			a.[Editable],
			a.[GroupID],
			a.[GroupDesc], 
			a.[DisplayOrder],			
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], CASE WHEN @CMSEditable = 1 THEN [CMSEdit] ELSE [Editable] END as [Editable],
				[GroupID], [GroupDesc], [DisplayOrder], [RangeID], [DropDown], [Mandatory]
		FROM	CWX_PersonInformation_Dict
		WHERE	Displayed = 1 AND TabID = @TabID
				AND (@CMSEditable = 0 OR (@CMSEditable = 1 AND [CMSEdit] = 1))				
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'PersonInformation' and [Type]='U')			
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'PersonID, LastName, FirstName, MiddleName, PString1'
	
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM PersonInformation WHERE PersonID = ' + Cast(@PersonID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Product_GetDynamicFields]    Script Date: 06/05/2009 14:50:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_GetDynamicFields]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Product_GetDynamicFields]    Script Date: 06/05/2009 14:51:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 17 Mar 2009
-- Description:	Get dynamic fields and data of an client
-- History:
--	[17 Mar 2009]	Minh Dam	Init version.
--	[22-Apr-2009]	Minh Dam	Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam	Remove parameters @PageSize, @PageIndex
--								Rename parameter @PageNumber to @TabID
--								Change from Page view to Tab view
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Product_GetDynamicFields]
	-- Add the parameters for the stored procedure here
	@ClientID int,
	@TabID int = 1,
	@ClientDictID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.[Listed], 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], 
				[DisplayOrder], [DropDown], [RangeID], [Mandatory]
		FROM CWX_ClientInformation_Dict
		WHERE Displayed = 1	AND TabID = @TabID AND (ClientID = @ClientDictID OR ISNULL(ClientID,0) = 0)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'ClientInformation' AND [Type]='U')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000)
	DECLARE @FieldName varchar(50)
	SET @FieldNameList = 'ClientID,ClientName,Priority,AgingForReschedule,AgingForDiscount,RescheduleAllowed,DiscountAllowed,LetterheadImage,CreditorID,PaymentAllocationRuleID,AgingForApportion,ApportionAllowed' --ClientActive

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(1000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM ClientInformation WHERE ClientID = ' + Cast(@ClientID as varchar)
	
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

END
GO

/****** Object:  Table [dbo].[CWX_DropDownDataDictionary]    Script Date: 06/05/2009 14:53:37 ******/
IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DropDownDataDictionary]') AND type in (N'U'))
BEGIN	

	CREATE TABLE [dbo].[CWX_DropDownDataDictionary](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[SQL] [varchar](max) NULL,
		[Listed] [bit] NOT NULL CONSTRAINT [DF_CWX_DropDownDataDictionary_Listed]  DEFAULT ((0)),
		[Lookup] [bit] NOT NULL CONSTRAINT [DF_CWX_DropDownDataDictionary_Lookup]  DEFAULT ((0)),
	 CONSTRAINT [PK_CWX_DropDownDataDictionary] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_DEBTOR_DETAILINFOAFTERSAVING]    Script Date: 06/05/2009 14:55:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DEBTOR_DETAILINFOAFTERSAVING]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DEBTOR_DETAILINFOAFTERSAVING]
GO

/****** Object:  StoredProcedure [dbo].[CWX_DEBTOR_DETAILINFOAFTERSAVING]    Script Date: 06/05/2009 14:55:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<ThanhNguyen>
-- Create date: <March 10, 2009>
-- Description:	<Update identityfield table when add new debtorinformatio and add 9 records to PersonPhone and PersonAddress>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DEBTOR_DETAILINFOAFTERSAVING]	
	@PersonID int,
	@EmployeeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from	
	SET NOCOUNT ON;
    
	UPDATE IdentityFields
	SET FieldValue = FieldValue + 1
	WHERE LOWER(TableName) = LOWER('PersonInformation')
	
	DECLARE @DebtorID int	
	SELECT @DebtorID = MAX(DebtorID) + 1
	FROM DebtorInformation

	UPDATE IdentityFields
	SET FieldValue = FieldValue + 1
	WHERE LOWER(TableName) = LOWER('DebtorInformation')
			
	DECLARE @index int
	DECLARE @num int
	SET @num = 9
	
	DECLARE @AddressID int
	SELECT @AddressID = MAX(AddressID)
	FROM PersonAddress

	UPDATE IdentityFields
	SET FieldValue = FieldValue + @num + 1
	WHERE LOWER(TableName) = LOWER('PersonAddress')

	DECLARE @PhoneID int
	SELECT @PhoneID = MAX(PhoneID)
	FROM PersonPhone

	UPDATE IdentityFields
	SET FieldValue = FieldValue + @num + 1
	WHERE LOWER(TableName) = LOWER('PersonPhone')
	
	SET @index = 1
	WHILE @index <= @num
	BEGIN
		INSERT INTO PersonAddress
		(
			AddressID,
			PersonID,
			AddressType,
			AddressStatus,
			EmployeeID,
			CreateDate
		)
		VALUES
		(
			@AddressID + @index,
			@PersonID,
			@index,
			0,
			@EmployeeID,
			GETDATE()
		)		

		INSERT INTO PersonPhone
		(
			PhoneID,
			PersonID,
			PhoneType,
			PhoneStatus,
			EmployeeID,
			CreateDate
		)
		VALUES
		(
			@PhoneID + @index,
			@PersonID,
			@index,
			0,
			@EmployeeID,
			GETDATE()
		)		

		SET @index = @index + 1
	END	
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Debtor_Search]    Script Date: 06/05/2009 14:55:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Debtor_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Debtor_Search]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Debtor_Search]    Script Date: 06/05/2009 14:56:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 05 Mar 2009
-- Description:	Search debtor by debtor's name and group name
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Debtor_Search]
	-- Add the parameters for the stored procedure here
	@DebtorName varchar(50) = '',
	@GroupName varchar(50) = '',
	@PageSize int = 10,
	@PageIndex int = 0
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		DECLARE @Sql nvarchar(1000), @Params nvarchar(100)
		DECLARE @NewLine varchar(2)
		SET @NewLine = '
	'

		SET @Params = '@PageSize int, @PageIndex int, @RowCount int OUTPUT'
		SET @Sql = 
	'SELECT ROW_NUMBER() OVER (ORDER BY d.GroupName) as RowNumber,
			d.DebtorID, d.GroupName, 
			ISNULL(p.FirstName,'''') + '' '' + ISNULL(p.MiddleName,'''') + '' '' + ISNULL(p.LastName,'''') as FullName
	INTO #temp
	FROM DebtorInformation d
		INNER JOIN PersonInformation p ON d.PersonID = p.PersonID
	WHERE 1=1' + @NewLine

		IF (@DebtorName <> '')
			SET @Sql = @Sql + 'AND (p.FirstName like ''@@DebtorName%'' OR p.MiddleName like ''@@DebtorName%'' OR p.LastName like ''@@DebtorName%'')' + @NewLine
		
		IF (@GroupName <> '')
			SET @Sql = @Sql + 'AND d.GroupName = ''' + @GroupName + '''' + @NewLine

		SET @Sql = @Sql + 'SELECT @RowCount = COUNT(*) FROM #temp' + @NewLine
		SET @Sql = @Sql + 
	'SELECT DebtorID, GroupName, FullName FROM #temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize'

		SET @Sql = REPLACE(@Sql, '@@DebtorName', @DebtorName)

		DECLARE @RowCount int
		Exec sp_executesql @Sql, @Params, @PageSize, @PageIndex, @RowCount OUTPUT

		RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_IsAccountNumberExisted]    Script Date: 06/05/2009 14:57:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_IsAccountNumberExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_IsAccountNumberExisted]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_IsAccountNumberExisted]    Script Date: 06/05/2009 14:58:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 18 Mar 2009
-- Description:	Check if Description is existed in table CWX_CLIENTYPE
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_IsAccountNumberExisted]
	-- Add the parameters for the stored procedure here
	@AccountNumber varchar(50) = '',
	@AccountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS (SELECT 1 FROM Account WHERE @AccountNumber <> '' AND InvoiceNumber = @AccountNumber AND AccountID <> @AccountID)
		RETURN 1
	ELSE 
		RETURN 0
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_DetailInfoAfterSaving]    Script Date: 06/05/2009 14:58:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_DetailInfoAfterSaving]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_DetailInfoAfterSaving]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_DetailInfoAfterSaving]    Script Date: 06/05/2009 14:58:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 11 Mar 2009
-- Description:	Update identity fields after saving account information
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_DetailInfoAfterSaving]
	-- Add the parameters for the stored procedure here
	@AccountID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Increase 'Account' by one
	UPDATE IdentityFields 
	SET FieldValue = FieldValue + 1 
	WHERE TableName = 'Account'

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetRuleAccountsDetail]    Script Date: 06/05/2009 15:44:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetRuleAccountsDetail]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetRuleAccountsDetail]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetAccountListForClientDebtorsView]    Script Date: 06/05/2009 15:44:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetAccountListForClientDebtorsView]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetAccountListForClientDebtorsView]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]    Script Date: 06/05/2009 15:44:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]    Script Date: 06/05/2009 15:44:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetEmployeePortfolio]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transactons_GetTransactionList]    Script Date: 06/05/2009 15:44:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transactons_GetTransactionList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transactons_GetTransactionList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 06/05/2009 15:44:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]    Script Date: 06/05/2009 15:44:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientTranTypeProperties_GetList]    Script Date: 06/05/2009 15:44:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTranTypeProperties_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientTranTypeProperties_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]    Script Date: 06/05/2009 15:44:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientTranTypeProperties_GetTransactionTypes]    Script Date: 06/05/2009 15:44:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTranTypeProperties_GetTransactionTypes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientTranTypeProperties_GetTransactionTypes]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TransactionType_GetFinancialTypeByTransactionType]    Script Date: 06/05/2009 15:44:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionType_GetFinancialTypeByTransactionType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TransactionType_GetFinancialTypeByTransactionType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientNotes_GetPagingListByClientID]    Script Date: 06/05/2009 15:44:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientNotes_GetPagingListByClientID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientNotes_GetPagingListByClientID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_StandardNotes_DeleteAll]    Script Date: 06/05/2009 15:44:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_StandardNotes_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_StandardNotes_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_SaveInfo]    Script Date: 06/05/2009 15:44:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_SaveInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CosigneeInformation_SaveInfo]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueByAmtRange]    Script Date: 06/05/2009 15:45:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_QueueByAmtRange]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_QueueByAmtRange]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseStat]    Script Date: 06/05/2009 15:44:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetPromiseStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseStat]
GO
/****** Object:  StoredProcedure [dbo].[SearchByLegalGroupCode]    Script Date: 06/05/2009 15:44:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchByLegalGroupCode]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchByLegalGroupCode]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientTaxTranType_GetListBaseOnClient]    Script Date: 06/05/2009 15:44:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTaxTranType_GetListBaseOnClient]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientTaxTranType_GetListBaseOnClient]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtList]    Script Date: 06/05/2009 15:44:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 06/05/2009 15:44:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientInformation_GetAssignedClients]    Script Date: 06/05/2009 15:44:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_GetAssignedClients]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientInformation_GetAssignedClients]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientInformation_GetAvailableClients]    Script Date: 06/05/2009 15:44:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_GetAvailableClients]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientInformation_GetAvailableClients]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_GetLockedDebtorList]    Script Date: 06/05/2009 15:44:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInformation_GetLockedDebtorList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DebtorInformation_GetLockedDebtorList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientStatus_SoftDeleteAll]    Script Date: 06/05/2009 15:44:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientStatus_SoftDeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientStatus_SoftDeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetLoginDetails]    Script Date: 06/05/2009 15:44:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetLoginDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetLoginDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Product_GetByEmployee]    Script Date: 06/05/2009 15:44:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_GetByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanCriteria_DeleteAllByRuleID]    Script Date: 06/05/2009 15:44:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanCriteria_DeleteAllByRuleID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlanCriteria_DeleteAllByRuleID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanCriteria_GetListByRuleID]    Script Date: 06/05/2009 15:44:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanCriteria_GetListByRuleID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlanCriteria_GetListByRuleID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientTaxTranType_SaveData]    Script Date: 06/05/2009 15:44:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTaxTranType_SaveData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientTaxTranType_SaveData]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Currency_GetCurrencyList]    Script Date: 06/05/2009 15:44:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Currency_GetCurrencyList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Currency_GetCurrencyList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]    Script Date: 06/05/2009 15:44:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetTotalQueueStatsByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalAgent]    Script Date: 06/05/2009 15:45:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalAgent]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByLegalAgent]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_Search]    Script Date: 06/05/2009 15:44:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 06/05/2009 15:45:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalForward]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByLegalForward]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByEmployeeName]    Script Date: 06/05/2009 15:45:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByEmployeeName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByEmployeeName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalEmployee]    Script Date: 06/05/2009 15:45:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByLegalEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_StandardNote_DeleteAll]    Script Date: 06/05/2009 15:44:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_StandardNote_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_InformationTable_StandardNote_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByName]    Script Date: 06/05/2009 15:45:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchDebtorByName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 06/05/2009 15:44:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetQueueStatsByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_FillPagingList]    Script Date: 06/05/2009 15:44:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_FillPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleTable_FillPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientEmployee_Delete]    Script Date: 06/05/2009 15:44:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientEmployee_Delete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientEmployee_Delete]
GO
/****** Object:  StoredProcedure [dbo].[SearchAccountByBill]    Script Date: 06/05/2009 15:44:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchAccountByBill]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchAccountByBill]
GO
/****** Object:  StoredProcedure [dbo].[SearchAccountByInvoice]    Script Date: 06/05/2009 15:44:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchAccountByInvoice]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchAccountByInvoice]
GO
/****** Object:  StoredProcedure [dbo].[SearchDebtorByPhone]    Script Date: 06/05/2009 15:44:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchDebtorByPhone]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchDebtorByPhone]
GO
/****** Object:  StoredProcedure [dbo].[SearchAccountByMobile]    Script Date: 06/05/2009 15:44:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchAccountByMobile]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchAccountByMobile]
GO
/****** Object:  StoredProcedure [dbo].[SearchByofficePhone]    Script Date: 06/05/2009 15:44:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchByofficePhone]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchByofficePhone]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanCriteria_TestRule]    Script Date: 06/05/2009 15:44:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanCriteria_TestRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlanCriteria_TestRule]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_GetCollateralCustomFields]    Script Date: 06/05/2009 15:44:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_GetCollateralCustomFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TracerInformation_GetCollateralCustomFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanRule_Delete]    Script Date: 06/05/2009 15:44:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanRule_Delete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlanRule_Delete]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_IsAccountNumberExisted]    Script Date: 06/05/2009 15:44:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_IsAccountNumberExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_IsAccountNumberExisted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CollateralCustomFields_DeleteOthers]    Script Date: 06/05/2009 15:44:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CollateralCustomFields_DeleteOthers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CollateralCustomFields_DeleteOthers]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanRule_DeleteAll]    Script Date: 06/05/2009 15:44:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanRule_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlanRule_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AgencyDefinedMaster_IsEditable]    Script Date: 06/05/2009 15:44:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AgencyDefinedMaster_IsEditable]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AgencyDefinedMaster_IsEditable]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_CheckPrimaryDebtor]    Script Date: 06/05/2009 15:44:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_CheckPrimaryDebtor]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CosigneeInformation_CheckPrimaryDebtor]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_LockAccounts]    Script Date: 06/05/2009 15:44:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInformation_LockAccounts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DebtorInformation_LockAccounts]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Product_GetAllTabs]    Script Date: 06/05/2009 15:44:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetAllTabs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_GetAllTabs]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_UnlockAccounts]    Script Date: 06/05/2009 15:44:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInformation_UnlockAccounts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DebtorInformation_UnlockAccounts]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetDropDownLookupValues]    Script Date: 06/05/2009 15:44:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetDropDownLookupValues]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetDropDownLookupValues]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_UpdateTransactionTypePosted]    Script Date: 06/05/2009 15:44:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_UpdateTransactionTypePosted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_UpdateTransactionTypePosted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountInformation_GetAllTabs]    Script Date: 06/05/2009 15:44:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountInformation_GetAllTabs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountInformation_GetAllTabs]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetAllTabs]    Script Date: 06/05/2009 15:44:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetAllTabs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetAllTabs]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetChildTransactions]    Script Date: 06/05/2009 15:44:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetChildTransactions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetChildTransactions]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonInformation_GetAllTabs]    Script Date: 06/05/2009 15:44:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonInformation_GetAllTabs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonInformation_GetAllTabs]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionType]    Script Date: 06/05/2009 15:44:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommModel_GetPagingList]    Script Date: 06/05/2009 15:44:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommModel_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommModel_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientInformation_GetNoCommissionModelClients]    Script Date: 06/05/2009 15:44:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_GetNoCommissionModelClients]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientInformation_GetNoCommissionModelClients]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 06/05/2009 15:44:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXML]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_LoadXML]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommModel_DeleteAll]    Script Date: 06/05/2009 15:44:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommModel_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommModel_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlan_DeleteAll]    Script Date: 06/05/2009 15:44:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlan_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlan_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ReportScheduleTable_GetCustomPagingList]    Script Date: 06/05/2009 15:44:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ReportScheduleTable_GetCustomPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ReportScheduleTable_GetCustomPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientType_IsDescriptionExisted]    Script Date: 06/05/2009 15:44:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientType_IsDescriptionExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientType_IsDescriptionExisted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_CustomDefinedField_Select]    Script Date: 06/05/2009 15:44:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_CustomDefinedField_Select]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TracerInformation_CustomDefinedField_Select]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientType_SoftDeleteAll]    Script Date: 06/05/2009 15:44:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientType_SoftDeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientType_SoftDeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCategory_IsDescriptionExisted]    Script Date: 06/05/2009 15:44:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCategory_IsDescriptionExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCategory_IsDescriptionExisted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCategory_SoftDeleteAll]    Script Date: 06/05/2009 15:44:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCategory_SoftDeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCategory_SoftDeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientStatus_IsDescriptionExisted]    Script Date: 06/05/2009 15:44:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientStatus_IsDescriptionExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientStatus_IsDescriptionExisted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetEmployeeIDBySupervisor]    Script Date: 06/05/2009 15:44:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetEmployeeIDBySupervisor]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetEmployeeIDBySupervisor]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_UnlockAllDebtors]    Script Date: 06/05/2009 15:44:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInformation_UnlockAllDebtors]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DebtorInformation_UnlockAllDebtors]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_SearchActiveEmployee]    Script Date: 06/05/2009 15:44:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_SearchActiveEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_SearchActiveEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_SeachPersonInformation]    Script Date: 06/05/2009 15:44:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_SeachPersonInformation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_SeachPersonInformation]
GO
/****** Object:  StoredProcedure [dbo].[SearchDebtorBySocial]    Script Date: 06/05/2009 15:44:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchDebtorBySocial]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchDebtorBySocial]
GO
/****** Object:  UserDefinedFunction [dbo].[CWX_AssignedClientIDTable]    Script Date: 06/05/2009 15:47:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AssignedClientIDTable]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CWX_AssignedClientIDTable]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionTypeInCaseEdit]    Script Date: 06/18/2009 15:59:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionTypeInCaseEdit]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionTypeInCaseEdit]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Views_GroupByFinancialType]    Script Date: 06/18/2009 15:59:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Views_GroupByFinancialType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Views_GroupByFinancialType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Views_GroupByAccountStatus]    Script Date: 06/18/2009 15:59:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Views_GroupByAccountStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Views_GroupByAccountStatus]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_DeleteTransaction]    Script Date: 06/18/2009 15:59:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_DeleteTransaction]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_DeleteTransaction]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientProperties_GetNoPropertiesClients]    Script Date: 06/18/2009 15:59:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties_GetNoPropertiesClients]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientProperties_GetNoPropertiesClients]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientProperties_GetClientsHaveProperties]    Script Date: 06/18/2009 15:59:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties_GetClientsHaveProperties]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientProperties_GetClientsHaveProperties]
GO
/****** Object:  StoredProcedure [dbo].[CWX_SMTP_SMS_Settings_Get]    Script Date: 06/18/2009 16:35:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMTP_SMS_Settings_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_SMTP_SMS_Settings_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_SMTP_SMS_SettingsUpdate]    Script Date: 06/18/2009 16:35:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMTP_SMS_SettingsUpdate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_SMTP_SMS_SettingsUpdate]
GO
/****** Object:  StoredProcedure [dbo].[CWX_SMTP_SMS_Check_MobilePhoneExist]    Script Date: 06/18/2009 16:35:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMTP_SMS_Check_MobilePhoneExist]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_SMTP_SMS_Check_MobilePhoneExist]
GO
/****** Object:  StoredProcedure [dbo].[CWX_SMS_SendingToTable_SendSMS]    Script Date: 06/18/2009 16:35:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMS_SendingToTable_SendSMS]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_SMS_SendingToTable_SendSMS]
GO
/****** Object:  StoredProcedure [dbo].[CWX_SMSMail_History_GetPagingList]    Script Date: 06/18/2009 16:35:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMSMail_History_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_SMSMail_History_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_SMSNMailTemplates_SoftDeleteAll]    Script Date: 06/18/2009 16:35:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMSNMailTemplates_SoftDeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_SMSNMailTemplates_SoftDeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseStat]    Script Date: 06/05/2009 15:44:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetPromiseStat]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get Promise Statistics
-- History:
--		2008/04/29	[Binh Truong]	Init version
--		2008/05/05	[Binh Truong]	Add criteria to exclude closed AccountStatus.
--		2008/05/07	[Binh Truong]	Add specific AccountPromise table name of a column to fix ambiguous 
--									column name ''EmployeeID''
--		2009/03/31	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseStat] 	
(
	@EmployeeID int = 0,
	@From datetime = NULL,
	@To datetime = NULL,
	@ClientID int = 0
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @Statement NVARCHAR(4000)
	DECLARE @Select NVARCHAR(1000)
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @GroupBy NVARCHAR(50)
	DECLARE @OrderBy NVARCHAR(50)
	DECLARE @Parms NVARCHAR(500)
		
	SET @Select = ''	
		SELECT		AccountPromise.Status, COUNT(*) AS AccountAmount, SUM(cast(AmountPromised as decimal)) AS Promised, SUM(cast(AmountPaid as decimal)) AS Paid
		FROM        AccountPromise INNER JOIN
							Account ON AccountPromise.AccountID = Account.AccountID
		''
	SET @Conditions = '' WHERE (Account.AgencyStatusID <> 2) ''
	SET @GroupBy = '' GROUP BY AccountPromise.Status ''
	SET @OrderBy = '' ORDER BY AccountPromise.Status ''
	
	IF @EmployeeID <> 0
	BEGIN
		SET @Conditions = @Conditions +
			''
			AND AccountPromise.EmployeeID = @EmployeeID
			AND (@ClientID = 0 OR Account.ClientID = @ClientID)
			''
	END
	
	IF @From IS NOT NULL
	BEGIN
		SET @To = DATEADD(day, 1, @To)
		SET @Conditions = @Conditions +
			''
			AND (DatePromised >= @From AND DatePromised < @To)
			''	
	END
	
	SET @Statement = @Select + @Conditions + @GroupBy + @OrderBy
	
	SET @Parms = ''
			@EmployeeID int,
			@From datetime,
			@To datetime,
			@ClientID int = 0
			''
print @Statement
	EXEC dbo.sp_executesql @Statement, @Parms,
							@EmployeeID,
							@From,
							@To,
							@ClientID


END
' 
END
GO
/****** Object:  Table [dbo].[CWX_ClientCategory]    Script Date: 06/05/2009 15:45:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCategory]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCategory](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](100) NULL,
	[Status] [char](1) NULL CONSTRAINT [DF_CWX_ClientCategory_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_CWX_ClientCategory] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]    Script Date: 06/05/2009 15:44:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetEmployeePortfolio]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get employee portfolio.
-- Parameters: 
--		0: Queue Active
--		Other number: All accounts
-- History:
--		2008/04/17	[Binh Truong]	Init version.
--		2008/05/15	[Binh Truong]	Cast BillBalance field to decimal(18,2) to fix Arithmetic overflow error converting expression.
--		2008/07/10	[Binh Truong]	Fix BillBalance NULL returned values.
--		2008/08/14	[Binh Truong]	EmployeeStatus = ''A''  >>>  EmployeeStatus <> ''R'' 
--		2009/03/30	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]
	@PorfolioType smallint = 0,
	@ClientID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @TotalAccStatement NVARCHAR(1000)
	DECLARE @TotalDollarValueStatement NVARCHAR(1000)
	DECLARE @MainStatement NVARCHAR(4000)
	DECLARE @RowCount INT
	
	SET @Conditions = ''''	

	IF @PorfolioType = 0		
		SET @Conditions = ''
			AND SystemStatusId = 5 
			AND AgencyStatusID <> 2 
			AND QueueDate <= GETDATE()
			''
	IF @ClientID > 0
		SET @Conditions = @Conditions + ''AND ClientID = '' + cast(@ClientID as varchar)
	
	DECLARE @ParmDefinition NVARCHAR(500);
	DECLARE @TotalAccount INT;
	DECLARE @TotalDollarValue DECIMAL(18,2);

	SET @TotalAccStatement = N''SELECT @TotalAccountOUT = COUNT(*) FROM Account WHERE (1=1) '';
	SET @TotalAccStatement = @TotalAccStatement + @Conditions
	SET @ParmDefinition = N''@TotalAccountOUT INT OUTPUT'';

	EXECUTE sp_executesql @TotalAccStatement, @ParmDefinition, @TotalAccountOUT=@TotalAccount OUTPUT;

	SET @TotalDollarValueStatement = N''SELECT @TotalDollarValueOUT = SUM(cast(ISNULL(BillBalance,0) as decimal)) FROM Account WHERE (1=1) '';
	SET @TotalDollarValueStatement = @TotalDollarValueStatement + @Conditions
	SET @ParmDefinition = N''@TotalDollarValueOUT DECIMAL(18,2) OUTPUT'';

	EXECUTE sp_executesql @TotalDollarValueStatement, @ParmDefinition, @TotalDollarValueOUT=@TotalDollarValue OUTPUT;
	
	--Build the MainStatement
	SET @MainStatement = ''INSERT INTO #Temp SELECT Employee.EmployeeID, Employee.EmployeeName, ''

	SET @MainStatement = @MainStatement + '' (SELECT COUNT(EmployeeID) AS Expr1
						FROM          Account AS AT
						WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalAccount, ''
	
	SET @MainStatement = @MainStatement + '' (SELECT CAST(((COUNT(EmployeeID) * 100) / CAST('' + CAST(@TotalAccount AS VARCHAR(30)) + '' AS DECIMAL(18,2))) AS DECIMAL(18,2)) AS Expr1
						FROM          Account AS AT
						WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalAccountPercent, ''
    
	SET @MainStatement = @MainStatement + '' (SELECT     CAST(SUM(cast(ISNULL(BillBalance,0) as decimal)) as decimal(18,2)) 
                    FROM        Account AS AT
                    WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalDollarValue, ''

	SET @MainStatement = @MainStatement + '' (SELECT     CAST(SUM(cast(ISNULL(BillBalance,0) as decimal)) as decimal(18,2)) * 100 / CAST('' + CAST(@TotalDollarValue AS VARCHAR(30)) + ''AS DECIMAL(18,2)) AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalDollarValuePercent, ''

	SET @MainStatement = @MainStatement + '' (SELECT     COUNT(TempEmployeeID) AS Expr1
					FROM          Account AS AT
					WHERE      (AT.TempEmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.TempEmployeeID) AS TotalAccountTemp, '' 

	SET @MainStatement = @MainStatement + '' (SELECT     SUM(cast(ISNULL(BillBalance,0) as decimal)) AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.TempEmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.TempEmployeeID) AS TotalDollarValueAccountTemp ''

	SET @MainStatement = @MainStatement + '' FROM  Employee WHERE EmployeeStatus <> ''''R'''''' 

	IF (@ClientID > 0)
		SET @MainStatement = @MainStatement + '' AND EmployeeID IN (SELECT EmployeeID FROM CWX_ClientEmployee WHERE ClientID = '' + cast(@ClientID as varchar) + '')''

print @MainStatement
	CREATE TABLE #Temp
	(
		Idx int IDENTITY,
		EmployeeID int,
		EmployeeName varchar(50),
		TotalAccount int,
		TotalAccountPercent DECIMAL(18,0),
		TotalDollarValue DECIMAL(18,2),
		TotalDollarValuePercent DECIMAL(18,0),
		TotalAccountTemp int,
		TotalDollarValueAccountTemp DECIMAL(18,2)		
	)

	EXEC dbo.sp_executesql @MainStatement
	
	SELECT @RowCount = Count(Idx) FROM #Temp

	SELECT  EmployeeName,
			EmployeeID,
			ISNULL(TotalAccount, 0) AS TotalAccount,
			CAST(ISNULL(TotalAccountPercent, 0) as varchar(50)) AS TotalAccountPercent,
			ISNULL(TotalDollarValue, 0) AS TotalDollarValue,
			CAST(ISNULL(TotalDollarValuePercent, 0) as varchar(50)) AS TotalDollarValuePercent,
			ISNULL(TotalAccountTemp, 0) AS TotalAccountTemp,
			ISNULL(TotalDollarValueAccountTemp, 0) AS TotalDollarValueAccountTemp
			
	FROM #Temp WHERE Idx between (@PageIndex)*@PageSize + 1 and (@PageIndex + 1)*@PageSize

	DROP TABLE #Temp
	
	RETURN @RowCount
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]    Script Date: 06/05/2009 15:44:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Description:	Get total active account and bill balance of collector
-- Parameters: 
--	@PorfolioType	0: Queue Active
--					Other number: All accounts
-- History:
--	2008/04/17	[Binh Truong]	Init version.
--	2008/04/23	[Binh Truong]	Cast BillBalance field to decimal to fix Arithmetic overflow error converting expression.
--	2008/07/10	[Binh Truong]	Fix NULL returned values.
--	2008/08/14	[Binh Truong]	EmployeeStatus = ''A''  >>>  EmployeeStatus <> ''R''
--	2009/03/30	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]
	@PorfolioType AS SMALLINT,
	@ClientID int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Select NVARCHAR(1000)
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @Statement NVARCHAR(2000)
	DECLARE @Parms NVARCHAR(500)
	
	SET @Conditions = '' WHERE (Employee.EmployeeStatus <> ''''R'''') ''	
	
	SET @Select = ''
		SELECT	COUNT(Account.AccountID) AS TotalAccount,
				ISNULL(SUM(CAST(Account.BillBalance as decimal)),0) as TotalDollarValue 
		FROM         Account INNER JOIN
                      Employee ON Account.EmployeeID = Employee.EmployeeID     
		'' 		
		
	IF @PorfolioType = 0		
		SET @Conditions = @Conditions + ''
					AND SystemStatusId = 5 
					AND AgencyStatusID <> 2 
					AND QueueDate <= GETDATE()
			''
	IF @ClientID > 0
	BEGIN
		SET @Conditions = @Conditions + '' AND Account.ClientID = '' + cast(@ClientID as varchar)	
		SET @Conditions = @Conditions + '' AND Employee.EmployeeID IN (SELECT EmployeeID FROM CWX_ClientEmployee WHERE ClientID = '' + cast(@ClientID as varchar) + '')''
	END

	SET @Statement = @Select + @Conditions
print @Statement	
	EXEC dbo.sp_executesql @Statement
		
	SET @Select = ''
		SELECT	COUNT(Account.TempEmployeeID ) AS TotalTempAccount,
				ISNULL(SUM(CAST(BillBalance as decimal)),0) as TotalTempDollarValue 
		FROM         Account INNER JOIN
                      Employee ON Account.TempEmployeeID = Employee.EmployeeID     
		'' 		
		
	SET @Statement = @Select + @Conditions
print @Statement	
	EXEC dbo.sp_executesql @Statement
	
END
' 
END
GO
/****** Object:  Table [dbo].[CWX_ClientNotes]    Script Date: 06/05/2009 15:46:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientNotes]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientNotes](
	[NoteID] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[ClientID] [int] NOT NULL,
	[NoteDateTime] [datetime] NULL,
	[NoteText] [nvarchar](1000) NULL,
 CONSTRAINT [PK_ClientNotes] PRIMARY KEY CLUSTERED 
(
	[NoteID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[CWX_ClientStatus]    Script Date: 06/05/2009 15:46:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientStatus]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientStatus](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](100) NULL,
	[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientStatus_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_CWX_ClientStatus] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientCommPlanRule]    Script Date: 06/05/2009 15:45:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanRule]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommPlanRule](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientCommPlanID] [int] NOT NULL,
	[Code] [varchar](50) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[RatePercent] [decimal](19, 5) NULL CONSTRAINT [DF_CWX_ClientCommPlanRule_RatePercent]  DEFAULT ((0)),
	[FixedAmount] [money] NULL CONSTRAINT [DF_CWX_ClientCommPlanRule_FixedAmount]  DEFAULT ((0)),
	[Minimum] [money] NULL CONSTRAINT [DF_CWX_ClientCommPlanRule_Minimum]  DEFAULT ((0)),
	[Maximum] [money] NULL CONSTRAINT [DF_CWX_ClientCommPlanRule_Maximum]  DEFAULT ((0)),
 CONSTRAINT [PK_CWX_ClientCommissionPlanRule] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientCommModel]    Script Date: 06/18/2009 16:53:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommModel]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommModel](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [int] NOT NULL,
	[Code] [varchar](50) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[SetupTo] [tinyint] NOT NULL,
	[ModelType] [tinyint] NOT NULL,
	[ClientCommRateID] [int] NULL,
	[ClientCommPlanID] [int] NULL,
	[FinancialTypeID] [int] NULL,
	[SystemStatusID] [int] NULL,
	[TransactionTypeID] [int] NULL,
	[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientCommModel_Status]  DEFAULT ('A'),
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[UserID] [int] NULL,
	[IsActive] [bit] NOT NULL CONSTRAINT [DF_CWX_ClientCommModel_IsActive]  DEFAULT ((1)),
	[UpdateBy] [int] NULL,
	[Minimum] [money] NULL,
	[Maximum] [money] NULL,
 CONSTRAINT [PK_CWX_ClientCommModel_1] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientCommModelLog]    Script Date: 06/18/2009 16:53:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommModelLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommModelLog](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[ID] [int] NULL,
	[ClientID] [int] NOT NULL,
	[Code] [varchar](50) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[SetupTo] [tinyint] NOT NULL,
	[ModelType] [tinyint] NOT NULL,
	[ClientCommRateID] [int] NULL,
	[ClientCommPlanID] [int] NULL,
	[FinancialTypeID] [int] NULL,
	[SystemStatusID] [int] NULL,
	[TransactionTypeID] [int] NULL,
	[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientCommModelLog_Status]  DEFAULT ('A'),
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[UserID] [int] NULL,
	[IsActive] [bit] NOT NULL CONSTRAINT [DF_CWX_ClientCommModelLog_IsActive]  DEFAULT ((1)),
	[UpdateBy] [int] NULL,
	[Minimum] [money] NULL,
	[Maximum] [money] NULL,
 CONSTRAINT [PK_CWX_ClientCommModelLog_1] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientCommPlanCriteria]    Script Date: 06/05/2009 15:45:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanCriteria]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommPlanCriteria](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientCommPlanRuleID] [int] NOT NULL,
	[Criteria] [varchar](50) NOT NULL,
	[Operator] [varchar](50) NOT NULL,
	[MatchingCriteria] [varchar](255) NOT NULL,
	[SQLFormat] [varchar](350) NULL,
	[Combining] [varchar](10) NULL,
 CONSTRAINT [PK_CWX_ClientCommissionPlanCriteria] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetLoginDetails]    Script Date: 06/05/2009 15:44:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetLoginDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <6 September 2008>
-- History:
--		[2008/09/06]	[Thuy Nguyen]	Init version.
--		[2009/03/31]	[Minh Dam]		Add parameter "@ClientID" and fitler by ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_GetLoginDetails]
	@EmployeeIDString varchar(1000),
	@ClientID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount INT
	SET @RowCount = 0

	IF (@EmployeeIDString != '''')
	BEGIN
		DECLARE @querystring varchar(2000);
		CREATE TABLE #Temp(
			RowNumber int,
			EmployeeID int,
			EmployeeName varchar(10),
			ViewedNo int,		
			AccountIDViewing int
		);

		SET @querystring = ''INSERT INTO #Temp
			SELECT 
			ROW_NUMBER() OVER (ORDER BY  e.EmployeeID ASC) AS RowNumber,		
			e.EmployeeID, e.UserID, ISNULL(COUNT(a1.RecordID),0) AS ViewedNo, ISNULL(a2.AccountID,0) AS AccountIDViewing
			FROM Employee e		
			LEFT JOIN 
				(SELECT * FROM AccountActions 
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID = 8
					@@ClientCondition1
				) AS a1
			ON e.EmployeeID = a1.CompletedBy
			LEFT JOIN 
				(SELECT AccountID, CompletedBy FROM AccountActions AS a
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID = 8
					AND RecordID >= (SELECT MAX(RecordID) FROM AccountActions
												WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
												AND ActionID=8
												AND CompletedBy=a.CompletedBy)
					@@ClientCondition1
				) AS a2
			ON e.EmployeeID = a2.CompletedBy
			WHERE e.EmployeeID IN ('' + @EmployeeIDString + '')				
				@@ClientCondition2
			GROUP BY e.EmployeeID, e.UserID, a2.AccountID''
		
		IF (@ClientID > 0)	
		BEGIN
			SET @querystring = REPLACE(@querystring, ''@@ClientCondition1'', ''AND AccountID IN (SELECT AccountID FROM Account WHERE ClientID = '' + cast(@ClientID as varchar) + '')'')
			SET @querystring = REPLACE(@querystring, ''@@ClientCondition2'', ''AND e.EmployeeID IN (SELECT EmployeeID FROM CWX_ClientEmployee WHERE ClientID = '' + cast(@ClientID as varchar) + '')'')
		END
		ELSE	
		BEGIN
			SET @querystring = REPLACE(@querystring, ''@@ClientCondition1'', '''')
			SET @querystring = REPLACE(@querystring, ''@@ClientCondition2'', '''')
		END
print @QueryString
		EXEC (@querystring)
		
		SELECT @RowCount = @@ROWCOUNT
		
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
		
		DROP TABLE #Temp
	END
	
	RETURN @RowCount

END
' 
END
GO
/****** Object:  Table [dbo].[CWX_ClientCommRate]    Script Date: 06/05/2009 15:45:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommRate]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommRate](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[StartDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
	[RateType] [int] NULL,
	[RateAmount] [money] NULL,
	[BaseAmount] [money] NULL,
 CONSTRAINT [PK_CWX_ClientCommissionRate] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[CWX_TimeZone]    Script Date: 06/05/2009 15:47:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TimeZone]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_TimeZone](
	[TimeZoneID] [int] NOT NULL,
	[ZoneName] [nvarchar](200) NOT NULL,
 CONSTRAINT [PK_CWX_TimeZone] PRIMARY KEY CLUSTERED 
(
	[TimeZoneID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[CWX_ClientCommRateSlab]    Script Date: 06/05/2009 15:45:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommRateSlab]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommRateSlab](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientCommRateID] [int] NULL,
	[FromValue] [money] NULL,
	[ToValue] [money] NULL,
	[RatePercent] [decimal](19, 5) NULL,
	[RateAmount] [money] NULL,
	[Minimum] [money] NULL,
	[Maximum] [money] NULL,
 CONSTRAINT [PK_CWX_ClientCommissionRateSlab] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[CWX_ClientPropertySettings]    Script Date: 06/05/2009 15:46:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientPropertySettings]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientPropertySettings](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Type] [int] NOT NULL,
	[Value] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_CWX_ClientPropertiesInformationTable] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[CWX_ClientPropertiesLog]    Script Date: 06/18/2009 16:53:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientPropertiesLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientPropertiesLog](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[ID] [int] NULL,
	[ClientID] [int] NULL,
	[BillingPeriod] [int] NULL,
	[InvoiceType] [int] NULL,
	[BillCommissiontoDebtor] [bit] NULL,
	[AgingType] [int] NULL,
	[ChargeFeeToClient] [bit] NULL,
	[ChargeFeetoDebtor] [bit] NULL,
	[Currency] [int] NULL,
	[StatementCurrency] [int] NULL,
	[ExchangeRate] [decimal](19, 5) NULL,
	[DebtorStatementSortOrder] [bit] NULL,
	[AddCommissionToOwing] [bit] NULL,
	[ReferralRate] [decimal](19, 5) NULL,
	[TaxExempt] [bit] NULL,
	[DiscountID] [int] NULL,
	[Status] [char](1) NULL CONSTRAINT [DF_CWX_ClientPropertiesLog_Status]  DEFAULT ('A'),
	[ClientFixFee] [money] NULL,
	[DebtorFixFee] [money] NULL,
	[UpdateDate] [smalldatetime] NULL CONSTRAINT [DF_CWX_ClientPropertiesLog_UpdateDate]  DEFAULT (getdate()),
	[UpdateBy] [int] NULL,
	[Version] [int] NULL CONSTRAINT [DF_CWX_ClientPropertiesLog_Version]  DEFAULT ((1)),
	[CloseAccountCriteria] [money] NULL,
 CONSTRAINT [PK_CWX_ClientPropertiesLog_1] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientProperties]    Script Date: 06/18/2009 16:53:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientProperties](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [int] NOT NULL,
	[BillingPeriod] [int] NULL,
	[InvoiceType] [int] NULL,
	[BillCommissiontoDebtor] [bit] NULL,
	[AgingType] [int] NULL,
	[ChargeFeeToClient] [bit] NULL,
	[ChargeFeetoDebtor] [bit] NULL,
	[Currency] [int] NULL,
	[StatementCurrency] [int] NULL,
	[ExchangeRate] [decimal](19, 5) NULL,
	[DebtorStatementSortOrder] [bit] NULL,
	[AddCommissionToOwing] [bit] NULL,
	[ReferralRate] [decimal](19, 5) NULL,
	[TaxExempt] [bit] NULL,
	[DiscountID] [int] NULL,
	[Status] [char](1) NULL CONSTRAINT [DF_CWX_ClientProperties_Status]  DEFAULT ('A'),
	[ClientFixFee] [money] NULL,
	[DebtorFixFee] [money] NULL,
	[UpdateDate] [smalldatetime] NULL CONSTRAINT [DF_CWX_ClientProperties_UpdateDate]  DEFAULT (getdate()),
	[UpdateBy] [int] NULL,
	[Version] [int] NULL CONSTRAINT [DF_CWX_ClientProperties_Version]  DEFAULT ((1)),
	[CloseAccountCriteria] [money] NULL,
 CONSTRAINT [PK_CWX_ClientProperties] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientTax]    Script Date: 06/05/2009 15:46:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTax]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientTax](
	[ClientID] [int] NOT NULL,
	[TaxRate] [decimal](19, 5) NULL,
	[TaxType] [int] NULL,
	[CalculateTax] [bit] NULL,
	[CreateDate] [datetime] NULL,
	[UpdateDate] [datetime] NULL,
	[UserID] [int] NULL,
	[Status] [char](1) NULL,
 CONSTRAINT [PK_CWX_ClientTax] PRIMARY KEY CLUSTERED 
(
	[ClientID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientTaxTranType]    Script Date: 06/05/2009 15:46:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTaxTranType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientTaxTranType](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [int] NOT NULL,
	[FinancialTypeID] [int] NULL,
	[TransactionTypeID] [int] NULL,
	[TaxRate] [decimal](19, 5) NULL,
	[CreateDate] [datetime] NULL,
	[UpdateDate] [datetime] NULL,
	[UserID] [int] NULL,
	[Status] [char](1) NULL,
 CONSTRAINT [PK_CWX_ClientTaxTranType_1] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_Currency]    Script Date: 06/18/2009 17:01:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CWX_Currency](
	[CurrencyID] [int] IDENTITY(1,1) NOT NULL,
	[CurrencyName] [nvarchar](10) NULL,
	[Symbol] [char](3) NOT NULL,
 CONSTRAINT [PK_CWX_Currency] PRIMARY KEY CLUSTERED 
(
	[CurrencyID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
 CONSTRAINT [U_CWX_Currency_Symbol] UNIQUE NONCLUSTERED 
(
	[Symbol] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
/****** Object:  Table [dbo].[CWX_ClientCommPlan]    Script Date: 06/05/2009 15:45:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlan]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommPlan](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [varchar](50) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Type] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientCommPlan_Type]  DEFAULT ('S'),
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[IsActive] [bit] NOT NULL CONSTRAINT [DF_CWX_ClientCommPlan_IsActive]  DEFAULT ((1)),
	[UserID] [int] NULL,
	[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientCommPlan_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_CWX_ClientCommissionPlan] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_CollateralCustomFields]    Script Date: 06/05/2009 15:47:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CollateralCustomFields]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_CollateralCustomFields](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CollateralID] [int] NOT NULL,
	[AgencyID] [int] NOT NULL,
	[Value] [varchar](1000) NULL,
 CONSTRAINT [PK_Collateral_CustomFields] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientTranTypeProperties]    Script Date: 06/05/2009 15:47:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTranTypeProperties]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientTranTypeProperties](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [int] NULL,
	[TransactionTypeID] [int] NULL,
	[CalculateComm] [bit] NULL,
	[CalculateTax] [bit] NULL,
	[ChargeInterest] [bit] NULL,
	[OmitClientStatement] [bit] NULL,
	[OmitClientDailyReport] [bit] NULL,
	[AddToOwing] [bit] NULL,
	[OriginalInterest] [decimal](19, 5) NULL,
	[InterestType] [tinyint] NULL,
	[AnnualInterest] [decimal](19, 5) NULL,
	[Period] [tinyint] NULL,
	[CalculateFromDate] [datetime] NULL,
	[ChargeToClient] [bit] NULL,
	[Status] [char](10) NOT NULL,
	[ChargeRelatedParties] [bit] NULL,
 CONSTRAINT [PK_CWX_ClientTranTypeProperties] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_SMS_SendingToTable]    Script Date: 06/18/2009 16:53:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMS_SendingToTable]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_SMS_SendingToTable](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SMS_Status] [int] NULL,
	[Appln_ID] [int] NULL,
	[SMS_Recipient] [varchar](15) NULL,
	[SMS_Stype] [varchar](50) NULL,
	[SMS_Message] [nvarchar](2000) NULL,
	[Priority_Level] [int] NULL,
	[Schedule_Date] [datetime] NULL,
	[Confirm_Reqd] [varchar](50) NULL,
	[SMS_Author] [varchar](50) NULL,
	[Validity_Time] [bigint] NULL,
	[SMS_TimeAndDate] [datetime] NULL,
	[SMS_PickupDate] [datetime] NULL,
	[Org_ID] [bigint] NULL,
	[Provider_ID] [nchar](10) NULL,
	[SMS_Language] [varchar](50) NULL,
 CONSTRAINT [PK_CWX_SMS_SendingToTable] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_SMSMail_History]    Script Date: 06/18/2009 16:53:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMSMail_History]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_SMSMail_History](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[TemplateID] [int] NULL,
	[ChannelID] [int] NULL,
	[UserID] [int] NULL,
	[EmailAddress] [nvarchar](255) NULL,
	[SMS_Number] [nvarchar](50) NULL,
	[Fax_Number] [nvarchar](50) NULL,
	[MessageText] [nvarchar](2000) NULL,
	[Status] [char](2) NULL,
	[ProcessDate] [datetime] NULL,
 CONSTRAINT [PK_CWX_SMSMail_Log] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_SMSNMailTemplates]    Script Date: 06/18/2009 16:53:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMSNMailTemplates]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_SMSNMailTemplates](
	[Template_ID] [int] IDENTITY(1,1) NOT NULL,
	[Channel_ID] [int] NULL,
	[Message_Body] [nvarchar](2000) NULL,
	[CreateDate] [datetime] NULL,
	[UpdateDate] [datetime] NULL,
	[UserID] [int] NULL,
	[Status] [char](1) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Code] [varchar](10) NULL,
 CONSTRAINT [PK_CWX_SMSNMailTemplates] PRIMARY KEY CLUSTERED 
(
	[Template_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'CWX_SMSNMailTemplates', N'COLUMN',N'Channel_ID'))
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N' - 1 � Email, 2 - SMS' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'CWX_SMSNMailTemplates', @level2type=N'COLUMN',@level2name=N'Channel_ID'
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'CWX_SMSNMailTemplates', N'COLUMN',N'Message_Body'))
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'can be any language' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'CWX_SMSNMailTemplates', @level2type=N'COLUMN',@level2name=N'Message_Body'
GO

/****** Object:  Table [dbo].[CWX_SMTP_SMS_Settings]    Script Date: 06/18/2009 16:53:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMTP_SMS_Settings]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_SMTP_SMS_Settings](
	[SMTP_SMS_AccountID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](256) NULL,
	[Description] [nvarchar](256) NULL,
	[EmailAddress] [nvarchar](128) NULL,
	[DisplayName] [nvarchar](128) NULL,
	[ReplyToAddress] [nvarchar](128) NULL,
	[ServerType] [nvarchar](255) NULL,
	[ServerName] [nvarchar](255) NULL,
	[Port] [int] NULL,
	[UseDefaultCridentials] [bit] NULL,
	[DefaultEmailSubject] [nvarchar](255) NULL,
	[SMTP_UserName] [nvarchar](128) NULL,
	[SMTP_Password] [nvarchar](128) NULL,
	[SMTP_EnableSSL] [bit] NULL,
	[SMS_Gateway] [nvarchar](255) NULL,
	[SMS_UserName] [nvarchar](128) NULL,
	[SMS_Password] [nvarchar](128) NULL,
	[SMS_SendingTo] [int] NULL,
 CONSTRAINT [PK_CWX_SMTP_SMS_Settings] PRIMARY KEY CLUSTERED 
(
	[SMTP_SMS_AccountID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'MS_Description' , N'SCHEMA',N'dbo', N'TABLE',N'CWX_SMTP_SMS_Settings', N'COLUMN',N'SMS_SendingTo'))
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'0: Unspecify; 1: Sending To Output file; 2: Sendingto: SMS Getway; 3: Table' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'CWX_SMTP_SMS_Settings', @level2type=N'COLUMN',@level2name=N'SMS_SendingTo'
GO

/****** Object:  Table [dbo].[CWX_DeleteTransaction_log]    Script Date: 06/22/2009 17:39:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DeleteTransaction_log]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_DeleteTransaction_log](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[AccountID] [int] NULL,
	[ClientID] [int] NULL CONSTRAINT [DF_CWX_DeleteTransaction_log_ClientID]  DEFAULT ((1)),
	[EmployeeID] [int] NULL CONSTRAINT [DF_CWX_DeleteTransaction_log_EmployeeID]  DEFAULT ((1001)),
	[PaymentTypeID] [int] NULL CONSTRAINT [DF_CWX_DeleteTransaction_log_PaymentTypeID]  DEFAULT ((0)),
	[DateOfTransaction] [smalldatetime] NULL,
	[TransactionType] [int] NULL CONSTRAINT [DF_CWX_DeleteTransaction_log_TransactionType]  DEFAULT ((0)),
	[TransactionAmount] [money] NULL,
	[TransactionComment] [varchar](150) NULL,
	[DateToPost] [smalldatetime] NULL,
	[PaidWhere] [char](30) NULL CONSTRAINT [DF_CWX_DeleteTransaction_log_PaidWhere]  DEFAULT ('B'),
	[ReversedFlag] [bit] NOT NULL,
	[ImportedTransactionID] [varchar](100) NULL,
	[Descriptor] [char](1) NULL,
	[TXN_POSTED] [varchar](1) NULL CONSTRAINT [DF_CWX_DeleteTransaction_log_TXN_POSTED]  DEFAULT ('N'),
	[PART_AMOUNT] [numeric](25, 3) NULL,
	[ParentTransactionID] [int] NULL,
	[PromiseID] [int] NULL,
	[DeletedBy] [int] NULL,
	[DeletedDate] [datetime] NULL,
 CONSTRAINT [PK_CWX_DeleteTransaction_log] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  StoredProcedure [dbo].[CWX_Product_GetAllTabs]    Script Date: 06/05/2009 15:44:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetAllTabs]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 27 Apr 2009
-- Description:	Get all tabs for account information
-- ThanhNguyen: April 28, 2009: Get all tab of @ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Product_GetAllTabs]
	@ClientID int = 0
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @TabID int
	DECLARE curTab CURSOR FOR
		SELECT DISTINCT TabID
		FROM CWX_ClientInformation_Dict
		WHERE ClientID = @ClientID OR ISNULL(ClientID,0) = 0
		ORDER BY TabID

	CREATE TABLE #temp(TabID int, TabDesc nvarchar(30))

	OPEN curTab
	FETCH NEXT FROM curTab INTO @TabID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		INSERT INTO #temp
			SELECT TOP 1 TabID, ISNULL(TabDesc,'''') FROM CWX_ClientInformation_Dict WHERE TabID = @TabID
		FETCH NEXT FROM curTab INTO @TabID
	END

	CLOSE curTab
	DEALLOCATE curTab

	SELECT * FROM #temp
	DROP TABLE #temp
END
' 
END
GO
/****** Object:  Table [dbo].[CWX_ClientPropertiesLog]    Script Date: 06/05/2009 15:46:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientPropertiesLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientPropertiesLog](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [int] NULL,
	[BillingPeriod] [int] NULL,
	[InvoiceType] [int] NULL,
	[BillCommissiontoDebtor] [bit] NULL,
	[AgingType] [int] NULL,
	[ChargeFeeToClient] [bit] NULL,
	[ChargeFeetoDebtor] [bit] NULL,
	[Currency] [int] NULL,
	[StatementCurrency] [int] NULL,
	[ExchangeRate] [decimal](18, 5) NULL,
	[DebtorStatementSortOrder] [bit] NULL,
	[AddCommissionToOwing] [bit] NULL,
	[ReferralRate] [decimal](18, 0) NULL,
	[TaxExempt] [bit] NULL,
	[DiscountID] [int] NULL,
	[Status] [char](1) NULL CONSTRAINT [DF_CWX_ClientPropertiesLog_Status]  DEFAULT ('A'),
	[ClientFixFee] [money] NULL,
	[DebtorFixFee] [money] NULL,
	[UpdateDate] [smalldatetime] NULL CONSTRAINT [DF_CWX_ClientPropertiesLog_UpdateDate]  DEFAULT (getdate()),
	[UpdateBy] [int] NULL,
 CONSTRAINT [PK_CWX_ClientPropertiesLog_1] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountInformation_GetAllTabs]    Script Date: 06/05/2009 15:44:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountInformation_GetAllTabs]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 27 Apr 2009
-- Description:	Get all tabs for account information
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountInformation_GetAllTabs]
	@ClientID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @TabID int
	DECLARE curTab CURSOR FOR
		SELECT DISTINCT TabID
		FROM CWX_AccountInformation_Dict
		WHERE ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID
		ORDER BY TabID

	CREATE TABLE #temp(TabID int, TabDesc nvarchar(30))

	OPEN curTab
	FETCH NEXT FROM curTab INTO @TabID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		INSERT INTO #temp
			SELECT TOP 1 TabID, ISNULL(TabDesc,'''') FROM CWX_AccountInformation_Dict WHERE TabID = @TabID
		FETCH NEXT FROM curTab INTO @TabID
	END

	CLOSE curTab
	DEALLOCATE curTab

	SELECT * FROM #temp
	DROP TABLE #temp
END
' 
END
GO
/****** Object:  Table [dbo].[CWX_ClientCommModelLog]    Script Date: 06/05/2009 15:45:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommModelLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientCommModelLog](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[ID] [int] NULL,
	[ClientID] [int] NOT NULL,
	[Code] [varchar](50) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[SetupTo] [tinyint] NOT NULL,
	[ModelType] [tinyint] NOT NULL,
	[ClientCommRateID] [int] NULL,
	[ClientCommPlanID] [int] NULL,
	[FinancialTypeID] [int] NULL,
	[SystemStatusID] [int] NULL,
	[TransactionTypeID] [int] NULL,
	[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientCommModelLog_Status]  DEFAULT ('A'),
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[UserID] [int] NULL,
	[IsActive] [bit] NOT NULL CONSTRAINT [DF_CWX_ClientCommModelLog_IsActive]  DEFAULT ((1)),
	[UpdateBy] [int] NULL,
 CONSTRAINT [PK_CWX_ClientCommModelLog_1] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommModel_DeleteAll]    Script Date: 06/05/2009 15:44:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommModel_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 26 May 2009
-- Description:	Removes/Marks as deleted all CommissionModels in database.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommModel_DeleteAll]
	-- Add the parameters for the stored procedure here
	@IsSoftDelete bit = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF (@IsSoftDelete = 1)
		UPDATE CWX_ClientCommModel
		SET [Status] = ''R''
		WHERE [Status] <> ''R''		
	ELSE
		DELETE CWX_ClientCommModel
		WHERE [Status] <> ''R''	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlan_DeleteAll]    Script Date: 06/05/2009 15:44:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlan_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 26 May 2009
-- Description:	Removes/Marks as deleted all CommissionPlans in database.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlan_DeleteAll]
	-- Add the parameters for the stored procedure here
	@IsSoftDelete bit = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF (@IsSoftDelete = 1)
		UPDATE CWX_ClientCommPlan
		SET [Status] = ''R''
		WHERE [Status] <> ''R''		
	ELSE
		DELETE CWX_ClientCommPlan
		WHERE [Status] <> ''R''	
END
' 
END
GO
/****** Object:  Table [dbo].[CWX_ClientType]    Script Date: 06/05/2009 15:47:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientType](
	[ClientTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientType_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_CWX_ClientType] PRIMARY KEY CLUSTERED 
(
	[ClientTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_ClientEmployee]    Script Date: 06/05/2009 15:46:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientEmployee]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_ClientEmployee](
	[EmployeeID] [int] NOT NULL,
	[ClientID] [int] NOT NULL,
 CONSTRAINT [PK_CWX_ClientEmployee] PRIMARY KEY CLUSTERED 
(
	[EmployeeID] ASC,
	[ClientID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_SeachPersonInformation]    Script Date: 06/05/2009 15:44:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_SeachPersonInformation]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Morris Mervin Mendoza
-- Create date: 9:50 AM 1/15/2009
-- Description:	
-- History:
--	[12 May 2009]	Minh Dam	Change to dynamic sql
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_SeachPersonInformation]
	-- Add the parameters for the stored procedure here
	@CustomerName varchar(50) = '''',
	@PhoneNumber varchar(50) = '''',
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN

	SET NOCOUNT ON;	
	DECLARE @Sql nvarchar(1000), @NewLine char(2)
	DECLARE @RowCount int
	SET @NewLine = ''
''

	CREATE TABLE #Temp
	(
		RowNumber int,
		PersonID int,
		CustomerName varchar(50),
		RelationshipNumber varchar(50),
		ID varchar(25)
	)
	
	SET @Sql =  
			''INSERT INTO #Temp''
			+ '' SELECT ROW_NUMBER() OVER (ORDER BY a.PersonID) as RowNumber, a.PersonID,''
			+ '' (a.FirstName + '''' ,'''' + a.MiddleName + '''' ,'''' + a.LastName) as CustomerName,''
			+ '' b.GroupName,''
			+ '' a.SocialSecurityNumber''
			+ '' FROM [dbo].[PersonInformation] a''
			+ ''	INNER JOIN [dbo].[DebtorInformation] b on a.PersonID = b.PersonID''
			+ '' WHERE 1=1''
			+ '' @@CustomerNameCondition''
			+ '' @@PhoneNumberCondition''	+ @NewLine
	
	SET @Sql = @Sql + ''SET @RowCount = @@ROWCOUNT'' + @NewLine
					+ ''IF @PageSize <= 0''
					+	''	SELECT * FROM #Temp''
					+ '' ELSE''
					+	''	SELECT * FROM #Temp''
					+		''	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize'' 
					+ @NewLine
	SET @Sql = @Sql + ''DROP TABLE #Temp''


	IF (@CustomerName <> '''')
		SET @Sql = REPLACE(@Sql, ''@@CustomerNameCondition'', ''AND (a.FirstName LIKE (''''%'' + @CustomerName + ''%'''')''
														+ '' OR a.MiddleName LIKE (''''%'' + @CustomerName + ''%'''')'' 
														+ '' OR a.LastName LIKE (''''%'' + @CustomerName + ''%''''))'')
	ELSE
		SET @Sql = REPLACE(@Sql, ''@@CustomerNameCondition'', '''')	

	IF (@PhoneNumber <> '''')
		SET @Sql = REPLACE(@Sql, ''@@PhoneNumberCondition'', ''AND a.PersonID IN (SELECT PersonID FROM PersonPhone WHERE PhoneNumber LIKE (''''%'' + @PhoneNumber + ''%''''))'')
	ELSE
		SET @Sql = REPLACE(@Sql, ''@@PhoneNumberCondition'', '''')
	
	DECLARE @Params nvarchar(100)
	SET @Params = ''@PageSize int, @PageIndex int, @RowCount int OUTPUT''
	EXEC sp_executesql @Sql, @Params, @PageSize, @PageIndex, @RowCount OUTPUT

	RETURN @RowCount
END
' 
END
GO
/****** Object:  Table [dbo].[CWX_FinancialType]    Script Date: 06/05/2009 15:47:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_FinancialType]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_FinancialType](
	[FinancialTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Type] [char](1) NOT NULL CONSTRAINT [DF_CWX_FinancialType_System]  DEFAULT ('S'),
	[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_FinancialType_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_CWX_FinancialType] PRIMARY KEY CLUSTERED 
(
	[FinancialTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CWX_StandardNotes]    Script Date: 06/05/2009 15:47:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_StandardNotes]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_StandardNotes](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](50) NOT NULL,
	[ClientID] [int] DEFAULT ((0)) NULL,
 CONSTRAINT [PK_CWX_StandardNote] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_FillPagingList]    Script Date: 06/05/2009 15:44:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_FillPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		LongNguyen
-- Create date: 2008-12-29
-- Description:	
-- History:
--	[29 Dec 2008]	Long Nguyen		Init version.
--	[23 Mar 2009]	Minh Dam		Add one parameter "ClientID"
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleTable_FillPagingList] 
	-- Add the parameters for the stored procedure here
	@RuleType tinyint,
	@RuleID int = 0,
	@Description varchar(100) = '''',
	@ClientID int = 0,
	@PageSize int,
	@PageIndex int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(ID)
	FROM RuleTable
	WHERE
		RuleType = @RuleType
		AND (@RuleID = 0 OR ID = @RuleID)
		AND Description LIKE (''%'' + @Description + ''%'')
		AND (@ClientID = 0 OR ClientID = @ClientID)	

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER(ORDER BY Description) as RowNumber,
				*
		FROM RuleTable
		WHERE
			RuleType = @RuleType
			AND (@RuleID = 0 OR ID = @RuleID)
			AND Description LIKE (''%'' + @Description + ''%'')
			AND (@ClientID = 0 OR ClientID = @ClientID)
	)

	SELECT 	*
	FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCategory_IsDescriptionExisted]    Script Date: 06/05/2009 15:44:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCategory_IsDescriptionExisted]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thanh Nguyen
-- Create date: May 12 2009
-- Description:	Check if an Descitpion is existed in table CWX_ClientCategory
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCategory_IsDescriptionExisted]
	-- Add the parameters for the stored procedure here
	@ClientCategoryID int,
	@Description varchar(100) = ''''	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS (SELECT 1 FROM CWX_ClientCategory 
				WHERE	@Description <> '''' 
						AND CWX_ClientCategory.Description = @Description 
						AND CWX_ClientCategory.ID <> @ClientCategoryID
						AND CWX_ClientCategory.Status <>''R'')
		RETURN 1
	ELSE 
		RETURN 0
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCategory_SoftDeleteAll]    Script Date: 06/05/2009 15:44:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCategory_SoftDeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thanh Nguyen
-- Create date: May 12, 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCategory_SoftDeleteAll] 	
AS
BEGIN
	UPDATE
		CWX_ClientCategory
	SET
		Status = ''R''	
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]    Script Date: 06/05/2009 15:44:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- ===================================================================================
-- Author:		Tuan Luong
-- Create date: May 15, 2008
-- Description:	Initializes CustomDefinedFields within the given debtorID, accountID.
-- Note: Modified on May 20, 2008 by Tuan Luong to improve performance
-- History:
--	2008/05/15	[Tuan Luong]	Init version.
--	2009/04/07	[Minh Dam]		Add code: "AND (a.Type IN (1,2))"
--								Add parameter "@ClientID" and filter by ClientID
-- ===================================================================================
CREATE PROC [dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]
	@DebtorID INT,
	@AccountID INT,
	@ClientID int = 0
AS
BEGIN
	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	INSERT CWX_CustomDefinedFields (AgencyID, AccountID, DebtorID, Description)
	SELECT AgencyDefID, @AccountID, @DebtorID, LongName
	FROM AgencyDefinedMaster
	WHERE AgencyDefID not in (Select AgencyID From CWX_CustomDefinedFields Where AccountID = @AccountID and DebtorID = @DebtorID)
		AND [Status] <> ''R''
		AND [Type] IN (1,2) -- Type equals Account or Debtor
		AND (@ClientID = 0 OR ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)

	IF( @@ERROR <> 0)
		GOTO Cleanup		


	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_CustomDefinedField_Select]    Script Date: 06/05/2009 15:44:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_CustomDefinedField_Select]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =============================================
-- Author:		Tuan Luong
-- Create date: May 15, 2008
-- Description:	Get custom defined fields.
-- History:
--	2008/05/15	[Tuan Luong]	Init version.
--	2009/04/06	[Minh Dam]		Add code: "AND (a.Type IN (1,2))"
--								Add parameter "@ClientID" and filter by ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TracerInformation_CustomDefinedField_Select]	
	@DebtorID	int,
	@AccountID	int,
	@ClientID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(c.ID)
	FROM CWX_CustomDefinedFields c 
	INNER JOIN AgencyDefinedMaster a ON c.AgencyID = a.AgencyDefID
	WHERE c.AgencyID <> 0 AND c.AccountID = @AccountID AND c.DebtorID = @DebtorID AND a.Status <> ''R''
		AND (a.Type IN (1,2)) -- Type equals Account or Debtor	
		AND (@ClientID = 0 OR ISNULL(a.ClientID, 0) = 0 OR a.ClientID = @ClientID)

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY Description) AS RowNumber, ID, a.LongName as [Description]	, [Value], FormatString		
		FROM CWX_CustomDefinedFields c 
		INNER JOIN AgencyDefinedMaster a ON c.AgencyID = a.AgencyDefID
		WHERE c.AgencyID <> 0 AND c.AccountID = @AccountID AND c.DebtorID = @DebtorID AND a.Status <> ''R''
			AND (a.Type IN (1,2)) -- Type equals Account or Debtor
			AND (@ClientID = 0 OR ISNULL(a.ClientID, 0) = 0 OR a.ClientID = @ClientID)
	)

	SELECT	* FROM	Temp
	WHERE	(@PageSize <= 0) OR (RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize))
	
	RETURN @RowCount

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_GetCollateralCustomFields]    Script Date: 06/05/2009 15:44:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_GetCollateralCustomFields]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 06 Apr 2009
-- Description:	Get custom defined fields and their values belong to a collateral
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TracerInformation_GetCollateralCustomFields]
	@CollateralID int,
	@ClientID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT c.ID, a.AgencyDefID, a.LongName as [Description], c.Value, a.FormatString
	FROM AgencyDefinedMaster a
		LEFT JOIN CWX_CollateralCustomFields c 
		ON a.AgencyDefID = c.AgencyID AND c.CollateralID = @CollateralID
	WHERE a.Type = 3 -- Collateral
		AND a.Status <> ''R''
		AND (@ClientID = 0 OR ISNULL(a.ClientID, 0) = 0 OR a.ClientID = @ClientID)
	ORDER BY a.LongName
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_CollateralCustomFields_DeleteOthers]    Script Date: 06/05/2009 15:44:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CollateralCustomFields_DeleteOthers]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 07 Apr 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CollateralCustomFields_DeleteOthers]
	@CollateralID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DELETE CWX_CollateralCustomFields
	WHERE CollateralID = @CollateralID
		AND AgencyID NOT IN (SELECT AgencyDefID 
							FROM AgencyDefinedMaster 
							WHERE [Type] = 3 -- Collateral 
								AND [Status] <> ''R'')		
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_StandardNote_DeleteAll]    Script Date: 06/05/2009 15:44:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_StandardNote_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- ===================================================================================
-- Author:		Tuan Luong
-- Create date: Jan 28th, 2008
-- Description:	Delete all standard notes (InfoID = 4, InfoType = 6, InfoSubType = 0)
-- Thanh Nguyen: changed on March 26. InfoSubType = 0 no longer exist because InfoSubType is
-- reserved for storing ClientID. When delete all Standard Notes will delete record that
-- Has InfoID = 4 and InfoType = 6
-- ===================================================================================
CREATE PROCEDURE [dbo].[CWX_InformationTable_StandardNote_DeleteAll] 	
	@InfoID int = 4,
	@InfoType int = 6	
AS
BEGIN
	SET NOCOUNT ON;    
	DELETE InformationTable
	WHERE	InfoID = @InfoID
			AND	InfoType = @InfoType			
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientTaxTranType_SaveData]    Script Date: 06/05/2009 15:44:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTaxTranType_SaveData]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 20, 2009
-- Description:	Save ClientTaxTranType
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientTaxTranType_SaveData]
	@ClientID int,
	@FinancialTypeID int,
	@TransactionTypeID int,
	@TaxRate decimal(19,5),
	@CreateDate datetime,
	@UpdateDate datetime,
	@UserID int,
	@ClientNoteDescription nvarchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;		
    -- Insert statements for procedure here
	IF( EXISTS(	SELECT	ID 
				FROM	CWX_ClientTaxTranType 
				WHERE	ClientID = @ClientID AND UserID = @UserID AND 
						FinancialTypeID =@FinancialTypeID AND TransactionTypeID = @TransactionTypeID AND
						[Status] = ''A''
				)
		)
	BEGIN
			UPDATE	CWX_ClientTaxTranType
			SET		TaxRate = @TaxRate, UpdateDate = @UpdateDate
			WHERE	@ClientID = @ClientID AND UserID = @UserID AND
					FinancialTypeID = @FinancialTypeID AND 
					TransactionTypeID = @TransactionTypeID AND
					[Status] = ''A''
			INSERT INTO CWX_ClientNotes VALUES(@UserID,@ClientID,@UpdateDate,@ClientNoteDescription)			
			
	END
	ELSE
	BEGIN
	IF( EXISTS(	SELECT	ID 
				FROM	CWX_ClientTaxTranType 
				WHERE	ClientID = @ClientID AND UserID = @UserID AND 
						FinancialTypeID =@FinancialTypeID AND
						[Status] = ''A''
				) 
		)
	BEGIN
		IF (@TransactionTypeID >=0)
		BEGIN			
			INSERT INTO CWX_ClientTaxTranType VALUES(@ClientID, @FinancialTypeID, @TransactionTypeID, @TaxRate, @CreateDate, @UpdateDate, @UserID, ''A'')
			INSERT INTO CWX_ClientNotes VALUES(@UserID,@ClientID,@UpdateDate,@ClientNoteDescription)			
		END
		ELSE
		BEGIN			
			UPDATE	CWX_ClientTaxTranType
			SET		TaxRate = @TaxRate, UpdateDate = @UpdateDate
			WHERE	@ClientID = @ClientID AND UserID = @UserID AND
					FinancialTypeID = @FinancialTypeID AND 					
					[Status] = ''A'' AND TransactionTypeID <= 0			
			INSERT INTO CWX_ClientNotes VALUES(@UserID,@ClientID,@UpdateDate,@ClientNoteDescription)			
		END
	END
	ELSE		
	BEGIN		
		INSERT INTO CWX_ClientTaxTranType VALUES(@ClientID, @FinancialTypeID, @TransactionTypeID, @TaxRate, @CreateDate, @UpdateDate, @UserID, ''A'')
		INSERT INTO CWX_ClientNotes VALUES(@UserID,@ClientID,@UpdateDate,@ClientNoteDescription)			
	END	
	END		
	RETURN @@ERROR	
	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientStatus_SoftDeleteAll]    Script Date: 06/05/2009 15:44:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientStatus_SoftDeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thanh Nguyen
-- Create date: May 13, 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientStatus_SoftDeleteAll] 	
AS
BEGIN
	UPDATE
		CWX_ClientStatus
	SET
		Status = ''R''
	WHERE Status <> ''R''	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientStatus_IsDescriptionExisted]    Script Date: 06/05/2009 15:44:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientStatus_IsDescriptionExisted]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thanh Nguyen
-- Create date: May 13 2009
-- Description:	Check if an Descitpion is existed in table CWX_ClientStatus
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientStatus_IsDescriptionExisted]
	-- Add the parameters for the stored procedure here
	@ClientStatusID int,
	@Description varchar(100) = ''''	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS (SELECT 1 FROM CWX_ClientStatus as cs 
				WHERE	@Description <> '''' 
						AND cs.Description = @Description 
						AND cs.ID <> @ClientStatusID
						AND cs.Status <>''R'')
		RETURN 1
	ELSE 
		RETURN 0
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanRule_Delete]    Script Date: 06/05/2009 15:44:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanRule_Delete]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 21 May 2009
-- Description:	Delete a Commission Plan Rule and its Criterias
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlanRule_Delete]
	-- Add the parameters for the stored procedure here
	@CommPlanRuleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	BEGIN TRANSACTION

	-- Delete Commission Plan Rule Criterias
	DELETE CWX_ClientCommPlanCriteria
	WHERE ClientCommPlanRuleID = @CommPlanRuleID

	-- Delete Commission Plan Rule
	DELETE CWX_ClientCommPlanRule
	WHERE ID = @CommPlanRuleID
	
	IF @@ERROR = 0
		COMMIT TRANSACTION
	ELSE
		ROLLBACK TRANSACTION
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanRule_DeleteAll]    Script Date: 06/05/2009 15:44:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanRule_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 21 May 2009
-- Description:	Delete all Commission Plan Rules and their Criterias
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlanRule_DeleteAll]
	-- Add the parameters for the stored procedure here
	@CommPlanID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	BEGIN TRANSACTION

	-- Delete Commission Plan Rule Criterias
	DELETE CWX_ClientCommPlanCriteria
	WHERE ClientCommPlanRuleID IN (SELECT ID FROM CWX_ClientCommPlanRule WHERE ClientCommPlanID = @CommPlanID)

	-- Delete Commission Plan Rule
	DELETE CWX_ClientCommPlanRule
	WHERE ClientCommPlanID = @CommPlanID
	
	IF @@ERROR = 0
		COMMIT TRANSACTION
	ELSE
		ROLLBACK TRANSACTION
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommModel_GetPagingList]    Script Date: 06/05/2009 15:44:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommModel_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 25 May 2009
-- Description:	Get list of client commission model with paging
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommModel_GetPagingList]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @RowCount int

	SELECT @RowCount = Count(*)
	FROM CWX_ClientCommModel a
		INNER JOIN ClientInformation b ON a.ClientID = b.ClientID AND b.Status <> ''R''
	WHERE a.Status <> ''R''

    -- Insert statements for procedure here
	WITH temp AS
	(
		SELECT	ROW_NUMBER() OVER (ORDER BY b.ClientName) as RowNumber,
				a.ID,
				b.ClientID, 
				b.ClientName, 
				c.Description as ClientType, 
				a.Code as ModelCode, 
				a.Description as ModelDescription
		FROM CWX_ClientCommModel a
			INNER JOIN ClientInformation b ON a.ClientID = b.ClientID AND b.Status <> ''R''
			LEFT JOIN CWX_ClientType c ON b.ClientTypeID = c.ClientTypeID AND c.Status <> ''R''
		WHERE a.Status <> ''R''
	)

	SELECT ID, ClientID, ClientName, ClientType, ModelCode, ModelDescription
	FROM temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanCriteria_DeleteAllByRuleID]    Script Date: 06/05/2009 15:44:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanCriteria_DeleteAllByRuleID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 20 May 2009
-- Description:	Delete all rule criterias belong to a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlanCriteria_DeleteAllByRuleID]
	@CommPlanRuleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DELETE CWX_ClientCommPlanCriteria
	WHERE ClientCommPlanRuleID = @CommPlanRuleID
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanCriteria_TestRule]    Script Date: 06/05/2009 15:44:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanCriteria_TestRule]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		MInh Dam
-- Create date: 21 May 2009
-- Description:	Retrieve records that match the Commission Plan Rule Criterias of a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlanCriteria_TestRule] 
	-- Add the parameters for the stored procedure here
	@CommPlanRuleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat, Combining
		FROM CWX_ClientCommPlanCriteria
		WHERE ClientCommPlanRuleID = @CommPlanRuleID
		Order By [ID]

	DECLARE @SQLFormat varchar(700)
	DECLARE @Combining varchar(10)
	DECLARE @NeedCombining varchar(10)
	DECLARE @WhereClause varchar(2000)
	DECLARE @IsOpenningBracket bit
	SET @NeedCombining = ''And''
	SET @WhereClause = ''''
	SET @IsOpenningBracket = 0

	OPEN RuleCriteriaCrsr
	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF (LOWER(@Combining) = ''or'')
			IF (@IsOpenningBracket = 0)
			BEGIN
				SET @WhereClause = @WhereClause + '' '' + @NeedCombining + '' ('' + @SQLFormat
				SET @IsOpenningBracket = 1
			END
			ELSE
				SET @WhereClause = @WhereClause + '' '' + @NeedCombining + '' '' + @SQLFormat
		ELSE
		BEGIN
			SET @WhereClause = @WhereClause + '' '' + @NeedCombining + '' '' + @SQLFormat			
			IF (@IsOpenningBracket = 1)
			BEGIN
				SET @WhereClause = @WhereClause + '') ''
				SET @IsOpenningBracket = 0
			END
		END

		SET @NeedCombining = @Combining /* remember previous value */
		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	END

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr

	--This is used for AllocationRule, if RuleType=1, append condition <Account.MAINTAINOFFICER = 0>
	DECLARE @RuleType tinyint	
	SET @WhereClause = '' AND Account.MAINTAINOFFICER = 0'' + @WhereClause

	DECLARE @Sql varchar(8000)
	SET @Sql = '' SELECT''
				+ '' Account.AccountId,Account.DebtorId,PersonInformation.FirstName,PersonInformation.MiddleName,PersonInformation.LastName,Account.BillBalance,Account.BillAmount,Account.InvoiceNumber''
				+ '' FROM Account''
				+ '' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID''
				+ '' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID''
				+ '' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID''
				+ '' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID''
				+ '' WHERE (PersonAddress.MailingAddress = 1)''
				+ '' AND Account.AgencyStatusID <> 2''-- Donot show closed account
				+ @WhereClause

	EXEC (@Sql)

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanCriteria_GetListByRuleID]    Script Date: 06/05/2009 15:44:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanCriteria_GetListByRuleID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 20 May 2009
-- Description:	Gets a list of Commission Plan Rule Criteria by CommissionPlanRuleID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlanCriteria_GetListByRuleID]
	-- Add the parameters for the stored procedure here
	@CommPlanRuleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @Temp table
	(
		COLUMN_NAME varchar(50),
		DESCRIPTION varchar(50),
		DATA_TYPE varchar(25),
		max_length int,
		[precision] int,
		[DATABASE] varchar(50)
	)

	INSERT INTO @Temp
	EXEC CWX_RuleCriteria_GetCriteriaByRuleType 1 -- Account Processing Rule

	SELECT
		c.ID, c.ClientCommPlanRuleID, c.Criteria, c.Operator, c.MatchingCriteria, c.SQLFormat,
		CASE c.ID
			WHEN (SELECT MAX(ID) FROM RuleCriteria WHERE RuleID = c.ClientCommPlanRuleID) THEN ''''
			ELSE c.Combining
		END AS Combining,
		t.DESCRIPTION AS DESCRIPTION,
		t.DATA_TYPE AS DataType
	FROM CWX_ClientCommPlanCriteria c
	LEFT JOIN @Temp t ON t.COLUMN_NAME = c.Criteria
	WHERE c.ClientCommPlanRuleID = @CommPlanRuleID
	ORDER BY c.ID
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientTaxTranType_GetListBaseOnClient]    Script Date: 06/05/2009 15:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTaxTranType_GetListBaseOnClient]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- Author:		ThanhNguyen
-- Create date: May 19, 2009
-- Description:	Get ClientTaxTranType base on ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientTaxTranType_GetListBaseOnClient]
	@ClientID int,
	@User int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @Rowcount int
    -- Insert statements for procedure here
	
	SELECT @Rowcount = count(*)
	FROM	CWX_ClientTaxTranType TaxTranType LEFT JOIN CWX_FinancialType FT ON TaxTranType.FinancialTypeID = FT.FinancialTypeID
				LEFT JOIN TransactionType TT ON TaxTranType.TransactionTypeID = TT.ID

	WHERE	TaxTranType.ClientID = @ClientID AND 
				TaxTranType.UserID = @User AND
				TaxTranType.Status = ''A''	

	SELECT	RowNumber, ID, FinancialType, TransactionType, TaxRate
	FROM 
	(
		SELECT	ROW_NUMBER() OVER (ORDER BY TaxTranType.ID DESC) AS RowNumber,
				TaxTranType.ID as ID , FT.Description as FinancialType, 
				ISNULL(TT.Description,'''') as TransactionType, TaxTranType.TaxRate
		FROM	CWX_ClientTaxTranType TaxTranType LEFT JOIN CWX_FinancialType FT ON TaxTranType.FinancialTypeID = FT.FinancialTypeID
				LEFT JOIN TransactionType TT ON TaxTranType.TransactionTypeID = TT.ID

		WHERE	TaxTranType.ClientID = @ClientID AND 
				TaxTranType.UserID = @User AND
				TaxTranType.Status = ''A''	
	) as a
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
		
	RETURN @Rowcount
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetAllTabs]    Script Date: 06/05/2009 15:44:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetAllTabs]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 27 Apr 2009
-- Description:	Get all tabs for account information
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Collateral_GetAllTabs]
	-- Add the parameters for the stored procedure here
	@CollateralID int,
	@ClientID int = 0,
	@CollateralTypeID int = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @CollateralID > 0 AND @CollateralTypeID IS NULL
		SELECT @CollateralTypeID = CollateralType FROM Collateral WHERE ID = @CollateralID

	DECLARE @TabID int
	DECLARE curTab CURSOR FOR
		SELECT DISTINCT TabID
		FROM CWX_Collateral_Dict
		WHERE (@ClientID = 0 OR ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)
			AND (@CollateralTypeID = 0 OR ISNULL(CollateralTypeID, 0) = 0 OR CollateralTypeID = @CollateralTypeID)
		ORDER BY TabID

	CREATE TABLE #temp(TabID int, TabDesc nvarchar(30))

	OPEN curTab
	FETCH NEXT FROM curTab INTO @TabID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		INSERT INTO #temp
			SELECT TOP 1 TabID, ISNULL(TabDesc,'''') FROM CWX_Collateral_Dict WHERE TabID = @TabID
		FETCH NEXT FROM curTab INTO @TabID
	END

	CLOSE curTab
	DEALLOCATE curTab

	SELECT * FROM #temp
	DROP TABLE #temp
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetDropDownLookupValues]    Script Date: 06/05/2009 15:44:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetDropDownLookupValues]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 24 Apr 2009
-- Description:	Get drop down lookup values
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetDropDownLookupValues]
	-- Add the parameters for the stored procedure here
	@DropDownID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @Sql varchar(max)
	SELECT @Sql = [SQL]
	FROM CWX_DropDownDataDictionary
	WHERE ID = @DropDownID

	EXEC (@Sql)
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonInformation_GetAllTabs]    Script Date: 06/05/2009 15:44:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonInformation_GetAllTabs]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
--	Author:			Minh Dam
--	Create date:	27 Apr 2009
--	Description:	Get all tabs for account information
--	[03-06-2009]	ThanhNguyen		Delete ClientID from Parameter base on issues 68
-- =============================================
CREATE PROCEDURE [dbo].[CWX_PersonInformation_GetAllTabs]
	-- Add the parameters for the stored procedure here	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @TabID int
	DECLARE curTab CURSOR FOR
		SELECT DISTINCT TabID
		FROM CWX_PersonInformation_Dict		
		ORDER BY TabID

	CREATE TABLE #temp(TabID int, TabDesc nvarchar(30))

	OPEN curTab
	FETCH NEXT FROM curTab INTO @TabID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		INSERT INTO #temp
			SELECT TOP 1 TabID, ISNULL(TabDesc,'''') FROM CWX_PersonInformation_Dict WHERE TabID = @TabID
		FETCH NEXT FROM curTab INTO @TabID
	END

	CLOSE curTab
	DEALLOCATE curTab

	SELECT * FROM #temp
	DROP TABLE #temp
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Currency_GetCurrencyList]    Script Date: 06/05/2009 15:44:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Currency_GetCurrencyList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_Currency_GetCurrencyList]	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT CurrencyID,  (CurrencyName + '' ('' + Symbol + '')'') as CurrencyNameAndSymbol
	FROM CWX_Currency
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AgencyDefinedMaster_IsEditable]    Script Date: 06/05/2009 15:44:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AgencyDefinedMaster_IsEditable]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 07 Apr 2009	
-- Description:	Check whether a custom defined field is editable or not
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AgencyDefinedMaster_IsEditable]
	@AgencyID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF NOT EXISTS (SELECT 1 FROM CWX_CustomDefinedFields WHERE AgencyID = @AgencyID)
		AND NOT EXISTS (SELECT 1 FROM CWX_CollateralCustomFields WHERE AgencyID = @AgencyID)
		RETURN 1
	ELSE
		RETURN 0
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientInformation_GetNoCommissionModelClients]    Script Date: 06/05/2009 15:44:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_GetNoCommissionModelClients]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 25 May 2009
-- Description:	Get a list of clients that haven''t had Commission Model yet.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientInformation_GetNoCommissionModelClients]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT ClientID, ClientName, cast(ClientID as varchar) + '' - '' + ClientName as ClientIDAndName
	FROM ClientInformation
	WHERE ClientID NOT IN (SELECT ClientID FROM CWX_ClientCommModel WHERE [Status] <> ''R'')
	AND [Status] <> ''R''
	ORDER BY ClientName
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientTranTypeProperties_GetTransactionTypes]    Script Date: 06/05/2009 15:44:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTranTypeProperties_GetTransactionTypes]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_ClientTranTypeProperties_GetTransactionTypes]
	@ClientID int,
	@FinancialTypeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	TT.ID, TT.Description 
	FROM	CWX_ClientTranTypeProperties TTP INNER JOIN TransactionType TT
			ON TTP.TransactionTypeID = TT.ID
	WHERE	(TTP.ClientID = @ClientID OR @ClientID = 0)AND TTP.[Status] = ''A''
			AND (TT.FinancialTypeID = @FinancialTypeID OR @FinancialTypeID = 0)
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientTranTypeProperties_GetList]    Script Date: 06/05/2009 15:44:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTranTypeProperties_GetList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ThanhNguyen	
-- Create date: May 21, 2009
-- Description:	Get list of client tran type properties
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientTranTypeProperties_GetList]
	@ClientID int,
	@PageSize  int = 10,
	@PageIndex int = 0	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @RowCount int   
	
	SELECT	b.ID, b.ClientID, b.CalculateComm, b.CalculateTax, b.ChargeInterest, 
			b.OmitClientStatement, b.OmitClientDailyReport, b.TransactionType
	FROM
	(	
		SELECT  ROW_NUMBER() OVER (ORDER BY TTP.ID DESC) AS RowNumber,
				TTP.ID, TTP.ClientID, TTP.CalculateComm, TTP.CalculateTax,TTP.ChargeInterest,
				TTP.OmitClientStatement, TTP.OmitClientDailyReport, TT.	Description as TransactionType
		FROM	CWX_ClientTranTypeProperties TTP INNER JOIN TransactionType TT
				ON TTP.TransactionTypeID = TT.ID
		WHERE	TTP.ClientID = @ClientID AND TTP.[Status] = ''A''
	)b
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	SELECT @RowCount = count(TTP.ID)
	FROM	CWX_ClientTranTypeProperties TTP INNER JOIN TransactionType TT
			ON TTP.TransactionTypeID = TT.ID
	WHERE	TTP.ClientID = @ClientID AND TTP.[Status] = ''A''
	
	RETURN @RowCount
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_TransactionType_GetFinancialTypeByTransactionType]    Script Date: 06/05/2009 15:44:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionType_GetFinancialTypeByTransactionType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_TransactionType_GetFinancialTypeByTransactionType]
	@ClientID int,
	@TransactionType int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @FinancialTypeID int
	SELECT @FinancialTypeID = FinancialTypeID
	FROM TransactionType
	WHERE ClientID = @ClientID AND ID = @TransactionType AND [Status] = ''A''
	RETURN @FinancialTypeID
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]    Script Date: 06/05/2009 15:44:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- History:
--	[26 Mar 2009]	Minh Dam		Add one parameter "ClientID"
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]
	@InterfaceDBName varchar(125),
	@TableName varchar(125),
	@ColumnName varchar(125),
	@ClientID int = 0
AS
BEGIN
	DECLARE @Sql varchar(2000)
	
	select @Sql = [SQL] from CWX_DataDictionary where ColumnName = @TableName + ''.'' + @ColumnName
	if (@Sql is null)
	begin
		SET @Sql = ''SELECT DISTINCT '' + @ColumnName + '' FROM '' + @InterfaceDBName + ''..'' + @TableName
		SET @Sql = @Sql + '' WHERE '' + @ColumnName + '' is not NULL''
		SET @Sql = @Sql + '' AND Len('' + @ColumnName + '') > 0''
		IF EXISTS (SELECT 1 FROM sys.columns WHERE [name] = ''ClientID'' AND [object_id] = (SELECT [object_id] FROM sys.objects WHERE [object_id] = OBJECT_ID(@TableName) AND [type] IN (N''U'')))
		   AND @ClientID > 0
			SET @Sql = @Sql + '' AND ClientID = '' + Cast(@ClientID as varchar)

		SET @Sql = @Sql + '' ORDER BY '' + @ColumnName	
	end
	
	EXEC(@Sql)
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientType_IsDescriptionExisted]    Script Date: 06/05/2009 15:44:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientType_IsDescriptionExisted]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 18 Mar 2009
-- Description:	Check if an Descitpion is existed in table CWX_CLIENTYPE
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientType_IsDescriptionExisted]
	-- Add the parameters for the stored procedure here
	@ClientTypeID int,
	@Description varchar(100) = ''''	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS (SELECT 1 FROM CWX_CLIENTTYPE 
				WHERE	@Description <> '''' 
						AND CWX_CLIENTTYPE.Description = @Description 
						AND CWX_CLIENTTYPE.ClientTypeID <> @ClientTypeID
						AND CWX_CLIENTTYPE.Status <>''R'')
		RETURN 1
	ELSE 
		RETURN 0
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientType_SoftDeleteAll]    Script Date: 06/05/2009 15:44:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientType_SoftDeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thanh Nguyen
-- Create date: March 18, 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientType_SoftDeleteAll] 	
AS
BEGIN
	UPDATE
		CWX_CLIENTTYPE
	SET
		Status = ''R''	
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Product_GetByEmployee]    Script Date: 06/05/2009 15:44:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetByEmployee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 15 Apr 2009
-- Description:	Get clients of an employee 
--				if @EmployeeID = 0 or this employee hasn''t assigned any clients then load all clients,
--				otherwise get clients of that employee						
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Product_GetByEmployee]
	-- Add the parameters for the stored procedure here
	@EmployeeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @sql nvarchar(1000)
	DECLARE @param nvarchar(100)
	SET @param = ''@EmployeeID int''

	SET @sql = 	''SELECT * FROM ClientInformation WHERE [Status] <> ''''R''''''
	IF (@EmployeeID > 0 AND EXISTS (SELECT 1 FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID))
		SET @sql = @sql + '' AND ClientID IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID)''

	SET @sql = @sql + '' ORDER BY ClientName''
	Exec sp_executesql @sql, @param, @EmployeeID
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientInformation_GetAssignedClients]    Script Date: 06/05/2009 15:44:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_GetAssignedClients]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 10 Apr 2009
-- Description:	Get assigned clients of an employee
-- History:
--	[2009/04/10]	Thanh Nguyen	Init version.
--	[2009/04/16]	Minh Dam		Add parameter "@ReportTo"
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientInformation_GetAssignedClients]
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@ReportTo int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	WITH ReportToClientList AS
	(
		SELECT * FROM dbo.CWX_AssignedClientIDTable(@ReportTo)
	)
	
	SELECT ClientID, ClientName
	FROM ClientInformation
	WHERE [Status] <> ''R''		
		AND ClientID IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID)
		AND ClientID IN (SELECT ClientID FROM ReportToClientList)
	ORDER BY ClientName
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientInformation_GetAvailableClients]    Script Date: 06/05/2009 15:44:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_GetAvailableClients]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 10 Apr 2009
-- Description:	Get assigned clients of an employee
-- History:
--	[2009/04/10]	Thanh Nguyen	Init version.
--	[2009/04/16]	Minh Dam		Add parameter "@ReportTo"
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientInformation_GetAvailableClients]
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@ReportTo int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	WITH ReportToClientList AS
	(
		SELECT * FROM dbo.CWX_AssignedClientIDTable(@ReportTo)
	)

	SELECT ClientID, ClientName
	FROM ClientInformation
	WHERE [Status] <> ''R''
		AND ClientID NOT IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID)
		AND ClientID IN (SELECT ClientID FROM ReportToClientList)
	ORDER BY ClientName
END

' 
END
GO
/****** Object:  UserDefinedFunction [dbo].[CWX_AssignedClientIDTable]    Script Date: 06/05/2009 15:47:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AssignedClientIDTable]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <10 April 2009>
-- Description:	<>
-- =============================================
CREATE FUNCTION [dbo].[CWX_AssignedClientIDTable]
(	
	@employeeID int
)
RETURNS @retTable TABLE (ClientID int)
AS
BEGIN

	IF (@EmployeeID > 0 AND EXISTS (SELECT 1 FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID))
	BEGIN
		INSERT INTO @retTable(ClientID)	
			SELECT	ClientID 
			FROM	ClientInformation 
			WHERE	[Status] <> ''R''
				AND (ClientID IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID))
	END
	ELSE
	BEGIN
		INSERT INTO @retTable(ClientID)	
			SELECT	ClientID 
			FROM	ClientInformation 
			WHERE	[Status] <> ''R''
	END
	
	INSERT INTO @retTable(ClientID) VALUES(0)
	
	RETURN

--	SELECT ClientID 
--	FROM ClientInformation 
--	WHERE ClientID IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @employeeID)
--		AND [Status] <> ''R''
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientEmployee_Delete]    Script Date: 06/05/2009 15:44:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientEmployee_Delete]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 20 Mar 2009
-- Description:	Delete all clients that are assigned to this @EmployeeID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientEmployee_Delete]
	-- Add the parameters for the stored procedure here
	@EmployeeID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DELETE CWX_ClientEmployee
	WHERE EmployeeID = @EmployeeID
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_StandardNotes_DeleteAll]    Script Date: 06/05/2009 15:44:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_StandardNotes_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_StandardNotes_DeleteAll]	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	DELETE FROM CWX_StandardNotes
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 06/05/2009 15:44:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXML]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Description:	Load all accounts with debtorID
-- History:
--	2008/04/03	[Tai Ly]		Init version.
--	2008/06/01	[Long Nguyen]	Add and remove some fields.
--	2008/06/27	[Binh Truong]	Remove BatchNumber field.	
--	2008/08/25	[Long Nguyen]	Remove @AdditionalTag
--	2008/09/04	[Thuy Nguyen]	Remove CoSigner table reference
--	2009/03/19	[Thuy Nguyen]	Remove ClientInformation.ContactName
--  2009/04/10	[Minh Dam]		Add parameter "@EmployeeID" that is the id of current login user 
--									and filter Account by ClientID belong to this user.
--	2009/05/25	[Minh Dam]		Only filter Account by ClientID when application by client
--	2009/06/04	[Hung nguyen]	Only filter Account by ClientID when Consolidation is account or ( Consolidation is not account and Load all Client Accounts  is checked)
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int,
	@EmployeeID int
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/
	/*	
	DECLARE @ApplicationBy int
	SELECT @ApplicationBy = FieldValue FROM IdentityFields WHERE TableName = ''ApplicationBy''

	IF (@ApplicationBy <> 1) -- Only filter Account by ClientID when ApplicationBy = 1 (by Client)
		SET @EmployeeID = 0
	*/

-- Relationship Collection - Consolidation    
   DECLARE @RelationshipCollection int;
   SELECT @RelationshipCollection=ValueFormat 
   FROM dbo.InformationTable
   WHERE infoid=1 and InfoType=1 and InfoSubType=0;

-- Load all Client Accounts  
   DECLARE @LoadAllClientAccounts bit;
   SELECT @LoadAllClientAccounts=ValueFormat 
   FROM dbo.InformationTable
   WHERE infoid=1 and InfoType=18 and InfoSubType=0;

-- Only filter Account by ClientID when ApplicationBy = 1 (by Client)
   IF((@RelationshipCollection<>0)AND (@LoadAllClientAccounts=0))
   BEGIN
	 SET @EmployeeID = 0 --no filter by client id
   END	
	
	--ThanhNguyen: temporary remove filterby client because encouter error
	SET @EmployeeID = 0;
	---end of ThanhNguyen
	
	WITH ClientListTable AS
	(		
		SELECT * FROM dbo.CWX_AssignedClientIDTable(@EmployeeID)
	)

	SELECT
			a.AccountID,
			ISNULL(l.LetterDesc, '''') AS SENTBY, ISNULL(al.LetterStatus, '''') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			p.AmountPromised AS FirstAmountPromised, p.PromiseFrequency AS FirstPromiseFrequency, p.Term AS FirstPromiseTerm, p.DatePromised, '''' AS PROMISE,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL,
			lastpromise.LASTPROMISEDATE, lastpromise.LASTPROMISEAMOUNT, lastpromise.LASTPROMISESTATUS, lastpromise.LASTPROMISESTATUSDESC,
			(CASE ISNULL(lg.GroupedAccountID, 0) WHEN 0 THEN 0 ELSE 1 END) AS IsGroupedAccount
	INTO	#AccountTemp
	FROM	Account	 a
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN ''d'' THEN ''day(s)''
						WHEN ''w'' THEN ''week(s)''
						WHEN ''m'' THEN ''month(s)''
						WHEN ''y'' THEN ''year(s)''
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get last promise
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised AS LASTPROMISEAMOUNT,
					p2.DatePromised AS LASTPROMISEDATE,
					p2.Status AS LASTPROMISESTATUS,
					CASE p2.Status
						WHEN 0 THEN ''Not Due''
						WHEN 1 THEN ''Paid On Time''
						WHEN 2 THEN ''Paid Late''
						WHEN 3 THEN ''Broken Promise''
						WHEN 4 THEN ''Canceled''
						ELSE ''''
					END AS LASTPROMISESTATUSDESC
				FROM AccountPromise p2 
				WHERE p2.PromiseID IN 
						(	SELECT TOP 1 PromiseID
							FROM (	SELECT PromiseID, DatePromised
									FROM AccountPromise 
									WHERE AccountID = p2.AccountID -- 69
							) as temp
							ORDER BY DatePromised DESC
						)) lastpromise ON lastpromise.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	--Check if account is GroupAccount
	LEFT JOIN Legal_Groups lg ON lg.GroupedAccountID = a.AccountID
	WHERE DebtorID = @DebtorID
		AND (NOT EXISTS(SELECT 1 FROM ClientListTable) OR a.ClientID IN (SELECT ClientID FROM ClientListTable))

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, nextAction.CodeDesc AS CurrentNextActionDesc, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, --ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised, #AccountTemp.FirstAmountPromised, #AccountTemp.FirstPromiseFrequency, #AccountTemp.FirstPromiseTerm
			, #AccountTemp.LASTPROMISEDATE, #AccountTemp.LASTPROMISEAMOUNT, #AccountTemp.LASTPROMISESTATUS, #AccountTemp.LASTPROMISESTATUSDESC
			, #AccountTemp.LASTCONTACTDATE, #AccountTemp.LASTCONTACTBY, #AccountTemp.PROMISETOPAY, #AccountTemp.PROMISEKEPT, #AccountTemp.PROMISEBROKEN, #AccountTemp.OUTGOINGCALL, #AccountTemp.NOACTIVITYDAYS
			, ISNULL(Account.IsPending, 0) AS IsPending
			, #AccountTemp.IsGroupedAccount
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID
			LEFT OUTER JOIN AccountCodeMaster nextAction on Account.CurrentNextAction = nextAction.CodeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]    Script Date: 06/05/2009 15:44:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetTotalQueueStatsByEmployee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- =============================================
-- Author:		<Long Nguyen>
-- Create date: <Jul 11, 2008>
-- Description:	<Get Queue Statistic by Collector for the datagrid>
-- History:
--	2008/07/11	[Long Nguyen]	Init version.
--	2009/03/30	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int,
	@ClientID int = 0
AS
BEGIN

	DECLARE @AccountCount int
	DECLARE @Touched int
	DECLARE @Actioned int
	DECLARE @Worked int
	DECLARE @Contacted int
	DECLARE @Promised int
	DECLARE @AccountBalance money

	IF (@ReportTime = 0)
		BEGIN

			SELECT
				@AccountCount = ISNULL(COUNT(DISTINCT AccountID),0),
				@AccountBalance = ISNULL(SUM(BillBalance),0)
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
								AND CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
								AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
								AND SystemStatusID in (1,5))
				AND (@ClientID = 0 OR ClientID = @ClientID)

			SELECT
				@Touched = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions 
			WHERE CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ResponsibleParty = @EmployeeID
				AND AccountID not in 
					(SELECT DISTINCT AccountID FROM AccountActions where ActionId <> 8
					AND CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
					AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
					AND ResponsibleParty = @EmployeeID)
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Actioned = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions
			WHERE CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ActionID <> 8
				AND ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Worked = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
				LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ac.ActionID <> 8
				AND av.ConsiderWorked = 1
				AND ac.ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Contacted = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 2
				AND ac.ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Promised = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
				LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 1
				AND ac.ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@AccountCount AS AccountCount,
				@Touched AS Touched,
				@Actioned AS Actioned,
				@Worked AS Worked,
				@Contacted AS Contacted,
				@Promised AS Promised,
				@AccountBalance AS AccountBalance
		END
	ELSE
		BEGIN
			SELECT
				@AccountCount = ISNULL(COUNT(DISTINCT AccountID),0),
				@AccountBalance = ISNULL(SUM(BillBalance),0)
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
									  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID in (1,5)
				AND (@ClientID = 0 OR ClientID = @ClientID)

			SELECT
				@Touched = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ResponsibleParty = @EmployeeID
				AND AccountID not in 
					(SELECT DISTINCT AccountID FROM AccountActions where ActionId <> 8
					AND CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
					AND ResponsibleParty = @EmployeeID)
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Actioned = ISNULL(COUNT(DISTINCT AccountID),0)
			from AccountActions
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ActionID <> 8
				AND ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Worked = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ac.ActionID <> 8
				AND av.ConsiderWorked = 1
				AND ac.ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Contacted = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 2
				AND ac.ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Promised = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 1
				AND ac.ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@AccountCount AS AccountCount,
				@Touched AS Touched,
				@Actioned AS Actioned,
				@Worked AS Worked,
				@Contacted AS Contacted,
				@Promised AS Promised,
				@AccountBalance AS AccountBalance
		END
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 06/05/2009 15:44:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetQueueStatsByEmployee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <17 June 2008>
-- Description:	<Get Queue Statistic by Collector for chart>
-- History:
--	2008/07/11	[Thuy Nguyen]	Init version.
--	2009/03/30	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int,
	@ClientID int = 0
AS
BEGIN

	DECLARE @BeforeDays INT
	DECLARE @AfterDays INT

	IF (@ReportTime = 0)
		BEGIN
			SELECT
				CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) as QueueDate,
				ISNULL(COUNT(DISTINCT AccountID),0) AS AccountCount,
				ISNULL(SUM(BillBalance),0) AS AccountBalance
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
									  AND CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
									  AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121))
				AND SystemStatusID in (1,5)
				AND (@ClientID = 0 OR ClientID = @ClientID)
			GROUP BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
			ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))
		END
	ELSE
		BEGIN
			SELECT
				CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) as QueueDate,
				ISNULL(COUNT(DISTINCT AccountID),0) AS AccountCount,
				ISNULL(SUM(BillBalance),0) AS AccountBalance
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
									  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID in (1,5)
				AND (@ClientID = 0 OR ClientID = @ClientID)
			GROUP BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
			ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))
		END
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetRuleAccountsDetail]    Script Date: 06/05/2009 15:44:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetRuleAccountsDetail]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Long Nguyen
-- Create date: 2008-11-21
-- Description:	
--		2008/11/21	[Long Nguyen]	Init version.
--		2009/03/30	[Minh Dam]		Add parameter "@ClientiD" and fileter by ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetRuleAccountsDetail]
	-- Add the parameters for the stored procedure here
	@EmployeeID int = 0,
	@StartDate smalldatetime = NULL,
	@EndDate smalldatetime = NULL,
	@ClientID int = 0,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int

    SELECT
		@RowCount = COUNT(RowNumber)
	FROM
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.AllocRuleID) AS RowNumber,
			a.AllocRuleID AS RuleID,
			r.Description AS RuleDescription,
			a.EmployeeID,
			e.UserID,
			ISNULL(COUNT(AccountID),0) AS TotalAccounts,
			ISNULL(SUM(BillBalance),0) AS TotalValue
		FROM Account a, Employee e, RuleTable r
		WHERE
			((@StartDate IS NULL) OR CONVERT(VARCHAR(10),a.LastAllocationDate,121) >= CONVERT(VARCHAR(10),@StartDate,121))
			AND ((@EndDate IS NULL) OR CONVERT(VARCHAR(10),a.LastAllocationDate,121) <= CONVERT(VARCHAR(10),@EndDate,121))
			AND a.EmployeeID = e.EmployeeID 
			AND a.AllocRuleID = r.[ID] 
			AND (@EmployeeID=0 OR a.EmployeeID = @EmployeeID)
			AND (@ClientID = 0 OR (a.ClientID = @ClientID AND r.ClientID = @ClientID))
		GROUP BY a.AllocRuleID, a.EmployeeID, e.UserID, r.Description
	) a

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.AllocRuleID) AS RowNumber,
			a.AllocRuleID AS RuleID,
			r.Description AS RuleDescription,
			a.EmployeeID,
			e.UserID,
			ISNULL(COUNT(AccountID),0) AS TotalAccounts,
			ISNULL(SUM(BillBalance),0) AS TotalValue
		FROM Account a, Employee e, RuleTable r 
		WHERE
			((@StartDate IS NULL) OR CONVERT(VARCHAR(10),a.LastAllocationDate,121) >= CONVERT(VARCHAR(10),@StartDate,121))
			AND ((@EndDate IS NULL) OR CONVERT(VARCHAR(10),a.LastAllocationDate,121) <= CONVERT(VARCHAR(10),@EndDate,121))
			AND a.EmployeeID = e.EmployeeID 
			AND a.AllocRuleID = r.[ID] 
			AND (@EmployeeID=0 OR a.EmployeeID = @EmployeeID)
			AND (@ClientID = 0 OR (a.ClientID = @ClientID AND r.ClientID = @ClientID))
		GROUP BY a.AllocRuleID, a.EmployeeID, e.UserID, r.Description
	)

	SELECT * FROM Temp
	WHERE ((@PageSize<=0) OR (RowNumber BETWEEN (@PageSize*@PageIndex+1) AND (@PageSize*(@PageIndex+1))))

	RETURN @RowCount
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 06/05/2009 15:44:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int,
	@ClientID int =0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
	BEGIN
		DECLARE @PersonID int
		SELECT @PersonID=d.PersonID
		FROM DebtorInformation d
		LEFT JOIN CosigneeInformation c ON c.PersonID = d.PersonID
		WHERE d.DebtorID=@debtorID-- AND c.Relationship_Type IS NULL

		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate]
				, CASE a.PersonID WHEN @PersonID THEN ''Debtor'' ELSE r.Description END AS [RelationshipType]
				, a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[DefendantNum], a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				LEFT JOIN PersonInformation p ON a.PersonID = p.PersonID
				LEFT JOIN Account b ON a.AccountID = b.AccountID
				LEFT JOIN CosigneeInformation g ON g.PersonID = a.PersonID AND g.Bill = b.AccountID
				LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE a.GroupID = @groupID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2 AND 
				CASE WHEN @ClientID > 0 THEN b.ClientID ELSE 0 END = @ClientID AND
				CASE WHEN ISNULL(r.RelationshipTypeID, 0) = 0 THEN 1 ELSE r.IncludeInGroup END <> 0
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	END
	ELSE
	BEGIN
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,''Debtor'' AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum], isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
				LEFT JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
				--LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID AND 
			CASE WHEN @ClientID > 0 THEN b.ClientID ELSE 0 END = @ClientID AND
			b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate], r.Description AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
			LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID) AND 
			CASE WHEN @ClientID > 0 THEN b.ClientID ELSE 0 END = @ClientID AND
			b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2 AND r.IncludeInGroup <> 0
		
		ORDER BY Seq, b.AccountID, FullName
	END
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_GetLockedDebtorList]    Script Date: 06/05/2009 15:44:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInformation_GetLockedDebtorList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE PROCEDURE [dbo].[CWX_DebtorInformation_GetLockedDebtorList]	
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(DebtorID)
	FROM DebtorInformation
	WHERE LockedByID is not null and LockedDate is not NULL

    -- Insert statements for procedure here
	SELECT	d.DebtorID, 
			p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName as [Name],
			e.EmployeeName as LockedBy,
			d.LockedDate			
	FROM DebtorInformation	d
		INNER JOIN PersonInformation p ON d.PersonID = p.PersonID
		INNER JOIN EMPLOYEE e ON e.EmployeeID = d.LockedByID
	WHERE d.LockedByID is not NULL and d.LockedDate is not NULL
	ORDER BY [Name] DESC
	
	return @RowCount
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetEmployeeIDBySupervisor]    Script Date: 06/05/2009 15:44:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetEmployeeIDBySupervisor]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <6-September-2008>
-- History:
--		2008/09/06	[Thuy Nguyen]	Init version.
--		2009/03/30	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_GetEmployeeIDBySupervisor]
	@SupervisorID int = 0,
	@ClientID int = 0
AS
BEGIN
	SELECT EmployeeID 
	FROM Employee 
	WHERE SupervisorID = @SupervisorID
		AND (@ClientID = 0 OR EmployeeID IN (SELECT EmployeeID FROM CWX_ClientEmployee WHERE ClientID = @ClientID))
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_SearchActiveEmployee]    Script Date: 06/05/2009 15:44:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_SearchActiveEmployee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Search employee with active status only.
-- History:
--	2008/08/15	[Binh Truong]	Init version.
--  2009/03/19  [Thanh Nguyen] Search Employees that are assinged to specific client. 
--              Results employees must be in table CWX_ClientEmployee  
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_SearchActiveEmployee]
	@EmployeeID int = 0,
	@EmployeeName varchar(50) = '''',
	@Department int = 0,
	@IsEmployeePool bit,
	@RoleID int = 0,
	@ClientID int = 0,	
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	--This only used in MainPage (Refer to), if employee is supervisor -> only select supervisor
	DECLARE @Supervisor bit
	IF @EmployeeID > 0
		SELECT	@Supervisor = Supervisor	
		FROM	Employee
		WHERE	EmployeeID = @EmployeeID AND EmployeeStatus = ''A''

	--Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = ''WHERE RowNumber BETWEEN '' + CAST(@BeginIndex as varchar(10)) + '' AND '' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = '' ''

	--Step 3: Populate the main SELECT command.
	DECLARE @cStmt varchar(4000)
	SET @cStmt = ''SELECT e.EmployeeID, e.UserID, e.EmployeeName, ISNULL(d.DeptDesc, '''''''') AS Department, e.RoleID, e.Description, ''
			 + '' CASE e.Supervisor WHEN 1 THEN ''''Y'''' ELSE '''''''' END AS Supervisor ''
			 + '' FROM Employee e LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID AND (d.Status <> ''''R'''') ''
			 + '' WHERE (e.EmployeeName LIKE (''''%'' + @EmployeeName + ''%'''')) ''
			 + '' AND ('' + STR(@Department) + ''= 0 OR e.Department = '' + STR(@Department) + '') ''
			 + '' AND ('' + STR(@RoleID) + ''= 0 OR e.RoleID = '' + STR(@RoleID) + '') AND (ISNULL(EmployeeStatus, '''''''') = ''''A'''') ''
			 + '' AND ('' + ISNULL(STR(@Supervisor), ''1'') + ''= 1 OR e.Supervisor = 1) ''
	
	IF (@IsEmployeePool = 1)
		SET @cStmt = @cStmt + '' AND EmployeeType=''''P'''' ''

	---Step 3_1: EmployeeIds must be belong to @ClientID of table CWX_ClientEmployee
	--@ClientID = 0 : means select all employees of all clients
	if(@ClientID > 0)
		SET @cStmt = @cStmt + '' AND e.EmployeeID IN ( SELECT EmployeeID FROM CWX_ClientEmployee WHERE ClientID = '' + STR(@ClientID) +  '' OR  0 = '' + STR(@ClientID)+ '')''
	
	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
	DECLARE @finalStmt varchar(8000)
	SET @finalStmt = ''WITH EmployeeList AS ''
				   + ''( ''
				   + ''  SELECT *, ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber ''
				   + ''  FROM ( ''	
				   + ''          {0}''
				   + ''    ) A ''
				   + '') ''
				   + ''SELECT * FROM EmployeeList '' + @pagingWhereClause
	SET @finalStmt = REPLACE(@finalStmt, ''{0}'', @cStmt)

	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)

	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = ''SELECT @RowCountOut=count(*) FROM ( {0} ) A''
    SET @rowCountStmt = REPLACE(@rowCountStmt, ''{0}'', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = ''@RowCountOut int OUTPUT''

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT
	
	RETURN @RowCount
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetAccountListForClientDebtorsView]    Script Date: 06/05/2009 15:44:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetAccountListForClientDebtorsView]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 27, 2009
-- Description:	Get account list base on ClientID, AccountStatus, EmployeeID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetAccountListForClientDebtorsView]
	@ClientID int, 
	@AccountStatus int, 
	@EmployeeID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT b.DebtorName, b.AccountNumber, b.BillBalance, b.SubmissionDate,AccountStatus, b.UserName
	FROM (
		SELECT	ROW_NUMBER() OVER (ORDER BY (ISNULL(p.firstName, '''') + '' '' + ISNULL(p.lastName,'''')) DESC) AS RowNumber,
				(ISNULL(p.firstName, '''') + '' '' + ISNULL(p.lastName,'''')) as DebtorName,
				a.InvoiceNumber as AccountNumber, a.SubmissionDate, a.BillBalance, ast.ShortDesc as AccountStatus,
				e.EmployeeName as UserName
		FROM	Account a INNER JOIN AccountStatus ast ON a.AgencyStatusID = ast.AgencyStatus
				INNER JOIN Employee e ON a.EmployeeID = e.EmployeeID
				INNER JOIN DebtorInformation d ON a.DebtorID = d.DebtorID
				INNER JOIN PersonInformation p ON d.PersonID = p.PersonID

		WHERE	(a.ClientID = @ClientID OR @ClientID = 0) AND 
				(a.AgencyStatusID = @AccountStatus OR @AccountStatus = 0)AND
				(a.EmployeeID = @EmployeeID	OR @EmployeeID = 0)
	) b
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DECLARE @rowCount int
	SELECT @rowCount = count(*)
	FROM	Account a INNER JOIN AccountStatus ast ON a.AgencyStatusID = ast.AgencyStatus
			INNER JOIN Employee e ON a.EmployeeID = e.EmployeeID
			INNER JOIN DebtorInformation d ON a.DebtorID = d.DebtorID
			INNER JOIN PersonInformation p ON d.PersonID = p.PersonID

	WHERE	(a.ClientID = @ClientID OR @ClientID = 0) AND 
			(a.AgencyStatusID = @AccountStatus OR @AccountStatus = 0)AND
			(a.EmployeeID = @EmployeeID	OR @EmployeeID = 0)

	RETURN @rowCount
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientNotes_GetPagingListByClientID]    Script Date: 06/05/2009 15:44:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientNotes_GetPagingListByClientID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 13 May 2009
-- Description:	Get notes by client with paging.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientNotes_GetPagingListByClientID]
	@ClientID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @RowCount int

	SELECT @RowCount = COUNT(*)
	FROM CWX_ClientNotes
	WHERE ClientID = @ClientID	

	WITH temp AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY NoteDateTime DESC) AS RowNumber,
				NoteID, a.EmployeeID, ISNULL(b.EmployeeName, '''') AS EmployeeName,
				ClientID, NoteDateTime, NoteText
		FROM CWX_ClientNotes a
			LEFT JOIN Employee b ON a.EmployeeID = b.EmployeeID
		WHERE ClientID = @ClientID
	)

	SELECT NoteID, EmployeeID, EmployeeName, ClientID, NoteDateTime, NoteText
	FROM temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByEmployeeName]    Script Date: 06/05/2009 15:45:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByEmployeeName]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE PROCEDURE [dbo].[CWX_Account_SearchByEmployeeName] 
	@EmployeeName varchar(100),
	@EmpList varchar(3000),
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

IF LEN(ISNULL(@EmpList,'''')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
	WHERE
		a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND UPPER(g.EmployeeName) LIKE (''%'' + UPPER(@EmployeeName) + ''%'')	

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			g.EmployeeName AS [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID 
		WHERE
			a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND UPPER(g.EmployeeName) LIKE (''%'' + UPPER(@EmployeeName) + ''%'')
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
	if @FilterByClient = 1 --search by client
		Begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex('','', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)
			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
			INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
			WHERE
				a.QueueDate <= GETDATE()
				AND a.DebtorID <> 0
				AND UPPER(g.EmployeeName) LIKE (''%'' + UPPER(@EmployeeName) + ''%'')
				AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
					g.EmployeeName AS [Employee Name]
				FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
				INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID 
				WHERE
					a.QueueDate <= GETDATE()
					AND a.DebtorID <> 0
					AND UPPER(g.EmployeeName) LIKE (''%'' + UPPER(@EmployeeName) + ''%'')
					AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type],
				[Name],
				[Employee Name]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End
	Else
		Begin
			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
			INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
			WHERE
				a.QueueDate <= GETDATE()
				AND a.DebtorID <> 0
				AND UPPER(g.EmployeeName) LIKE (''%'' + UPPER(@EmployeeName) + ''%'')
				AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '',''))	

			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
					g.EmployeeName AS [Employee Name]
				FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
				INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID 
				WHERE
					a.QueueDate <= GETDATE()
					AND a.DebtorID <> 0
					AND UPPER(g.EmployeeName) LIKE (''%'' + UPPER(@EmployeeName) + ''%'')
					AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '',''))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type],
				[Name],
				[Employee Name]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End    
End


END


' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_Search]    Script Date: 06/05/2009 15:44:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Search]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'



-- =============================================
-- Author:		LongNguyen
-- Create date: Dec 15, 2007
-- Description:	
-- History:
--		2007/12/15	[Long Nguyen]	Init version.
--		2009/03/31	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_Search]
	@EmployeeID int = 0,
	@EmployeeName varchar(50) = '''',
	@Department int = 0,
	@IsEmployeePool bit,
	@RoleID int = 0,
	@ClientID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--This only used in MainPage (Refer to), if employee is supervisor -> only select supervisor
	DECLARE @Supervisor bit
	IF @EmployeeID > 0
		SELECT	@Supervisor = Supervisor	
		FROM	Employee
		WHERE	EmployeeID = @EmployeeID

	--Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = ''WHERE RowNumber BETWEEN '' + CAST(@BeginIndex as varchar(10)) + '' AND '' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = '' ''

	--Step 3: Populate the main SELECT command.
	DECLARE @cStmt varchar(4000)
	SET @cStmt = ''SELECT e.EmployeeID, e.UserID, e.EmployeeName, ISNULL(d.DeptDesc, '''''''') AS Department, e.RoleID, e.Description, ''
			 + '' CASE e.Supervisor WHEN 1 THEN ''''Y'''' ELSE '''''''' END AS Supervisor ''
			 + '' FROM Employee e LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID AND (d.Status <> ''''R'''') ''
			 + '' WHERE (e.EmployeeName LIKE (''''%'' + @EmployeeName + ''%'''')) ''
			 + '' AND ('' + STR(@Department) + ''= 0 OR e.Department = '' + STR(@Department) + '') ''
			 + '' AND ('' + STR(@RoleID) + ''= 0 OR e.RoleID = '' + STR(@RoleID) + '') AND (ISNULL(EmployeeStatus, '''''''') <> ''''R'''') ''
			 + '' AND ('' + ISNULL(STR(@Supervisor), ''1'') + ''= 1 OR e.Supervisor = 1) ''
			 + '' AND ('' + STR(@ClientID)+''= 0 OR EmployeeID IN (SELECT EmployeeID FROM CWX_ClientEmployee WHERE ClientID = '' + STR(@ClientID) + '')) ''
	
	IF (@IsEmployeePool = 1)
		SET @cStmt = @cStmt + '' AND EmployeeType=''''P'''' ''

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
	DECLARE @finalStmt varchar(8000)
	SET @finalStmt = ''WITH EmployeeList AS ''
				   + ''( ''
				   + ''  SELECT *, ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber ''
				   + ''  FROM ( ''	
				   + ''          {0}''
				   + ''    ) A ''
				   + '') ''
				   + ''SELECT * FROM EmployeeList '' + @pagingWhereClause
	SET @finalStmt = REPLACE(@finalStmt, ''{0}'', @cStmt)
print @finalStmt
	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)

	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = ''SELECT @RowCountOut=count(*) FROM ( {0} ) A''
    SET @rowCountStmt = REPLACE(@rowCountStmt, ''{0}'', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = ''@RowCountOut int OUTPUT''

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT
	
	RETURN @RowCount
END




' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 06/05/2009 15:45:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalForward]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalForward] 
	@SolicitorID int,
	@EmpList varchar(3000),
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

IF LEN(ISNULL(@EmpList,'''')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
		INNER JOIN Legal_Solicitors ls ON ls.Status = ''A'' and ls.SolicitorID = lg.SolicitorID
	WHERE
		a.DebtorID <> 0
        And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()	

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
			INNER JOIN Legal_Solicitors ls ON ls.Status = ''A'' and ls.SolicitorID = lg.SolicitorID
		WHERE
			a.DebtorID <> 0
			And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
	if @FilterByClient = 1 --search by client
		Begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex('','', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)
			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
				INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
				INNER JOIN Legal_Solicitors ls ON ls.Status = ''A'' and ls.SolicitorID = lg.SolicitorID
			WHERE
				a.DebtorID <> 0
				And lg.GroupID = ld.GroupID
				AND a.AgencyStatusID <> 2
				AND a.QueueDate <= GETDATE()
				AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
				FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
					INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
					INNER JOIN Legal_Solicitors ls ON ls.Status = ''A'' and ls.SolicitorID = lg.SolicitorID
				WHERE
					a.DebtorID <> 0
					And lg.GroupID = ld.GroupID
					AND a.AgencyStatusID <> 2
					AND a.QueueDate <= GETDATE()
					AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End
	Else
		Begin
			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
				INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
				INNER JOIN Legal_Solicitors ls ON ls.Status = ''A'' and ls.SolicitorID = lg.SolicitorID
			WHERE
				a.DebtorID <> 0
				And lg.GroupID = ld.GroupID
				AND a.AgencyStatusID <> 2
				AND a.QueueDate <= GETDATE()
				AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '',''))	

			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
				FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
					INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
					INNER JOIN Legal_Solicitors ls ON ls.Status = ''A'' and ls.SolicitorID = lg.SolicitorID
				WHERE
					a.DebtorID <> 0
					And lg.GroupID = ld.GroupID
					AND a.AgencyStatusID <> 2
					AND a.QueueDate <= GETDATE()
					AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '',''))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End    
End

END


' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalAgent]    Script Date: 06/05/2009 15:45:04 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalAgent]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =============================================
-- Description:	
-- History:
--	2008/04/21	[Sathya]		Init version.
--	2008/08/14	[Binh Truong]	la.Status = ''A''  >>>  la.Status <> ''R''
--	2008/09/25	[Sathya]		la.Status <> ''R''  >>>  la.Status = ''A''
--								Add criteria lg.GroupID = ld.GroupID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalAgent] 
	@AgentId int,
	@EmpList varchar(3000),
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

IF LEN(ISNULL(@EmpList,'''')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
		INNER JOIN Legal_Agents la ON la.Status = ''A'' and la.AgentID = lg.AgentID
	WHERE
		a.DebtorID <> 0
		And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()	

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
			INNER JOIN Legal_Agents la ON la.Status = ''A'' and la.AgentID = lg.AgentID
		WHERE
			a.DebtorID <> 0
            And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
	if @FilterByClient = 1 --search by client
		Begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex('','', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)
			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
				INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
				INNER JOIN Legal_Agents la ON la.Status = ''A'' and la.AgentID = lg.AgentID
			WHERE
				a.DebtorID <> 0
				And lg.GroupID = ld.GroupID
				AND a.AgencyStatusID <> 2
				AND a.QueueDate <= GETDATE()
				AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
			
			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
				FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
					INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
					INNER JOIN Legal_Agents la ON la.Status = ''A'' and la.AgentID = lg.AgentID
				WHERE
					a.DebtorID <> 0
					And lg.GroupID = ld.GroupID
					AND a.AgencyStatusID <> 2
					AND a.QueueDate <= GETDATE()
					AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End
	Else
		Begin
			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
				INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
				INNER JOIN Legal_Agents la ON la.Status = ''A'' and la.AgentID = lg.AgentID
			WHERE
				a.DebtorID <> 0
				And lg.GroupID = ld.GroupID
				AND a.AgencyStatusID <> 2
				AND a.QueueDate <= GETDATE()
				AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '',''))
			
			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
				FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
					INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
					INNER JOIN Legal_Agents la ON la.Status = ''A'' and la.AgentID = lg.AgentID
				WHERE
					a.DebtorID <> 0
					And lg.GroupID = ld.GroupID
					AND a.AgencyStatusID <> 2
					AND a.QueueDate <= GETDATE()
					AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '',''))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End    
End

END


' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalEmployee]    Script Date: 06/05/2009 15:45:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalEmployee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalEmployee] 
	@v_employeeId int,
	@EmpList varchar(3000),
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

IF LEN(ISNULL(@EmpList,'''')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()	

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
	IF @FilterByClient = 1 --search by client
		Begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex('','', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)
			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
				INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
			WHERE
				a.DebtorID <> 0
				AND a.AgencyStatusID <> 2
				AND a.QueueDate <= GETDATE()
				AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
				FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
					INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
				WHERE
					a.DebtorID <> 0
					AND a.AgencyStatusID <> 2
					AND a.QueueDate <= GETDATE()
					AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End
	Else
		Begin
			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
				INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
			WHERE
				a.DebtorID <> 0
				AND a.AgencyStatusID <> 2
				AND a.QueueDate <= GETDATE()
				AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '',''))	

			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
				FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
					INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
				WHERE
					a.DebtorID <> 0
					AND a.AgencyStatusID <> 2
					AND a.QueueDate <= GETDATE()
					AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '',''))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End    
End

END


' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtList]    Script Date: 06/05/2009 15:44:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@AccountID int = 0,
	@ClientID int=0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    IF @groupID <> 0
		SELECT [GroupDebtID],a.[GroupID],a.[AccountID],a.[LastEditDate],a.[PaymentAllocationRuleID],a.[IsInclude], a.[IsPrimary], b.InvoiceNumber
				,CAST(0 AS bit) AS IsGrouped
				,'''' AS GroupName
		FROM Legal_GroupDebts a
			JOIN Account b ON a.AccountID = b.AccountID
		WHERE a.AccountID = b.AccountID AND 
			CASE WHEN @ClientID > 0 THEN b.ClientID ELSE 0 END = @ClientID AND
			GroupID = @groupID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2
		ORDER BY a.[IsPrimary] DESC, b.AccountID
	ELSE
		SELECT	NULL AS [GroupDebtID], NULL AS [GroupID], b.[AccountID], NULL AS [LastEditDate],
				NULL AS [PaymentAllocationRuleID], 
				CAST((CASE b.AccountID WHEN @AccountID THEN 1 ELSE 0 END) AS bit) AS [IsInclude],
				CAST((CASE b.AccountID WHEN @AccountID THEN 1 ELSE 0 END) AS bit) AS [IsPrimary],
				b.InvoiceNumber,
				CAST(0 AS bit) AS IsGrouped,
				'''' AS GroupName
		FROM Account b 
		WHERE b.DebtorID = @debtorID AND 
			CASE WHEN @ClientID > 0 THEN b.ClientID ELSE 0 END = @ClientID AND
			b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2
		ORDER BY a.[IsPrimary] DESC, b.AccountID
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ReportScheduleTable_GetCustomPagingList]    Script Date: 06/05/2009 15:44:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ReportScheduleTable_GetCustomPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- History:
--	[26 Mar 2009]	Minh Dam		Add one parameter "ClientID"
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ReportScheduleTable_GetCustomPagingList] 
	@ClientID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(ID)
	FROM ReportScheduleTable
	WHERE @ClientID = 0 OR ClientID = @ClientID

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY r.ID) AS RowNumber,
				r.ID, 
				r.ReportID, 
				r.ScheduleType, 
				r.Description, 
				r.ScheduleStatus, 
				r.ScheduledDay, 
				r.BeginDate, 
				r.EndDate, 
				d.LetterDesc
		FROM ReportScheduleTable AS r 
			INNER JOIN DefineLetters AS d ON r.ReportID = d.LetterID
		WHERE @ClientID = 0 OR r.ClientID = @ClientID
    )

	SELECT	* FROM	Temp
	WHERE	(@PageSize <= 0) OR (RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize))
	
	RETURN @RowCount

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetChildTransactions]    Script Date: 06/05/2009 15:44:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetChildTransactions]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get child transaction list by parent transaction ID.
-- History:
--	2008/09/29	[Binh Truong]	Init version
--  2009/04/26  [SD]			Removed the Transactions.TXN_POSTED = ''Y''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_GetChildTransactions]
	@ParentTransactionID int
	
AS
BEGIN
	SET NOCOUNT ON;	
	SELECT	Transactions.TransactionID, 
			Transactions.TransactionAmount, 
			Transactions.TransactionComment,
			TransactionType.TransactionCode + '' - '' + TransactionType.Description as TransactionCodeDescription	
	FROM         Transactions INNER JOIN
	                      TransactionType ON Transactions.TransactionType = TransactionType.ID
	WHERE	Transactions.PaymentTypeID <> 0 AND
			Transactions.ParentTransactionID = @ParentTransactionID 
			--AND Transactions.TXN_POSTED = ''Y''
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionType]    Script Date: 06/05/2009 15:44:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- =============================================
-- Description:	Get transaction type and total amount of each transaction.
-- History:
--	2008/09/24	[Binh Truong]	Init version.
--  2009/04/26  [SD]			Removed the Transactions.TXN_POSTED = ''Y''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_GetTransactionType]
	@AccountID int,
	@ClientID int,
	@PaymentAllocationRuleID int = 0
AS
BEGIN
	SET NOCOUNT ON
	IF @PaymentAllocationRuleID = 0
	BEGIN
		SELECT     T.TransactionType, SUM(ISNULL(T.TransactionAmount, 0)) AS Amount, TT.Description, TT.TransactionCode, TT.AffectBalance
			FROM         Transactions AS T INNER JOIN
								  TransactionType AS TT ON T.TransactionType = TT.ID
			WHERE   (T.AccountID = @AccountID) AND 
					(T.ClientID = @ClientID) AND 
					--(T.TXN_POSTED = ''N'') AND
					(TT.AffectBalance = 1)
			GROUP BY T.TransactionType, TT.Description, TT.TransactionCode, TT.AffectBalance
	END
	ELSE
	BEGIN
		SELECT	T1.*,901,902,903
		FROM
				(SELECT     T.TransactionType, SUM(ISNULL(T.TransactionAmount, 0)) AS Amount, TT.Description, TT.TransactionCode, TT.AffectBalance
				FROM         Transactions AS T INNER JOIN
									  TransactionType AS TT ON T.TransactionType = TT.ID
				WHERE     (T.AccountID = @AccountID) AND (T.ClientID = @ClientID) --AND (T.TXN_POSTED = ''N'')
				GROUP BY T.TransactionType, TT.Description, TT.TransactionCode, TT.AffectBalance) as T1 LEFT OUTER JOIN
					Legal_PaymentAllocationRuleItems AS LP ON T1.TransactionType = LP.TransactionTypeID
		WHERE	LP.PaymentAllocationRuleID = @PaymentAllocationRuleID AND
				T1.AffectBalance = 1		
		ORDER BY LP.Seq
	END	
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_UpdateTransactionTypePosted]    Script Date: 06/05/2009 15:44:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_UpdateTransactionTypePosted]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Update posted transaction.
-- History:
--	2009/04/26	[SD]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_UpdateTransactionTypePosted]
	@AccountID int,
	@TransactionType int
AS
BEGIN	
	UPDATE    Transactions
	SET              TXN_POSTED = ''Y''
	WHERE     (AccountID = @AccountID) AND (TransactionType = @TransactionType) AND (TXN_POSTED = ''N'')
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 06/05/2009 15:44:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Description:	Get Transaction List by TransactionType with a custom column is "Transaction Code - Description"
-- History:
--	2008/08/29	[Thuy Nguyen]	Init version.
--	2008/09/29	[Binh Truong]	Select total transaction amount.
--	2008/10/29	[Binh Truong]	Add DateToPost field.
--	2008/10/30	[Binh Truong]	Exclude Transactions.Descriptor = ''A''
--  2009/04/26  [SD]			Removed the Transactions.Descriptor = ''A''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList] 		
	@AccountID int = 0,
	@TransactionType int = 0,
	@PaidAt int = -1,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;	

	DECLARE @querystring varchar(1000);

		CREATE TABLE #Temp(
		RowNumber int,		
		TransactionID int not null,
		DateToPost smalldatetime,
		DateOfTransaction smalldatetime,
		TransactionAmount money,		
		TransactionComment nvarchar(150),
		TransactionCodeDescription nvarchar(150),
		TransactionType int,
		InterestBreakdown bit,
		ReversedFlag bit,
		ImportedTransactionID varchar(100),
		TXN_POSTED varchar(1),
		TXN_PaymentType varchar(20),
		TXN_PaymentType_Details varchar(30),
		PaidAt varchar(3)
	);


SET @querystring = ''INSERT INTO #Temp
		SELECT 
		ROW_NUMBER() OVER (ORDER BY  t.DateOfTransaction DESC,t.TransactionID DESC) AS RowNumber,
		t.TransactionID, t.DateToPost, t.DateOfTransaction, t.TransactionAmount, t.TransactionComment,
		tt.TransactionCode + '''' - '''' + tt.Description as TransactionCodeDescription,
		t.TransactionType, tt.InterestBreakdown, t.ReversedFlag, t.ImportedTransactionID, t.TXN_POSTED,
		case t.PaymentTypeID when 0 then '' + '''''''' + ''-'' + ''''''''  +
						'' when 1 then'' + '''''''' + ''Cash'' + ''''''''  +
				    	'' when 2 then'' + '''''''' + ''Cashiers Cheque'' + ''''''''  + 
				    	'' when 3 then'' + '''''''' + ''Cheque'' + ''''''''  +
				    	'' when 4 then'' + '''''''' + ''Credit Card'' + ''''''''  +
				    	'' when 5 then'' + '''''''' + ''Money Order'' + ''''''''  + 
 					'' end,'' + 
		''case when t.TransactionType = 901 then t.PaidWhere else '' + '''''''' + ''-'' + '''''''' + ''end,'' +
		''case when t.PaidAt = 1 then ''''PTC'''' else ''''PTA'''' end '' +
	'' FROM Transactions t LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID
	WHERE	t.AccountID = '' + cast(@AccountID as varchar) + '' AND 
			ISNULL(t.ParentTransactionID, 0) = 0''
		
-- AND t.Descriptor <> ''''A''''

	IF @TransactionType<>0 SET @querystring = @querystring + '' AND t.TransactionType = '' + cast(@TransactionType as varchar);
	
	IF @PaidAt > -1 SET @querystring = @querystring + '' AND t.PaidAt = '' + cast(@PaidAt as varchar(1));
	
	EXEC (@querystring)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	DROP TABLE #Temp
	
	SELECT	SUM(TransactionAmount) as TotalAmount
	FROM	Transactions
	WHERE	AccountID = @AccountID AND
			(@TransactionType=0 OR TransactionType = @TransactionType) AND
			ISNULL(ParentTransactionID, 0) = 0 
			--AND Descriptor <> ''A'' -- exclude additional transaction		
	RETURN @RowCount
END
'
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transactons_GetTransactionList]    Script Date: 06/05/2009 15:44:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transactons_GetTransactionList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 26, 2009
-- Description:	Get list of payment type (PTA or PTC)
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transactons_GetTransactionList]
	@PaymentType int,
	@ExcludeReversalTran bit,
	@ClientID int,
	@PageSize int = 10,
	@PageIndex int = 0	 	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @Rowcount int
	DECLARE @paidAt bit
			
    -- Insert statements for procedure here
	SELECT RowNumber, TransactionID, DebtorName, TransactionType, PaymentType, Amount, Description
	FROM 
	(
		SELECT	ROW_NUMBER() OVER (ORDER BY t.TransactionID DESC) AS RowNumber,
				 t.TransactionID as TransactionID, (p.FirstName + '' '' + p.LastName) as DebtorName, TT.Description as TransactionType,
				CASE 
					WHEN PaidAt = 0 THEN ''PTA'' 
					WHEN PaidAt = 1 THEN ''PTC''									
				END as PaymentType,
				t.TransactionAmount as Amount, t.TransactionComment as [Description]
		FROM	Transactions t INNER JOIN Account a ON t.AccountID = a.AccountID
				INNER JOIN TransactionType tt ON t.TransactionType = tt.ID	
				INNER JOIN DebtorInformation d ON a.DebtorID = d.DebtorID
				INNER JOIN PersonInformation p ON d.PersonID = p.PersonID
		WHERE	(t.PaidAt = @PaymentType OR @PaymentType = -1) AND 
				 (t.ReversedFlag <> @ExcludeReversalTran OR @ExcludeReversalTran = 0) AND
				(t.ClientID = @ClientID OR @ClientID = -1)
	) as a
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	SELECT @Rowcount = count(*)
	FROM	Transactions t INNER JOIN Account a ON t.AccountID = a.AccountID
				INNER JOIN TransactionType tt ON t.TransactionType = tt.ID	
				INNER JOIN DebtorInformation d ON a.DebtorID = d.DebtorID
				INNER JOIN PersonInformation p ON d.PersonID = p.PersonID
	WHERE	(t.PaidAt = @PaymentType OR @PaymentType = -1) AND 
				 (t.ReversedFlag <> @ExcludeReversalTran OR @ExcludeReversalTran = 0) AND
				(t.ClientID = @ClientID OR @ClientID = -1)

	RETURN @Rowcount			
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByName]    Script Date: 06/05/2009 15:45:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByName]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE PROCEDURE [dbo].[CWX_Account_SearchDebtorByName] 
	@DebtorName varchar(100),
	@EmpList varchar(3000),
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF @PageSize > 0
BEGIN
	SET @BeginIndex = @PageIndex * @PageSize + 1
	SET @EndIndex = (@PageIndex + 1) * @PageSize
END
ELSE
BEGIN
	SET @BeginIndex = 1
	SET @EndIndex = @RowCount
END

IF LEN(ISNULL(@EmpList,'''')) = 0 --search full
	Begin
		SELECT
			@RowCount = COUNT(a.AccountID)
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(p.FirstName) + '' '' + RTRIM(p.MiddleName) + '' '' + RTRIM(p.LastName)) LIKE (''%'' + UPPER(@DebtorName) + ''%'')		

		WITH Temp
		AS
		(
			SELECT
				ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + '' '' + RTRIM(p.MiddleName) + '' '' + RTRIM(p.LastName))) AS RowNumber,
				(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as KeyField,
				a.QueueDate AS [QueueDate],
				a.InvoiceNumber as [Account Number],
				a.AccountAge AS [DPD],
				a.MCode AS [Bucket],
				a.CCode AS [Cycle],
				a.BillAmount AS [Bill Amount],
				a.BillBalance AS [Bill Balance],
				s.ShortDesc as [Status],
				s.SortPriority AS [Priority],
				a.AssignmentType AS [Assignment Type],
				p.SocialSecurityNumber AS [ID],
				rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
			FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			WHERE
				a.DebtorID <> 0
				AND UPPER(RTRIM(p.FirstName) + '' '' + RTRIM(p.MiddleName) + '' '' + RTRIM(p.LastName)) LIKE (''%'' + UPPER(@DebtorName) + ''%'')
		)

		SELECT
			[KeyField],
			[QueueDate],
			[Account Number],
			[DPD],
			[Bucket],
			[Cycle],
			[Bill Amount],
			[Bill Balance],
			[Status],
			[Priority],
			[Assignment Type],
			[ID],
			[Name]
		FROM Temp
		WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

		RETURN @RowCount
	End
Else
	Begin
		if @FilterByClient = 1 --search by client
			Begin
				DECLARE @employeeID varchar(50)
				DECLARE @index int

				SET @index = charindex('','', @EmpList)
				SET @employeeID = substring(@EmpList, 1, @index -1)
				SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

				SELECT
					@RowCount = COUNT(a.AccountID)
				FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				WHERE
					a.DebtorID <> 0
					AND UPPER(RTRIM(p.FirstName) + '' '' + RTRIM(p.MiddleName) + '' '' + RTRIM(p.LastName)) LIKE (''%'' + UPPER(@DebtorName) + ''%'')
					AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

				WITH Temp
				AS
				(
					SELECT
						ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + '' '' + RTRIM(p.MiddleName) + '' '' + RTRIM(p.LastName))) AS RowNumber,
						(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as KeyField,
						a.QueueDate AS [QueueDate],
						a.InvoiceNumber as [Account Number],
						a.AccountAge AS [DPD],
						a.MCode AS [Bucket],
						a.CCode AS [Cycle],
						a.BillAmount AS [Bill Amount],
						a.BillBalance AS [Bill Balance],
						s.ShortDesc as [Status],
						s.SortPriority AS [Priority],
						a.AssignmentType AS [Assignment Type],
						p.SocialSecurityNumber AS [ID],
						rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
					FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					WHERE
						a.DebtorID <> 0
						AND UPPER(RTRIM(p.FirstName) + '' '' + RTRIM(p.MiddleName) + '' '' + RTRIM(p.LastName)) LIKE (''%'' + UPPER(@DebtorName) + ''%'')
						AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
				)

				SELECT
					[KeyField],
					[QueueDate],
					[Account Number],
					[DPD],
					[Bucket],
					[Cycle],
					[Bill Amount],
					[Bill Balance],
					[Status],
					[Priority],
					[Assignment Type],
					[ID],
					[Name]
				FROM Temp
				WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

				RETURN @RowCount
			End
		Else --search by emplist
			Begin
				SELECT
					@RowCount = COUNT(a.AccountID)
				FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				WHERE
					a.DebtorID <> 0
					AND UPPER(RTRIM(p.FirstName) + '' '' + RTRIM(p.MiddleName) + '' '' + RTRIM(p.LastName)) LIKE (''%'' + UPPER(@DebtorName) + ''%'')
					AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '',''))		

				WITH Temp
				AS
				(
					SELECT
						ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + '' '' + RTRIM(p.MiddleName) + '' '' + RTRIM(p.LastName))) AS RowNumber,
						(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as KeyField,
						a.QueueDate AS [QueueDate],
						a.InvoiceNumber as [Account Number],
						a.AccountAge AS [DPD],
						a.MCode AS [Bucket],
						a.CCode AS [Cycle],
						a.BillAmount AS [Bill Amount],
						a.BillBalance AS [Bill Balance],
						s.ShortDesc as [Status],
						s.SortPriority AS [Priority],
						a.AssignmentType AS [Assignment Type],
						p.SocialSecurityNumber AS [ID],
						rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
					FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					WHERE
						a.DebtorID <> 0
						AND UPPER(RTRIM(p.FirstName) + '' '' + RTRIM(p.MiddleName) + '' '' + RTRIM(p.LastName)) LIKE (''%'' + UPPER(@DebtorName) + ''%'')
						AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '',''))
				)

				SELECT
					[KeyField],
					[QueueDate],
					[Account Number],
					[DPD],
					[Bucket],
					[Cycle],
					[Bill Amount],
					[Bill Balance],
					[Status],
					[Priority],
					[Assignment Type],
					[ID],
					[Name]
				FROM Temp
				WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

				RETURN @RowCount
			End		
	End
END


' 
END
GO
/****** Object:  StoredProcedure [dbo].[SearchByofficePhone]    Script Date: 06/05/2009 15:44:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchByofficePhone]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

/******   Script Date: 2007/04/09,sathya  ******/
CREATE PROCEDURE [dbo].[SearchByofficePhone]
	@PhoneNumber char(50),
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt=''Select  convert(varchar(10), a.DebtorID) + ''''|'''' + convert(varchar(10), a.AccountID) as KeyField,''
	SET @cStmt=@cStmt+''a.QueueDate as [QueueDate],''
	SET @cStmt=@cStmt+''a.InvoiceNumber as [Account Number],''
	SET @cStmt=@cStmt+''a.AccountAge as [DPD],''
	SET @cStmt=@cStmt+''a.MCode AS [Bucket],''
	SET @cStmt=@cStmt+''a.CCode as [Cycle],''
	SET @cStmt=@cStmt+''a.BillAmount  as [Bill Amount],''
	SET @cStmt=@cStmt+''a.BillBalance  as [Bill Balance],''
	SET @cStmt=@cStmt+''s.ShortDesc as [Status],''
	SET @cStmt=@cStmt+''s.SortPriority AS [Priority],''
	SET @cStmt=@cStmt+''a.AssignmentType AS [Assignment Type],''
	SET @cStmt=@cStmt+''rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName) As [Name]''
SET @cStmt=@cStmt+'' from ''
	SET @cStmt=@cStmt+''Account a,''
	SET @cStmt=@cStmt+''DebtorInformation d,''
	SET @cStmt=@cStmt+''PersonInformation p,''
	SET @cStmt=@cStmt+''AccountStatus s''
SET @cStmt=@cStmt+'' where p.EmploymentPhone = ''+''''''''+Cast(@PhoneNumber As Char(50))+''''''''
	SET @cStmt=@cStmt+'' and d.DebtorID = a.DebtorID''
	SET @cStmt=@cStmt+'' and p.PersonID = d.PersonID''
	SET @cStmt=@cStmt+'' and s.AgencyStatus = a.AgencyStatusID''
	if @EmpList <> ''''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex('','', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + '' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))''
		end
		else
		begin
			SET @cStmt=@cStmt+'' and a.EmployeeID in (''+@EmpList+'')''
		end		
	end
	SET @cStmt=@cStmt+'' and a.DebtorID <> 0''
Exec SP_ExecuteSQL @cStmt
END


' 
END
GO
/****** Object:  StoredProcedure [dbo].[SearchAccountByBill]    Script Date: 06/05/2009 15:44:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchAccountByBill]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[SearchAccountByBill]
	@AcctID INT,
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt=''Select  convert(varchar(10), a.DebtorID) + ''''|'''' + convert(varchar(10), a.AccountID) as KeyField,''
	SET @cStmt=@cStmt+''a.QueueDate as [QueueDate],''
	SET @cStmt=@cStmt+''a.InvoiceNumber as [Account Number],''
	SET @cStmt=@cStmt+''a.AccountAge as [DPD],''
	SET @cStmt=@cStmt+''a.MCode AS [Bucket],''
	SET @cStmt=@cStmt+''a.CCode as [Cycle],''
	SET @cStmt=@cStmt+''a.BillAmount  as [Bill Amount],''
	SET @cStmt=@cStmt+''a.BillBalance  as [Bill Balance],''
	SET @cStmt=@cStmt+''s.ShortDesc as [Status],''
	SET @cStmt=@cStmt+''s.SortPriority AS [Priority],''
	SET @cStmt=@cStmt+''a.AssignmentType AS [Assignment Type],''
	SET @cStmt=@cStmt+''rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName) As [Name]''
SET @cStmt=@cStmt+'' from ''
	SET @cStmt=@cStmt+''Account a,''
	SET @cStmt=@cStmt+''DebtorInformation d,''
	SET @cStmt=@cStmt+''PersonInformation p,''
	SET @cStmt=@cStmt+''AccountStatus s''
SET @cStmt=@cStmt+'' where a.AccountID = ''+Cast(@AcctID As Char(9))
	SET @cStmt=@cStmt+'' and d.DebtorID = a.DebtorID''
	SET @cStmt=@cStmt+'' and p.PersonID = d.PersonID''
	SET @cStmt=@cStmt+'' and s.AgencyStatus = a.AgencyStatusID''
	if @EmpList <> ''''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex('','', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + '' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))''
		end
		else
		begin
			SET @cStmt=@cStmt+'' and a.EmployeeID in (''+@EmpList+'')''
		end		
	end
	SET @cStmt=@cStmt+'' and a.DebtorID <> 0''
Exec SP_ExecuteSQL @cStmt
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[SearchAccountByInvoice]    Script Date: 06/05/2009 15:44:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchAccountByInvoice]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE   PROCEDURE [dbo].[SearchAccountByInvoice]
	@Invoice char(50),
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt=''Select  convert(varchar(10), a.DebtorID) + ''''|'''' + convert(varchar(10), a.AccountID) as KeyField,''
	SET @cStmt=@cStmt+''a.QueueDate as [QueueDate],''
	SET @cStmt=@cStmt+''a.InvoiceNumber as [Account Number],''
	SET @cStmt=@cStmt+''a.AccountAge as [DPD],''
	SET @cStmt=@cStmt+''a.MCode AS [Bucket],''
	SET @cStmt=@cStmt+''a.CCode as [Cycle],''
	SET @cStmt=@cStmt+''a.BillAmount  as [Bill Amount],''
	SET @cStmt=@cStmt+''a.BillBalance  as [Bill Balance],''
	SET @cStmt=@cStmt+''s.ShortDesc as [Status],''
	SET @cStmt=@cStmt+''s.SortPriority AS [Priority],''
	SET @cStmt=@cStmt+''a.AssignmentType AS [Assignment Type],''
	SET @cStmt=@cStmt+''rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName) As [ Name],''
	SET @cStmt=@cStmt+''a.DebtorID As [DebtorID]''	
SET @cStmt=@cStmt+'' from ''
	SET @cStmt=@cStmt+''Account a,''
	SET @cStmt=@cStmt+''DebtorInformation d,''
	SET @cStmt=@cStmt+''PersonInformation p,''
	SET @cStmt=@cStmt+''AccountStatus s''
SET @cStmt=@cStmt+'' where a.InvoiceNumber = ''+''''''''+Cast(@Invoice As Char(50))+''''''''
	SET @cStmt=@cStmt+'' and d.DebtorID = a.DebtorID''
	SET @cStmt=@cStmt+'' and p.PersonID = d.PersonID''
	SET @cStmt=@cStmt+'' and s.AgencyStatus = a.AgencyStatusID''
	
	if @EmpList <> ''''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex('','', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + '' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))''
		end
		else
		begin
			SET @cStmt=@cStmt+'' and a.EmployeeID in (''+@EmpList+'')''
		end
	end
	SET @cStmt=@cStmt+'' and a.DebtorID <> 0''
	
Exec SP_ExecuteSQL @cStmt
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[SearchDebtorByPhone]    Script Date: 06/05/2009 15:44:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchDebtorByPhone]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

/******   Script Date: 2007/04/09,sathya  ******/
CREATE PROCEDURE [dbo].[SearchDebtorByPhone]
	@PhoneNumber char(25),
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt=''Select  convert(varchar(10), a.DebtorID) + ''''|'''' + convert(varchar(10), a.AccountID) as KeyField,''
	SET @cStmt=@cStmt+''a.QueueDate as [QueueDate],''
	SET @cStmt=@cStmt+''a.InvoiceNumber as [Account Number],''
	SET @cStmt=@cStmt+''a.AccountAge as [DPD],''
	SET @cStmt=@cStmt+''a.MCode AS [Bucket],''
	SET @cStmt=@cStmt+''a.CCode as [Cycle],''
	SET @cStmt=@cStmt+''a.BillAmount  as [Bill Amount],''
	SET @cStmt=@cStmt+''a.BillBalance  as [Bill Balance],''
	SET @cStmt=@cStmt+''s.ShortDesc as [Status],''
	SET @cStmt=@cStmt+''s.SortPriority AS [Priority],''
	SET @cStmt=@cStmt+''a.AssignmentType AS [Assignment Type],''
	SET @cStmt=@cStmt+''rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName) As [Name]''
SET @cStmt=@cStmt+'' from ''
	SET @cStmt=@cStmt+''Account a,''
	SET @cStmt=@cStmt+''DebtorInformation d,''
	SET @cStmt=@cStmt+''PersonInformation p,''
	SET @cStmt=@cStmt+''AccountStatus s''
SET @cStmt=@cStmt+'' where p.HomePhone = ''+''''''''+Cast(@PhoneNumber As Char(25))+''''''''
	SET @cStmt=@cStmt+'' and d.DebtorID = a.DebtorID''
	SET @cStmt=@cStmt+'' and p.PersonID = d.PersonID''
	SET @cStmt=@cStmt+'' and s.AgencyStatus = a.AgencyStatusID''

	if @EmpList <> ''''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex('','', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + '' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))''
		end
		else
		begin
			SET @cStmt=@cStmt+'' and a.EmployeeID in (''+@EmpList+'')''
		end		
	end
	SET @cStmt=@cStmt+'' and a.DebtorID <> 0''
Exec SP_ExecuteSQL @cStmt
END


' 
END
GO
/****** Object:  StoredProcedure [dbo].[SearchAccountByMobile]    Script Date: 06/05/2009 15:44:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchAccountByMobile]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

/******   Script Date: 2007/04/09,sathya  ******/
CREATE PROCEDURE [dbo].[SearchAccountByMobile]
	@MobilePhone char(50),
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt=''Select  convert(varchar(10), a.DebtorID) + ''''|'''' + convert(varchar(10), a.AccountID) as KeyField,''
SET @cStmt=@cStmt+''a.QueueDate as [QueueDate],''
SET @cStmt=@cStmt+''a.InvoiceNumber as [Account Number],''
SET @cStmt=@cStmt+''a.AccountAge as [DPD],''
SET @cStmt=@cStmt+''a.MCode AS [Bucket],''
SET @cStmt=@cStmt+''a.CCode as [Cycle],''
SET @cStmt=@cStmt+''a.BillAmount  as [Bill Amount],''
SET @cStmt=@cStmt+''a.BillBalance  as [Bill Balance],''
SET @cStmt=@cStmt+''s.ShortDesc as [Status],''
SET @cStmt=@cStmt+''s.SortPriority AS [Priority],''
SET @cStmt=@cStmt+''a.AssignmentType AS [Assignment Type],''
SET @cStmt=@cStmt+''rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName) As [Name]''
SET @cStmt=@cStmt+'' from ''
	SET @cStmt=@cStmt+''Account a,''
	SET @cStmt=@cStmt+''DebtorInformation d,''
	SET @cStmt=@cStmt+''PersonInformation p,''
	SET @cStmt=@cStmt+''AccountStatus s''
SET @cStmt=@cStmt+'' where p.MobilPhone = ''+''''''''+Cast(@MobilePhone As Char(50))+''''''''
	SET @cStmt=@cStmt+'' and d.DebtorID = a.DebtorID''
	SET @cStmt=@cStmt+'' and p.PersonID = d.PersonID''
	SET @cStmt=@cStmt+'' and s.AgencyStatus = a.AgencyStatusID''
	if @EmpList <> ''''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex('','', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + '' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))''
		end
		else
		begin
			SET @cStmt=@cStmt+'' and a.EmployeeID in (''+@EmpList+'')''
		end		
	end
	SET @cStmt=@cStmt+'' and a.DebtorID <> 0''
Exec SP_ExecuteSQL @cStmt
END


' 
END
GO
/****** Object:  StoredProcedure [dbo].[SearchByLegalGroupCode]    Script Date: 06/05/2009 15:44:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchByLegalGroupCode]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'



-- =============================================
-- Author:		KhoaDang
CREATE PROCEDURE [dbo].[SearchByLegalGroupCode]
	@GroupCode varchar(20),
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt=''Select  convert(varchar(10), a.DebtorID) + ''''|'''' + convert(varchar(10), a.AccountID) as KeyField,''
	SET @cStmt=@cStmt+''a.QueueDate as [QueueDate],''
	SET @cStmt=@cStmt+''a.InvoiceNumber as [Account Number],''
	SET @cStmt=@cStmt+''a.AccountAge as [DPD],''
	SET @cStmt=@cStmt+''a.MCode AS [Bucket],''
	SET @cStmt=@cStmt+''a.CCode as [Cycle],''
	SET @cStmt=@cStmt+''a.BillAmount  as [Bill Amount],''
	SET @cStmt=@cStmt+''a.BillBalance  as [Bill Balance],''
	SET @cStmt=@cStmt+''s.ShortDesc as [Status],''
	SET @cStmt=@cStmt+''s.SortPriority AS [Priority],''
	SET @cStmt=@cStmt+''a.AssignmentType AS [Assignment Type],''
	SET @cStmt=@cStmt+''rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName) As [Name]''
SET @cStmt=@cStmt+'' from ''
	SET @cStmt=@cStmt+''Account a,''
	SET @cStmt=@cStmt+''DebtorInformation d,''
	SET @cStmt=@cStmt+''PersonInformation p,''
	SET @cStmt=@cStmt+''AccountStatus s,''
	SET @cStmt=@cStmt+''Legal_Groups g''
	SET @cStmt=@cStmt+'' where a.AccountID = g.GroupedAccountID''
	SET @cStmt=@cStmt+'' and d.DebtorID = a.DebtorID''
	SET @cStmt=@cStmt+'' and p.PersonID = d.PersonID''
	SET @cStmt=@cStmt+'' and s.AgencyStatus = a.AgencyStatusID and g.Code='' + '''''''' + RTRIM(@GroupCode) + ''''''''
	if @EmpList <> ''''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex('','', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + '' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))''
		end
		else
		begin
			SET @cStmt=@cStmt+'' and a.EmployeeID in (''+@EmpList+'')''
		end		
	end
	
	SET @cStmt=@cStmt+'' and a.DebtorID <> 0''
	Exec SP_ExecuteSQL @cStmt
END


' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueByAmtRange]    Script Date: 06/05/2009 15:45:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_QueueByAmtRange]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_Account_QueueByAmtRange] 
	-- Add the parameters for the stored procedure here
	@v_Range int,
	@EmpList varchar(3000),	
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause VARCHAR(50)
	SET @orderByClause = '' ORDER BY a.QueueDate DESC''


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = ''WHERE RowIndex BETWEEN '' + CAST(@BeginIndex as varchar(10)) + '' AND '' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = '' ''


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = '' SELECT''
				+ ''   (CONVERT(varchar(10), a.DebtorID) + ''''|'''' + CONVERT(varchar(10), a.AccountID)) AS KeyField,''
				+ ''   a.QueueDate AS [QueueDate],''
				+ ''   a.InvoiceNumber as [Account Number],''
				+ ''   a.AccountAge AS [DPD],''
				+ ''   a.MCode AS [Bucket],''
				+ ''   a.CCode AS [Cycle],''
				+ ''   a.BillAmount AS [Bill Amount],''
				+ ''   a.BillBalance AS [Bill Balance],''
				+ ''   s.ShortDesc AS [Status],''
				+ ''   s.SortPriority AS [Priority],''
				+ ''   a.AssignmentType AS [Assignment Type],''
				+ ''   (rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName)) AS [Name]''
				+ '' FROM Account a''
				+ '' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID''
				+ '' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID''
				+ '' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID''
				+ '' WHERE''
				+ ''   a.QueueDate <= getDate()''
				+ ''   AND a.DebtorID <> 0''
				+ ''   AND a.AgencyStatusID <> 2''

	if ((@EmpList <> '''') and (@EmpList <> ''Null''))
	Begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex('','', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + '' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))''
		end
		else
		begin
			SET @cStmt=@cStmt+'' AND a.EmployeeID in (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString('''''' + @EmpList + '''''','' + '''''''' + '','' + '''''''' + ''))''
		end				
	End

	if @v_Range = 1
	Begin
		SET @cStmt = @cStmt +''   AND a.BillBalance < 10000''
	End

	if @v_Range = 2
	Begin
		SET @cStmt = @cStmt +''  AND a.BillBalance >= 10000''
		SET @cStmt = @cStmt +''  AND a.BillBalance < 25000''
	End

	if @v_Range = 3
	Begin
		SET @cStmt = @cStmt +''	AND a.BillBalance >= 25000''
		SET @cStmt = @cStmt +''	AND a.BillBalance < 50000''		
	End

	if @v_Range = 4
	Begin
		SET @cStmt = @cStmt +''	AND a.BillBalance >= 50000''
		SET @cStmt = @cStmt +''	AND a.BillBalance < 150000''		
	End

	if @v_Range = 5
	Begin
		SET @cStmt = @cStmt +''	AND a.BillBalance >= 150000''
	End


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = ''WITH AccountResults AS ''
				   + ''( ''
				   + ''  SELECT *, ROW_NUMBER() OVER ('' + @orderByClause + '') as RowIndex ''
				   + ''  FROM ( ''	
				   + ''          {0}''
				   + ''    ) A ''
				   + '') ''
				   + ''   ''
				   + ''SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [Name]''
				   + ''FROM AccountResults ''
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, ''{0}'', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = ''SELECT @RowCountOut=count(*) FROM ( {0} ) A''
    SET @rowCountStmt = REPLACE(@rowCountStmt, ''{0}'', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = ''@RowCountOut int OUTPUT''

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[SearchDebtorBySocial]    Script Date: 06/05/2009 15:44:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchDebtorBySocial]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
/******   Script Date: 2007/04/09,sathya  ******/
CREATE PROCEDURE [dbo].[SearchDebtorBySocial]
	@Social char(25),
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN

DECLARE @cStmt NVARCHAR(4000)
SET @cStmt=''Select  convert(varchar(10), a.DebtorID) + ''''|'''' + convert(varchar(10), a.AccountID) as KeyField,''
	SET @cStmt=@cStmt+''a.DebtorID As [DebtorID],''
	SET @cStmt=@cStmt+''a.InvoiceNumber As [Account No.],''
	SET @cStmt=@cStmt+''convert(char(10), a.QueueDate, 111) as [QueueDate],''
	SET @cStmt=@cStmt+''a.AccountAge as [DPD],''
	SET @cStmt=@cStmt+''CAST(a.MCode AS CHAR(2)) as [Bucket],''
	SET @cStmt=@cStmt+''a.CCode as [Cycle],''
	SET @cStmt=@cStmt+''a.BillAmount  as [Bill Amount],''
	SET @cStmt=@cStmt+''a.BillBalance  as [Bill Balance],''
	SET @cStmt=@cStmt+''a.Minimum_due  as [Minimum Due],''
	SET @cStmt=@cStmt+''p.SocialSecurityNumber as [ID],''
	SET @cStmt=@cStmt+''rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName) As [ Name]''
SET @cStmt=@cStmt+'' from ''
	SET @cStmt=@cStmt+''Account a,''
	SET @cStmt=@cStmt+''DebtorInformation d,''
	SET @cStmt=@cStmt+''PersonInformation p''
SET @cStmt=@cStmt+'' where p.SocialSecurityNumber = ''+''''''''+Cast(@Social As Char(25))+''''''''
	SET @cStmt=@cStmt+'' and d.DebtorID = a.DebtorID''
	SET @cStmt=@cStmt+'' and d.PersonID = p.PersonID''
	SET @cStmt=@cStmt+'' and a.DebtorID <> 0 and a.AgencyStatusID <> 2 and a.SystemStatusID <> 2 and a.AccountAge > 0 and a.BillBalance > 0''	

	if @EmpList <> ''''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex('','', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + '' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))''
		end
		else
		begin
			SET @cStmt=@cStmt+'' and a.EmployeeID in (''+@EmpList+'')''
		end		
	end
print @cStmt
Exec SP_ExecuteSQL @cStmt
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_IsAccountNumberExisted]    Script Date: 06/05/2009 15:44:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_IsAccountNumberExisted]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 18 Mar 2009
-- Description:	Check if Description is existed in table CWX_CLIENTYPE
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_IsAccountNumberExisted]
	-- Add the parameters for the stored procedure here
	@AccountNumber varchar(50) = '''',
	@AccountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS (SELECT 1 FROM Account WHERE @AccountNumber <> '''' AND InvoiceNumber = @AccountNumber AND AccountID <> @AccountID)
		RETURN 1
	ELSE 
		RETURN 0
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_SaveInfo]    Script Date: 06/05/2009 15:44:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_SaveInfo]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'	
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_SaveInfo]
	@AccountID int,
	@PersonID int,
	@RelationshipType int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @InvoiceNumber varchar(50)
	DECLARE @DebtorID int
	DECLARE @InterfaceID int
	DECLARE @SocialSecurityNumber varchar(50)

	SELECT
		@InvoiceNumber = InvoiceNumber,
		@DebtorID = DebtorID,
		@InterfaceID = InterfaceID
	FROM Account
	WHERE AccountID = @AccountID
	
	-- Relationship_no is the GroupName of Debtor of Person that Cosignee belongs to
	SELECT @SocialSecurityNumber = GroupName
	FROM DebtorInformation 
	WHERE PersonID = @PersonID
    -- Insert statements for procedure here
	--Insert data
	IF(NOT EXISTS(SELECT Bill FROM CosigneeInformation Where Bill = @AccountID and PersonID = @PersonID))
	BEGIN
		INSERT INTO CosigneeInformation
		(
			Bill,
			PersonID,
			DebtorID,
			Relationship_no,
			Relationship_Type,
			Account_no,
			InterfaceID
		)
		VALUES
		(
			@AccountID,
			@PersonID,
			@DebtorID,
			@SocialSecurityNumber,
			@RelationshipType,
			@InvoiceNumber,
			@InterfaceID
		)
	END
	ELSE
	BEGIN
	--Update data	
		UPDATE CosigneeInformation
		SET Relationship_Type= @RelationshipType
		WHERE Bill = @AccountID and PersonID = @PersonID
	
	END
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_CheckPrimaryDebtor]    Script Date: 06/05/2009 15:44:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_CheckPrimaryDebtor]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ThanhNguyen
-- Create date: 02-June-2009
-- Description:	Check whether the PersonID is the primary debtor
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_CheckPrimaryDebtor] 
	@AccountID int,
	@PersonIDToCheck int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @PersonID int
	SELECT @PersonID = a.PersonID
	FROM
	(
		SELECT distinct d.PersonID as PersonID
		FROM CosigneeInformation c INNER JOIN DebtorInformation d ON c.DebtorID = d.DebtorID
		WHERE c.Bill = @AccountID
	) a
	if(@PersonID = @PersonIDToCheck) RETURN 1
	RETURN 0	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_UnlockAllDebtors]    Script Date: 06/05/2009 15:44:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInformation_UnlockAllDebtors]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE PROCEDURE [dbo].[CWX_DebtorInformation_UnlockAllDebtors]	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE DebtorInformation
	SET LockedByID = null,
		LockedDate = null
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_UnlockAccounts]    Script Date: 06/05/2009 15:44:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInformation_UnlockAccounts]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 08 Apr 2009
-- Description:	Unlock all accounts of a debtor
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DebtorInformation_UnlockAccounts]
	@DebtorID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE DebtorInformation
	SET LockedByID = null,
		LockedDate = null,
		LockedBy   = null
	WHERE DebtorID = @DebtorID
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_LockAccounts]    Script Date: 06/05/2009 15:44:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInformation_LockAccounts]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 08 Apr 2009
-- Description:	Lock all accounts of a debtor
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DebtorInformation_LockAccounts]
	@DebtorID int,
	@LockedByEmployeeID int,
	@LockedDate datetime,
	@LockedSessionID varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE DebtorInformation
	SET LockedByID = @LockedByEmployeeID,
		LockedDate = @LockedDate,
		LockedBy = @LockedSessionID
	WHERE DebtorID = @DebtorID
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionTypeInCaseEdit]    Script Date: 06/18/2009 15:59:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionTypeInCaseEdit]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_Transaction_GetTransactionTypeInCaseEdit]
	@AccountID int,
	@ClientID int,
	@PaymentAllocationRuleID int = 0,
	@TransactionID int
AS
BEGIN
	SET NOCOUNT ON
	IF @PaymentAllocationRuleID = 0
	BEGIN
		SELECT     T.TransactionType, SUM(ISNULL(T.TransactionAmount, 0)) AS Amount, TT.Description, TT.TransactionCode, TT.AffectBalance
			FROM         Transactions AS T INNER JOIN
								  TransactionType AS TT ON T.TransactionType = TT.ID
			WHERE   (T.AccountID = @AccountID) AND 
					(T.ClientID = @ClientID) AND 
					--(T.TXN_POSTED = ''N'') AND
					(TT.AffectBalance = 1) AND
					T.TransactionID <> @TransactionID AND
					Isnull(T.ParentTransactionID,'''') <> @TransactionID
			GROUP BY T.TransactionType, TT.Description, TT.TransactionCode, TT.AffectBalance
	END
	ELSE
	BEGIN
		SELECT	T1.*,901,902,903
		FROM
				(SELECT     T.TransactionType, SUM(ISNULL(T.TransactionAmount, 0)) AS Amount, TT.Description, TT.TransactionCode, TT.AffectBalance
				FROM         Transactions AS T INNER JOIN
									  TransactionType AS TT ON T.TransactionType = TT.ID
				WHERE     (T.AccountID = @AccountID) AND 
							(T.ClientID = @ClientID) AND --AND (T.TXN_POSTED = ''N'')
							T.TransactionID <> @TransactionID AND
							Isnull(T.ParentTransactionID,'''') <> @TransactionID
				GROUP BY T.TransactionType, TT.Description, TT.TransactionCode, TT.AffectBalance) as T1 LEFT OUTER JOIN
					Legal_PaymentAllocationRuleItems AS LP ON T1.TransactionType = LP.TransactionTypeID
		WHERE	LP.PaymentAllocationRuleID = @PaymentAllocationRuleID AND
				T1.AffectBalance = 1		
		ORDER BY LP.Seq
	END	
END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Views_GroupByFinancialType]    Script Date: 06/18/2009 15:59:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Views_GroupByFinancialType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_Views_GroupByFinancialType]
	@ClientID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	fnct.description ,sum(c.BillAmount) as TotalAmount
	FROM	account c INNER JOIN transactions t ON c.accountid = t.accountid
			INNER JOIN transactiontype tt ON t.transactiontype = tt.id
			INNER JOIN cwx_financialtype fnct ON tt.financialtypeid = fnct.financialtypeid
	WHERE	(c.clientid = @ClientID OR @ClientID = 0)
	GROUP BY fnct.Description
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Views_GroupByAccountStatus]    Script Date: 06/18/2009 15:59:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Views_GroupByAccountStatus]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 26, 2009
-- Description:	Summary Account info follow format:
--	Status	Total Account		TotalListAmount		TotalBillBalance
--	Active	5					140.000				15365
--	Legal	6					150.000				165.000		
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Views_GroupByAccountStatus]
	@ClientID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	ast.ShortDesc as [Status], count(a.accountID) as TotalAccount, sum(a.BillAmount) as TotalListAmount, 
			sum(a.BillBalance) as TotalBillBalance

	FROM	Account a INNER JOIN AccountStatus ast ON a.AgencyStatusID = ast.AgencyStatus
	WHERE	(a.ClientID = @ClientID OR @ClientID = 0) AND ast.Type IN (''D'',''S'')
	GROUP BY ast.ShortDesc			
END

' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Transaction_DeleteTransaction]    Script Date: 06/18/2009 15:59:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_DeleteTransaction]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Delete transaction.
-- History:
--	2009/June/09	[Phuong Le]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_DeleteTransaction] 
	@AccountID int,
	@transactionID int,
	@TransactionType int, -- 1: Add Other Charge; 2: Receive Payment
	@TransactionAmount money,
	@EffectToBalance int = 0, -- 0: No effect; 1: increase balance; 2: decrease balance,
	@DeleteBy int,
	@WriteHistory bit,
	@DeleteParentTransaction bit
AS
BEGIN	
	BEGIN TRANSACTION
	
	--Write Log
	IF @WriteHistory =1
		BEGIN
			INSERT INTO dbo.CWX_DeleteTransaction_log(AccountID, ClientID, EmployeeID, PaymentTypeID, DateOfTransaction, TransactionType,
					TransactionAmount, TransactionComment, DateToPost, PaidWhere, ReversedFlag, ImportedTransactionID,
					Descriptor, TXN_POSTED, PART_AMOUNT, ParentTransactionID, PromiseID, DeletedBy, DeletedDate)
				SELECT AccountID, ClientID, EmployeeID, PaymentTypeID, DateOfTransaction, TransactionType,
					TransactionAmount, TransactionComment, DateToPost, PaidWhere, ReversedFlag, ImportedTransactionID,
					Descriptor, TXN_POSTED, PART_AMOUNT, ParentTransactionID, PromiseID, @DeleteBy, getdate()
				FROM [dbo].[transactions]
				WHERE transactionid = @transactionID or ParentTransactionID = @transactionID
		END

	IF @@ERROR <> 0
	   BEGIN
		ROLLBACK TRAN
		return 0
	   END 
	--Delete transaction
	IF @DeleteParentTransaction =1
		BEGIN
			DELETE [dbo].[transactions] WHERE transactionid = @transactionID or ParentTransactionID = @transactionID			
		END
	ELSE
		BEGIN
			DELETE [dbo].[transactions] WHERE ParentTransactionID = @transactionID
		END

	IF @@ERROR <> 0
	   BEGIN
		ROLLBACK TRAN
		return 0
	   END
	--Update amount
	EXEC [dbo].[CWX_Account_UpdateTransactionAmount] @AccountID, @TransactionType, @TransactionAmount, @EffectToBalance
	IF @@ERROR <> 0
	   BEGIN
		ROLLBACK TRAN
		return 0
	   END

	COMMIT TRANSACTION
	return 1
END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientProperties_GetClientsHaveProperties]    Script Date: 06/18/2009 15:59:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties_GetClientsHaveProperties]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ThanhNguyen
-- Create date: 09-June-2009
-- Description:	Get list of Clients that have properties
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientProperties_GetClientsHaveProperties]	
	@PageSize int = 10, 
	@PageIndex int =0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT RowNumber, a.ClientID, a.ClientName, a.BillingPeriod, a.InvoiceType
	FROM 
	(
		SELECT	ROW_NUMBER() OVER (ORDER BY c.ClientID DESC) AS RowNumber,
				c.ClientID, ISNULL(c.ClientName,'''') as ClientName, cps.value as BillingPeriod, cps1.value as InvoiceType
		FROM	ClientInformation c INNER JOIN CWX_ClientProperties cp ON c.ClientID = cp.ClientID
				LEFT JOIN CWX_ClientPropertySettings cps ON cp.BillingPeriod = cps.ID
				LEFT JOIN CWX_ClientPropertySettings cps1 ON cp.InvoiceType = cps1.ID				
		WHERE	c.ClientID IN (SELECT ClientID FROM CWX_ClientProperties WHERE [Status] <> ''R'') AND
				cp.Status <> ''R''
			
	) as a
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DECLARE @rowCount int
	SELECT	@rowCount  = count(*)
	FROM	ClientInformation c INNER JOIN CWX_ClientProperties cp ON c.ClientID = cp.ClientID
			LEFT JOIN CWX_ClientPropertySettings cps ON cp.BillingPeriod = cps.ID
			LEFT JOIN CWX_ClientPropertySettings cps1 ON cp.InvoiceType = cps1.ID				
	WHERE	c.ClientID IN (SELECT ClientID FROM CWX_ClientProperties WHERE [Status] <> ''R'') AND
			cp.Status <> ''R''

	RETURN @rowCount
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientProperties_GetNoPropertiesClients]    Script Date: 06/18/2009 15:59:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties_GetNoPropertiesClients]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ThanhNguyen
-- Create date: 09-June-2009
-- Description:	Get list of Clients that do not have properties
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientProperties_GetNoPropertiesClients]	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT	c.ClientID, cast(c.ClientID as nvarchar(10))+ '' - '' + ISNULL(c.ClientName,'''') as ClientIDAndName
	FROM	ClientInformation c 
	WHERE c.ClientID NOT IN (SELECT ClientID FROM CWX_ClientProperties WHERE [Status] <> ''R'') AND [Status] <> ''R''
END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_SMTP_SMS_Check_MobilePhoneExist]    Script Date: 06/18/2009 16:35:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMTP_SMS_Check_MobilePhoneExist]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE PROC [dbo].[CWX_SMTP_SMS_Check_MobilePhoneExist] 
	@MobilePhoneNo	varchar(15)   
AS 
	return 1
	
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_SMSNMailTemplates_SoftDeleteAll]    Script Date: 06/18/2009 16:35:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMSNMailTemplates_SoftDeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- ===================================================================================
-- Author:		Hung nguyen
-- Create date: Jun 9, 2009
-- Description:	sms mail template
-- ===================================================================================
Create PROCEDURE [dbo].[CWX_SMSNMailTemplates_SoftDeleteAll] 
AS
BEGIN
	UPDATE	[dbo].[CWX_SMSNMailTemplates]
	SET		[Status] = ''R''
--	WHERE	ActionType = ''U''
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_SMS_SendingToTable_SendSMS]    Script Date: 06/18/2009 16:35:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMS_SendingToTable_SendSMS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ThanhNguyen	
-- Create date: 15-June-2009
-- Description:	Insert data to CWX_SMS_SendingToTable
-- =============================================
CREATE PROCEDURE [dbo].[CWX_SMS_SendingToTable_SendSMS]
	@SMS_Number varchar(15),
	@SMS_Message nvarchar(2000),
	@UserID varchar(50),
	@SendingDate datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO CWX_SMS_SendingToTable (SMS_Recipient,SMS_Message,SMS_Author,SMS_TimeAndDate)
	VALUES(@SMS_Number,@SMS_Message,@UserID,@SendingDate)
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_SMTP_SMS_Settings_Get]    Script Date: 06/18/2009 16:35:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMTP_SMS_Settings_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- ===================================================================================
-- Author:		Hung nguyen
-- Create date: Jun 9, 2009
-- Description:	sms mail template
-- ===================================================================================
CREATE PROC [dbo].[CWX_SMTP_SMS_Settings_Get] 
   
AS 
	SET NOCOUNT ON 
	
	--just use the first record only
	SELECT top 1 
		[SMTP_SMS_AccountID], 
		[DefaultEmailSubject], 
		[Description], 
		[DisplayName], 
		[EmailAddress], 
		[Name], 
		[Port], 
		[ReplyToAddress], 
		[ServerName], 
		[ServerType], 
		[SMS_Gateway], 		
		[SMS_Password], 
		[SMS_SendingTo], 
		[SMS_UserName], 
		[SMTP_EnableSSL], 
		[SMTP_Password], 
		[SMTP_UserName], 
		[UseDefaultCridentials] 
	FROM   [dbo].[CWX_SMTP_SMS_Settings] 
	ORDER BY SMTP_SMS_AccountID
	
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_SMTP_SMS_SettingsUpdate]    Script Date: 06/19/2009 18:03:04 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	just use the first record only
-- History:
--	2008/09/12	[hung nguyen]	Init version.
-- =============================================
CREATE PROC [dbo].[CWX_SMTP_SMS_SettingsUpdate] 
(
    @DefaultEmailSubject nvarchar(255)= null,
 --   @Description nvarchar(256) =null,
    @DisplayName nvarchar(128)= null,
    @EmailAddress nvarchar(128)= null,
 --   @Name nvarchar(256)= null,
    @Port int =null,
    @ReplyToAddress nvarchar(128)= null,
    @ServerName nvarchar(255) =null,
 --   @ServerType nvarchar(255) =null,
    @SMS_Getway nvarchar(255) =null,    
    @SMS_Password nvarchar(128) =null,
    @SMS_SendingTo int =null,
    @SMS_UserName nvarchar(128) =null,
    @SMTP_EnableSSL bit =null,
    @SMTP_Password nvarchar(128) =null,
    @SMTP_UserName nvarchar(128) =null
  --  @UseDefaultCridentials bit =null
)
AS 
	SET NOCOUNT ON 

	declare @SMTP_SMS_AccountID int;
	declare @AccountName nvarchar(100);

	set @AccountName= 'CWX_Account';
    set @SMTP_SMS_AccountID=0;

BEGIN TRAN

	if exists( select top 1 * from [dbo].[CWX_SMTP_SMS_Settings] )
		begin
			
			--just use the first record in this table only
			select top 1  @SMTP_SMS_AccountID= SMTP_SMS_AccountID 
			from [dbo].[CWX_SMTP_SMS_Settings]
			order by SMTP_SMS_AccountID;

				
				UPDATE [dbo].[CWX_SMTP_SMS_Settings]
				SET     [DefaultEmailSubject] = @DefaultEmailSubject, 
				--		[Description]     = @Description, 
						[DisplayName]     = @DisplayName, 
						[EmailAddress]    = @EmailAddress, 
				--		[Name]            = @Name, 
						[Port]            = @Port, 
				--		[ReplyToAddress]  = @ReplyToAddress, 
						[ServerName]      = @ServerName, 
				--		[ServerType]      = @ServerType, 
						[SMS_Gateway]      = @SMS_Getway, 						
				 
						[SMS_SendingTo]   = @SMS_SendingTo, 
						[SMS_UserName]    = @SMS_UserName, 
						[SMTP_EnableSSL]  = @SMTP_EnableSSL, 
				
						[SMTP_UserName]   = @SMTP_UserName 
				--		[UseDefaultCridentials] = @UseDefaultCridentials
				WHERE  [SMTP_SMS_AccountID] = @SMTP_SMS_AccountID	

				--update password if any
				IF((@SMTP_Password is not null) and (@SMTP_Password<>''))
				BEGIN
						UPDATE [dbo].[CWX_SMTP_SMS_Settings]
						SET     [SMTP_Password]   = @SMTP_Password
						WHERE  [SMTP_SMS_AccountID] = @SMTP_SMS_AccountID	
				END

				IF((@SMS_Password is not null) and (@SMS_Password<>''))
				BEGIN
						UPDATE [dbo].[CWX_SMTP_SMS_Settings]
						SET    [SMS_Password]    = @SMS_Password 
						WHERE  [SMTP_SMS_AccountID] = @SMTP_SMS_AccountID	
				END
		END
	ELSE
		BEGIN
			INSERT INTO [dbo].[CWX_SMTP_SMS_Settings] 
			(
				[DefaultEmailSubject], 
		--		[Description], 
				[DisplayName], 
				[EmailAddress], 
		--		[Name], 
				[Port], 
		--		[ReplyToAddress], 
				[ServerName], 
		--		[ServerType], 
				[SMS_Gateway], 				
				[SMS_Password], 
				[SMS_SendingTo], 
				[SMS_UserName], 
				[SMTP_EnableSSL], 
				[SMTP_Password], 
				[SMTP_UserName]
		--		[UseDefaultCridentials]
			)
			Values (
				@DefaultEmailSubject, 
		--		@Description, 
				@DisplayName, 
				@EmailAddress, 
		--		@Name, 
				@Port, 
		--		@ReplyToAddress, 
				@ServerName, 
		--		@ServerType, 
				@SMS_Getway, 				
				@SMS_Password, 
				@SMS_SendingTo, 
				@SMS_UserName, 
				@SMTP_EnableSSL, 
				@SMTP_Password, 
				@SMTP_UserName 
		--		@UseDefaultCridentials
		    )
			
		end	



--Update to system mail account

-- The Configuration Component Database account

DECLARE @account TABLE 
(
	accountID INT, 
	accountName VARCHAR(30), 
	[description] VARCHAR(80), 
	emailAddress VARCHAR(90), 
	displayName VARCHAR(90), 
	replyToAddress VARCHAR(90), 
	serverType VARCHAR(20), 
	serverName VARCHAR(90), 
	port INT, 
	userName VARCHAR(30), 
	useDefaultCredentials BIT, 
	enableSSL BIT
);

DECLARE @profileAccount TABLE 
(
		profileID INT, 
		profile_name varchar(30), 
		accountID int, 
		account_name varchar(30), 
		sequenceNumber int
); 

DECLARE @profile TABLE 
(
	profileID INT, 
	profile_name varchar(30), 
	[description] varchar(30)
); 

DECLARE @principalProfile TABLE 
(
	principleID INT, 
	principal_name varchar(30), 
	profileID int, 
	profile_name varchar(30), 
	isdefault bit
) 


INSERT INTO @account 
(
	accountID, 
	accountName, 
	[description], 
	emailAddress, 
	displayName, 
	replyToAddress, 
	serverType, 
	serverName, 
	port, 
	userName, 
	useDefaultCredentials, 
	enableSSL
)EXECUTE msdb.dbo.sysmail_help_account_sp


IF (NOT EXISTS (SELECT accountID FROM @account WHERE accountName = @AccountName)) 
BEGIN 
	EXECUTE msdb.dbo.sysmail_add_account_sp 
		@account_name    = @AccountName, 
		@description     = 'Mail account sending database notifications', 
		@email_address   = @EmailAddress, 
		@display_name    = @DisplayName, 
		--@replyto_address = 'cwx@gmail.com', 
		@mailserver_name = @ServerName,
		@port            = @Port,
		@username        = @SMTP_UserName,
		@password        = @SMTP_Password,
		@enable_ssl      = @SMTP_EnableSSL;	
END 
ELSE
BEGIN

	IF((@SMTP_Password is null) or (@SMTP_Password=''))
	BEGIN
		EXECUTE [msdb].[dbo].[sysmail_update_account_sp]
		   @account_name     = @AccountName,
		   @email_address    = @EmailAddress,
		   @display_name     = @DisplayName,
		   @mailserver_name  = @ServerName,  
		   @replyto_address  = null,
		   @port             = @Port,
		   @username         = @SMTP_UserName,
		 --  @password       = @SMTP_Password, //not update password field if it's empty
		   @enable_ssl       = @SMTP_EnableSSL
	END
	ELSE
	BEGIN
		EXECUTE [msdb].[dbo].[sysmail_update_account_sp]
		   @account_name     = @AccountName,
		   @email_address    = @EmailAddress,
		   @display_name     = @DisplayName,
		   @mailserver_name  = @ServerName,  
		   @replyto_address  = null,
		   @port             = @Port,
		   @username    = @SMTP_UserName,
		   @password    = @SMTP_Password,
		   @enable_ssl  = @SMTP_EnableSSL
	END
END

-- do profile 
INSERT INTO @profile 
(
	profileID, 
	profile_name, 
	[description]
)EXECUTE msdb.dbo.sysmail_help_profile_sp

IF (NOT EXISTS (SELECT profileID FROM @profile WHERE profile_name = 'CWX_Profile')) 
BEGIN 
	-- Create a Database Mail profile 
	EXECUTE msdb.dbo.sysmail_add_profile_sp 
		@profile_name = 'CWX_Profile', 
		@description = 'Used to send mail'; 
END 

-- do profile to account link 
INSERT INTO @profileAccount 
(
	profileID, 
	profile_name, 
	accountID, 
	account_name, 
	sequenceNumber
) EXECUTE msdb.dbo.sysmail_help_profileaccount_sp

IF (NOT EXISTS (SELECT profileID FROM @profileAccount WHERE profile_name = 'CWX_Profile')) 
BEGIN 

	-- Add the account to the profile 
	EXECUTE msdb.dbo.sysmail_add_profileaccount_sp 
		@profile_name = 'CWX_Profile', 
		@account_name = @AccountName, 
		@sequence_number =1 ; 
END 

-- make prinicple profile 
INSERT INTO @principalProfile
(
	PrincipleID, 
	principal_name, 
	profileID, 
	profile_name, 
	isdefault
)EXEC msdb.dbo.sysmail_help_principalprofile_sp

IF (NOT EXISTS (SELECT PrincipleID FROM @principalProfile WHERE profile_name = 'CWX_Profile')) 
BEGIN 
	-- Grant access to the profile 
	EXECUTE msdb.dbo.sysmail_add_principalprofile_sp 
	@profile_name = 'CWX_Profile', 
	@principal_name = 'public', 
	@is_default = true 
END 

SET NOCOUNT OFF 


-- See if there is an error
IF (@@ERROR <> 0)
  -- There's an error b/c @ERROR is not 0, rollback
  ROLLBACK

ELSE
  COMMIT   -- Success!  Commit the transaction
GO
/****** Object:  StoredProcedure [dbo].[CWX_SMSMail_History_GetPagingList]    Script Date: 06/18/2009 16:35:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMSMail_History_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ThanhNguyen
-- Create date: June-16-2009
-- Description:	Get history info of SMS And Mail
-- =============================================
CREATE PROCEDURE [dbo].[CWX_SMSMail_History_GetPagingList]
	@ChannelID int,
	@PageSize int = 10,
	@PageIndex int =  0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT a.RowNumber, a.ID, a.EmailAddress, a.PhoneNumber, a.Channel, a.SendingDate, a.TemplateDescription, a.BodyMessage
	FROM (
    -- Insert statements for procedure here
		SELECT	ROW_NUMBER() OVER (ORDER BY smsh.ID) AS RowNumber,
				smsh.ID as ID, ISNULL(smsh.MessageText, '''') as BodyMessage,  
				ISNULL(smsh.EmailAddress,'''') as EmailAddress, ISNULL(smsh.SMS_Number,'''') as PhoneNumber, 
				CASE WHEN smsh.ChannelID = 1 THEN ''Email'' ELSE ''SMS'' END as Channel,
				smsh.ProcessDate as SendingDate, ISNULL(dl.LetterDesc,'''') as TemplateDescription
		FROM	CWX_SMSMail_History smsh
				LEFT JOIN DefineLetters dl ON smsh.TemplateID = dl.LetterID
		WHERE	(smsh.ChannelID = @ChannelID OR @ChannelID = 0)
	) a
	WHERE (@PageSize <= 0) OR (RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize)
	
	DECLARE @rowCount int
	SELECT	@rowCount = count(*)
	FROM	CWX_SMSMail_History smsh
			LEFT JOIN DefineLetters dl ON smsh.TemplateID = dl.LetterID
	WHERE	(smsh.ChannelID = @ChannelID OR @ChannelID = 0)
	RETURN @rowCount
END
' 
END
GO

if not exists (select * from InformationTable where Description='Show Debtor Management')	
	insert into InformationTable values (1, 17, 0, '', 'Show Debtor Management', '', 'True', 'A')
GO
IF NOT EXISTS (SELECT * FROM IdentityFields WHERE TableName = 'ApplicationBy')	
	INSERT INTO IdentityFields(TableName, FieldValue) VALUES ('ApplicationBy', 0)
GO

IF NOT EXISTS (SELECT * FROM CWX_Currency WHERE CurrencyName='Rupi')	
INSERT INTO [dbo].[CWX_Currency]([CurrencyName],[Symbol])
     VALUES ('Rupi', 'Rp')

IF NOT EXISTS (SELECT * FROM CWX_Currency WHERE CurrencyName='USD')
INSERT INTO [dbo].[CWX_Currency]([CurrencyName],[Symbol])
     VALUES ('USD', '$')

IF NOT EXISTS (SELECT * FROM CWX_Currency WHERE CurrencyName='Pound')
INSERT INTO [dbo].[CWX_Currency]([CurrencyName],[Symbol])
     VALUES ('Pound', '�')

IF NOT EXISTS (SELECT * FROM CWX_Currency WHERE CurrencyName='EUR')
INSERT INTO [dbo].[CWX_Currency]([CurrencyName],[Symbol])
     VALUES ('EUR', '�')

IF NOT EXISTS (SELECT * FROM CWX_Currency WHERE CurrencyName='JPY')
INSERT INTO [dbo].[CWX_Currency]([CurrencyName],[Symbol])	
     VALUES ('JPY', '�')	

GO	

INSERT INTO CWX_StandardNotes(Description,ClientID)
SELECT it.Description, 0
FROM InformationTable it
WHERE it.InfoID = 4 and it.infotype = 6

GO

IF(NOT EXISTS(SELECT * FROM IDENTITYFIELDS WHERE TableName = 'CMSRelatedPartiesClassic'))	
BEGIN	
	INSERT INTO IDENTITYFIELDS
	VALUES('CMSRelatedPartiesClassic',0)
END
GO

UPDATE QueryDebtorInfoMaster
SET [Sql] = 'Exec CWX_Account_LoadXML %D, %E'
WHERE [Sql] = 'Exec CWX_Account_LoadXML %D'
GO

if not exists( select top 1 [description]  from dbo.InformationTable where [description]='Load all Client Accounts')
begin
    INSERT INTO [dbo].[InformationTable]([InfoID], [InfoType], [InfoSubType], [InfoKey], [Description], [Value], [ValueFormat], [Status])
	VALUES(1, 18, 0, N'', N'Load all Client Accounts', N'', N'True', N'A')
end	
GO

 --------------ThanhNguyen--------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DropDownDataDictionary]') AND type in (N'U'))
BEGIN
	
	INSERT INTO CWX_DropdownDataDictionary
	VALUES('Select CodeID, CodeDesc FROM AccountCodeMaster WHERE CodeType = 2 AND Status <> ''R''',0,0)

	INSERT INTO CWX_DropdownDataDictionary
	ValueS('Select LanguageID, Description FROM Languages WHERE Status <> ''R''',0,0) 

	INSERT INTO CWX_DropdownDataDictionary
	VALUES('Early in the Morning|Morning|Afternoon|EveningNight',1,0)

	INSERT INTO CWX_DropdownDataDictionary
	VALUES('Accounting|Software|Human Resources|Admin|IT',1,0)
	
	INSERT INTO CWX_DropdownDataDictionary
	VALUES('Select CodeID, CodeDesc FROM AccountCodeMaster WHERE CodeType = 1 AND Status <> ''R''',0,0)
	
	INSERT INTO CWX_DropdownDataDictionary
	VALUES('Select CodeID, CodeDesc FROM AccountCodeMaster WHERE CodeType = 3 AND Status <> ''R''',0,0)

END
GO
------INSERT TEST DATA TO CWX_PersonInformation_Dict
DELETE CWX_PersonInformation_Dict
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonInformation_Dict]') AND type in (N'U'))
BEGIN		
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'HomePhone'))
	BEGIN	
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('HomePhone','Home Phone',1,1,0,'Contact Information',1,1,'Contact Information',0,1)
    END
    
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'MobilPhone'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('MobilPhone','Mobil Phone',1,1,0,'Contact Information',2,1,'Contact Information',0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'EmploymentPhone'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('EmploymentPhone','Employment Phone',1,1,0,'Contact Information',3,1,'Contact Information',0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'EmploymentPhoneExtension'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('EmploymentPhoneExtension','Employment Phone Extension',1,1,0,'Contact Information',4,1,'Contact Information',0,1)
	END
		
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'Position'))
	BEGIN		
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('Position','Position',1,1,1,'Debtor Career',1,2,'Debtor Career',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'Profession'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('Profession','Profession',1,1,1,'Debtor Career',2,2,'Debtor Career',0,1)
    END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'Language'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('Language','Language',1,1,1,'Debtor Career',3,2,'Debtor Career',2,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'Department'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('Department','Department',1,1,1,'Debtor Career',4,2,'Debtor Career',4,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PMoney1'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('PMoney1','Total Income Per Month',1,1,2,'Income',1,3,'Income',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PMoney2'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('PMoney2','Husband Income',1,1,2,'Income',2,3,'Income',0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PMoney3'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('PMoney3','Wife Income',1,1,2,'Income',3,3,'Income',0,1)
	END

	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PLong1'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('PLong1','Number Of Childs',1,1,3,'Debtor Children Information',1,4,'Debtor Children Information',0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PLong2'))
	BEGIN	
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('PLong2','Age Of First Child',1,1,3,'Debtor Children Information',2,4,'Debtor Children Information',0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PLong3'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[DropDown],[CMSEdit])
    VALUES('PLong3','Age Of Last Child',1,1,3,'Debtor Children Information',3,4,'Debtor Children Information',0,1)
	END
END
GO

DELETE CWX_AccountInformation_Dict
-------INSERT DATA TO CWX_AccountInformation_Dict
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountInformation_Dict]') AND type in (N'U'))
BEGIN
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'RountinePayment'))
	BEGIN	
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('RountinePayment','Rountine Payment',1,1,2,'Account Payment Information',0,1,0,2,'Account Payment Information',1,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'BillAmount'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('BillAmount','Bill Amount',1,1,2,'Account Payment Information',1,1,0,2,'Account Payment Information',1,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'PaymentPlan'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('PaymentPlan','Payment Plan',1,1,2,'Account Payment Information',2,1,0,2,'Account Payment Information',1,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'AccountType'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('AccountType','Account Type',1,1,1,'Account Information',1,1,0,1,'Account Information',2,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'AccountClass'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('AccountClass','Account Class',1,1,1,'Account Information',3,1,0,1,'Account Information',2,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'Long1'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('Long1','Credit',1,1,1,'Account Credit',1,2,0,3,'Account Credit',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'Long2'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('Long2','Credit',1,1,2,'Account Credit',1,2,0,3,'Account Credit',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentNextAction'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('CurrentNextAction','Current Next Action',1,1,2,'Account Action',1,1,1,3,'Account Credit',3,1)
	END

	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentNextActionDate'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('CurrentNextActionDate','Current Next Action Date',1,1,2,'Account Action',2,1,0,3,'Account Credit',3,1)
	END

	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentCallResult'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('CurrentCallResult','Current Call Result',1,1,2,'Account Action',3,1,6,3,'Account Credit',3,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentCallResultDate'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('CurrentCallResultDate','Current CallResult Date',1,1,2,'Account Action',4,1,0,3,'Account Credit',3,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentReason'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('CurrentReason','Current Reason',1,1,2,'Account Action',5,1,5,3,'Account Credit',3,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentReasonDate'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('CurrentReasonDate','Current Reason Date',1,1,2,'Account Action',6,1,0,3,'Account Credit',0,1)		
    END
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_Dict]') AND type in (N'U'))
BEGIN	
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString1'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString1','Address1',1,1,1,'ClientInformation',1,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString2'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString2','Address2',1,1,1,'ClientInformation',2,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString3'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString3','Email',1,1,1,'ClientInformation',3,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString4'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString4','City',1,1,1,'ClientInformation',4,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString5'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString5','State',1,1,1,'ClientInformation',5,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString6'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString6','Zip',1,1,1,'ClientInformation',6,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString7'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString7','Country',1,1,1,'ClientInformation',7,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString8'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString8','Region',1,1,1,'ClientInformation',8,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString9'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString9','PhoneNumber',1,1,1,'ClientInformation',9,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString10'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString10','FaxNumber',1,1,1,'ClientInformation',10,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CInt1'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CInt1','Client Percent',1,1,1,'Client Percent Information',1,3,'Client Percent Information',1,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CInt2'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CInt2','Client Old Percent',1,1,1,'Client Percent Information',2,3,'Client Percent Information',1,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CInt3'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CInt3','Client Percent',1,1,1,'Client Percent Information',3,3,'Client Percent Information',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CFloat1'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CFloat1','Previous Balance',1,1,2,'Client Balance Information',1,2,'Client Balance Information',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CFloat2'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CFloat2','Previous AP Balance',1,1,2,'Client Balance Information',2,2,'Client Balance Information',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CFloat3'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CFloat3','Deduct AR Balance',1,1,2,'Client Balance Information',3,2,'Client Balance Information',0,0)
	END	
END
GO
-----ThanhNguyen---------
IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 1 AND [Value] = 'Monthly')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(1,'Monthly')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 1 AND [Value] = 'Weekly')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(1,'Weekly')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 1 AND [Value] = 'Daily')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(1,'Daily')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 1 AND [Value] = 'All')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(1,'All')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 2 AND [Value] = 'Net Client')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(2,'Net Client')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 2 AND [Value] = 'Gross Client')) 
BEGIN
	
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(2,'Gross Client')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 2 AND [Value] = 'Net - Bill Client' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(2,'Net - Bill Client')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 3 AND [Value] = 'DOS to submission Date')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(3,'DOS to submission Date')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 3 AND [Value] = 'DOS to Posting Date')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(3,'DOS to Posting Date')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 3 AND [Value] = 'Submisson Date to Posting Date')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(3,'Submisson Date to Posting Date')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 4 AND [Value] = 'Based on Payment Amount' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(4,'Based on Payment Amount')	
END


IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 4 AND [Value] = 'Based on Agency Part'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(4,'Based on Agency Part')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'Daily')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'Daily')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'Weekly' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'Weekly')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = '30 Days')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'30 Days')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'Monthly' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'Monthly')

END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'SemiMonthly')) 
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'SemiMonthly')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'BiMonthly' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'BiMonthly')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'Quarterly' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'Quarterly')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'SemiAnnually' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'SemiAnnually')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'Annually' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'Annually')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] = 5 AND [Value] = 'Custom' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(5,'Custom')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] =  6 AND [Value] = 'Simple Interest' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(6,'Simple Interest')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] =  6 AND [Value] = 'Compound Interest' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(6,'Compound Interest')
END


IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '1' AND [Description] = 'Payment' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('1','Payment','S','A')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '2' AND [Description] = 'Principal' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
VALUES('2','Principal','S','A')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '3' AND [Description] = 'Interest' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('3','Interest','S','A')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '4' AND [Description] = 'Fee' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('4','Fee','S','A')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '5' AND [Description] = 'Legal' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('5','Legal','S','A')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '6' AND [Description] = 'Misc' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('6','Misc','S','A')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '7' AND [Description] = 'Other' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('7','Other','S','A')
END


IF(NOT EXISTS(	SELECT * FROM [CWX_FinancialType]
				WHERE [Code] = '8' AND [Description] = 'Adjustment' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_FinancialType]([Code],[Description],[Type],[Status])
	VALUES('8','Adjustment','S','A')
END
GO
-----End Of ThanhNguyen-----

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '1' AND [Description] = 'Age' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('1','Age','S')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '2' AND [Description] = 'List Amount' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('2','List Amount','S')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '3' AND [Description] = 'Payment Amount' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('3','Payment Amount ','S')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '4' AND [Description] = 'Paid To Date' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('4','Paid To Date','S')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '5' AND [Description] = 'Payment Days from Listing' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('5','Payment Days from Listing','S')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '6' AND [Description] = 'Payment Days from Delinquent' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('6','Payment Days from Delinquent','S')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '7' AND [Description] = 'Payment Days from Charged' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('7','Payment Days from Charged','S')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '8' AND [Description] = 'Remaining Balance' AND [Type] = 'S'))
BEGIN	
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('8','Remaining Balance','S')
END

GO
-------------------Phuong Le--------------------------
UPDATE QueryMaster  SET SQL2 = 'EXEC SearchAccountByInvoice %1,%2,%FilterByClient' WHERE SQL2= 'EXEC SearchAccountByInvoice %1,%2'
UPDATE QueryMaster  SET SQL2 = 'EXEC CWX_Account_QueueByAmtRange %1, %2,%FilterByClient' WHERE SQL2= 'EXEC CWX_Account_QueueByAmtRange %1, %2'
UPDATE QueryMaster  SET SQL2 = 'EXEC SearchAccountByBill  %1,%2,%FilterByClient' WHERE SQL2= 'EXEC SearchAccountByBill  %1,%2'
UPDATE QueryMaster  SET SQL2 = 'EXEC CWX_Account_SearchDebtorByName %1, %2,%FilterByClient' WHERE SQL2= 'EXEC CWX_Account_SearchDebtorByName %1, %2'
UPDATE QueryMaster  SET SQL2 = 'EXEC SearchDebtorByPhone %1,%2,%FilterByClient' WHERE SQL2= 'EXEC SearchDebtorByPhone %1,%2'
UPDATE QueryMaster  SET SQL2 = 'EXEC SearchAccountByMobile %1,%2,%FilterByClient' WHERE SQL2= 'EXEC SearchAccountByMobile %1,%2'
UPDATE QueryMaster  SET SQL2 = 'EXEC SearchByofficePhone %1,%2,%FilterByClient' WHERE SQL2= 'EXEC SearchByofficePhone %1,%2'
UPDATE QueryMaster  SET SQL2 = 'EXEC CWX_Account_SearchByEmployeeName %1, %2,%FilterByClient' WHERE SQL2= 'EXEC CWX_Account_SearchByEmployeeName %1, %2'
UPDATE QueryMaster  SET SQL2 = 'EXEC SearchByLegalGroupCode %1, %2,%FilterByClient' WHERE SQL2= 'EXEC SearchByLegalGroupCode %1, %2'
UPDATE QueryMaster  SET SQL2 = 'EXEC CWX_Account_SearchByLegalEmployee %1, %2,%FilterByClient' WHERE SQL2= 'EXEC CWX_Account_SearchByLegalEmployee %1, %2'
UPDATE QueryMaster  SET SQL2 = 'EXEC CWX_Account_SearchByLegalForward  %1, %2,%FilterByClient' WHERE SQL2= 'EXEC CWX_Account_SearchByLegalForward  %1, %2'
UPDATE QueryMaster  SET SQL2 = 'EXEC CWX_Account_SearchByLegalAgent  %1, %2,%FilterByClient' WHERE SQL2= 'EXEC CWX_Account_SearchByLegalAgent  %1, %2'

GO
-----------------------------------------------------------------------------------------------------------------------
-- SMTP setting
------------------------------------------------------------------------------------------------------------------------------

-- Before setting up the Database Mail profile and accounts, we have to enable the Database Mail feature on the server.
master.dbo.sp_configure 'show advanced options',1
go
reconfigure with override
go
master.dbo.sp_configure 'Database Mail XPs',1
--go
--sp_configure 'SQL Mail XPs',0
go
reconfigure 
go
----------------------------------------------------------------------------------------------------------------------------------------------


	
	
