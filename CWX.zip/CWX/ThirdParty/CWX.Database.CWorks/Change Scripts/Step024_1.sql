-- Script is applied on version 3.0.1, 3.0.2, 3.0.3, 3.0.4, 3.0.5

-- [2008-12-02]		Minh Dam	Drop primary key QueueId from table AllocationSortMaster
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.AllocationSortMaster
	DROP CONSTRAINT PK_AllocationSortMaster
GO
COMMIT
GO


-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Dec 02, 2008
-- Description:		Add column 'RuleId' with default value '0'
-- Effected table:	AllocationSortMaster
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'AllocationSortMaster' and c.name = 'RuleId')
BEGIN
	ALTER TABLE AllocationSortMaster
	ADD RuleId int NOT NULL
		CONSTRAINT [AllocationSortMaster_RuleId] DEFAULT '0'
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_AddRemove]    Script Date: 12/02/2008 16:04:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
--	[2008-12-02]	Minh Dam		Add parameter @AccountProcessingRuleId
-- =============================================
ALTER PROCEDURE [dbo].[CWX_AllocationSortMaster_AddRemove] 
	@AccountAllocationSorts xml,
	@AccountProcessingRuleId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @tbAccountAllocationSort table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4),
		SQLFormat varchar(100),
		RuleId int
	)

	DECLARE @NewQueueID int
	DECLARE @QueueID int
	DECLARE @Description varchar(60)
	DECLARE @SQLFormat varchar(100)
	DECLARE @RuleId int

	SET @NewQueueID = 1

	DECLARE @SortID int
	IF EXISTS (SELECT QueueId FROM AllocationSortMaster WHERE sortid = 0 AND RuleId = @AccountProcessingRuleId)
		SET @SortID = 0
	ELSE
		SET @SortID = @NewQueueID

	DECLARE AccountAllocationSortCrsr CURSOR FOR
	SELECT
		ParamValues.AccountAllocationSort.value('./@AccountAllocationSortID','int') AS AccountAllocationSortID,
		ParamValues.AccountAllocationSort.value('./@Description','varchar(60)') AS Description,
		ParamValues.AccountAllocationSort.value('./@SQLFormat','varchar(100)') AS SQLFormat,
		ParamValues.AccountAllocationSort.value('./@RuleId', 'int') AS RuleId
	FROM
		@AccountAllocationSorts.nodes('/AccountAllocationSorts/AccountAllocationSort') as ParamValues(AccountAllocationSort) 

	OPEN AccountAllocationSortCrsr

	FETCH NEXT FROM AccountAllocationSortCrsr
	INTO @QueueID, @Description, @SQLFormat, @RuleId

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @SortID > 0
			SET @SortID = @NewQueueID

		IF @QueueID = 0
			INSERT INTO @tbAccountAllocationSort
			VALUES(@NewQueueID, @Description, '"' + @Description + '"', @SortID, 'ASC ', @SQLFormat, @RuleId)
		ELSE
			INSERT INTO @tbAccountAllocationSort
			SELECT
				@NewQueueID, Description, QueueColumn, @SortID, SortDirection, SQLFormat, RuleId
			FROM
				AllocationSortMaster
			WHERE
				QueueId = @QueueID AND RuleId = @RuleId
		
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM AccountAllocationSortCrsr
		INTO @QueueID, @Description, @SQLFormat, @RuleId
	END

	DELETE FROM AllocationSortMaster WHERE RuleId = @AccountProcessingRuleId
	IF( @@ERROR <> 0)
		GOTO Cleanup

	INSERT INTO AllocationSortMaster SELECT * FROM @tbAccountAllocationSort
	IF( @@ERROR <> 0)
		GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE AccountAllocationSortCrsr
	DEALLOCATE AccountAllocationSortCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_UpdateList]    Script Date: 12/02/2008 16:04:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 27th, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
--	[2008-12-02]	Minh Dam		Add parameter @AccountProcessingRuleId
-- =============================================
ALTER PROCEDURE [dbo].[CWX_AllocationSortMaster_UpdateList] 
	-- Add the parameters for the stored procedure here
	@AccountAllocationSorts xml,
	@Enabled bit,
	@AccountProcessingRuleId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @QueueID int
	DECLARE @SortDirection char(4)
	DECLARE @RuleId int

	DECLARE @NewQueueID int
	SET @NewQueueID = 1

	DECLARE @SortID int
	IF @Enabled = 1
		SET @SortID = 1
	ELSE
		SET @SortID = 0

	DECLARE @tbAccountAllocationSort table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4),
		SQLFormat varchar(100),
		RuleId int
	)

	DECLARE AccountAllocationSortCrsr CURSOR FOR
    SELECT
		ParamValues.AccountAllocationSort.value('./@AccountAllocationSortID','int') AS AccountAllocationSortID,
		ParamValues.AccountAllocationSort.value('./@SortDirection','char(4)') AS SortDirection,
		ParamValues.AccountAllocationSort.value('./@RuleId','int') AS RuleId
	FROM
		@AccountAllocationSorts.nodes('/AccountAllocationSorts/AccountAllocationSort') as ParamValues(AccountAllocationSort) 

	OPEN AccountAllocationSortCrsr

	FETCH NEXT FROM AccountAllocationSortCrsr
	INTO @QueueID, @SortDirection, @RuleId

	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO @tbAccountAllocationSort
		SELECT
			@NewQueueID, Description, QueueColumn, @SortID, @SortDirection, SQLFormat, @RuleId
		FROM
			AllocationSortMaster
		WHERE
			QueueId = @QueueID AND RuleId = @RuleId

		IF @Enabled = 1
			SET @SortID = @SortID + 1
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM AccountAllocationSortCrsr
		INTO @QueueID, @SortDirection, @RuleId
	END

	DELETE FROM AllocationSortMaster WHERE RuleId = @AccountProcessingRuleId
	IF( @@ERROR <> 0)
        GOTO Cleanup

	INSERT INTO AllocationSortMaster SELECT * FROM @tbAccountAllocationSort
	IF( @@ERROR <> 0)
        GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE AccountAllocationSortCrsr
	DEALLOCATE AccountAllocationSortCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_GetAvailable]    Script Date: 12/02/2008 16:04:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 27th, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
--	[2008-12-02]	Minh Dam		Add @AccountProcessingRuleId
-- =============================================
ALTER PROCEDURE [dbo].[CWX_AllocationSortMaster_GetAvailable] 
	@AccountProcessingRuleId int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		CASE SUBSTRING(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))), LEN(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value])))) - 1, 2)
			WHEN '_Q' THEN SUBSTRING(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))), 1, LEN(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value])))) - 2)
			ELSE LTRIM(RTRIM(CONVERT(varchar(125), ex.[value])))
		END AS [Description],
		OBJECT_NAME(c.[object_id]) + '.' + c.[name] AS SQLFormat
	INTO #Temp
	FROM
		sys.[columns] c
		LEFT OUTER JOIN sys.[extended_properties] ex ON ex.[major_id] = c.[object_id]
	WHERE
		OBJECTPROPERTY(c.[object_id], 'IsMsShipped')=0
		AND ex.[minor_id] = c.[column_id]
		AND ex.[name] = 'MS_Description'
		AND (
				OBJECT_NAME(c.[object_id]) = 'Account'
				OR OBJECT_NAME(c.[object_id]) = 'PersonInformation'
				OR OBJECT_NAME(c.[object_id]) = 'DebtorInformation'
				OR OBJECT_NAME(c.[object_id]) = 'PersonAddress'
				OR OBJECT_NAME(c.[object_id]) = 'AccountOther'
			)
		AND LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))) <> ''
	ORDER BY
		ex.[value]

	SELECT
		0 AS QueueId,
		Description,
		('"' + Description + '"') AS QueueColumn,
		0 AS sortid,
		'ASC ' AS SortDirection,
		SQLFormat
	FROM
		#Temp
	WHERE
		[Description] NOT IN (SELECT Description FROM AllocationSortMaster WHERE RuleId = @AccountProcessingRuleId)
END
GO

-- Scripts 3.0.2:

/****** Object:  StoredProcedure [dbo].[CWX_DebtorInfomation_Get]    Script Date: 12/03/2008 13:28:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInfomation_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DebtorInfomation_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInfomation_Get]    Script Date: 12/03/2008 13:28:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInfomation_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Triet Pham
-- Create date: 03/26/2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DebtorInfomation_Get]
	@DebtorID int,
	@PersonID int = 0
AS
BEGIN
	SET NOCOUNT ON;
	IF @PersonID=0
	SELECT 
		TOP 1
		DebtorID, 
		PString3, 
		DebtorInformation.PersonID, 
		CompanyName, 
		DoingBusinessAs, 
		GroupName, 
		HotNote, 
		ZipDelPoint, 
		ZipCart, 
		ReturnedMail, 
		HoldLetters, 
		HoldHomeCalls, 
		HoldWorkCalls, 
		PullCreditReport, 
		SendReminderLetters, 
		DateOfLastCreditReportPull, 
		CreditReportFileName, 
		LastEditDate, 
		LastEditBy, 
		LockedByID, 
		LockedBy, 
		PString1, 
		PString2, 
		PString4, 
		PString5, 
		PString6, 
		PString7, 
		PString8, 
		PString9, 
		PString10, 
		PString11, 
		PString12, 
		PString13, 
		PString14, 
		PString15, 
		PString16, 
		PString17, 
		PString18, 
		PString19, 
		PString20, 
		PString21, 
		PString22, 
		PString23, 
		PString24, 
		PString25, 
		PString26, 
		PString27, 
		PString28, 
		PString29, 
		PString30, 
		PString31, 
		PString32, 
		PString33, 
		PString34, 
		PString35, 
		PString36, 
		PString37, 
		PString38, 
		PString39, 
		PString40, 
		PString41, 
		PString42, 
		PString43, 
		PString44, 
		PString45,
		PMoney1, 
		PMoney2, 
		PMoney3, 
		PMoney4, 
		PMoney5, 
		PMoney6, 
		PMoney7, 
		PMoney8, 
		PMoney9, 
		PMoney10, 
		PMoney11, 
		PMoney12, 
		PMoney13, 
		PMoney14, 
		PMoney15, 
		PMoney16, 
		PMoney17, 
		PMoney18, 
		PMoney19, 
		PMoney20, 
		PMoney21, 
		PMoney22, 
		PMoney23, 
		PMoney24, 
		PMoney25, 
		PLong1, 
		PLong2, 
		PLong3, 
		PLong4, 
		PLong5, 
		PLong6, 
		PLong7, 
		PLong8, 
		PLong9, 
		PLong10, 
		PLong11, 
		PLong12, 
		PLong13, 
		PLong14, 
		PLong15, 
		PLong16, 
		PLong17, 
		PLong18, 
		PLong19, 
		PLong20,
		PLong21, 
		PLong22, 
		PLong23, 
		PLong24, 
		PLong25, 
		PLong26, 
		PLong27, 
		PLong28, 
		PLong29, 
		PLong30, 
		PLong31, 
		PLong32, 
		PLong33, 
		PLong34, 
		PLong35, 
		PLong36, 
		PLong37, 
		PLong38, 
		PLong39, 
		PLong40, 
		PLong41, 
		PLong42, 
		PLong43, 
		PLong44, 
		PLong45, 
		PLong46, 
		PLong47, 
		PLong48, 
		PLong49, 
		PLong50, 
		PString46, 
		PString47, 
		PString48, 
		PString49, 
		PString50, 
		PMoney26, 
		PMoney27, 
		PMoney28, 
		PMoney29, 
		PMoney30, 
		PMoney31, 
		PMoney32, 
		PMoney33, 
		PMoney34, 
		PMoney35, 
		PMoney36, 
		PMoney37, 
		PMoney38, 
		PMoney39, 
		PMoney40, 
		PMoney41, 
		PMoney42, 
		PMoney43, 
		PMoney44, 
		PMoney45, 
		PMoney46, 
		PMoney47, 
		PMoney48, 
		PMoney49, 
		PMoney50, 
		PDate1, 
		PDate2, 
		PDate3, 
		PDate4, 
		PDate5, 
		PDate6, 
		PDate7, 
		PDate8, 
		PDate9, 
		PDate10, 
		LastName, 
		FirstName, 
		MiddleName, 
		Suffix, 
		SocialSecurityNumber, 
		AlternateID1Name, 
		AlternateID1, 
		AlternateID2Name, 
		AlternateID2, 
		DriversLicenseNumber, 
		DateOfBirth, 
		HomePhone, 
		MobilPhone, 
		Employment, 
		EmploymentPhone, 
		EmploymentPhoneExtension, 
		Fax, 
		Email, 
		CallAfter, 
		BankRuptDate, 
		BankRuptType, 
		[Language],
		SpouseID, 
		TimeZone, 
		GMTOffset, 
		Nationality, 
		Other_Phone_Number, 
		Other_Phone_Number1, 
		Home_PO_Box, 
		Nearest_Landmark, 
		NO_Of_Years_Resi, 
		Business_Type, 
		Position, 
		Profession, 
		Department, 
		Employee_Number, 
		Title, 
		Employer_Code, 
		FriendName, 
		Friend_Off_Phone, 
		Friend_Res_Phone, 
		Friend_FaxNo,
		(SELECT COUNT(Account.AccountID) FROM Account WHERE Account.DebtorID = DebtorInformation.DebtorID) AS ACCOUNTCOUNT,
		(SELECT SUM(Account.BillBalance) FROM Account WHERE Account.DebtorID = DebtorInformation.DebtorID) AS ACCOUNTBALANCE
	FROM PersonInformation
	LEFT JOIN DebtorInformation ON DebtorInformation.PersonID = PersonInformation.PersonID
	WHERE
		DebtorInformation.DebtorID = @DebtorID
	ELSE
	SELECT 
		TOP 1
		DebtorID, 
		PString3, 
		DebtorInformation.PersonID, 
		CompanyName, 
		DoingBusinessAs, 
		GroupName, 
		HotNote, 
		ZipDelPoint, 
		ZipCart, 
		ReturnedMail, 
		HoldLetters, 
		HoldHomeCalls, 
		HoldWorkCalls, 
		PullCreditReport, 
		SendReminderLetters, 
		DateOfLastCreditReportPull, 
		CreditReportFileName, 
		LastEditDate, 
		LastEditBy, 
		LockedByID, 
		LockedBy, 
		PString1, 
		PString2, 
		PString4, 
		PString5, 
		PString6, 
		PString7, 
		PString8, 
		PString9, 
		PString10, 
		PString11, 
		PString12, 
		PString13, 
		PString14, 
		PString15, 
		PString16, 
		PString17, 
		PString18, 
		PString19, 
		PString20, 
		PString21, 
		PString22, 
		PString23, 
		PString24, 
		PString25, 
		PString26, 
		PString27, 
		PString28, 
		PString29, 
		PString30, 
		PString31, 
		PString32, 
		PString33, 
		PString34, 
		PString35, 
		PString36, 
		PString37, 
		PString38, 
		PString39, 
		PString40, 
		PString41, 
		PString42, 
		PString43, 
		PString44, 
		PString45,
		PMoney1, 
		PMoney2, 
		PMoney3, 
		PMoney4, 
		PMoney5, 
		PMoney6, 
		PMoney7, 
		PMoney8, 
		PMoney9, 
		PMoney10, 
		PMoney11, 
		PMoney12, 
		PMoney13, 
		PMoney14, 
		PMoney15, 
		PMoney16, 
		PMoney17, 
		PMoney18, 
		PMoney19, 
		PMoney20, 
		PMoney21, 
		PMoney22, 
		PMoney23, 
		PMoney24, 
		PMoney25, 
		PLong1, 
		PLong2, 
		PLong3, 
		PLong4, 
		PLong5, 
		PLong6, 
		PLong7, 
		PLong8, 
		PLong9, 
		PLong10, 
		PLong11, 
		PLong12, 
		PLong13, 
		PLong14, 
		PLong15, 
		PLong16, 
		PLong17, 
		PLong18, 
		PLong19, 
		PLong20,
		PLong21, 
		PLong22, 
		PLong23, 
		PLong24, 
		PLong25, 
		PLong26, 
		PLong27, 
		PLong28, 
		PLong29, 
		PLong30, 
		PLong31, 
		PLong32, 
		PLong33, 
		PLong34, 
		PLong35, 
		PLong36, 
		PLong37, 
		PLong38, 
		PLong39, 
		PLong40, 
		PLong41, 
		PLong42, 
		PLong43, 
		PLong44, 
		PLong45, 
		PLong46, 
		PLong47, 
		PLong48, 
		PLong49, 
		PLong50, 
		PString46, 
		PString47, 
		PString48, 
		PString49, 
		PString50, 
		PMoney26, 
		PMoney27, 
		PMoney28, 
		PMoney29, 
		PMoney30, 
		PMoney31, 
		PMoney32, 
		PMoney33, 
		PMoney34, 
		PMoney35, 
		PMoney36, 
		PMoney37, 
		PMoney38, 
		PMoney39, 
		PMoney40, 
		PMoney41, 
		PMoney42, 
		PMoney43, 
		PMoney44, 
		PMoney45, 
		PMoney46, 
		PMoney47, 
		PMoney48, 
		PMoney49, 
		PMoney50, 
		PDate1, 
		PDate2, 
		PDate3, 
		PDate4, 
		PDate5, 
		PDate6, 
		PDate7, 
		PDate8, 
		PDate9, 
		PDate10, 
		LastName, 
		FirstName, 
		MiddleName, 
		Suffix, 
		SocialSecurityNumber, 
		AlternateID1Name, 
		AlternateID1, 
		AlternateID2Name, 
		AlternateID2, 
		DriversLicenseNumber, 
		DateOfBirth, 
		HomePhone, 
		MobilPhone, 
		Employment, 
		EmploymentPhone, 
		EmploymentPhoneExtension, 
		Fax, 
		Email, 
		CallAfter, 
		BankRuptDate, 
		BankRuptType, 
		[Language],
		SpouseID, 
		TimeZone, 
		GMTOffset, 
		Nationality, 
		Other_Phone_Number, 
		Other_Phone_Number1, 
		Home_PO_Box, 
		Nearest_Landmark, 
		NO_Of_Years_Resi, 
		Business_Type, 
		Position, 
		Profession, 
		Department, 
		Employee_Number, 
		Title, 
		Employer_Code, 
		FriendName, 
		Friend_Off_Phone, 
		Friend_Res_Phone, 
		Friend_FaxNo,
		(SELECT COUNT(Account.AccountID) FROM Account WHERE Account.DebtorID = DebtorInformation.DebtorID) AS ACCOUNTCOUNT,
		(SELECT SUM(Account.BillBalance) FROM Account WHERE Account.DebtorID = DebtorInformation.DebtorID) AS ACCOUNTBALANCE
	FROM PersonInformation
	LEFT JOIN DebtorInformation ON DebtorInformation.PersonID = PersonInformation.PersonID
	WHERE
		PersonInformation.PersonID = @PersonID

	SET NOCOUNT OFF
END

' 
END
GO

-- Scripts 3.0.3:

-- =======================================================================
-- Author:			Sathya
-- Create date:		Dec 03, 2008
-- Description:		Improve performance
-- =======================================================================

if exists (select name from sys.sysindexes where name like 'IDX_BILLID')
	DROP INDEX NotesCurrent.IDX_BILLID
GO

/****** Object:  Index [IDX_DebtorID]    Script Date: 12/03/2008 12:28:31 ******/
CREATE NONCLUSTERED INDEX [IDX_BILLID] ON [dbo].[NotesCurrent] 
(
	[BillID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

GO

--========================================================
if exists (select name from sys.sysindexes where name like 'IDTYPE')
	DROP INDEX PersonPhone.IDTYPE
GO
/****** Object:  Index [IDTYPE]    Script Date: 12/03/2008 16:23:18 ******/
CREATE NONCLUSTERED INDEX [IDTYPE] ON [dbo].[PersonPhone] 
(
	[PersonID] ASC,
	[PhoneType] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = OFF) ON [PRIMARY]

--================================================
if exists (select name from sys.sysindexes where name like 'IDX_RESPONSIBLEPARTY')
	DROP INDEX AccountActions.IDX_RESPONSIBLEPARTY
GO
/****** Object:  Index [IDX_RESPONSIBLEPARTY]    Script Date: 12/03/2008 16:36:52 ******/
CREATE NONCLUSTERED INDEX [IDX_RESPONSIBLEPARTY] ON [dbo].[AccountActions] 
(
	[ResponsibleParty] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = OFF) ON [PRIMARY]

--==================================================

if exists (select name from sys.sysindexes where name like 'IDX_DEBTOR_EMPLOYEE_TYPE')
	DROP INDEX NotesCurrent.IDX_DEBTOR_EMPLOYEE_TYPE
GO
/****** Object:  Index [IDX_DEBTOR_EMPLOYEE_TYPE]    Script Date: 12/03/2008 16:45:05 ******/
CREATE NONCLUSTERED INDEX [IDX_DEBTOR_EMPLOYEE_TYPE] ON [dbo].[NotesCurrent] 
(
	[DebtorID] ASC,
	[EmployeeID] ASC,
	[NoteType] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = OFF) ON [PRIMARY]
GO

--=================================================
if exists (select name from sys.sysindexes where name like 'IDX_DEBTORID_EMPLOYEEID')
	DROP INDEX NotesCurrent.IDX_DEBTORID_EMPLOYEEID
GO
/****** Object:  Index [IDX_DEBTORID_EMPLOYEEID]    Script Date: 12/03/2008 17:25:04 ******/
CREATE NONCLUSTERED INDEX [IDX_DEBTORID_EMPLOYEEID] ON [dbo].[NotesCurrent] 
(
	[DebtorID] ASC,
	[EmployeeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = OFF) ON [PRIMARY]
--=================================================
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================
-- Author:		Triet Pham
-- Create date: 03/26/2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_DebtorInfomation_Get]
	@DebtorID int,
	@PersonID int = 0
AS
BEGIN
	SET NOCOUNT ON;

	IF @PersonID = 0
	BEGIN
		SELECT 
			TOP 1
			DebtorID, 
			PString3, 
			DebtorInformation.PersonID, 
			CompanyName, 
			DoingBusinessAs, 
			GroupName, 
			HotNote, 
			ZipDelPoint, 
			ZipCart, 
			ReturnedMail, 
			HoldLetters, 
			HoldHomeCalls, 
			HoldWorkCalls, 
			PullCreditReport, 
			SendReminderLetters, 
			DateOfLastCreditReportPull, 
			CreditReportFileName, 
			LastEditDate, 
			LastEditBy, 
			LockedByID, 
			LockedBy, 
			PString1, 
			PString2, 
			PString4, 
			PString5, 
			PString6, 
			PString7, 
			PString8, 
			PString9, 
			PString10, 
			PString11, 
			PString12, 
			PString13, 
			PString14, 
			PString15, 
			PString16, 
			PString17, 
			PString18, 
			PString19, 
			PString20, 
			PString21, 
			PString22, 
			PString23, 
			PString24, 
			PString25, 
			PString26, 
			PString27, 
			PString28, 
			PString29, 
			PString30, 
			PString31, 
			PString32, 
			PString33, 
			PString34, 
			PString35, 
			PString36, 
			PString37, 
			PString38, 
			PString39, 
			PString40, 
			PString41, 
			PString42, 
			PString43, 
			PString44, 
			PString45,
			PMoney1, 
			PMoney2, 
			PMoney3, 
			PMoney4, 
			PMoney5, 
			PMoney6, 
			PMoney7, 
			PMoney8, 
			PMoney9, 
			PMoney10, 
			PMoney11, 
			PMoney12, 
			PMoney13, 
			PMoney14, 
			PMoney15, 
			PMoney16, 
			PMoney17, 
			PMoney18, 
			PMoney19, 
			PMoney20, 
			PMoney21, 
			PMoney22, 
			PMoney23, 
			PMoney24, 
			PMoney25, 
			PLong1, 
			PLong2, 
			PLong3, 
			PLong4, 
			PLong5, 
			PLong6, 
			PLong7, 
			PLong8, 
			PLong9, 
			PLong10, 
			PLong11, 
			PLong12, 
			PLong13, 
			PLong14, 
			PLong15, 
			PLong16, 
			PLong17, 
			PLong18, 
			PLong19, 
			PLong20,
			PLong21, 
			PLong22, 
			PLong23, 
			PLong24, 
			PLong25, 
			PLong26, 
			PLong27, 
			PLong28, 
			PLong29, 
			PLong30, 
			PLong31, 
			PLong32, 
			PLong33, 
			PLong34, 
			PLong35, 
			PLong36, 
			PLong37, 
			PLong38, 
			PLong39, 
			PLong40, 
			PLong41, 
			PLong42, 
			PLong43, 
			PLong44, 
			PLong45, 
			PLong46, 
			PLong47, 
			PLong48, 
			PLong49, 
			PLong50, 
			PString46, 
			PString47, 
			PString48, 
			PString49, 
			PString50, 
			PMoney26, 
			PMoney27, 
			PMoney28, 
			PMoney29, 
			PMoney30, 
			PMoney31, 
			PMoney32, 
			PMoney33, 
			PMoney34, 
			PMoney35, 
			PMoney36, 
			PMoney37, 
			PMoney38, 
			PMoney39, 
			PMoney40, 
			PMoney41, 
			PMoney42, 
			PMoney43, 
			PMoney44, 
			PMoney45, 
			PMoney46, 
			PMoney47, 
			PMoney48, 
			PMoney49, 
			PMoney50, 
			PDate1, 
			PDate2, 
			PDate3, 
			PDate4, 
			PDate5, 
			PDate6, 
			PDate7, 
			PDate8, 
			PDate9, 
			PDate10, 
			LastName, 
			FirstName, 
			MiddleName, 
			Suffix, 
			SocialSecurityNumber, 
			AlternateID1Name, 
			AlternateID1, 
			AlternateID2Name, 
			AlternateID2, 
			DriversLicenseNumber, 
			DateOfBirth, 
			HomePhone, 
			MobilPhone, 
			Employment, 
			EmploymentPhone, 
			EmploymentPhoneExtension, 
			Fax, 
			Email, 
			CallAfter, 
			BankRuptDate, 
			BankRuptType, 
			[Language],
			SpouseID, 
			TimeZone, 
			GMTOffset, 
			Nationality, 
			Other_Phone_Number, 
			Other_Phone_Number1, 
			Home_PO_Box, 
			Nearest_Landmark, 
			NO_Of_Years_Resi, 
			Business_Type, 
			Position, 
			Profession, 
			Department, 
			Employee_Number, 
			Title, 
			Employer_Code, 
			FriendName, 
			Friend_Off_Phone, 
			Friend_Res_Phone, 
			Friend_FaxNo,
			(SELECT COUNT(Account.AccountID) FROM Account WHERE Account.DebtorID = DebtorInformation.DebtorID) AS ACCOUNTCOUNT,
			(SELECT SUM(Account.BillBalance) FROM Account WHERE Account.DebtorID = DebtorInformation.DebtorID) AS ACCOUNTBALANCE
		FROM PersonInformation
		LEFT JOIN DebtorInformation ON DebtorInformation.PersonID = PersonInformation.PersonID
		WHERE DebtorInformation.DebtorID = @DebtorID
	END
	ELSE
	BEGIN
		SELECT 
			TOP 1
			DebtorID, 
			PString3, 
			DebtorInformation.PersonID, 
			CompanyName, 
			DoingBusinessAs, 
			GroupName, 
			HotNote, 
			ZipDelPoint, 
			ZipCart, 
			ReturnedMail, 
			HoldLetters, 
			HoldHomeCalls, 
			HoldWorkCalls, 
			PullCreditReport, 
			SendReminderLetters, 
			DateOfLastCreditReportPull, 
			CreditReportFileName, 
			LastEditDate, 
			LastEditBy, 
			LockedByID, 
			LockedBy, 
			PString1, 
			PString2, 
			PString4, 
			PString5, 
			PString6, 
			PString7, 
			PString8, 
			PString9, 
			PString10, 
			PString11, 
			PString12, 
			PString13, 
			PString14, 
			PString15, 
			PString16, 
			PString17, 
			PString18, 
			PString19, 
			PString20, 
			PString21, 
			PString22, 
			PString23, 
			PString24, 
			PString25, 
			PString26, 
			PString27, 
			PString28, 
			PString29, 
			PString30, 
			PString31, 
			PString32, 
			PString33, 
			PString34, 
			PString35, 
			PString36, 
			PString37, 
			PString38, 
			PString39, 
			PString40, 
			PString41, 
			PString42, 
			PString43, 
			PString44, 
			PString45,
			PMoney1, 
			PMoney2, 
			PMoney3, 
			PMoney4, 
			PMoney5, 
			PMoney6, 
			PMoney7, 
			PMoney8, 
			PMoney9, 
			PMoney10, 
			PMoney11, 
			PMoney12, 
			PMoney13, 
			PMoney14, 
			PMoney15, 
			PMoney16, 
			PMoney17, 
			PMoney18, 
			PMoney19, 
			PMoney20, 
			PMoney21, 
			PMoney22, 
			PMoney23, 
			PMoney24, 
			PMoney25, 
			PLong1, 
			PLong2, 
			PLong3, 
			PLong4, 
			PLong5, 
			PLong6, 
			PLong7, 
			PLong8, 
			PLong9, 
			PLong10, 
			PLong11, 
			PLong12, 
			PLong13, 
			PLong14, 
			PLong15, 
			PLong16, 
			PLong17, 
			PLong18, 
			PLong19, 
			PLong20,
			PLong21, 
			PLong22, 
			PLong23, 
			PLong24, 
			PLong25, 
			PLong26, 
			PLong27, 
			PLong28, 
			PLong29, 
			PLong30, 
			PLong31, 
			PLong32, 
			PLong33, 
			PLong34, 
			PLong35, 
			PLong36, 
			PLong37, 
			PLong38, 
			PLong39, 
			PLong40, 
			PLong41, 
			PLong42, 
			PLong43, 
			PLong44, 
			PLong45, 
			PLong46, 
			PLong47, 
			PLong48, 
			PLong49, 
			PLong50, 
			PString46, 
			PString47, 
			PString48, 
			PString49, 
			PString50, 
			PMoney26, 
			PMoney27, 
			PMoney28, 
			PMoney29, 
			PMoney30, 
			PMoney31, 
			PMoney32, 
			PMoney33, 
			PMoney34, 
			PMoney35, 
			PMoney36, 
			PMoney37, 
			PMoney38, 
			PMoney39, 
			PMoney40, 
			PMoney41, 
			PMoney42, 
			PMoney43, 
			PMoney44, 
			PMoney45, 
			PMoney46, 
			PMoney47, 
			PMoney48, 
			PMoney49, 
			PMoney50, 
			PDate1, 
			PDate2, 
			PDate3, 
			PDate4, 
			PDate5, 
			PDate6, 
			PDate7, 
			PDate8, 
			PDate9, 
			PDate10, 
			LastName, 
			FirstName, 
			MiddleName, 
			Suffix, 
			SocialSecurityNumber, 
			AlternateID1Name, 
			AlternateID1, 
			AlternateID2Name, 
			AlternateID2, 
			DriversLicenseNumber, 
			DateOfBirth, 
			HomePhone, 
			MobilPhone, 
			Employment, 
			EmploymentPhone, 
			EmploymentPhoneExtension, 
			Fax, 
			Email, 
			CallAfter, 
			BankRuptDate, 
			BankRuptType, 
			[Language],
			SpouseID, 
			TimeZone, 
			GMTOffset, 
			Nationality, 
			Other_Phone_Number, 
			Other_Phone_Number1, 
			Home_PO_Box, 
			Nearest_Landmark, 
			NO_Of_Years_Resi, 
			Business_Type, 
			Position, 
			Profession, 
			Department, 
			Employee_Number, 
			Title, 
			Employer_Code, 
			FriendName, 
			Friend_Off_Phone, 
			Friend_Res_Phone, 
			Friend_FaxNo,
			(SELECT COUNT(Account.AccountID) FROM Account WHERE Account.DebtorID = DebtorInformation.DebtorID) AS ACCOUNTCOUNT,
			(SELECT SUM(Account.BillBalance) FROM Account WHERE Account.DebtorID = DebtorInformation.DebtorID) AS ACCOUNTBALANCE
		FROM PersonInformation
		LEFT JOIN DebtorInformation ON DebtorInformation.PersonID = PersonInformation.PersonID
		WHERE PersonInformation.PersonID = @PersonID
	END
	
	SET NOCOUNT OFF
END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go




-- =============================================================
-- Author:		Triet Pham
-- Create date: Mar 26th, 2008
-- Description:	Retrieve all personal addresses
-- =============================================================
ALTER PROCEDURE [dbo].[CWX_PersonAddress_Get]	
	@DebtorID int,
	@PersonID int = 0
AS
BEGIN

	SET NOCOUNT ON	
	
	DECLARE @HomeAddress1 varchar(255)
	DECLARE @HomeAddress2 varchar(255)
	DECLARE @HomeAddress3 varchar(255)
	DECLARE @HomeCity varchar(255)
	DECLARE @HomeState varchar(50)
	DECLARE @HomeZip varchar(25)
	DECLARE @HomeCountry varchar(50)
	DECLARE @HomeTerritory varchar(50)
	DECLARE @HomeRegion varchar(50)
	DECLARE @HomeMailingAddress bit

	DECLARE @PostalAddress1 varchar(255)
	DECLARE @PostalAddress2 varchar(255)
	DECLARE @PostalAddress3 varchar(255)
	DECLARE @PostalCity varchar(255)
	DECLARE @PostalState varchar(50)
	DECLARE @PostalZip varchar(25)
	DECLARE @PostalCountry varchar(50)
	DECLARE @PostalTerritory varchar(50)
	DECLARE @PostalRegion varchar(50)
	DECLARE @PostalMailingAddress bit

	DECLARE @EmploymentAddress1 varchar(255)
	DECLARE @EmploymentAddress2 varchar(255)
	DECLARE @EmploymentAddress3 varchar(255)
	DECLARE @EmploymentCity varchar(255)
	DECLARE @EmploymentState varchar(50)
	DECLARE @EmploymentZip varchar(25)
	DECLARE @EmploymentCountry varchar(50)
	DECLARE @EmploymentTerritory varchar(50)
	DECLARE @EmploymentRegion varchar(50)
	DECLARE @EmploymentMailingAddress bit

	DECLARE @OtherAddress1 varchar(255)
	DECLARE @OtherAddress2 varchar(255)
	DECLARE @OtherAddress3 varchar(255)
	DECLARE @OtherCity varchar(255)
	DECLARE @OtherState varchar(50)
	DECLARE @OtherZip varchar(25)
	DECLARE @OtherCountry varchar(50)
	DECLARE @OtherTerritory varchar(50)
	DECLARE @OtherRegion varchar(50)
	DECLARE @OtherMailingAddress bit

	if @PersonID = 0
	BEGIN
		SELECT
			@HomeAddress1 = p.Address1,
			@HomeAddress2 = p.Address2,
			@HomeAddress3 = p.Address3,
			@HomeCity = p.City,
			@HomeState = p.State,
			@HomeZip = p.Zip,
			@HomeCountry = p.Country,
			@HomeTerritory = p.Territory,
			@HomeRegion = p.Region,
			@HomeMailingAddress = p.MailingAddress
		FROM PersonAddress p 
		LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
		WHERE 
			d.DebtorID = @DebtorID
			AND p.AddressType = 1

		SELECT
			@EmploymentAddress1 = p.Address1,
			@EmploymentAddress2 = p.Address2,
			@EmploymentAddress3 = p.Address3,
			@EmploymentCity = p.City,
			@EmploymentState = p.State,
			@EmploymentZip = p.Zip,
			@EmploymentCountry = p.Country,
			@EmploymentTerritory = p.Territory,
			@EmploymentRegion = p.Region,
			@EmploymentMailingAddress = p.MailingAddress
		FROM PersonAddress p 
		LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
		WHERE 
			d.DebtorID = @DebtorID
			AND p.AddressType = 3

		SELECT
			@PostalAddress1 = p.Address1,
			@PostalAddress2 = p.Address2,
			@PostalAddress3 = p.Address3,
			@PostalCity = p.City,
			@PostalState = p.State,
			@PostalZip = p.Zip,
			@PostalCountry = p.Country,
			@PostalTerritory = p.Territory,
			@PostalRegion = p.Region,
			@PostalMailingAddress = p.MailingAddress
		FROM PersonAddress p 
		LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
		WHERE 
			d.DebtorID = @DebtorID
			AND p.AddressType = 2

		SELECT
			@OtherAddress1 = p.Address1,
			@OtherAddress2 = p.Address2,
			@OtherAddress3 = p.Address3,
			@OtherCity = p.City,
			@OtherState = p.State,
			@OtherZip = p.Zip,
			@OtherCountry = p.Country,
			@OtherTerritory = p.Territory,
			@OtherRegion = p.Region,
			@OtherMailingAddress = p.MailingAddress
		FROM PersonAddress p 
		LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
		WHERE 
			d.DebtorID = @DebtorID
			AND p.AddressType = 4
		END
	ELSE
		BEGIN
			SELECT
				@HomeAddress1 = p.Address1,
				@HomeAddress2 = p.Address2,
				@HomeAddress3 = p.Address3,
				@HomeCity = p.City,
				@HomeState = p.State,
				@HomeZip = p.Zip,
				@HomeCountry = p.Country,
				@HomeTerritory = p.Territory,
				@HomeRegion = p.Region,
				@HomeMailingAddress = p.MailingAddress
			FROM PersonAddress p 
			LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
			WHERE 
				p.PersonID = @PersonID
				AND p.AddressType = 1

			SELECT
				@EmploymentAddress1 = p.Address1,
				@EmploymentAddress2 = p.Address2,
				@EmploymentAddress3 = p.Address3,
				@EmploymentCity = p.City,
				@EmploymentState = p.State,
				@EmploymentZip = p.Zip,
				@EmploymentCountry = p.Country,
				@EmploymentTerritory = p.Territory,
				@EmploymentRegion = p.Region,
				@EmploymentMailingAddress = p.MailingAddress
			FROM PersonAddress p 
			LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
			WHERE 
				p.PersonID = @PersonID
				AND p.AddressType = 3

			SELECT
				@PostalAddress1 = p.Address1,
				@PostalAddress2 = p.Address2,
				@PostalAddress3 = p.Address3,
				@PostalCity = p.City,
				@PostalState = p.State,
				@PostalZip = p.Zip,
				@PostalCountry = p.Country,
				@PostalTerritory = p.Territory,
				@PostalRegion = p.Region,
				@PostalMailingAddress = p.MailingAddress
			FROM PersonAddress p 
			LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
			WHERE 
				p.PersonID = @PersonID
				AND p.AddressType = 2

			SELECT
				@OtherAddress1 = p.Address1,
				@OtherAddress2 = p.Address2,
				@OtherAddress3 = p.Address3,
				@OtherCity = p.City,
				@OtherState = p.State,
				@OtherZip = p.Zip,
				@OtherCountry = p.Country,
				@OtherTerritory = p.Territory,
				@OtherRegion = p.Region,
				@OtherMailingAddress = p.MailingAddress
			FROM PersonAddress p 
			LEFT JOIN DebtorInformation d ON p.PersonID = d.PersonID
			WHERE 
				p.PersonID = @PersonID
				AND p.AddressType = 4
		END

	SELECT 
		@HomeAddress1 AS HomeAddress1,
		@HomeAddress2 AS HomeAddress2,
		@HomeAddress3 AS HomeAddress3,
		@HomeCity AS HomeCity,
		@HomeState AS HomeState,
		@HomeZip AS HomeZip,
		@HomeCountry AS HomeCountry,
		@HomeTerritory AS HomeTerritory,
		@HomeRegion AS HomeRegion,
		@HomeMailingAddress AS HomeMailingAddress,

		@PostalAddress1 AS PostalAddress1,
		@PostalAddress2 AS PostalAddress2,
		@PostalAddress3 AS PostalAddress3,
		@PostalCity AS PostalCity,
		@PostalState AS PostalState,
		@PostalZip AS PostalZip,
		@PostalCountry AS PostalCountry,
		@PostalTerritory AS PostalTerritory,
		@PostalRegion AS PostalRegion,
		@PostalMailingAddress AS PostalMailingAddress,

		@EmploymentAddress1 AS EmploymentAddress1,
		@EmploymentAddress2 AS EmploymentAddress2,
		@EmploymentAddress3 AS EmploymentAddress3,
		@EmploymentCity AS EmploymentCity,
		@EmploymentState AS EmploymentState,
		@EmploymentZip AS EmploymentZip,
		@EmploymentCountry AS EmploymentCountry,
		@EmploymentTerritory AS EmploymentTerritory,
		@EmploymentRegion AS EmploymentRegion,
		@EmploymentMailingAddress AS EmploymentMailingAddress,

		@OtherAddress1 AS OtherAddress1,
		@OtherAddress2 AS OtherAddress2,
		@OtherAddress3 AS OtherAddress3,
		@OtherCity AS OtherCity,
		@OtherState AS OtherState,
		@OtherZip AS OtherZip,
		@OtherCountry AS OtherCountry,
		@OtherTerritory AS OtherTerritory,
		@OtherRegion AS OtherRegion,
		@OtherMailingAddress AS OtherMailingAddress

	SET NOCOUNT OFF
END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- =============================================================
-- Description:	Retrieve all personal phone details
-- History:
--	2008/03/26	[Triet Pham]	Init version.
--	2008/11/27	[Sathya]		Modified.
-- =============================================================
ALTER PROCEDURE [dbo].[CWX_PersonPhone_Get]	
	@DebtorID int = 0,
	@PersonID int = 0
AS
BEGIN
	SET NOCOUNT ON	
	DECLARE @TYPE1PHONENO varchar(50)
	DECLARE @TYPE1PHONEDESC varchar(255)
	DECLARE @TYPE1PHONEXT varchar(25)
	DECLARE @TYPE1PHONESTAUS smallint

	DECLARE @TYPE2PHONENO varchar(50)
	DECLARE @TYPE2PHONEDESC varchar(255)
	DECLARE @TYPE2PHONEXT varchar(25)
	DECLARE @TYPE2PHONESTAUS smallint

	DECLARE @TYPE3PHONENO varchar(50)
	DECLARE @TYPE3PHONEDESC varchar(255)
	DECLARE @TYPE3PHONEXT varchar(25)
	DECLARE @TYPE3PHONESTAUS smallint

	DECLARE @TYPE4PHONENO varchar(50)
	DECLARE @TYPE4PHONEDESC varchar(255)
	DECLARE @TYPE4PHONEXT varchar(25)
	DECLARE @TYPE4PHONESTAUS smallint

	DECLARE @TYPE5PHONENO varchar(50)
	DECLARE @TYPE5PHONEDESC varchar(255)
	DECLARE @TYPE5PHONEXT varchar(25)
	DECLARE @TYPE5PHONESTAUS smallint

	DECLARE @TYPE6PHONENO varchar(50)
	DECLARE @TYPE6PHONEDESC varchar(255)
	DECLARE @TYPE6PHONEXT varchar(25)
	DECLARE @TYPE6PHONESTAUS smallint

	DECLARE @TYPE7PHONENO varchar(50)
	DECLARE @TYPE7PHONEDESC varchar(255)
	DECLARE @TYPE7PHONEXT varchar(25)
	DECLARE @TYPE7PHONESTAUS smallint

	DECLARE @TYPE8PHONENO varchar(50)
	DECLARE @TYPE8PHONEDESC varchar(255)
	DECLARE @TYPE8PHONEXT varchar(25)
	DECLARE @TYPE8PHONESTAUS smallint

	DECLARE @TYPE9PHONENO varchar(50)
	DECLARE @TYPE9PHONEDESC varchar(255)
	DECLARE @TYPE9PHONEXT varchar(25)
	DECLARE @TYPE9PHONESTAUS smallint

	IF @PersonID = 0
	BEGIN
		SELECT 
			@TYPE1PHONENO = PhoneNumber,
			@TYPE1PHONEDESC = Description,
			@TYPE1PHONEXT = PhoneExtension,
			@TYPE1PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			d.DebtorID = @DebtorID
			AND ph.PhoneType = 1
		
		SELECT 
			@TYPE2PHONENO = PhoneNumber,
			@TYPE2PHONEDESC = Description,
			@TYPE2PHONEXT = PhoneExtension,
			@TYPE2PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			d.DebtorID = @DebtorID
			AND ph.PhoneType = 2

		SELECT 
			@TYPE3PHONENO = PhoneNumber,
			@TYPE3PHONEDESC = Description,
			@TYPE3PHONEXT = PhoneExtension,
			@TYPE3PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			d.DebtorID = @DebtorID
			AND ph.PhoneType = 3

		SELECT 
			@TYPE4PHONENO = PhoneNumber,
			@TYPE4PHONEDESC = Description,
			@TYPE4PHONEXT = PhoneExtension,
			@TYPE4PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			d.DebtorID = @DebtorID
			AND ph.PhoneType = 4

		SELECT 
			@TYPE5PHONENO = PhoneNumber,
			@TYPE5PHONEDESC = Description,
			@TYPE5PHONEXT = PhoneExtension,
			@TYPE5PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			d.DebtorID = @DebtorID
			AND ph.PhoneType = 5

		SELECT 
			@TYPE6PHONENO = PhoneNumber,
			@TYPE6PHONEDESC = Description,
			@TYPE6PHONEXT = PhoneExtension,
			@TYPE6PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			d.DebtorID = @DebtorID
			AND ph.PhoneType = 6

		SELECT 
			@TYPE7PHONENO = PhoneNumber,
			@TYPE7PHONEDESC = Description,
			@TYPE7PHONEXT = PhoneExtension,
			@TYPE7PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			d.DebtorID = @DebtorID
			AND ph.PhoneType = 7

		SELECT 
			@TYPE8PHONENO = PhoneNumber,
			@TYPE8PHONEDESC = Description,
			@TYPE8PHONEXT = PhoneExtension,
			@TYPE8PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			d.DebtorID = @DebtorID
			AND ph.PhoneType = 8

		SELECT 
			@TYPE9PHONENO = PhoneNumber,
			@TYPE9PHONEDESC = Description,
			@TYPE9PHONEXT = PhoneExtension,
			@TYPE9PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			d.DebtorID = @DebtorID
			AND ph.PhoneType = 9
	END
	ELSE
	BEGIN
		SELECT 
			@TYPE1PHONENO = PhoneNumber,
			@TYPE1PHONEDESC = Description,
			@TYPE1PHONEXT = PhoneExtension,
			@TYPE1PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			ph.PersonID = @PersonID
			AND ph.PhoneType = 1
		
		SELECT 
			@TYPE2PHONENO = PhoneNumber,
			@TYPE2PHONEDESC = Description,
			@TYPE2PHONEXT = PhoneExtension,
			@TYPE2PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			ph.PersonID = @PersonID
			AND ph.PhoneType = 2

		SELECT 
			@TYPE3PHONENO = PhoneNumber,
			@TYPE3PHONEDESC = Description,
			@TYPE3PHONEXT = PhoneExtension,
			@TYPE3PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			ph.PersonID = @PersonID
			AND ph.PhoneType = 3

		SELECT 
			@TYPE4PHONENO = PhoneNumber,
			@TYPE4PHONEDESC = Description,
			@TYPE4PHONEXT = PhoneExtension,
			@TYPE4PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			ph.PersonID = @PersonID
			AND ph.PhoneType = 4

		SELECT 
			@TYPE5PHONENO = PhoneNumber,
			@TYPE5PHONEDESC = Description,
			@TYPE5PHONEXT = PhoneExtension,
			@TYPE5PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			ph.PersonID = @PersonID
			AND ph.PhoneType = 5

		SELECT 
			@TYPE6PHONENO = PhoneNumber,
			@TYPE6PHONEDESC = Description,
			@TYPE6PHONEXT = PhoneExtension,
			@TYPE6PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			ph.PersonID = @PersonID
			AND ph.PhoneType = 6

		SELECT 
			@TYPE7PHONENO = PhoneNumber,
			@TYPE7PHONEDESC = Description,
			@TYPE7PHONEXT = PhoneExtension,
			@TYPE7PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			ph.PersonID = @PersonID
			AND ph.PhoneType = 7

		SELECT 
			@TYPE8PHONENO = PhoneNumber,
			@TYPE8PHONEDESC = Description,
			@TYPE8PHONEXT = PhoneExtension,
			@TYPE8PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			ph.PersonID = @PersonID
			AND ph.PhoneType = 8

		SELECT 
			@TYPE9PHONENO = PhoneNumber,
			@TYPE9PHONEDESC = Description,
			@TYPE9PHONEXT = PhoneExtension,
			@TYPE9PHONESTAUS = PhoneStatus
		FROM PersonPhone AS ph
		LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
		WHERE
			ph.PersonID = @PersonID
			AND ph.PhoneType = 9
	END

	SELECT
		@TYPE1PHONENO AS TYPE1PHONENO,
		@TYPE1PHONEDESC AS TYPE1PHONEDESC,
		@TYPE1PHONEXT AS TYPE1PHONEXT,
		@TYPE1PHONESTAUS AS TYPE1PHONESTAUS,
		@TYPE2PHONENO AS TYPE2PHONENO,
		@TYPE2PHONEDESC AS TYPE2PHONEDESC,
		@TYPE2PHONEXT AS TYPE2PHONEXT,
		@TYPE2PHONESTAUS AS TYPE2PHONESTAUS, 
		@TYPE3PHONENO AS TYPE3PHONENO,
		@TYPE3PHONEDESC AS TYPE3PHONEDESC,
		@TYPE3PHONEXT AS TYPE3PHONEXT,
		@TYPE3PHONESTAUS AS TYPE3PHONESTAUS, 
		@TYPE4PHONENO AS TYPE4PHONENO,
		@TYPE4PHONEDESC AS TYPE4PHONEDESC,
		@TYPE4PHONEXT AS TYPE4PHONEXT,
		@TYPE4PHONESTAUS AS TYPE4PHONESTAUS, 
		@TYPE5PHONENO AS TYPE5PHONENO,
		@TYPE5PHONEDESC AS TYPE5PHONEDESC,
		@TYPE5PHONEXT AS TYPE5PHONEXT, 
		@TYPE5PHONESTAUS AS TYPE5PHONESTAUS,
		@TYPE6PHONENO AS TYPE6PHONENO,
		@TYPE6PHONEDESC AS TYPE6PHONEDESC,
		@TYPE6PHONEXT AS TYPE6PHONEXT,
		@TYPE6PHONESTAUS AS TYPE6PHONESTAUS, 
		@TYPE7PHONENO AS TYPE7PHONENO,
		@TYPE7PHONEDESC AS TYPE7PHONEDESC,
		@TYPE7PHONEXT AS TYPE7PHONEXT, 
		@TYPE7PHONESTAUS AS TYPE7PHONESTAUS,
		@TYPE8PHONENO AS TYPE8PHONENO,
		@TYPE8PHONEDESC AS TYPE8PHONEDESC,
		@TYPE8PHONEXT AS TYPE8PHONEXT,
		@TYPE8PHONESTAUS AS TYPE8PHONESTAUS, 
		@TYPE9PHONENO AS TYPE9PHONENO,
		@TYPE9PHONEDESC AS TYPE9PHONEDESC,
		@TYPE9PHONEXT AS TYPE9PHONEXT,
		@TYPE9PHONESTAUS AS TYPE9PHONESTAUS 
END

GO
--End of Sathya script

-- Scripts 3.0.4:
IF NOT EXISTS (SELECT * FROM IdentityFields WHERE TableName = 'ChkDownPmtGTTotalAmount')
INSERT INTO IdentityFields VALUES ('ChkDownPmtGTTotalAmount', 1)

IF NOT EXISTS (SELECT * FROM IdentityFields WHERE TableName = 'BillBalanceWhenLTDownPayment')
INSERT INTO IdentityFields VALUES ('BillBalanceWhenLTDownPayment', 1)


-- Scripts 3.0.5:
-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Dec 04, 2008
-- Description:		Drop column 'RuleId'
-- Effected table:	QueueSortMaster
-- =======================================================================
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'QueueSortMaster' and c.name = 'RuleId')
BEGIN
	BEGIN TRANSACTION
	SET QUOTED_IDENTIFIER ON
	SET ARITHABORT ON
	SET NUMERIC_ROUNDABORT OFF
	SET CONCAT_NULL_YIELDS_NULL ON
	SET ANSI_NULLS ON
	SET ANSI_PADDING ON
	SET ANSI_WARNINGS ON
	COMMIT
	BEGIN TRANSACTION
	
	ALTER TABLE dbo.QueueSortMaster
		DROP CONSTRAINT QueueSortMaster_RuleId
	
	ALTER TABLE dbo.QueueSortMaster
		DROP COLUMN RuleId

	COMMIT
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_AddRemove]    Script Date: 12/04/2008 16:37:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
-- =============================================
ALTER PROCEDURE [dbo].[CWX_QueueSortMaster_AddRemove] 
	@QueuePriorities xml
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @tbQueuePriority table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4)
	)

	DECLARE @NewQueueID int
	SET @NewQueueID = 1

	DECLARE @QueueID int
	DECLARE @Description varchar(60)

	DECLARE @SortID int
	IF EXISTS (SELECT QueueId FROM QueueSortMaster WHERE sortid = 0)
		SET @SortID = 0
	ELSE
		SET @SortID = @NewQueueID

	DECLARE QueuePriorityCrsr CURSOR FOR
	SELECT
		ParamValues.QueuePriority.value('./@QueueID','int') AS QueueID,
		ParamValues.QueuePriority.value('./@Description','varchar(60)') AS Description
	FROM
		@QueuePriorities.nodes('/QueuePriorities/QueuePriority') as ParamValues(QueuePriority) 

	OPEN QueuePriorityCrsr

	FETCH NEXT FROM QueuePriorityCrsr
	INTO @QueueID, @Description

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @SortID > 0
			SET @SortID = @NewQueueID

		IF @QueueID = 0
			INSERT INTO @tbQueuePriority
			VALUES(@NewQueueID, @Description, '"' + @Description + '"', @SortID, 'ASC ')
		ELSE
			INSERT INTO @tbQueuePriority
			SELECT
				@NewQueueID, Description, QueueColumn, @SortID, SortDirection
			FROM
				QueueSortMaster
			WHERE
				QueueId = @QueueID
		
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM QueuePriorityCrsr
		INTO @QueueID, @Description
	END

	DELETE FROM QueueSortMaster
	IF( @@ERROR <> 0)
		GOTO Cleanup

	INSERT INTO QueueSortMaster SELECT * FROM @tbQueuePriority
	IF( @@ERROR <> 0)
		GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE QueuePriorityCrsr
	DEALLOCATE QueuePriorityCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END
GO


/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_GetAvailable]    Script Date: 12/04/2008 16:39:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
-- =============================================
ALTER PROCEDURE [dbo].[CWX_QueueSortMaster_GetAvailable] 

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		[DESCRIPTION] = SUBSTRING(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))), 1, LEN(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value])))) - 2)
	INTO #Temp
	FROM
		sys.[columns] c
		LEFT OUTER JOIN sys.[extended_properties] ex ON ex.[major_id] = c.[object_id]
	WHERE
		OBJECTPROPERTY(c.[object_id], 'IsMsShipped')=0
		AND ex.[minor_id] = c.[column_id]
		AND ex.[name] = 'MS_Description'
		AND (
				OBJECT_NAME(c.[object_id]) = 'Account'
				OR OBJECT_NAME(c.[object_id]) = 'Accountother'
				OR OBJECT_NAME(c.[object_id]) = 'DebtorInformation'
				OR OBJECT_NAME(c.[object_id]) = 'PersonInformation'
				OR OBJECT_NAME(c.[object_id]) = 'AccountStatus'
			)
		AND LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))) LIKE '%_Q'
	ORDER BY
		[Description]

	SELECT
		0 AS QueueId,
		Description,
		('"' + Description + '"') AS QueueColumn,
		0 AS sortid,
		'ASC ' AS SortDirection
	FROM
		#Temp
	WHERE
		[Description] NOT IN (SELECT Description FROM QueueSortMaster)
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_UpdateList]    Script Date: 12/04/2008 16:40:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
-- =============================================
ALTER PROCEDURE [dbo].[CWX_QueueSortMaster_UpdateList] 
	@QueuePriorities xml,
	@Enabled bit
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @QueueID int
	DECLARE @SortDirection char(4)
	DECLARE @SortID int

	IF @Enabled = 1
		SET @SortID = 1
	ELSE
		SET @SortID = 0

	DECLARE @tbQueuePriority table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4)
	)

	DECLARE @NewQueueID int
	SET @NewQueueID = 1

	DECLARE QueuePriorityCrsr CURSOR FOR
	SELECT
		ParamValues.QueuePriority.value('./@QueueID','int') AS QueueID,
		ParamValues.QueuePriority.value('./@SortDirection','char(4)') AS SortDirection
	FROM
		@QueuePriorities.nodes('/QueuePriorities/QueuePriority') as ParamValues(QueuePriority)

	OPEN QueuePriorityCrsr

	FETCH NEXT FROM QueuePriorityCrsr
	INTO @QueueID, @SortDirection

	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO @tbQueuePriority
		SELECT
			@NewQueueID, Description, QueueColumn, @SortID, @SortDirection
		FROM
			QueueSortMaster
		WHERE
			QueueId = @QueueID

		IF @Enabled = 1
			SET @SortID = @SortID + 1
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM QueuePriorityCrsr
		INTO @QueueID, @SortDirection
	END

	DELETE FROM QueueSortMaster
	IF( @@ERROR <> 0)
        GOTO Cleanup

	INSERT INTO QueueSortMaster SELECT * FROM @tbQueuePriority
	IF( @@ERROR <> 0)
        GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE QueuePriorityCrsr
	DEALLOCATE QueuePriorityCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END
GO


/****** Object:  StoredProcedure [dbo].[CW_SORT_ORDER]    Script Date: 12/04/2008 16:32:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/******   Script Date: 2005/07/15  ******/
ALTER Procedure [dbo].[CW_SORT_ORDER](@v_SortOrder VarChar(700) OUT) As
BEGIN
    Declare @SortCur Cursor , @v_Description VarChar(700)
    Set @SortCur=Cursor For Select QueueColumn +  ' ' + Rtrim(Ltrim(SortDirection) )+ ',' Description  
			      From QueueSortMaster 
			     Where SortId<>0 Order By SortId
    Set @v_SortOrder=''
    Open @SortCur
    Fetch Next From @SortCur Into @v_Description
    While @@Fetch_Status=0 
    Begin
        Set @v_SortOrder=@v_SortOrder+@v_Description
	Fetch Next From @SortCur Into @v_Description
    End
    If @v_SortOrder<>''
    Begin
       Set @v_SortOrder=SubString(@v_SortOrder,1,Len(LTrim(RTrim(@v_SortOrder)))-1)
    End
    Close @SortCur
    DeAllocate @SortCur
END
GO

--Add setting to show/hide CMS Progress bar
IF NOT EXISTS (SELECT TableName FROM IdentityFields WHERE TableName='CMSProgressBar')
	INSERT INTO IdentityFields VALUES('CMSProgressBar', 1)
GO

-- Script Closed.