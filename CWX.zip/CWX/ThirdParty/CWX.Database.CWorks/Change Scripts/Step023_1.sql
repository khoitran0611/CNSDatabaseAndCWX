-- Script is applied on version 2.9.1, 2.9.2, 2.9.3, 2.9.4, 2.9.5, 2.9.6, 2.9.8, 2.9.9, 2.9.10, 2.9.11, 2.9.12, 2.9.13, 2.9.14, 2.9.15, 2.9.16, 2.9.17, 2.9.19, 2.9.20, 2.9.22, 2.9.23

-- Scripts 2.9.1:

UPDATE CosigneeInformation SET Relationship_Type=NULL
GO

ALTER TABLE CosigneeInformation
	ALTER COLUMN Relationship_Type int NULL
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 11/04/2008 11:57:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 11/04/2008 11:57:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debtors with Account No. and Customer 's fullName
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate], r.Description AS [RelationshipType], a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[DefendantNum], a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				LEFT JOIN PersonInformation p ON a.PersonID = p.PersonID
				LEFT JOIN Account b ON a.AccountID = b.AccountID
				LEFT JOIN CosigneeInformation g ON g.PersonID = a.PersonID AND g.Bill = b.AccountID
				LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE a.GroupID = @groupID
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	ELSE
	BEGIN
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,r.Description AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum], isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
				LEFT JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
				LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate], r.Description AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
			LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID)
		
		ORDER BY Seq, b.AccountID, FullName
	END
END
GO

-- Scripts 2.9.2:

/****** Object:  StoredProcedure [dbo].[CWX_TransactionType_GetCustom]    Script Date: 11/05/2008 11:33:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionType_GetCustom]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TransactionType_GetCustom]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TransactionType_GetCustom]    Script Date: 11/05/2008 11:33:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionType_GetCustom]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get transaction type where AffectBalance are Increase or NoEffect.
-- History:
--	2008/11/05	[Binh Truong]	Init version.
-- =============================================
create PROCEDURE [dbo].[CWX_TransactionType_GetCustom]
AS
BEGIN
	SET NOCOUNT ON
	SELECT  TransactionType.*
	FROM    TransactionType
	WHERE   (Status <> ''R'') AND
			(AffectBalance = 1 OR AffectBalance = 0)			
END' 
END
GO

-- Scripts 2.9.3:

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 11/06/2008 11:26:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 11/06/2008 11:26:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debtors with Account No. and Customer 's fullName
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate], ISNULL(r.Description, 'Debtor') AS [RelationshipType], a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[DefendantNum], a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				LEFT JOIN PersonInformation p ON a.PersonID = p.PersonID
				LEFT JOIN Account b ON a.AccountID = b.AccountID
				LEFT JOIN CosigneeInformation g ON g.PersonID = a.PersonID AND g.Bill = b.AccountID
				LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE a.GroupID = @groupID
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	ELSE
	BEGIN
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,'Debtor' AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum], isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
				LEFT JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
				--LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate], r.Description AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
			LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID)
		
		ORDER BY Seq, b.AccountID, FullName
	END
END
GO


-- Scripts 2.9.4:

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 11/06/2008 17:06:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 11/06/2008 17:06:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debtors with Account No. and Customer 's fullName
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
	BEGIN
		DECLARE @PersonID int
		SELECT @PersonID=d.PersonID
		FROM DebtorInformation d
		LEFT JOIN CosigneeInformation c ON c.PersonID = d.PersonID
		WHERE d.DebtorID=@debtorID-- AND c.Relationship_Type IS NULL

		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate]
				, CASE a.PersonID WHEN @PersonID THEN 'Debtor' ELSE r.Description END AS [RelationshipType]
				, a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[DefendantNum], a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				LEFT JOIN PersonInformation p ON a.PersonID = p.PersonID
				LEFT JOIN Account b ON a.AccountID = b.AccountID
				LEFT JOIN CosigneeInformation g ON g.PersonID = a.PersonID AND g.Bill = b.AccountID
				LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE a.GroupID = @groupID
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	END
	ELSE
	BEGIN
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,'Debtor' AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum], isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
				LEFT JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
				--LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate], r.Description AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
			LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID)
		
		ORDER BY Seq, b.AccountID, FullName
	END
END

GO


/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_Get]    Script Date: 11/07/2008 15:08:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProductSetting_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_Get]    Script Date: 11/07/2008 15:08:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- ===================================================================================
-- Description:	Get product setting
-- History:
--	2008/11/07	[Binh Truong]	Init version.
-- ===================================================================================
CREATE PROCEDURE [dbo].[CWX_ProductSetting_Get] 
	@ProductID int, 
	@InfoSubType int, -- SettingProductType
	@Bucket varchar(50) -- Bucket
AS
BEGIN
	SET NOCOUNT ON
		
	DECLARE @ProductInfo int
	DECLARE @strMaxBucket varchar(50)
	DECLARE @MaxBucket int
	
	SET @ProductInfo = 6 -- Code for product setting
	
	SELECT  TOP(1) @strMaxBucket=InfoKey
	FROM	InformationTable
	WHERE	InfoID = @ProductInfo AND 
			InfoKey LIKE ''%+''
	
	IF @strMaxBucket IS NULL
	BEGIN
		SELECT  @MaxBucket=MAX(InfoKey)
		FROM	InformationTable
		WHERE	InfoID = @ProductInfo
	END
	ELSE
	BEGIN
		SET @MaxBucket = CAST(REPLACE(@strMaxBucket, ''+'', '''') AS int)
	END
	
	IF @Bucket > @MaxBucket
		SET @Bucket = @strMaxBucket
	
	SELECT  InformationTable.*
	FROM    InformationTable
	WHERE	(InfoID = @ProductInfo) AND 
			(InfoKey = @Bucket) AND 
			(InfoType = @ProductID) AND
			InfoSubType = @InfoSubType
					
END
' 
END
GO

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
EXECUTE sp_unbindefault N'dbo.NotesCurrent.SequenceID'
GO
ALTER TABLE dbo.NotesCurrent
	DROP COLUMN SequenceID
GO
COMMIT

/****** Object:  StoredProcedure [dbo].[CWX_Account_ChangeAccountStatus]    Script Date: 11/07/2008 15:27:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ChangeAccountStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_ChangeAccountStatus]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ChangeQueueDay]    Script Date: 11/07/2008 15:27:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ChangeQueueDay]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_ChangeQueueDay]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_MaintainDelinquencyOfficer]    Script Date: 11/07/2008 15:27:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_MaintainDelinquencyOfficer]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_MaintainDelinquencyOfficer]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ReferToEmployee]    Script Date: 11/07/2008 15:27:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ReferToEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_ReferToEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_TemporaryReassign]    Script Date: 11/07/2008 15:27:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_TemporaryReassign]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_TemporaryReassign]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_PermanentReassign]    Script Date: 11/07/2008 15:27:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_PermanentReassign]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_PermanentReassign]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ChangeAccountStatus]    Script Date: 11/07/2008 15:27:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ChangeAccountStatus]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE PROCEDURE [dbo].[CWX_Account_ChangeAccountStatus] 
	@AgencyStatusID int,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, ''|'')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @StatusDesc varchar(10)		

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				AgencyStatusID = @AgencyStatusID
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID
			
			SELECT @StatusDesc = ShortDesc FROM AccountStatus WHERE AgencyStatus = @AgencyStatusID
			SET @NoteText = ''AcctMgmt: Status Change to '' + @StatusDesc
			
			INSERT INTO NotesCurrent
			VALUES(@CurrentUserID, @DebtorID, @AccountID, GETDATE(), ''A'', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ChangeQueueDay]    Script Date: 11/07/2008 15:27:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ChangeQueueDay]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 01, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_ChangeQueueDay] 
	-- Add the parameters for the stored procedure here
	@QueueDay int = 0,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, ''|'')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				QueueDate = DATEADD(day, @QueueDay, GETDATE())
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SET @NoteText = ''AcctMgmt: Queue Date Changed; '' + CAST(@QueueDay AS varchar(5)) + ''  Queue Days Added ''

			INSERT INTO NotesCurrent
			VALUES(@CurrentUserID, @DebtorID, @AccountID, GETDATE(), ''A'', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_MaintainDelinquencyOfficer]    Script Date: 11/07/2008 15:27:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_MaintainDelinquencyOfficer]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Binh Truong
-- Create date: April 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_MaintainDelinquencyOfficer] 
	-- Add the parameters for the stored procedure here
	@MaintainOfficer bit,
	@AccountIDs varchar(8000),
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, ''|'')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				MaintainOfficer = @MaintainOfficer
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SET @NoteText = ''AcctMgmt: Maintain Delinquency Officer ''
			IF @MaintainOfficer = 0
				SET @NoteText = @NoteText + ''unchecked''
			ELSE
				SET @NoteText = @NoteText + ''checked''

			INSERT INTO NotesCurrent
			VALUES(@CurrentUserID, @DebtorID, @AccountID, GETDATE(), ''A'', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ReferToEmployee]    Script Date: 11/07/2008 15:27:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ReferToEmployee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE PROCEDURE [dbo].[CWX_Account_ReferToEmployee]
	@EmployeeID int,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, ''|'')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				ActionEmployee = @EmployeeID
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @EmployeeID
			SET @NoteText = ''AcctMgmt: Refer to '' + cast(@EmployeeID as varchar)
			
			INSERT INTO NotesCurrent
			VALUES(@CurrentUserID, @DebtorID, @AccountID, GETDATE(), ''A'', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_TemporaryReassign]    Script Date: 11/07/2008 15:27:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_TemporaryReassign]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 27, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_TemporaryReassign] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, ''|'')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				AssignmentType = ''T'',
				TempEmployeeID = @EmployeeID
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @EmployeeID
			SET @NoteText = ''AcctMgmt: Temporary Reassignment To '' + cast(@EmployeeID as varchar)
			
			INSERT INTO NotesCurrent
			VALUES(@CurrentUserID, @DebtorID, @AccountID, GETDATE(), ''A'', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_PermanentReassign]    Script Date: 11/07/2008 15:27:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_PermanentReassign]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 27, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_PermanentReassign] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@MaintainOfficer bit = 0,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, ''|'')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				AssignmentType = ''P'',
				EmployeeID = @EmployeeID,
				MaintainOfficer = @MaintainOfficer
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @CurrentUserID
			SET @NoteText = ''AcctMgmt: Permanent Reassignment to '' + cast(@CurrentUserID as varchar) + '' with MaintainOfficer ''
			IF @MaintainOfficer = 0
				SET @NoteText = @NoteText + ''unchecked''
			ELSE
				SET @NoteText = @NoteText + ''checked''

			INSERT INTO NotesCurrent
			VALUES(@CurrentUserID, @DebtorID, @AccountID, GETDATE(), ''A'', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END

' 
END
GO

-- Scripts 2.9.5:

/****** Object:  StoredProcedure [dbo].[CWX_TransactionType_GetCustom]    Script Date: 11/07/2008 17:21:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionType_GetCustom]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TransactionType_GetCustom]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TransactionType_GetCustom]    Script Date: 11/07/2008 17:21:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionType_GetCustom]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get transaction type where AffectBalance are Increase or NoEffect.
-- History:
--	2008/11/05	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TransactionType_GetCustom]
AS
BEGIN
	SET NOCOUNT ON
	SELECT		*
	FROM		TransactionType
	WHERE		(Status <> ''R'') AND 
				(AffectBalance = 1 OR AffectBalance = 0)
	ORDER BY	TransactionCode	
END' 
END
GO

-- Scripts 2.9.7:

ALTER TABLE dbo.Legal_Hearings
	DROP COLUMN Attendant
GO

ALTER TABLE dbo.Legal_Hearings
	ADD LegalAgentID int NULL
GO

-- Scripts 2.9.8:

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 11/11/2008 11:17:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetList]    Script Date: 11/11/2008 11:17:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 11/11/2008 11:17:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-14
-- Description:	Get the list of Groups of selecting customer
-- History:	2008-07-14	[Thao Nguyen]	Init version.
--			2008-10-23	[Minh Dam]		Add new parameter AccountID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
	-- Add the parameters for the stored procedure here
	@DebtorID int,
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int

	SELECT
		ROW_NUMBER() OVER (ORDER BY G.Code) AS RowNumber,
		G.*	
	INTO #Temp
	FROM (SELECT DISTINCT
		a.GroupID,
		a.Code,
		a.[Description],
		ISNULL(a.GroupedAccountID, 0) AS GroupedAccountID,
		Case When d.GroupID is not null then 1 else 0 end HasStep
		FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
			LEFT JOIN Account c ON b.AccountID = c.AccountID
			LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> ''R'') d ON a.GroupID = d.GroupID
		WHERE
			a.Status <> ''R''
			AND c.DebtorID = @DebtorID 
			AND ((a.GroupedAccountID = @AccountID) OR (b.AccountID = @AccountID AND b.IsInclude = 1))) G

	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
	
END




' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetList]    Script Date: 11/11/2008 11:17:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-18
-- Description:	Get all Legal Group by Debtor
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetList] 
	-- Add the parameters for the stored procedure here
	@DebtorID int,
	@AccountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT a.*
	FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebtors b ON a.GroupID = b.GroupID AND DebtorID is not NULL
			LEFT JOIN Legal_GroupDebts b2 ON a.GroupID = b2.GroupID
	WHERE
		a.Status <> ''R''
		AND b.DebtorID = @DebtorID
		AND ((a.GroupedAccountID = @AccountID) OR (b.AccountID = @AccountID AND b.IsInclude = 1))
	ORDER BY Code, [Description]
END

' 
END
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 24, 2008
-- Description:	Retrieve records that match the rulecriterias of a rule
-- History:
--	[24-03-2008]	Long Nguyen		Init version.
--	[11-11-2008]	Minh Dam		Add parameters @SortField and @SortDir
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 11/11/2008 13:36:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[CWX_Account_GetListByRule] 
	-- Add the parameters for the stored procedure here
	@RuleID int,
	@ProcessedAccountIDs varchar(4000) = NULL,
	@SortField varchar(100) = 'AccountId',
	@SortDir varchar(4) = 'ASC',
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	Set @orderByClause = ' ORDER BY ' + @SortField + ' ' + @SortDir


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat, Combining
		FROM RuleCriteria
		WHERE RuleID = @RuleID

	DECLARE @SQLFormat varchar(700)
	DECLARE @Combining varchar(10)
	DECLARE @NeedCombining varchar(10)
	DECLARE @WhereClause varchar(2000)
	DECLARE @IsOpenningBracket bit
	SET @NeedCombining = 'And'
	SET @WhereClause = ''
	SET @IsOpenningBracket = 0

	OPEN RuleCriteriaCrsr
	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF (LOWER(@Combining) = 'or')
			IF (@IsOpenningBracket = 0)
			BEGIN
				SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' (' + @SQLFormat
				SET @IsOpenningBracket = 1
			END
			ELSE
				SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' ' + @SQLFormat
		ELSE
		BEGIN
			SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' ' + @SQLFormat			
			IF (@IsOpenningBracket = 1)
			BEGIN
				SET @WhereClause = @WhereClause + ') '
				SET @IsOpenningBracket = 0
			END
		END

		SET @NeedCombining = @Combining /* remember previous value */
		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	END

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr

	--Remove the Account that was processed
	IF @ProcessedAccountIDs IS NOT NULL AND @ProcessedAccountIDs <> ''
	BEGIN
		SELECT CAST(SplitedText AS int) AS AccountID
		INTO #ProcessedAccountIDs
		FROM CWX_FnSplitString(@ProcessedAccountIDs, '|')

		SET @WhereClause = @WhereClause + ' AND Account.AccountId NOT IN (SELECT AccountID FROM #ProcessedAccountIDs)'
	END

	--This is used for AllocationRule, if RuleType=1, append condition <Account.MAINTAINOFFICER = 0>
	DECLARE @RuleType tinyint
	SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID
	IF @RuleType = 1
		SET @WhereClause = ' AND Account.MAINTAINOFFICER = 0' + @WhereClause

	DECLARE @Sql varchar(8000)
	SET @Sql = ' SELECT'
				+ ' Account.AccountId,Account.DebtorId,PersonInformation.FirstName,PersonInformation.MiddleName,PersonInformation.LastName,Account.BillBalance,Account.BillAmount,Account.InvoiceNumber'
				+ ' FROM Account'
				+ ' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID'
				+ ' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID'
				+ ' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID'
				+ ' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID'
				+ ' WHERE (PersonAddress.MailingAddress = 1)'
				+ ' AND Account.AgencyStatusID <> 2'-- Donot show closed account
				+ @WhereClause


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT * '
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @Sql)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @Sql)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetList]    Script Date: 11/12/2008 14:20:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 11/12/2008 14:20:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_IsGroupedAccount]    Script Date: 11/12/2008 14:20:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_IsGroupedAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_IsGroupedAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetList]    Script Date: 11/12/2008 14:20:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-18
-- Description:	Get all Legal Group by Debtor
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetList] 
	-- Add the parameters for the stored procedure here
	@DebtorID int,
	@AccountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT DISTINCT a.*
	FROM Legal_Groups a
		LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
		LEFT JOIN Account c ON b.AccountID = c.AccountID
	WHERE
		a.Status <> ''R''
		AND c.DebtorID = @DebtorID 
		AND ((a.GroupedAccountID = @AccountID) OR (b.AccountID = @AccountID AND b.IsInclude = 1))
	ORDER BY Code, [Description]
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 11/12/2008 14:20:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-14
-- Description:	Get the list of Groups of selecting customer
-- History:	2008-07-14	[Thao Nguyen]	Init version.
--			2008-10-23	[Minh Dam]		Add new parameter AccountID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
	-- Add the parameters for the stored procedure here
	@DebtorID int,
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int

	SELECT
		ROW_NUMBER() OVER (ORDER BY G.Code) AS RowNumber,
		G.*	
	INTO #Temp
	FROM (SELECT DISTINCT
		a.GroupID,
		a.Code,
		a.[Description],
		ISNULL(a.GroupedAccountID, 0) AS GroupedAccountID,
		Case When d.GroupID is not null then 1 else 0 end HasStep
		FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
			LEFT JOIN Account c ON b.AccountID = c.AccountID
			LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> ''R'') d ON a.GroupID = d.GroupID
		WHERE
			a.Status <> ''R''
			AND c.DebtorID = @DebtorID 
			AND ((a.GroupedAccountID = @AccountID) OR (b.AccountID = @AccountID AND b.IsInclude = 1))) G

	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_IsGroupedAccount]    Script Date: 11/12/2008 14:20:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_IsGroupedAccount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

CREATE PROCEDURE [dbo].[CWX_Account_IsGroupedAccount]
	-- Add the parameters for the stored procedure here
	@AccountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	IF EXISTS(	SELECT *
				FROM Legal_GroupDebts a
					INNER JOIN Legal_Groups b ON a.GroupID = b.GroupID
				WHERE b.Status <> ''R'' AND a.AccountID = @AccountID AND a.IsInclude = 1 AND b.GroupedAccountID <> @AccountID )
		RETURN 1
	ELSE
		RETURN 0
END
' 
END
GO

ALTER TABLE Legal_GroupSteps ADD
	SolicitorID int NULL
GO

ALTER TABLE Legal_Snapshots ADD
	SolicitorID int NULL
GO

-- Scripts 2.9.9:

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtList]    Script Date: 11/13/2008 17:05:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtList]    Script Date: 11/13/2008 17:05:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debts with Account No.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@AccountID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    IF @groupID <> 0
		SELECT [GroupDebtID],a.[GroupID],a.[AccountID],a.[LastEditDate],a.[PaymentAllocationRuleID],a.[IsInclude], a.[IsPrimary], b.InvoiceNumber
				,CAST(0 AS bit) AS IsGrouped
				,'''' AS GroupName
		FROM Legal_GroupDebts a
			JOIN Account b ON a.AccountID = b.AccountID
		WHERE a.AccountID = b.AccountID AND GroupID = @groupID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2
		ORDER BY a.[IsPrimary] DESC, b.AccountID
	ELSE
		SELECT	NULL AS [GroupDebtID], NULL AS [GroupID], b.[AccountID], NULL AS [LastEditDate],
				NULL AS [PaymentAllocationRuleID], 
				CAST((CASE b.AccountID WHEN @AccountID THEN 1 ELSE 0 END) AS bit) AS [IsInclude],
				CAST((CASE b.AccountID WHEN @AccountID THEN 1 ELSE 0 END) AS bit) AS [IsPrimary],
				b.InvoiceNumber,
				CAST(0 AS bit) AS IsGrouped,
				'''' AS GroupName
		FROM Account b 
		WHERE b.DebtorID = @debtorID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2
		ORDER BY a.[IsPrimary] DESC, b.AccountID
END


' 
END
GO

ALTER TABLE dbo.TransactionType ADD
	InterestBreakdown bit NULL
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 11/14/2008 10:28:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 11/14/2008 10:28:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'



-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debtors with Account No. and Customer ''s fullName
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
	BEGIN
		DECLARE @PersonID int
		SELECT @PersonID=d.PersonID
		FROM DebtorInformation d
		LEFT JOIN CosigneeInformation c ON c.PersonID = d.PersonID
		WHERE d.DebtorID=@debtorID-- AND c.Relationship_Type IS NULL

		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate]
				, CASE a.PersonID WHEN @PersonID THEN ''Debtor'' ELSE r.Description END AS [RelationshipType]
				, a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[DefendantNum], a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				LEFT JOIN PersonInformation p ON a.PersonID = p.PersonID
				LEFT JOIN Account b ON a.AccountID = b.AccountID
				LEFT JOIN CosigneeInformation g ON g.PersonID = a.PersonID AND g.Bill = b.AccountID
				LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE a.GroupID = @groupID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	END
	ELSE
	BEGIN
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,''Debtor'' AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum], isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
				LEFT JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
				--LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate], r.Description AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
			LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID) AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2
		
		ORDER BY Seq, b.AccountID, FullName
	END
END

' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalEmployee]    Script Date: 11/14/2008 12:42:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByLegalEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByEmployeeName]    Script Date: 11/14/2008 12:42:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByEmployeeName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByEmployeeName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByName]    Script Date: 11/14/2008 12:42:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchDebtorByName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 11/14/2008 12:42:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalEmployee]    Script Date: 11/14/2008 12:42:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalEmployee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalEmployee] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '''') = '''' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '','')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '''') = '''' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '','')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByEmployeeName]    Script Date: 11/14/2008 12:42:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByEmployeeName]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByEmployeeName] 
	-- Add the parameters for the stored procedure here
	@EmployeeName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
	WHERE
		a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND UPPER(g.EmployeeName) LIKE (''%'' + UPPER(@EmployeeName) + ''%'')
		AND (ISNULL(@EmpList, '''') = '''' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '','')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			g.EmployeeName AS [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID 
		WHERE
			a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND UPPER(g.EmployeeName) LIKE (''%'' + UPPER(@EmployeeName) + ''%'')
			AND (ISNULL(@EmpList, '''') = '''' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '','')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByName]    Script Date: 11/14/2008 12:42:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByName]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'




-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchDebtorByName] 
	-- Add the parameters for the stored procedure here
	@DebtorName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(p.FirstName) + '' '' + RTRIM(p.MiddleName) + '' '' + RTRIM(p.LastName)) LIKE (''%'' + UPPER(@DebtorName) + ''%'')
		AND (ISNULL(@EmpList, '''') = '''' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '','')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + '' '' + RTRIM(p.MiddleName) + '' '' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(p.FirstName) + '' '' + RTRIM(p.MiddleName) + '' '' + RTRIM(p.LastName)) LIKE (''%'' + UPPER(@DebtorName) + ''%'')
			AND (ISNULL(@EmpList, '''') = '''' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, '','')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 11/14/2008 12:42:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'



-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debtors with Account No. and Customer ''s fullName
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
	BEGIN
		DECLARE @PersonID int
		SELECT @PersonID=d.PersonID
		FROM DebtorInformation d
		LEFT JOIN CosigneeInformation c ON c.PersonID = d.PersonID
		WHERE d.DebtorID=@debtorID-- AND c.Relationship_Type IS NULL

		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate]
				, CASE a.PersonID WHEN @PersonID THEN ''Debtor'' ELSE r.Description END AS [RelationshipType]
				, a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[DefendantNum], a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				LEFT JOIN PersonInformation p ON a.PersonID = p.PersonID
				LEFT JOIN Account b ON a.AccountID = b.AccountID
				LEFT JOIN CosigneeInformation g ON g.PersonID = a.PersonID AND g.Bill = b.AccountID
				LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE a.GroupID = @groupID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	END
	ELSE
	BEGIN
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,''Debtor'' AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum], isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
				LEFT JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
				--LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate], r.Description AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
			LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID) AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2
		
		ORDER BY Seq, b.AccountID, FullName
	END
END

' 
END
GO

ALTER TABLE dbo.Legal_Snapshots ADD
	CaseNumber varchar(30) NULL
GO

ALTER TABLE dbo.Legal_Hearings ADD
	SolicitorID int NULL
GO

-- Scripts 2.9.10:
-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Nov 14, 2008
-- Description:		Create table ClientSubProductInfo
-- =======================================================================
/****** Object:  Table [dbo].[ClientSubProductInfo]    Script Date: 11/14/2008 16:50:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ClientSubProductInfo]') AND type in (N'U'))
DROP TABLE [dbo].[ClientSubProductInfo]
GO

/****** Object:  Table [dbo].[ClientSubProductInfo]    Script Date: 11/14/2008 16:49:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ClientSubProductInfo](
	[SubClientID] [int] IDENTITY(1,1) NOT NULL,
	[ProductCode] [varchar](10) NOT NULL,
	[ProductName] [varchar](100) NULL,
	[ProductType] [varchar](100) NULL,
	[ProductGroup] [varchar](100) NULL,
	[SalesCanvass] [varchar](100) NULL,
	[ParentClientID] [int] NOT NULL,
	[Note] [nvarchar](250) NULL,
	[Status] [char](1) NOT NULL CONSTRAINT [DF_ClientSubProductInfo_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_ClientSubProductInfo] PRIMARY KEY CLUSTERED 
(
	[SubClientID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

-- Scripts 2.9.11:

/****** Object:  Table [dbo].[CWX_InterestBreakdown]    Script Date: 11/17/2008 10:33:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InterestBreakdown]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_InterestBreakdown]
GO
/****** Object:  Table [dbo].[CWX_InterestBreakdown]    Script Date: 11/17/2008 10:33:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InterestBreakdown]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_InterestBreakdown](
	[InterestBreakdownID] [int] IDENTITY(1,1) NOT NULL,
	[AccountID] [int] NULL,
	[TransactionTypeID] [int] NULL,
	[StartDate] [smalldatetime] NULL,
	[EndDate] [smalldatetime] NULL,
	[NumOfDays] [int] NULL,
	[InterestRate] [money] NULL,
	[DebtAmount] [money] NULL,
	[InterestAmount] [money] NULL,
	[AmountPerDay] [money] NULL,
 CONSTRAINT [PK_CWX_InterestBreakdown] PRIMARY KEY CLUSTERED 
(
	[InterestBreakdownID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_InterestBreakdown_GetTotalValues]    Script Date: 11/17/2008 10:33:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InterestBreakdown_GetTotalValues]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_InterestBreakdown_GetTotalValues]
GO
/****** Object:  StoredProcedure [dbo].[CWX_InterestBreakdown_GetTotalValues]    Script Date: 11/17/2008 10:33:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InterestBreakdown_GetTotalValues]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		LongNguyen
-- Create date: 2008-11-14
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_InterestBreakdown_GetTotalValues] 
	@AccountID int,
	@TransactionTypeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT SUM(NumOfDays) AS NumOfDays, SUM(InterestAmount) AS InterestAmount
	FROM CWX_InterestBreakdown
	WHERE AccountID=@AccountID AND TransactionTypeID=@TransactionTypeID
END
' 
END
GO

-- Scripts 2.9.12:

/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 11/17/2008 18:32:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 11/17/2008 18:32:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get Transaction List by TransactionType with a custom column is "Transaction Code - Description"
-- History:
--	2008/08/29	[Thuy Nguyen]	Init version.
--	2008/09/29	[Binh Truong]	Select total transaction amount.
--	2008/10/29	[Binh Truong]	Add DateToPost field.
--	2008/10/30	[Binh Truong]	Exclude Transactions.Descriptor = ''A''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList] 		
	@AccountID int = 0,
	@TransactionType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;	

	DECLARE @querystring varchar(1000);

	CREATE TABLE #Temp(
		RowNumber int,		
		TransactionID int not null,
		DateToPost smalldatetime,
		DateOfTransaction smalldatetime,
		TransactionAmount money,		
		TransactionComment nvarchar(150),
		TransactionCodeDescription nvarchar(150),
		TransactionType int,
		InterestBreakdown bit
	);

	
	SET @querystring = ''INSERT INTO #Temp
		SELECT 
		ROW_NUMBER() OVER (ORDER BY  t.DateOfTransaction DESC, TransactionID DESC) AS RowNumber,
		t.TransactionID, t.DateToPost, t.DateOfTransaction, t.TransactionAmount, t.TransactionComment,
		tt.TransactionCode + '''' - '''' + tt.Description as TransactionCodeDescription,
		t.TransactionType, tt.InterestBreakdown
	FROM Transactions t LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID
	WHERE	t.AccountID = '' + cast(@AccountID as varchar) + '' AND 
			t.ParentTransactionID IS NULL AND 
			t.Descriptor <> ''''A''''
			''

	IF @TransactionType<>0 SET @querystring = @querystring + '' AND t.TransactionType = '' + cast(@TransactionType as varchar);
	
	EXEC (@querystring)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	
	SELECT	SUM(TransactionAmount) as TotalAmount
	FROM	Transactions
	WHERE	AccountID = @AccountID AND
			(@TransactionType=0 OR TransactionType = @TransactionType) AND
			ParentTransactionID IS NULL AND
			Descriptor <> ''A'' -- exclude additional transaction		
	
	RETURN @RowCount
END
' 
END
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Jun 26, 2008
-- Description:		Add column 'AddressType'
-- Effected table:	RuleTable
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'RuleTable' and c.name = 'AddressType')
BEGIN
	ALTER TABLE RuleTable
		ADD AddressType tinyint NULL		
END
GO

-- Scripts 2.9.13:

ALTER TABLE CWX_InterestBreakdown
	DROP COLUMN AmountPerDay
GO

/****** Object:  StoredProcedure [dbo].[CWX_InterestBreakdown_GetTotalValues]    Script Date: 11/19/2008 13:47:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InterestBreakdown_GetTotalValues]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_InterestBreakdown_GetTotalValues]
GO
/****** Object:  StoredProcedure [dbo].[CWX_InterestBreakdown_GetTotalValues]    Script Date: 11/19/2008 13:47:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InterestBreakdown_GetTotalValues]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		LongNguyen
-- Create date: 2008-11-14
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_InterestBreakdown_GetTotalValues] 
	@AccountID int,
	@TransactionTypeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT ISNULL(SUM(NumOfDays), 0) AS NumOfDays, ISNULL(SUM(InterestAmount), 0) AS InterestAmount
	FROM CWX_InterestBreakdown
	WHERE AccountID=@AccountID AND TransactionTypeID=@TransactionTypeID
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_GetSettingByAccountID]    Script Date: 11/19/2008 13:59:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_GetSettingByAccountID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProductSetting_GetSettingByAccountID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_Get]    Script Date: 11/19/2008 13:59:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProductSetting_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_GetSettingByAccountID]    Script Date: 11/19/2008 13:59:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_GetSettingByAccountID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get product settings by Account ID.
-- History:
--	2008/05/08	[Binh Truong]	Init version.
--	2008/10/10	[Binh Truong]	Fix bug MCode > 6
--	2008/11/19	[Binh Truong]	Fix bug MCode = NULL, set MCode = 0
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ProductSetting_GetSettingByAccountID]
(
	@AccountID int
)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @ProductInfo int
	DECLARE @Bucket varchar(10)
	DECLARE @ProductID int 
	DECLARE @strMaxBucket varchar(10)
	DECLARE @MaxBucket int
	
	SET @ProductInfo = 6
	
	SELECT  @Bucket=MCode, @ProductID=ClientID
	FROM	Account
	WHERE	AccountID = @AccountID
	
	SELECT  TOP(1) @strMaxBucket=InfoKey
	FROM	InformationTable
	WHERE	InfoID = @ProductInfo AND 
			InfoKey LIKE ''%+''
	
	IF @strMaxBucket IS NULL
	BEGIN
		SELECT  @MaxBucket=MAX(InfoKey)
		FROM	InformationTable
		WHERE	InfoID = @ProductInfo
	END
	ELSE
	BEGIN
		SET @MaxBucket = CAST(REPLACE(@strMaxBucket, ''+'', '''') AS int)
	END
	
	IF @Bucket IS NULL OR LEN(@Bucket) = 0
		SET @Bucket = 0
	
	IF CONVERT(int, @Bucket) > @MaxBucket
		SET @Bucket = @strMaxBucket
	
	SELECT  InformationTable.*
	FROM    InformationTable
	WHERE	(InfoID = @ProductInfo) AND 
			(InfoKey = @Bucket) AND 
			(InfoType = @ProductID)
	
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_Get]    Script Date: 11/19/2008 13:59:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- ===================================================================================
-- Description:	Get product setting
-- History:
--	2008/11/07	[Binh Truong]	Init version.
--	2008/11/01	[Binh Truong]	Fix bug MCode > 6
--	2008/11/19	[Binh Truong]	Fix bug MCode = NULL, set MCode = 0
-- ===================================================================================
CREATE PROCEDURE [dbo].[CWX_ProductSetting_Get] 
	@ProductID int, 
	@InfoSubType int, -- SettingProductType
	@Bucket varchar(50) -- Bucket
AS
BEGIN
	SET NOCOUNT ON
		
	DECLARE @ProductInfo int
	DECLARE @strMaxBucket varchar(50)
	DECLARE @MaxBucket int
	
	SET @ProductInfo = 6 -- Code for product setting
	
	SELECT  TOP(1) @strMaxBucket=InfoKey
	FROM	InformationTable
	WHERE	InfoID = @ProductInfo AND 
			InfoKey LIKE ''%+''
	
	IF @strMaxBucket IS NULL
	BEGIN
		SELECT  @MaxBucket=MAX(InfoKey)
		FROM	InformationTable
		WHERE	InfoID = @ProductInfo
	END
	ELSE
	BEGIN
		SET @MaxBucket = CAST(REPLACE(@strMaxBucket, ''+'', '''') AS int)
	END
	
	IF @Bucket IS NULL OR LEN(@Bucket) = 0
		SET @Bucket = 0
	
	IF @Bucket > @MaxBucket
		SET @Bucket = @strMaxBucket
	
	SELECT  InformationTable.*
	FROM    InformationTable
	WHERE	(InfoID = @ProductInfo) AND 
			(InfoKey = @Bucket) AND 
			(InfoType = @ProductID) AND
			InfoSubType = @InfoSubType
					
END
' 
END
GO

-- Scripts 2.9.14:

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Transactions ADD
	PromiseID int NULL
GO
COMMIT
GO

-- Scripts 2.9.15:

/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 11/20/2008 17:30:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 11/20/2008 17:30:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get Transaction List by TransactionType with a custom column is "Transaction Code - Description"
-- History:
--	2008/08/29	[Thuy Nguyen]	Init version.
--	2008/09/29	[Binh Truong]	Select total transaction amount.
--	2008/10/29	[Binh Truong]	Add DateToPost field.
--	2008/10/30	[Binh Truong]	Exclude Transactions.Descriptor = ''A''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList] 		
	@AccountID int = 0,
	@TransactionType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;	

	DECLARE @querystring varchar(1000);

	CREATE TABLE #Temp(
		RowNumber int,		
		TransactionID int not null,
		DateToPost smalldatetime,
		DateOfTransaction smalldatetime,
		TransactionAmount money,		
		TransactionComment nvarchar(150),
		TransactionCodeDescription nvarchar(150),
		TransactionType int,
		InterestBreakdown bit,
		ReversedFlag bit,
		ImportedTransactionID varchar(100)
	);

	
	SET @querystring = ''INSERT INTO #Temp
		SELECT 
		ROW_NUMBER() OVER (ORDER BY  t.DateOfTransaction DESC, TransactionID DESC) AS RowNumber,
		t.TransactionID, t.DateToPost, t.DateOfTransaction, t.TransactionAmount, t.TransactionComment,
		tt.TransactionCode + '''' - '''' + tt.Description as TransactionCodeDescription,
		t.TransactionType, tt.InterestBreakdown, t.ReversedFlag, t.ImportedTransactionID
	FROM Transactions t LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID
	WHERE	t.AccountID = '' + cast(@AccountID as varchar) + '' AND 
			t.ParentTransactionID IS NULL AND 
			t.Descriptor <> ''''A''''
			''

	IF @TransactionType<>0 SET @querystring = @querystring + '' AND t.TransactionType = '' + cast(@TransactionType as varchar);
	
	EXEC (@querystring)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	
	SELECT	SUM(TransactionAmount) as TotalAmount
	FROM	Transactions
	WHERE	AccountID = @AccountID AND
			(@TransactionType=0 OR TransactionType = @TransactionType) AND
			ParentTransactionID IS NULL AND
			Descriptor <> ''A'' -- exclude additional transaction		
	
	RETURN @RowCount
END
' 
END
GO

-- Scripts 2.9.16:

-- =============================================
-- Author:		Minh Dam
-- Create date: 21-Nov-2008
-- Description:	Get the last account status
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetLastAccountStatus]    Script Date: 11/21/2008 15:29:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetLastAccountStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetLastAccountStatus]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetLastAccountStatus]    Script Date: 11/21/2008 15:29:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Account_GetLastAccountStatus]
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@LastAgencyStatusID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @AgencyStatusID int
	IF (@LastAgencyStatusID > 0)
		SET @AgencyStatusID = @LastAgencyStatusID
	ELSE
		SELECT @AgencyStatusID = AgencyStatusID
		FROM Account
		WHERE AccountID = @AccountID

	SELECT	ShortDesc
	FROM	AccountStatus
	WHERE	AgencyStatus = @AgencyStatusID
END
GO


-- Scripts 2.9.17:
-- 2008-11-21	[Minh Dam]	Init version
IF NOT EXISTS(SELECT TableName FROM IdentityFields WHERE TableName='BillAmountIncludesBillBalance')
BEGIN
	INSERT INTO IdentityFields
			(TableName, FieldValue)
	VALUES  ('BillAmountIncludesBillBalance', 1)
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetRuleAccountsDetail]    Script Date: 11/21/2008 17:53:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetRuleAccountsDetail]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetRuleAccountsDetail]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetRuleAccountsDetail]    Script Date: 11/21/2008 17:53:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetRuleAccountsDetail]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Long Nguyen
-- Create date: 2008-11-21
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetRuleAccountsDetail]
	-- Add the parameters for the stored procedure here
	@EmployeeID int = 0,
	@StartDate smalldatetime = NULL,
	@EndDate smalldatetime = NULL,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int

    SELECT
		@RowCount = COUNT(RowNumber)
	FROM
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.AllocRuleID) AS RowNumber,
			a.AllocRuleID AS RuleID,
			r.Description AS RuleDescription,
			a.EmployeeID,
			e.UserID,
			ISNULL(COUNT(AccountID),0) AS TotalAccounts,
			ISNULL(SUM(BillBalance),0) AS TotalValue
		FROM Account a,Employee e,RuleTable r 
		WHERE
			((@StartDate IS NULL) OR CONVERT(VARCHAR(10),a.LastAllocationDate,121) >= CONVERT(VARCHAR(10),@StartDate,121))
			AND ((@EndDate IS NULL) OR CONVERT(VARCHAR(10),a.LastAllocationDate,121) <= CONVERT(VARCHAR(10),@EndDate,121))
			AND a.EmployeeID = e.EmployeeID 
			AND a.AllocRuleID = r.[ID] 
			AND (@EmployeeID=0 OR a.EmployeeID = @EmployeeID)
		GROUP BY a.AllocRuleID,a.EmployeeID,e.UserID,r.Description
	) a

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.AllocRuleID) AS RowNumber,
			a.AllocRuleID AS RuleID,
			r.Description AS RuleDescription,
			a.EmployeeID,
			e.UserID,
			ISNULL(COUNT(AccountID),0) AS TotalAccounts,
			ISNULL(SUM(BillBalance),0) AS TotalValue
		FROM Account a,Employee e,RuleTable r 
		WHERE
			((@StartDate IS NULL) OR CONVERT(VARCHAR(10),a.LastAllocationDate,121) >= CONVERT(VARCHAR(10),@StartDate,121))
			AND ((@EndDate IS NULL) OR CONVERT(VARCHAR(10),a.LastAllocationDate,121) <= CONVERT(VARCHAR(10),@EndDate,121))
			AND a.EmployeeID = e.EmployeeID 
			AND a.AllocRuleID = r.[ID] 
			AND (@EmployeeID=0 OR a.EmployeeID = @EmployeeID)
		GROUP BY a.AllocRuleID,a.EmployeeID,e.UserID,r.Description
	)

	SELECT * FROM Temp
	WHERE ((@PageSize<=0) OR (RowNumber BETWEEN (@PageSize*@PageIndex+1) AND (@PageSize*(@PageIndex+1))))

	RETURN @RowCount
END

' 
END
GO

-- =============================================
-- Author:		Long Nguyen
-- Create date: 2008-11-24
-- Description:	Add IsGroupAccountCreated field to the Legal_Groups
-- =============================================
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Legal_Groups ADD
	IsGroupAccountCreated bit NULL
GO
ALTER TABLE dbo.Legal_Groups ADD CONSTRAINT
	DF_Legal_Groups_IsGroupAccountCreated DEFAULT 0 FOR IsGroupAccountCreated
GO
COMMIT
GO

-- Scripts 2.9.19:
-- [2008-11-25]	Minh Dam	Add a record to InformationTable to store a value indicate 
--							whether the icons of tree menu is showed or not.
							
IF (NOT EXISTS(SELECT * FROM InformationTable WHERE InfoID = 1 AND InfoType=15))
	INSERT INTO InformationTable(InfoID, InfoType, InfoSubType, InfoKey, [Description], [Value], ValueFormat, [Status]) 
	VALUES (1, 15, 0, '', 'Show icon of tree menu in CMS Main page', '', 'True', 'A')
ELSE
	UPDATE InformationTable
	SET InfoSubType = 0,
		InfoKey = '',
		[Description] = 'Show icon of tree menu in CMS Main page',
		[Value] = '',
		ValueFormat = 'True',
		[Status] = 'A'
	WHERE InfoID = 1 AND InfoType = 15	
GO

-- Scripts 2.9.20:

/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 11/26/2008 16:50:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 11/26/2008 16:50:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Description:	Get Transaction List by TransactionType with a custom column is "Transaction Code - Description"
-- History:
--	2008/08/29	[Thuy Nguyen]	Init version.
--	2008/09/29	[Binh Truong]	Select total transaction amount.
--	2008/10/29	[Binh Truong]	Add DateToPost field.
--	2008/10/30	[Binh Truong]	Exclude Transactions.Descriptor = ''A''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList] 		
	@AccountID int = 0,
	@TransactionType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;	

	DECLARE @querystring varchar(1000);

	CREATE TABLE #Temp(
		RowNumber int,		
		TransactionID int not null,
		DateToPost smalldatetime,
		DateOfTransaction smalldatetime,
		TransactionAmount money,		
		TransactionComment nvarchar(150),
		TransactionCodeDescription nvarchar(150),
		TransactionType int,
		InterestBreakdown bit,
		ReversedFlag bit,
		ImportedTransactionID varchar(100),
		TXN_POSTED varchar(1)
	);

	
	SET @querystring = ''INSERT INTO #Temp
		SELECT 
		ROW_NUMBER() OVER (ORDER BY  t.DateOfTransaction DESC, TransactionID DESC) AS RowNumber,
		t.TransactionID, t.DateToPost, t.DateOfTransaction, t.TransactionAmount, t.TransactionComment,
		tt.TransactionCode + '''' - '''' + tt.Description as TransactionCodeDescription,
		t.TransactionType, tt.InterestBreakdown, t.ReversedFlag, t.ImportedTransactionID, t.TXN_POSTED
	FROM Transactions t LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID
	WHERE	t.AccountID = '' + cast(@AccountID as varchar) + '' AND 
			ISNULL(t.ParentTransactionID, 0) = 0 AND 
			t.Descriptor <> ''''A''''
			''

	IF @TransactionType<>0 SET @querystring = @querystring + '' AND t.TransactionType = '' + cast(@TransactionType as varchar);
	
	EXEC (@querystring)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	
	SELECT	SUM(TransactionAmount) as TotalAmount
	FROM	Transactions
	WHERE	AccountID = @AccountID AND
			(@TransactionType=0 OR TransactionType = @TransactionType) AND
			ParentTransactionID IS NULL AND
			Descriptor <> ''A'' -- exclude additional transaction		
	
	RETURN @RowCount
END

' 
END
GO




-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Jun 26, 2008
-- Description:		Add column 'RuleId' with default value '0'
-- Effected table:	QueueSortMaster
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'QueueSortMaster' and c.name = 'RuleId')
BEGIN
	ALTER TABLE QueueSortMaster
	ADD RuleId int NOT NULL
		CONSTRAINT [QueueSortMaster_RuleId] DEFAULT '0'
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_AddRemove]    Script Date: 11/26/2008 18:30:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
--	[2008-11-26]	Minh Dam		Add parameter @AccountProcessingRuleId
-- =============================================
ALTER PROCEDURE [dbo].[CWX_QueueSortMaster_AddRemove] 
	@QueuePriorities xml,
	@AccountProcessingRuleId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @tbQueuePriority table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4),
		RuleId int
	)

	DECLARE @NewQueueID int
	SET @NewQueueID = 1

	DECLARE @QueueID int
	DECLARE @Description varchar(60)
	DECLARE @RuleId int

	DECLARE @SortID int
	IF EXISTS (SELECT QueueId FROM QueueSortMaster WHERE sortid = 0 AND RuleId = @AccountProcessingRuleId)
		SET @SortID = 0
	ELSE
		SET @SortID = @NewQueueID

	DECLARE QueuePriorityCrsr CURSOR FOR
	SELECT
		ParamValues.QueuePriority.value('./@QueueID','int') AS QueueID,
		ParamValues.QueuePriority.value('./@Description','varchar(60)') AS Description,
		ParamValues.QueuePriority.value('./@RuleId', 'int') AS RuleId
	FROM
		@QueuePriorities.nodes('/QueuePriorities/QueuePriority') as ParamValues(QueuePriority) 

	OPEN QueuePriorityCrsr

	FETCH NEXT FROM QueuePriorityCrsr
	INTO @QueueID, @Description, @RuleId

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @SortID > 0
			SET @SortID = @NewQueueID

		IF @QueueID = 0
			INSERT INTO @tbQueuePriority
			VALUES(@NewQueueID, @Description, '"' + @Description + '"', @SortID, 'ASC ', @RuleId)
		ELSE
			INSERT INTO @tbQueuePriority
			SELECT
				@NewQueueID, Description, QueueColumn, @SortID, SortDirection, RuleId
			FROM
				QueueSortMaster
			WHERE
				QueueId = @QueueID AND RuleId = @RuleId			
		
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM QueuePriorityCrsr
		INTO @QueueID, @Description, @RuleId
	END

	DELETE FROM QueueSortMaster WHERE RuleId = @AccountProcessingRuleId
	IF( @@ERROR <> 0)
		GOTO Cleanup

	INSERT INTO QueueSortMaster SELECT * FROM @tbQueuePriority
	IF( @@ERROR <> 0)
		GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE QueuePriorityCrsr
	DEALLOCATE QueuePriorityCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END
GO


/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_UpdateList]    Script Date: 11/26/2008 17:47:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
--	[2008-11-26]	Minh Dam		Add parameter @AccountProcessingRuleId
-- =============================================
ALTER PROCEDURE [dbo].[CWX_QueueSortMaster_UpdateList] 
	@QueuePriorities xml,
	@Enabled bit,
	@AccountProcessingRuleId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @QueueID int
	DECLARE @SortDirection char(4)
	DECLARE @SortID int
	DECLARE @RuleId int

	IF @Enabled = 1
		SET @SortID = 1
	ELSE
		SET @SortID = 0

	DECLARE @tbQueuePriority table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4),
		RuleId int
	)

	DECLARE @NewQueueID int
	SET @NewQueueID = 1

	DECLARE QueuePriorityCrsr CURSOR FOR
	SELECT
		ParamValues.QueuePriority.value('./@QueueID','int') AS QueueID,
		ParamValues.QueuePriority.value('./@SortDirection','char(4)') AS SortDirection,
		ParamValues.QueuePriority.value('./@RuleId','int') AS RuleId
	FROM
		@QueuePriorities.nodes('/QueuePriorities/QueuePriority') as ParamValues(QueuePriority)

	OPEN QueuePriorityCrsr

	FETCH NEXT FROM QueuePriorityCrsr
	INTO @QueueID, @SortDirection, @RuleId

	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO @tbQueuePriority
		SELECT
			@NewQueueID, Description, QueueColumn, @SortID, @SortDirection, @RuleId
		FROM
			QueueSortMaster
		WHERE
			QueueId = @QueueID AND RuleId = @RuleId

		IF @Enabled = 1
			SET @SortID = @SortID + 1
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM QueuePriorityCrsr
		INTO @QueueID, @SortDirection, @RuleId
	END

	DELETE FROM QueueSortMaster WHERE RuleId = @AccountProcessingRuleId
	IF( @@ERROR <> 0)
        GOTO Cleanup

	INSERT INTO QueueSortMaster SELECT * FROM @tbQueuePriority
	IF( @@ERROR <> 0)
        GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE QueuePriorityCrsr
	DEALLOCATE QueuePriorityCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END
GO


/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_GetAvailable]    Script Date: 11/27/2008 14:06:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
--	[2008-11-26]	Minh Dam		Add @AccountProcessingRuleId
-- =============================================
ALTER PROCEDURE [dbo].[CWX_QueueSortMaster_GetAvailable] 
	@AccountProcessingRuleId int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		[DESCRIPTION] = SUBSTRING(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))), 1, LEN(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value])))) - 2)
	INTO #Temp
	FROM
		sys.[columns] c
		LEFT OUTER JOIN sys.[extended_properties] ex ON ex.[major_id] = c.[object_id]
	WHERE
		OBJECTPROPERTY(c.[object_id], 'IsMsShipped')=0
		AND ex.[minor_id] = c.[column_id]
		AND ex.[name] = 'MS_Description'
		AND (
				OBJECT_NAME(c.[object_id]) = 'Account'
				OR OBJECT_NAME(c.[object_id]) = 'Accountother'
				OR OBJECT_NAME(c.[object_id]) = 'DebtorInformation'
				OR OBJECT_NAME(c.[object_id]) = 'PersonInformation'
				OR OBJECT_NAME(c.[object_id]) = 'AccountStatus'
			)
		AND LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))) LIKE '%_Q'
	ORDER BY
		[Description]

	SELECT
		0 AS QueueId,
		Description,
		('"' + Description + '"') AS QueueColumn,
		0 AS sortid,
		'ASC ' AS SortDirection
	FROM
		#Temp
	WHERE
		[Description] NOT IN (SELECT Description FROM QueueSortMaster WHERE RuleId = @AccountProcessingRuleId)
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_GetList]    Script Date: 11/27/2008 14:20:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProductSetting_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_GetList]    Script Date: 11/27/2008 14:20:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_GetList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- ===================================================================================
-- Description:	Get list of product setting
-- History:
--	2008/11/27	[Binh Truong]	Init version.
-- ===================================================================================
create PROCEDURE [dbo].[CWX_ProductSetting_GetList] 
	@ProductID int, 
	@Bucket varchar(50)
AS
BEGIN
	SET NOCOUNT ON
		
	DECLARE @ProductInfo int
	DECLARE @strMaxBucket varchar(50)
	DECLARE @MaxBucket int
	
	SET @ProductInfo = 6 -- Code for product setting
	
	IF CHARINDEX(''+'', @Bucket) = 0
	BEGIN
		SELECT  TOP(1) @strMaxBucket=InfoKey
		FROM	InformationTable
		WHERE	InfoID = @ProductInfo AND 
				InfoKey LIKE ''%+''
		
		IF @strMaxBucket IS NULL
		BEGIN
			SELECT  @MaxBucket=MAX(InfoKey)
			FROM	InformationTable
			WHERE	InfoID = @ProductInfo
		END
		ELSE
		BEGIN
			SET @MaxBucket = CAST(REPLACE(@strMaxBucket, ''+'', '''') AS int)
		END
		
		IF @Bucket IS NULL OR LEN(@Bucket) = 0
			SET @Bucket = 0
		
		IF @Bucket > @MaxBucket
			SET @Bucket = @strMaxBucket
			
	END	
	
	SELECT  InformationTable.*
	FROM    InformationTable
	WHERE	(InfoID = @ProductInfo) AND 
			(InfoKey = @Bucket) AND 
			(InfoType = @ProductID)
					
END
' 
END
GO

-- Scripts 2.9.22:

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO

-- =============================================================
-- Description:	Retrieve all personal phone details
-- History:
--	2008/03/26	[Triet Pham]	Init version.
--	2008/11/27	[Sathya]		Modified.
-- =============================================================
ALTER PROCEDURE [dbo].[CWX_PersonPhone_Get]	
	@DebtorID int = 0,
	@PersonID int = 0
AS
BEGIN
	SET NOCOUNT ON	
	DECLARE @TYPE1PHONENO varchar(50)
	DECLARE @TYPE1PHONEDESC varchar(255)
	DECLARE @TYPE1PHONEXT varchar(25)
	DECLARE @TYPE1PHONESTAUS smallint

	DECLARE @TYPE2PHONENO varchar(50)
	DECLARE @TYPE2PHONEDESC varchar(255)
	DECLARE @TYPE2PHONEXT varchar(25)
	DECLARE @TYPE2PHONESTAUS smallint

	DECLARE @TYPE3PHONENO varchar(50)
	DECLARE @TYPE3PHONEDESC varchar(255)
	DECLARE @TYPE3PHONEXT varchar(25)
	DECLARE @TYPE3PHONESTAUS smallint

	DECLARE @TYPE4PHONENO varchar(50)
	DECLARE @TYPE4PHONEDESC varchar(255)
	DECLARE @TYPE4PHONEXT varchar(25)
	DECLARE @TYPE4PHONESTAUS smallint

	DECLARE @TYPE5PHONENO varchar(50)
	DECLARE @TYPE5PHONEDESC varchar(255)
	DECLARE @TYPE5PHONEXT varchar(25)
	DECLARE @TYPE5PHONESTAUS smallint

	DECLARE @TYPE6PHONENO varchar(50)
	DECLARE @TYPE6PHONEDESC varchar(255)
	DECLARE @TYPE6PHONEXT varchar(25)
	DECLARE @TYPE6PHONESTAUS smallint

	DECLARE @TYPE7PHONENO varchar(50)
	DECLARE @TYPE7PHONEDESC varchar(255)
	DECLARE @TYPE7PHONEXT varchar(25)
	DECLARE @TYPE7PHONESTAUS smallint

	DECLARE @TYPE8PHONENO varchar(50)
	DECLARE @TYPE8PHONEDESC varchar(255)
	DECLARE @TYPE8PHONEXT varchar(25)
	DECLARE @TYPE8PHONESTAUS smallint

	DECLARE @TYPE9PHONENO varchar(50)
	DECLARE @TYPE9PHONEDESC varchar(255)
	DECLARE @TYPE9PHONEXT varchar(25)
	DECLARE @TYPE9PHONESTAUS smallint

	SELECT 
		@TYPE1PHONENO = PhoneNumber,
		@TYPE1PHONEDESC = Description,
		@TYPE1PHONEXT = PhoneExtension,
		@TYPE1PHONESTAUS = PhoneStatus
	FROM PersonPhone AS ph
	LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (ph.PersonID = @PersonID))
		AND ph.PhoneType = 1

	SELECT 
		@TYPE2PHONENO = PhoneNumber,
		@TYPE2PHONEDESC = Description,
		@TYPE2PHONEXT = PhoneExtension,
		@TYPE2PHONESTAUS = PhoneStatus
	FROM PersonPhone AS ph
	LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (ph.PersonID = @PersonID))
		AND ph.PhoneType = 2

	SELECT 
		@TYPE3PHONENO = PhoneNumber,
		@TYPE3PHONEDESC = Description,
		@TYPE3PHONEXT = PhoneExtension,
		@TYPE3PHONESTAUS = PhoneStatus
	FROM PersonPhone AS ph
	LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (ph.PersonID = @PersonID))
		AND ph.PhoneType = 3

	SELECT 
		@TYPE4PHONENO = PhoneNumber,
		@TYPE4PHONEDESC = Description,
		@TYPE4PHONEXT = PhoneExtension,
		@TYPE4PHONESTAUS = PhoneStatus
	FROM PersonPhone AS ph
	LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (ph.PersonID = @PersonID))
		AND ph.PhoneType = 4

	SELECT 
		@TYPE5PHONENO = PhoneNumber,
		@TYPE5PHONEDESC = Description,
		@TYPE5PHONEXT = PhoneExtension,
		@TYPE5PHONESTAUS = PhoneStatus
	FROM PersonPhone AS ph
	LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (ph.PersonID = @PersonID))
		AND ph.PhoneType = 5

	SELECT 
		@TYPE6PHONENO = PhoneNumber,
		@TYPE6PHONEDESC = Description,
		@TYPE6PHONEXT = PhoneExtension,
		@TYPE6PHONESTAUS = PhoneStatus
	FROM PersonPhone AS ph
	LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (ph.PersonID = @PersonID))
		AND ph.PhoneType = 6

	SELECT 
		@TYPE7PHONENO = PhoneNumber,
		@TYPE7PHONEDESC = Description,
		@TYPE7PHONEXT = PhoneExtension,
		@TYPE7PHONESTAUS = PhoneStatus
	FROM PersonPhone AS ph
	LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (ph.PersonID = @PersonID))
		AND ph.PhoneType = 7

	SELECT 
		@TYPE8PHONENO = PhoneNumber,
		@TYPE8PHONEDESC = Description,
		@TYPE8PHONEXT = PhoneExtension,
		@TYPE8PHONESTAUS = PhoneStatus
	FROM PersonPhone AS ph
	LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (ph.PersonID = @PersonID))
		AND ph.PhoneType = 8

	SELECT 
		@TYPE9PHONENO = PhoneNumber,
		@TYPE9PHONEDESC = Description,
		@TYPE9PHONEXT = PhoneExtension,
		@TYPE9PHONESTAUS = PhoneStatus
	FROM PersonPhone AS ph
	LEFT JOIN DebtorInformation AS d ON ph.PersonID = d.PersonID
	WHERE
		((@PersonID = 0 AND d.DebtorID = @DebtorID) OR (ph.PersonID = @PersonID))
		AND ph.PhoneType = 9

	SELECT
		@TYPE1PHONENO AS TYPE1PHONENO,
		@TYPE1PHONEDESC AS TYPE1PHONEDESC,
		@TYPE1PHONEXT AS TYPE1PHONEXT,
		@TYPE1PHONESTAUS AS TYPE1PHONESTAUS,
		@TYPE2PHONENO AS TYPE2PHONENO,
		@TYPE2PHONEDESC AS TYPE2PHONEDESC,
		@TYPE2PHONEXT AS TYPE2PHONEXT,
		@TYPE2PHONESTAUS AS TYPE2PHONESTAUS, 
		@TYPE3PHONENO AS TYPE3PHONENO,
		@TYPE3PHONEDESC AS TYPE3PHONEDESC,
		@TYPE3PHONEXT AS TYPE3PHONEXT,
		@TYPE3PHONESTAUS AS TYPE3PHONESTAUS, 
		@TYPE4PHONENO AS TYPE4PHONENO,
		@TYPE4PHONEDESC AS TYPE4PHONEDESC,
		@TYPE4PHONEXT AS TYPE4PHONEXT,
		@TYPE4PHONESTAUS AS TYPE4PHONESTAUS, 
		@TYPE5PHONENO AS TYPE5PHONENO,
		@TYPE5PHONEDESC AS TYPE5PHONEDESC,
		@TYPE5PHONEXT AS TYPE5PHONEXT, 
		@TYPE5PHONESTAUS AS TYPE5PHONESTAUS,
		@TYPE6PHONENO AS TYPE6PHONENO,
		@TYPE6PHONEDESC AS TYPE6PHONEDESC,
		@TYPE6PHONEXT AS TYPE6PHONEXT,
		@TYPE6PHONESTAUS AS TYPE6PHONESTAUS, 
		@TYPE7PHONENO AS TYPE7PHONENO,
		@TYPE7PHONEDESC AS TYPE7PHONEDESC,
		@TYPE7PHONEXT AS TYPE7PHONEXT, 
		@TYPE7PHONESTAUS AS TYPE7PHONESTAUS,
		@TYPE8PHONENO AS TYPE8PHONENO,
		@TYPE8PHONEDESC AS TYPE8PHONEDESC,
		@TYPE8PHONEXT AS TYPE8PHONEXT,
		@TYPE8PHONESTAUS AS TYPE8PHONESTAUS, 
		@TYPE9PHONENO AS TYPE9PHONENO,
		@TYPE9PHONEDESC AS TYPE9PHONEDESC,
		@TYPE9PHONEXT AS TYPE9PHONEXT,
		@TYPE9PHONESTAUS AS TYPE9PHONESTAUS 
END
GO

/****** Object:  StoredProcedure [dbo].[CW_SORT_ORDER]    Script Date: 11/28/2008 17:09:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CW_SORT_ORDER]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CW_SORT_ORDER]
GO
/****** Object:  StoredProcedure [dbo].[CW_SORT_ORDER]    Script Date: 11/28/2008 17:09:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CW_SORT_ORDER]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'/******   Script Date: 2005/07/15  ******/
CREATE Procedure CW_SORT_ORDER(@v_SortOrder VarChar(700) OUT) As
BEGIN
    Declare @SortCur Cursor , @v_Description VarChar(700)
    Set @SortCur=Cursor For Select QueueColumn +  '' '' + Rtrim(Ltrim(SortDirection) )+ '','' Description  
			      From QueueSortMaster 
			     Where SortId<>0 and RuleID=0 Order By SortId
    Set @v_SortOrder=''''
    Open @SortCur
    Fetch Next From @SortCur Into @v_Description
    While @@Fetch_Status=0 
    Begin
        Set @v_SortOrder=@v_SortOrder+@v_Description
	Fetch Next From @SortCur Into @v_Description
    End
    If @v_SortOrder<>''''
    Begin
       Set @v_SortOrder=SubString(@v_SortOrder,1,Len(LTrim(RTrim(@v_SortOrder)))-1)
    End
    Close @SortCur
    DeAllocate @SortCur
END
' 
END
GO


-- Script 2.9.23:

/****** Object:  StoredProcedure [dbo].[CWX_Account_ChangeQueueDay]    Script Date: 12/01/2008 11:28:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ChangeQueueDay]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_ChangeQueueDay]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ChangeQueueDay]    Script Date: 12/01/2008 11:28:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ChangeQueueDay]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 01, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_ChangeQueueDay] 
	-- Add the parameters for the stored procedure here
	@QueueDay int = 0,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, ''|'')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		--Only use date, remove time
		DECLARE @CurrentDate smalldatetime
		SET @CurrentDate = CONVERT(smalldatetime, CONVERT(varchar(11), GETDATE(), 121))

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				QueueDate = DATEADD(day, @QueueDay, @CurrentDate)
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SET @NoteText = ''AcctMgmt: Queue Date Changed; '' + CAST(@QueueDay AS varchar(5)) + ''  Queue Days Added ''

			INSERT INTO NotesCurrent
			VALUES(@CurrentUserID, @DebtorID, @AccountID, GETDATE(), ''A'', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END

' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterQueue_InsertLetterQueueForCMSScreen]    Script Date: 12/01/2008 11:41:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountLetterQueue_InsertLetterQueueForCMSScreen]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountLetterQueue_InsertLetterQueueForCMSScreen]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterQueue_InsertLetterQueueForCMSScreen]    Script Date: 12/01/2008 11:41:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountLetterQueue_InsertLetterQueueForCMSScreen]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Insert new record of AccountLetterQueue table. AddressType field handle the default value.
-- History:
--	2008/12/01	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountLetterQueue_InsertLetterQueueForCMSScreen]
	@LetterID	int,
	@AccountID	int,
	@DebtorID	int,
	@EmployeeID	int,
	@RunDate	datetime	
AS
BEGIN
	INSERT INTO AccountLetterQueue
	            (AccountID, LetterID, RunDate, XmitStatus, EmployeeID)
	VALUES		(@AccountID,@LetterID,@RunDate, ''O'',      @EmployeeID)
END
' 
END
GO

-- Script Closed.