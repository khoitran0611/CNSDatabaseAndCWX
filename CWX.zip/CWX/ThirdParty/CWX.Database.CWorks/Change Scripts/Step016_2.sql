-- Script is applied on version 2.2.5, 2.2.7, 2.2.8, 2.2.9
/****** Object:  StoredProcedure [dbo].[CWX_Account_UnlockPoolAccount]    Script Date: 07/17/2008 18:28:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UnlockPoolAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_UnlockPoolAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_UnlockPoolAccount]    Script Date: 07/17/2008 18:28:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UnlockPoolAccount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
CREATE PROCEDURE CWX_Account_UnlockPoolAccount
	@AccountID int
AS
BEGIN
	update Account set PoolSelected=0 where AccountID=@AccountID
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_UnlockAllPoolAccount]    Script Date: 07/17/2008 18:28:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UnlockAllPoolAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_UnlockAllPoolAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_UnlockAllPoolAccount]    Script Date: 07/17/2008 18:28:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UnlockAllPoolAccount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
CREATE PROCEDURE CWX_Account_UnlockAllPoolAccount
AS
BEGIN
	update Account set PoolSelected=0
END
' 
END
GO

Insert into QueryParams values (26,1,'Available Pools','','select a.EmployeeID,a.Description from Employee a,EmployeePool b where a.EmployeeID = b.PoolId and b.EmployeeID = %E')
GO
Insert into QueryMaster values (26,1,'Pool','',0,'EXEC CWX_GetEmployeeNextPoolAccount %E')
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtList]    Script Date: 07/18/2008 10:09:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 07/18/2008 10:09:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 07/18/2008 10:09:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 07/18/2008 10:09:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-14
-- Description:	Get the list of Groups of selecting customer
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
	-- Add the parameters for the stored procedure here
	@debtorID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
    SELECT
		ROW_NUMBER() OVER (ORDER BY G.Code) AS RowNumber,
		G.*	
	INTO #Temp
	FROM (SELECT DISTINCT
		a.GroupID,
		a.Code,
		a.[Description],
		Case When d.GroupID is null then 1 else 0 end HasStep
		FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
			LEFT JOIN Account c ON b.AccountID = c.AccountID
			LEFT JOIN (Select distinct GroupID from Legal_GroupSteps) d ON a.GroupID = d.GroupID
		WHERE  a.Status <> ''R'' and c.DebtorID = @debtorID) G
	ORDER BY G.Code	

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT *
	FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
	
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtList]    Script Date: 07/18/2008 10:09:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debts with Account No.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    IF @groupID <> 0
		SELECT a.[GroupDebtID],a.[GroupID],a.[AccountID],a.[LastEditDate],a.[PaymentAllocationRuleID],a.[IsInclude], a.[IsPrimary], b.InvoiceNumber
				,Case When c.IsInclude is not NULL Then 1 Else 0 End IsGrouped
				,GroupName
		FROM Legal_GroupDebts a
			JOIN Account b ON a.AccountID = b.AccountID
			LEFT JOIN (Select AccountID, IsInclude, (b.Code+'' - ''+b.Description) as GroupName 
						From Legal_GroupDebts a, Legal_Groups b where a.GroupID=b.GroupID and a.GroupID <> @groupID 
									and IsInclude = 1 and b.Status <> ''R'') c ON a.AccountID = c.AccountID
		WHERE a.AccountID = b.AccountID AND GroupID = @groupID
	ELSE
		SELECT a.[GroupDebtID],a.[GroupID],b.[AccountID],a.[LastEditDate],a.[PaymentAllocationRuleID],IsNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrimary], 0) [IsPrimary], b.InvoiceNumber
				,Case When c.IsInclude is not NULL Then 1 Else 0 End IsGrouped
				,GroupName
		FROM Account b 
			LEFT JOIN (SELECT * FROM Legal_GroupDebts WHERE GroupID = 0) a ON a.AccountID = b.AccountID
			LEFT JOIN (Select AccountID, IsInclude, (b.Code+'' - ''+b.Description) as GroupName 
						From Legal_GroupDebts a, Legal_Groups b where a.GroupID=b.GroupID and IsInclude = 1 and b.Status <> ''R'') c ON b.AccountID = c.AccountID
		WHERE b.DebtorID = @debtorID

END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 07/18/2008 10:09:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debtors with Account No. and Customer ''s fullName
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate] ,a.[RelationshipTypeID] ,a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				JOIN PersonInformation p ON a.PersonID = p.PersonID
				JOIN Account b ON a.AccountID = b.AccountID
		WHERE a.GroupID = @groupID
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	ELSE
	Begin
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate] ,a.[RelationshipTypeID] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				JOIN PersonInformation p ON g.PersonID = p.PersonID
				JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a 
				ON g.PersonID = a.PersonID
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate] ,a.[RelationshipTypeID] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + '' '' + p.FirstName + '' '' + p.MiddleName + '' '' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a 
				ON g.PersonID = a.PersonID
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID)
		
		ORDER BY Seq, b.AccountID, FullName
	End
END
' 
END
GO

-- Scripts 2.2.7:

-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 18, 2008
-- Description:		Add column AgentID
-- Effected table:	Legal_GroupSteps
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_GroupSteps' and c.name = 'AgentID')
BEGIN
	ALTER TABLE Legal_GroupSteps
	ADD AgentID int NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_GroupSteps' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_GroupSteps
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_GroupSteps_RowStatus] DEFAULT 'A'
END
GO

-- Scripts 2.2.8:

-- =======================================================================
-- Author:			Minh dam
-- Create date:		Jul 18, 2008
-- Description:		Add column RelativeImagePath and set primary key ImageID to automated increment
-- Effected table:	Image
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id 
WHERE o.name = 'Image' and c.name = 'RelativeImagePath')
BEGIN
	ALTER TABLE dbo.Image 
		ADD RelativeImagePath [varchar](1000) NULL	
END
GO

-- =======================================================================
-- Author:			Tuan Luong
-- Create date:		Jul 18, 2008
-- Description:		Add column [Value]
-- Effected table:	Legal_CustomFields
-- =======================================================================
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_CustomFields' and c.name = 'Value')
BEGIN
	ALTER TABLE Legal_CustomFields
	ALTER COLUMN [Value] NVARCHAR(1000) NULL
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_GetEmployeeNextPoolAccount]    Script Date: 07/19/2008 14:05:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetEmployeeNextPoolAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetEmployeeNextPoolAccount]    Script Date: 07/19/2008 14:05:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetEmployeeNextPoolAccount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount] 
	@v_employeeId int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='''' 
		   SET @v_SortOrder = '' "QueueDate" DESC''

    Set @orderByClause = ''ORDER BY '' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = ''WHERE RowIndex BETWEEN '' + CAST(@BeginIndex as varchar(10)) + '' AND '' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = '' ''
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = '' SELECT (CONVERT(varchar(10), a.DebtorID) + ''''|'''' + CONVERT(varchar(10), a.AccountID)) AS KeyField,''
				+ ''   a.QueueDate AS [QueueDate],''
				+ ''   a.AccountAge AS [DPD],''
				+ ''   a.MCode AS [Bucket],''
				+ ''   a.CCode AS [Cycle],''
				+ ''   a.BillAmount AS [Bill Amount],''
				+ ''   a.BillBalance AS [Bill Balance],''
				+ ''   s.ShortDesc AS [Status],''
				+ ''   s.SortPriority AS [Priority],''
				+ ''   a.AssignmentType AS [Assignment Type],''
				+ ''   p.SocialSecurityNumber AS [ID],''
				+ ''   (rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName)) AS [Name]''
				+ '' FROM Account a''
				+ '' INNER JOIN Accountother o ON o.AccountID = a.AccountID''
				+ '' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID''
				+ '' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID''
				+ '' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID''
				+ '' WHERE''
				+ ''   a.QueueDate<=GetDate()''
				+ ''   AND (a.EmployeeID = ''+CAST(@v_employeeId as varchar(9))+'' OR a.TempEmployeeID = ''+CAST(@v_employeeId as varchar(9))+'')''
				+ ''   AND a.DebtorID <> 0''
				+ ''   AND a.AgencyStatusID <> 2''
				+ ''	  AND a.SystemStatusID in (1,5)''
				+ ''	  AND a.PoolSelected = 0''

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = ''WITH AccountResults AS ''
				   + ''( ''
				   + ''  SELECT *, ROW_NUMBER() OVER ('' + @orderByClause + '') as RowIndex ''
				   + ''  FROM ( ''	
				   + ''          {0}''
				   + ''    ) A ''
				   + '') ''
				   + ''   ''
				   + ''SELECT top 1 KeyField, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]''
				   + ''FROM AccountResults ''
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, ''{0}'', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
		
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = ''SELECT @RowCountOut=count(*) FROM ( {0} ) A''
    SET @rowCountStmt = REPLACE(@rowCountStmt, ''{0}'', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = ''@RowCountOut int OUTPUT''
	
	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	if (@RowCount > 1)
		RETURN 2

	RETURN @RowCount
END

' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 07/18/2008 10:09:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 07/18/2008 10:09:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-14
-- Description:	Get the list of Groups of selecting customer
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
	-- Add the parameters for the stored procedure here
	@debtorID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
    SELECT
		ROW_NUMBER() OVER (ORDER BY G.Code) AS RowNumber,
		G.*	
	INTO #Temp
	FROM (SELECT DISTINCT
		a.GroupID,
		a.Code,
		a.[Description],
		Case When d.GroupID is not null then 1 else 0 end HasStep
		FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
			LEFT JOIN Account c ON b.AccountID = c.AccountID
			LEFT JOIN (Select distinct GroupID from Legal_GroupSteps) d ON a.GroupID = d.GroupID
		WHERE  a.Status <> ''R'' and c.DebtorID = @debtorID) G
	ORDER BY G.Code	

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT *
	FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
	
END
' 
END
GO
-- Scripts 2.2.9:

/****** Object:  StoredProcedure [dbo].[CWX_GetEmployeeNextPoolAccount]    Script Date: 07/21/2008 11:47:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetEmployeeNextPoolAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetEmployeeNextPoolAccount]    Script Date: 07/21/2008 11:47:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetEmployeeNextPoolAccount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount] 
	@v_employeeId int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='''' 
		   SET @v_SortOrder = '' "QueueDate" DESC''

    Set @orderByClause = ''ORDER BY '' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = ''WHERE RowIndex BETWEEN '' + CAST(@BeginIndex as varchar(10)) + '' AND '' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = '' ''
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = '' SELECT (CONVERT(varchar(10), a.DebtorID) + ''''|'''' + CONVERT(varchar(10), a.AccountID)) AS KeyField,''
				+ ''   a.QueueDate AS [QueueDate],''
				+ ''   a.AccountAge AS [DPD],''
				+ ''   a.MCode AS [Bucket],''
				+ ''   a.CCode AS [Cycle],''
				+ ''   a.BillAmount AS [Bill Amount],''
				+ ''   a.BillBalance AS [Bill Balance],''
				+ ''   s.ShortDesc AS [Status],''
				+ ''   s.SortPriority AS [Priority],''
				+ ''   a.AssignmentType AS [Assignment Type],''
				+ ''   p.SocialSecurityNumber AS [ID],''
				+ ''   (rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName)) AS [Name]''
				+ '' FROM Account a''
				+ '' INNER JOIN Accountother o ON o.AccountID = a.AccountID''
				+ '' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID''
				+ '' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID''
				+ '' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID''
				+ '' WHERE''
				+ ''   a.QueueDate<=GetDate()''
				+ ''   AND a.EmployeeID = ''+CAST(@v_employeeId as varchar(9))
				+ ''   AND a.DebtorID <> 0''
				+ ''   AND a.AgencyStatusID <> 2''
				+ ''	  AND a.SystemStatusID in (1,5)''
				+ ''	  AND a.PoolSelected = 0''

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = ''WITH AccountResults AS ''
				   + ''( ''
				   + ''  SELECT *, ROW_NUMBER() OVER ('' + @orderByClause + '') as RowIndex ''
				   + ''  FROM ( ''	
				   + ''          {0}''
				   + ''    ) A ''
				   + '') ''
				   + ''   ''
				   + ''SELECT top 1 KeyField, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]''
				   + ''FROM AccountResults ''
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, ''{0}'', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
		
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = ''SELECT @RowCountOut=count(*) FROM ( {0} ) A''
    SET @rowCountStmt = REPLACE(@rowCountStmt, ''{0}'', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = ''@RowCountOut int OUTPUT''
	
	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	if (@RowCount > 1)
		RETURN 2

	RETURN @RowCount
END

' 
END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: Jul 21, 2008>
-- Description:	Drop the table DefineImageType
-- Effected table: DefineImageType
-- =============================================
/****** Object:  Table [dbo].[DefineImageType]    Script Date: 07/21/2008 14:48:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DefineImageType]') AND type in (N'U'))
DROP TABLE [dbo].[DefineImageType]

-- =============================================
-- Author:		Minh Dam
-- Create date: Jul 21, 2008>
-- Description:	Drop column ImageTypeID and add new column Description for Image table
-- Effected table: Image
-- =============================================
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Image' and c.name = 'ImageTypeID')
BEGIN
	ALTER TABLE [dbo].[Image]
		DROP COLUMN ImageTypeID		
END

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Image' and c.name = 'Description')
BEGIN
	ALTER TABLE [dbo].[Image]
		ADD [Description] nvarchar(100) NULL
END

IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Image' and c.name = 'Description')
BEGIN
	UPDATE [dbo].[Image] SET [Description] = '' WHERE [Description] IS NULL
	ALTER TABLE [dbo].[Image]
		ALTER COLUMN [Description] nvarchar(100) NOT NULL
END

-- =============================================
-- Author:		Minh Dam
-- Create date: Jul 21, 2008>
-- Description:	Set primary key ImageID to IDENTITY(1,1)
-- Effected table: Image
-- =============================================
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Image' and c.name = 'ImageID')
BEGIN
	ALTER TABLE [dbo].[Image]
		DROP CONSTRAINT [PK_Image]

	ALTER TABLE [dbo].[Image]
		DROP COLUMN [ImageID]

	ALTER TABLE [dbo].[Image]
		ADD [ImageID] [int] IDENTITY(1,1) NOT NULL

	ALTER TABLE [dbo].[Image]
		ADD CONSTRAINT [PK_Image] PRIMARY KEY CLUSTERED 
		(
			[ImageID] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
END
GO

update QueryMaster set SQL2='EXEC CWX_GetEmployeeNextPoolAccount %E, %1' where ID=26
GO
drop procedure CWX_Account_UnlockAllPoolAccount
GO
drop procedure CWX_Account_UnlockPoolAccount
GO

/****** Object:  StoredProcedure [dbo].[CWX_GetEmployeeNextPoolAccount]    Script Date: 07/21/2008 15:34:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetEmployeeNextPoolAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetEmployeeNextPoolAccount]    Script Date: 07/21/2008 15:34:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetEmployeeNextPoolAccount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount] 
	@v_currentLoginEmployeeId int,
	@v_employeeId int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='''' 
		   SET @v_SortOrder = '' "QueueDate" DESC''

    Set @orderByClause = ''ORDER BY '' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = ''WHERE RowIndex BETWEEN '' + CAST(@BeginIndex as varchar(10)) + '' AND '' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = '' ''
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt =  '' SELECT a.DebtorID, a.AccountID,''
				+ ''   a.QueueDate AS [QueueDate],''
				+ ''   a.AccountAge AS [DPD],''
				+ ''   a.MCode AS [Bucket],''
				+ ''   a.CCode AS [Cycle],''
				+ ''   a.BillAmount AS [Bill Amount],''
				+ ''   a.BillBalance AS [Bill Balance],''
				+ ''   s.ShortDesc AS [Status],''
				+ ''   s.SortPriority AS [Priority],''
				+ ''   a.AssignmentType AS [Assignment Type],''
				+ ''   p.SocialSecurityNumber AS [ID],''
				+ ''   (rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName)) AS [Name]''
				+ '' FROM Account a''
				+ '' INNER JOIN Accountother o ON o.AccountID = a.AccountID''
				+ '' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID''
				+ '' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID''
				+ '' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID''
				+ '' WHERE''
				+ ''   a.QueueDate<=GetDate()''
				+ ''   AND a.EmployeeID = ''+CAST(@v_employeeId as varchar(9))
				+ ''   AND a.DebtorID <> 0''
				+ ''   AND a.AgencyStatusID <> 2''
				+ ''	  AND a.SystemStatusID in (1,5)''
				+ ''	  AND a.PoolSelected = 0''

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = ''WITH AccountResults AS ''
				   + ''( ''
				   + ''  SELECT *, ROW_NUMBER() OVER ('' + @orderByClause + '') as RowIndex ''
				   + ''  FROM ( ''	
				   + ''          {0}''
				   + ''    ) A ''
				   + '') ''
				   + ''   ''
				   + ''SELECT top 1 DebtorID, AccountID, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name] INTO #PoolAccount ''
				   + ''FROM AccountResults ''
				   + @pagingWhereClause	
				   + '' DECLARE @AccountID int ''
				   + '' DECLARE @DebtorID int ''
				   + '' SELECT @AccountID=AccountID, @DebtorID=DebtorID FROM #PoolAccount ''
				   + '' EXEC CWX_Account_UpdatePoolStatus @AccountID, @DebtorID, '' + STR(@v_currentLoginEmployeeId)
				   + '' SELECT (CONVERT(varchar(10), DebtorID) + ''''|'''' + CONVERT(varchar(10), AccountID)) AS KeyField, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name] ''
				   + '' FROM #PoolAccount ''

    SET @finalStmt = REPLACE(@finalStmt, ''{0}'', @cStmt)

	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
		
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = ''SELECT @RowCountOut=count(*) FROM ( {0} ) A''
    SET @rowCountStmt = REPLACE(@rowCountStmt, ''{0}'', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = ''@RowCountOut int OUTPUT''
	
	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	if (@RowCount > 1)
		RETURN 2

	RETURN @RowCount
END

' 
END
GO

alter table Settlement add InterestPercentage real
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: Jul 21, 2008>
-- Description:	Create store procedure Legal_Agents_GetPagingList
-- =============================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Agents_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Agents_GetPagingList]

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Agents_GetPagingList]    Script Date: 07/21/2008 17:30:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Legal_Agents_GetPagingList]
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	SELECT ROW_NUMBER() OVER(ORDER BY b.[Code]) as RowNumber,
			a.AgentID, a.[Code], a.[Name], a.[Description] ,
			b.[Code] + ' - ' + b.[Description] as AgentType,
			c.[Code] + ' - ' + c.[Description]  as AgentSubtype 
	INTO #temp
	FROM Legal_Agents a
		LEFT JOIN Legal_AgentTypes b ON a.[AgentTypeID] = b.[AgentTypeID]
		LEFT JOIN Legal_AgentSubtypes c ON a.[AgentSubtypeID] = c.[AgentSubtypeID]
	WHERE a.Status <> 'R'
	ORDER BY RowNumber
	
	Declare @RowCount int
	Set @RowCount = @@ROWCOUNT	

	SELECT 	[AgentID], [Code], [Name], [Description], [AgentType], [AgentSubtype]
	FROM #temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_Document_GetLettersByType]    Script Date: 07/21/2008 17:43:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Document_GetLettersByType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Document_GetLettersByType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Document_GetLettersByType]    Script Date: 07/21/2008 17:43:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Document_GetLettersByType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-------------------------------------------------------
-- Description: Get Letters by letter type and client ID.
-- History:
--	2008/07/21	[Binh Truong]	Init version.
-------------------------------------------------------
CREATE PROCEDURE dbo.CWX_Document_GetLettersByType
(
	@LetterType int,
	@ClientID int = 0
)
AS
BEGIN
	SELECT * 
	FROM DefineLetters 
	WHERE	LetterType = @LetterType AND 
			(ClientID = 0 OR ClientID = @ClientID) 
	ORDER BY LetterDesc
END
' 
END
GO

/******  Script Closed. Go next: Step016_3  ******/