﻿/****** Object:  StoredProcedure [dbo].[CWX_Account_Queue_NoActivityInXDays]    Script Date: 05/06/2009 17:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_Queue_NoActivityInXDays] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lNumberOfDays int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	DECLARE @index int
	SET @index = charindex('|', @EmpList)	
	SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			e.EmployeeName As [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()))
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_Queue_NoContactInXDays]    Script Date: 05/06/2009 17:27:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_Queue_NoContactInXDays] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lNumberOfDays int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @index int

	SET @index = charindex('|', @EmpList)
	SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()) and ActionID in (select ActionID from AvailableActions where productivityid = 3))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			e.EmployeeName As [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()) and ActionID in (select ActionID from AvailableActions where productivityid = 3))
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralItemType]    Script Date: 05/06/2009 17:34:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralItemType] 
	@v_employeeId int,
	@ItemID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @index int

	SET @index = charindex('|', @EmpList)
	SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.CollateralType = @ItemID

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.CollateralType = @ItemID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.CollateralType = @ItemID

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.CollateralType = @ItemID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralByEmployee]    Script Date: 05/06/2009 17:36:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralByEmployee] 
	@v_employeeId int,
	@cEmployeeID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @index int

	SET @index = charindex('|', @EmpList)
	SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.EmployeeID = @cEmployeeID 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.EmployeeID = @cEmployeeID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.EmployeeID = @cEmployeeID 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.EmployeeID = @cEmployeeID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralItemType]    Script Date: 12/30/2008 16:43:37 ******/
SET ANSI_NULLS ON


/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralStage]    Script Date: 05/06/2009 17:37:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralStage] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@cStageID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @index int

	SET @index = charindex('|', @EmpList)
	SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.CollateralStage = @cStageID 


	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.CollateralStage = @cStageID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.CollateralStage = @cStageID 


	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.CollateralStage = @cStageID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralByEmployee]    Script Date: 12/30/2008 16:42:10 ******/
SET ANSI_NULLS ON


/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralNextAction]    Script Date: 05/06/2009 17:38:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralNextAction] 
	@v_employeeId int,
	@cNextAction int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @index int

	SET @index = charindex('|', @EmpList)
	SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.NextAction = @cNextAction 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.NextAction = @cNextAction
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.NextAction = @cNextAction 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.NextAction = @cNextAction
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
END
GO

/****** Object:  StoredProcedure [dbo].[SearchByLegalGroupCode]    Script Date: 05/06/2009 17:40:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		KhoaDang
ALTER PROCEDURE [dbo].[SearchByLegalGroupCode](@GroupCode varchar(20),@EmpList varchar(3000)) As
BEGIN

	DECLARE @index int

	SET @index = charindex('|', @EmpList)
	SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s,'
	SET @cStmt=@cStmt+'Legal_Groups g'
	SET @cStmt=@cStmt+' where a.AccountID = g.GroupedAccountID'
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID and g.Code=' + '''' + RTRIM(@GroupCode) + ''''
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
	Exec SP_ExecuteSQL @cStmt
END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON


/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalEmployee]    Script Date: 05/06/2009 17:45:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalEmployee] 
	@v_employeeId int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @index int

	SET @index = charindex('|', @EmpList)
	SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 05/06/2009 17:46:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalForward] 
	@SolicitorID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @index int

	SET @index = charindex('|', @EmpList)
	SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
		INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
	WHERE
		a.DebtorID <> 0
        And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
			INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
		WHERE
			a.DebtorID <> 0
			And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
		INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
	WHERE
		a.DebtorID <> 0
        And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
			INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
		WHERE
			a.DebtorID <> 0
			And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralStage]    Script Date: 12/30/2008 16:15:31 ******/
SET ANSI_NULLS ON


/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalAgent]    Script Date: 05/06/2009 17:48:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	
-- History:
--	2008/04/21	[Sathya]		Init version.
--	2008/08/14	[Binh Truong]	la.Status = 'A'  >>>  la.Status <> 'R'
--	2008/09/25	[Sathya]		la.Status <> 'R'  >>>  la.Status = 'A'
--								Add criteria lg.GroupID = ld.GroupID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalAgent] 
	@AgentId int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @index int

	SET @index = charindex('|', @EmpList)
	SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
		INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
	WHERE
		a.DebtorID <> 0
		And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
			INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
		WHERE
			a.DebtorID <> 0
            And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
		INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
	WHERE
		a.DebtorID <> 0
		And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
			INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
		WHERE
			a.DebtorID <> 0
            And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_SeachPersonInformation]    Script Date: 05/12/2009 17:27:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Morris Mervin Mendoza
-- Create date: 9:50 AM 1/15/2009
-- Description:	
-- History:
--	[12 May 2009]	Minh Dam	Change to dynamic sql
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Employee_SeachPersonInformation]
	-- Add the parameters for the stored procedure here
	@CustomerName varchar(50) = '',
	@PhoneNumber varchar(50) = '',
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN

	SET NOCOUNT ON;	
	DECLARE @Sql nvarchar(1000), @NewLine char(2)
	DECLARE @RowCount int
	SET @NewLine = '
'

	CREATE TABLE #Temp
	(
		RowNumber int,
		PersonID int,
		CustomerName varchar(50),
		RelationshipNumber varchar(50),
		ID varchar(25)
	)
	
	SET @Sql =  
			'INSERT INTO #Temp'
			+ ' SELECT ROW_NUMBER() OVER (ORDER BY a.PersonID) as RowNumber, a.PersonID,'
			+ ' (a.FirstName + '' ,'' + a.MiddleName + '' ,'' + a.LastName) as CustomerName,'
			+ ' b.GroupName,'
			+ ' a.SocialSecurityNumber'
			+ ' FROM [dbo].[PersonInformation] a'
			+ '	INNER JOIN [dbo].[DebtorInformation] b on a.PersonID = b.PersonID'
			+ ' WHERE 1=1'
			+ ' @@CustomerNameCondition'
			+ ' @@PhoneNumberCondition'	+ @NewLine
	
	SET @Sql = @Sql + 'SET @RowCount = @@ROWCOUNT' + @NewLine
					+ 'IF @PageSize <= 0'
					+	'	SELECT * FROM #Temp'
					+ ' ELSE'
					+	'	SELECT * FROM #Temp'
					+		'	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize' 
					+ @NewLine
	SET @Sql = @Sql + 'DROP TABLE #Temp'


	IF (@CustomerName <> '')
		SET @Sql = REPLACE(@Sql, '@@CustomerNameCondition', 'AND (a.FirstName LIKE (''%' + @CustomerName + '%'')'
														+ ' OR a.MiddleName LIKE (''%' + @CustomerName + '%'')' 
														+ ' OR a.LastName LIKE (''%' + @CustomerName + '%''))')
	ELSE
		SET @Sql = REPLACE(@Sql, '@@CustomerNameCondition', '')	

	IF (@PhoneNumber <> '')
		SET @Sql = REPLACE(@Sql, '@@PhoneNumberCondition', 'AND a.PersonID IN (SELECT PersonID FROM PersonPhone WHERE PhoneNumber LIKE (''%' + @PhoneNumber + '%''))')
	ELSE
		SET @Sql = REPLACE(@Sql, '@@PhoneNumberCondition', '')
	
	DECLARE @Params nvarchar(100)
	SET @Params = '@PageSize int, @PageIndex int, @RowCount int OUTPUT'
	EXEC sp_executesql @Sql, @Params, @PageSize, @PageIndex, @RowCount OUTPUT

	RETURN @RowCount
END
GO


/****** Object:  StoredProcedure [dbo].[SearchDebtorBySocial]    Script Date: 05/12/2009 17:29:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchDebtorBySocial](@Social char(25),@EmpList varchar(3000)) As
BEGIN

DECLARE @employeeID varchar(50)
DECLARE @index int

SET @index = charindex('|', @EmpList)
SET @employeeID = substring(@EmpList, 1, @index -1)
SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.DebtorID As [DebtorID],'
	SET @cStmt=@cStmt+'a.InvoiceNumber As [Account No.],'
	SET @cStmt=@cStmt+'convert(char(10), a.QueueDate, 111) as [QueueDate],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'CAST(a.MCode AS CHAR(2)) as [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'a.Minimum_due  as [Minimum Due],'
	SET @cStmt=@cStmt+'p.SocialSecurityNumber as [ID],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p'
SET @cStmt=@cStmt+' where p.SocialSecurityNumber = '+''''+Cast(@Social As Char(25))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and d.PersonID = p.PersonID'
	SET @cStmt=@cStmt+' and a.DebtorID <> 0 and a.AgencyStatusID <> 2 and a.SystemStatusID <> 2 and a.AccountAge > 0 and a.BillBalance > 0'

	SELECT * INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
	SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'

	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end

Exec SP_ExecuteSQL @cStmt
END
GO
