-- Script is applied on version 2.1.1
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetList]    Script Date: 07/01/2008 15:18:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetList]    Script Date: 07/01/2008 15:18:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetList]
	@RuleID int
AS
BEGIN	
	SET NOCOUNT ON;
	CREATE TABLE #Temp
	(
		COLUMN_NAME varchar(125),
		DESCRIPTION varchar(125),
		DATA_TYPE varchar(125),
		[DATABASE] varchar(125)		
	)

	DECLARE @RuleType tinyint
    SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID	

	IF @RuleType <> 3
	BEGIN
		CREATE TABLE #TempTableInfoList
		(
			TableID int,
			TableName varchar(125)
		)
		DECLARE @InterfaceDBName varchar(125)
		SET @InterfaceDBName = ''''	

		IF (@RuleType = 1 or @RuleType = 4) -- Allocation Rule or Temporary Rule
		BEGIN
			DECLARE @AllocationTables VARCHAR(2000)		
			SET @AllocationTables = ''Account,AccountOther,DebtorInformation,PersonInformation,PersonAddress''
			
			INSERT #TempTableInfoList
			SELECT object_id, SplitedText		
			FROM CWX_FnSplitString (@AllocationTables,'','')
			INNER JOIN sys.objects
			ON name = SplitedText
		END
		ELSE IF (@RuleType = 2) -- Extraction Rule
		BEGIN	
			DECLARE @AccountTableName varchar(125)		
			SELECT TOP 1 @InterfaceDBName = InterfaceDBName, @AccountTableName = AccountTable
			FROM Interface WHERE AccountTable is not NULL or AccountTable <> ''''
			ORDER BY InterfaceID

			SET @InterfaceDBName = @InterfaceDBName + ''.''
			SET @AccountTableName = @AccountTableName + '',''

			DECLARE @SelectTableInfoStatement varchar(2000)
			SET @SelectTableInfoStatement = ''INSERT #TempTableInfoList SELECT object_id, SplitedText FROM CWX_FnSplitString ('''''' + @AccountTableName + '''''','''','''')  
											INNER JOIN '' + @InterfaceDBName + ''sys.objects o 
											ON o.name = SplitedText''
			EXEC(@SelectTableInfoStatement)
		END
		
		DECLARE @SelectDescriptionStatement varchar(2000)
		SET @SelectDescriptionStatement = ''INSERT #Temp ''
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + 
			''SELECT [COLUMN_NAME] = o.name + ''''.'''' + ltrim(rtrim(c.name)),		  
			[DESCRIPTION] = dbo.CWX_RuleCriteria_FnProcessDescription (ltrim(rtrim(convert(varchar(125), ex.value)))),  
			[DATA_TYPE] = upper(ty.name), 
			[DATABASE] = ''''''
		IF @InterfaceDBName <> ''''	
			SET @SelectDescriptionStatement = @SelectDescriptionStatement + SUBSTRING(@InterfaceDBName, 1, DATALENGTH(@InterfaceDBName) - 1) + ''''''''
		ELSE
			SET @SelectDescriptionStatement = @SelectDescriptionStatement + ''''''''	
		  
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + '' FROM '' +
			@InterfaceDBName + ''sys.objects o 
		INNER JOIN '' +  
			@InterfaceDBName + ''sys.columns c 
		ON 
			o.object_id = c.object_id  
		LEFT OUTER JOIN '' +
			@InterfaceDBName + ''sys.extended_properties ex  
		ON  
			ex.major_id = c.object_id  
			AND ex.minor_id = c.column_id  
			AND ex.name = ''''MS_Description''''  
		LEFT OUTER JOIN '' + 
			@InterfaceDBName + ''sys.types ty  
		ON  
			ty.system_type_id = c.system_type_id		 		 
		WHERE  
			c.object_id in (SELECT TableID FROM #TempTableInfoList)
			AND ex.value is not NULL AND ex.value <> ''''''''
		ORDER  
			BY [DESCRIPTION]''
		
		EXEC (@SelectDescriptionStatement)		
		
		SELECT r.*, t.DESCRIPTION
		FROM RuleCriteria r
		INNER JOIN #Temp t ON r.Criteria = t.COLUMN_NAME
		WHERE RuleID = @RuleID
		ORDER BY ID

		DROP TABLE #TempTableInfoList
		DROP TABLE #Temp
	END
	ELSE --Result Processing Rule
	BEGIN
		SELECT *, Criteria AS DESCRIPTION
		FROM RuleCriteria
		WHERE RuleID = @RuleID
		ORDER BY ID
	END
END

' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]    Script Date: 07/01/2008 14:58:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]    Script Date: 07/01/2008 14:58:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]
	@RuleType int		
AS
BEGIN
	SET NOCOUNT ON;

	CREATE TABLE #TempTableInfoList
	(
		TableID int,
		TableName varchar(125)
	)
	DECLARE @InterfaceDBName varchar(125)
	SET @InterfaceDBName = ''''	

	IF (@RuleType = 1 or @RuleType = 4) -- Allocation Rule or Temporary Rule
	BEGIN
		DECLARE @AllocationTables VARCHAR(2000)		
		SET @AllocationTables = ''Account,AccountOther,DebtorInformation,PersonInformation,PersonAddress''
		
		INSERT #TempTableInfoList
		SELECT object_id, SplitedText		
		FROM CWX_FnSplitString (@AllocationTables,'','')
		INNER JOIN sys.objects
		ON name = SplitedText
	END
	ELSE IF (@RuleType = 2) -- Extraction Rule
	BEGIN	
		DECLARE @AccountTableName varchar(125)		
		SELECT TOP 1 @InterfaceDBName = InterfaceDBName, @AccountTableName = AccountTable
		FROM Interface WHERE AccountTable is not NULL or AccountTable <> ''''
		ORDER BY InterfaceID

		SET @InterfaceDBName = @InterfaceDBName + ''.''
		SET @AccountTableName = @AccountTableName + '',''

		DECLARE @SelectTableInfoStatement varchar(2000)
		SET @SelectTableInfoStatement = ''INSERT #TempTableInfoList SELECT object_id, SplitedText FROM CWX_FnSplitString ('''''' + @AccountTableName + '''''','''','''')  
										INNER JOIN '' + @InterfaceDBName + ''sys.objects o 
										ON o.name = SplitedText''
		EXEC(@SelectTableInfoStatement)
	END

	DECLARE @SelectDescriptionStatement varchar(2000)
	SET @SelectDescriptionStatement = ''SELECT [COLUMN_NAME] = o.name + ''''.'''' + ltrim(rtrim(c.name)),		  
		[DESCRIPTION] = dbo.CWX_RuleCriteria_FnProcessDescription (ltrim(rtrim(convert(varchar(125), ex.value)))),  
		[DATA_TYPE] = upper(ty.name), c.max_length, c.precision, 
		[DATABASE] = ''''''
	IF @InterfaceDBName <> ''''	
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + SUBSTRING(@InterfaceDBName, 1, DATALENGTH(@InterfaceDBName) - 1) + ''''''''
	ELSE
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + ''''''''	
	  
	SET @SelectDescriptionStatement = @SelectDescriptionStatement + '' FROM '' +
		@InterfaceDBName + ''sys.objects o 
	INNER JOIN '' +  
		@InterfaceDBName + ''sys.columns c 
	ON 
		o.object_id = c.object_id  
	LEFT OUTER JOIN '' +
		@InterfaceDBName + ''sys.extended_properties ex  
	ON  
		ex.major_id = c.object_id  
		AND ex.minor_id = c.column_id  
		AND ex.name = ''''MS_Description''''  
	LEFT OUTER JOIN '' + 
		@InterfaceDBName + ''sys.types ty  
	ON  
		ty.system_type_id = c.system_type_id  
	WHERE  
		c.object_id in (SELECT TableID FROM #TempTableInfoList)
		AND ex.value is not NULL AND ex.value <> ''''''''
	ORDER  
		BY [DESCRIPTION]''
	
	EXEC (@SelectDescriptionStatement)
	DROP TABLE #TempTableInfoList
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Notes_GetWithType]    Script Date: 07/03/2008 13:28:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Notes_GetWithType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Notes_GetWithType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Notes_GetWithType]    Script Date: 07/03/2008 13:28:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Tai Ly
-- Create date: May 08, 1008
-- Description:	Get notes from database
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Notes_GetWithType] 	
	-- Add the parameters for the stored procedure here
	@DebtorID	int,
	@AccountID	int,
	@NoteText	varchar(1000) = '',
	@NoteType	varchar(1) = ' ',	
	@Month		int = -1,
	@Day		int = -1,
	@FromDate	datetime = '1753-01-01',
	@ToDate		datetime = '9999-12-31',
	@SearchHistory bit = 0,
	@PageSize	int = 10,
	@PageIndex	int = 0
AS
BEGIN
	Declare @IdentityTableValue int

	DECLARE @TempTableVar table(
		RowNumber		int,
		NoteDateTime	datetime,
		NoteText		varchar(1000),
		NoteType		varchar(1),
		UserID			varchar(10)
	);

	IF @Month >= 0
	BEGIN
		SET @FromDate = DATEADD(month, -1*@Month, GETDATE())
		SET @ToDate = GETDATE()
	END
	ELSE IF @Day >= 0
	BEGIN
		SET @FromDate = DATEADD(day, -1*@Day, GETDATE())
		SET @ToDate = GETDATE()
	END

	SELECT @IdentityTableValue = ISNULL(FieldValue, -1) FROM IdentityFields WHERE TableName = 'NotesDisplayByAccount'

	IF (@IdentityTableValue < 0)
			INSERT INTO IdentityFields VALUES('NotesDisplayByAccount',0)

	SELECT @NoteText = '%' + @NoteText + '%';

	IF @SearchHistory = 0
		INSERT INTO @TempTableVar
		SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID
		FROM		NotesCurrent n, Employee e
		WHERE		((@IdentityTableValue <= 0 AND n.DebtorID = @DebtorID) OR n.BillID = @AccountID)
					AND n.EmployeeID *= e.EmployeeID 
					AND (@NoteType = ' ' OR UPPER(NoteType) = UPPER(@NoteType))
					AND n.NoteText LIKE @NoteText
					AND (DATEDIFF(day, @FromDate, n.NoteDateTime)>=0 AND DATEDIFF(day, n.NoteDateTime, @ToDate)>=0)
	ELSE
		INSERT INTO @TempTableVar
		SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID
		FROM		NotesHistory n, Employee e
		WHERE		((@IdentityTableValue <= 0 AND n.DebtorID = @DebtorID) OR n.BillID = @AccountID)
					AND n.EmployeeID *= e.EmployeeID 
					AND (@NoteType = ' ' OR UPPER(NoteType) = UPPER(@NoteType))
					AND n.NoteText LIKE @NoteText
					AND (DATEDIFF(day, @FromDate, n.NoteDateTime)>=0 AND DATEDIFF(day, n.NoteDateTime, @ToDate)>=0)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
	ELSE
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
		WHERE	RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize)		

	RETURN @RowCount

END
GO
/******  Script Closed. Go next: Step015_2  ******/