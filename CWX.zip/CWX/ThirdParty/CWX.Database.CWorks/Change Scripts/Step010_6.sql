  -- Scripts are applied on version 1.5.6
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Tai Ly
-- Create date: May 08, 1008
-- Description:	Get notes from database
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Notes_GetWithType] 	
	-- Add the parameters for the stored procedure here
	@DebtorID	int,
	@AccountID	int,
	@NoteText	varchar(256) = '',
	@NoteType	varchar(1) = ' ',	
	@Month		int = -1,
	@Day		int = -1,
	@FromDate	datetime = '1753-01-01',
	@ToDate		datetime = '9999-12-31',
	@PageSize	int = 10,
	@PageIndex	int = 0
AS
BEGIN
	Declare @IdentityTableValue int

	DECLARE @TempTableVar table(
		RowNumber		int,
		NoteDateTime	datetime,
		NoteText		varchar(700),
		NoteType		varchar(1),
		UserID			varchar(10)
	);

	Set @IdentityTableValue = (Select FieldValue from IdentityFields where TableName = 'NotesDisplayByAccount')
	IF (@IdentityTableValue <= 0 )
	BEGIN 						
			IF (@IdentityTableValue < 0)
			BEGIN
				Insert into IdentityFields values('NotesDisplayByAccount',0)
			END
			IF (@NoteType = ' ') -- all note type			
			BEGIN						
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN													
						SELECT @NoteText = '%' + @NoteText + '%';											
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate)								
										AND n.NoteText LIKE @NoteText										
					
				END
				ELSE IF @Month = -1	-- no month input
				BEGIN													
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID 
										AND n.NoteText LIKE @NoteText AND																	
										n.NoteDateTime >= DATEADD(day, -1*@Day, GETDATE())  																					
					
				END
				ELSE	-- no day input
				BEGIN													
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID 
										AND n.NoteText LIKE @NoteText AND										
										n.NoteDateTime >= DATEADD(month, -1*@Month, GETDATE())
				END
			END
			ELSE
			BEGIN	-- has note type
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) AND n.NoteText LIKE @NoteText											

				END
				ELSE IF @Month = -1		-- no month input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND n.NoteText LIKE @NoteText AND
										n.NoteDateTime >= DATEADD(day, -1*@Day, GETDATE())
							ORDER BY	n.NoteDateTime DESC, n.NoteID			
				END
				ELSE -- no day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND n.NoteText LIKE @NoteText AND
										n.NoteDateTime >= DATEADD(month, -1*@Month, GETDATE())													
				END
			END
	END	
	ELSE		
	BEGIN
			IF (@NoteType = ' ')	-- no note type			
			BEGIN
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) 
										AND n.NoteText LIKE @NoteText							

				END
				ELSE IF (@Month = -1)	-- no month input
				BEGIN
					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID 
										AND n.NoteText LIKE @NoteText AND
										n.NoteDateTime >= DATEADD(day, -1*@Day, GETDATE())						
					
				END
				ELSE	-- no day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID
										AND n.NoteText LIKE @NoteText AND
										n.NoteDateTime >= DATEADD(month, -1*@Month, GETDATE())														
				END				
			END
			ELSE	-- has note type
			BEGIN
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  AND UPPER(NoteType) = UPPER(@NoteType) 
										AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) AND n.NoteText LIKE @NoteText							
					
				END
				ELSE IF @Month = -1			-- no month input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  AND UPPER(NoteType) = UPPER(@NoteType) 
										AND n.NoteText LIKE @NoteText AND
										n.NoteDateTime >= DATEADD(day, -1*@Day, GETDATE())																	
				END
				ELSE						-- no day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)
										AND n.NoteText LIKE @NoteText AND
										n.NoteDateTime >= DATEADD(month, -1*@Month, GETDATE())					

				END					
			END
	END		

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
	ELSE
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
		WHERE	RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize)		

	RETURN @RowCount

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_TransactionSummary]    Script Date: 05/08/2008 16:57:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionSummary]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TransactionSummary]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TransactionSummary]    Script Date: 05/08/2008 16:57:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionSummary]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<khoadang>
-- Create date: <may 6>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TransactionSummary]
	@AccountID int
AS
BEGIN
	Select TransactionType, Descriptor, Sum(TransactionAmount) As Amount, Sum(ClientPart) As ClientPart, 
			Sum(AgencyPart) As AgencyPart, Sum(EmployeePart) As EmployeePart
		From Transactions Where AccountID=@AccountID and ConsiderWhenCalcBal=1
		Group By TransactionType, Descriptor
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetAmountPromised]    Script Date: 05/09/2008 10:59:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetAmountPromised]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetAmountPromised]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetAmountPromised]    Script Date: 05/09/2008 10:59:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetAmountPromised]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get total outstanding, amount promised, amount remain money of an account.
-- History:
--		2008/05/06	[Binh Truong]	Init version.
--		2008/05/07	[Binh Truong]	Remove Amount Paid information.
--		2008/05/09	[Binh Truong]	Add ISNULL check.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetAmountPromised]
(
	@AccountID int = NULL
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @CurrentAmountPromised decimal(18,2)
	-- DECLARE @AmountPaid decimal(18,2)
	DECLARE @TotalOutstanding decimal(18,2)
		
	SELECT	@TotalOutstanding = ISNULL(SUM(BillBalance), 0)
	FROM	Account
	WHERE	(ISNULL(@AccountID, 0) = 0 OR AccountID = @AccountID)
		
	SELECT	@CurrentAmountPromised = ISNULL(SUM(AmountPromised), 0) - ISNULL(SUM(AmountPaid), 0)
	FROM	AccountPromise
	WHERE	(ISNULL(@AccountID, 0) = 0 OR AccountID = @AccountID) AND
			Status = 0 -- Not due
	/*
	SELECT	@AmountPaid=SUM(AmountPaid)
	FROM	AccountPromise
	WHERE	(ISNULL(@AccountID, 0) = 0 OR AccountID = @AccountID) AND
			(Status = 1 OR Status = 2) -- Paid on time or paid late
	*/			
	SELECT	ISNULL(@TotalOutstanding, 0) as TotalOutstanding,
			ISNULL(@CurrentAmountPromised, 0) as CurrentAmountPromised,
			--@AmountPaid as AmountPaid,
			ISNULL(@TotalOutstanding - @CurrentAmountPromised, 0) as RemainingAmount
	
END' 
END
GO

/******  Script Closed. Go next: Step010_7  ******/