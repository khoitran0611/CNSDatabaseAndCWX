-- Script is applied on version 2.3.4, 2.3.6

-- Scripts 2.3.4:

/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetBrokenPromiseList]    Script Date: 08/04/2008 16:12:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetBrokenPromiseList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetBrokenPromiseList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseDueList]    Script Date: 08/04/2008 16:12:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetPromiseDueList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseDueList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseHistoryList]    Script Date: 08/04/2008 16:12:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetPromiseHistoryList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseHistoryList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Agents_GetPagingList]    Script Date: 08/04/2008 16:12:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Agents_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Agents_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingList]    Script Date: 08/04/2008 16:12:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Contacts_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 08/04/2008 16:12:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Hearings_GetPagingList]    Script Date: 08/04/2008 16:12:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Hearings_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Hearings_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Localities_GetPagingList]    Script Date: 08/04/2008 16:12:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Localities_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Localities_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Snapshots_GetPagingList]    Script Date: 08/04/2008 16:12:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Snapshots_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Snapshots_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_LetterHistory_Get]    Script Date: 08/04/2008 16:12:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LetterHistory_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LetterHistory_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ReportScheduleTable_GetCustomPagingList]    Script Date: 08/04/2008 16:12:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ReportScheduleTable_GetCustomPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ReportScheduleTable_GetCustomPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TicketDefinition_GetPagingList]    Script Date: 08/04/2008 16:12:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketDefinition_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TicketDefinition_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_CustomDefinedField_Select]    Script Date: 08/04/2008 16:12:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_CustomDefinedField_Select]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TracerInformation_CustomDefinedField_Select]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetBrokenPromiseList]    Script Date: 08/04/2008 16:12:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: May 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetBrokenPromiseList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(PromiseID)
	FROM AccountPromise
	WHERE
		Status = 3 AND AccountID = @AccountID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
			p.PromiseID,
			p.AccountID,
			p.AmountPromised,
			p.DatePromised,
			p.Status,
			p.AmountPaid,
			p.DatePaid,
			p.Period,
			p.Term,
			p.PromiseFrequency,
			e.EmployeeName
		FROM AccountPromise p
		INNER JOIN Employee e ON p.EmployeeID = e.EmployeeID
		WHERE
			p.Status = 3 AND p.AccountID = @AccountID
	)

	SELECT * FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END



GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseDueList]    Script Date: 08/04/2008 16:12:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: May 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseDueList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(PromiseID)
	FROM AccountPromise
	WHERE
		Status = 0 AND AccountID = @AccountID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
			p.PromiseID,
			p.AccountID,
			p.AmountPromised,
			p.DatePromised,
			p.Status,
			p.AmountPaid,
			p.DatePaid,
			p.Period,
			p.Term,
			p.PromiseFrequency,
			e.EmployeeName,
			a.CodeDesc as PromiseGiver
		FROM AccountPromise p
		INNER JOIN Employee e ON p.EmployeeID = e.EmployeeID
		INNER JOIN AccountCodeMaster a ON p.PromiseGiver = a.CodeID
		WHERE
			p.Status = 0 AND p.AccountID = @AccountID
	)

	SELECT * FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseHistoryList]    Script Date: 08/04/2008 16:12:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: May 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseHistoryList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(PromiseID)
	FROM AccountPromise
	WHERE
		Status in (1,2) AND AccountID = @AccountID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
			p.PromiseID,
			p.AccountID,
			p.AmountPromised,
			p.DatePromised,
			p.Status,
			p.AmountPaid,
			p.DatePaid,
			p.Period,
			p.Term,
			p.PromiseFrequency,
			e.EmployeeName
		FROM AccountPromise p
		INNER JOIN Employee e ON p.EmployeeID = e.EmployeeID
		WHERE
			p.Status in (1,2) AND p.AccountID = @AccountID
	)

	SELECT * FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Agents_GetPagingList]    Script Date: 08/04/2008 16:12:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: 11-Jul-2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Agents_GetPagingList]
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(AgentID)
	FROM Legal_Agents
	WHERE Status <> 'R'

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER(ORDER BY b.[Code]) as RowNumber,
				a.AgentID, a.[Code], a.[Name], a.[Description] ,
				b.[Code] + ' - ' + b.[Description] as AgentType,
				c.[Code] + ' - ' + c.[Description]  as AgentSubtype 
		FROM Legal_Agents a
			LEFT JOIN Legal_AgentTypes b ON a.[AgentTypeID] = b.[AgentTypeID]
			LEFT JOIN Legal_AgentSubtypes c ON a.[AgentSubtypeID] = c.[AgentSubtypeID]
		WHERE a.Status <> 'R'
	)

	SELECT 	[AgentID], [Code], [Name], [Description], [AgentType], [AgentSubtype]
	FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingList]    Script Date: 08/04/2008 16:12:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-08
-- Description:	Get paging list of LegalContacts, alphabetically ascending order by 
-- 'Parent Contact Employee Name' group by 'Parent Contact Type'
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingList]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(ContactID)
	FROM Legal_Contacts
	WHERE Status <> 'R'

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.ParentType, Coalesce(b.Code, c.Code, d.Code)) AS RowNumber,
			a.ContactID,
			a.ParentType, 
			Coalesce(b.Code, c.Code, d.Code) Code, 
			Coalesce(b.Name, c.CommonName, d.Name) [Name],
			IsNull(Title,'') Title, IsNull(FirstName, '') FirstName, IsNull(LastName, '') LastName, 
			a.[Description]		
		FROM Legal_Contacts a
			LEFT JOIN Legal_Solicitors b ON a.ParentID = b.SolicitorID AND ParentType = '1'
			LEFT JOIN Legal_Creditors c ON a.ParentID = c.CreditorID AND ParentType = '3'
			LEFT JOIN Legal_Agents d ON a.ParentID = d.AgentID AND ParentType = '2'
		WHERE  a.Status <> 'R'
	)

	SELECT ContactID, ParentType, Code + Case When [Name]<>'' Then ' - ' + [Name] Else '' End CodeAndName, 
			LTRIM(Case When Title<>'' Then Title Else '' End + Case When FirstName<>'' Then ' '+FirstName Else '' End + 
				Case When LastName<>'' Then ' ' + LastName Else '' End) ContactName,
			[Description]
	FROM Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 08/04/2008 16:12:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-14
-- Description:	Get the list of Groups of selecting customer
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
	-- Add the parameters for the stored procedure here
	@debtorID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(G.GroupID)
	FROM 
		(SELECT DISTINCT a.GroupID
		FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
			LEFT JOIN Account c ON b.AccountID = c.AccountID
			LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> 'R') d ON a.GroupID = d.GroupID
		WHERE  a.Status = 'R' and c.DebtorID = @debtorID) G

	WITH Temp AS
	(	
		SELECT
			ROW_NUMBER() OVER (ORDER BY G.Code) AS RowNumber,
			G.*	
		FROM (SELECT DISTINCT
			a.GroupID,
			a.Code,
			a.[Description],
			Case When d.GroupID is not null then 1 else 0 end HasStep
			FROM Legal_Groups a
				LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
				LEFT JOIN Account c ON b.AccountID = c.AccountID
				LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> 'R') d ON a.GroupID = d.GroupID
			WHERE  a.Status <> 'R' and c.DebtorID = @debtorID) G
	)

	SELECT * FROM Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
	
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Hearings_GetPagingList]    Script Date: 08/04/2008 16:12:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Legal_Hearings_GetPagingList]	
	@GroupStepID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(HearingID)
	FROM Legal_Hearings
	WHERE GroupStepID = @GroupStepID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY h.DateHearing) AS RowNumber,
			h.CourtID as Court,
			h.HearingID,
			h.GroupStepID,
			t.Code + ' - ' +  t.Description as CodeAndName,
			h.DateHearing
		FROM Legal_Hearings h 
		LEFT JOIN Legal_HearingTypes t ON h.HearingTypeID = t.HearingTypeID
		WHERE h.GroupStepID = @GroupStepID
	)

	SELECT * FROM Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	ORDER BY DateHearing
	
	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Localities_GetPagingList]    Script Date: 08/04/2008 16:12:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =======================================================================
-- Author:		Tuan Luong
-- Create date: Jun 16, 2008
-- Description:	Get paging list of Legal Localities
-- =======================================================================
CREATE PROCEDURE [dbo].[CWX_Legal_Localities_GetPagingList]	
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(LocalityID)
	FROM Legal_Localities
	WHERE Status <> 'R'

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY l.Name) AS RowNumber,
			l.LocalityID,
			l.[Name],
			ISNULL(l.Postcode, '') as Postcode,
			r.Description as Region
		FROM Legal_Localities l
		LEFT JOIN Legal_Regions r ON l.RegionID = r.RegionID AND r.Status <> 'R'
		WHERE l.Status <> 'R'
	)

	SELECT * FROM Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	ORDER BY [Name]
	
	RETURN @RowCount
END



GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Snapshots_GetPagingList]    Script Date: 08/04/2008 16:12:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[CWX_Legal_Snapshots_GetPagingList]
	@GroupStepID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(SnapshotID)
	FROM Legal_Snapshots
	WHERE GroupStepID = @GroupStepID

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER(ORDER BY b.[Code]) as RowNumber,
				a.[SnapshotID], a.[DateCreated], a.[DebtAmount],
				b.[Code] + ' - ' + b.[Description] as SnapshotType
		FROM Legal_Snapshots a
		LEFT JOIN Legal_SnapshotTypes b ON a.[SnapshotTypeID] = b.[SnapshotTypeID] AND b.[Status] <> 'R'
		WHERE a.GroupStepID = @GroupStepID
	)

	SELECT 	[SnapshotID], [SnapshotType], [DateCreated], [DebtAmount]
	FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_LetterHistory_Get]    Script Date: 08/04/2008 16:12:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LetterHistory_Get]
	-- Add the parameters for the stored procedure here
	@AccountID	int,
	@PageSize	int = 10,
	@PageIndex	int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(ID)
	FROM AccountLetter
	WHERE AccountID = @AccountID

	WITH Temp AS
	(
		SELECT	ROW_NUMBER() OVER (ORDER BY ID) AS RowNumber, 
				ID, a.LetterID as LetterID, LetterDesc, LetterDate, AddressType, ViewLetterPath
		FROM	AccountLetter a
		INNER JOIN DefineLetters d ON a.LetterID = d.LetterID
		WHERE	a.AccountID = @AccountID
	)
	
	SELECT	* FROM	Temp
	WHERE	(@PageSize <= 0) OR (RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize))

	RETURN @RowCount
	
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_ReportScheduleTable_GetCustomPagingList]    Script Date: 08/04/2008 16:12:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_ReportScheduleTable_GetCustomPagingList] 
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(ID)
	FROM ReportScheduleTable;

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY r.ID) AS RowNumber,
				r.ID, 
				r.ReportID, 
				r.ScheduleType, 
				r.Description, 
				r.ScheduleStatus, 
				r.ScheduledDay, 
				r.BeginDate, 
				r.EndDate, 
				d.LetterDesc
		FROM ReportScheduleTable AS r 
		INNER JOIN DefineLetters AS d ON r.ReportID = d.LetterID
    )

	SELECT	* FROM	Temp
	WHERE	(@PageSize <= 0) OR (RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize))
	
	RETURN @RowCount

END

GO
/****** Object:  StoredProcedure [dbo].[CWX_TicketDefinition_GetPagingList]    Script Date: 08/04/2008 16:12:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_TicketDefinition_GetPagingList]	
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(TktDefID)
	FROM TicketDefinition
	WHERE Status <> 'R'

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY t.TktDefID) AS RowNumber,
			t.TktDefID as TicketDefinitionID,
			t.Description,
			t.ApprovalLevel,
			t.ApproverDays,
			t.RoleID,		
			ISNULL(e.EmployeeName, '') as EmployeeName,
			t.EmpDDays,
			t.TicketType		
		FROM TicketDefinition t 
		LEFT JOIN Employee e ON t.EmployeeID = e.EmployeeID AND e.EmployeeStatus <> 'R'
		WHERE  t.Status <> 'R'
	)

	SELECT * FROM Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	ORDER BY TicketDefinitionID
	
	RETURN @RowCount
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_CustomDefinedField_Select]    Script Date: 08/04/2008 16:12:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Tuan Luong
-- Create date: May 15, 2008
-- Description:	Get custom defined fields.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TracerInformation_CustomDefinedField_Select]	
	@DebtorID	int,
	@AccountID	int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(c.ID)
	FROM CWX_CustomDefinedFields c 
	INNER JOIN AgencyDefinedMaster a ON c.AgencyID = a.AgencyDefID
	WHERE c.AgencyID <> 0 AND c.AccountID = @AccountID AND c.DebtorID = @DebtorID AND a.Status <> 'R'

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY Description) AS RowNumber, ID, Description, [Value], FormatString		
		FROM CWX_CustomDefinedFields c 
		INNER JOIN AgencyDefinedMaster a ON c.AgencyID = a.AgencyDefID
		WHERE c.AgencyID <> 0 AND c.AccountID = @AccountID AND c.DebtorID = @DebtorID AND a.Status <> 'R'
	)

	SELECT	* FROM	Temp
	WHERE	(@PageSize <= 0) OR (RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize))
	
	RETURN @RowCount

END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountStatus_LoadInQueue]    Script Date: 08/04/2008 16:16:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountStatus_LoadInQueue]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountStatus_LoadInQueue]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_CosignerCNT]    Script Date: 08/04/2008 16:17:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CosignerCNT]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_CosignerCNT]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_Define_Letter_Get]    Script Date: 08/04/2008 16:18:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_Define_Letter_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_Define_Letter_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetInterfaceID]    Script Date: 08/04/2008 16:18:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetInterfaceID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetInterfaceID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_AccountActionOther_Insert]    Script Date: 08/04/2008 16:20:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_AccountActionOther_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_AccountActionOther_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Debtor_HotNote_Update]    Script Date: 08/04/2008 16:20:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Debtor_HotNote_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Debtor_HotNote_Update]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Letter_Select]    Script Date: 08/04/2008 16:20:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Letter_Select]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Letter_Select]
GO
/****** Object:  StoredProcedure [dbo].[CWX_NextAction_Get]    Script Date: 08/04/2008 16:20:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_NextAction_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_NextAction_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonAddress_GetDetail]    Script Date: 08/04/2008 16:20:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonAddress_GetDetail]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonAddress_GetDetail]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PromiseFrequency_Get]    Script Date: 08/04/2008 16:20:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PromiseFrequency_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PromiseFrequency_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_TEST]    Script Date: 08/04/2008 16:20:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_TEST]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_TEST]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Spouse_Get]    Script Date: 08/04/2008 16:20:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Spouse_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Spouse_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_Get]    Script Date: 08/04/2008 16:20:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TracerInformation_Get]
GO

-- Scripts 2.3.6:

/****** Object:  Table [dbo].[CWX_DataDictionary]    Script Date: 08/05/2008 17:00:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CWX_DataDictionary](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ColumnName] [varchar](100) NOT NULL,
	[Description] [varchar](50) NOT NULL,
	[SQL] [varchar](max) NULL,
 CONSTRAINT [PK_CWX_DataDictionary] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

GO

-- =======================================================================
-- Author:			Thuy Nguyen
-- Create date:		Aug 6, 2008
-- Description:		Drop all of redundant columns in Employee table
-- Effected table:	Employee
-- =======================================================================
-- 1
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'Password')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[Password]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN Password		
END
GO 
-- 2
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'LinkDebtors')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[LinkDebtors]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN LinkDebtors		
END
GO
-- 3
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'WorkDebtors')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[WorkDebtors]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN WorkDebtors		
END
GO
-- 4
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'EditDateOfService')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[EditDateOfService]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN EditDateOfService		
END
GO
-- 5
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'EditDebName')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[EditDebName]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN EditDebName		
END
GO
-- 6
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'EditDebAddress')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[EditDebAddress]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN EditDebAddress		
END
GO
-- 7
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'EditDebPhone')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[EditDebPhone]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN EditDebPhone		
END
GO
-- 8
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'NotUsedA')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[NotUsedA]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN NotUsedA		
END
GO
-- 9
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'EditDebSocSec')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[EditDebSocSec]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN EditDebSocSec		
END
GO
-- 10
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'SendLetters')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[SendLetters]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN SendLetters		
END
GO
-- 11
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'NotUsedB')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[NotUsedB]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN NotUsedB		
END
GO 
-- 12
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'NotUsedC')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[NotUsedC]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN NotUsedC		
END
GO
-- 13
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'NotUsedD')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[NotUsedD]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN NotUsedD		
END
GO
-- 14
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'SIFBill')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[SIFBill]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN SIFBill		
END
GO
-- 15
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'CloseBill')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[CloseBill]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN CloseBill		
END
GO
-- 16
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'EditInvoiceNumber')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[EditInvoiceNumber]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN EditInvoiceNumber		
END
GO
-- 17
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'EditAgeDefBill')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[EditAgeDefBill]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN EditAgeDefBill		
END
GO
-- 18
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'EditQueueDate')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[EditQueueDate]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN EditQueueDate		
END
GO
-- 19
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'NotUsedE')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[NotUsedE]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN NotUsedE		
END
GO
-- 20
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'NotUsedF')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[NotUsedF]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN NotUsedF		
END
GO
-- 21
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'NotUsedG')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[NotUsedG]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN NotUsedG		
END
GO 
-- 22
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'DelDebtor')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[DelDebtor]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN DelDebtor		
END
GO
-- 23
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'NotUsedI')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[NotUsedI]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN NotUsedI		
END
GO
-- 24
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'AssignCollectors')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[AssignCollectors]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN AssignCollectors		
END
GO
-- 25
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'NotUsedJ')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[NotUsedJ]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN NotUsedJ		
END
GO
-- 26
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'DelTran')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[DelTran]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN DelTran		
END
GO
-- 27
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'DelBill')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[DelBill]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN DelBill		
END
GO
-- 28
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'AccesTranManag')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[AccesTranManag]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN AccesTranManag		
END
GO
-- 29
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'AccessClientInfo')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[AccessClientInfo]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN AccessClientInfo		
END
GO
-- 30
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'EditClientInfo')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[EditClientInfo]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN EditClientInfo		
END
GO
-- 31
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'EditClientNotes')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[EditClientNotes]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN EditClientNotes		
END
GO 
-- 32
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'ViewClientGraphs')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[ViewClientGraphs]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN ViewClientGraphs		
END
GO
-- 33
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'DelClient')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[DelClient]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN DelClient		
END
GO
-- 34
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'EditEmployeeInfo')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[EditEmployeeInfo]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN EditEmployeeInfo		
END
GO
-- 35
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'AssignNewWork')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[AssignNewWork]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN AssignNewWork		
END
GO
-- 36
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'NotUsedK')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[NotUsedK]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN NotUsedK		
END
GO
-- 37
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'PrintLetters')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[PrintLetters]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN PrintLetters		
END
GO
-- 38
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'ChgBillStatus')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[ChgBillStatus]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN ChgBillStatus		
END
GO
-- 39
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'ChgBillCollector')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[ChgBillCollector]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN ChgBillCollector		
END
GO
-- 40
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'EditRepDebtor')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[EditRepDebtor]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN EditRepDebtor		
END
GO
-- 41
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'NotUsedL')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[NotUsedL]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN NotUsedL		
END
GO 
-- 42
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'DispInManag')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[DispInManag]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN DispInManag		
END
GO
-- 43
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'NotUsedM')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[NotUsedM]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN NotUsedM		
END
GO
-- 44
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'DeletePromise')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[DeletePromise]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN DeletePromise		
END
GO
-- 45
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'PassWordExpiryDt')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[PassWordExpiryDt]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN PassWordExpiryDt		
END
GO
-- 46
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'AuthoriseEmpInfo')
BEGIN
	ALTER TABLE [dbo].[Employee] DROP CONSTRAINT [DF_Employee_AuthoriseEmpInfo]
	ALTER TABLE Employee DROP COLUMN AuthoriseEmpInfo		
END
GO
-- 47
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'ChangePwdOnLogon')
BEGIN
	ALTER TABLE [dbo].[Employee] DROP CONSTRAINT [DF_Employee_Attempts]
	ALTER TABLE Employee DROP COLUMN ChangePwdOnLogon		
END
GO
-- 48
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'ChangePwdDate')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[ChangePwdDate]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN ChangePwdDate		
END
GO
-- 49
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'ChangePwdCount')
BEGIN
	ALTER TABLE [dbo].[Employee] DROP CONSTRAINT [DF_Employee_ChagePwdCount]
	ALTER TABLE Employee DROP COLUMN ChangePwdCount		
END
GO
-- 50
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Employee' and c.name = 'Salt')
BEGIN
	EXEC sys.sp_unbindefault @objname=N'[dbo].[Employee].[Salt]' , @futureonly='futureonly'
	ALTER TABLE Employee DROP COLUMN Salt		
END
GO

/******  Script Closed. Go next: Step017_2  ******/