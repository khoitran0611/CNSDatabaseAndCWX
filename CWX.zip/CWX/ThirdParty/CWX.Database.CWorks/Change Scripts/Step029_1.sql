﻿-- Script is applied on version 3.5.4:

-- Start of Scripts 3.5.4:

-- Alter Bucket data type to int
ALTER TABLE [AccountPromise] ALTER COLUMN [Bucket] int  

go
-- Alter Bucket data type to int
ALTER TABLE [AccountPromise] ALTER COLUMN [DPD] int 

go

if exists(select 1 from sys.sysobjects where [name] = N'CWX_AdditionalInfo_Get' and [type] = N'P')
   drop procedure CWX_AdditionalInfo_Get
go
create PROC [dbo].[CWX_AdditionalInfo_Get]
	@Name varchar(50),
	@AccountID int,
	@PageSize INT = 10,
	@PageIndex INT = 0
AS

DECLARE @ErrMsg varchar(200)
DECLARE @Sql varchar(2000)
DECLARE @TableName nvarchar(50)
DECLARE @ColumnNames nvarchar(400)
DECLARE @UniqueColumnName varchar(100)
DECLARE @IsXSL bit
DECLARE @HasDefinedPK bit 

SET @HasDefinedPK = 0
SELECT @TableName = LOWER(TableName), @ColumnNames = ColumnNames, @IsXSL = XSL
	FROM CWX_AdditionalDataDetails WHERE [Name] = @Name

/* check table name */
DeCLARE @IsExist int
SELECT @IsExist = CHARINDEX('additional', @TableName)
IF (@IsExist <> 1)
BEGIN
	SET @ErrMsg = 'InvalidTable'
	GOTO RAISE_ERROR_MESSAGE
END

/* check existing of AccountID column in Table */
IF NOT EXISTS (SELECT 'true' FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.Name = @TableName AND c.Name = 'AccountId')
BEGIN
	SET @ErrMsg = 'InvalidAccountIDColumn'
	GOTO RAISE_ERROR_MESSAGE
END

/* build sql statement */
IF (@IsXSL = 1)
BEGIN
	SET @ColumnNames = '*'
END
ELSE
BEGIN
	/* check existing of column names in table */
	DECLARE @Colname varchar(30)
	DECLARE ColNameCursor CURSOR FOR SELECT CAST(SplitedText AS varchar(20)) AS ColumnName FROM CWX_FnSplitString(@ColumnNames, ',')

	set @UniqueColumnName = (SELECT c.[name] AS ColumnName
							 FROM sys.key_constraints AS k 
								INNER JOIN
									sys.tables AS t ON t.[object_id] = k.parent_object_id AND t.[Name] = @TableName
								INNER JOIN
									sys.schemas AS s ON s.schema_id = t.schema_id 
								INNER JOIN
									sys.index_columns AS ic ON ic.[object_id] = t.[object_id] AND ic.index_id = k.unique_index_id 
								INNER JOIN sys.columns AS c ON c.[object_id] = t.[object_id] AND c.column_id = ic.column_id
							 WHERE (t.name <> N'sysdiagrams') AND (t.is_ms_shipped = 0) AND (k.type = 'PK'))

    IF ((@UniqueColumnName IS NULL) OR (lower(@UniqueColumnName) <> 'recordid'))
     BEGIN
         SET @ErrMsg = 'Table requires a primary key or a RecordId column'
	     GOTO RAISE_ERROR_MESSAGE
     END   
    
	OPEN ColNameCursor
	FETCH NEXT FROM ColNameCursor INTO @ColName
	
	SET @ColumnNames = ''
	SET @ColName = RTRIM(LTRIM(@ColName))
	
    WHILE @@FETCH_STATUS = 0
	BEGIN
		IF EXISTS (SELECT 1 FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.Name = @TableName AND c.Name = @ColName)
		BEGIN
			IF (LEN(@ColumnNames) = 0)
				SET @ColumnNames = @ColName
			ELSE
                IF LOWER(@UniqueColumnName) <> @ColName  
				   SET @ColumnNames = @ColumnNames + ',' + @ColName
                ELSE
                   IF @HasDefinedPK = 0   
                      SET @HasDefinedPK = 1             
		END

		FETCH NEXT FROM ColNameCursor INTO @ColName
		SET @ColName = RTRIM(LTRIM(@ColName))
	END

	CLOSE ColNameCursor
	DEALLOCATE ColNameCursor
END

IF (@HasDefinedPK = 0) AND (@UniqueColumnName <> '')
   SET @ColumnNames = @ColumnNames + ',' + @UniqueColumnName

/* retrieve data that following user settings */
DECLARE @StartRow int, @EndRow int
SET @StartRow = @PageIndex * @PageSize + 1
SET @EndRow = (@PageIndex + 1) * @PageSize

SET @Sql = 'DECLARE @TotalRow int '
SET @Sql = @Sql + 'SELECT ' + @ColumnNames + ' , ROW_NUMBER() OVER (ORDER BY AccountID) AS RowNumber INTO #RESULT FROM ' + @TableName + ' '
SET @Sql = @Sql + 'WHERE AccountID=' + STR(@AccountID) + ' '
SET @Sql = @Sql + 'SET @TotalRow = @@ROWCOUNT '
SET @Sql = @Sql + 'SELECT ' + @ColumnNames + ' FROM #RESULT WHERE RowNumber BETWEEN ' + STR(@StartRow) + ' AND ' + STR(@EndRow) + ' '
SET @Sql = @Sql + 'SELECT @TotalRow as [RowCount]'

exec(@Sql)

RETURN

RAISE_ERROR_MESSAGE:
	RAISERROR (@ErrMsg, 16, 1)
go

/****** Object:  StoredProcedure [dbo].[CWX_AdditionalDataDetails_AddDynamicFields]    Script Date: 01/26/2009 07:48:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AdditionalDataDetails_AddDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AdditionalDataDetails_AddDynamicFields]

GO
/****** Object:  StoredProcedure [dbo].[CWX_AdditionalDataDetails_AddDynamicFields]    Script Date: 01/26/2009 19:50:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Morris Mendoza
-- Create date: 20/01/2008
-- Description:	
-- =============================================				
CREATE PROCEDURE [dbo].[CWX_AdditionalDataDetails_AddDynamicFields]
	@AdditionalDataID int,
	@AccountID int,
	@PrimaryID int,
	@columns varchar(4000),
	@values varchar(4000),
	@updatesql varchar(4000)
AS

BEGIN
	DECLARE @tablename varchar(4000)	
--delete existing values in AdditionalDetails table
	SELECT @tablename = tablename from CWX_AdditionalDataDetails Where ID = @AdditionalDataID

	--DELETE FROM AdditionalFields WHERE AccountID = @AccountID
	
	DECLARE @Sql varchar(4000)

	IF @AccountID = 0 OR @AccountID = null
		BEGIN
			SET @Sql = 'INSERT INTO ' +  @tablename + ' (' + @columns + ') VALUES (' + @values + ')'
		END
	ELSE
		BEGIN
		Declare @ColumnName varchar(4000)
		select @ColumnName = c.name
		from sysindexes i
		join sysobjects o ON i.id = o.id
		join sysobjects pk ON i.name = pk.name
		AND pk.parent_obj = i.id
		AND pk.xtype = 'PK'
		join sysindexkeys ik on i.id = ik.id
		and i.indid = ik.indid
		join syscolumns c ON ik.id = c.id
		AND ik.colid = c.colid
		where o.name = @TableName
		order by ik.keyno
			SET @Sql = 'UPDATE ' + @tablename + ' ' + @updatesql + ' WHERE AccountID = ' + cast(@AccountID as varchar)
			+ ' and ' + @ColumnName + '=' + cast(@PrimaryID as varchar)
		END
	EXEC(@sql)

	SELECT @@RowCOUNT
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_AdditionalDataDetails_GetDynamicFields]    Script Date: 01/26/2009 07:48:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AdditionalDataDetails_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AdditionalDataDetails_GetDynamicFields]

GO
/****** Object:  StoredProcedure [dbo].[CWX_AdditionalDataDetails_GetDynamicFields]    Script Date: 01/26/2009 16:50:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Morris Mendoza
-- Create date: 20/01/2008
-- Description:	
-- =============================================				
CREATE PROCEDURE [dbo].[CWX_AdditionalDataDetails_GetDynamicFields]
	@AdditionalDataID int,
	@AccountID int,
	@PrimaryID int
AS
BEGIN
DECLARE @TableName varchar(100),@count int

SELECT a.ColumnNames,a.TableName INTO #ColumnSetTable 
FROM (Select ColumnNames, TableName from CWX_AdditionalDataDetails Where ID = @AdditionalDataID) a
SELECT @count = Count(*) From #ColumnSetTable
SELECT @TableName = Tablename From #ColumnSetTable

	DECLARE @FieldName varchar(4000)
	DECLARE curColumn CURSOR FOR
		SELECT ColumnNames FROM #ColumnSetTable
	OPEN curColumn
	FETCH NEXT FROM curColumn INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		select txt_value as [ColumnName] INTO #finaltable From fn_ParseText2Table(@FieldName, ',')
		Select a.ColumnName,b.[DataType],b.[MaxLength] 
		From #finaltable a
		INNER JOIN 
				(SELECT c.[name] as [ColumnName], t.[name] as [DataType], c.[max_length] as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id]
WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = @TableName and [Type]='U')
		) b 
		ON a.[ColumnName] = b.[ColumnName]

		FETCH NEXT FROM curColumn INTO @FieldName
	END
	CLOSE curColumn
	DEALLOCATE curColumn
	DROP TABLE #ColumnSetTable
	
	DECLARE @FieldNameList varchar(4000)
	SET @FieldNameList = ''
	IF(@count > 0)
	BEGIN
		DECLARE currField CURSOR FOR
			SELECT [ColumnName] FROM #finaltable	
		OPEN currField
		FETCH NEXT FROM currField INTO @FieldName
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			SET @FieldNameList = @FieldNameList + @FieldName + ',';
			FETCH NEXT FROM currField INTO @FieldName
		END
		SET @FieldNameList = Left(@FieldNameList, Len(@FieldNameList)-1)
		--PRINT @FIeldNameList
		CLOSE currField
		DEALLOCATE currField

		DROP TABLE #finaltable	
	END

	Declare @ColumnName varchar(4000)
	select @ColumnName = c.name
	from sysindexes i
	join sysobjects o ON i.id = o.id
	join sysobjects pk ON i.name = pk.name
	AND pk.parent_obj = i.id
	AND pk.xtype = 'PK'
	join sysindexkeys ik on i.id = ik.id
	and i.indid = ik.indid
	join syscolumns c ON ik.id = c.id
	AND ik.colid = c.colid
	where o.name = @TableName
	order by ik.keyno

	DECLARE @Sql varchar(4000)

	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM '+ @TableName + ' WHERE ACCOUNTID = ' + cast(@AccountID as varchar)
		+ ' AND ' + @ColumnName + '=' + cast(@PrimaryID as varchar)
	PRINT @SQL	
EXEC (@Sql)

END

GO

if exists(select 1 from sys.objects where [name] = N'CWX_DeleteAdditionalFieldsData' and [type] = N'P')
   drop procedure CWX_DeleteAdditionalFieldsData
go

create procedure CWX_DeleteAdditionalFieldsData
@id int,
@all bit
as
begin

if (@all = 0)
   delete from dbo.AdditionalFields where RecordID = @id 
else 
   delete from dbo.AdditionalFields where AccountID = @id

return @@ROWCOUNT

end

go