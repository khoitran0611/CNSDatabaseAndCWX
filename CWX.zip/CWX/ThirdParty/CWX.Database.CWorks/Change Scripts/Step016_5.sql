-- Script is applied on version 2.2.15

-- 2008/07/24	[Binh Truong]
IF NOT EXISTS (SELECT * FROM InformationTable WHERE InfoID=1 AND InfoType=14)
	INSERT INTO InformationTable VALUES(1, 14, 0, '', 'Apply cycle date for customer promise', NULL, 'False', 'A')
GO

/****** Object:  StoredProcedure [dbo].[CWX_AdditionalInfo_Get]    Script Date: 07/24/2008 17:44:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AdditionalInfo_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AdditionalInfo_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AdditionalInfo_Get]    Script Date: 07/24/2008 17:44:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AdditionalInfo_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROC [dbo].[CWX_AdditionalInfo_Get]
	@Name varchar(50),
	@AccountID int,
	@PageSize INT = 10,
	@PageIndex INT = 0
AS

DECLARE @ErrMsg varchar(200)
DECLARE @Sql varchar(2000)
DECLARE @TableName nvarchar(50)
DECLARE @ColumnNames nvarchar(400)
DECLARE @IsXSL bit

SELECT @TableName = LOWER(TableName), @ColumnNames = ColumnNames, @IsXSL = XSL
	FROM CWX_AdditionalDataDetails WHERE [Name] = @Name

/* check table name */
DeCLARE @IsExist int
SELECT @IsExist = CHARINDEX(''additional'', @TableName)
IF (@IsExist <> 1)
BEGIN
	SET @ErrMsg = ''InvalidTable''
	GOTO RAISE_ERROR_MESSAGE
END

/* check existing of AccountID column in Table */
IF NOT EXISTS (SELECT ''true'' FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.Name = @TableName AND c.Name = ''AccountId'')
BEGIN
	SET @ErrMsg = ''InvalidAccountIDColumn''
	GOTO RAISE_ERROR_MESSAGE
END

/* build sql statement */
IF (@IsXSL = 1)
BEGIN
	SET @ColumnNames = ''*''
END
ELSE
BEGIN
	/* check existing of column names in table */
	DECLARE @Colname varchar(30)
	DECLARE ColNameCursor CURSOR FOR
	SELECT CAST(SplitedText AS varchar(20)) AS ColumnName
			FROM CWX_FnSplitString(@ColumnNames, '','')

	OPEN ColNameCursor
	FETCH NEXT FROM ColNameCursor INTO @ColName
	
	SET @ColumnNames = ''''
	SET @ColName = RTRIM(LTRIM(@ColName))
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF EXISTS (SELECT ''true'' FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.Name = @TableName AND c.Name = @ColName)
		BEGIN
			IF (LEN(@ColumnNames) = 0)
				SET @ColumnNames = @ColName
			ELSE
				SET @ColumnNames = @ColumnNames + '','' + @ColName
		END

		FETCH NEXT FROM ColNameCursor INTO @ColName
		SET @ColName = RTRIM(LTRIM(@ColName))
	END

	CLOSE ColNameCursor
	DEALLOCATE ColNameCursor
END

/* retrieve data that following user settings */
DECLARE @StartRow int, @EndRow int
SET @StartRow = @PageIndex * @PageSize + 1
SET @EndRow = (@PageIndex + 1) * @PageSize

SET @Sql = ''DECLARE @TotalRow int ''
SET @Sql = @Sql + ''SELECT '' + @ColumnNames + '' , ROW_NUMBER() OVER (ORDER BY AccountID) AS RowNumber INTO #RESULT FROM '' + @TableName + '' ''
SET @Sql = @Sql + ''WHERE AccountID='' + STR(@AccountID) + '' ''
SET @Sql = @Sql + ''SET @TotalRow = @@ROWCOUNT ''
SET @Sql = @Sql + ''SELECT '' + @ColumnNames + '' FROM #RESULT WHERE RowNumber BETWEEN '' + STR(@StartRow) + '' AND '' + STR(@EndRow) + '' ''
SET @Sql = @Sql + ''SELECT @TotalRow as [RowCount]''
EXEC(@Sql)
RETURN

RAISE_ERROR_MESSAGE:
	RAISERROR (@ErrMsg, 16, 1)
' 
END
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Jul 24, 2008
-- Description:		Drop column 'GroupID' then Add column 'GroupStepID'
-- Effected table:	Legal_Snapshots
-- =======================================================================
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Snapshots' and c.name = 'GroupID')
BEGIN
	DELETE FROM [Legal_Snapshots]
	ALTER TABLE [Legal_Snapshots] DROP COLUMN GroupID
	ALTER TABLE [Legal_Snapshots] ADD GroupStepID int NOT NULL
END
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Jul 24, 2008
-- Description:		Create store procedure 'Legal_Snapshots_GetPagingList
-- =======================================================================
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Snapshots_GetPagingList]    Script Date: 07/24/2008 18:24:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Snapshots_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Snapshots_GetPagingList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Snapshots_GetPagingList]    Script Date: 07/24/2008 18:24:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Legal_Snapshots_GetPagingList]
	@GroupStepID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	SELECT ROW_NUMBER() OVER(ORDER BY b.[Code]) as RowNumber,
			a.[SnapshotID], a.[DateCreated], a.[DebtAmount],
			b.[Code] + ' - ' + b.[Description] as SnapshotType
	INTO #temp
	FROM Legal_Snapshots a
		LEFT JOIN Legal_SnapshotTypes b ON a.[SnapshotTypeID] = b.[SnapshotTypeID]
	WHERE a.GroupStepID = @GroupStepID
	--WHERE a.Status <> 'R'
	ORDER BY RowNumber
	
	Declare @RowCount int
	Set @RowCount = @@ROWCOUNT	

	SELECT 	[SnapshotID], [SnapshotType], [DateCreated], [DebtAmount]
	FROM #temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/*The notes recorded with user name instead of login uesriD. Please change the notes entries of account management to reflect the userid. - raised by Sathya*/

/****** Object:  StoredProcedure [dbo].[CWX_Account_PermanentReassign]    Script Date: 07/25/2008 09:38:58 ******/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 27, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_PermanentReassign] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@MaintainOfficer bit = 0,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				AssignmentType = 'P',
				EmployeeID = @EmployeeID,
				MaintainOfficer = @MaintainOfficer
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @CurrentUserID
			SET @NoteText = 'AcctMgmt: Permanent Reassignment to ' + cast(@CurrentUserID as varchar) + ' with MaintainOfficer '
			IF @MaintainOfficer = 0
				SET @NoteText = @NoteText + 'unchecked'
			ELSE
				SET @NoteText = @NoteText + 'checked'

			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END


/****** Object:  StoredProcedure [dbo].[CWX_Account_TemporaryReassign]    Script Date: 07/25/2008 09:46:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 27, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_TemporaryReassign] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				AssignmentType = 'T',
				TempEmployeeID = @EmployeeID
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @EmployeeID
			SET @NoteText = 'AcctMgmt: Temporary Reassignment To ' + cast(@EmployeeID as varchar)
			
			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_ReferToEmployee]    Script Date: 07/25/2008 09:48:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[CWX_Account_ReferToEmployee]
	@EmployeeID int,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				ActionEmployee = @EmployeeID
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @EmployeeID
			SET @NoteText = 'AcctMgmt: Refer to ' + cast(@EmployeeID as varchar)
			
			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_GetEmployeeNextPoolAccount]    Script Date: 07/25/2008 10:26:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetEmployeeNextPoolAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetEmployeeNextPoolAccount]    Script Date: 07/25/2008 10:26:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetEmployeeNextPoolAccount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount] 
	@v_currentLoginEmployeeId int,
	@v_employeeId int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='''' 
		   SET @v_SortOrder = '' "QueueDate" DESC''

    Set @orderByClause = ''ORDER BY '' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = ''WHERE RowIndex BETWEEN '' + CAST(@BeginIndex as varchar(10)) + '' AND '' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = '' ''
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt =  '' SELECT a.DebtorID, a.AccountID,''
				+ ''   a.QueueDate AS [QueueDate],''
				+ ''   a.AccountAge AS [DPD],''
				+ ''   a.MCode AS [Bucket],''
				+ ''   a.CCode AS [Cycle],''
				+ ''   a.BillAmount AS [Bill Amount],''
				+ ''   a.BillBalance AS [Bill Balance],''
				+ ''   s.ShortDesc AS [Status],''
				+ ''   s.SortPriority AS [Priority],''
				+ ''   a.AssignmentType AS [Assignment Type],''
				+ ''   p.SocialSecurityNumber AS [ID],''
				+ ''   (rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName)) AS [Name]''
				+ '' FROM Account a''
				+ '' INNER JOIN Accountother o ON o.AccountID = a.AccountID''
				+ '' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID''
				+ '' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID''
				+ '' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID''
				+ '' WHERE''
				+ ''   a.QueueDate<=GetDate()''
				+ ''   AND a.EmployeeID = ''+CAST(@v_employeeId as varchar(9))
				+ ''   AND a.DebtorID <> 0''
				+ ''   AND a.AgencyStatusID <> 2''
				+ ''	  AND a.SystemStatusID in (1,5)''
				+ ''	  AND a.PoolSelected = 0''

	--Step 4: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = ''SELECT @RowCountOut=count(*) FROM ( {0} ) A''
    SET @rowCountStmt = REPLACE(@rowCountStmt, ''{0}'', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = ''@RowCountOut int OUTPUT''
	
	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	--Step 5: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = ''WITH AccountResults AS ''
				   + ''( ''
				   + ''  SELECT *, ROW_NUMBER() OVER ('' + @orderByClause + '') as RowIndex ''
				   + ''  FROM ( ''	
				   + ''          {0}''
				   + ''    ) A ''
				   + '') ''
				   + ''   ''
				   + ''SELECT top 1 DebtorID, AccountID, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name] INTO #PoolAccount ''
				   + ''FROM AccountResults ''
				   + @pagingWhereClause	
				   + '' DECLARE @AccountID int ''
				   + '' DECLARE @DebtorID int ''
				   + '' SELECT @AccountID=AccountID, @DebtorID=DebtorID FROM #PoolAccount ''
				   + '' EXEC CWX_Account_UpdatePoolStatus @AccountID, @DebtorID, '' + STR(@v_currentLoginEmployeeId)
				   + '' SELECT (CONVERT(varchar(10), DebtorID) + ''''|'''' + CONVERT(varchar(10), AccountID)) AS KeyField, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name] ''
				   + '' FROM #PoolAccount ''

    SET @finalStmt = REPLACE(@finalStmt, ''{0}'', @cStmt)

	--Step 6: Execute the main SQL command.	
	EXEC (@finalStmt)
		
	if (@RowCount > 1)
		RETURN 2

	RETURN @RowCount
END

' 
END
GO

TRUNCATE TABLE TempDebtorXml
GO

UPDATE QueryMaster SET SQL2='EXEC CWX_Account_SearchByQueueSStat %E, %1, %DPD, %Bucket, %Cycle' WHERE ID=1
GO

IF NOT EXISTS (SELECT * FROM QueryParams WHERE QueryID=1 AND ParamID IN (2,3,4))
BEGIN
	INSERT INTO QueryParams VALUES(1,2,'DPD','','SELECT DISTINCT AccountAge, AccountAge FROM Account ORDER BY AccountAge')
	INSERT INTO QueryParams VALUES(1,3,'Bucket','','SELECT DISTINCT MCode, MCode FROM Account ORDER BY MCode')
	INSERT INTO QueryParams VALUES(1,4,'Cycle','','SELECT DISTINCT CCode, CCode FROM Account ORDER BY CCode')
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 07/25/2008 10:36:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByQueueSStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 07/25/2008 10:36:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_SystemStatus int,
	@AccountAge int = -1,
	@MCode int = -1,
	@CCode int = -1,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId as varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID <> 2'

	IF @v_SystemStatus = 0 
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'+''

	IF ((@v_SystemStatus = 1) or (@v_SystemStatus = 5))
		SET @cStmt=@cStmt+' AND s.SystemStatus = '+CAST(@v_SystemStatus AS varchar(9))+''

	IF @v_SystemStatus = 2
	BEGIN
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'+''
		SET @cStmt=@cStmt+' AND convert(varchar(10),a.SubmissionDate,121)=convert(varchar(10),GetDate(),121)'+''
	END
	
	IF @AccountAge <> -1
		SET @cStmt=@cStmt+' AND a.AccountAge = '+CAST(@AccountAge AS varchar(9))
	IF @MCode <> -1
		SET @cStmt=@cStmt+' AND a.MCode = '+CAST(@MCode AS varchar(9))
	IF @CCode <> -1
		SET @cStmt=@cStmt+' AND a.CCode = '+CAST(@CCode AS varchar(9))

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 07/25/2008 10:38:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXML]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_LoadXML]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 07/25/2008 10:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Load all accounts with debtorID
-- History:
--	08/04/03	[Tai Ly]	Init version.
--	08/06/01	[Long Nguyen]	Add and remove some fields.
--	08/06/27	[Binh Truong]	Remove BatchNumber field.	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int	
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/
	SELECT
			a.AccountID,
			c.COOWNERS,
			ISNULL(l.LetterDesc, '') AS SENTBY, ISNULL(al.LetterStatus, '') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			('Debtor promises to pay ' + CAST(p.AmountPromised AS varchar) + ' for ' + CAST(p.PromiseFrequency AS varchar) + ' ' + ISNULL(p.Term, '') + ', Next Payment due on ') AS PROMISE, p.DatePromised,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL,
			lastpromise.LASTPROMISEDATE, lastpromise.LASTPROMISEAMOUNT, lastpromise.LASTPROMISESTATUS, lastpromise.LASTPROMISESTATUSDESC
	INTO	#AccountTemp
	FROM	Account	 a
	--Count CoSigner for account
	LEFT JOIN (SELECT AccountID, COUNT(CoSignerID) AS COOWNERS FROM CoSigner GROUP BY AccountID) c ON c.AccountID = a.AccountID
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN 'd' THEN 'day(s)'
						WHEN 'w' THEN 'week(s)'
						WHEN 'm' THEN 'month(s)'
						WHEN 'y' THEN 'year(s)'
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get last promise
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised AS LASTPROMISEAMOUNT,
					p2.DatePromised AS LASTPROMISEDATE,
					p2.Status AS LASTPROMISESTATUS,
					CASE p2.Status
						WHEN 0 THEN 'Not Due'
						WHEN 1 THEN 'Paid On Time'
						WHEN 2 THEN 'Paid Late'
						WHEN 3 THEN 'Broken Promise'
						WHEN 4 THEN 'Canceled'
						ELSE ''
					END AS LASTPROMISESTATUSDESC
				FROM AccountPromise p2 
				WHERE p2.DatePromised = (SELECT MAX(DatePromised) FROM AccountPromise WHERE AccountID = p2.AccountID)) lastpromise ON lastpromise.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	WHERE DebtorID = @DebtorID

	--If @AdditionalTag = 1 get additional data
	DECLARE @AdditionalTag int
	SELECT @AdditionalTag = FieldValue FROM IdentityFields WHERE TableName = 'AdditionalTag'

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, nextAction.CodeDesc AS CurrentNextActionDesc, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			, #AccountTemp.COOWNERS--, DebtorID as COOWNERS
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE--, InvoiceNumber as SENTBY, ' ' as LETTERSTATUS, QueueDate as LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised--, String1 as PROMISE
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.LASTCONTACTDATE ELSE '' END AS LASTCONTACTDATE--' ' as LASTCONTACTDATE
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.LASTCONTACTBY ELSE '' END AS LASTCONTACTBY--, ' ' as LASTCONTACTBY
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISETOPAY ELSE '' END AS PROMISETOPAY--, ' ' as PROMISETOPAY
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISEKEPT ELSE '' END AS PROMISEKEPT--, ' ' as PROMISEKEPT
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISEBROKEN ELSE '' END AS PROMISEBROKEN--, ' ' as PROMISEBROKEN
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.OUTGOINGCALL ELSE '' END AS OUTGOINGCALL--, ' ' as OUTGOINGCALL
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.NOACTIVITYDAYS ELSE '' END AS NOACTIVITYDAYS--, ' ' as NOACTIVITYDAYS
			, #AccountTemp.LASTPROMISEDATE, #AccountTemp.LASTPROMISEAMOUNT, #AccountTemp.LASTPROMISESTATUS, #AccountTemp.LASTPROMISESTATUSDESC
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID
			LEFT OUTER JOIN AccountCodeMaster nextAction on Account.CurrentNextAction = nextAction.CodeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END

GO

/******  Script Closed. Go next: Step016_6  ******/