-- Scripts are applied on version 1.4.1 build 2 

/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterQueue_Delete]    Script Date: 04/23/2008 16:55:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountLetterQueue_Delete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountLetterQueue_Delete]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterQueue_Delete]    Script Date: 04/23/2008 16:55:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		KhoaDuong	
-- Create date: April 18, 2008
-- Description:	Order letter - Delete Account Letter Queue
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountLetterQueue_Delete]
	-- Add the parameters for the stored procedure here
	@LetterID	int,
	@AccountID	int
AS
BEGIN
	-- Insert statements for procedure here
	DELETE FROM dbo.AccountLetterQueue WHERE LetterID = @LetterID AND AccountID = @AccountID
END
GO

UPDATE    QueryMaster
SET              [SQL2] = 'EXEC SearchAccountByTicketNumber %E, %1'
WHERE     (ID = 18)

GO

/****** Object:  StoredProcedure [dbo].[CWX_Employee_LoadCollectorReferral]    Script Date: 04/24/2008 15:25:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_LoadCollectorReferral]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_LoadCollectorReferral]
GO

-- =============================================
-- Author:		Tai Ly
-- Create date: April 24, 2008
-- Description:	Get collector or referral for main page
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_LoadCollectorReferral]
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@LoadAll bit = 1,
	@EmployeeName varchar(50) = '',
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;	

	DECLARE @RowCount int
	CREATE TABLE #Temp
	(
		RowNumber int,	
		EmployeeID int,
		EmployeeName varchar(50),
		UserID		varchar(10)
	)

    -- Insert statements for procedure here
	IF (@LoadAll = 1)	-- collector
	BEGIN
		IF @EmployeeName = ''	-- No employee name input
		BEGIN
			INSERT		INTO #Temp
				SELECT		ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber, EmployeeID, EmployeeName, UserID		
				FROM		[dbo].[Employee]
				WHERE		EmployeeStatus = 'A'
				ORDER BY	employeename		
		END
		ELSE
		BEGIN
			INSERT		INTO #Temp
				SELECT		ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber, EmployeeID, EmployeeName, UserID		
				FROM		[dbo].[Employee]
				WHERE		EmployeeStatus = 'A' AND EmployeeName LIKE ('%' + @EmployeeName + '%')
				ORDER BY	employeename			
		END	
		
	END
	ELSE	-- referral case
	BEGIN
		DECLARE @Supervisor bit

		SELECT	@Supervisor = Supervisor	
		FROM	[dbo].[Employee]		
		WHERE	EmployeeID = @EmployeeID

		IF @EmployeeName = ''	-- No employee name input
		BEGIN
			IF @Supervisor = 1	-- Input Employee is the supervisor
			BEGIN
				INSERT		INTO #Temp
					SELECT		ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber, EmployeeID, EmployeeName, UserID
					FROM		[dbo].[Employee]
					WHERE		EmployeeStatus = 'A' AND EmployeeID <> @EmployeeID									

				
			END
			ELSE
			BEGIN
				INSERT INTO #Temp
					SELECT		ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber,EmployeeID, EmployeeName, UserID					
					FROM		[dbo].[Employee]
					WHERE		EmployeeStatus = 'A' AND EmployeeID <> @EmployeeID														
								AND Supervisor = 1
			END
		END						
		ELSE	-- WITH EmployeeName input
		BEGIN
			IF @Supervisor = 1	-- Input Employee is the supervisor
			BEGIN
				INSERT		INTO #Temp
					SELECT		ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber, EmployeeID, EmployeeName, UserID				
					FROM		[dbo].[Employee]
					WHERE		EmployeeStatus = 'A' AND EmployeeID <> @EmployeeID AND EmployeeName LIKE ('%' + @EmployeeName + '%')									
			END
			ELSE
			BEGIN
				INSERT		INTO #Temp				
					SELECT		ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber, EmployeeID, EmployeeName, UserID				
					FROM		[dbo].[Employee]
					WHERE		EmployeeStatus = 'A' AND EmployeeID <> @EmployeeID														
								AND Supervisor = 1   AND EmployeeID <> @EmployeeID AND EmployeeName LIKE ('%' + @EmployeeName + '%')
			END			
		END
		
	END	

	SELECT @RowCount = @@ROWCOUNT

	IF @PageSize <= 0
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	RETURN @RowCount	
	
END
GO
