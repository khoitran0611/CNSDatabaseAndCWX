 -- Scripts are applied on version 1.3 build 3
 

/****** Object:  StoredProcedure [dbo].[CWX_Account_MaintainDelinquencyOfficer]    Script Date: 04/03/2008 10:06:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_MaintainDelinquencyOfficer]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_MaintainDelinquencyOfficer]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_MaintainDelinquencyOfficer]    Script Date: 04/03/2008 10:06:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_MaintainDelinquencyOfficer]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Binh Truong
-- Create date: April 02, 2008
-- Description:	
-- =============================================
create PROCEDURE [dbo].CWX_Account_MaintainDelinquencyOfficer 
	-- Add the parameters for the stored procedure here
	@MaintainOfficer bit,
	@AccountIDs varchar(8000),
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, ''|'')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				MaintainOfficer = @MaintainOfficer
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SET @NoteText = ''AcctMgmt: Maintain Delinquency Officer ''
			IF @MaintainOfficer = 0
				SET @NoteText = @NoteText + ''unchecked''
			ELSE
				SET @NoteText = @NoteText + ''checked''

			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), ''A'', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END
' 
END
GO
 

-- =============================================
-- Author:		Tuan Luong
-- Create date: Apr 02, 2008
-- Description:	
-- =============================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ChangeAccountStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_ChangeAccountStatus]
GO
CREATE PROCEDURE [dbo].[CWX_Account_ChangeAccountStatus] 
	@AgencyStatusID int,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @StatusDesc varchar(10)		

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				AgencyStatusID = @AgencyStatusID
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID
			
			SELECT @StatusDesc = ShortDesc FROM AccountStatus WHERE AgencyStatus = @AgencyStatusID
			SET @NoteText = 'AcctMgmt: Status Change to ' + @StatusDesc
			
			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END