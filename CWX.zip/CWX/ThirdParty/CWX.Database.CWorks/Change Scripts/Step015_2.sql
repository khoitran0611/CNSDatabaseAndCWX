-- Script is applied on version 2.1.2, 2.1.4

/****** Object:  Table [dbo].[CWX_AccountWorkTimeRecord]    Script Date: 07/03/2008 14:57:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountWorkTimeRecord]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_AccountWorkTimeRecord]
GO
/****** Object:  Table [dbo].[CWX_AccountWorkTimeRecord]    Script Date: 07/03/2008 14:57:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountWorkTimeRecord]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_AccountWorkTimeRecord](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[AccountID] [int] NULL,
	[EmployeeID] [int] NULL,
	[StartTime] [smalldatetime] NULL,
	[EndTime] [smalldatetime] NULL,
	[MinutesWorked] [int] NULL DEFAULT ((0)),
 CONSTRAINT [PK_CWX_AccountWorkTimeRecord] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO

-- 2.1.4:

-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 04, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_PaymentAllocationRules
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_PaymentAllocationRules' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_PaymentAllocationRules
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_PaymentAllocationRules_RowStatus] DEFAULT 'A'
END
GO

-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 04, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_Solicitors
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Solicitors' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_Solicitors
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_Solicitors_RowStatus] DEFAULT 'A'
END
GO

IF NOT EXISTS (SELECT * FROM InformationTable WHERE InfoID=1 AND InfoType=13)
	INSERT INTO InformationTable VALUES(1, 13, 0, '', 'NotesDisplayByAccount', NULL, 'False', 'A')
GO

/****** Object:  StoredProcedure [dbo].[CWX_Notes_GetWithType]    Script Date: 07/04/2008 15:04:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Notes_GetWithType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Notes_GetWithType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Notes_GetWithType]    Script Date: 07/04/2008 15:04:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		Tai Ly
-- Create date: May 08, 1008
-- Description:	Get notes from database
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Notes_GetWithType] 	
	-- Add the parameters for the stored procedure here
	@DebtorID	int,
	@AccountID	int,
	@NoteText	varchar(1000) = '',
	@NoteType	varchar(1) = ' ',	
	@Month		int = -1,
	@Day		int = -1,
	@FromDate	datetime = '1753-01-01',
	@ToDate		datetime = '9999-12-31',
	@SearchHistory bit = 0,
	@SearchByAccount bit = 0,
	@PageSize	int = 10,
	@PageIndex	int = 0
AS
BEGIN
	DECLARE @TempTableVar table(
		RowNumber		int,
		NoteDateTime	datetime,
		NoteText		varchar(1000),
		NoteType		varchar(1),
		UserID			varchar(10)
	);

	IF @Month >= 0
	BEGIN
		SET @FromDate = DATEADD(month, -1*@Month, GETDATE())
		SET @ToDate = GETDATE()
	END
	ELSE IF @Day >= 0
	BEGIN
		SET @FromDate = DATEADD(day, -1*@Day, GETDATE())
		SET @ToDate = GETDATE()
	END

	SELECT @NoteText = '%' + @NoteText + '%';

	IF @SearchHistory = 0
		INSERT INTO @TempTableVar
		SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID
		FROM		NotesCurrent n, Employee e
		WHERE		((@SearchByAccount = 0 AND n.DebtorID = @DebtorID) OR n.BillID = @AccountID)
					AND n.EmployeeID *= e.EmployeeID 
					AND (@NoteType = ' ' OR UPPER(NoteType) = UPPER(@NoteType))
					AND n.NoteText LIKE @NoteText
					AND (DATEDIFF(day, @FromDate, n.NoteDateTime)>=0 AND DATEDIFF(day, n.NoteDateTime, @ToDate)>=0)
	ELSE
		INSERT INTO @TempTableVar
		SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID
		FROM		NotesHistory n, Employee e
		WHERE		((@SearchByAccount = 0 AND n.DebtorID = @DebtorID) OR n.BillID = @AccountID)
					AND n.EmployeeID *= e.EmployeeID 
					AND (@NoteType = ' ' OR UPPER(NoteType) = UPPER(@NoteType))
					AND n.NoteText LIKE @NoteText
					AND (DATEDIFF(day, @FromDate, n.NoteDateTime)>=0 AND DATEDIFF(day, n.NoteDateTime, @ToDate)>=0)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
	ELSE
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
		WHERE	RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize)		

	RETURN @RowCount

END
GO

/******  Script Closed. Go next: Step015_3  ******/