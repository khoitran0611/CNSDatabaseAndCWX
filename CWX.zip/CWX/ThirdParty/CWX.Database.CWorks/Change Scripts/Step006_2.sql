  GO
/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_UpdateList]    Script Date: 03/05/2008 14:17:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_QueueSortMaster_UpdateList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_QueueSortMaster_UpdateList]

GO
/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_UpdateList]    Script Date: 03/05/2008 14:18:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_QueueSortMaster_UpdateList] 
	@QueuePriorities xml,
	@Enabled bit
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @QueueID int
	DECLARE @SortDirection char(4)
	DECLARE @SortID int

	IF @Enabled = 1
		SET @SortID = 1
	ELSE
		SET @SortID = 0

	DECLARE @tbQueuePriority table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4)
	)

	DECLARE @NewQueueID int
	SET @NewQueueID = 1

	DECLARE QueuePriorityCrsr CURSOR FOR
	SELECT
		ParamValues.QueuePriority.value('./@QueueID','int') AS QueueID,
		ParamValues.QueuePriority.value('./@SortDirection','char(4)') AS SortDirection
	FROM
		@QueuePriorities.nodes('/QueuePriorities/QueuePriority') as ParamValues(QueuePriority)

	OPEN QueuePriorityCrsr

	FETCH NEXT FROM QueuePriorityCrsr
	INTO @QueueID, @SortDirection

	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO @tbQueuePriority
		SELECT
			@NewQueueID, Description, QueueColumn, @SortID, @SortDirection
		FROM
			QueueSortMaster
		WHERE
			QueueId = @QueueID

		IF @Enabled = 1
			SET @SortID = @SortID + 1
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM QueuePriorityCrsr
		INTO @QueueID, @SortDirection
	END

	DELETE FROM QueueSortMaster
	IF( @@ERROR <> 0)
        GOTO Cleanup

	INSERT INTO QueueSortMaster SELECT * FROM @tbQueuePriority
	IF( @@ERROR <> 0)
        GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE QueuePriorityCrsr
	DEALLOCATE QueuePriorityCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END

GO
/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_AddRemove]    Script Date: 03/05/2008 14:17:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_QueueSortMaster_AddRemove]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_QueueSortMaster_AddRemove]

GO
/****** Object:  StoredProcedure [dbo].[CWX_QueueSortMaster_AddRemove]    Script Date: 03/05/2008 14:17:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_QueueSortMaster_AddRemove] 
	@QueuePriorities xml
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @tbQueuePriority table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4)
	)

	DECLARE @NewQueueID int
	SET @NewQueueID = 1

	DECLARE @QueueID int
	DECLARE @Description varchar(60)

	DECLARE @SortID int
	IF EXISTS (SELECT QueueId FROM QueueSortMaster WHERE sortid = 0)
		SET @SortID = 0
	ELSE
		SET @SortID = @NewQueueID

	DECLARE QueuePriorityCrsr CURSOR FOR
	SELECT
		ParamValues.QueuePriority.value('./@QueueID','int') AS QueueID,
		ParamValues.QueuePriority.value('./@Description','varchar(60)') AS Description
	FROM
		@QueuePriorities.nodes('/QueuePriorities/QueuePriority') as ParamValues(QueuePriority) 

	OPEN QueuePriorityCrsr

	FETCH NEXT FROM QueuePriorityCrsr
	INTO @QueueID, @Description

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @SortID > 0
			SET @SortID = @NewQueueID

		IF @QueueID = 0
			INSERT INTO @tbQueuePriority
			VALUES(@NewQueueID, @Description, '"' + @Description + '"', @SortID, 'ASC ')
		ELSE
			INSERT INTO @tbQueuePriority
			SELECT
				@NewQueueID, Description, QueueColumn, @SortID, SortDirection
			FROM
				QueueSortMaster
			WHERE
				QueueId = @QueueID
		
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM QueuePriorityCrsr
		INTO @QueueID, @Description
	END

	DELETE FROM QueueSortMaster
	IF( @@ERROR <> 0)
		GOTO Cleanup

	INSERT INTO QueueSortMaster SELECT * FROM @tbQueuePriority
	IF( @@ERROR <> 0)
		GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE QueuePriorityCrsr
	DEALLOCATE QueuePriorityCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END


GO
/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_UpdateList]    Script Date: 03/05/2008 13:01:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AllocationSortMaster_UpdateList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AllocationSortMaster_UpdateList]

GO
/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_UpdateList]    Script Date: 03/05/2008 13:01:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 27th, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AllocationSortMaster_UpdateList] 
	-- Add the parameters for the stored procedure here
	@AccountAllocationSorts xml,
	@Enabled bit
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @QueueID int
	DECLARE @SortDirection char(4)

	DECLARE @NewQueueID int
	SET @NewQueueID = 1

	DECLARE @SortID int
	IF @Enabled = 1
		SET @SortID = 1
	ELSE
		SET @SortID = 0

	DECLARE @tbAccountAllocationSort table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4),
		SQLFormat varchar(100)
	)

	DECLARE AccountAllocationSortCrsr CURSOR FOR
    SELECT
		ParamValues.AccountAllocationSort.value('./@AccountAllocationSortID','int') AS AccountAllocationSortID,
		ParamValues.AccountAllocationSort.value('./@SortDirection','char(4)') AS SortDirection
	FROM
		@AccountAllocationSorts.nodes('/AccountAllocationSorts/AccountAllocationSort') as ParamValues(AccountAllocationSort) 

	OPEN AccountAllocationSortCrsr

	FETCH NEXT FROM AccountAllocationSortCrsr
	INTO @QueueID, @SortDirection

	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO @tbAccountAllocationSort
		SELECT
			@NewQueueID, Description, QueueColumn, @SortID, @SortDirection, SQLFormat
		FROM
			AllocationSortMaster
		WHERE
			QueueId = @QueueID

		IF @Enabled = 1
			SET @SortID = @SortID + 1
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM AccountAllocationSortCrsr
		INTO @QueueID, @SortDirection
	END

	DELETE FROM AllocationSortMaster
	IF( @@ERROR <> 0)
        GOTO Cleanup

	INSERT INTO AllocationSortMaster SELECT * FROM @tbAccountAllocationSort
	IF( @@ERROR <> 0)
        GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE AccountAllocationSortCrsr
	DEALLOCATE AccountAllocationSortCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_AddRemove]    Script Date: 03/05/2008 13:27:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AllocationSortMaster_AddRemove]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AllocationSortMaster_AddRemove]

GO
/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_AddRemove]    Script Date: 03/05/2008 13:27:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AllocationSortMaster_AddRemove] 
	@AccountAllocationSorts xml
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @tbAccountAllocationSort table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4),
		SQLFormat varchar(100)
	)

	DECLARE @NewQueueID int
	DECLARE @QueueID int
	DECLARE @Description varchar(60)
	DECLARE @SQLFormat varchar(100)

	SET @NewQueueID = 1

	DECLARE @SortID int
	IF EXISTS (SELECT QueueId FROM AllocationSortMaster WHERE sortid = 0)
		SET @SortID = 0
	ELSE
		SET @SortID = @NewQueueID

	DECLARE AccountAllocationSortCrsr CURSOR FOR
	SELECT
		ParamValues.AccountAllocationSort.value('./@AccountAllocationSortID','int') AS AccountAllocationSortID,
		ParamValues.AccountAllocationSort.value('./@Description','varchar(60)') AS Description,
		ParamValues.AccountAllocationSort.value('./@SQLFormat','varchar(100)') AS SQLFormat
	FROM
		@AccountAllocationSorts.nodes('/AccountAllocationSorts/AccountAllocationSort') as ParamValues(AccountAllocationSort) 

	OPEN AccountAllocationSortCrsr

	FETCH NEXT FROM AccountAllocationSortCrsr
	INTO @QueueID, @Description, @SQLFormat

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @SortID > 0
			SET @SortID = @NewQueueID

		IF @QueueID = 0
			INSERT INTO @tbAccountAllocationSort
			VALUES(@NewQueueID, @Description, '"' + @Description + '"', @SortID, 'ASC ', @SQLFormat)
		ELSE
			INSERT INTO @tbAccountAllocationSort
			SELECT
				@NewQueueID, Description, QueueColumn, @SortID, SortDirection, SQLFormat
			FROM
				AllocationSortMaster
			WHERE
				QueueId = @QueueID
		
		SET @NewQueueID = @NewQueueID + 1

		FETCH NEXT FROM AccountAllocationSortCrsr
		INTO @QueueID, @Description, @SQLFormat
	END

	DELETE FROM AllocationSortMaster
	IF( @@ERROR <> 0)
		GOTO Cleanup

	INSERT INTO AllocationSortMaster SELECT * FROM @tbAccountAllocationSort
	IF( @@ERROR <> 0)
		GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE AccountAllocationSortCrsr
	DEALLOCATE AccountAllocationSortCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END

GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_DeleteAll]    Script Date: 03/04/2008 16:53:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleTable_DeleteAll]

GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_DeleteAll]    Script Date: 03/04/2008 16:53:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleTable_DeleteAll] 
	@RuleType tinyint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	--Delete RuleOther
	DELETE RuleOthers WHERE RuleId IN (SELECT ID FROM RuleTable WHERE RuleType = @RuleType)
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Delete RuleCriteria
	DELETE RuleCriteria WHERE RuleId IN (SELECT ID FROM RuleTable WHERE RuleType = @RuleType)
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Delete RuleTable
	DELETE RuleTable WHERE RuleType = @RuleType
	IF( @@ERROR <> 0)
        GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END