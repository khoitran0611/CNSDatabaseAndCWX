-- Script is applied on version 2.2.24, 2.2.25

-- Scripts 2.2.24:
/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 07/31/2008 10:43:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetQueueStatsByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 07/31/2008 10:43:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <17 June 2008>
-- Description:	<Get Queue Statistic by Collector for chart>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int
	
AS
BEGIN

	DECLARE @BeforeDays INT
	DECLARE @AfterDays INT

	IF (@ReportTime = 0)
		BEGIN
			SELECT
				CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) as QueueDate,
				ISNULL(COUNT(DISTINCT AccountID),0) AS AccountCount,
				ISNULL(SUM(BillBalance),0) AS AccountBalance
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
									  AND CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
									  AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121))
				AND SystemStatusID in (1,5)
			GROUP BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
			ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))
		END
	ELSE
		BEGIN
			SELECT
				CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) as QueueDate,
				ISNULL(COUNT(DISTINCT AccountID),0) AS AccountCount,
				ISNULL(SUM(BillBalance),0) AS AccountBalance
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
									  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID in (1,5)
			GROUP BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
			ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))
		END
END
GO

TRUNCATE TABLE TempDebtorXml
GO

-- Scripts 2.2.25:
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetAvailablePool]    Script Date: 07/31/2008 14:09:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetAvailablePool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetAvailablePool]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetAvailablePool]    Script Date: 07/31/2008 14:10:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Jul 10, 2008
-- Description:	Get all avalable pool
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_GetAvailablePool]
	@EmployeeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT EmployeeID AS PoolID, EmployeeID, Description
	FROM Employee
	WHERE
		EmployeeStatus <> 'R' AND EmployeeType = 'P'
		AND EmployeeID NOT IN (SELECT PoolID FROM EmployeePool WHERE EmployeeID = @EmployeeID)
	ORDER BY Description
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetSelectedPool]    Script Date: 07/31/2008 14:11:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetSelectedPool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetSelectedPool]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetSelectedPool]    Script Date: 07/31/2008 14:11:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Jul 10, 2008
-- Description:	Get all selected pool
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_GetSelectedPool]
	@EmployeeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT p.PoolID, e.EmployeeID, e.Description
	FROM EmployeePool p
	LEFT JOIN Employee e ON e.EmployeeID = p.PoolID
	WHERE
		e.EmployeeStatus <> 'R'
		AND p.EmployeeID = @EmployeeID
	ORDER BY e.Description
END
GO
/******  Script Closed. Go next: Step017_1  ******/