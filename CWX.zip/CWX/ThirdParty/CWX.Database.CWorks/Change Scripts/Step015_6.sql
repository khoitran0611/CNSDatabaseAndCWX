-- Script is applied on version 2.1.13, 2.1.14
/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 07/11/2008 16:04:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetQueueStatsByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 07/11/2008 16:04:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <17 June 2008>
-- Description:	<Get Queue Statistic by Collector>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int
	
AS
BEGIN

	DECLARE @BeforeDays INT
	DECLARE @AfterDays INT

	IF (@ReportTime = 0)
		BEGIN
			DECLARE @QueueDate smalldatetime
			DECLARE @AccountCount int
			DECLARE @AccountBalance money

			DECLARE @Temp table
			(
				EmployeeID int,
				QueueDate smalldatetime,
				AccountCount int,
				AccountBalance money
			)

			DECLARE @Index int
			SET @Index = -7

			WHILE @Index < 7
			BEGIN
				SET @QueueDate = GETDATE() + @Index
				SET @AccountCount = 0
				SET @AccountBalance = 0

				SELECT
					@AccountCount = ISNULL(COUNT(AccountID),0),
					@AccountBalance = ISNULL(SUM(BillBalance),0)
				FROM Account
				WHERE 
					CONVERT(VARCHAR(10),QueueDate,121) = CONVERT(VARCHAR(10),@QueueDate,121)
					AND SystemStatusID = 5 
					AND EmployeeID = @EmployeeID
				GROUP BY EmployeeID, CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
				ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))

				INSERT INTO @Temp VALUES(@EmployeeID, @QueueDate, @AccountCount, @AccountBalance)

				SET @Index = @Index + 1
			END

			SELECT * FROM @Temp
		END
	ELSE
		BEGIN
			SELECT EmployeeID, CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) as QueueDate, ISNULL(COUNT(AccountID),0) AS AccountCount, ISNULL(SUM(BillBalance),0) AS AccountBalance 
			FROM Account 
			WHERE SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))

			GROUP BY EmployeeID, CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
			ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))
		END
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]    Script Date: 07/11/2008 16:08:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetTotalQueueStatsByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]    Script Date: 07/11/2008 16:08:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Long Nguyen>
-- Create date: <Jul 11, 2008>
-- Description:	<Get Queue Statistic by Collector>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int
AS
BEGIN

	DECLARE @AccountCount int
	DECLARE @Touched int
	DECLARE @Actioned int
	DECLARE @Worked int
	DECLARE @Contacted int
	DECLARE @Promised int
	DECLARE @AccountBalance money

	IF (@ReportTime = 0)
		BEGIN
			SELECT
				@AccountCount = ISNULL(COUNT(DISTINCT AccountID),0),
				@AccountBalance = ISNULL(SUM(BillBalance),0)
			FROM Account
			WHERE 
				CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID

			SELECT
				@Touched = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			WHERE 
				CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID = 8

			SELECT
				@Actioned = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			WHERE 
				CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8

			SELECT
				@Worked = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND av.ConsiderWorked = 1

			SELECT
				@Contacted = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND av.ProductivityID = 2

			SELECT
				@Promised = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND av.ProductivityID = 1

			SELECT
				@AccountCount AS AccountCount,
				@Touched AS Touched,
				@Actioned AS Actioned,
				@Worked AS Worked,
				@Contacted AS Contacted,
				@Promised AS Promised,
				@AccountBalance AS AccountBalance
		END
	ELSE
		BEGIN
			SELECT
				@AccountCount = ISNULL(COUNT(DISTINCT AccountID),0),
				@AccountBalance = ISNULL(SUM(BillBalance),0)
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID

			SELECT
				@Touched = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			WHERE 
				a.AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID = 8

			SELECT
				@Actioned = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			WHERE 
				a.AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8

			SELECT
				@Worked = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				a.AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND av.ConsiderWorked = 1

			SELECT
				@Contacted = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				a.AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND av.ProductivityID = 2

			SELECT
				@Promised = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				a.AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND av.ProductivityID = 1

			SELECT
				@AccountCount AS AccountCount,
				@Touched AS Touched,
				@Actioned AS Actioned,
				@Worked AS Worked,
				@Contacted AS Contacted,
				@Promised AS Promised,
				@AccountBalance AS AccountBalance
		END
END
GO

/****** Object:  Table [dbo].[Legal_HearingTypes]    Script Date: 06/17/2008 09:29:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_HearingTypes](
	[HearingTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_HearingTypes_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_HearingTypes] PRIMARY KEY CLUSTERED 
(
	[HearingTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 11, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_HearingTypes
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_HearingTypes' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_HearingTypes
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_HearingTypes_RowStatus] DEFAULT 'A'
END
GO

-- Scripts 2.1.14:

-- =======================================================================
-- Author:			Long Nguyen
-- Create date:		Jul 14, 2008
-- Description:		Change label from 'Legal  Forwarder' to 'Legal Group',
--					'Legal NextAction' to 'Legal Solicitors'
-- Effected table:	QueryMaster
-- =======================================================================
UPDATE QueryMaster SET Description='Legal Group' WHERE ID=23
UPDATE QueryMaster SET Description='Legal Solicitors' WHERE ID=25
GO

/****** Object:  Table [dbo].[Legal_Groups]    Script Date: 07/14/2008 10:24:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Legal_Groups]') AND type in (N'U'))
DROP TABLE [dbo].[Legal_Groups]
GO
/****** Object:  Table [dbo].[Legal_Groups]    Script Date: 07/14/2008 10:24:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Legal_Groups]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Legal_Groups](
	[GroupID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[AgentID] [int] NULL,
	[CreditorID] [int] NULL,
	[SolicitorID] [int] NULL,
	[Note] [nvarchar](4000) NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_Groups_LastEditDate]  DEFAULT (getdate()),
	[Status] [char](1) NOT NULL CONSTRAINT [DF_Legal_Groups_Status]  DEFAULT ('A'),
 CONSTRAINT [PK_Legal_Groups] PRIMARY KEY CLUSTERED 
(
	[GroupID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 14, 2008
-- Description:		Add more columns
-- Effected table:	Legal_GroupDebtors
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id 
WHERE o.name = 'Legal_GroupDebtors' and c.name = 'LegalTypeID')
BEGIN
	ALTER TABLE dbo.Legal_GroupDebtors ADD
		[AccountID] [int] NOT NULL,
		LegalTypeID int NULL,
		IsDefendant bit NOT NULL CONSTRAINT DF_Legal_GroupDebtors_IsDefendant DEFAULT 0,
		IsInclude bit NOT NULL CONSTRAINT DF_Legal_GroupDebtors_IsInclude DEFAULT 0,
		IsPrincipal bit NOT NULL CONSTRAINT DF_Legal_GroupDebtors_IsPrincipal DEFAULT 0
END
GO

-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 14, 2008
-- Description:		Add more columns
-- Effected table:	Legal_GroupDebts
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id 
WHERE o.name = 'Legal_GroupDebts' and c.name = 'IsInclude')
BEGIN
	ALTER TABLE dbo.Legal_GroupDebts ADD
		IsInclude bit NOT NULL CONSTRAINT DF_Legal_GroupDebts_IsInclude DEFAULT 0,
		IsPrincipal bit NOT NULL CONSTRAINT DF_Legal_GroupDebts_IsPrincipal DEFAULT 0
END
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Jul 14, 2008
-- Description:		Add Legal_LegalTypes table
-- Effected table:	Legal_LegalTypes
-- =======================================================================
/****** Object:  Table [dbo].[Legal_Groups]    Script Date: 07/14/2008 10:24:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Legal_LegalTypes]') AND type in (N'U'))
DROP TABLE [dbo].[Legal_Groups]
GO
/****** Object:  Table [dbo].[Legal_LegalTypes]    Script Date: 07/02/2008 09:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_LegalTypes](
	[LegalTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Seq] [int] NOT NULL CONSTRAINT [DF_Legal_LegalTypes_Seq]  DEFAULT ((0)),
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_LegalTypes_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_LegalTypes] PRIMARY KEY CLUSTERED 
(
	[LegalTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Jul 14, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_LegalTypes
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_LegalTypes' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_LegalTypes
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_LegalTypes_RowStatus] DEFAULT 'A'
END
GO

/******  Script Closed. Go next: Step016_1  ******/