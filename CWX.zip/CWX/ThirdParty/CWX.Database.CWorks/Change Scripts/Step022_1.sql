 -- Script is applied on version 2.8.1, 2.8.2, 2.8.3, 2.8.4, 2.8.5, 2.8.6, 2.8.7, 2.8.8, 2.8.9, 2.8.10, 2.8.11, 2.8.12, 2.8.13, 2.8.14, 2.8.15, 2.8.16, 2.8.18, 2.8.20
 
 -- Scripts 2.8.1:
 
 /****** Object:  StoredProcedure [dbo].[CWX_Account_IsGroupedAccount]    Script Date: 10/14/2008 16:41:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_IsGroupedAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_IsGroupedAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_IsGroupedAccount]    Script Date: 10/14/2008 16:41:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Account_IsGroupedAccount]
	-- Add the parameters for the stored procedure here
	@AccountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	IF EXISTS(	SELECT *
				FROM Legal_GroupDebts a
					INNER JOIN Legal_Groups b ON a.GroupID = b.GroupID
				WHERE a.AccountID = @AccountID AND a.IsInclude = 1 AND b.Status <> 'R')
		RETURN 1
	ELSE
		RETURN 0
END
GO



-- =============================================================
-- Author:		Minh Dam
-- Create date: Otc 14, 2008
-- Description:	Create store procedure CWX_Legal_CustomFieldTypes_IsEditable.
-- =============================================================
/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFieldTypes_IsEditable]    Script Date: 10/14/2008 16:54:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_CustomFieldTypes_IsEditable]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_CustomFieldTypes_IsEditable]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFieldTypes_IsEditable]    Script Date: 10/14/2008 16:55:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Legal_CustomFieldTypes_IsEditable]
	-- Add the parameters for the stored procedure here
	@CustomFieldTypeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF NOT EXISTS (SELECT * FROM Legal_CustomFields WHERE CustomFieldTypeID = @CustomFieldTypeID)
		RETURN 1
	ELSE
		RETURN 0
END
GO



-- =============================================
-- Description:	Get transaction type and total amount of each transaction.
-- History:
--	2008/09/24	[Binh Truong]	Init version.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Transaction_GetTransactionType]
	@AccountID int,
	@ClientID int,
	@PaymentAllocationRuleID int = 0
AS
BEGIN
	SET NOCOUNT ON
	IF @PaymentAllocationRuleID = 0
	BEGIN
		SELECT     T.TransactionType, SUM(ISNULL(T.TransactionAmount, 0)) AS Amount, TT.Description, TT.TransactionCode, TT.AffectBalance
			FROM         Transactions AS T INNER JOIN
								  TransactionType AS TT ON T.TransactionType = TT.ID
			WHERE     (T.AccountID = @AccountID) AND (T.ClientID = @ClientID) AND (T.TXN_POSTED = 'N')
			GROUP BY T.TransactionType, TT.Description, TT.TransactionCode, TT.AffectBalance
	END
	ELSE
	BEGIN
		SELECT	T1.*
		FROM
				(SELECT     T.TransactionType, SUM(ISNULL(T.TransactionAmount, 0)) AS Amount, TT.Description, TT.TransactionCode, TT.AffectBalance
				FROM         Transactions AS T INNER JOIN
									  TransactionType AS TT ON T.TransactionType = TT.ID
				WHERE     (T.AccountID = @AccountID) AND (T.ClientID = @ClientID) AND (T.TXN_POSTED = 'N')
				GROUP BY T.TransactionType, TT.Description, TT.TransactionCode, TT.AffectBalance) as T1 LEFT OUTER JOIN
					Legal_PaymentAllocationRuleItems AS LP ON T1.TransactionType = LP.TransactionTypeID
		WHERE	LP.PaymentAllocationRuleID = @PaymentAllocationRuleID
		ORDER BY LP.Seq
	END	
END
GO

-- =============================================================
-- Author:		Minh Dam
-- Create date: Otc 15, 2008
-- Description:	Add columns WaiverCondition and WaiverMonths to table DefineFees
-- =============================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'DefineFees' and c.name = 'WaiverCondition')
BEGIN
	ALTER TABLE DefineFees
		ADD WaiverCondition varchar(2) NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'DefineFees' and c.name = 'WaiverMonths')
BEGIN
	ALTER TABLE DefineFees
		ADD WaiverMonths int NULL
END
GO

UPDATE QueryMaster SET SQL2 = 'EXEC SearchByLegalGroupCode %E, %1' WHERE ID = 23
GO

-- Scripts 2.8.3:
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 10/23/2008 14:10:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-14
-- Description:	Get the list of Groups of selecting customer
-- History:	2008-07-14	[Thao Nguyen]	Init version.
--			2008-10-23	[Minh Dam]		Add new parameter AccountID.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
	-- Add the parameters for the stored procedure here
	@DebtorID int,
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int

	SELECT
		ROW_NUMBER() OVER (ORDER BY G.Code) AS RowNumber,
		G.*	
	INTO #Temp
	FROM (SELECT DISTINCT
		a.GroupID,
		a.Code,
		a.[Description],
		ISNULL(a.GroupedAccountID, 0) AS GroupedAccountID,
		Case When d.GroupID is not null then 1 else 0 end HasStep
		FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
			LEFT JOIN Account c ON b.AccountID = c.AccountID
			LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> 'R') d ON a.GroupID = d.GroupID
		WHERE  a.Status <> 'R' and c.DebtorID = @DebtorID 
			AND b.AccountID = @AccountID AND b.IsInclude = 1) G	

	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
	
END
GO

-- Scripts 2.8.4:
-- =============================================================
-- Author:		Long Nguyen
-- Create date: Otc 23, 2008
-- Description:	Import new letter.
-- =============================================================

BEGIN TRANSACTION

UPDATE DefineLetters SET LetterDesc = RTRIM(LTRIM(LetterDesc))

CREATE TABLE #Temp
(
	[LetterID] [int] IDENTITY(1,1) NOT NULL,
	[LetterDesc] [varchar](50) NULL,
	[LetterType] [tinyint] NULL,
	[FileName] [varchar](255) NULL,
	[Destination] [tinyint] NULL,
	[Copies] [tinyint] NOT NULL,
	[Parameters] [varchar](255) NULL,
	[AccountSpecific] [bit] NOT NULL,
	[Narration] [varchar](255) NULL,
	[DocumentPath] [varchar](250) NULL,
	[EmailAddress] [varchar](250) NULL,
	[ClientID] [int] default(0)
)

INSERT INTO #Temp VALUES('Acounts Not Worked On',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\AccountsNotWorkedOn.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Account Status by Collector',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\AccountStatusByCollector.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Account Status by Cycle',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\AccountStatusByCycle.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Audit Trail',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\AuditTrail.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Collector Effectiveness and Efficiency',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\Collector Effectiveness and Efficiency.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Collector Hourly Activity',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\CollectorHourlyActivity.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Collector Queue',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\CollectorQueue.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Collector Queue by Status',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\CollectorQueueByStatus.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Collector Queue by Status Summary',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\CollectorQueueByStatusSummary.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Current Account Queue Inventory',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\CurrentAccountQueueInventory.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Daily Allocation by Employee',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\DailyAllocationByEmployee.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Daily Allocation by Rule',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\DailyAllocationByRule.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Employee Account List',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\EmployeeAccountList.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Friendly Reminder',0,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\FriendlyReminder.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Letter Generated',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\LetterGenerated.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Payment Detail by Collector',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\PaymentDetailByCollector.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Promise Detail by Date Paid or Date Taken',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\PromiseDetaiByDatePaidOrDateTaken.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Promise Sumary',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\PromiseSummary.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Supervisor Queue by Status',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\SupervisorQueueByStatus.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Total Inventory',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\TotalInventory.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('First Notice Of Letter',0,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\1stNoticeofDemand.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Daily Routine Upload Statistics',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\Daily Routine Upload Statistics.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Second Notice Of Letter',0,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\2ndNoticeofDemand.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Third Notice Of Letter',0,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\3rdNoticeofDemand.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('View Order Letter',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\ViewOrderedLetter.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Letters Generated',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\LetterGenerated.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Discount Agreement',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\DiscoutAgreement.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Reschedule Agreement',1,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\CWXReports\RescheduleAgreement.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)
INSERT INTO #Temp VALUES('Lawyers Demand Letter',0,'C:\Inetpub\wwwroot\CWX281\Report\ReportFiles\LawyersDemandLetter.rpt',1,0,'',0,'','D:\CWX\LetterHistory','',0)

DECLARE DefineLetterCrsr CURSOR FOR
SELECT * FROM #Temp

OPEN DefineLetterCrsr

DECLARE @LetterID int
DECLARE @LetterDesc varchar(50)
DECLARE @LetterType tinyint
DECLARE @FileName varchar(255)
DECLARE @Destination tinyint
DECLARE @Copies tinyint
DECLARE @Parameters varchar(255)
DECLARE @AccountSpecific bit
DECLARE @Narration varchar(255)
DECLARE @DocumentPath varchar(250)
DECLARE @EmailAddress varchar(250)
DECLARE @ClientID int

FETCH NEXT FROM DefineLetterCrsr
INTO @LetterID, @LetterDesc, @LetterType, @FileName, @Destination, @Copies, @Parameters, @AccountSpecific, @Narration, @DocumentPath, @EmailAddress, @ClientID

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @LetterID = NULL

	SELECT @LetterID = LetterID FROM DefineLetters WHERE LetterDesc = @LetterDesc
	
	IF @LetterID IS NOT NULL --The letter already existed, just update the select lettter
		UPDATE DefineLetters
		SET
			LetterType = @LetterType,
			[FileName] = @FileName,
			Destination = @Destination,
			Copies = @Copies,
			Parameters = @Parameters,
			AccountSpecific = @AccountSpecific,
			Narration = @Narration,
			DocumentPath = @DocumentPath,
			EmailAddress = @EmailAddress,
			ClientID = @ClientID
		WHERE LetterID = @LetterID
	ELSE --The letter does not exist, insert new record into DefineLetters
		INSERT INTO DefineLetters VALUES(@LetterDesc, @LetterType, @FileName, @Destination, @Copies, @Parameters, @AccountSpecific, @Narration, @DocumentPath, @EmailAddress, @ClientID)

	FETCH NEXT FROM DefineLetterCrsr
	INTO @LetterID, @LetterDesc, @LetterType, @FileName, @Destination, @Copies, @Parameters, @AccountSpecific, @Narration, @DocumentPath, @EmailAddress, @ClientID
END

CLOSE DefineLetterCrsr
DEALLOCATE DefineLetterCrsr

DROP TABLE #Temp

COMMIT TRANSACTION
GO

-- Scripts 2.8.5:

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetList]    Script Date: 10/24/2008 15:38:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetList]    Script Date: 10/24/2008 15:38:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-18
-- Description:	Get all Legal Group by Debtor
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetList] 
	-- Add the parameters for the stored procedure here
	@DebtorID int,
	@AccountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT a.*
	FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebtors b ON a.GroupID = b.GroupID AND DebtorID is not NULL
			LEFT JOIN Legal_GroupDebts b2 ON a.GroupID = b2.GroupID
	WHERE  a.Status <> 'R' and b.DebtorID = @DebtorID AND b2.AccountID = @AccountID AND b2.IsInclude = 1
	ORDER BY Code, [Description]
END

GO

-- Scripts 2.8.6:

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'DefineFees' and c.name = 'WaiverAmount')
BEGIN
	ALTER TABLE DefineFees ADD WaiverAmount money
END
GO

-- Scripts 2.8.7:
/****** Object:  StoredProcedure [dbo].[CWX_Notes_GetWithType]    Script Date: 10/27/2008 18:37:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Get notes from database
-- History:
--	2008/05/08	[Tai Ly]		Init version.
--	2008/10/03	[Binh Truong]	Update NoteText varchar to nvarchar datatype.
--  2008/10/28	[Minh Dam]		Select BillID and InvoiceNumber.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Notes_GetWithType]
	@DebtorID	int,
	@AccountID	int,
	@NoteText	nvarchar(1000) = '',
	@NoteType	varchar(1) = ' ',	
	@Month		int = -1,
	@Day		int = -1,
	@FromDate	datetime = '1753-01-01',
	@ToDate		datetime = '9999-12-31',
	@SearchHistory bit = 0,
	@SearchByAccount bit = 0,
	@PageSize	int = 10,
	@PageIndex	int = 0
AS
BEGIN
	DECLARE @TempTableVar table(
		RowNumber		int,
		NoteDateTime	datetime,
		NoteText		nvarchar(1000),
		NoteType		varchar(1),
		UserID			varchar(10),
		AccountID		int,
		InvoiceNumber	varchar(50)
	);

	IF @Month >= 0
	BEGIN
		SET @FromDate = DATEADD(month, -1*@Month, GETDATE())
		SET @ToDate = GETDATE()
	END
	ELSE IF @Day >= 0
	BEGIN
		SET @FromDate = DATEADD(day, -1*@Day, GETDATE())
		SET @ToDate = GETDATE()
	END

	SELECT @NoteText = '%' + @NoteText + '%';

	IF @SearchHistory = 0
		INSERT INTO @TempTableVar
		SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, 
					n.NoteDateTime, n.NoteText, n.NoteType, e.UserID, n.BillID, a.InvoiceNumber
		FROM		NotesCurrent n, Employee e, Account a
		WHERE		((@SearchByAccount = 0 AND n.DebtorID = @DebtorID) OR n.BillID = @AccountID)
					AND n.EmployeeID *= e.EmployeeID 
					AND n.BillID = a.AccountID
					AND (@NoteType = ' ' OR UPPER(NoteType) = UPPER(@NoteType))
					AND n.NoteText LIKE @NoteText
					AND (DATEDIFF(day, @FromDate, n.NoteDateTime)>=0 AND DATEDIFF(day, n.NoteDateTime, @ToDate)>=0)
	ELSE
		INSERT INTO @TempTableVar
		SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, 
					n.NoteDateTime, n.NoteText, n.NoteType, e.UserID, n.BillID, a.InvoiceNumber
		FROM		NotesHistory n, Employee e, Account a
		WHERE		((@SearchByAccount = 0 AND n.DebtorID = @DebtorID) OR n.BillID = @AccountID)
					AND n.EmployeeID *= e.EmployeeID 
					AND n.BillID = a.AccountID
					AND (@NoteType = ' ' OR UPPER(NoteType) = UPPER(@NoteType))
					AND n.NoteText LIKE @NoteText
					AND (DATEDIFF(day, @FromDate, n.NoteDateTime)>=0 AND DATEDIFF(day, n.NoteDateTime, @ToDate)>=0)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT	NoteDateTime, NoteText, NoteType, UserID, AccountID, InvoiceNumber
		FROM	@TempTableVar
	ELSE
		SELECT	NoteDateTime, NoteText, NoteType, UserID, AccountID, InvoiceNumber
		FROM	@TempTableVar
		WHERE	RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize)		

	RETURN @RowCount

END
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		29/10/2008
-- Description:		Drop column 'Name' from table Legal_Solicitors
-- =======================================================================
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Solicitors' and c.name = 'Name')
BEGIN
	ALTER TABLE Legal_Solicitors
		DROP COLUMN [Name]
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]    Script Date: 10/28/2008 16:55:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Get paging list of LegalContacts belong to a parent contact type
-- History:
--	2008/08/28	[Minh Dam]		Init version.
--	2008/09/19	[Binh Truong]	Add @ParentContactID parameter.
--	2008/10/28	[Minh Dam]		Change column 'Name' to 'Firm' in Solicitor section.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]
	@ParentContactType int = 0,
	@ParentContactID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @Sql varchar(5000)

	DECLARE @RowCount int
	SELECT	@RowCount=COUNT(ContactID)
	FROM	Legal_Contacts
	WHERE	(@ParentContactType = 0 OR ParentType = @ParentContactType) AND 
			(@ParentContactID = 0 OR ParentID = @ParentContactID) AND
			[Status] <> 'R'

	SET @Sql =
			'WITH Temp AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY b.Code) AS RowNumber,
					a.ContactID,
					a.ParentType, 
					b.Code [Code], 
					b.@@NameField [Name],
					IsNull(Title,'''') Title, IsNull(FirstName, '''') FirstName, IsNull(LastName, '''') LastName, 
					a.[Description]
				FROM Legal_Contacts a
					LEFT JOIN @@RefTable b ON a.ParentID = b.@@RefField
				WHERE	(@@ParentContactType = 0 OR a.ParentType = @@ParentContactType) AND 
						(@@ParentContactID = 0 OR a.ParentID = @@ParentContactID) AND
						a.Status <> ''R''
			)

			SELECT ContactID, ParentType, Code + Case When [Name]<>'''' Then '' - '' + [Name] Else '''' End CodeAndName, 
					LTRIM(Case When Title<>'''' Then Title Else '''' End + Case When FirstName<>'''' Then '' ''+FirstName Else '''' End + 
						Case When LastName<>'''' Then '' '' + LastName Else '''' End) ContactName,
					[Description]
			FROM Temp WHERE RowNumber BETWEEN @@PageIndex * @@PageSize + 1 AND (@@PageIndex + 1) * @@PageSize
			'

	IF (@ParentContactType = 1) -- Solicitors
	BEGIN
		SET @Sql = REPLACE(@Sql, '@@RefTable', 'Legal_Solicitors')
		SET @Sql = REPLACE(@Sql, '@@RefField', 'SolicitorID')
		SET @Sql = REPLACE(@Sql, '@@NameField', 'Firm')
	END
	ELSE IF (@ParentContactType = 2) -- Agents
	BEGIN
		SET @Sql = REPLACE(@Sql, '@@RefTable', 'Legal_Agents')
		SET @Sql = REPLACE(@Sql, '@@RefField', 'AgentID')
		SET @Sql = REPLACE(@Sql, '@@NameField', 'Name')
	END
	ELSE -- Creditors
	BEGIN
		SET @Sql = REPLACE(@Sql, '@@RefTable', 'Legal_Creditors')
		SET @Sql = REPLACE(@Sql, '@@RefField', 'CreditorID')
		SET @Sql = REPLACE(@Sql, '@@NameField', 'CommonName')
	END
	
	SET @Sql = REPLACE(@Sql, '@@ParentContactType', cast(@ParentContactType as varchar))
	SET @Sql = REPLACE(@Sql, '@@ParentContactID', cast(@ParentContactID as varchar))
	SET @Sql = REPLACE(@Sql, '@@PageSize', cast(@PageSize as varchar))
	SET @Sql = REPLACE(@Sql, '@@PageIndex', cast(@PageIndex as varchar))

	--PRINT @Sql
	EXEC sp_sqlexec @Sql
	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingList]    Script Date: 10/28/2008 16:55:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-08
-- Description:	Get paging list of LegalContacts, alphabetically ascending order by 
--				'Parent Contact Employee Name' group by 'Parent Contact Type'
-- History:
--	2008/07/08	[Thao Nguyen]	Init version.
--	2008/10/28	[Minh Dam]		Change b.Name to b.Firm
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingList]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(ContactID)
	FROM Legal_Contacts
	WHERE Status <> 'R'

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.ParentType, Coalesce(b.Code, c.Code, d.Code)) AS RowNumber,
			a.ContactID,
			a.ParentType, 
			Coalesce(b.Code, c.Code, d.Code) Code, 
			Coalesce(b.Firm, c.CommonName, d.Name) [Name],
			IsNull(Title,'') Title, IsNull(FirstName, '') FirstName, IsNull(LastName, '') LastName, 
			a.[Description]		
		FROM Legal_Contacts a
			LEFT JOIN Legal_Solicitors b ON a.ParentID = b.SolicitorID AND ParentType = '1'
			LEFT JOIN Legal_Creditors c ON a.ParentID = c.CreditorID AND ParentType = '3'
			LEFT JOIN Legal_Agents d ON a.ParentID = d.AgentID AND ParentType = '2'
		WHERE  a.Status <> 'R'
	)

	SELECT ContactID, ParentType, Code + Case When [Name]<>'' Then ' - ' + [Name] Else '' End CodeAndName, 
			LTRIM(Case When Title<>'' Then Title Else '' End + Case When FirstName<>'' Then ' '+FirstName Else '' End + 
				Case When LastName<>'' Then ' ' + LastName Else '' End) ContactName,
			[Description]
	FROM Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
GO

/****** Object:  Table [dbo].[CWX_AccountFeeWaivers]    Script Date: 10/28/2008 17:18:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountFeeWaivers]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_AccountFeeWaivers]
GO
/****** Object:  Table [dbo].[CWX_AccountFeeWaivers]    Script Date: 10/28/2008 17:18:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CWX_AccountFeeWaivers](
	[RecordID] [int] IDENTITY(1,1) NOT NULL,
	[AccountID] [int] NULL,
	[FeeID] [int] NULL,
	[TransactionID] [int] NULL,
	[TransactionDate] [smalldatetime] NULL,
	[WaiverMonths] [int] NULL,
 CONSTRAINT [PK_CWX_AccountFeeWaivers] PRIMARY KEY CLUSTERED 
(
	[RecordID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

/****** Object:  StoredProcedure [dbo].[CWX_DefineFees_FillListByAccount]    Script Date: 10/28/2008 17:26:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DefineFees_FillListByAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DefineFees_FillListByAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DefineFees_FillListByAccount]    Script Date: 10/28/2008 17:26:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Oct 27, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DefineFees_FillListByAccount]
	@AccountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT f.*
	FROM DefineFees f
	LEFT JOIN (SELECT FeeID, AccountID, TransactionDate, WaiverMonths FROM CWX_AccountFeeWaivers WHERE AccountID=@AccountID) t ON t.FeeID = f.FeeID
	WHERE
		(f.FeeType = 0)
		OR (ISNULL(t.FeeID, 0) = 0)
		OR (ISNULL(f.WaiverMonths, 0) <= 0)
		OR (CONVERT(varchar(10),DATEADD(month, t.WaiverMonths, t.TransactionDate),121) <= CONVERT(varchar(10), GETDATE(), 121))
END
GO

-- Scripts 2.8.8:
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Agents_GetPagingListByAgentType]    Script Date: 10/28/2008 18:52:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Agents_GetPagingListByAgentType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Agents_GetPagingListByAgentType]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Agents_GetPagingListByAgentType]    Script Date: 10/28/2008 18:52:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 28-Oct-2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Agents_GetPagingListByAgentType]
	-- Add the parameters for the stored procedure here
	@AgentTypeID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT ROW_NUMBER() OVER(ORDER BY b.[Code]) as RowNumber,
			a.AgentID, a.[Code], a.[Name], a.[Description] ,
			b.[Code] + ' - ' + b.[Description] as AgentType,
			c.[Code] + ' - ' + c.[Description]  as AgentSubtype 
	INTO #Temp
	FROM Legal_Agents a
		LEFT JOIN Legal_AgentTypes b ON a.[AgentTypeID] = b.[AgentTypeID]
		LEFT JOIN Legal_AgentSubtypes c ON a.[AgentSubtypeID] = c.[AgentSubtypeID]
	WHERE a.Status <> 'R'
		AND (@AgentTypeID = 0 OR a.AgentTypeID = @AgentTypeID)
	
	SET @RowCount = @@ROWCOUNT

	SELECT 	[AgentID], [Code], [Name], [Description], [AgentType], [AgentSubtype]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

-- Scripts 2.8.9:

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_IsLegalRateExisted]    Script Date: 10/29/2008 13:39:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Rates_IsLegalRateExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Rates_IsLegalRateExisted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_IsLegalRateExisted]    Script Date: 10/29/2008 13:39:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 05, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Rates_IsLegalRateExisted]
	-- Add the parameters for the stored procedure here
	@ID int = 0,
	@RateCode nvarchar(50),
	@StartDate smalldatetime = NULL,
	@EndDate smalldatetime = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT COUNT(ID)
	FROM Legal_Rates
	WHERE
		(@ID = 0 OR ID <> @ID)
		AND (RateCode = @RateCode)
		AND
		(
			(@EndDate IS NULL) OR
			((@StartDate IS NULL OR CONVERT(VARCHAR(10),@StartDate,121) < CONVERT(VARCHAR(10),EndDate,121)) AND (StartDate IS NULL OR CONVERT(VARCHAR(10),@EndDate,121) > CONVERT(VARCHAR(10),StartDate,121)))
		)
		AND Status <> 'R'
END
GO

-- Scripts 2.8.10:

/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateFee]    Script Date: 10/29/2008 15:07:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UpdateFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_UpdateFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateFee]    Script Date: 10/29/2008 15:07:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Khoa Dang
CREATE PROCEDURE [dbo].[CWX_Account_UpdateFee]
	@AccountID int,
	@FeeID int
AS
BEGIN
	declare @feeAmount float
	declare @feeType int, @effectBalance smallint	

	/* get fee type and amount of fee */
	select @feeType=FeeType, @feeAmount = case FeeType when 0 then AmountOfFee else FeePercent end,
		@effectBalance = AffectBalance
		from DefineFees d 
			left join TransactionType t on d.TransactionTypeID = t.ID
		where FeeID = @FeeID

	if (@feeType is null) or (@feeAmount is null) /* do not find any information of fee and then cancel transaction */
		return
	
	if (@feeType = 0)	
	begin		
		if (@effectBalance = 1)
			update Account
			set
				BillBalance = BillBalance + @feeAmount,
				BillOtherCharges = @feeAmount
			where AccountID = @AccountID
		else if (@effectBalance = 2)
			update Account 
			set 
				BillBalance = BillBalance - @feeAmount,
				BillOtherCharges = @feeAmount
			where AccountID = @AccountID	
	end
	else 
	begin
		if (@feeType = 1)
		begin
			if (@effectBalance = 1) 
				update Account 
				set 
					BillBalance = BillBalance + (BillBalance * @feeAmount),
					BillOtherCharges = BillBalance * @feeAmount
				where AccountID = @AccountID
			else if (@effectBalance = 2)
				update Account 
				set 
					BillBalance = BillBalance - (BillBalance * @feeAmount),
					BillOtherCharges = BillBalance * @feeAmount
				where AccountID = @AccountID
		end
		else
		begin
			if (@effectBalance = 1) 
				update Account 
				set 
					BillBalance = BillBalance + (BillAmount * @feeAmount),
					BillOtherCharges = BillAmount * @feeAmount
				where AccountID = @AccountID	
			else if (@effectBalance = 2) 
				update Account 
				set 
					BillBalance = BillBalance - (BillAmount * @feeAmount),
					BillOtherCharges = BillAmount * @feeAmount
				where AccountID = @AccountID	
		end
	end
END
GO


-- =============================================
-- Description:	Get Transaction List by TransactionType with a custom column is "Transaction Code - Description"
-- History:
--	2008/08/29	[Thuy Nguyen]	Init version.
--	2008/09/29	[Binh Truong]	Select total transaction amount.
--	2008/10/29	[Binh Truong]	Add DateToPost field.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList] 		
	@AccountID int = 0,
	@TransactionType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;	

	DECLARE @querystring varchar(1000);

	CREATE TABLE #Temp(
		RowNumber int,		
		TransactionID int not null,
		DateToPost smalldatetime,
		DateOfTransaction smalldatetime,
		TransactionAmount money,		
		TransactionComment nvarchar(150),
		TransactionCodeDescription nvarchar(150),
		TransactionType int
	);

	
	SET @querystring = 'INSERT INTO #Temp
		SELECT 
		ROW_NUMBER() OVER (ORDER BY  t.DateOfTransaction DESC, TransactionID DESC) AS RowNumber,
		t.TransactionID, t.DateToPost, t.DateOfTransaction, t.TransactionAmount, t.TransactionComment,
		tt.TransactionCode + '' - '' + tt.Description as TransactionCodeDescription,
		t.TransactionType
	FROM Transactions t LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID
	WHERE t.AccountID = ' + cast(@AccountID as varchar) + ' AND t.ParentTransactionID IS NULL'

	IF @TransactionType<>0 SET @querystring = @querystring + ' AND t.TransactionType = ' + cast(@TransactionType as varchar);
	
	EXEC (@querystring)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	
	SELECT	SUM(TransactionAmount) as TotalAmount
	FROM	Transactions
	WHERE	AccountID = @AccountID AND
			(@TransactionType=0 OR TransactionType = @TransactionType) AND
			ParentTransactionID IS NULL
			
	
	RETURN @RowCount

END
GO

-- Scripts 2.8.11:
-- =============================================
-- Description:	
-- History:
--	2008/08/10	[Minh Dam]		Init version.
--	2008/09/29	[Minh Dam]		Sort CustomFields by Sequence Number
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFields_GetCustomFields]    Script Date: 10/29/2008 17:23:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Legal_CustomFields_GetCustomFields]
	-- Add the parameters for the stored procedure here
	@ActivityID int,
	@ActivityType int,
	@FieldType int,
	@FieldTypeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF (@FieldTypeID IS NOT NULL AND @FieldTypeID > 0)
	BEGIN
		SELECT	a.[CustomFieldTypeID], a.[Description], a.[Type],
				ISNULL(b.[CustomFieldID],0) [CustomFieldID], ISNULL(b.[ActivityID],0) [ActivityID], 
				ISNULL(b.[ActivityType],0) [ActivityType], ISNULL(b.[Value],'') [Value]
		FROM
			(SELECT [CustomFieldTypeID], [Description], [Type], [Seq]
			FROM Legal_CustomFieldTypes 
			WHERE [Status] <> 'R' AND FieldType = @FieldType AND FieldTypeID = @FieldTypeID) a
			LEFT JOIN
			(SELECT [CustomFieldID], [CustomFieldTypeID], [ActivityID], [ActivityType], [Value]
			FROM Legal_CustomFields 
			WHERE ActivityID = @ActivityID AND ActivityType = @ActivityType) b
			ON a.CustomFieldTypeID = b.CustomFieldTypeID
		ORDER BY a.[Seq], a.[Description]
	END

	ELSE
	BEGIN
		SELECT	a.[CustomFieldTypeID], a.[Description], a.[Type],
				ISNULL(b.[CustomFieldID],0) [CustomFieldID], ISNULL(b.[ActivityID],0) [ActivityID], 
				ISNULL(b.[ActivityType],0) [ActivityType], ISNULL(b.[Value],'') [Value]
		FROM
			(SELECT [CustomFieldID], [CustomFieldTypeID], [ActivityID], [ActivityType], [Value]
			FROM Legal_CustomFields
			WHERE ActivityID = @ActivityID AND ActivityType = @ActivityType) b
			INNER JOIN
			(SELECT [CustomFieldTypeID], [Description], [Type], [Seq]
			FROM Legal_CustomFieldTypes
			WHERE [Status] <> 'R' AND FieldType = @FieldType) a
			ON a.CustomFieldTypeID = b.CustomFieldTypeID
		ORDER BY a.[Seq], a.[Description]
	END

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFieldTypes_GetPagingListByFieldType]    Script Date: 10/29/2008 17:24:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_CustomFieldTypes_GetPagingListByFieldType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_CustomFieldTypes_GetPagingListByFieldType]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFieldTypes_GetPagingListByFieldType]    Script Date: 10/29/2008 17:25:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Description:	
-- History:
--	[2008-10-29]	[Minh Dam]		Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_CustomFieldTypes_GetPagingListByFieldType]
	-- Add the parameters for the stored procedure here
	@FieldType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @RowCount int
	
	SELECT	ROW_NUMBER() OVER (ORDER BY a.[Description] ASC) AS RowNumber,
			a.[CustomFieldTypeID], a.[Code], a.[Description], a.[Seq] as Sequence, a.[Type], a.[FieldType], 
			CASE WHEN a.[FieldType]=1 THEN b.[Code] + ' - ' + b.[Description]
				 ELSE c.[Code] + ' - ' + c.[Description] END AS [FieldTypeCodeAndDescription]
	INTO #Temp
	FROM Legal_CustomFieldTypes a
		LEFT JOIN Legal_GroupStepTypes b ON a.FieldTypeID = b.GroupStepTypeID
		LEFT JOIN Legal_HearingTypes c ON a.FieldTypeID = c.HearingTypeID
	WHERE a.[Status] <> 'R'
		AND (@FieldType = 0 OR a.FieldType = @FieldType)

	SET @RowCount = @@ROWCOUNT

	SELECT CustomFieldTypeID, Code, [Description], Sequence, [Type], [FieldType], FieldTypeCodeAndDescription
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO


-- =============================================
-- Author:		Minh Dam
-- Description:	Change data length of column Descripton to 250
-- =============================================
ALTER TABLE Legal_LegalTypes
	ALTER COLUMN [Description] nvarchar(250) NOT NULL
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_IsLegalRateExisted]    Script Date: 10/29/2008 17:33:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Rates_IsLegalRateExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Rates_IsLegalRateExisted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_IsLegalRateExisted]    Script Date: 10/29/2008 17:33:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 05, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Rates_IsLegalRateExisted]
	-- Add the parameters for the stored procedure here
	@ID int = 0,
	@RateCode nvarchar(50),
	@StartDate smalldatetime = NULL,
	@EndDate smalldatetime = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT COUNT(ID)
	FROM Legal_Rates
	WHERE
		(@ID = 0 OR ID <> @ID)
		AND (RateCode = @RateCode)
		AND
		(
			(EndDate IS NULL) OR
			((@StartDate IS NULL OR CONVERT(VARCHAR(10),@StartDate,121) < CONVERT(VARCHAR(10),EndDate,121)) AND (@EndDate IS NULL OR StartDate IS NULL OR CONVERT(VARCHAR(10),@EndDate,121) > CONVERT(VARCHAR(10),StartDate,121)))
		)
		AND Status <> 'R'
END
GO

-- Scripts 2.8.13:

/****** Object:  StoredProcedure [dbo].[CWX_Account_CreateGroupAccount]    Script Date: 10/30/2008 09:37:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CreateGroupAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_CreateGroupAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_CreateGroupAccount]    Script Date: 10/30/2008 09:37:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description:	Create a new account by group ID.
-- History:
--	2008/09/03	[LongNguyen]	Init version.
--	2008/09/19	[Binh Truong]	Delete a record in TempDebtorXml where debtorID = debtorID of created account. Purpose: clear cache.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_CreateGroupAccount]
	@GroupID int
AS
BEGIN
	DECLARE @BillBalance money
	DECLARE @BillAmount money
	
	--Increase 'Account' by one
	UPDATE IdentityFields SET FieldValue = FieldValue + 1 WHERE TableName = 'Account'

	--Insert new Account with all detail from the primary account of group	
	SELECT @BillBalance=SUM(a.BillBalance), @BillAmount=SUM(a.BillAmount)
	FROM Legal_GroupDebts g
	LEFT JOIN Account a ON a.AccountID = g.AccountID
	WHERE g.IsInclude=1 AND g.GroupID=@GroupID

	DECLARE @PrimaryAccountID int
	SELECT @PrimaryAccountID=AccountID FROM Legal_GroupDebts WHERE GroupID = @GroupID AND IsPrimary = 1

	DECLARE @AccountID int
	SELECT @AccountID=MAX(AccountID)+1 FROM Account

	INSERT INTO Account
	SELECT @AccountID
		  ,DebtorID
		  ,EmployeeID
		  ,ClientID
		  ,AgencyStatusID
		  ,SystemStatusID
		  ,ActionCodeID
		  ,OfficeID
		  ,MCode
		  ,CCode
		  ,@AccountID --,InvoiceNumber
		  ,AccountType
		  ,AccountClass
		  ,QueueDate
		  ,DateOfService
		  ,SubmissionDate
		  ,LastClientTransactionDate
		  ,RoutinePayment
		  ,PaymentPlan
		  ,PatientName
		  ,@BillAmount
		  ,@BillBalance
		  ,BillOtherCharges
		  ,ClientPaysLegalFees
		  ,AccountForwarded
		  ,CreditReported
		  ,CreditReportedDate
		  ,ClientPercent
		  ,ClientOCPercent
		  ,SplitPayment
		  ,CurrentAction
		  ,CurrentActionDate
		  ,NoLetterBefore
		  ,NoFeeBefore
		  ,MaintainOfficer
		  ,AccountAge
		  ,LastEditDate
		  ,LastEditBy
		  ,LastVerifyDate
		  ,AllocRuleID
		  ,AutoProcRuleID
		  ,LastExtractionDate
		  ,LastAllocationDate
		  ,LastAutoProcessDate
		  ,ExtractionRuleID
		  ,AccountForwardedTo
		  ,CurrencyCode
		  ,BatchNumber
		  ,InterestRate
		  ,ActionEmployee
		  ,LastPromiseBatch
		  ,CreditReportRequested
		  ,CreditReportRequestedBy
		  ,CreditReportRequestedOn
		  ,CreditReportRequestStatus
		  ,WriteOffDate
		  ,LastInterestDate
		  ,TempEmployeeID
		  ,OAManaged
		  ,InterfaceID
		  ,Delq_string
		  ,SortOrder
		  ,Allocated
		  ,BrokenCount
		  ,CARD_FILE_NO
		  ,ARREAR_PATH
		  ,BUCKET_TYPE
		  ,OLD_BUCKET_TYPE
		  ,CARD_TYPE
		  ,BRANCH_CODE
		  ,FORMULA
		  ,BANK_CODE
		  ,PAID
		  ,OtherAccountNo
		  ,TENOR
		  ,FORMULA_FLAG
		  ,MINIMUM_DUE
		  ,CURRENT_BKT_NUM
		  ,PREV_BKT_NUM
		  ,productivecount
		  ,contactcount
		  ,nocontactcount
		  ,DelqHistory
		  ,BucketMovement
		  ,DPDMovement
		  ,PreviousAllocRuleID
		  ,OnLeaveEmpID
		  ,LeaveLoadRelFlag
		  ,CurrentReason
		  ,CurrentReasonDate
		  ,CurrentNextAction
		  ,CurrentNextActionDate
		  ,CurrentCallResult
		  ,CurrentCallResultDate
		  ,CampaignId
		  ,CloseDate
		  ,MaxContact
		  ,AssignmentType
		  ,PoolSelected
		  ,IsPending
		FROM Account
		WHERE AccountID = @PrimaryAccountID

	--Delete redundant data
	--DELETE AccountOther WHERE AccountID = @AccountID
	--Insert into AccountOther
	INSERT INTO AccountOther
	SELECT @AccountID
		  ,Long1
		  ,Long2
		  ,Long3
		  ,Long4
		  ,Long5
		  ,Long6
		  ,Long7
		  ,Long8
		  ,Long9
		  ,Long10
		  ,Long11
		  ,Long12
		  ,Long13
		  ,Long14
		  ,Long15
		  ,Long16
		  ,Long17
		  ,Long18
		  ,Long19
		  ,Long20
		  ,Long21
		  ,Long22
		  ,Long23
		  ,Long24
		  ,Long25
		  ,Long26
		  ,Long27
		  ,Long28
		  ,Long29
		  ,Long30
		  ,Long31
		  ,Long32
		  ,Long33
		  ,Long34
		  ,Long35
		  ,Long36
		  ,Long37
		  ,Long38
		  ,Long39
		  ,Long40
		  ,Long41
		  ,Long42
		  ,Long43
		  ,Long44
		  ,Long45
		  ,Long46
		  ,Long47
		  ,Long48
		  ,Long49
		  ,Long50
		  ,Money1
		  ,Money2
		  ,Money3
		  ,Money4
		  ,Money5
		  ,Money6
		  ,Money7
		  ,Money8
		  ,Money9
		  ,Money10
		  ,Money11
		  ,Money12
		  ,Money13
		  ,Money14
		  ,Money15
		  ,Money16
		  ,Money17
		  ,Money18
		  ,Money19
		  ,Money20
		  ,Money21
		  ,Money22
		  ,Money23
		  ,Money24
		  ,Money25
		  ,Money26
		  ,Money27
		  ,Money28
		  ,Money29
		  ,Money30
		  ,Money31
		  ,Money32
		  ,Money33
		  ,Money34
		  ,Money35
		  ,Money36
		  ,Money37
		  ,Money38
		  ,Money39
		  ,Money40
		  ,Money41
		  ,Money42
		  ,Money43
		  ,Money44
		  ,Money45
		  ,Money46
		  ,Money47
		  ,Money48
		  ,Money49
		  ,Money50
		  ,Date1
		  ,Date2
		  ,Date3
		  ,Date4
		  ,Date5
		  ,Date6
		  ,Date7
		  ,Date8
		  ,Date9
		  ,Date10
		  ,Date11
		  ,Date12
		  ,Date13
		  ,Date14
		  ,Date15
		  ,Date16
		  ,Date17
		  ,Date18
		  ,Date19
		  ,Date20
		  ,Date21
		  ,Date22
		  ,Date23
		  ,Date24
		  ,Date25
		  ,Date26
		  ,Date27
		  ,Date28
		  ,Date29
		  ,Date30
		  ,Date31
		  ,Date32
		  ,Date33
		  ,Date34
		  ,Date35
		  ,Date36
		  ,Date37
		  ,Date38
		  ,Date39
		  ,Date40
		  ,Date41
		  ,Date42
		  ,Date43
		  ,Date44
		  ,Date45
		  ,Date46
		  ,Date47
		  ,Date48
		  ,Date49
		  ,Date50
		  ,String1
		  ,String2
		  ,String3
		  ,String4
		  ,String5
		  ,String6
		  ,String7
		  ,String8
		  ,String9
		  ,String10
		  ,String11
		  ,String12
		  ,String13
		  ,String14
		  ,String15
		  ,String16
		  ,String17
		  ,String18
		  ,String19
		  ,String20
		  ,String21
		  ,String22
		  ,String23
		  ,String24
		  ,String25
		  ,String26
		  ,String27
		  ,String28
		  ,String29
		  ,String30
		  ,String31
		  ,String32
		  ,String33
		  ,String34
		  ,String35
		  ,String36
		  ,String37
		  ,String38
		  ,String39
		  ,String40
		  ,String41
		  ,String42
		  ,String43
		  ,String44
		  ,String45
		  ,String46
		  ,String47
		  ,String48
		  ,String49
		  ,String50
		  ,Additional1
		  ,Additional2
		  ,Additional3
		  ,Additional4
		  ,ArrearsHistory
		FROM AccountOther
		WHERE AccountID = @PrimaryAccountID
		
	DELETE FROM TempDebtorXml
	WHERE DebtorID = (SELECT DebtorID FROM Account WHERE AccountID = @AccountID)

	SELECT @AccountID
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_IsLegalRateExisted]    Script Date: 10/30/2008 10:12:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Rates_IsLegalRateExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Rates_IsLegalRateExisted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_IsLegalRateExisted]    Script Date: 10/30/2008 10:12:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO








-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 05, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Rates_IsLegalRateExisted]
	-- Add the parameters for the stored procedure here
	@ID int = 0,
	@RateCode nvarchar(50),
	@StartDate smalldatetime = NULL,
	@EndDate smalldatetime = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT COUNT(ID)
	FROM Legal_Rates
	WHERE
		(@ID = 0 OR ID <> @ID)
		AND (RateCode = @RateCode)
		AND
		(
			(EndDate IS NULL) OR
			((@StartDate IS NULL OR CONVERT(VARCHAR(10),@StartDate,121) <= CONVERT(VARCHAR(10),EndDate,121)) AND (@EndDate IS NULL OR StartDate IS NULL OR CONVERT(VARCHAR(10),@EndDate,121) >= CONVERT(VARCHAR(10),StartDate,121)))
		)
		AND Status <> 'R'
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 10/30/2008 14:46:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 10/30/2008 14:46:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get Transaction List by TransactionType with a custom column is "Transaction Code - Description"
-- History:
--	2008/08/29	[Thuy Nguyen]	Init version.
--	2008/09/29	[Binh Truong]	Select total transaction amount.
--	2008/10/29	[Binh Truong]	Add DateToPost field.
--	2008/10/30	[Binh Truong]	Exclude Transactions.Descriptor = ''A''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList] 		
	@AccountID int = 0,
	@TransactionType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;	

	DECLARE @querystring varchar(1000);

	CREATE TABLE #Temp(
		RowNumber int,		
		TransactionID int not null,
		DateToPost smalldatetime,
		DateOfTransaction smalldatetime,
		TransactionAmount money,		
		TransactionComment nvarchar(150),
		TransactionCodeDescription nvarchar(150),
		TransactionType int
	);

	
	SET @querystring = ''INSERT INTO #Temp
		SELECT 
		ROW_NUMBER() OVER (ORDER BY  t.DateOfTransaction DESC, TransactionID DESC) AS RowNumber,
		t.TransactionID, t.DateToPost, t.DateOfTransaction, t.TransactionAmount, t.TransactionComment,
		tt.TransactionCode + '''' - '''' + tt.Description as TransactionCodeDescription,
		t.TransactionType
	FROM Transactions t LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID
	WHERE	t.AccountID = '' + cast(@AccountID as varchar) + '' AND 
			t.ParentTransactionID IS NULL AND 
			t.Descriptor <> ''''A''''
			''

	IF @TransactionType<>0 SET @querystring = @querystring + '' AND t.TransactionType = '' + cast(@TransactionType as varchar);
	
	EXEC (@querystring)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	
	SELECT	SUM(TransactionAmount) as TotalAmount
	FROM	Transactions
	WHERE	AccountID = @AccountID AND
			(@TransactionType=0 OR TransactionType = @TransactionType) AND
			ParentTransactionID IS NULL AND
			Descriptor <> ''A'' -- exclude additional transaction		
	
	RETURN @RowCount
END
' 
END
GO


-- Scripts 2.8.14:

/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_Add]    Script Date: 10/30/2008 16:59:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_Add]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CosigneeInformation_Add]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_Add]    Script Date: 10/30/2008 16:59:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 25, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_Add] 
	-- Add the parameters for the stored procedure here
	@PersonID int,
	@SocialSecurityNumber varchar(25),
	@AlternateID1 varchar(50),
	@AlternateID1Name varchar(50),
	@Title varchar(50),
	@FirstName varchar(50),
	@MiddleName varchar(50),
	@LastName varchar(50),
	@DateOfBirth smalldatetime = NULL,
	@PString3 varchar(25),
	@Language int,
	@Email varchar(50),
	@NO_Of_Years_Resi varchar(10),
	@PMoney1 money,
	@PString2 varchar(10),
	@PString5 varchar(50),
	@Nationality varchar(50),
	@Fax varchar(30),
	@DriversLicenseNumber varchar(25),
	@PMoney2 money,
	@Profession varchar(50),
	@Business_Type varchar(50),
	@Position varchar(50),
	@Department varchar(35),
	@Employee_Number varchar(50),
	@Employment varchar(50),
	@Employer_Code char(4),
	@EmploymentPhone varchar(30),
	@EmploymentPhoneExtension varchar(8),
	@FriendName varchar(50),
	@Friend_Off_Phone varchar(50),
	@Friend_Res_Phone varchar(30),
	@Friend_FaxNo varchar(30),

	@AccountID int,
	@Relationship_Type varchar(20),

	@EmployeeID int
AS
BEGIN
	DECLARE @TranStarted bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	--If PersonInformation already existed
	IF @PersonID > 0
		--Update the PersonInformation
		UPDATE PersonInformation
		SET
			SocialSecurityNumber = @SocialSecurityNumber,
			PString1 = @SocialSecurityNumber,
			AlternateID1 = @AlternateID1,
			AlternateID1Name = @AlternateID1Name,
			Title = @Title,
			FirstName = @FirstName,
			MiddleName = @MiddleName,
			LastName = @LastName,
			DateOfBirth = @DateOfBirth,
			PString3 = @PString3,
			[Language] = @Language,
			Email = @Email,
			NO_Of_Years_Resi = @NO_Of_Years_Resi,
			PMoney1 = @PMoney1,
			PString2 = @PString2,
			PString5 = @PString5,
			Nationality = @Nationality,
			Fax = @Fax,
			DriversLicenseNumber = @DriversLicenseNumber,
			PMoney2 = @PMoney2,
			Profession = @Profession,
			Business_Type = @Business_Type,
			Position = @Position,
			Department = @Department,
			Employee_Number = @Employee_Number,
			Employment = @Employment,
			Employer_Code = @Employer_Code,
			EmploymentPhone = @EmploymentPhone,
			EmploymentPhoneExtension = @EmploymentPhoneExtension,
			FriendName = @FriendName,
			Friend_Off_Phone = @Friend_Off_Phone,
			Friend_Res_Phone = @Friend_Res_Phone,
			Friend_FaxNo = @Friend_FaxNo
		WHERE
			PersonID = @PersonID
		IF( @@ERROR <> 0)
        GOTO Cleanup
	ELSE
	BEGIN
		--Generate new PersonID
		SELECT @PersonID = MAX(PersonID) + 1
		FROM PersonInformation

		UPDATE IdentityFields
		SET FieldValue = @PersonID
		WHERE LOWER(TableName) = LOWER('PersonInformation')
		IF( @@ERROR <> 0)
        GOTO Cleanup

		--Add new PersonInformation
		INSERT INTO PersonInformation
		(
			PersonID,
			SocialSecurityNumber,
			PString1,
			AlternateID1,
			AlternateID1Name,
			Title,
			FirstName,
			MiddleName,
			LastName,
			DateOfBirth,
			PString3,
			[Language],
			Email,
			NO_Of_Years_Resi,
			PMoney1,
			PString2,
			PString5,
			Nationality,
			Fax,
			DriversLicenseNumber,
			PMoney2,
			Profession,
			Business_Type,
			Position,
			Department,
			Employee_Number,
			Employment,
			Employer_Code,
			EmploymentPhone,
			EmploymentPhoneExtension,
			FriendName,
			Friend_Off_Phone,
			Friend_Res_Phone,
			Friend_FaxNo
		)
		VALUES
		(
			@PersonID,
			@SocialSecurityNumber,
			@SocialSecurityNumber,
			@AlternateID1,
			@AlternateID1Name,
			@Title,
			@FirstName,
			@MiddleName,
			@LastName,
			@DateOfBirth,
			@PString3,
			@Language,
			@Email,
			@NO_Of_Years_Resi,
			@PMoney1,
			@PString2,
			@PString5,
			@Nationality,
			@Fax,
			@DriversLicenseNumber,
			@PMoney2,
			@Profession,
			@Business_Type,
			@Position,
			@Department,
			@Employee_Number,
			@Employment,
			@Employer_Code,
			@EmploymentPhone,
			@EmploymentPhoneExtension,
			@FriendName,
			@Friend_Off_Phone,
			@Friend_Res_Phone,
			@Friend_FaxNo
		)
		IF( @@ERROR <> 0)
        GOTO Cleanup

		DECLARE @index int
		DECLARE @num int
		SET @num = 9
		
		--Add new 9 PersonAddress and 9 PersonPhone
		DECLARE @AddressID int
		SELECT @AddressID = MAX(AddressID)
		FROM PersonAddress

		UPDATE IdentityFields
		SET FieldValue = @AddressID + @num
		WHERE LOWER(TableName) = LOWER('PersonAddress')

		DECLARE @PhoneID int
		SELECT @PhoneID = MAX(PhoneID)
		FROM PersonPhone

		UPDATE IdentityFields
		SET FieldValue = @PhoneID + @num
		WHERE LOWER(TableName) = LOWER('PersonPhone')
		
		SET @index = 1
		WHILE @index <= @num
		BEGIN
			INSERT INTO PersonAddress
			(
				AddressID,
				PersonID,
				AddressType,
				AddressStatus,
				EmployeeID,
				CreateDate
			)
			VALUES
			(
				@AddressID + @index,
				@PersonID,
				@index,
				0,
				@EmployeeID,
				GETDATE()
			)
			IF( @@ERROR <> 0)
			GOTO Cleanup

			INSERT INTO PersonPhone
			(
				PhoneID,
				PersonID,
				PhoneType,
				PhoneStatus,
				EmployeeID,
				CreateDate
			)
			VALUES
			(
				@PhoneID + @index,
				@PersonID,
				@index,
				0,
				@EmployeeID,
				GETDATE()
			)
			IF( @@ERROR <> 0)
			GOTO Cleanup

			SET @index = @index + 1
		END
	END

	--Insert new CosigneeInformation
	DECLARE @InvoiceNumber varchar(50)
	DECLARE @DebtorID int
	DECLARE @InterfaceID int

	SELECT
		@InvoiceNumber = InvoiceNumber,
		@DebtorID = DebtorID,
		@InterfaceID = InterfaceID
	FROM Account
	WHERE AccountID = @AccountID

	--If CosigneeInformation already existed
	IF EXISTS (SELECT Bill FROM CosigneeInformation WHERE Bill = @AccountID AND PersonID = @PersonID)
	BEGIN
		UPDATE CosigneeInformation
		SET
			DebtorID = @DebtorID,
			Relationship_no = @SocialSecurityNumber,
			Relationship_Type = @Relationship_Type,
			Account_no = @InvoiceNumber,
			InterfaceID = @InterfaceID
		WHERE
			Bill = @AccountID AND PersonID = @PersonID
		IF( @@ERROR <> 0)
        GOTO Cleanup
	END
	ELSE
	BEGIN
		INSERT INTO CosigneeInformation
		(
			Bill,
			PersonID,
			DebtorID,
			Relationship_no,
			Relationship_Type,
			Account_no,
			InterfaceID
		)
		VALUES
		(
			@AccountID,
			@PersonID,
			@DebtorID,
			@SocialSecurityNumber,
			@Relationship_Type,
			@InvoiceNumber,
			@InterfaceID
		)
		IF( @@ERROR <> 0)
        GOTO Cleanup
	END

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

	SELECT @PersonID
END
GO


-- Scripts 2.8.15:
-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Oct 30, 2008
-- Description:		Add column 'DebtCauseID' to table 'Legal_Groups'
-- Effected table:	Legal_Creditors
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Groups' and c.name = 'DebtCauseID')
BEGIN
	ALTER TABLE Legal_Groups
		ADD DebtCauseID int NOT NULL
			CONSTRAINT [Legal_Groups_DebtCauseID] DEFAULT ('0')
END
GO

-- Scripts 2.8.16:
-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Oct 30, 2008
-- Description:		Add column 'AgingForApportion' and 'ApportionAllowed' to table 'ClientInformation'
-- Effected table:	Legal_Creditors
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'AgingForApportion')
BEGIN
	ALTER TABLE ClientInformation
		ADD AgingForApportion money NULL
			CONSTRAINT [ClientInformation_AgingForApportion] DEFAULT ('0')
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'ApportionAllowed')
BEGIN
	ALTER TABLE ClientInformation
		ADD ApportionAllowed int NULL
			CONSTRAINT [ClientInformation_ApportionAllowed] DEFAULT ('0')
END
GO

-- Scripts 2.8.18:

/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 10/31/2008 10:25:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXML]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_LoadXML]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 10/31/2008 10:25:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description:	Load all accounts with debtorID
-- History:
--	08/04/03	[Tai Ly]	Init version.
--	08/06/01	[Long Nguyen]	Add and remove some fields.
--	08/06/27	[Binh Truong]	Remove BatchNumber field.	
--	08/08/25	[Long Nguyen]	Remove @AdditionalTag
--	08/09/04	[Thuy Nguyen]	Remove CoSigner table reference
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int	
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/
	SELECT
			a.AccountID,
			ISNULL(l.LetterDesc, '') AS SENTBY, ISNULL(al.LetterStatus, '') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			p.AmountPromised AS FirstAmountPromised, p.PromiseFrequency AS FirstPromiseFrequency, p.Term AS FirstPromiseTerm, p.DatePromised, '' AS PROMISE,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL,
			lastpromise.LASTPROMISEDATE, lastpromise.LASTPROMISEAMOUNT, lastpromise.LASTPROMISESTATUS, lastpromise.LASTPROMISESTATUSDESC,
			(CASE ISNULL(lg.GroupedAccountID, 0) WHEN 0 THEN 0 ELSE 1 END) AS IsGroupedAccount
	INTO	#AccountTemp
	FROM	Account	 a
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN 'd' THEN 'day(s)'
						WHEN 'w' THEN 'week(s)'
						WHEN 'm' THEN 'month(s)'
						WHEN 'y' THEN 'year(s)'
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get last promise
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised AS LASTPROMISEAMOUNT,
					p2.DatePromised AS LASTPROMISEDATE,
					p2.Status AS LASTPROMISESTATUS,
					CASE p2.Status
						WHEN 0 THEN 'Not Due'
						WHEN 1 THEN 'Paid On Time'
						WHEN 2 THEN 'Paid Late'
						WHEN 3 THEN 'Broken Promise'
						WHEN 4 THEN 'Canceled'
						ELSE ''
					END AS LASTPROMISESTATUSDESC
				FROM AccountPromise p2 
				WHERE p2.PromiseID IN 
						(	SELECT TOP 1 PromiseID
							FROM (	SELECT PromiseID, DatePromised
									FROM AccountPromise 
									WHERE AccountID = p2.AccountID -- 69
							) as temp
							ORDER BY DatePromised DESC
						)) lastpromise ON lastpromise.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	--Check if account is GroupAccount
	LEFT JOIN Legal_Groups lg ON lg.GroupedAccountID = a.AccountID
	WHERE DebtorID = @DebtorID

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, nextAction.CodeDesc AS CurrentNextActionDesc, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised, #AccountTemp.FirstAmountPromised, #AccountTemp.FirstPromiseFrequency, #AccountTemp.FirstPromiseTerm
			, #AccountTemp.LASTPROMISEDATE, #AccountTemp.LASTPROMISEAMOUNT, #AccountTemp.LASTPROMISESTATUS, #AccountTemp.LASTPROMISESTATUSDESC
			, #AccountTemp.LASTCONTACTDATE, #AccountTemp.LASTCONTACTBY, #AccountTemp.PROMISETOPAY, #AccountTemp.PROMISEKEPT, #AccountTemp.PROMISEBROKEN, #AccountTemp.OUTGOINGCALL, #AccountTemp.NOACTIVITYDAYS
			, ISNULL(Account.IsPending, 0) AS IsPending
			, #AccountTemp.IsGroupedAccount
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID
			LEFT OUTER JOIN AccountCodeMaster nextAction on Account.CurrentNextAction = nextAction.CodeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END
GO


-- =============================================
-- Description:	Get transaction type and total amount of each transaction.
-- History:
--	2008/09/24	[Binh Truong]	Init version.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Transaction_GetTransactionType]
	@AccountID int,
	@ClientID int,
	@PaymentAllocationRuleID int = 0
AS
BEGIN
	SET NOCOUNT ON
	IF @PaymentAllocationRuleID = 0
	BEGIN
		SELECT     T.TransactionType, SUM(ISNULL(T.TransactionAmount, 0)) AS Amount, TT.Description, TT.TransactionCode, TT.AffectBalance
			FROM         Transactions AS T INNER JOIN
								  TransactionType AS TT ON T.TransactionType = TT.ID
			WHERE   (T.AccountID = @AccountID) AND 
					(T.ClientID = @ClientID) AND 
					(T.TXN_POSTED = 'N') AND
					(TT.AffectBalance = 1)
			GROUP BY T.TransactionType, TT.Description, TT.TransactionCode, TT.AffectBalance
	END
	ELSE
	BEGIN
		SELECT	T1.*
		FROM
				(SELECT     T.TransactionType, SUM(ISNULL(T.TransactionAmount, 0)) AS Amount, TT.Description, TT.TransactionCode, TT.AffectBalance
				FROM         Transactions AS T INNER JOIN
									  TransactionType AS TT ON T.TransactionType = TT.ID
				WHERE     (T.AccountID = @AccountID) AND (T.ClientID = @ClientID) AND (T.TXN_POSTED = 'N')
				GROUP BY T.TransactionType, TT.Description, TT.TransactionCode, TT.AffectBalance) as T1 LEFT OUTER JOIN
					Legal_PaymentAllocationRuleItems AS LP ON T1.TransactionType = LP.TransactionTypeID
		WHERE	LP.PaymentAllocationRuleID = @PaymentAllocationRuleID AND
				T1.AffectBalance = 1		
		ORDER BY LP.Seq
	END	
END
GO
/******  Script Closed.  ******/