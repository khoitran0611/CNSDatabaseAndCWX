 -- Scripts are applied on version 1.9.4 & 1.9.5
 UPDATE TempDebtorXml SET IsDirty = 1
 
 IF NOT EXISTS (SELECT * FROM InformationTable WHERE InfoID = 1 AND InfoType = 12)
	INSERT INTO InformationTable VALUES(1, 12, 0, '', 'ApplyTimeFormatForXml', NULL, 'True', 'A')
GO

ALTER TABLE RuleTable ADD SMS int Default 0
ALTER TABLE RuleTable ADD Email int Default 0
ALTER TABLE RuleTable ADD Fax int Default 0
GO

ALTER TABLE AccountLetterQueue ADD SMS varchar(50)
ALTER TABLE AccountLetterQueue ADD Email varchar(50)
ALTER TABLE AccountLetterQueue ADD Email_CC varchar(250)
ALTER TABLE AccountLetterQueue ADD Fax varchar(50)
GO

ALTER TABLE AccountLetter ADD SMS varchar(50)
ALTER TABLE AccountLetter ADD Email varchar(50)
ALTER TABLE AccountLetter ADD Email_CC varchar(250)
ALTER TABLE AccountLetter ADD Fax varchar(50)
GO

Update RuleTable set SMS = 0
Update RuleTable set Email = 0
Update RuleTable set Fax = 0
GO

Alter table DefineLetters add ClientID int default 0
GO

Update DefineLetters set ClientID = 0
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountCodeMaster_PromiseGiver_SoftDeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountCodeMaster_PromiseGiver_SoftDeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountCodeMaster_PromiseGiver_SoftDeleteAll]    Script Date: 06/10/2008 14:50:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountCodeMaster_PromiseGiver_SoftDeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_AccountCodeMaster_PromiseGiver_SoftDeleteAll] 
	@CodeType int = 5	
AS
BEGIN
	UPDATE
		AccountCodeMaster
	SET
		Status = ''R''
	WHERE
		CodeType = @CodeType AND CodeDesc <> ''Debtor''
END' 
END
GO

/******  Script Closed. Go next: Step013_5  ******/