 -- Script is applied on version 2.2.12, 2.2.13, 2.2.14

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Hearings_GetPagingList]    Script Date: 07/23/2008 16:46:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Hearings_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Hearings_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Hearings_GetPagingList]    Script Date: 07/23/2008 16:46:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Hearings_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =======================================================================
-- Author:		Tuan Luong
-- Create date: Jul 22, 2008
-- Description:	Get paging list of Legal Hearings
-- =======================================================================
CREATE PROCEDURE [dbo].[CWX_Legal_Hearings_GetPagingList]	
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		ROW_NUMBER() OVER (ORDER BY h.DateHearing) AS RowNumber,
		h.CourtID as Court,
		h.HearingID,
		h.GroupStepID,
		t.Code + '' - '' +  t.Description as CodeAndName,
		h.DateHearing
	INTO #Temp
	FROM Legal_Hearings h LEFT JOIN Legal_HearingTypes t 
	ON h.HearingTypeID = t.HearingTypeID
	WHERE  t.Status <> ''R''

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	ORDER BY DateHearing
	
	RETURN @RowCount
END


' 
END
GO


--Author: Sathya--

Update QueryMaster set SQL2 =  'EXEC CWX_Account_SearchByLegalEmployee %1, %2' where [ID] = 24
Update QueryMaster set SQL2 =  'EXEC CWX_Account_SearchByLegalForward  %1, %2' where [ID] = 25

Insert into QueryMaster values (27,	1,	'Legal Agent','EXEC SearchByLegalAgent %1, %2',	3,'EXEC CWX_Account_SearchByLegalAgent  %1, %2')
Insert into QueryParams values (27,	1,	'Legal Agents','','Select AgentID,[Name] from Legal_Agents where Status = '+''''+ 'A'+''''+' order by [Name]')

Alter Table Legal_Groups Add EmployeeId INT default 1001


set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- =============================================
-- Author:		KhoaDang
ALTER PROCEDURE [dbo].[SearchByLegalGroupCode](@GroupID INT,@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s,'
	SET @cStmt=@cStmt+'Legal_Groups g,'
	SET @cStmt=@cStmt+'Legal_GroupDebts gd'
	SET @cStmt=@cStmt+' where a.AccountID = gd.AccountID'
	SET @cStmt=@cStmt+' and gd.GroupID = g.GroupID'
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID and gd.IsInclude=1 and g.GroupID=' + STR(@GroupID)
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END


set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalForward] 
	-- Add the parameters for the stored procedure here
	@SolicitorID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
		INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
			INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END


set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalEmployee] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalAgent] 
	-- Add the parameters for the stored procedure here
	@AgentId int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
		INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
			INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]    Script Date: 07/23/2008 14:52:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetTotalQueueStatsByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]    Script Date: 07/23/2008 14:52:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		<Long Nguyen>
-- Create date: <Jul 11, 2008>
-- Description:	<Get Queue Statistic by Collector for the datagrid>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int
AS
BEGIN

	DECLARE @AccountCount int
	DECLARE @Touched int
	DECLARE @Actioned int
	DECLARE @Worked int
	DECLARE @Contacted int
	DECLARE @Promised int
	DECLARE @AccountBalance money

	IF (@ReportTime = 0)
		BEGIN

			SELECT
				@AccountCount = ISNULL(COUNT(DISTINCT AccountID),0),
				@AccountBalance = ISNULL(SUM(BillBalance),0)
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
								AND CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
								AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
								AND SystemStatusID in (1,5))

			SELECT
				@Touched = ISNULL(COUNT(DISTINCT AccountID),0)
					FROM AccountActions 
					where CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
						AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
						AND ResponsibleParty = @EmployeeID
						AND AccountID not in 
							(SELECT DISTINCT AccountID FROM AccountActions where ActionId <> 8
							AND CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
							AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
							AND ResponsibleParty = @EmployeeID)

			SELECT
				@Actioned = ISNULL(COUNT(DISTINCT AccountID),0)
			from AccountActions
			where CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ActionID <> 8
				AND ResponsibleParty = @EmployeeID

			SELECT
				@Worked = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ac.ActionID <> 8
				AND av.ConsiderWorked = 1
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Contacted = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 2
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Promised = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 1
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@AccountCount AS AccountCount,
				@Touched AS Touched,
				@Actioned AS Actioned,
				@Worked AS Worked,
				@Contacted AS Contacted,
				@Promised AS Promised,
				@AccountBalance AS AccountBalance
		END
	ELSE
		BEGIN
			SELECT
				@AccountCount = ISNULL(COUNT(DISTINCT AccountID),0),
				@AccountBalance = ISNULL(SUM(BillBalance),0)
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
									  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID in (1,5)

			SELECT
				@Touched = ISNULL(COUNT(DISTINCT AccountID),0)
			from AccountActions
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ResponsibleParty = @EmployeeID
				AND AccountID not in 
					(SELECT DISTINCT AccountID FROM AccountActions where ActionId <> 8
					AND CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
					AND ResponsibleParty = @EmployeeID)

			SELECT
				@Actioned = ISNULL(COUNT(DISTINCT AccountID),0)
			from AccountActions
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ActionID <> 8
				AND ResponsibleParty = @EmployeeID

			SELECT
				@Worked = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ac.ActionID <> 8
				AND av.ConsiderWorked = 1
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Contacted = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 2
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Promised = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 1
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@AccountCount AS AccountCount,
				@Touched AS Touched,
				@Actioned AS Actioned,
				@Worked AS Worked,
				@Contacted AS Contacted,
				@Promised AS Promised,
				@AccountBalance AS AccountBalance
		END
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 07/23/2008 14:54:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetQueueStatsByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 07/23/2008 14:54:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <17 June 2008>
-- Description:	<Get Queue Statistic by Collector for chart>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int
	
AS
BEGIN

	DECLARE @BeforeDays INT
	DECLARE @AfterDays INT

	IF (@ReportTime = 0)
		BEGIN
			DECLARE @QueueDate smalldatetime
			DECLARE @AccountCount int
			DECLARE @AccountBalance money

			DECLARE @Temp table
			(
				EmployeeID int,
				QueueDate smalldatetime,
				AccountCount int,
				AccountBalance money
			)

			DECLARE @Index int
			SET @Index = -7

			WHILE @Index < 7
			BEGIN
				SET @QueueDate = GETDATE() + @Index
				SET @AccountCount = 0
				SET @AccountBalance = 0

				SELECT
					@AccountCount = ISNULL(COUNT(AccountID),0),
					@AccountBalance = ISNULL(SUM(BillBalance),0)
				FROM Account
				WHERE 
					CONVERT(VARCHAR(10),QueueDate,121) = CONVERT(VARCHAR(10),@QueueDate,121)
					AND SystemStatusID in (1,5)
					AND EmployeeID = @EmployeeID
				GROUP BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
				ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))

				INSERT INTO @Temp VALUES(@EmployeeID, @QueueDate, @AccountCount, @AccountBalance)

				SET @Index = @Index + 1
			END

			SELECT * FROM @Temp
		END
	ELSE
		BEGIN
			SELECT CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) as QueueDate, ISNULL(COUNT(AccountID),0) AS AccountCount, ISNULL(SUM(BillBalance),0) AS AccountBalance 
			FROM Account 
			WHERE 
				SystemStatusID in (1,5)
				AND AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))

			GROUP BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
			ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))
		END
END

-- Scripts 2.2.13:

-- =======================================================================
-- Author:		Minh Dam
-- Create date: Jul 23, 2008
-- Description:	Get paging list of Legal Snapshots
-- =======================================================================
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Snapshots_GetPagingList]    Script Date: 07/23/2008 15:32:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Snapshots_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Snapshots_GetPagingList]

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Snapshots_GetPagingList]    Script Date: 07/23/2008 15:33:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Legal_Snapshots_GetPagingList]
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	SELECT ROW_NUMBER() OVER(ORDER BY b.[Code]) as RowNumber,
			a.[SnapshotID], a.[DateCreated], a.[DebtAmount],
			b.[Code] + ' - ' + b.[Description] as SnapshotType
	INTO #temp
	FROM Legal_Snapshots a
		LEFT JOIN Legal_SnapshotTypes b ON a.[SnapshotTypeID] = b.[SnapshotTypeID]
	--WHERE a.Status <> 'R'
	ORDER BY RowNumber
	
	Declare @RowCount int
	Set @RowCount = @@ROWCOUNT	

	SELECT 	[SnapshotID], [SnapshotType], [DateCreated], [DebtAmount]
	FROM #temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Employee_Search]    Script Date: 07/23/2008 16:14:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_Search]    Script Date: 07/23/2008 16:14:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Search]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'



-- =============================================
-- Author:		LongNguyen
-- Create date: Dec 15, 2007
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_Search]
	@EmployeeID int = 0,
	@EmployeeName varchar(50) = '''',
	@Department int = 0,
	@IsEmployeePool bit,
	@RoleID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--This only used in MainPage (Refer to), if employee is supervisor -> only select supervisor
	DECLARE @Supervisor bit
	IF @EmployeeID > 0
		SELECT	@Supervisor = Supervisor	
		FROM	Employee
		WHERE	EmployeeID = @EmployeeID

	--Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = ''WHERE RowNumber BETWEEN '' + CAST(@BeginIndex as varchar(10)) + '' AND '' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = '' ''

	--Step 3: Populate the main SELECT command.
	DECLARE @cStmt varchar(4000)
	SET @cStmt = ''SELECT e.EmployeeID, e.UserID, e.EmployeeName, ISNULL(d.DeptDesc, '''''''') AS Department, e.RoleID, e.Description, ''
			 + '' CASE e.Supervisor WHEN 1 THEN ''''Y'''' ELSE '''''''' END AS Supervisor ''
			 + '' FROM Employee e LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID AND (d.Status <> ''''R'''') ''
			 + '' WHERE (e.EmployeeName LIKE (''''%'' + @EmployeeName + ''%'''')) ''
			 + '' AND ('' + STR(@Department) + ''= 0 OR e.Department = '' + STR(@Department) + '') ''
			 + '' AND ('' + STR(@RoleID) + ''= 0 OR e.RoleID = '' + STR(@RoleID) + '') AND (ISNULL(EmployeeStatus, '''''''') <> ''''R'''') ''
			 + '' AND ('' + ISNULL(STR(@Supervisor), ''1'') + ''= 1 OR e.Supervisor = 1) ''
	
	IF (@IsEmployeePool = 1)
		SET @cStmt = @cStmt + '' AND EmployeeType=''''P'''' ''

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
	DECLARE @finalStmt varchar(8000)
	SET @finalStmt = ''WITH EmployeeList AS ''
				   + ''( ''
				   + ''  SELECT *, ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber ''
				   + ''  FROM ( ''	
				   + ''          {0}''
				   + ''    ) A ''
				   + '') ''
				   + ''SELECT * FROM EmployeeList '' + @pagingWhereClause
	SET @finalStmt = REPLACE(@finalStmt, ''{0}'', @cStmt)

	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)

	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = ''SELECT @RowCountOut=count(*) FROM ( {0} ) A''
    SET @rowCountStmt = REPLACE(@rowCountStmt, ''{0}'', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = ''@RowCountOut int OUTPUT''

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT
	
	RETURN @RowCount
END




' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalAgent]    Script Date: 07/23/2008 17:27:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Sathya
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalAgent] 
	-- Add the parameters for the stored procedure here
	@AgentId int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
		INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
			INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO

-- Scripts 2.2.14:
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
/****** Object:  Table [dbo].[CWX_TicketAddressChange]    Script Date: 07/24/2008 10:40:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketAddressChange]') AND type in (N'U'))
	DROP TABLE [dbo].[CWX_TicketAddressChange]
GO

CREATE TABLE [dbo].[CWX_TicketAddressChange](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[DebtorID] [int] NULL CONSTRAINT [DF__CWX_Ticke__Debto__2B9F624A]  DEFAULT ((0)),
	[AddressType] [tinyint] NULL CONSTRAINT [DF__CWX_Ticke__Addre__2E7BCEF5]  DEFAULT ((0)),
	[Address1] [varchar](255) NULL,
	[Address2] [varchar](255) NULL,
	[Address3] [varchar](255) NULL,
	[City] [varchar](255) NULL,
	[State] [varchar](50) NULL,
	[Zip] [varchar](25) NULL,
	[Remark] [varchar](255) NULL
) ON [PRIMARY]

/****** Object:  Table [dbo].[CWX_TicketPhoneChange]    Script Date: 07/24/2008 10:41:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketPhoneChange]') AND type in (N'U'))
	DROP TABLE [dbo].[CWX_TicketPhoneChange]
GO

CREATE TABLE [dbo].[CWX_TicketPhoneChange](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[DebtorID] [int] NULL CONSTRAINT [DF__CWX_Ticke__Debto__4EE89E87]  DEFAULT ((0)),
	[PhoneType] [tinyint] NULL CONSTRAINT [DF__CWX_Ticke__Phone__4FDCC2C0]  DEFAULT ((0)),
	[PhoneNumber] [varchar](50) NULL,
	[PhoneExtension] [varchar](50) NULL,
	[PhoneStatus] [smallint] NULL,
	[Description] [varchar](255) NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Hearings_GetPagingList]    Script Date: 07/24/2008 11:15:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Hearings_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Hearings_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Hearings_GetPagingList]    Script Date: 07/24/2008 11:15:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Hearings_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =======================================================================
-- Author:		Tuan Luong
-- Create date: Jul 22, 2008
-- Description:	Get paging list of Legal Hearings
-- =======================================================================
CREATE PROCEDURE [dbo].[CWX_Legal_Hearings_GetPagingList]	
	@GroupStepID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		ROW_NUMBER() OVER (ORDER BY h.DateHearing) AS RowNumber,
		h.CourtID as Court,
		h.HearingID,
		h.GroupStepID,
		t.Code + '' - '' +  t.Description as CodeAndName,
		h.DateHearing
	INTO #Temp
	FROM Legal_Hearings h LEFT JOIN Legal_HearingTypes t 
	ON h.HearingTypeID = t.HearingTypeID
	WHERE h.GroupStepID = @GroupStepID AND t.Status <> ''R''

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	ORDER BY DateHearing
	
	RETURN @RowCount
END


' 
END
GO

/******  Script Closed. Go next: Step016_5  ******/