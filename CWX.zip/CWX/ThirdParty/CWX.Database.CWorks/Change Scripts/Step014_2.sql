-- Script is applied on version 2.0.2
/****** Object:  StoredProcedure [dbo].[CWX_Product_LetterHeadImage_Save]    Script Date: 06/25/2008 13:11:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_LetterHeadImage_Save]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_LetterHeadImage_Save]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Product_LetterHeadImage_Save]    Script Date: 06/25/2008 13:11:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<khoa dang>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Product_LetterHeadImage_Save]
	@ClientID int, 
	@LetterHeadImage image = null
AS
BEGIN
	update ClientInformation set LetterheadImage=@LetterHeadImage
		where ClientID=@ClientID
END

GO

IF NOT EXISTS (SELECT name FROM sys.objects where name = 'Legal_CreditorTypes')
BEGIN
	CREATE TABLE [dbo].[Legal_CreditorTypes](
		[CreditorTypeID] [int] IDENTITY(1,1) NOT NULL,
		[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_CreditorTypes_LastEditDate]  DEFAULT (getdate()),
	 CONSTRAINT [PK_Legal_CreditorTypes] PRIMARY KEY CLUSTERED 
	(
		[CreditorTypeID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO

-- =======================================================================
-- Author:			Tuan Luong
-- Create date:		Jun 24, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_CreditorTypes
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_CreditorTypes' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_CreditorTypes
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_CreditorTypes_RowStatus] DEFAULT 'A'
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByAssignedEmployeesString]    Script Date: 06/25/2008 14:00:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByAssignedEmployeesString]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByAssignedEmployeesString]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByAssignedEmployeesString]    Script Date: 06/25/2008 14:01:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Binh Truong
-- Create date: March 24th, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByAssignedEmployeesString] 	
	@AssignedEmployees TEXT
AS
BEGIN
	SET NOCOUNT ON
		
	SELECT Employee.*
	FROM dbo.CWX_FnSplitString(@AssignedEmployees, '|'), Employee
	WHERE EmployeeID = SplitedText
	ORDER BY Employee.EmployeeName
	
	SET NOCOUNT OFF
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByRuleID]    Script Date: 06/25/2008 14:01:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByRuleID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByRuleID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByRuleID]    Script Date: 06/25/2008 14:02:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Binh Truong
-- Create date: March 24th, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountProcessingRule_GetAssignedEmployeesByRuleID] 	
	@RuleID INT
AS
BEGIN
	SET NOCOUNT ON
	
	DECLARE @AssignedEmployees VARCHAR(8000)
	
	SELECT  @AssignedEmployees=Employees
	FROM    RulesAllocUsers
	WHERE	RuleID = @RuleID
		
	SELECT EmployeeID, EmployeeName 
	FROM dbo.CWX_FnSplitString(@AssignedEmployees, '|'), Employee
	WHERE EmployeeID = SplitedText 
	ORDER BY EmployeeName
	
	SET NOCOUNT OFF
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 06/25/2008 15:33:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetListByRule]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 06/25/2008 15:33:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 24, 2008
-- Description:	Retrieve records that match the rulecriterias of a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetListByRule] 
	-- Add the parameters for the stored procedure here
	@RuleID int,
	@PageSize int = 0,
	@PageIndex int = 0,
	@ProcessedAccountIDs varchar(4000) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	Set @orderByClause = ' ORDER BY AccountId'


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat, Combining
		FROM RuleCriteria
		WHERE RuleID = @RuleID

	DECLARE @SQLFormat varchar(700)
	DECLARE @Combining varchar(10)
	DECLARE @NeedCombining varchar(10)
	DECLARE @WhereClause varchar(2000)
	DECLARE @IsOpenningBracket bit
	SET @NeedCombining = 'And'
	SET @WhereClause = ''
	SET @IsOpenningBracket = 0

	OPEN RuleCriteriaCrsr
	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF (LOWER(@Combining) = 'or')
			IF (@IsOpenningBracket = 0)
			BEGIN
				SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' (' + @SQLFormat
				SET @IsOpenningBracket = 1
			END
			ELSE
				SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' ' + @SQLFormat
		ELSE
		BEGIN
			SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' ' + @SQLFormat			
			IF (@IsOpenningBracket = 1)
			BEGIN
				SET @WhereClause = @WhereClause + ') '
				SET @IsOpenningBracket = 0
			END
		END

		SET @NeedCombining = @Combining /* remember previous value */
		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	END

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr

	--Remove the Account that was processed
	IF @ProcessedAccountIDs IS NOT NULL AND @ProcessedAccountIDs <> ''
	BEGIN
		SELECT CAST(SplitedText AS int) AS AccountID
		INTO #ProcessedAccountIDs
		FROM CWX_FnSplitString(@ProcessedAccountIDs, '|')

		SET @WhereClause = @WhereClause + ' AND Account.AccountId NOT IN (SELECT AccountID FROM #ProcessedAccountIDs)'
	END

	--This is used for AllocationRule, if RuleType=1, append condition <Account.MAINTAINOFFICER = 0>
	DECLARE @RuleType tinyint
	SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID
	IF @RuleType = 1
		SET @WhereClause = ' AND Account.MAINTAINOFFICER = 0' + @WhereClause

	DECLARE @Sql varchar(8000)
	SET @Sql = ' SELECT'
				+ ' Account.AccountId,Account.DebtorId,PersonInformation.FirstName,PersonInformation.MiddleName,PersonInformation.LastName,Account.BillBalance,Account.BillAmount,Account.InvoiceNumber'
				+ ' FROM Account'
				+ ' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID'
				+ ' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID'
				+ ' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID'
				+ ' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID'
				+ ' WHERE (PersonAddress.MailingAddress = 1)'
				+ ' AND Account.AgencyStatusID <> 2'-- Donot show closed account
				+ @WhereClause


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT * '
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @Sql)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @Sql)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_CreditorTypes_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Tuan Luong
-- Create date: Jun 23, 2008
-- Description:	Delete all records in Legal_CreditorTypes Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_CreditorTypes_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_CreditorTypes
		SET [Status] = ''R''
		WHERE [Status] = ''A''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_CreditorTypes		
	END
END
' 
END
GO

/****** Object:  Table [dbo].[CWX_AdditionalDataDetails]    Script Date: 06/26/2008 10:22:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AdditionalDataDetails]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_AdditionalDataDetails]
GO
/****** Object:  Table [dbo].[CWX_AdditionalDataDetails]    Script Date: 06/26/2008 10:22:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AdditionalDataDetails]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_AdditionalDataDetails](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[TableName] [varchar](50) NOT NULL,
	[ColumnNames] [varchar](400) NOT NULL,
	[XSL] [bit] NOT NULL,
	[XSLStylesheet] [varchar](100) NULL,
	[Grid] [bit] NOT NULL,
 CONSTRAINT [PK_CWX_AdditionalDataDetails] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [IX_Table_Name] UNIQUE NONCLUSTERED 
(
	[Name] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/******  Script Closed. Go next: Step014_3  ******/