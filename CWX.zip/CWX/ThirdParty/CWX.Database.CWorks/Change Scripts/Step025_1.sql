﻿-- Script is applied on version 3.1.0, 3.1.2:

-- Start of Scripts 3.1.0:

/***********TABLE INDEXES*****************/
if  exists (select name from sys.indexes where object_id = OBJECT_ID(N'[dbo].[Account]') and [name] = N'Account2')
	Drop Index Account.Account2
GO

if exists (select name from sys.indexes where object_id = OBJECT_ID(N'[dbo].[Account]') and [name] = N'IDX_ClientID')
	Drop Index Account.IDX_ClientID
GO

if exists (select [name] from sys.indexes where object_id = OBJECT_ID(N'[dbo].[Account]') and [name] = N'IDX_DebtorID')
	Drop Index Account.IDX_DebtorID
GO

if exists (select [name] from sys.indexes where object_id = OBJECT_ID(N'[dbo].[Account]') and [name] = N'IDX_EmployeeID')
	Drop Index Account.IDX_EmployeeID
GO

if exists (select [name] from sys.indexes where object_id = OBJECT_ID(N'[dbo].[Account]') and [name] = N'IX_EmployeeID')
	Drop Index Account.IX_EmployeeID
GO

IF  EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DebtorInformation]') AND [name] = N'DebtorInformation4')
    DROP INDEX [DebtorInformation4] ON [dbo].[DebtorInformation]
GO

IF  EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DebtorInformation]') AND [name] = N'IDX_DEBPERID')
    DROP INDEX [IDX_DEBPERID] ON [dbo].[DebtorInformation] WITH ( ONLINE = OFF )
GO

IF  EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PersonInformation]') AND [name] = N'PersonInformation3')
    DROP INDEX [PersonInformation3] ON [dbo].[PersonInformation] WITH ( ONLINE = OFF )
GO

IF  NOT EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Account]') AND [name] = N'cu_Account_AccountID')
    CREATE UNIQUE CLUSTERED INDEX [cu_Account_AccountID] ON [Account] 
    (
	  [AccountID] ASC
    )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

IF  NOT EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DebtorInformation]') AND [name] = N'cu_DebtorInformation_DebtorID')
   CREATE UNIQUE CLUSTERED INDEX [cu_DebtorInformation_DebtorID] ON [dbo].[DebtorInformation] 
   (
      [DebtorID] ASC
   )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO


IF  NOT EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PersonInformation]') AND [name] = N'cu_PersonInformation')
    CREATE UNIQUE CLUSTERED INDEX [cu_PersonInformation] ON [dbo].[PersonInformation] 
   (
 	  [PersonID] ASC
   )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO


IF  NOT EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Account]') AND [name] = N'nc_Account_ClientID')
   CREATE INDEX nc_Account_ClientID ON dbo.Account(ClientID)
GO

IF  NOT EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Account]') AND [name] = N'nc_Account_DebtorID')
   CREATE INDEX nc_Account_DebtorID ON dbo.Account(DebtorID)
GO

IF  NOT EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Account]') AND [name] = N'nc_Account_EmployeeID')
   CREATE INDEX nc_Account_EmployeeID ON dbo.Account(EmployeeID)
GO

IF  NOT EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Account]') AND [name] = N'nc_Account_EmpSum')
   CREATE INDEX nc_Account_EmpSum ON dbo.Account(EmployeeID, BillAmount, BillBalance)
GO

IF  NOT EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[debtorInformation]') AND [name] = N'nc_DebtorInformation_PersonID')
   CREATE INDEX nc_DebtorInformation_PersonID ON dbo.debtorInformation(PersonID)
GO

IF  NOT EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[debtorInformation]') AND [name] = N'nc_DebtorInformation_LockedByID')
   CREATE INDEX nc_DebtorInformation_LockedByID ON dbo.DebtorInformation(LockedByID)
GO

IF  NOT EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PersonInformation]') AND [name] = N'nc_PersonInfo_OtherPhoneNumber')
   CREATE INDEX nc_PersonInfo_OtherPhoneNumber ON dbo.PersonInformation(Other_Phone_Number)
GO

IF  NOT EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PersonInformation]') AND [name] = N'nc_PersonInfo_FullName')
   CREATE INDEX nc_PersonInfo_FullName ON dbo.PersonInformation(LastName, MiddleName, FirstName)
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByZip]    Script Date: 12/10/2008 15:44:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByZip]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchDebtorByZip]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByIDCard]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByIDCard]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchDebtorByIDCard]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalAgent]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalAgent]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchByLegalAgent]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByEmpID]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByEmpID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchDebtorByEmpID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalForward]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchByLegalForward]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByCourtDistrict]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByCourtDistrict]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchDebtorByCourtDistrict]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByCoOwnerHmPhn]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByCoOwnerHmPhn]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchDebtorByCoOwnerHmPhn]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByCity]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByCity]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchDebtorByCity]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByAddress]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByAddress]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchDebtorByAddress]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByCollateralAdd]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByCollateralAdd]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchDebtorByCollateralAdd]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByDOB]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByDOB]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchDebtorByDOB]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByPTPDate]    Script Date: 12/10/2008 15:44:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByPTPDate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchDebtorByPTPDate]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalEmployee]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchByLegalEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByEmployeeName]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByEmployeeName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchByEmployeeName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByName]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchDebtorByName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralByEmployee]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchCollateralByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchCollateralByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralItemType]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchCollateralItemType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchCollateralItemType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralStage]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchCollateralStage]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchCollateralStage]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralNextAction]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchCollateralNextAction]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchCollateralNextAction]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalNextAction]    Script Date: 12/10/2008 15:44:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalNextAction]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_Account_SearchByLegalNextAction]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalNextAction]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchByLegalNextAction] 
	@v_employeeId int,
	@NextAction int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
    INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND l.NextAction = @NextAction

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m.CodeDesc as [Next Action],
			l.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
		INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND l.NextAction = @NextAction
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
    INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND l.NextAction = @NextAction

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m.CodeDesc as [Next Action],
			l.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
		INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND l.NextAction = @NextAction
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByPTPDate]    Script Date: 12/10/2008 15:44:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchDebtorByPTPDate] 
	@PTPDate varchar(15),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	IF ISDATE(@PTPDate) = 0 
	BEGIN
		SET @PTPDate = '1900-01-01'
	END

	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,''))=0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.AccountPromise ap
	ON a.AccountID = ap.AccountID
	WHERE
		a.DebtorID <> 0
		AND ap.DatePromised = CONVERT(DATETIME, @PTPDate)

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(ap.DatePromised) AS [PTP Date]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.AccountPromise ap
		ON a.AccountID = ap.AccountID
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND ap.DatePromised = CONVERT(DATETIME, @PTPDate)
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[PTP Date]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.AccountPromise ap
	ON a.AccountID = ap.AccountID
	WHERE
		a.DebtorID <> 0
		AND ap.DatePromised = CONVERT(DATETIME, @PTPDate)
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(ap.DatePromised) AS [PTP Date]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.AccountPromise ap
		ON a.AccountID = ap.AccountID
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND ap.DatePromised = CONVERT(DATETIME, @PTPDate)
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[PTP Date]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByCollateralAdd]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchDebtorByCollateralAdd] 
	@CollateralAdd varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.Collateral c
	ON a.AccountID = c.AccountID
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(c.CString18)) LIKE ('%' + UPPER(@CollateralAdd) + '%')

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(c.CString18) AS [Collateral Address]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.Collateral c
		ON a.AccountID = c.AccountID
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(c.CString18)) LIKE ('%' + UPPER(@CollateralAdd) + '%')
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Collateral Address]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.Collateral c
	ON a.AccountID = c.AccountID
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(c.CString18)) LIKE ('%' + UPPER(@CollateralAdd) + '%')
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(c.CString18) AS [Collateral Address]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.Collateral c
		ON a.AccountID = c.AccountID
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(c.CString18)) LIKE ('%' + UPPER(@CollateralAdd) + '%')
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Collateral Address]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByDOB]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchDebtorByDOB] 
	@DOB varchar(15),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	IF ISDATE(@DOB) = 0 
	BEGIN
		SET @DOB = '1900-01-01'
	END

	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	WHERE
		a.DebtorID <> 0
		AND p.DateOfBirth = CONVERT(DATETIME, @DOB)

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(p.DateOfBirth) AS [Date of Birth]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND p.DateOfBirth = CONVERT(DATETIME, @DOB)
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[Date of Birth]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	WHERE
		a.DebtorID <> 0
		AND p.DateOfBirth = CONVERT(DATETIME, @DOB)
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(p.DateOfBirth) AS [Date of Birth]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND p.DateOfBirth = CONVERT(DATETIME, @DOB)
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[Date of Birth]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByCourtDistrict]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchDebtorByCourtDistrict] 
	@CourtDistrict varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.PersonAddress pa 
	ON p.PersonID = pa.PersonID
	AND pa.AddressType = 1
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(pa.City)) LIKE ('%' + UPPER(@CourtDistrict) + '%')

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(pa.City) AS [Court District]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.PersonAddress pa 
		ON p.PersonID = pa.PersonID
		AND pa.AddressType = 1
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(pa.City)) LIKE ('%' + UPPER(@CourtDistrict) + '%')
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[Court District]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.PersonAddress pa 
	ON p.PersonID = pa.PersonID
	AND pa.AddressType = 1
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(pa.City)) LIKE ('%' + UPPER(@CourtDistrict) + '%')
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(pa.City) AS [Court District]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.PersonAddress pa 
		ON p.PersonID = pa.PersonID
		AND pa.AddressType = 1
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(pa.City)) LIKE ('%' + UPPER(@CourtDistrict) + '%')
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[Court District]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByCoOwnerHmPhn]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchDebtorByCoOwnerHmPhn] 
	@CoOwnerHmPhn varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(p.Other_Phone_Number)) LIKE ('%' + UPPER(@CoOwnerHmPhn) + '%')

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(p.Other_Phone_Number) AS [Co Owner Home Phone]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.PersonAddress pa 
		ON p.PersonID = pa.PersonID
		AND pa.AddressType = 1
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(p.Other_Phone_Number)) LIKE ('%' + UPPER(@CoOwnerHmPhn) + '%')
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[Co Owner Home Phone]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(p.Other_Phone_Number)) LIKE ('%' + UPPER(@CoOwnerHmPhn) + '%')
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(p.Other_Phone_Number) AS [Co Owner Home Phone]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.PersonAddress pa 
		ON p.PersonID = pa.PersonID
		AND pa.AddressType = 1
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(p.Other_Phone_Number)) LIKE ('%' + UPPER(@CoOwnerHmPhn) + '%')
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[Co Owner Home Phone]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByCity]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchDebtorByCity] 
	@DebtorCity varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.PersonAddress pa 
	ON p.PersonID = pa.PersonID
	AND pa.AddressType = 1
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(pa.City)) LIKE ('%' + UPPER(@DebtorCity) + '%')

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(pa.City) AS [City]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.PersonAddress pa 
		ON p.PersonID = pa.PersonID
		AND pa.AddressType = 1
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(pa.City)) LIKE ('%' + UPPER(@DebtorCity) + '%')
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[City]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.PersonAddress pa 
	ON p.PersonID = pa.PersonID
	AND pa.AddressType = 1
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(pa.City)) LIKE ('%' + UPPER(@DebtorCity) + '%')
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(pa.City) AS [City]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.PersonAddress pa 
		ON p.PersonID = pa.PersonID
		AND pa.AddressType = 1
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(pa.City)) LIKE ('%' + UPPER(@DebtorCity) + '%')
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[City]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByAddress]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchDebtorByAddress] 
	@DebtorAddress varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.PersonAddress pa 
	ON p.PersonID = pa.PersonID
	AND pa.AddressType = 1
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(pa.Address1) + ' ' + RTRIM(pa.Address2) + ' ' + RTRIM(pa.Address3)) LIKE ('%' + UPPER(@DebtorAddress) + '%')

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			UPPER(RTRIM(pa.Address1) + ' ' + RTRIM(pa.Address2) + ' ' + RTRIM(pa.Address3)) AS [Address]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.PersonAddress pa 
		ON p.PersonID = pa.PersonID
		AND pa.AddressType = 1
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(pa.Address1) + ' ' + RTRIM(pa.Address2) + ' ' + RTRIM(pa.Address3)) LIKE ('%' + UPPER(@DebtorAddress) + '%')
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[Address]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.PersonAddress pa 
	ON p.PersonID = pa.PersonID
	AND pa.AddressType = 1
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(pa.Address1) + ' ' + RTRIM(pa.Address2) + ' ' + RTRIM(pa.Address3)) LIKE ('%' + UPPER(@DebtorAddress) + '%')
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			UPPER(RTRIM(pa.Address1) + ' ' + RTRIM(pa.Address2) + ' ' + RTRIM(pa.Address3)) AS [Address]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.PersonAddress pa 
		ON p.PersonID = pa.PersonID
		AND pa.AddressType = 1
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(pa.Address1) + ' ' + RTRIM(pa.Address2) + ' ' + RTRIM(pa.Address3)) LIKE ('%' + UPPER(@DebtorAddress) + '%')
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[Address]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByIDCard]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchDebtorByIDCard] 
	@DebtorIDCardNo varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN AccountOther ao
	ON a.AccountID = ao.AccountID
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(ao.Additional4)) LIKE ('%' + UPPER(@DebtorIDCardNo) + '%')

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(ao.Additional4) AS [ID Card Number]
		FROM Account a
		INNER JOIN AccountOther ao
		ON a.AccountID = ao.AccountID
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.PersonAddress pa 
		ON p.PersonID = pa.PersonID
		AND pa.AddressType = 1
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(ao.Additional4)) LIKE ('%' + UPPER(@DebtorIDCardNo) + '%')
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[ID Card Number]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN AccountOther ao
	ON a.AccountID = ao.AccountID
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(ao.Additional4)) LIKE ('%' + UPPER(@DebtorIDCardNo) + '%')
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(ao.Additional4) AS [ID Card Number]
		FROM Account a
		INNER JOIN AccountOther ao
		ON a.AccountID = ao.AccountID
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.PersonAddress pa 
		ON p.PersonID = pa.PersonID
		AND pa.AddressType = 1
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(ao.Additional4)) LIKE ('%' + UPPER(@DebtorIDCardNo) + '%')
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[ID Card Number]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalAgent]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	
-- History:
--	2008/04/21	[Sathya]		Init version.
--	2008/08/14	[Binh Truong]	la.Status = 'A'  >>>  la.Status <> 'R'
--	2008/09/25	[Sathya]		la.Status <> 'R'  >>>  la.Status = 'A'
--								Add criteria lg.GroupID = ld.GroupID
-- =============================================
CREATE PROCEDURE [CWX_Account_SearchByLegalAgent] 
	@AgentId int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
		INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
	WHERE
		a.DebtorID <> 0
		And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
			INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
		WHERE
			a.DebtorID <> 0
            And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
		INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
	WHERE
		a.DebtorID <> 0
		And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
			INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
		WHERE
			a.DebtorID <> 0
            And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByZip]    Script Date: 12/10/2008 15:44:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchDebtorByZip] 
	@DebtorZip varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.PersonAddress pa 
	ON p.PersonID = pa.PersonID
	AND pa.AddressType = 1
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(pa.Zip)) LIKE ('%' + UPPER(@DebtorZip) + '%')

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(pa.Zip) AS [Zip Code]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.PersonAddress pa 
		ON p.PersonID = pa.PersonID
		AND pa.AddressType = 1
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(pa.Zip)) LIKE ('%' + UPPER(@DebtorZip) + '%')
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[Zip Code]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.PersonAddress pa 
	ON p.PersonID = pa.PersonID
	AND pa.AddressType = 1
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(pa.Zip)) LIKE ('%' + UPPER(@DebtorZip) + '%')
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			p.SocialSecurityNumber AS [ID],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			RTRIM(pa.Zip) AS [Zip Code]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.PersonAddress pa 
		ON p.PersonID = pa.PersonID
		AND pa.AddressType = 1
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(pa.Zip)) LIKE ('%' + UPPER(@DebtorZip) + '%')
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[ID],
		[Name],
		[Zip Code]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByEmpID]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchDebtorByEmpID] 
	@EmpID varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.Employee e
	ON a.EmployeeID = e.EmployeeID
	WHERE
		a.DebtorID <> 0
		AND a.EmployeeID = @EmpID

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			rtrim(e.EmployeeName) AS [Collector Name],
			a.EmployeeID AS [Collector ID]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.Employee e
		ON a.EmployeeID = e.EmployeeID
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND a.EmployeeID = @EmpID
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Collector ID],
		[Collector Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN dbo.DebtorInformation d 
	ON d.DebtorID = a.DebtorID
	INNER JOIN dbo.PersonInformation p 
	ON p.PersonID = d.PersonID
	INNER JOIN dbo.Employee e
	ON a.EmployeeID = e.EmployeeID
	WHERE
		a.DebtorID <> 0
		AND a.EmployeeID = @EmpID
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			rtrim(e.EmployeeName) AS [Collector Name],
			a.EmployeeID AS [Collector ID]
		FROM Account a
		INNER JOIN DebtorInformation d 
		ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p 
		ON p.PersonID = d.PersonID
		INNER JOIN dbo.Employee e
		ON a.EmployeeID = e.EmployeeID
		INNER JOIN AccountStatus s 
		ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			a.DebtorID <> 0
			AND a.EmployeeID = @EmpID
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Collector ID],
		[Collector Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchByLegalForward] 
	@SolicitorID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
		INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
	WHERE
		a.DebtorID <> 0
        And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
			INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
		WHERE
			a.DebtorID <> 0
			And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
		INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
	WHERE
		a.DebtorID <> 0
        And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
			INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
		WHERE
			a.DebtorID <> 0
			And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByEmployeeName]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchByEmployeeName] 
	@EmployeeName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
	WHERE
		a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			g.EmployeeName AS [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID 
		WHERE
			a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
	WHERE
		a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			g.EmployeeName AS [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID 
		WHERE
			a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalEmployee]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchByLegalEmployee] 
	@v_employeeId int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralItemType]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchCollateralItemType] 
	@v_employeeId int,
	@ItemID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.CollateralType = @ItemID

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.CollateralType = @ItemID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.CollateralType = @ItemID

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.CollateralType = @ItemID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralByEmployee]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchCollateralByEmployee] 
	@v_employeeId int,
	@cEmployeeID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.EmployeeID = @cEmployeeID 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.EmployeeID = @cEmployeeID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.EmployeeID = @cEmployeeID 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.EmployeeID = @cEmployeeID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByName]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchDebtorByName] 
	@DebtorName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
	Begin
		SELECT
			@RowCount = COUNT(a.AccountID)
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')

		IF @PageSize > 0
		BEGIN
			SET @BeginIndex = @PageIndex * @PageSize + 1
			SET @EndIndex = (@PageIndex + 1) * @PageSize
		END
		ELSE
		BEGIN
			SET @BeginIndex = 1
			SET @EndIndex = @RowCount
		END

		WITH Temp
		AS
		(
			SELECT
				ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
				(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
				a.QueueDate AS [QueueDate],
				a.InvoiceNumber as [Account Number],
				a.AccountAge AS [DPD],
				a.MCode AS [Bucket],
				a.CCode AS [Cycle],
				a.BillAmount AS [Bill Amount],
				a.BillBalance AS [Bill Balance],
				s.ShortDesc as [Status],
				s.SortPriority AS [Priority],
				a.AssignmentType AS [Assignment Type],
				p.SocialSecurityNumber AS [ID],
				rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
			FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			WHERE
				a.DebtorID <> 0
				AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
		)

		SELECT
			[KeyField],
			[QueueDate],
			[Account Number],
			[DPD],
			[Bucket],
			[Cycle],
			[Bill Amount],
			[Bill Balance],
			[Status],
			[Priority],
			[Assignment Type],
			[ID],
			[Name]
		FROM Temp
		WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

		RETURN @RowCount
	End
Else
	Begin
		SELECT
			@RowCount = COUNT(a.AccountID)
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))

		IF @PageSize > 0
		BEGIN
			SET @BeginIndex = @PageIndex * @PageSize + 1
			SET @EndIndex = (@PageIndex + 1) * @PageSize
		END
		ELSE
		BEGIN
			SET @BeginIndex = 1
			SET @EndIndex = @RowCount
		END

		WITH Temp
		AS
		(
			SELECT
				ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
				(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
				a.QueueDate AS [QueueDate],
				a.InvoiceNumber as [Account Number],
				a.AccountAge AS [DPD],
				a.MCode AS [Bucket],
				a.CCode AS [Cycle],
				a.BillAmount AS [Bill Amount],
				a.BillBalance AS [Bill Balance],
				s.ShortDesc as [Status],
				s.SortPriority AS [Priority],
				a.AssignmentType AS [Assignment Type],
				p.SocialSecurityNumber AS [ID],
				rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
			FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			WHERE
				a.DebtorID <> 0
				AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
				AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		)

		SELECT
			[KeyField],
			[QueueDate],
			[Account Number],
			[DPD],
			[Bucket],
			[Cycle],
			[Bill Amount],
			[Bill Balance],
			[Status],
			[Priority],
			[Assignment Type],
			[ID],
			[Name]
		FROM Temp
		WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

		RETURN @RowCount
	End


END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralStage]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [CWX_Account_SearchCollateralStage] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@cStageID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.CollateralStage = @cStageID 


	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.CollateralStage = @cStageID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.CollateralStage = @cStageID 


	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.CollateralStage = @cStageID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralNextAction]    Script Date: 12/10/2008 15:44:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CWX_Account_SearchCollateralNextAction] 
	@v_employeeId int,
	@cNextAction int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.NextAction = @cNextAction 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.NextAction = @cNextAction
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.NextAction = @cNextAction 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.NextAction = @cNextAction
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
END
GO
-- END Admerex scripts 3.1.0 --------------------------------------

-- Scripts 3.1.2:
