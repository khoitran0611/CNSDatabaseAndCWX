﻿-- Script is applied on version 3.6.2:

-- Start of Scripts 3.6.2:

/******* BEGIN Update AdditionalAcctSubProd table ********/

CREATE TABLE #Temp_AdditionalAcctSubProd
(AccountID int, SubProductID int,Issue int,OriginalDebt money,GST money ,TotalDebt money,
Paid money,Due money,Notes varchar(100),CreatedBy int,CreatedOn datetime)

GO 

INSERT INTO #Temp_AdditionalAcctSubProd
SELECT AccountId, SubProductId, Issue, OriginalDebt, GST, TotalDebt,
Paid, Due, Notes, CreatedBy, CreatedOn 
FROM AdditionalAcctSubProd;

GO 

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AdditionalAcctSubProd]') AND type in (N'U'))
DROP TABLE [dbo].[AdditionalAcctSubProd]

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[AdditionalAcctSubProd](
	[RecordId] [int] IDENTITY(1,1) NOT NULL,
	[AccountID] [int] NOT NULL,
	[SubProductID] [int] NOT NULL,
	[Issue] [int] NOT NULL,
	[OriginalDebt] [money] NOT NULL CONSTRAINT [DF__Additiona__Origi__55A15465]  DEFAULT ((0)),
	[GST] [money] NOT NULL CONSTRAINT [DF__AdditionalA__GST__5695789E]  DEFAULT ((0)),
	[TotalDebt] [money] NOT NULL CONSTRAINT [DF__Additiona__Total__57899CD7]  DEFAULT ((0)),
	[Paid] [money] NOT NULL CONSTRAINT [DF__Additional__Paid__587DC110]  DEFAULT ((0)),
	[Due] [money] NOT NULL CONSTRAINT [DF__AdditionalA__Due__5971E549]  DEFAULT ((0)),
	[Notes] [varchar](100) NULL,
	[CreatedBy] [int] NULL,
	[CreatedOn] [datetime] NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

GO

INSERT INTO AdditionalAcctSubProd
SELECT * FROM #Temp_AdditionalAcctSubProd;

DROP TABLE #Temp_AdditionalAcctSubProd;

/****** END Update AdditionalAcctSubProd table  *******/ 

/****** Object:  StoredProcedure [dbo].[CWX_Customer_AddAccountSubProductDetails]    Script Date: 02/26/2009 18:38:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Customer_AddAccountSubProductDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Customer_AddAccountSubProductDetails]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Customer_UpdateAccountSubProductDetails]    Script Date: 02/26/2009 18:38:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Customer_UpdateAccountSubProductDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Customer_UpdateAccountSubProductDetails]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetSubProductTotalUnAllocatedAmount]    Script Date: 02/26/2009 18:38:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetSubProductTotalUnAllocatedAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetSubProductTotalUnAllocatedAmount]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Client_SubProduct_ListAll]    Script Date: 02/26/2009 18:38:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Client_SubProduct_ListAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Client_SubProduct_ListAll]
GO


/****** Object:  StoredProcedure [dbo].[CWX_Customer_AddAccountSubProductDetails]    Script Date: 03/04/2009 13:19:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Suzette M. Dimasaca
-- Create date: Jan 26, 2009
-- Description:	This will insert data to AdditionalAcctSubProd table
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Customer_AddAccountSubProductDetails]
	-- Add the parameters for the stored procedure here
	@AccountID	Int
	, @SubProductId Int
	, @Issue	Int
	, @GST		Money
	, @OriginalDebt Money
	, @Paid		Money
	, @Notes	VarChar(100)
	, @CreatedBy	Int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TotalDebt	Money
		,@Due			Money

	SET @TotalDebt = (@OriginalDebt - @GST)
	SET @Due = (@TotalDebt - @Paid)

	INSERT INTO AdditionalAcctSubProd
	VALUES (@AccountID
		, @SubProductID
		, @Issue
		, @OriginalDebt
		, @GST
		, @TotalDebt
		, @Paid
		, @Due
		, @Notes
		, @CreatedBy
		, getdate())
    
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Customer_UpdateAccountSubProductDetails]    Script Date: 03/04/2009 13:21:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Alvin Marable
-- Create date: Mar 03, 2009
-- Description:	This will update AdditionalAcctSubProd table record
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Customer_UpdateAccountSubProductDetails]
	-- Add the parameters for the stored procedure here
	@AccountID	Int
	, @SubProductId Int
	, @Issue	Int
	, @GST		Money
	, @OriginalDebt Money
	, @Paid		Money
	, @Notes	VarChar(100)
	, @RecordID Int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TotalDebt	Money
		,@Due			Money

	SET @TotalDebt = (@OriginalDebt - @GST)
	SET @Due = (@TotalDebt - @Paid)

	UPDATE AdditionalAcctSubProd
	SET AccountId = @AccountID,
		SubProductId = @SubProductID,
		Issue = @Issue,
		OriginalDebt = @OriginalDebt,
		GST = @GST,
		TotalDebt = @TotalDebt,
		Paid = @Paid,
		Due = @Due,
		Notes = @Notes
	WHERE RecordId = @RecordID
    
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetSubProductTotalUnAllocatedAmount]    Script Date: 03/04/2009 13:29:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Compute total un-allocated amount for account sub-product.
-- History:
--	2009/03/03	[Alvin Marable]	Initial version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetSubProductTotalUnAllocatedAmount] 
	@AccountID int,
	@RecorID int,
	@OriginalDebt MONEY,
	@GST MONEY,
	@Paid MONEY,
	@BillAmount MONEY
AS
BEGIN	
	SET NOCOUNT ON;
	
	-- Formula: 
	-- Total un-allocated amount = (BillAmount) – (Sum of original debt of given account)  
	--			- (Sum of GST of given account) – (original debt from screen input) – (GST from screen input)
	
	DECLARE @SumOfOriginalDebt MONEY;
	DECLARE @SumOfGST MONEY;
	DECLARE @SumOfPaid MONEY;

	DECLARE @TotalUnAllocatedAmount MONEY;
	SET @TotalUnAllocatedAmount = 0;
		
	SELECT @SumOfOriginalDebt = SUM(ISNULL(OriginalDebt,0)), 
		   @SumOfGST = SUM(ISNULL(GST,0)) ,
		   @SumOfPaid = SUM(ISNULL(Paid,0))	
	FROM AdditionalAcctSubProd
	WHERE AccountId = @AccountID AND
		RecordId = CASE WHEN ISNULL(@RecorID,0) <> 0 THEN -1 ELSE RecordId END ;

	SET @TotalUnAllocatedAmount = 
		ISNULL(@BillAmount,0) - 
		(ISNULL(@SumOfOriginalDebt,0) + ISNULL(@SumOfGST,0)) - 
		(@OriginalDebt + @GST );

	SELECT ISNULL (@TotalUnAllocatedAmount, 0 ) TotalAmount;	

END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDebtorID]    Script Date: 03/05/2009 11:46:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Get list of product and sub-product name.
-- History:
--	2009/03/04	[Alvin Marable]	Initial version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Client_SubProduct_ListAll] 
AS
BEGIN	
	
	SET NOCOUNT ON;
	
	SELECT ClientSubProductInfo.*, ClientName, ClientName + ' - ' +  ProductCode  + ' - ' + ProductName ProductClientCodeName
	FROM ClientSubProductInfo
	INNER JOIN ClientInformation ON ClientID = ParentClientID
	WHERE ISNULL(ClientName + ' - ' +  ProductCode  + ' - ' + ProductName ,'')>''
	ORDER BY ProductClientCodeName

END

GO



