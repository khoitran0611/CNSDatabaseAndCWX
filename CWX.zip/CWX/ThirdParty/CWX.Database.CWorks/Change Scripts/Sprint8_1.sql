﻿	
if not exists( select top 1 [description]  from dbo.InformationTable where [description]='Enforce Post Code Validation')
begin
    INSERT INTO [dbo].[InformationTable]([InfoID], [InfoType], [InfoSubType], [InfoKey], [Description], [Value], [ValueFormat], [Status])
	VALUES(1, 19, 0, N'', N'Enforce Post Code Validation', N'', N'False', N'A')
end
GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'NotesCurrent' AND COLUMN_NAME = N'NotePriority' )
BEGIN
	CREATE TABLE [dbo].[NotesCurrent_temp](
		[NoteID] [int] IDENTITY(1,1) NOT NULL,
		[EmployeeID] [int] NOT NULL,
		[DebtorID] [int] NOT NULL,
		[BillID] [int] NOT NULL,
		[NoteDateTime] [datetime] NULL,
		[NoteType] [varchar](1) NULL,
		[NoteText] [nvarchar](1000) NULL,
		[NotePriority] [smallint] NOT NULL DEFAULT (0)
	) ON [PRIMARY]
	
	Insert into [NotesCurrent_temp] (Employeeid, debtorid, billid, notetype, notetext) 
		Select Employeeid, debtorid, billid, notetype, notetext  from [NotesCurrent]
	
	Execute SP_Rename 'NotesCurrent', 'NotesCurrent_Old'
	
	Execute SP_Rename 'NotesCurrent_temp', 'NotesCurrent'
END

Go

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'NotesHistory' AND COLUMN_NAME = N'NotePriority' )
BEGIN
	CREATE TABLE [dbo].[NotesHistory_temp](
		[NoteID] [int] IDENTITY(1,1) NOT NULL,
		[EmployeeID] [int] NOT NULL,
		[DebtorID] [int] NOT NULL,
		[BillID] [int] NOT NULL,
		[NoteDateTime] [datetime] NULL,
		[NoteType] [varchar](1) NULL,
		[NoteText] [nvarchar](1000) NULL,
		[NotePriority] [smallint] NOT NULL DEFAULT (0)
	) ON [PRIMARY]
	
	Insert into [NotesHistory_temp] (Employeeid, debtorid, billid, notetype, notetext) 
		Select Employeeid, debtorid, billid, notetype, notetext  from [NotesHistory]
		
	Execute SP_Rename 'NotesHistory', 'NotesHistory_Old'
	
	Execute SP_Rename 'NotesHistory_temp', 'NotesHistory'
END

Go
-----------------------------------------------
-- Description: Save note.
-- History:
--	2008/10/03	[Binh Truong]	Update NoteText from varchar to nvarchar datatype.
--								Update NoteText length from 700 to 1000.
--  2009/29/06	[Phuong Le]		Add NotePriority
-----------------------------------------------
ALTER PROCEDURE [dbo].[CWX_Save_Note] 	
(	
	@EmployeeID int, 
	@DebtorID int, 
	@AccountID int, 
	@NoteDateTime datetime, 
	@NoteType varchar (1), 
	@NoteText nvarchar(1000),
	@NotePriority smallint
)
AS
BEGIN

INSERT INTO [dbo].[NotesCurrent] (EmployeeID, DebtorID, BillID, NoteDateTime, NoteType, NoteText, NotePriority)
VALUES (@EmployeeID, @DebtorID, @AccountID, @NoteDateTime, @NoteType, @NoteText, @NotePriority )

SELECT @@IDENTITY

END

GO

-- =============================================
-- Description:	Get notes from database
-- History:
--	2008/05/08	[Tai Ly]		Init version.
--	2008/10/03	[Binh Truong]	Update NoteText varchar to nvarchar datatype.
--  2008/10/28	[Minh Dam]		Select BillID and InvoiceNumber.
--  2009/30/06	[Phuong Le]		Add Priority
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Notes_GetWithType]
	@DebtorID	int,
	@AccountID	int,
	@NoteText	nvarchar(1000) = '',
	@NoteType	varchar(1) = ' ',	
	@Month		int = -1,
	@Day		int = -1,
	@FromDate	datetime = '1753-01-01',
	@ToDate		datetime = '9999-12-31',
	@SearchHistory bit = 0,
	@SearchByAccount bit = 0,
	@NotePriority	smallint = -1,
	@PageSize	int = 10,
	@PageIndex	int = 0
AS
BEGIN
	DECLARE @TempTableVar table(
		RowNumber		int,
		NoteDateTime	datetime,
		NoteText		nvarchar(1000),
		NoteType		varchar(1),
		UserID			varchar(10),
		AccountID		int,
		InvoiceNumber	varchar(50),
		NotePriority	smallint,
		NoteID			int
	);

	IF @Month >= 0
	BEGIN
		SET @FromDate = DATEADD(month, -1*@Month, GETDATE())
		SET @ToDate = GETDATE()
	END
	ELSE IF @Day >= 0
	BEGIN
		SET @FromDate = DATEADD(day, -1*@Day, GETDATE())
		SET @ToDate = GETDATE()
	END

	SELECT @NoteText = '%' + @NoteText + '%';

	IF @SearchHistory = 0
		INSERT INTO @TempTableVar
		SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.notepriority desc, n.NoteID) AS RowNumber, 
					n.NoteDateTime, n.NoteText, n.NoteType, e.UserID, n.BillID, a.InvoiceNumber, n.NotePriority, n.NoteID
		FROM		NotesCurrent n, Employee e, Account a
		WHERE		((@SearchByAccount = 0 AND n.DebtorID = @DebtorID) OR n.BillID = @AccountID)
					AND n.EmployeeID *= e.EmployeeID 
					AND n.BillID = a.AccountID
					AND (@NoteType = ' ' OR UPPER(NoteType) = UPPER(@NoteType))
					AND n.NoteText LIKE @NoteText
					AND (DATEDIFF(day, @FromDate, n.NoteDateTime)>=0 AND DATEDIFF(day, n.NoteDateTime, @ToDate)>=0)
					AND (@NotePriority=-1 OR (@NotePriority>-1 AND n.NotePriority=@NotePriority))
	ELSE
		INSERT INTO @TempTableVar
		SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.notepriority desc, n.NoteID) AS RowNumber, 
					n.NoteDateTime, n.NoteText, n.NoteType, e.UserID, n.BillID, a.InvoiceNumber, n.NotePriority, n.NoteID
		FROM		NotesHistory n, Employee e, Account a
		WHERE		((@SearchByAccount = 0 AND n.DebtorID = @DebtorID) OR n.BillID = @AccountID)
					AND n.EmployeeID *= e.EmployeeID 
					AND n.BillID = a.AccountID
					AND (@NoteType = ' ' OR UPPER(NoteType) = UPPER(@NoteType))
					AND n.NoteText LIKE @NoteText
					AND (DATEDIFF(day, @FromDate, n.NoteDateTime)>=0 AND DATEDIFF(day, n.NoteDateTime, @ToDate)>=0)
					AND (@NotePriority=-1 OR (@NotePriority>-1 AND n.NotePriority=@NotePriority))

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT	NoteDateTime, NoteText, NoteType, UserID, AccountID, InvoiceNumber, NotePriority, NoteID
		FROM	@TempTableVar
	ELSE
		SELECT	NoteDateTime, NoteText, NoteType, UserID, AccountID, InvoiceNumber, NotePriority, NoteID
		FROM	@TempTableVar
		WHERE	RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize)		

	RETURN @RowCount

END

GO

/****** Object:  Table [dbo].[CWX_PostalCodeVal_Dict]    Script Date: 07/02/2009 12:09:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PostalCodeVal_Dict]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_PostalCodeVal_Dict](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MasterTableName] [varchar](255) NOT NULL,
	[ExternalConnString] [varchar](255) NULL,
	[Address1FieldName] [varchar](255) NULL,
	[Address2FieldName] [varchar](255) NULL,
	[Address3FieldName] [varchar](255) NULL,
	[CityFieldName] [varchar](255) NULL,
	[StateFieldName] [varchar](50) NULL,
	[ZipFieldName] [varchar](25) NOT NULL,
 CONSTRAINT [PK_CWX_PostalCodeVal_Dict] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]


END
GO


-- CREATE PROCEDURE CWX_Account_LoadXMLByAccountID
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXMLByAccountID]    Script Date: 07/09/2009 09:20:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXMLByAccountID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_LoadXMLByAccountID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXMLByAccountID]    Script Date: 07/09/2009 09:22:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Load account xml by accountID
-- History:
--	2009/07/03	[Minh Dam]		Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_LoadXMLByAccountID]
	@AccountID	int
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/
   
	SELECT
			a.AccountID,
			ISNULL(l.LetterDesc, '') AS SENTBY, ISNULL(al.LetterStatus, '') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			p.AmountPromised AS FirstAmountPromised, p.PromiseFrequency AS FirstPromiseFrequency, p.Term AS FirstPromiseTerm, p.DatePromised, '' AS PROMISE,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL,
			lastpromise.LASTPROMISEDATE, lastpromise.LASTPROMISEAMOUNT, lastpromise.LASTPROMISESTATUS, lastpromise.LASTPROMISESTATUSDESC,
			(CASE ISNULL(lg.GroupedAccountID, 0) WHEN 0 THEN 0 ELSE 1 END) AS IsGroupedAccount
	INTO	#AccountTemp
	FROM	Account	 a
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN 'd' THEN 'day(s)'
						WHEN 'w' THEN 'week(s)'
						WHEN 'm' THEN 'month(s)'
						WHEN 'y' THEN 'year(s)'
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get last promise
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised AS LASTPROMISEAMOUNT,
					p2.DatePromised AS LASTPROMISEDATE,
					p2.Status AS LASTPROMISESTATUS,
					CASE p2.Status
						WHEN 0 THEN 'Not Due'
						WHEN 1 THEN 'Paid On Time'
						WHEN 2 THEN 'Paid Late'
						WHEN 3 THEN 'Broken Promise'
						WHEN 4 THEN 'Canceled'
						ELSE ''
					END AS LASTPROMISESTATUSDESC
				FROM AccountPromise p2 
				WHERE p2.PromiseID IN 
						(	SELECT TOP 1 PromiseID
							FROM (	SELECT PromiseID, DatePromised
									FROM AccountPromise 
									WHERE AccountID = p2.AccountID -- 69
							) as temp
							ORDER BY DatePromised DESC
						)) lastpromise ON lastpromise.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	--Check if account is GroupAccount
	LEFT JOIN Legal_Groups lg ON lg.GroupedAccountID = a.AccountID
	WHERE a.AccountID = @AccountID

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, nextAction.CodeDesc AS CurrentNextActionDesc, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, --ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised, #AccountTemp.FirstAmountPromised, #AccountTemp.FirstPromiseFrequency, #AccountTemp.FirstPromiseTerm
			, #AccountTemp.LASTPROMISEDATE, #AccountTemp.LASTPROMISEAMOUNT, #AccountTemp.LASTPROMISESTATUS, #AccountTemp.LASTPROMISESTATUSDESC
			, #AccountTemp.LASTCONTACTDATE, #AccountTemp.LASTCONTACTBY, #AccountTemp.PROMISETOPAY, #AccountTemp.PROMISEKEPT, #AccountTemp.PROMISEBROKEN, #AccountTemp.OUTGOINGCALL, #AccountTemp.NOACTIVITYDAYS
			, ISNULL(Account.IsPending, 0) AS IsPending
			, #AccountTemp.IsGroupedAccount
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID
			LEFT OUTER JOIN AccountCodeMaster nextAction on Account.CurrentNextAction = nextAction.CodeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_NotePriority]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_NotePriority](
		[Priority] [int] NOT NULL,
		[Description] [nvarchar](100) NULL
	 CONSTRAINT [PK_CWX_NotePriority] PRIMARY KEY CLUSTERED 
	(
		[Priority] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]	
END

GO

IF(NOT EXISTS(	SELECT 1 FROM CWX_NotePriority WHERE Priority = 0 ))
BEGIN
	INSERT INTO CWX_NotePriority (Priority, Description) VALUES (0, 'No priority')	
END

GO

IF(NOT EXISTS(	SELECT 1 FROM CWX_NotePriority WHERE Priority = 1 ))
BEGIN
	INSERT INTO CWX_NotePriority (Priority, Description) VALUES (1, 'Low')
END

GO

IF(NOT EXISTS(	SELECT 1 FROM CWX_NotePriority WHERE Priority = 2 ))
BEGIN
	INSERT INTO CWX_NotePriority (Priority, Description) VALUES (2, 'Medium')
END

GO

IF(NOT EXISTS(	SELECT 1 FROM CWX_NotePriority WHERE Priority = 3 ))
BEGIN
	INSERT INTO CWX_NotePriority (Priority, Description) VALUES (3, 'High')
END
	
GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_SMSMail_History' AND COLUMN_NAME = N'AccountID' )
BEGIN
ALTER TABLE [dbo].[CWX_SMSMail_History]
	ADD AccountID int not null DEFAULT 0
END

GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_SMSMail_History' AND COLUMN_NAME = N'TextTemplateID' )
BEGIN
ALTER TABLE [dbo].[CWX_SMSMail_History]
	ADD TextTemplateID int null
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_SMSMail_History' AND COLUMN_NAME = 'TemplateID')
BEGIN
	EXEC sp_rename 'CWX_SMSMail_History.TemplateID', 'LetterTemplateID'
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_SMSMail_History_GetPagingList]    Script Date: 07/13/2009 14:21:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMSMail_History_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_SMSMail_History_GetPagingList]


/****** Object:  StoredProcedure [dbo].[CWX_SMSMail_History_GetPagingList]    Script Date: 07/13/2009 14:21:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: June-16-2009
-- Description:	Get history info of SMS And Mail
-- =============================================
CREATE PROCEDURE [dbo].[CWX_SMSMail_History_GetPagingList]
	@AccountID int = 0,
	@ChannelID int,
	@PageSize int = 10,
	@PageIndex int =  0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT a.RowNumber, a.ID, a.EmailAddress, a.PhoneNumber, a.Channel, a.SendingDate, a.TemplateDescription, a.BodyMessage
	FROM (
    -- Insert statements for procedure here
		SELECT	ROW_NUMBER() OVER (ORDER BY smsh.ID) AS RowNumber,
				smsh.ID as ID, ISNULL(smsh.MessageText, '') as BodyMessage,  
				ISNULL(smsh.EmailAddress,'') as EmailAddress, ISNULL(smsh.SMS_Number,'') as PhoneNumber, 
				CASE WHEN smsh.ChannelID = 1 THEN 'Email' ELSE 'SMS' END as Channel,
				smsh.ProcessDate as SendingDate, ISNULL(dl.LetterDesc,'') as TemplateDescription
		FROM	CWX_SMSMail_History smsh
				LEFT JOIN DefineLetters dl ON smsh.LetterTemplateID = dl.LetterID
		WHERE	(smsh.ChannelID = @ChannelID OR @ChannelID = 0) AND
				AccountID = @AccountID
	) a
	WHERE (@PageSize <= 0) OR (RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize)
	
	DECLARE @rowCount int
	SELECT	@rowCount = count(*)
	FROM	CWX_SMSMail_History smsh
			LEFT JOIN DefineLetters dl ON smsh.LetterTemplateID = dl.LetterID
	WHERE	(smsh.ChannelID = @ChannelID OR @ChannelID = 0) AND
			AccountID = @AccountID
	RETURN @rowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 07/14/2009 10:31:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList]

/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 07/14/2009 10:31:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Get Transaction List by TransactionType with a custom column is "Transaction Code - Description"
-- History:
--	2008/08/29	[Thuy Nguyen]	Init version.
--	2008/09/29	[Binh Truong]	Select total transaction amount.
--	2008/10/29	[Binh Truong]	Add DateToPost field.
--	2008/10/30	[Binh Truong]	Exclude Transactions.Descriptor = 'A'
--  2009/04/26  [SD]			Removed the Transactions.Descriptor = 'A'
--  2009/04/28  [SD]            Add two more columns to list
--  2009/07/14  [ThanhNguyen]	Add UserID column to list
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList] 		
	@AccountID int = 0,
	@TransactionType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0	
AS
BEGIN
	SET NOCOUNT ON;	

	DECLARE @querystring varchar(1000);

		CREATE TABLE #Temp(
		RowNumber int,		
		TransactionID int not null,
		DateToPost smalldatetime,
		DateOfTransaction smalldatetime,
		TransactionAmount money,		
		TransactionComment nvarchar(150),
		TransactionCodeDescription nvarchar(150),
		TransactionType int,
		InterestBreakdown bit,
		ReversedFlag bit,
		ImportedTransactionID varchar(100),
		TXN_POSTED varchar(1),
		TXN_PaymentType varchar(20),
		TXN_PaymentType_Details varchar(30),
		UserID varchar(10)
	);


SET @querystring = 'INSERT INTO #Temp
		SELECT 
		ROW_NUMBER() OVER (ORDER BY  t.DateOfTransaction DESC,t.TransactionID DESC) AS RowNumber,
		t.TransactionID, t.DateToPost, t.DateOfTransaction, t.TransactionAmount, t.TransactionComment,
		tt.TransactionCode + '' - '' + tt.Description as TransactionCodeDescription,
		t.TransactionType, tt.InterestBreakdown, t.ReversedFlag, t.ImportedTransactionID, t.TXN_POSTED,
		case t.PaymentTypeID when 0 then ' + '''' + '-' + ''''  +
						' when 1 then' + '''' + 'Cash' + ''''  +
				    	' when 2 then' + '''' + 'Cashiers Cheque' + ''''  + 
				    	' when 3 then' + '''' + 'Cheque' + ''''  +
				    	' when 4 then' + '''' + 'Credit Card' + ''''  +
				    	' when 5 then' + '''' + 'Money Order' + ''''  + 
 					' end,' + 
		'case when t.TransactionType = 901 then t.PaidWhere else ' + '''' + '-' + '''' + 'end, e.UserID as UserID' +
	' FROM	Transactions t LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID 
			LEFT JOIN Employee e ON t.EmployeeID = e.EmployeeID
	WHERE	t.AccountID = ' + cast(@AccountID as varchar) + ' AND 
			ISNULL(t.ParentTransactionID, 0) = 0'

-- AND t.Descriptor <> ''A''

	IF @TransactionType<>0 SET @querystring = @querystring + ' AND t.TransactionType = ' + cast(@TransactionType as varchar);
	
	EXEC (@querystring)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	DROP TABLE #Temp
	
	SELECT	SUM(TransactionAmount) as TotalAmount
	FROM	Transactions
	WHERE	AccountID = @AccountID AND
			(@TransactionType=0 OR TransactionType = @TransactionType) AND
			ISNULL(ParentTransactionID, 0) = 0 
			--AND Descriptor <> 'A' -- exclude additional transaction		
	RETURN @RowCount
END
GO

if exists( select top 1 [description]  from dbo.InformationTable where [description]='Enforce Post Code Validation')
begin
   Update InformationTable
   SET  [description]= 'Post Code Validation'
	WHERE infoID = 1 AND InfoType = 9 AND InfoSubType = 0 AND [Description] = 'Enforce Post Code Validation' 
end
GO

/****** Object:  StoredProcedure [dbo].[CWX_AdditionalDataDetails_AddDynamicFields]    Script Date: 07/16/2009 15:29:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Morris Mendoza
-- Create date: 20/01/2008
-- Description:	
-- =============================================				
ALTER PROCEDURE [dbo].[CWX_AdditionalDataDetails_AddDynamicFields]
	@AdditionalDataID int,
	@AccountID int,
	@PrimaryID int,
	@columns varchar(4000),
	@values varchar(4000),
	@updatesql varchar(4000)
AS

BEGIN
	DECLARE @tablename varchar(4000)	
--delete existing values in AdditionalDetails table
	SELECT @tablename = tablename from CWX_AdditionalDataDetails Where ID = @AdditionalDataID

	--DELETE FROM AdditionalFields WHERE AccountID = @AccountID
	
	DECLARE @Sql varchar(4000)

	IF @PrimaryID = 0 
		BEGIN
			SET @Sql = 'INSERT INTO ' +  @tablename + ' (' + @columns + ') VALUES (' + @values + ')'
		END
	ELSE
		BEGIN
		Declare @ColumnName varchar(4000)
		select @ColumnName = c.name
		from sysindexes i
		join sysobjects o ON i.id = o.id
		join sysobjects pk ON i.name = pk.name
		AND pk.parent_obj = i.id
		AND pk.xtype = 'PK'
		join sysindexkeys ik on i.id = ik.id
		and i.indid = ik.indid
		join syscolumns c ON ik.id = c.id
		AND ik.colid = c.colid
		where o.name = @TableName
		order by ik.keyno
			SET @Sql = 'UPDATE ' + @tablename + ' ' + @updatesql + ' WHERE AccountID = ' + cast(@AccountID as varchar)
			+ ' and ' + @ColumnName + '=' + cast(@PrimaryID as varchar)
		END
	EXEC(@sql)

	SELECT @@RowCOUNT
END

GO

IF EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_CustomDefinedFields' AND COLUMN_NAME = N'Value' )
BEGIN
	ALTER TABLE CWX_CustomDefinedFields ALTER COLUMN [Value] nvarchar(750)
END
GO

IF EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_CustomDefinedFields' AND COLUMN_NAME = N'Description' )
BEGIN
	ALTER TABLE CWX_CustomDefinedFields ALTER COLUMN [Description] nvarchar(100)
END
GO


-- CREATE TABLE CWX_DebtorSearchField
/****** Object:  Table [dbo].[CWX_DebtorSearchField]    Script Date: 07/14/2009 17:21:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorSearchField]') AND type in (N'U'))
BEGIN	
	CREATE TABLE [dbo].[CWX_DebtorSearchField](
		[FieldName] [varchar](50) NOT NULL,
		[Description] [nvarchar](50) NOT NULL,
		[TableID] [tinyint] NOT NULL
	) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF


-- ALTER PROCEDURE CWX_Debtor_Search
/****** Object:  StoredProcedure [dbo].[CWX_Debtor_Search]    Script Date: 07/14/2009 16:49:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 05 Mar 2009
-- Description:	Search debtor by debtor's name and group name
-- History:
--	[2009-03-05]	Minh Dam	Init version.
--	[2009-07-14]	Minh Dam	Remove parameters @DebtorName and @GroupName
--								Add parameters @FieldName, @TableName and @SearchValue
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Debtor_Search]
	-- Add the parameters for the stored procedure here
	@FieldName varchar(50) = '',
	@TableName	varchar(50) = '',
	@SearchValue nvarchar(100) = '',
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Insert statements for procedure here
	DECLARE @Sql nvarchar(4000), @Params nvarchar(100)
	DECLARE @NewLine varchar(2)
	SET @NewLine = '
'
	
	SET @Sql = 
'SELECT ROW_NUMBER() OVER (ORDER BY a.GroupName) as RowNumber,
		a.DebtorID, 
		a.GroupName, 
		ISNULL(b.FirstName,'''') + '' '' + ISNULL(b.MiddleName,'''') + '' '' + ISNULL(b.LastName,'''') as DebtorName,
		b.SocialSecurityNumber,
		b.PersonID
INTO #temp
FROM DebtorInformation a
	INNER JOIN PersonInformation b ON a.PersonID = b.PersonID' + @NewLine

	IF (@TableName <> '' AND @FieldName <> '')
	BEGIN
		IF (@TableName = 'DebtorInformation')
		  BEGIN
			SET @Sql = @Sql + 'WHERE a.' + @FieldName + ' LIKE ''%' + @SearchValue + '%'''
		  END
		ELSE IF (@TableName = 'PersonInformation')
		  BEGIN
			IF (@FieldName LIKE '%Name')
			  BEGIN
				SET @Sql = @Sql + 'WHERE (REPLACE(RTRIM(b.FirstName) + '' '' + RTRIM(ISNULL(b.MiddleName,'''')) + '' '' + RTRIM(b.LastName), ''  '', '' '')) LIKE ''%' + @SearchValue + '%'''
			  END
			ELSE
				SET @Sql = @Sql + 'WHERE b.' + @FieldName + ' LIKE ''%' + @SearchValue + '%'''
		  END
		ELSE IF (@TableName = 'Account')
		  BEGIN
			SET @Sql = @Sql + 'WHERE a.DebtorID IN (SELECT DebtorID FROM ' + @TableName + ' WHERE ' + @FieldName + ' LIKE ''%' + @SearchValue + '%'')'
		  END
		ELSE IF (@TableName = 'AccountOther')
		  BEGIN 
			SET @Sql = @Sql + 'WHERE a.DebtorID IN (SELECT c.DebtorID FROM Account c INNER JOIN ' + @TableName + ' d ON c.AccountID = d.AccountID WHERE d.' + @FieldName + ' LIKE ''%' + @SearchValue + '%'')'
		  END
		ELSE
		  BEGIN
			SET @Sql = @Sql + 'WHERE b.PersonID IN (SELECT PersonID FROM ' + @TableName + ' WHERE ' + @FieldName + ' LIKE ''%' + @SearchValue + '%'')'
		  END

		SET @Sql = @Sql + @NewLine
	END

	SET @Sql = @Sql + 'SELECT @RowCount = COUNT(*) FROM #temp' + @NewLine
	SET @Sql = @Sql + 
'SELECT DebtorID, GroupName, DebtorName, SocialSecurityNumber, PersonID
FROM #temp
WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize'

	DECLARE @RowCount int
	SET @Params = '@PageSize int, @PageIndex int, @RowCount int OUTPUT'
	Exec sp_executesql @Sql, @Params, @PageSize, @PageIndex, @RowCount OUTPUT
	Print @Sql
	RETURN @RowCount
END
GO


-- ALTER PROCEDURE CWX_Account_SearchDebtorByName
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByName]    Script Date: 07/15/2009 15:44:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		
-- Create date: 
-- Description:	
-- History:
--	[2009-07-15]	Minh Dam	Add REPLACE(UPPER(DebtorName),'  ',' ') to  each statement in WHERE clause.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchDebtorByName] 
	@DebtorName varchar(100),
	@EmpList varchar(3000),
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF @PageSize > 0
BEGIN
	SET @BeginIndex = @PageIndex * @PageSize + 1
	SET @EndIndex = (@PageIndex + 1) * @PageSize
END
ELSE
BEGIN
	SET @BeginIndex = 1
	SET @EndIndex = @RowCount
END

IF LEN(ISNULL(@EmpList,'')) = 0 --search full
	Begin
		SELECT
			@RowCount = COUNT(a.AccountID)
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		WHERE
			a.DebtorID <> 0
			AND REPLACE(UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)),'  ',' ') LIKE ('%' + UPPER(@DebtorName) + '%')		

		WITH Temp
		AS
		(
			SELECT
				ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
				(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
				a.QueueDate AS [QueueDate],
				a.InvoiceNumber as [Account Number],
				a.AccountAge AS [DPD],
				a.MCode AS [Bucket],
				a.CCode AS [Cycle],
				a.BillAmount AS [Bill Amount],
				a.BillBalance AS [Bill Balance],
				s.ShortDesc as [Status],
				s.SortPriority AS [Priority],
				a.AssignmentType AS [Assignment Type],
				p.SocialSecurityNumber AS [ID],
				rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
			FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			WHERE
				a.DebtorID <> 0
				AND REPLACE(UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)),'  ',' ') LIKE ('%' + UPPER(@DebtorName) + '%')
		)

		SELECT
			[KeyField],
			[QueueDate],
			[Account Number],
			[DPD],
			[Bucket],
			[Cycle],
			[Bill Amount],
			[Bill Balance],
			[Status],
			[Priority],
			[Assignment Type],
			[ID],
			[Name]
		FROM Temp
		WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

		RETURN @RowCount
	End
Else
	Begin
		if @FilterByClient = 1 --search by client
			Begin
				DECLARE @employeeID varchar(50)
				DECLARE @index int

				SET @index = charindex(',', @EmpList)
				SET @employeeID = substring(@EmpList, 1, @index -1)
				SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

				SELECT
					@RowCount = COUNT(a.AccountID)
				FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				WHERE
					a.DebtorID <> 0
					AND REPLACE(UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)),'  ',' ') LIKE ('%' + UPPER(@DebtorName) + '%')
					AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

				WITH Temp
				AS
				(
					SELECT
						ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
						(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
						a.QueueDate AS [QueueDate],
						a.InvoiceNumber as [Account Number],
						a.AccountAge AS [DPD],
						a.MCode AS [Bucket],
						a.CCode AS [Cycle],
						a.BillAmount AS [Bill Amount],
						a.BillBalance AS [Bill Balance],
						s.ShortDesc as [Status],
						s.SortPriority AS [Priority],
						a.AssignmentType AS [Assignment Type],
						p.SocialSecurityNumber AS [ID],
						rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
					FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					WHERE
						a.DebtorID <> 0
						AND REPLACE(UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)),'  ',' ') LIKE ('%' + UPPER(@DebtorName) + '%')
						AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
				)

				SELECT
					[KeyField],
					[QueueDate],
					[Account Number],
					[DPD],
					[Bucket],
					[Cycle],
					[Bill Amount],
					[Bill Balance],
					[Status],
					[Priority],
					[Assignment Type],
					[ID],
					[Name]
				FROM Temp
				WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

				RETURN @RowCount
			End
		Else --search by emplist
			Begin
				SELECT
					@RowCount = COUNT(a.AccountID)
				FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				WHERE
					a.DebtorID <> 0
					AND REPLACE(UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)),'  ',' ') LIKE ('%' + UPPER(@DebtorName) + '%')
					AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))		

				WITH Temp
				AS
				(
					SELECT
						ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
						(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
						a.QueueDate AS [QueueDate],
						a.InvoiceNumber as [Account Number],
						a.AccountAge AS [DPD],
						a.MCode AS [Bucket],
						a.CCode AS [Cycle],
						a.BillAmount AS [Bill Amount],
						a.BillBalance AS [Bill Balance],
						s.ShortDesc as [Status],
						s.SortPriority AS [Priority],
						a.AssignmentType AS [Assignment Type],
						p.SocialSecurityNumber AS [ID],
						rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
					FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					WHERE
						a.DebtorID <> 0
						AND REPLACE(UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)),'  ',' ') LIKE ('%' + UPPER(@DebtorName) + '%')
						AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
				)

				SELECT
					[KeyField],
					[QueueDate],
					[Account Number],
					[DPD],
					[Bucket],
					[Cycle],
					[Bill Amount],
					[Bill Balance],
					[Status],
					[Priority],
					[Assignment Type],
					[ID],
					[Name]
				FROM Temp
				WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

				RETURN @RowCount
			End		
	End
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_GetListByAccountID]    Script Date: 07/20/2009 15:25:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_GetListByAccountID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CosigneeInformation_GetListByAccountID]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_GetListByAccountID]    Script Date: 07/20/2009 15:26:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 18, 2008
-- Description:	
-- [20/07/2009]:ThanhNguyen: Add column Social Security Number
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_GetListByAccountID] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(c.PersonID)
	FROM CosigneeInformation c
	JOIN PersonInformation p ON c.PersonID = p.PersonID
	JOIN PersonAddress a ON a.PersonID = p.PersonID
	WHERE
		a.AddressType = 2
		AND c.Bill = @AccountID

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + p.LastName)) AS RowNumber,
			c.PersonID,
			(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName,			
			(r.Code + ' - ' + r.Description) AS Relationship_no,p.SocialSecurityNumber,
            c.Relationship_no as Relationship_no1,   
			a.Address1,
			a.City,
			a.State,
			a.Zip,
			p.HomePhone,
			p.MobilPhone,
			p.EmploymentPhone
		FROM CosigneeInformation c
		JOIN PersonInformation p ON c.PersonID = p.PersonID
		JOIN PersonAddress a ON a.PersonID = p.PersonID
		LEFT JOIN Legal_RelationshipTypes r ON CAST(r.RelationshipTypeID AS varchar(20)) = c.Relationship_Type
		WHERE
			a.AddressType = 2
			AND c.Bill = @AccountID
	)

	SELECT *
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO
