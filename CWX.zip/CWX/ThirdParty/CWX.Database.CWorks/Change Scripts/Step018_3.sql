-- Script is applied on version 2.4.6, 2.4.7, 2.4.8, 2.4.9, 2.4.10, 2.4.11, 2.4.12, 2.4.14

-- Scripts 2.4.6: 

/****** Object:  StoredProcedure [dbo].[CWX_Employee_Deactive]    Script Date: 08/15/2008 17:40:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Deactive]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_Deactive]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_Deactive]    Script Date: 08/15/2008 17:40:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Deactive]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Deactive employee.
-- History:
--	2008/08/15	[Binh Truong]	Init version.
-- =============================================
create PROCEDURE [dbo].[CWX_Employee_Deactive]
	@EmployeeID int
	
AS
BEGIN
	UPDATE Employee
	SET
		EmployeeStatus = ''D''
	WHERE
		EmployeeID = @EmployeeID	
END







' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_SearchActiveEmployee]    Script Date: 08/15/2008 18:05:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_SearchActiveEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_SearchActiveEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_SearchActiveEmployee]    Script Date: 08/15/2008 18:05:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_SearchActiveEmployee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Search employee with active status only.
-- History:
--	2008/08/15	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_SearchActiveEmployee]
	@EmployeeID int = 0,
	@EmployeeName varchar(50) = '''',
	@Department int = 0,
	@IsEmployeePool bit,
	@RoleID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	--This only used in MainPage (Refer to), if employee is supervisor -> only select supervisor
	DECLARE @Supervisor bit
	IF @EmployeeID > 0
		SELECT	@Supervisor = Supervisor	
		FROM	Employee
		WHERE	EmployeeID = @EmployeeID AND EmployeeStatus = ''A''

	--Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = ''WHERE RowNumber BETWEEN '' + CAST(@BeginIndex as varchar(10)) + '' AND '' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = '' ''

	--Step 3: Populate the main SELECT command.
	DECLARE @cStmt varchar(4000)
	SET @cStmt = ''SELECT e.EmployeeID, e.UserID, e.EmployeeName, ISNULL(d.DeptDesc, '''''''') AS Department, e.RoleID, e.Description, ''
			 + '' CASE e.Supervisor WHEN 1 THEN ''''Y'''' ELSE '''''''' END AS Supervisor ''
			 + '' FROM Employee e LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID AND (d.Status <> ''''R'''') ''
			 + '' WHERE (e.EmployeeName LIKE (''''%'' + @EmployeeName + ''%'''')) ''
			 + '' AND ('' + STR(@Department) + ''= 0 OR e.Department = '' + STR(@Department) + '') ''
			 + '' AND ('' + STR(@RoleID) + ''= 0 OR e.RoleID = '' + STR(@RoleID) + '') AND (ISNULL(EmployeeStatus, '''''''') = ''''A'''') ''
			 + '' AND ('' + ISNULL(STR(@Supervisor), ''1'') + ''= 1 OR e.Supervisor = 1) ''
	
	IF (@IsEmployeePool = 1)
		SET @cStmt = @cStmt + '' AND EmployeeType=''''P'''' ''

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
	DECLARE @finalStmt varchar(8000)
	SET @finalStmt = ''WITH EmployeeList AS ''
				   + ''( ''
				   + ''  SELECT *, ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber ''
				   + ''  FROM ( ''	
				   + ''          {0}''
				   + ''    ) A ''
				   + '') ''
				   + ''SELECT * FROM EmployeeList '' + @pagingWhereClause
	SET @finalStmt = REPLACE(@finalStmt, ''{0}'', @cStmt)

	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)

	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = ''SELECT @RowCountOut=count(*) FROM ( {0} ) A''
    SET @rowCountStmt = REPLACE(@rowCountStmt, ''{0}'', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = ''@RowCountOut int OUTPUT''

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT
	
	RETURN @RowCount
END




' 
END
GO

UPDATE QueryParams
SET PickList='SELECT DISTINCT AccountAge, AccountAge FROM Account WHERE (EmployeeID=%E OR TempEmployeeID=%E) ORDER BY AccountAge'
WHERE QueryID=1 AND ParamID=2
UPDATE QueryParams
SET PickList='SELECT DISTINCT MCode, MCode FROM Account WHERE (EmployeeID=%E OR TempEmployeeID=%E) ORDER BY MCode'
WHERE QueryID=1 AND ParamID=3
UPDATE QueryParams
SET PickList='SELECT DISTINCT CCode, CCode FROM Account WHERE (EmployeeID=%E OR TempEmployeeID=%E) ORDER BY CCode'
WHERE QueryID=1 AND ParamID=4
GO

/****** Object:  StoredProcedure [dbo].[CWX_GetDynamicEditableFields]    Script Date: 08/18/2008 17:50:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetDynamicEditableFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetDynamicEditableFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetDynamicEditableFields]    Script Date: 08/18/2008 17:50:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Khoa Dang
CREATE PROCEDURE [dbo].[CWX_GetDynamicEditableFields]
	@TableID smallint,
	@RowID int
AS
BEGIN
	DECLARE @TableName varchar(20)
	DECLARE @PrimaryKey varchar(20)
	IF @TableID = 1
	BEGIN
		SET @TableName = 'PersonInformation'
		SET @PrimaryKey = 'PersonID'
	END
	ELSE 
		IF @TableID = 2
		BEGIN
			SET @TableName = 'AccountOther'
			SET @PrimaryKey = 'AccountID'
		END

	/* DataTable 1: get FieldName and Description of DynamicEditableFields table depends on Type field */
	SELECT f.FieldName, f.Description, t.Name as DataType, c.max_length as MaxLength, c.precision, c.is_nullable AS IsNullable INTO #DynamicFields 
		FROM ((sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id)
			INNER JOIN sys.types t ON t.system_type_id = c.system_type_id)
			INNER JOIN CWX_DynamicEditableFields f ON c.Name = f.FieldName
		WHERE o.Name=@TableName AND f.TableID=@TableID
	
	SELECT * FROM #DynamicFields

	/* DataTable 2: return the structure of table that needs to update */
	DECLARE @FieldName varchar(100)
	DECLARE @FieldNames varchar(1000)
	DECLARE DynamicFieldsCursor CURSOR FOR SELECT FieldName FROM #DynamicFields
	OPEN DynamicFieldsCursor
	FETCH NEXT FROM DynamicFieldsCursor INTO @FieldName

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF LEN(@FieldNames) > 0
			SET @FieldNames = @FieldNames + ',' + @FieldName
		ELSE
			SET @FieldNames = @FieldName

		FETCH NEXT FROM DynamicFieldsCursor INTO @FieldName
	END

	CLOSE DynamicFieldsCursor
	DEALLOCATE DynamicFieldsCursor

	DECLARE @sql varchar(2000)
	SET @sql = 'SELECT ' + @FieldNames + ' FROM ' + @TableName + ' WHERE ' + @PrimaryKey + '=' + Str(@RowID)
	EXEC (@sql)

	/* DataTable 3: primary key */
	SELECT @PrimaryKey as PrimaryKey
END
GO

-- Scripts 2.4.7:

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 10, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SVByEmployee] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@CollectorID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
	INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
	WHERE
		e.Supervisor = 1
		AND (a.EmployeeID = @CollectorID OR a.TempEmployeeID = @CollectorID)
		AND a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND a.AgencyStatusID <> 2

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.QueueDate desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
		INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
		WHERE
			e.Supervisor = 1
			AND (a.EmployeeID = @CollectorID OR a.TempEmployeeID = @CollectorID OR a.OfficeID = @CollectorID)
			AND a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND a.AgencyStatusID <> 2			
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON


-- =============================================
-- Author:		Minh Dam
-- Create date: Aug 19, 2008
-- Description:	Create table Collateral
-- =============================================
/****** Object:  Table [dbo].[Collateral]    Script Date: 08/19/2008 14:47:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Collateral]') AND type in (N'U'))
DROP TABLE [dbo].[Collateral]
GO

/****** Object:  Table [dbo].[Collateral]    Script Date: 08/19/2008 14:48:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Collateral](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[AccountID] [int] NULL DEFAULT ((0)),
	[HostCollateralID] [int] NULL DEFAULT ((0)),
	[CollateralType] [int] NULL CONSTRAINT [DF_Collateral_CollateralType]  DEFAULT ((0)),
	[CollateralStage] [int] NULL CONSTRAINT [DF_Collateral_CollateralStage]  DEFAULT ((0)),
	[EmployeeID] [int] NULL CONSTRAINT [DF_Collateral_EmployeeID]  DEFAULT ((0)),
	[NextAction] [int] NULL CONSTRAINT [DF_Collateral_NextAction]  DEFAULT ((0)),
	[NextActionDate] [smalldatetime] NULL,
	[CInt1] [int] NULL CONSTRAINT [DF_Collateral_CInt1]  DEFAULT ((0)),
	[CInt2] [int] NULL CONSTRAINT [DF_Collateral_CInt2]  DEFAULT ((0)),
	[CInt3] [int] NULL CONSTRAINT [DF_Collateral_CInt3]  DEFAULT ((0)),
	[CInt4] [int] NULL CONSTRAINT [DF_Collateral_CInt4]  DEFAULT ((0)),
	[CInt5] [int] NULL CONSTRAINT [DF_Collateral_CInt5]  DEFAULT ((0)),
	[CInt6] [int] NULL CONSTRAINT [DF_Collateral_CInt6]  DEFAULT ((0)),
	[CInt7] [int] NULL CONSTRAINT [DF_Collateral_CInt7]  DEFAULT ((0)),
	[CInt8] [int] NULL CONSTRAINT [DF_Collateral_CInt8]  DEFAULT ((0)),
	[CInt9] [int] NULL CONSTRAINT [DF_Collateral_CInt9]  DEFAULT ((0)),
	[CInt10] [int] NULL CONSTRAINT [DF_Collateral_CInt10]  DEFAULT ((0)),
	[CString1] [varchar](50) NULL,
	[CString2] [varchar](50) NULL,
	[CString3] [varchar](50) NULL,
	[CString4] [varchar](50) NULL,
	[CString5] [varchar](50) NULL,
	[CString6] [varchar](50) NULL,
	[CString7] [varchar](50) NULL,
	[CString8] [varchar](50) NULL,
	[CString9] [varchar](50) NULL,
	[CString10] [varchar](50) NULL,
	[CString11] [varchar](25) NULL,
	[CString12] [varchar](25) NULL,
	[CString13] [varchar](25) NULL,
	[CString14] [varchar](25) NULL,
	[CString15] [varchar](25) NULL,
	[CString16] [varchar](250) NULL,
	[CString17] [varchar](250) NULL,
	[CString18] [varchar](250) NULL,
	[CString19] [varchar](250) NULL,
	[CString20] [varchar](250) NULL,
	[CDate1] [smalldatetime] NULL,
	[CDate2] [smalldatetime] NULL,
	[CDate3] [smalldatetime] NULL,
	[CDate4] [smalldatetime] NULL,
	[CDate5] [smalldatetime] NULL,
	[CDate6] [smalldatetime] NULL,
	[CDate7] [smalldatetime] NULL,
	[CDate8] [smalldatetime] NULL,
	[CDate9] [smalldatetime] NULL,
	[CDate10] [smalldatetime] NULL,
	[CDate11] [smalldatetime] NULL,
	[CDate12] [smalldatetime] NULL,
	[CDate13] [smalldatetime] NULL,
	[CDate14] [smalldatetime] NULL,
	[CDate15] [smalldatetime] NULL,
	[CMoney1] [money] NULL CONSTRAINT [DF_Collateral_CMoney1]  DEFAULT ((0)),
	[CMoney2] [money] NULL CONSTRAINT [DF_Collateral_CMoney2]  DEFAULT ((0)),
	[CMoney3] [money] NULL CONSTRAINT [DF_Collateral_CMoney3]  DEFAULT ((0)),
	[CMoney4] [money] NULL CONSTRAINT [DF_Collateral_CMoney4]  DEFAULT ((0)),
	[CMoney5] [money] NULL CONSTRAINT [DF_Collateral_CMoney5]  DEFAULT ((0)),
	[CMoney6] [money] NULL CONSTRAINT [DF_Collateral_CMoney6]  DEFAULT ((0)),
	[CMoney7] [money] NULL CONSTRAINT [DF_Collateral_CMoney7]  DEFAULT ((0)),
	[CMoney8] [money] NULL CONSTRAINT [DF_Collateral_CMoney8]  DEFAULT ((0)),
	[CMoney9] [money] NULL CONSTRAINT [DF_Collateral_CMoney9]  DEFAULT ((0)),
	[CMoney10] [money] NULL CONSTRAINT [DF_Collateral_CMoney10]  DEFAULT ((0)),
	[CMoney11] [money] NULL CONSTRAINT [DF_Collateral_CMoney11]  DEFAULT ((0)),
	[CMoney12] [money] NULL CONSTRAINT [DF_Collateral_CMoney12]  DEFAULT ((0)),
	[CMoney13] [money] NULL CONSTRAINT [DF_Collateral_CMoney13]  DEFAULT ((0)),
	[CMoney14] [money] NULL CONSTRAINT [DF_Collateral_CMoney14]  DEFAULT ((0)),
	[CMoney15] [money] NULL CONSTRAINT [DF_Collateral_CMoney15]  DEFAULT ((0))
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: Aug 19, 2008
-- Description:	Create store procedure CWX_Collateral_GetList
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetList]    Script Date: 08/19/2008 14:50:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetList]    Script Date: 08/19/2008 14:50:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Collateral_GetList]
	@AccountID int,
	@EmployeeID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT [ID], [AccountID], [HostCollateralID], [EmployeeID], [NextActionDate],
			dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType]) AS CollateralType,
			dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage]) AS CollateralStage,
			dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction]) AS NextAction
	FROM Collateral
	WHERE AccountID = @AccountID AND EmployeeID = @EmployeeID
END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: Aug 19, 2008
-- Description:	Create store procedure CWX_Collateral_GetDynamicFields
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 08/19/2008 14:51:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 08/19/2008 14:51:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
			
CREATE PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
	@CollateralID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			b.[DataType],
			b.[MaxLength]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], [DisplayOrder]
		FROM CWX_Collateral_Dict
		WHERE Displayed = 1) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], c.[max_length] as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Collateral' and [Type]='U')
			AND (c.[name] LIKE 'CInt%' OR c.[name] LIKE 'CString%' OR c.[name] LIKE 'CDate%' OR c.[name] LIKE 'CMoney%')
		) b 
		ON a.[FieldName] = b.[ColumnName]
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'ID,AccountID,HostCollateralID,EmployeeID,CollateralType,CollateralStage,NextAction,NextActionDate'
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM Collateral WHERE ID = ' + Cast(@CollateralID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM CWX_Collateral_Dict
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup
END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: Aug 19, 2008
-- Description:	Create function CWX_AccountCodeMaster_GetCodeDescription
-- =============================================
/****** Object:  UserDefinedFunction [dbo].[CWX_AccountCodeMaster_GetCodeDescription]    Script Date: 08/19/2008 14:53:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountCodeMaster_GetCodeDescription]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CWX_AccountCodeMaster_GetCodeDescription]
GO

/****** Object:  UserDefinedFunction [dbo].[CWX_AccountCodeMaster_GetCodeDescription]    Script Date: 08/19/2008 14:53:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[CWX_AccountCodeMaster_GetCodeDescription]
(
	@CodeID int
)
RETURNS varchar(50)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar varchar(50)

	-- Add the T-SQL statements to compute the return value here
	SELECT @ResultVar = CodeDesc
	FROM AccountCodeMaster
	WHERE CodeID = @CodeID

	-- Return the result of the function
	RETURN ISNULL(@ResultVar,'')

END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_Active]    Script Date: 08/19/2008 15:15:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Active]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_Active]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_Active]    Script Date: 08/19/2008 15:15:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Active]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Active employee.
-- History:
--	2008/08/15	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_Active]
	@EmployeeID int
	
AS
BEGIN
	UPDATE Employee
	SET
		EmployeeStatus = ''A''
	WHERE
		EmployeeID = @EmployeeID	
END







' 
END
GO


-- Scripts 2.4.8:
UPDATE QueryParams SET PickList='ALL|0|Active|5|Pending|6|New|2|Legal|1' WHERE QueryID=1 AND ParamID=1
UPDATE QueryMaster SET SQL2='EXEC CWX_Account_SearchByQueueSStat %E, %1, %DPD, %Bucket, %Cycle' WHERE ID=1
UPDATE QueryMaster SET SQL2='EXEC CWX_Account_SearchByQueueAStat %E, %1' WHERE ID=2
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueAStat]    Script Date: 08/19/2008 16:08:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByQueueAStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueAStat]    Script Date: 08/19/2008 16:08:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_AgencyStatus int,
--	@IsPending bit = 0,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId AS varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID = '+CAST(@v_AgencyStatus AS varchar(9))
--				+ '   AND ISNULL(a.IsPending,0) = '+CAST(@IsPending AS varchar(1))


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 08/19/2008 16:09:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByQueueSStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 08/19/2008 16:09:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_SystemStatus int,
	@AccountAge int = -1,
	@MCode int = -1,
	@CCode int = -1,
--	@IsPending bit = 0,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId as varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID <> 2'
--				+ '   AND ISNULL(a.IsPending,0) = '+CAST(@IsPending AS varchar(1))

	IF @v_SystemStatus = 0 
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'

	IF ((@v_SystemStatus = 1) or (@v_SystemStatus = 5))
		SET @cStmt=@cStmt+' AND s.SystemStatus = '+CAST(@v_SystemStatus AS varchar(9))+''

	IF @v_SystemStatus = 2
	BEGIN
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'
		SET @cStmt=@cStmt+' AND convert(varchar(10),a.SubmissionDate,121)=convert(varchar(10),GetDate(),121)'+''
	END

	IF @v_SystemStatus = 6 --Pending account
		SET @cStmt=@cStmt+' AND a.IsPending = 1'
	
	IF @AccountAge <> -1
		SET @cStmt=@cStmt+' AND a.AccountAge = '+CAST(@AccountAge AS varchar(9))
	IF @MCode <> -1
		SET @cStmt=@cStmt+' AND a.MCode = '+CAST(@MCode AS varchar(9))
	IF @CCode <> -1
		SET @cStmt=@cStmt+' AND a.CCode = '+CAST(@CCode AS varchar(9))

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_ActiveAll]    Script Date: 08/19/2008 16:52:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_ActiveAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_ActiveAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_ActiveAll]    Script Date: 08/19/2008 16:52:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_ActiveAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Active all employee.
-- History:
--	2008/08/15	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_ActiveAll]
AS
BEGIN
	UPDATE Employee
	SET
		EmployeeStatus = ''A''
	WHERE
		EmployeeStatus = ''D''	
END







' 
END
GO

IF NOT EXISTS (SELECT ID FROM QueryMaster WHERE ID=28)
	INSERT INTO QueryMaster VALUES(28, 1, 'Pool Pending', '', 0, 'EXEC CWX_Account_SearchByPoolPending %E, %1')
GO

IF NOT EXISTS (SELECT QueryID FROM QueryParams WHERE QueryID=28)
	INSERT INTO QueryParams VALUES(28, 1, 'Available Pools', '', 'select a.EmployeeID,a.Description from Employee a,EmployeePool b where a.EmployeeID = b.PoolId and b.EmployeeID = %E')
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByPoolPending]    Script Date: 08/19/2008 18:13:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByPoolPending]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByPoolPending]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByPoolPending]    Script Date: 08/19/2008 18:13:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByPoolPending] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@PoolID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '   AND s.SystemStatus in (1,5)'
--				+ '   AND convert(varchar(10),a.SubmissionDate,121)=convert(varchar(10),GetDate(),121)'
				+ '   AND a.OfficeID = '+CAST(@v_employeeId as varchar(9))
				+ '   AND a.EmployeeID = '+CAST(@PoolID as varchar(9))
				+ '   AND a.IsPending = 1'

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO

-- Scripts 2.4.9:

/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 08/20/2008 10:44:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXML]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_LoadXML]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 08/20/2008 10:44:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Description:	Load all accounts with debtorID
-- History:
--	08/04/03	[Tai Ly]	Init version.
--	08/06/01	[Long Nguyen]	Add and remove some fields.
--	08/06/27	[Binh Truong]	Remove BatchNumber field.	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int	
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/
	SELECT
			a.AccountID,
			c.COOWNERS,
			ISNULL(l.LetterDesc, '') AS SENTBY, ISNULL(al.LetterStatus, '') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			p.AmountPromised AS FirstAmountPromised, p.PromiseFrequency AS FirstPromiseFrequency, p.Term AS FirstPromiseTerm, p.DatePromised, '' AS PROMISE,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL,
			lastpromise.LASTPROMISEDATE, lastpromise.LASTPROMISEAMOUNT, lastpromise.LASTPROMISESTATUS, lastpromise.LASTPROMISESTATUSDESC
	INTO	#AccountTemp
	FROM	Account	 a
	--Count CoSigner for account
	LEFT JOIN (SELECT AccountID, COUNT(CoSignerID) AS COOWNERS FROM CoSigner GROUP BY AccountID) c ON c.AccountID = a.AccountID
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN 'd' THEN 'day(s)'
						WHEN 'w' THEN 'week(s)'
						WHEN 'm' THEN 'month(s)'
						WHEN 'y' THEN 'year(s)'
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get last promise
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised AS LASTPROMISEAMOUNT,
					p2.DatePromised AS LASTPROMISEDATE,
					p2.Status AS LASTPROMISESTATUS,
					CASE p2.Status
						WHEN 0 THEN 'Not Due'
						WHEN 1 THEN 'Paid On Time'
						WHEN 2 THEN 'Paid Late'
						WHEN 3 THEN 'Broken Promise'
						WHEN 4 THEN 'Canceled'
						ELSE ''
					END AS LASTPROMISESTATUSDESC
				FROM AccountPromise p2 
				WHERE p2.PromiseID IN 
						(	SELECT TOP 1 PromiseID
							FROM (	SELECT PromiseID, DatePromised
									FROM AccountPromise 
									WHERE AccountID = p2.AccountID -- 69
							) as temp
							ORDER BY DatePromised DESC
						)) lastpromise ON lastpromise.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	WHERE DebtorID = @DebtorID

	--If @AdditionalTag = 1 get additional data
	DECLARE @AdditionalTag int
	SELECT @AdditionalTag = FieldValue FROM IdentityFields WHERE TableName = 'AdditionalTag'

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, nextAction.CodeDesc AS CurrentNextActionDesc, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			, #AccountTemp.COOWNERS--, DebtorID as COOWNERS
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE--, InvoiceNumber as SENTBY, ' ' as LETTERSTATUS, QueueDate as LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised, #AccountTemp.FirstAmountPromised, #AccountTemp.FirstPromiseFrequency, #AccountTemp.FirstPromiseTerm--, String1 as PROMISE
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.LASTCONTACTDATE ELSE '' END AS LASTCONTACTDATE--' ' as LASTCONTACTDATE
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.LASTCONTACTBY ELSE '' END AS LASTCONTACTBY--, ' ' as LASTCONTACTBY
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISETOPAY ELSE '' END AS PROMISETOPAY--, ' ' as PROMISETOPAY
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISEKEPT ELSE '' END AS PROMISEKEPT--, ' ' as PROMISEKEPT
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISEBROKEN ELSE '' END AS PROMISEBROKEN--, ' ' as PROMISEBROKEN
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.OUTGOINGCALL ELSE '' END AS OUTGOINGCALL--, ' ' as OUTGOINGCALL
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.NOACTIVITYDAYS ELSE '' END AS NOACTIVITYDAYS--, ' ' as NOACTIVITYDAYS
			, #AccountTemp.LASTPROMISEDATE, #AccountTemp.LASTPROMISEAMOUNT, #AccountTemp.LASTPROMISESTATUS, #AccountTemp.LASTPROMISESTATUSDESC
			, ISNULL(Account.IsPending, 0) AS IsPending
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID
			LEFT OUTER JOIN AccountCodeMaster nextAction on Account.CurrentNextAction = nextAction.CodeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Employee_SearchDeactiveEmployee]    Script Date: 08/20/2008 15:23:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_SearchDeactiveEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_SearchDeactiveEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_SearchDeactiveEmployee]    Script Date: 08/20/2008 15:23:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_SearchDeactiveEmployee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Search employee with deactive status only.
-- History:
--	2008/08/18	[Binh Truong]	Init version.
-- =============================================
create PROCEDURE [dbo].[CWX_Employee_SearchDeactiveEmployee]
	@EmployeeID int = 0,
	@EmployeeName varchar(50) = '''',
	@Department int = 0,
	@IsEmployeePool bit,
	@RoleID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	--This only used in MainPage (Refer to), if employee is supervisor -> only select supervisor
	DECLARE @Supervisor bit
	IF @EmployeeID > 0
		SELECT	@Supervisor = Supervisor	
		FROM	Employee
		WHERE	EmployeeID = @EmployeeID AND EmployeeStatus = ''D''

	--Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = ''WHERE RowNumber BETWEEN '' + CAST(@BeginIndex as varchar(10)) + '' AND '' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = '' ''

	--Step 3: Populate the main SELECT command.
	DECLARE @cStmt varchar(4000)
	SET @cStmt = ''SELECT e.EmployeeID, e.UserID, e.EmployeeName, ISNULL(d.DeptDesc, '''''''') AS Department, e.RoleID, e.Description, ''
			 + '' CASE e.Supervisor WHEN 1 THEN ''''Y'''' ELSE '''''''' END AS Supervisor ''
			 + '' FROM Employee e LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID AND (d.Status <> ''''R'''') ''
			 + '' WHERE (e.EmployeeName LIKE (''''%'' + @EmployeeName + ''%'''')) ''
			 + '' AND ('' + STR(@Department) + ''= 0 OR e.Department = '' + STR(@Department) + '') ''
			 + '' AND ('' + STR(@RoleID) + ''= 0 OR e.RoleID = '' + STR(@RoleID) + '') AND (ISNULL(EmployeeStatus, '''''''') = ''''D'''') ''
			 + '' AND ('' + ISNULL(STR(@Supervisor), ''1'') + ''= 1 OR e.Supervisor = 1) ''
	
	IF (@IsEmployeePool = 1)
		SET @cStmt = @cStmt + '' AND EmployeeType=''''P'''' ''

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
	DECLARE @finalStmt varchar(8000)
	SET @finalStmt = ''WITH EmployeeList AS ''
				   + ''( ''
				   + ''  SELECT *, ROW_NUMBER() OVER (ORDER BY EmployeeID) AS RowNumber ''
				   + ''  FROM ( ''	
				   + ''          {0}''
				   + ''    ) A ''
				   + '') ''
				   + ''SELECT * FROM EmployeeList '' + @pagingWhereClause
	SET @finalStmt = REPLACE(@finalStmt, ''{0}'', @cStmt)

	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)

	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = ''SELECT @RowCountOut=count(*) FROM ( {0} ) A''
    SET @rowCountStmt = REPLACE(@rowCountStmt, ''{0}'', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = ''@RowCountOut int OUTPUT''

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT
	
	RETURN @RowCount
END




' 
END
GO



-- Scripts 2.4.10:

/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateTransactionAmount]    Script Date: 08/20/2008 17:06:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UpdateTransactionAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_UpdateTransactionAmount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateTransactionAmount]    Script Date: 08/20/2008 17:07:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UpdateTransactionAmount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <20 Aug 2008>
-- Description:	<Update Bill Balance, Bill Amount for 1.Add Other Charge 2.Receive Payment>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_UpdateTransactionAmount] 	
	@AccountID int,
	@TransactionType int, -- 1: Add Other Charge; 2: Receive Payment
	@TransactionAmount money	
AS
BEGIN
    
	IF @TransactionType = 1		
		UPDATE Account 
		SET BillAmount = BillAmount + @TransactionAmount, BillBalance = BillBalance + @TransactionAmount
		WHERE AccountID = @AccountID		
	ELSE
		UPDATE Account 
		SET BillAmount = BillAmount - @TransactionAmount , BillBalance = BillBalance - @TransactionAmount
		WHERE AccountID = @AccountID		
END
' 
END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: Aug 20, 2008
-- Description:	Alter store procedure CWX_Collateral_GetList
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetList]    Script Date: 08/20/2008 17:31:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetList]    Script Date: 08/20/2008 17:31:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Collateral_GetList]
	@AccountID int,
	@EmployeeID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT [ID], [AccountID], [HostCollateralID], [EmployeeID], [NextActionDate],
			ISNULL(dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6),'') AS CollateralType,
			ISNULL(dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7),'') AS CollateralStage,
			ISNULL(dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2),'') AS NextAction
	FROM Collateral
	WHERE AccountID = @AccountID AND EmployeeID = @EmployeeID
	ORDER BY [CollateralType], [CollateralStage], [NextAction], [NextActionDate]
END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: Aug 20, 2008
-- Description:	Alter store procedure CWX_Collateral_GetDynamicFields
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 08/20/2008 17:32:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 08/20/2008 17:32:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
		
CREATE PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
	@CollateralID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			b.[DataType],
			b.[MaxLength]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], [DisplayOrder]
		FROM CWX_Collateral_Dict
		WHERE Displayed = 1) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], c.[max_length] as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Collateral' and [Type]='U')
			AND (c.[name] LIKE 'CInt%' OR c.[name] LIKE 'CString%' OR c.[name] LIKE 'CDate%' OR c.[name] LIKE 'CMoney%')
		) b 
		ON a.[FieldName] = b.[ColumnName]
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'ID,AccountID,HostCollateralID,EmployeeID,NextActionDate,'
	SET @FieldNameList = @FieldNameList + 
'(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6) IS NOT NULL THEN CollateralType ELSE 0 END) AS CollateralType,
(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7) IS NOT NULL THEN CollateralStage ELSE 0 END) AS CollateralStage,
(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2) IS NOT NULL THEN NextAction ELSE 0 END) AS NextAction'
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM Collateral WHERE ID = ' + Cast(@CollateralID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup
END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: Aug 20, 2008
-- Description:	Alter function CWX_AccountCodeMaster_GetCodeDescription
-- =============================================
/****** Object:  UserDefinedFunction [dbo].[CWX_AccountCodeMaster_GetCodeDescription]    Script Date: 08/20/2008 17:33:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountCodeMaster_GetCodeDescription]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CWX_AccountCodeMaster_GetCodeDescription]
GO

/****** Object:  UserDefinedFunction [dbo].[CWX_AccountCodeMaster_GetCodeDescription]    Script Date: 08/20/2008 17:34:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 13-08-2008
-- Description:	Get the CodeDesc field 
-- =============================================
CREATE FUNCTION [dbo].[CWX_AccountCodeMaster_GetCodeDescription]
(
	@CodeID int,
	@CodeType int
)
RETURNS varchar(50)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar varchar(50)

	-- Add the T-SQL statements to compute the return value here
	SELECT @ResultVar = CodeDesc
	FROM AccountCodeMaster
	WHERE [CodeID] = @CodeID 
	  AND [CodeType] = @CodeType
	  AND [Status] <> 'R'

	-- Return the result of the function
	RETURN @ResultVar

END
GO


-- Scripts 2.4.11: 

/****** Object:  StoredProcedure [dbo].[CWX_CalculateTransactionsSummary]    Script Date: 08/21/2008 13:44:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CalculateTransactionsSummary]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CalculateTransactionsSummary]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByPoolPending]    Script Date: 08/21/2008 14:18:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByPoolPending]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByPoolPending]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByPoolPending]    Script Date: 08/21/2008 14:19:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByPoolPending] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@PoolID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '   AND s.SystemStatus in (1,5)'
--				+ '   AND convert(varchar(10),a.SubmissionDate,121)=convert(varchar(10),GetDate(),121)'
				+ '   AND a.OfficeID = '+CAST(@v_employeeId as varchar(9))
				+ '   AND a.EmployeeID = '+CAST(@PoolID as varchar(9))
				+ '   AND a.IsPending = 1'
				+ '	  AND a.PoolSelected = 1'

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 10, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SVByEmployee] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@CollectorID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
	INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
	WHERE
		e.Supervisor = 1
		AND (a.EmployeeID = @CollectorID OR a.TempEmployeeID = @CollectorID OR a.OfficeID = @CollectorID)
		AND a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND a.AgencyStatusID <> 2

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.QueueDate desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
		INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
		WHERE
			e.Supervisor = 1
			AND (a.EmployeeID = @CollectorID OR a.TempEmployeeID = @CollectorID OR a.OfficeID = @CollectorID)
			AND a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND a.AgencyStatusID <> 2			
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SVByEmployee]    Script Date: 08/21/2008 16:32:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SVByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SVByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SVByEmployee]    Script Date: 08/21/2008 16:35:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Scripts 2.4.7:

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 10, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SVByEmployee] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@CollectorID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
	--INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
	WHERE
		--e.Supervisor = 1
		(a.EmployeeID = @CollectorID OR a.TempEmployeeID = @CollectorID OR a.OfficeID = @CollectorID)
		AND a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND a.AgencyStatusID <> 2

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.QueueDate desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
		--INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
		WHERE
			--e.Supervisor = 1
			(a.EmployeeID = @CollectorID OR a.TempEmployeeID = @CollectorID OR a.OfficeID = @CollectorID)
			AND a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

--Add new language Arabic ---- Thuy Nguyen

if not exists (select * from WebLanguages where ID = 4)
	insert into WebLanguages values(4, 3, 'Arabic', 0, 'ar-SA', 'images/lang_arabian.gif', 'images/lang_arabiano.gif')
go

-- Scripts 2.4.12

/****** Object:  StoredProcedure [dbo].[CWX_Account_SVByEmployee]    Script Date: 08/22/2008 09:57:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SVByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SVByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SVByEmployee]    Script Date: 08/22/2008 09:57:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 10, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SVByEmployee] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@CollectorID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	--INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
	--INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
	WHERE
		--e.Supervisor = 1
		(a.EmployeeID = @CollectorID OR a.TempEmployeeID = @CollectorID OR a.OfficeID = @CollectorID)
		AND a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND a.AgencyStatusID <> 2

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.QueueDate desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		--INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
		--INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
		WHERE
			--e.Supervisor = 1
			(a.EmployeeID = @CollectorID OR a.TempEmployeeID = @CollectorID OR a.OfficeID = @CollectorID)
			AND a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

-- Scripts 2.4.14:

/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateTransactionAmount]    Script Date: 08/22/2008 16:53:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UpdateTransactionAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_UpdateTransactionAmount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateTransactionAmount]    Script Date: 08/22/2008 16:53:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UpdateTransactionAmount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <20 Aug 2008>
-- Description:	<Update Bill Balance, Bill Amount for 1.Add Other Charge 2.Receive Payment>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_UpdateTransactionAmount] 	
	@AccountID int,
	@TransactionType int, -- 1: Add Other Charge; 2: Receive Payment
	@TransactionAmount money	
AS
BEGIN	
    
	IF @TransactionType = 1		
		UPDATE Account 
		SET BillAmount = BillAmount + @TransactionAmount, 
			BillBalance = BillBalance + @TransactionAmount,
			BillOtherCharges = @TransactionAmount
		WHERE AccountID = @AccountID		
	ELSE
		UPDATE Account 
		SET BillAmount = BillAmount - @TransactionAmount , BillBalance = BillBalance - @TransactionAmount
		WHERE AccountID = @AccountID		
END
' 
END
GO

/******  Script Closed.  ******/