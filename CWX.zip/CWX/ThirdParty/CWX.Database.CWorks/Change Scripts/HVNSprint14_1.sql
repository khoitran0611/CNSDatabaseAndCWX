﻿IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_CDL_SourceMapDetails' AND COLUMN_NAME = 'DefaultValue')
BEGIN
	ALTER TABLE [dbo].[CWX_CDL_SourceMapDetails] 
		ADD  DefaultValue nvarchar(50) null
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_CDL_SourceMapDetails' AND COLUMN_NAME = 'HostFieldName')
BEGIN
	ALTER TABLE [dbo].[CWX_CDL_SourceMapDetails] 
		ADD HostFieldName varchar(50) null
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_CDL_SourceMapDetails' AND COLUMN_NAME = 'HostFieldDescription')
BEGIN
	ALTER TABLE [dbo].[CWX_CDL_SourceMapDetails] 
		ADD HostFieldDescription nvarchar(200) null
END
GO


-- [30-Sep-2009] [Minh Dam] Remove column 'Name' from table CWX_CDL_SourceMapTemplate
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_CDL_SourceMapTemplate' AND COLUMN_NAME = 'Name')
BEGIN
	ALTER TABLE [dbo].[CWX_CDL_SourceMapTemplate] 
		DROP COLUMN [Name]
END
GO


-- [30-Sep-2009] [Minh Dam] Add column 'KeyColumn' into CWX_CDL_ImportDestTable_Dict
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_CDL_ImportDestTable_Dict' AND COLUMN_NAME = 'KeyColumn')
BEGIN
	ALTER TABLE [dbo].[CWX_CDL_ImportDestTable_Dict] 
		ADD KeyColumn varchar(50) null
END
GO


-- [30-Sep-2009] [Minh Dam] Create table CWX_CDL_LoadToCWorks_Dict
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_LoadToCWorks_Dict]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_CDL_LoadToCWorks_Dict](
		[RowID] [int] IDENTITY(1,1) NOT NULL,
		[ID] [int] NOT NULL,
		[Load1Field] [varchar](50) NOT NULL,
		[CWorksField] [varchar](50) NULL,
	 CONSTRAINT [PK_CWX_CDL_LoadToCWorks_Dict] PRIMARY KEY CLUSTERED 
	(
		[RowID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO


-- [30-Sep-2009] [Minh Dam] Create table [CWX_CDL_SSISFunctions]
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SSISFunctions]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_CDL_SSISFunctions](
		[ID] [int] NOT NULL,
		[Type] [tinyint] NOT NULL,
		[Name] [varchar](20) NOT NULL,
		[Syntax] [varchar](100) NOT NULL,
		[Format] [varchar](100) NULL,
		[Displayed] [bit] NOT NULL,
	 CONSTRAINT [PK_CWX_CDL_SSISFunctions] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO


-- [30-Sep-2009] [Minh Dam] Create table [CWX_CDL_SSISOperators]
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SSISOperators]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_CDL_SSISOperators](
		[ID] [int] NOT NULL,
		[Name] [varchar](40) NOT NULL,
		[Operator] [varchar](50) NOT NULL,
		[Displayed] [bit] NOT NULL CONSTRAINT [DF_CWX_CDL_SSISOperators_Displayed]  DEFAULT ((1)),
	 CONSTRAINT [PK_CWX_CDL_SSISOperators] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_CDL_LoadToCWorks_Dict_CWorksField]    Script Date: 10/01/2009 10:56:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_LoadToCWorks_Dict_CWorksField]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CDL_LoadToCWorks_Dict_CWorksField]

GO
/****** Object:  StoredProcedure [dbo].[CWX_CDL_LoadToCWorks_Dict_CWorksField]    Script Date: 09/29/2009 11:37:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: 29 Sep, 2009
-- Description:	Get CWorks Field base on RowID and Load1Field on table LoadToCWorks_Dict
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CDL_LoadToCWorks_Dict_CWorksField]
	@ID int,
	@Load1Field varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	SELECT CWorksField
	FROM CWX_CDL_LoadToCWorks_Dict
	WHERE ID = @ID And  Load1Field= @Load1Field	
END
GO


-- [30-Sep-2009] [Minh Dam] Add column 'EnforceTotalColumnsInTemplate' to CWX_CDL_ImportSource table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_CDL_ImportSource' AND COLUMN_NAME = 'EnforceTotalColumnsInTemplate')
BEGIN
	ALTER TABLE [dbo].[CWX_CDL_ImportSource] 
		ADD  EnforceTotalColumnsInTemplate bit NULL
END
GO



-- [30-Sep-2009] [Minh Dam] Create SP CWX_CDL_SourceMapTemplate_GetList
/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapTemplate_GetList]    Script Date: 09/17/2009 09:35:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SourceMapTemplate_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CDL_SourceMapTemplate_GetList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapTemplate_GetList]    Script Date: 09/30/2009 18:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		MinH Dam
-- Create date: 26 Aug, 2009
-- Description:	Get list of ImportTemplate
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CDL_SourceMapTemplate_GetList]
	-- Add the parameters for the stored procedure here
	@ClientID int = 0,
	@SourceID int = 0,
	@OnlyActive bit = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT  a.TemplateID, a.SourceID, a.Description, a.DestDatabase, a.DestTable, a.Active,
			ISNULL(b.Name,'') as SourceName,
			ISNULL(c.ClientName, '') as ClientName
	FROM CWX_CDL_SourceMapTemplate a
		INNER JOIN CWX_CDL_ImportSource b ON b.SourceID = a.SourceID AND b.Status <> 'R'	
		LEFT JOIN ClientInformation c ON c.ClientID = b.ClientID AND c.Status <> 'R'
	WHERE (@ClientID = 0 OR ISNULL(b.ClientID,0) = @ClientID)
		AND (@SourceID = 0 OR a.SourceID = @SourceID)
		AND (@OnlyActive = 0 OR a.Active = 1)
		AND a.Status <> 'R'
	ORDER BY a.Active DESC, a.TemplateID, b.ClientName
END
GO


-- [30-Sep-2009] [Minh Dam] Create SP [CWX_CDL_SourceMapDetails_GetKeyColumn]
/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapDetails_GetKeyColumn]    Script Date: 09/30/2009 18:40:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SourceMapDetails_GetKeyColumn]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CDL_SourceMapDetails_GetKeyColumn]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapDetails_GetKeyColumn]    Script Date: 09/30/2009 18:41:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 30 Sep, 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CDL_SourceMapDetails_GetKeyColumn]
	@TemplateID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @keyColumn varchar(50)
	SELECT @keyColumn = KeyColumn
	FROM CWX_CDL_ImportDestTable_Dict a
	WHERE EXISTS ( SELECT 1 FROM CWX_CDL_SourceMapTemplate b
					WHERE b.TemplateID = @TemplateID
						AND b.Status <> 'R'
						AND b.DestDatabase = a.DatabaseID 
						AND b.DestTable = a.TableName)

	IF (@keyColumn IS NOT NULL AND @keyColumn <> '')
	BEGIN
		SELECT *
		FROM CWX_CDL_SourceMapDetails
		WHERE TemplateID = @TemplateID
			AND DestField = @keyColumn
	END
END
GO


-- [30-Sep-2009] [Minh Dam] Create SP [CWX_CDL_SourceMapTemplate_Copy]
/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapTemplate_Copy]    Script Date: 09/17/2009 09:34:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SourceMapTemplate_Copy]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CDL_SourceMapTemplate_Copy]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapTemplate_Copy]    Script Date: 09/30/2009 18:45:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Minh Dam
-- Create date: 14 Sep, 2009
-- Description:	Copy Source Map Template
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CDL_SourceMapTemplate_Copy]
	@CopyTemplateID int = 0,
	@CreatedBy int,
	@CreatedDate datetime	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here    
	DECLARE @result int
    BEGIN TRAN
    BEGIN TRY
		DECLARE @newTemplateID int
		SET @newTemplateID = 0
		-- Insert data to CWX_CDL_SourceMapTemplate table    
		INSERT INTO CWX_CDL_SourceMapTemplate
		(
			SourceID, 
			[Description],
			DestDatabase,
			DestTable,
			Active,
			[Unicode],
			LocaleID,
			CodeBaseID,
			CreatedBy,
			CreatedDate,
			[Status]
		)
			SELECT	SourceID, 
					'Copy of' + [Description],
					DestDatabase,
					DestTable,
					0,
					[Unicode],
					LocaleID,
					CodeBaseID,
					@CreatedBy,
					@CreatedDate,
					Status
			FROM CWX_CDL_SourceMapTemplate
			WHERE TemplateID = @CopyTemplateID
				AND Status <> 'R'
		
		--Insert data to CWX_CDL_SourceMapDetails and CWX_CDL_SourceMapDetails_Validation tables
		SET @newTemplateID = @@IDENTITY	

		DECLARE @sourceCol varchar(50), @destField varchar(50), @columnWidth int, @startPosition int, @endPosition int
		DECLARE @fieldType tinyint, @length int, @validation varchar(200), @isDerived bit, @derivedFrom varchar(200)
		DECLARE	@allowsNull bit, @isSystemDefined bit, @mapDetailID int
		DECLARE @newMapDetailID int
		
		DECLARE curSourceMapDetails CURSOR FOR
			SELECT	ID,
					SourceCol,
					DestField,
					ColumnWidth,
					StartPosition,
					EndPosition,
					FieldType,
					[Length],
					[Validation],
					IsDerived,
					DerivedFrom,
					AllowsNull,
					IsSystemDefined									
			FROM CWX_CDL_SourceMapDetails
			WHERE TemplateID = @CopyTemplateID
				AND Status <> 'R'
			
		OPEN curSourcemapDetails
		FETCH NEXT FROM curSourcemapDetails 
			INTO @mapDetailID, @sourceCol, @destField, @columnWidth, @startPosition, @endPosition, @fieldType, 
				 @length, @validation, @isDerived, @derivedFrom, @allowsNull, @isSystemDefined
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--Insert data to CWX_CDL_SourceMapDetails table
			INSERT INTO CWX_CDL_SourceMapDetails
			(
				TemplateID,
				SourceCol,
				DestField,
				ColumnWidth,
				StartPosition,
				EndPosition,
				FieldType,
				[Length],
				[Validation],
				IsDerived,
				DerivedFrom,
				AllowsNull,
				IsSystemDefined,
				CreatedBy,
				CreatedDate			
			)
			VALUES
			(
				@newTemplateID,
				@sourceCol,
				@destField,
				@columnWidth,
				@startPosition,
				@endPosition,
				@fieldType,
				@length,
				@validation,
				@isDerived,
				@derivedFrom,
				@allowsNull,
				@isSystemDefined,
				@CreatedBy,
				@CreatedDate			
			)
			
			-- Insert data to CWX_SourceMapDetails_Validation table
			SET @newMapDetailID = @@IDENTITY

			INSERT INTO CWX_CDL_SourceMapDetails_Validation
			(
				MapDetailID,
				Operator,
				MatchingValue,
				Combining
			)
				SELECT	@newMapDetailID,
						Operator,
						MatchingValue,
						Combining
				FROM CWX_CDL_SourceMapDetails_Validation
				WHERE MapDetailID = @mapDetailID
			
			-- Go to next record
			FETCH NEXT FROM curSourcemapDetails 
				INTO @mapDetailID, @sourceCol, @destField, @columnWidth, @startPosition, @endPosition, @fieldType, 
					 @length, @validation, @isDerived, @derivedFrom, @allowsNull, @isSystemDefined
		END
						
		COMMIT TRAN
		SET @result = @newTemplateID
	END TRY	

	-- Catch exception
	BEGIN CATCH
		ROLLBACK TRAN

		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT 
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();

		--RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState)\
		SET @result = 0
	END CATCH
	
	IF CURSOR_STATUS('global', 'curSourcemapDetails') > 0
	BEGIN
		CLOSE curSourcemapDetails
		DEALLOCATE curSourcemapDetails
	END	

	RETURN @result
END
GO


-- [30-Sep-2009] [Minh Dam] Create script to init data for CWX_CDL_SSISOperators and CWX_CDL_SSISFunctions tables
-- `dbo.CWX_CDL_SSISOperators`
DELETE CWX_CDL_SSISOperators
INSERT dbo.CWX_CDL_SSISOperators VALUES (1, '+ (Add)', '+', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (2, '+ (Concatenate)', '+', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (3, '- (Subtract)', '-', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (4, '- (Negate)', '-', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (5, '* (Multiply)', '*', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (6, '/ (Divide)', '/', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (7, '% (Modulo)', '%', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (8, '() (Parentheses)', '()', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (9, '== (Equal)', '==', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (10, '!= (UnEqual)', '!=', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (11, '> (Greater Than)', '>', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (12, '< (Less Than)', '<', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (13, '>= (Greater Than or Equal To)', '>=', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (14, '<= (Less Than or Equal To)', '<=', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (15, '&& (Logical AND)', '&&', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (16, '|| (Logical OR)', '||', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (17, '? : (Conditional)', '«boolean_expression» ? «when_true» : «when_false»', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (18, '& (Bitwise AND)', '&', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (19, '| (Bitwise OR)', '|', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (20, '^ (Bitwise Exclusive OR)', '^', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (21, '~ (Bitwise NOT)', '~', 1)
INSERT dbo.CWX_CDL_SSISOperators VALUES (22, '! (Logical NOT)', '!', 1)
GO

-- `dbo.CWX_CDL_SSISFunctions`
DELETE CWX_CDL_SSISFunctions
INSERT dbo.CWX_CDL_SSISFunctions VALUES (1, 1, 'ABS', 'ABS( «numeric_expression» )', 'ABS({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (2, 1, 'CEILING', 'CEILING( «numeric_expression» )', 'CEILING({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (3, 1, 'EXP', 'EXP( «numeric_expression» )', 'EXP({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (4, 1, 'FLOOR', 'FLOOR( «numeric_expression» )', 'FLOOR({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (5, 1, 'LN', 'LN( «numeric_expression» )', 'LN({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (6, 1, 'LOG', 'LOG( «numeric_expression» )', 'LOG({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (7, 1, 'POWER', 'POWER( «numeric_expression», «power» )', 'POWER({0}, «power»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (8, 1, 'ROUND', 'ROUND( «numeric_expression», «length» )', 'ROUND({0}, «length»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (9, 1, 'SIGN', 'SIGN( «numeric_expression» )', 'SIGN({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (10, 1, 'SQUARE', 'SQUARE( «numeric_expression» )', 'SQUARE({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (11, 1, 'SQRT', 'SQRT( «numeric_expression» )', 'SQRT({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (12, 2, 'CODEPOINT', 'CODEPOINT( «character_expression» )', 'CODEPOINT({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (13, 2, 'FINDSTRING', 'FINDSTRING( «character_expression», «string», «occurrence» )', 'FINDSTRING({0}, «string», «occurrence»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (14, 2, 'HEX', 'HEX( «integer_expression» )', 'HEX({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (15, 2, 'LEN', 'LEN( «character_expression» )', 'LEN({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (16, 2, 'LOWER', 'LOWER( «character_expression» )', 'LOWER({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (17, 2, 'LTRIM', 'LTRIM( «character_expression» )', 'LTRIM({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (18, 2, 'REPLACE', 'REPLACE( «character_expression», «search_expression», «replace_expression» )', 'REPLACE({0}, «search_expression», «replace_expression»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (19, 2, 'REPLICATE', 'REPLICATE( «character_expression», «times» )', 'REPLICATE({0}, «times»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (20, 2, 'RESERVE', 'REVERSE( «character_expression» )', 'REVERSE({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (21, 2, 'RIGHT', 'RIGHT( «character_expression», «number» )', 'RIGHT({0}, «number»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (22, 2, 'RTRIM', 'RTRIM( «character_expression» )', 'RTRIM({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (23, 2, 'SUBSTRING', 'SUBSTRING( «character_expression», «start», «length» )', 'SUBSTRING({0}, «start», «length»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (24, 2, 'TRIM', 'TRIM( «character_expression» )', 'TRIM({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (25, 2, 'UPPER', 'UPPER( «character_expression» )', 'UPPER({0})', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (26, 3, 'DATEADD', 'DATEADD( «datepart», «number», «date» )', 'DATEADD(«datepart», «number», «date» )', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (27, 3, 'DATEDIFF', 'DATEDIFF( «datepart», «startdate», «enddate» )', 'DATEDIFF(«datepart», «startdate», «enddate»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (28, 3, 'DATEPART', 'DATEPART( «datepart», «date» )', 'DATEPART(«datepart», «date»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (29, 3, 'DAY', 'DAY( «date» )', 'DAY( «date» )', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (30, 3, 'GETDATE', 'GETDATE()', 'GETDATE()', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (31, 3, 'GETUTCDATE', 'GETUTCDATE()', 'GETUTCDATE()', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (32, 3, 'MONTH', 'MONTH( «date» )', 'MONTH( «date» )', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (33, 3, 'YEAR', 'YEAR( «date» )', 'YEAR( «date» )', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (34, 5, '(DT_I1)', '(DT_I1)', '(DT_I1)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (35, 5, '(DT_I2)', '(DT_I2)', '(DT_I2)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (36, 5, '(DT_I4)', '(DT_I4)', '(DT_I4)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (37, 5, '(DT_I8)', '(DT_I8)', '(DT_I8)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (38, 5, '(DT_UI1)', '(DT_UI1)', '(DT_UI1)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (39, 5, '(DT_UI2)', '(DT_UI2)', '(DT_UI2)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (40, 5, '(DT_UI4)', '(DT_UI4)', '(DT_UI4)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (41, 5, '(DT_UI8)', '(DT_UI8)', '(DT_UI8)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (42, 5, '(DT_R4)', '(DT_R4)', '(DT_R4)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (43, 5, '(DT_R8)', '(DT_R8)', '(DT_R8)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (44, 5, '(DT_STR)', '(DT_STR, «length», «code_page»)', '(DT_STR, «length», «code_page»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (45, 5, '(DT_WSTR)', '(DT_WSTR, «length»)', '(DT_WSTR, «length»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (46, 5, '(DT_DATE)', '(DT_DATE)', '(DT_DATE)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (47, 5, '(DT_BOOL)', '(DT_BOOL)', '(DT_BOOL)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (48, 5, '(DT_NUMERIC)', '(DT_NUMERIC, «precision», «scale»)', '(DT_NUMERIC, «precision», «scale»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (49, 5, '(DT_DECIMAL)', '(DT_DECIMAL, «scale»)', '(DT_DECIMAL, «scale»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (50, 5, '(DT_CY)', '(DT_CY)', '(DT_CY)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (51, 5, '(DT_GUID)', '(DT_GUID)', '(DT_GUID)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (52, 5, '(DT_BYTES)', '(DT_BYTES, «length»)', '(DT_BYTES, «length»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (53, 5, '(DT_DBDATE)', '(DT_DBDATE)', '(DT_DBDATE)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (54, 5, '(DT_DBTIME)', '(DT_DBTIME)', '(DT_DBTIME)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (55, 5, '(DT_DBTIMESTAMP)', '(DT_DBTIMESTAMP)', '(DT_DBTIMESTAMP)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (56, 5, '(DT_FILETIME)', '(DT_FILETIME)', '(DT_FILETIME)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (57, 5, '(DT_IMAGE)', '(DT_IMAGE)', '(DT_IMAGE)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (58, 5, '(DT_TEXT)', '(DT_TEXT, «code_page»)', '(DT_TEXT, «code_page»)', 1)
INSERT dbo.CWX_CDL_SSISFunctions VALUES (59, 5, '(DT_NTEXT)', '(DT_NTEXT)', '(DT_NTEXT)', 1)
GO


/****** Object:  StoredProcedure [dbo].[CWX_CDL_LoadToCWorks_Dict_CWorksField]    Script Date: 10/01/2009 16:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: 29 Sep, 2009
-- Description:	Get CWorks Field base on RowID and Load1Field on table LoadToCWorks_Dict
-- =============================================
ALTER PROCEDURE [dbo].[CWX_CDL_LoadToCWorks_Dict_CWorksField]
	@DatabaseID int,
	@TableName varchar(50),
	--@ID int,
	@Load1Field varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @ID int
	SELECT @ID = ID
	FROM CWX_CDL_ImportDestTable_Dict
	WHERE DatabaseID = DatabaseID AND TableName = @TableName
    -- Insert statements for procedure here	
	SELECT CWorksField
	FROM CWX_CDL_LoadToCWorks_Dict
	WHERE ID = @ID And  Load1Field= @Load1Field	
END
GO