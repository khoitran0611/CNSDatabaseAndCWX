-- Script is applied on version 2.1.5, 2.1.6
-- =======================================================================
-- Author:		Thao Nguyen
-- Create date: Jul 07, 2008
-- Description:	Drop columns Contact
-- Effected table:	Legal_Solicitors
-- =======================================================================
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Solicitors' and c.name = 'Contact')
BEGIN
	ALTER TABLE Legal_Solicitors
	DROP COLUMN Contact
END
GO

/****** Object:  Table [dbo].[Legal_AgentTypes]    Script Date: 06/17/2008 09:29:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_AgentTypes](
	[AgentTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Seq] [int] NOT NULL CONSTRAINT [DF_Legal_AgentTypes_Seq]  DEFAULT ((0)),
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_AgentTypes_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_AgentTypes] PRIMARY KEY CLUSTERED 
(
	[AgentTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]


-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Jul 07, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_AgentTypes
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_AgentTypes' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_AgentTypes
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_AgentTypes_RowStatus] DEFAULT 'A'
END
GO

/****** Object:  Table [dbo].[Legal_AgentSubtypes]    Script Date: 06/17/2008 09:29:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_AgentSubtypes](
	[AgentSubtypeID] [int] IDENTITY(1,1) NOT NULL,
	[AgentTypeID] [int] NOT NULL,
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Seq] [int] NOT NULL CONSTRAINT [DF_Legal_AgentSubtypes_Seq]  DEFAULT ((0)),
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_AgentSubtypes_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_AgentSubtypes] PRIMARY KEY CLUSTERED 
(
	[AgentSubtypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Jul 07, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_AgentSubtypes
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_AgentSubtypes' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_AgentSubtypes
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_AgentSubtypes_RowStatus] DEFAULT 'A'
END
GO

/****** Object:  Table [dbo].[Legal_Contacts]    Script Date: 06/17/2008 09:29:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Legal_Contacts](
	[ContactID] [int] IDENTITY(1,1) NOT NULL,
	[ParentID] [int] NOT NULL,
	[ParentType] [char](1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Title] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FirstName] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[LastName] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Description] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CommPointID] [int] NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_Contacts_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_Contacts] PRIMARY KEY CLUSTERED 
(
	[ContactID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 08, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_Contacts
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Contacts' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_Contacts
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_Contacts_RowStatus] DEFAULT 'A'
END
GO

-- Scripts 2.1.6, 2.1.7:

/****** Object:  StoredProcedure [dbo].[CWX_Ticket_ViewTicket]    Script Date: 07/08/2008 18:14:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Ticket_ViewTicket]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Ticket_ViewTicket]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Ticket_ViewTicket]    Script Date: 07/08/2008 18:14:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Ticket_ViewTicket]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Khoa Dang
CREATE PROCEDURE [dbo].[CWX_Ticket_ViewTicket]
	@accountID int,
	@pageSize int,
	@pageIndex int
AS
BEGIN
	declare @startRow int, @endRow int
	declare @totalRow int
	set @startRow = @pageIndex * @pageSize + 1
	set @endRow = (@pageIndex + 1) * @pageSize

	select row_number() over (order by t.RequestDate desc) as RowNumber, t.TicketID, d.Description, t.CurrentStage/t.TotalStage as Stage, t.RequestDate, t.StartDate,
		t.DueDate, (select Description from TicketStatus where TicketStatusID=t.TicketStatus) as TicketStatus,
		(select EmployeeName from Employee where EmployeeID=t.Requester) as RequesterName,
		(select EmployeeName from Employee where EmployeeID=t.AssignedTo) as AssignedTo
	into #TicketView
	from Ticket t inner join TicketDefinition d on t.TicketTypeID=d.TktDefID
	where t.AccountID=@AccountID
	
	select @totalRow=@@RowCount
	select * from #TicketView where RowNumber between @startRow and @endRow
	select @totalRow as TotalRow
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_TicketStage_Get]    Script Date: 07/08/2008 18:14:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketStage_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TicketStage_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TicketStage_Get]    Script Date: 07/08/2008 18:14:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketStage_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
CREATE proc [dbo].[CWX_TicketStage_Get]
	@TicketID int
As
BEGIN
	select TicketStageID,Stage,InDate,DueDate,s.Description as StageStatus,e.EmployeeName
		from TicketStages t inner join Employee e on t.EmployeeID=e.EmployeeID
		left join TicketStatus s on t.StageStatus=s.TicketStatusID
		where TicketID=@TicketID
		order by Stage asc
END' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_TicketNote_Get]    Script Date: 07/08/2008 18:14:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketNote_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TicketNote_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TicketNote_Get]    Script Date: 07/08/2008 18:14:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketNote_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
CREATE PROCEDURE [dbo].[CWX_TicketNote_Get]
	@ticketID int
AS
BEGIN

	select NoteDateTime,NoteText,e.EmployeeName
		from TicketNotes t inner join Employee e on t.EmployeeID=e.EmployeeID
		where t.NoteType=''M'' and t.TicketID=@TicketID
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Ticket_ViewTicket]    Script Date: 07/09/2008 10:30:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Ticket_ViewTicket]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Ticket_ViewTicket]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Ticket_ViewTicket]    Script Date: 07/09/2008 10:30:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Ticket_ViewTicket]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Khoa Dang
CREATE PROCEDURE [dbo].[CWX_Ticket_ViewTicket]
	@accountID int,
	@pageSize int,
	@pageIndex int
AS
BEGIN
	declare @startRow int, @endRow int
	declare @totalRow int
	set @startRow = @pageIndex * @pageSize + 1
	set @endRow = (@pageIndex + 1) * @pageSize

	select row_number() over (order by t.RequestDate desc) as RowNumber, t.TicketID, t.TicketTypeID, d.Description, STR(t.CurrentStage) + ''/'' + STR(t.TotalStage) as Stage, t.RequestDate, t.StartDate,
		t.DueDate, (select Description from TicketStatus where TicketStatusID=t.TicketStatus) as TicketStatus,
		(select EmployeeName from Employee where EmployeeID=t.Requester) as RequesterName,
		(select EmployeeName from Employee where EmployeeID=t.AssignedTo) as AssignedTo
	into #TicketView
	from Ticket t inner join TicketDefinition d on t.TicketTypeID=d.TktDefID
	where t.AccountID=@AccountID
	
	select @totalRow=@@RowCount
	select * from #TicketView where RowNumber between @startRow and @endRow
	select @totalRow as TotalRow
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_TicketNote_Get]    Script Date: 07/09/2008 10:30:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketNote_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TicketNote_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TicketNote_Get]    Script Date: 07/09/2008 10:30:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketNote_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
CREATE PROCEDURE [dbo].[CWX_TicketNote_Get]
	@ticketID int
AS
BEGIN

	select NoteDateTime,NoteText,e.EmployeeName
		from TicketNotes t inner join Employee e on t.EmployeeID=e.EmployeeID
		where t.NoteType=''M'' and t.TicketID=@TicketID
		order by NoteDateTime desc
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingList]    Script Date: 07/09/2008 14:32:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Contacts_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingList]    Script Date: 07/09/2008 14:32:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Contacts_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-08
-- Description:	Get paging list of LegalContacts, alphabetically ascending order by 
-- ''Parent Contact Employee Name'' group by ''Parent Contact Type''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingList]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT
		ROW_NUMBER() OVER (ORDER BY a.ParentType, Coalesce(b.Code, c.Code)) AS RowNumber,
		a.ContactID,
		a.ParentType, 
		Coalesce(b.Code, c.Code) Code, 
		Coalesce(b.Name, c.CommonName) [Name],
		IsNull(Title,'''') Title, IsNull(FirstName, '''') FirstName, IsNull(LastName, '''') LastName, 
		a.[Description]		
	INTO #Temp
	FROM Legal_Contacts a
		LEFT JOIN Legal_Solicitors b ON a.ParentID = b.SolicitorID AND ParentType = ''1''
		LEFT JOIN Legal_Creditors c ON a.ParentID = c.CreditorID AND ParentType = ''3''
	WHERE  a.Status <> ''R''
	ORDER BY a.ParentType, Code	

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT ContactID, ParentType, Code + Case When [Name]<>'''' Then '' - '' + [Name] Else '''' End CodeAndName, 
			LTRIM(Case When Title<>'''' Then Title Else '''' End + Case When FirstName<>'''' Then '' ''+FirstName Else '''' End + 
				Case When LastName<>'''' Then '' '' + LastName Else '''' End) ContactName,
			[Description]
	FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
' 
END
GO

/****** Object:  Table [dbo].[Legal_TransactionTypes]    Script Date: 07/09/2008 14:28:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Legal_TransactionTypes](
	[TransactionTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](50) NOT NULL,
	[Category] [char](1) NOT NULL,
	[TransactionType] [int] NOT NULL,
 CONSTRAINT [PK_Legal_TransactionTypes] PRIMARY KEY CLUSTERED 
(
	[TransactionTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[Legal_Agents]    Script Date: 06/17/2008 09:29:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_Agents](
	[AgentID] [int] IDENTITY(1,1) NOT NULL,
	[AgentTypeID] [int] NOT NULL,
	[AgentSubtypeID] [int] NULL,
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Name] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CourtID] [int] NULL,
	[AgentOccupationID] [int] NULL,
	[PostCodeStart] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PostCodeEnd] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CommPointID] [int] NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_Agents_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_Agents] PRIMARY KEY CLUSTERED 
(
	[AgentID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 09, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_Agents
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Agents' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_Agents
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_Agents_RowStatus] DEFAULT 'A'
END
GO

-- =======================================================================
-- Author:			Thuy Nguyen
-- Create date:		Jul 09, 2008
-- Description:		Update Ticket definition change "Site Visit" to "Payment Pickup"
-- Effected table:	TicketDefinition
-- =======================================================================
Update TicketDefinition set Description = 'Payment Pickup' where TktDefID = 3

/******  Script Closed. Go next: Step015_4  ******/