-- Script is applied on version 1.2 build 3

-- ====================================================================
-- Author:		  Tuan Luong
-- Create date:   Mar 10, 2008
-- Modified date: Mar 20, 2008
-- Description:	  Returns a table contains all table names bases 
--				  on the given @RuleType
-- Parameters: 
--	@RuleType:  1 - Extraction
--			    2 - Account Processing
--				3 - Available Temporary (belongs to Account Management)
-- Database:      CWorks
-- =====================================================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Interface_FnGetCriteriaTableNames]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CWX_Interface_FnGetCriteriaTableNames]
GO
CREATE FUNCTION [dbo].[CWX_Interface_FnGetCriteriaTableNames]
(
	@RuleType int
)
RETURNS 
@CriteriaTableNames TABLE 
(
	TableName varchar(125)
)
AS
BEGIN
	IF (@RuleType = 1)
	BEGIN
		INSERT @CriteriaTableNames
		SELECT TOP 1 AccountTable FROM Interface 
		WHERE AccountTable is not NULL or AccountTable <> ''
		ORDER BY InterfaceID
		
		INSERT @CriteriaTableNames
		SELECT TOP 1 CustomerTable FROM Interface 
		WHERE AccountTable is not NULL or AccountTable <> ''
		ORDER BY InterfaceID	
	END
	ELSE IF (@RuleType = 2)
	BEGIN
		INSERT @CriteriaTableNames
		SELECT TOP 1 AccountTable FROM Interface 
		WHERE AccountTable is not NULL or AccountTable <> ''
		ORDER BY InterfaceID
		
		INSERT @CriteriaTableNames
		SELECT TOP 1 CustomerTable FROM Interface 
		WHERE AccountTable is not NULL or AccountTable <> ''
		ORDER BY InterfaceID
	END
	ELSE IF (@RuleType = 4)
	BEGIN
		INSERT @CriteriaTableNames
		SELECT TOP 1 AccountTable FROM Interface 
		WHERE AccountTable is not NULL or AccountTable <> ''
		ORDER BY InterfaceID
		
		INSERT @CriteriaTableNames
		SELECT TOP 1 CustomerTable FROM Interface 
		WHERE AccountTable is not NULL or AccountTable <> ''
		ORDER BY InterfaceID
	END	
	RETURN 
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_Search]    Script Date: 03/21/2008 18:15:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_Search]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_Search]    Script Date: 03/21/2008 18:15:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Dec 15, 2007
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_Search]
	@EmployeeName varchar(50) = '',
	@Department int = 0,
	@RoleID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT
		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber,
		e.EmployeeID,
		e.UserID,
		e.EmployeeName,
		ISNULL(d.DeptDesc, '') AS Department,
		e.RoleID,
		--r.[Role],
		e.Description,
		CASE e.Supervisor WHEN 1 THEN 'Y' ELSE '' END AS Supervisor
	INTO #Temp
	FROM Employee e
	--LEFT JOIN RoleDefinition r ON e.RoleID = r.RoleID
	LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID AND (d.Status <> 'R')
	WHERE
		(e.EmployeeName LIKE ('%' + @EmployeeName + '%'))
		AND (@Department = 0 OR e.Department = @Department)
		AND (@RoleID = 0 OR e.RoleID = @RoleID)
		AND (ISNULL(EmployeeStatus, '') <> 'R')

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF @PageSize <= 0
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END



