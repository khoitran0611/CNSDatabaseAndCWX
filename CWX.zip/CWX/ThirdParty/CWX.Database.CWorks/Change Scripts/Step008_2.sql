 -- Scripts are applied on version 1.3 build 2

/****** Object:  StoredProcedure [dbo].[CWX_Account_ChangeQueueDay]    Script Date: 04/01/2008 17:47:08 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ChangeQueueDay]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_ChangeQueueDay]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ChangeQueueDay]    Script Date: 04/01/2008 17:47:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 01, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_ChangeQueueDay] 
	-- Add the parameters for the stored procedure here
	@QueueDay int = 0,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				QueueDate = DATEADD(day, @QueueDay, GETDATE())
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SET @NoteText = 'AcctMgmt: Queue Date Changed; ' + CAST(@QueueDay AS varchar(5)) + '  Queue Days Added '

			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 04/01/2008 17:47:08 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetListByRule]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 04/01/2008 17:47:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 24, 2008
-- Description:	Retrieve records that match the rulecriterias of a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetListByRule] 
	-- Add the parameters for the stored procedure here
	@RuleID int,
	@PageSize int = 10,
	@PageIndex int = 0,
	@ProcessedAccountIDs varchar(4000) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat
		FROM RuleCriteria
		WHERE RuleID = @RuleID

	DECLARE @SQLFormat varchar(100)
	DECLARE @WhereClause varchar(2000)

	OPEN RuleCriteriaCrsr

	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @WhereClause = ' AND ' + @SQLFormat

		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat
	END

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr

	--Remove the Account that was processed
	IF @ProcessedAccountIDs IS NOT NULL AND @ProcessedAccountIDs <> ''
	BEGIN
		SELECT CAST(SplitedText AS int) AS AccountID
		INTO #ProcessedAccountIDs
		FROM CWX_FnSplitString(@ProcessedAccountIDs, '|')

		SET @WhereClause = @WhereClause + ' AND Account.AccountId NOT IN (SELECT AccountID FROM #ProcessedAccountIDs)'
	END

	--This is used for AllocationRule, if RuleType=1, append condition <Account.MAINTAINOFFICER = 0>
	DECLARE @RuleType tinyint
	SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID
	IF @RuleType = 1
		SET @WhereClause = ' AND Account.MAINTAINOFFICER = 0' + @WhereClause

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY PRIMARY KEY,
		AccountId int,
		DebtorId int,
		FirstName varchar(50),
		MiddleName varchar(50),
		LastName varchar(50),
		BillBalance money,
		BillAmount money,
		InvoiceNumber varchar(50)
	)

	DECLARE @Sql varchar(4000)

	SET @Sql = 'INSERT INTO #Temp'
				+ ' SELECT'
				+ ' Account.AccountId,Account.DebtorId,PersonInformation.FirstName,PersonInformation.MiddleName,PersonInformation.LastName,Account.BillBalance,Account.BillAmount,Account.InvoiceNumber'
				+ ' FROM Account'
				+ ' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID'
				+ ' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID'
				+ ' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID'
				+ ' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID'
				+ ' WHERE (PersonAddress.MailingAddress = 1)'
				+ @WhereClause
				+ ' ORDER BY Account.AccountId'

	EXEC (@Sql)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	DROP TABLE #Temp

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_PermanentReassign]    Script Date: 04/01/2008 17:47:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_PermanentReassign]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_PermanentReassign]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_PermanentReassign]    Script Date: 04/01/2008 17:47:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 27, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_PermanentReassign] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@MaintainOfficer bit = 0,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				AssignmentType = 'P',
				EmployeeID = @EmployeeID,
				MaintainOfficer = @MaintainOfficer
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @CurrentUserID
			SET @NoteText = 'AcctMgmt: Permanent Reassignment to ' + @EmployeeName + ' with MaintainOfficer '
			IF @MaintainOfficer = 0
				SET @NoteText = @NoteText + 'unchecked'
			ELSE
				SET @NoteText = @NoteText + 'checked'

			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_TemporaryReassign]    Script Date: 04/01/2008 17:47:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_TemporaryReassign]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_TemporaryReassign] 
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_TemporaryReassign]    Script Date: 04/01/2008 17:47:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 27, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_TemporaryReassign] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				AssignmentType = 'T',
				TempEmployeeID = @EmployeeID
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @EmployeeID
			SET @NoteText = 'AcctMgmt: Temporary Reassignment To ' + @EmployeeName
			
			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_ProductSetting_InsertDefaultValues]    Script Date: 04/02/2008 10:04:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_ProductSetting_InsertDefaultValues]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_InformationTable_ProductSetting_InsertDefaultValues]
GO
/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_ProductSetting_InsertDefaultValues]    Script Date: 04/02/2008 10:06:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_InformationTable_ProductSetting_InsertDefaultValues] 
	-- Add the parameters for the stored procedure here
	@ProductID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @Bucket int
	DECLARE @BucketName varchar(50)

	SET @Bucket = 0
	WHILE @Bucket <= 7
	BEGIN
		IF @Bucket = 7
			SET @BucketName = '6+'
		ELSE
			SET @BucketName = CAST(@Bucket AS varchar(50))

		INSERT INTO InformationTable VALUES(6, @ProductID,  1, @BucketName, 'PercentageToKeepPromise',			 '95', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID,  2, @BucketName, 'GracePeriodToPaymentDate',			  '3', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID,  3, @BucketName, 'BrokenPromisesCount',				  '3', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID,  4, @BucketName, 'HoldDaysCount',					  '3', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID,  5, @BucketName, 'MinAcceptCommitmentAmount',		 '50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID,  6, @BucketName, 'MinAcceptCommitmentPercent',		 '50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID,  7, @BucketName, 'MinAcceptOverlimitPercent',		 '50', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID,  8, @BucketName, 'NoAnswerCount',					  '3', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID,  9, @BucketName, 'NoCommitmentCount',				  '3', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID, 10, @BucketName, 'PromiseIntervalDaysCount',			  '3', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID, 11, @BucketName, 'MaxAllowableContacts',				  '3', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID, 12, @BucketName, 'MaxQueueDateWithPromise',			 '10', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID, 13, @BucketName, 'MaxQueueDaysWithoutPromise',		  '3', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID, 14, @BucketName, 'DownpaymentPercentForReschedule',	 '25', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID, 15, @BucketName, 'DownpaymentPercentForDiscount',	 '25', '', 'A')
		INSERT INTO InformationTable VALUES(6, @ProductID, 16, @BucketName, 'MinimumDuePercent',				'100', '', 'A')

		IF( @@ERROR <> 0)
			GOTO Cleanup

		SET @Bucket = @Bucket + 1
	END

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
	END

Cleanup:
	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		ROLLBACK TRANSACTION
	END

END
GO

-- =============================================
-- Author:		Tuan Luong
-- Create date: Apr 01, 2008
-- Description:	
-- =============================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ReferToEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_ReferToEmployee]
GO
CREATE PROCEDURE [dbo].[CWX_Account_ReferToEmployee]
	@EmployeeID int,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				ActionEmployee = @EmployeeID
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @EmployeeID
			SET @NoteText = 'AcctMgmt: Refer to ' + @EmployeeName
			
			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END

GO
