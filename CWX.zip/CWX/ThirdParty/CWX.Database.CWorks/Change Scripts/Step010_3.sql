-- Scripts are applied on version 1.5.0 & 1.5.1
UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_QueueByAmtRange %1, %2'
WHERE	(ID = 8)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_Queue_NoActivityInXDays %1, %2'
WHERE	(ID = 13)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_Queue_NoContactInXDays %1, %2'
WHERE	(ID = 14)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchCollateralItemType %1, %2'
WHERE	(ID = 19)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchCollateralByEmployee %1, %2'
WHERE	(ID = 20)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchCollateralStage %1, %2'
WHERE	(ID = 21)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchCollateralNextAction %1, %2'
WHERE	(ID = 22)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchByLegalForward %1, %2'
WHERE	(ID = 23)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchByLegalEmployee %1, %2'
WHERE	(ID = 24)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchByLegalNextAction %1, %2'
WHERE	(ID = 25)

GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueFuture]    Script Date: 04/28/2008 09:24:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_QueueFuture]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_QueueFuture]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueFuture]    Script Date: 04/28/2008 09:24:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_QueueFuture] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@Days int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		[KeyField] varchar(30),
		[QueueDate] char(10),
		[Account Number] varchar(50),
		[DPD] int,
		[Bucket] char(1),
		[Cycle] smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		[Status] varchar(10),
		[Priority] int,
		[Assignment Type] char(1),
		[Name] varchar(200)
	)
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.EmployeeID = ' + CAST(@EmployeeID AS varchar(10))
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

--Today|2|GE Today|0|Tomorrow|1|3 Days|3|5 Days|5

				if (@Days = 1) or (@Days = 3) or (@Days = 5)
				Begin
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) <= dateadd(day,' + CAST(@Days AS varchar(10)) + ', getdate())'
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) >= getdate()'
				End

				if @Days = 2
				Begin
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) = getdate()'
				End

				if @Days = 0
				Begin
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) >= getdate()'
				End

				Set @cStmt = @cStmt + ' Order by a.QueueDate DESC'
				EXEC (@cStmt)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]    Script Date: 04/25/2008 13:50:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]    Script Date: 04/25/2008 13:50:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Binh Truong
-- Create date: April 17, 2008
-- Modify date: April 23, 2008
-- Description:	Get total active account and bill balance of collector
-- Parameters: 
--	@PorfolioType	0: Queue Active
--					Other number: All accounts
-- =============================================================
CREATE PROCEDURE CWX_EmployeeReport_GetTotalAccountAndBillBalance
	@PorfolioType AS SMALLINT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Select NVARCHAR(1000)
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @Statement NVARCHAR(2000)
	DECLARE @Parms NVARCHAR(500)
	
	SET @Conditions = '' WHERE (Employee.EmployeeStatus = ''''A'''') ''	
	
	SET @Select = ''
		SELECT	COUNT(Account.AccountID) AS TotalAccount,
				SUM(Account.BillBalance) as TotalDollarValue 
		FROM         Account INNER JOIN
                      Employee ON Account.EmployeeID = Employee.EmployeeID     
		'' 		
		
	IF @PorfolioType = 0		
		SET @Conditions = @Conditions + ''
					AND SystemStatusId = 5 
					AND AgencyStatusID <> 2 
					AND QueueDate <= GETDATE()
			''
		
	SET @Statement = @Select + @Conditions
	
	EXEC dbo.sp_executesql @Statement
		
	SET @Select = ''
		SELECT	COUNT(Account.TempEmployeeID ) AS TotalTempAccount,
				SUM(BillBalance) as TotalTempDollarValue 
		FROM         Account INNER JOIN
                      Employee ON Account.TempEmployeeID = Employee.EmployeeID     
		'' 		
		
	SET @Statement = @Select + @Conditions
	
	EXEC dbo.sp_executesql @Statement
	
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetAccountAmountByEmployeeID]    Script Date: 04/25/2008 14:21:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetAccountAmountByEmployeeID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_EmployeeReport_GetAccountAmountByEmployeeID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]    Script Date: 04/25/2008 14:21:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetEmployeePortfolio]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetAccountAmountByEmployeeID]    Script Date: 04/25/2008 14:21:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetAccountAmountByEmployeeID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--===============================================================================
-- Description:	Get account amount by EmployeeID.
-- Parameters: 
--	@EmployeeID		Employee ID
--	@PorfolioType	0: Queue Active
--					Other number: All accounts
-- Revision History:
--  Date        Comment
--  04/23/08    Binh Truong: Initial version started.
--  04/24/08	Binh Truong: Add @PortfolioType parametter.
--===============================================================================
CREATE PROCEDURE [dbo].[CWX_EmployeeReport_GetAccountAmountByEmployeeID]
	@EmployeeID INT,
	@PorfolioType SMALLINT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @Statement NVARCHAR(4000)
	DECLARE @Select NVARCHAR(1000)
	DECLARE @GroupBy NVARCHAR(1000)
	DECLARE @ParmsDeclare NVARCHAR(1000)
	
	SET @Select	= ''
		SELECT		AccountStatus.ShortDesc AS AccountStatus, COUNT(Account.AccountID) AS AccountAmount
		FROM		AccountStatus INNER JOIN
						Account ON AccountStatus.AgencyStatus = Account.AgencyStatusID
		''
	
	SET @Conditions = ''
		WHERE		(Account.EmployeeID = @EmployeeID
					OR Account.TempEmployeeID = @EmployeeID)
		''
			
	SET @GroupBy = ''	
		GROUP BY	AccountStatus.ShortDesc
		''
	
	IF @PorfolioType = 0		
		SET @Conditions = @Conditions + ''AND (
			SystemStatusId = 5 
			AND AgencyStatusID <> 2 
			AND QueueDate <= GETDATE()
			)''
		
	SET @Statement = @Select + @Conditions + @GroupBy
	
	SET @ParmsDeclare = ''
			@EmployeeID INT = NULL
			''
	
	EXEC dbo.sp_executesql @Statement, @ParmsDeclare,
							@EmployeeID
	
END


' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]    Script Date: 04/25/2008 14:21:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetEmployeePortfolio]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Binh Truong
-- Create date: April 17, 2008
-- Modified date : April 21, 2008
-- Modified by: Tuan Luong
-- Description:	Get employee portfolio
-- Parameters: 
--	@PorfolioType	0: Queue Active
--					Other number: All accounts
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]
	@PorfolioType smallint,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @TotalAccStatement NVARCHAR(1000)
	DECLARE @TotalDollarValueStatement NVARCHAR(1000)
	DECLARE @MainStatement NVARCHAR(4000)
	DECLARE @RowCount INT
	
	SET @Conditions = ''''	

	IF @PorfolioType = 0		
		SET @Conditions = ''
			AND SystemStatusId = 5 
			AND AgencyStatusID <> 2 
			AND QueueDate <= GETDATE()
			''
	
	DECLARE @ParmDefinition NVARCHAR(500);
	DECLARE @TotalAccount VARCHAR(30);
	DECLARE @TotalDollarValue VARCHAR(30);

	SET @TotalAccStatement = N''SELECT @TotalAccountOUT = COUNT(*) FROM Account WHERE (1=1) '';
	SET @TotalAccStatement = @TotalAccStatement + @Conditions
	SET @ParmDefinition = N''@TotalAccountOUT INT OUTPUT'';

	EXECUTE sp_executesql @TotalAccStatement, @ParmDefinition, @TotalAccountOUT=@TotalAccount OUTPUT;

	SET @TotalDollarValueStatement = N''SELECT @TotalDollarValueOUT = SUM(BillBalance) FROM Account WHERE (1=1)'';
	SET @TotalDollarValueStatement = @TotalDollarValueStatement + @Conditions
	SET @ParmDefinition = N''@TotalDollarValueOUT INT OUTPUT'';

	EXECUTE sp_executesql @TotalDollarValueStatement, @ParmDefinition, @TotalDollarValueOUT=@TotalDollarValue OUTPUT;
	
	--Build the MainStatement
	SET @MainStatement = ''INSERT INTO #Temp SELECT Employee.EmployeeID, Employee.EmployeeName, ''

	SET @MainStatement = @MainStatement + '' (SELECT COUNT(EmployeeID) AS Expr1
						FROM          Account AS AT
						WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalAccount, ''
	
	SET @MainStatement = @MainStatement + '' (SELECT CAST(((COUNT(EmployeeID) * 100) / CAST('' + @TotalAccount + '' AS DECIMAL(18,2))) AS DECIMAL(18,2)) AS Expr1
						FROM          Account AS AT
						WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalAccountPercent, ''
    
	SET @MainStatement = @MainStatement + '' (SELECT     SUM(BillBalance) AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalDollarValue, ''

	SET @MainStatement = @MainStatement + '' (SELECT     SUM(BillBalance) * 100 / '' + @TotalDollarValue + '' AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalDollarValuePercent, ''

	SET @MainStatement = @MainStatement + '' (SELECT     COUNT(TempEmployeeID) AS Expr1
					FROM          Account AS AT
					WHERE      (AT.TempEmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.TempEmployeeID) AS TotalAccountTemp, '' 

	SET @MainStatement = @MainStatement + '' (SELECT     SUM(BillBalance) AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.TempEmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.TempEmployeeID) AS TotalDollarValueAccountTemp ''

	SET @MainStatement = @MainStatement +	'' FROM  Employee WHERE EmployeeStatus = ''''A'''''' 

	CREATE TABLE #Temp
	(
		Idx int IDENTITY,
		EmployeeID int,
		EmployeeName varchar(50),
		TotalAccount int,
		TotalAccountPercent DECIMAL(18,0),
		TotalDollarValue int,
		TotalDollarValuePercent DECIMAL(18,0),
		TotalAccountTemp int,
		TotalDollarValueAccountTemp int		
	)

	EXEC dbo.sp_executesql @MainStatement
	
	SELECT @RowCount = Count(Idx) FROM #Temp

	SELECT  EmployeeName,
			EmployeeID,
			ISNULL(TotalAccount, 0) AS TotalAccount,
			CAST(ISNULL(TotalAccountPercent, 0) as varchar(50)) AS TotalAccountPercent,
			ISNULL(TotalDollarValue, 0) AS TotalDollarValue,
			CAST(ISNULL(TotalDollarValuePercent, 0) as varchar(50)) AS TotalDollarValuePercent,
			ISNULL(TotalAccountTemp, 0) AS TotalAccountTemp,
			ISNULL(TotalDollarValueAccountTemp, 0) AS TotalDollarValueAccountTemp
			
	FROM #Temp WHERE Idx between (@PageIndex)*@PageSize + 1 and (@PageIndex + 1)*@PageSize

	DROP TABLE #Temp
	
	RETURN @RowCount
END


' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_GetListByAccountID]    Script Date: 04/25/2008 14:42:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_GetListByAccountID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CosigneeInformation_GetListByAccountID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_GetListByAccountID]    Script Date: 04/25/2008 14:44:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 18, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_GetListByAccountID] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  (p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + p.LastName)) AS RowNumber,
		(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName,
		c.Relationship_no,
		a.Address1,
		a.City,
		a.State,
		a.Zip,
		p.HomePhone,
		p.MobilPhone,
		p.EmploymentPhone
	INTO #Temp
	FROM CosigneeInformation c
	JOIN PersonInformation p ON c.PersonID = p.PersonID
	JOIN PersonAddress a ON a.PersonID = p.PersonID
	WHERE
		a.AddressType = 2
		AND c.Bill = @AccountID

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT *
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 04/25/2008 17:43:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	AccountID
	INTO	#AccountTemp
	FROM	Account	
	WHERE	DebtorID = @DebtorID
	
	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, NoLetterBefore, NoFeeBefore, MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, BatchNumber, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, CurrentCallResult, CampaignId,
			' ' as LETTERSTATUS, BillAmount + BillBalance as BALANCE, String1 as PROMISE, QueueDate as LETTERDATE, InvoiceNumber as SENTBY, DebtorID as COOWNERS,
			' ' as LASTCONTACTDATE, ' ' as LASTCONTACTBY, ' ' as PROMISETOPAY, ' ' as PROMISEKEPT, ' ' as PROMISEBROKEN, ' ' as OUTGOINGCALL, ' ' as NOACTIVITYDAYS, 
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction 			
			
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END
GO

/****** Object:  Table [dbo].[TempDebtorXml]    Script Date: 04/25/2008 16:30:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TempDebtorXml]') AND type in (N'U'))
Begin
	Delete from [dbo].[TempDebtorXml]
End
GO

/****** Script Closed ******/