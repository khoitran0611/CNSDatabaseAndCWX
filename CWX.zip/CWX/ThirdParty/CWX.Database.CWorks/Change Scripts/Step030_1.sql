﻿-- Script is applied on version 3.6.0:

-- Start of Scripts 3.6.0:
Insert Into InformationTable (InfoID, InfoType, InfoSubType, InfoKey, [Description], [Value], ValueFormat, [Status])
	Values (1,16,0,'','Show Management Console','','True','A')
GO

IF  NOT EXISTS (SELECT [name] FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Transactions]') AND [name] = N'IDX_Transactions_ParentTransactionId')
   CREATE INDEX IDX_Transactions_ParentTransactionId ON dbo.Transactions(ParentTransactionID) 

ALTER TABLE AccountPromise ALTER COLUMN Sequence int
GO
ALTER TABLE AccountPromise ALTER COLUMN PeriodSeq int
GO

/****** Object:  StoredProcedure [dbo].[CWX_GetDynamicEditableFields]    Script Date: 02/20/2009 17:03:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Khoa Dang
ALTER PROCEDURE [dbo].[CWX_GetDynamicEditableFields]
	@TableID smallint,
	@RowID int
AS
BEGIN
	DECLARE @TableName varchar(20)
	DECLARE @TableName2 varchar(20)
	DECLARE @TableID2 int
	DECLARE @PrimaryKey varchar(20)
	IF @TableID = 1
	BEGIN
		SET @TableName = 'PersonInformation'
		SET @PrimaryKey = 'PersonID'
	END
	ELSE 
		IF @TableID = 2
		BEGIN
			SET @TableName = 'AccountOther'
			SET @TableName2 = 'Account'
			SET @PrimaryKey = 'AccountID'
			--SET 3 for Account Table
			SET @TableID2 = 3
		END

	/* DataTable 1: get FieldName and Description of DynamicEditableFields table depends on Type field */
	SELECT f.FieldName, f.Description, t.Name as DataType, c.max_length as MaxLength, c.precision, c.is_nullable AS IsNullable INTO #DynamicFields 
		FROM ((sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id)
			INNER JOIN sys.types t ON t.system_type_id = c.system_type_id)
			INNER JOIN CWX_DynamicEditableFields f ON c.Name = f.FieldName
		WHERE o.Name=@TableName AND f.TableID=@TableID
	
	SELECT * FROM #DynamicFields

	/* DataTable 2: return the structure of table that needs to update */
	DECLARE @FieldName varchar(100)
	DECLARE @FieldNames varchar(1000)
	DECLARE DynamicFieldsCursor CURSOR FOR SELECT FieldName FROM #DynamicFields
	OPEN DynamicFieldsCursor
	FETCH NEXT FROM DynamicFieldsCursor INTO @FieldName

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF LEN(@FieldNames) > 0
			SET @FieldNames = @FieldNames + ',' + @FieldName
		ELSE
			SET @FieldNames = @FieldName

		FETCH NEXT FROM DynamicFieldsCursor INTO @FieldName
	END

	CLOSE DynamicFieldsCursor
	DEALLOCATE DynamicFieldsCursor

	DECLARE @sql varchar(2000)
	SET @sql = 'SELECT ' + @FieldNames + ' FROM ' + @TableName + ' WHERE ' + @PrimaryKey + '=' + Str(@RowID)
	EXEC (@sql)

	/* DataTable 3: primary key */
	SELECT @PrimaryKey as PrimaryKey


	IF @TableID = 2
		BEGIN
			/* DataTable 4: get FieldName and Description of DynamicEditableFields table depends on Type field */
		SELECT f.FieldName, f.Description, t.Name as DataType, c.max_length as MaxLength, c.precision, c.is_nullable AS IsNullable INTO #DynamicFields2 
		FROM ((sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id)
			INNER JOIN sys.types t ON t.system_type_id = c.system_type_id)
			INNER JOIN CWX_DynamicEditableFields f ON c.Name = f.FieldName
		WHERE o.Name=@TableName2 AND f.TableID=@TableID2

		SELECT * FROM #DynamicFields2

		SET @FieldNames = ''
		DECLARE DynamicFieldsCursor CURSOR FOR SELECT FieldName FROM #DynamicFields2
		OPEN DynamicFieldsCursor
		FETCH NEXT FROM DynamicFieldsCursor INTO @FieldName

		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF LEN(@FieldNames) > 0
				SET @FieldNames = @FieldNames + ',' + @FieldName
			ELSE
				SET @FieldNames = @FieldName

			FETCH NEXT FROM DynamicFieldsCursor INTO @FieldName
		END

		CLOSE DynamicFieldsCursor
		DEALLOCATE DynamicFieldsCursor
		If LEN(@FieldNames) > 0
			BEGIN
				SET @sql = 'SELECT ' + @FieldNames + ' FROM ' + @TableName2 + ' WHERE ' + @PrimaryKey + '=' + Str(@RowID)
				EXEC (@sql)
			END
		END

END

GO

--	Add NumberofCopies column in AccountLetter and AccountLetterQueue tables
ALTER TABLE AccountLetter 
ADD NumberOfCopies INT NULL

GO

ALTER TABLE AccountLetterQueue 
ADD NumberOfCopies INT NULL

GO
