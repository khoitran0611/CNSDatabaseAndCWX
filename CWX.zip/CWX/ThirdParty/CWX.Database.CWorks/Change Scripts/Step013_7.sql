 -- Scripts are applied on version 1.9.10
 -- =======================================================================
-- Author:		Thuy Nguyen
-- Create date: Jun 12, 2008
-- Description:	Add column CreatedDate to table Employee
-- =======================================================================
IF NOT EXISTS (SELECT * FROM dbo.syscolumns WHERE name='CreatedDate' and id = (SELECT id FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[Employee]') and OBJECTPROPERTY(id, N'IsUserTable') = 1))
ALTER TABLE Employee ADD CreatedDate DateTime
GO


/****** Object:  StoredProcedure [dbo].[CWX_AvailableActions_SoftDeleteAll]    Script Date: 06/12/2008 13:40:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AvailableActions_SoftDeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AvailableActions_SoftDeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AvailableActions_SoftDeleteAll]    Script Date: 06/12/2008 13:40:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AvailableActions_SoftDeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- ===================================================================================
-- Author:		Binh Truong
-- Create date: Jun 12, 2008
-- Description:	Delete all ActionCode
-- ===================================================================================
CREATE PROCEDURE [dbo].[CWX_AvailableActions_SoftDeleteAll] 
AS
BEGIN
	UPDATE	[dbo].[AvailableActions]
	SET		Status = ''R''
	WHERE	ActionType = ''U''
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_BlackOutDates_DeleteAll]    Script Date: 06/12/2008 14:43:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_BlackOutDates_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_BlackOutDates_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_BlackOutDates_DeleteAll]    Script Date: 06/12/2008 14:43:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_BlackOutDates_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- ===================================================================================
-- Author:		Binh Truong
-- Create date: Jun 12, 2008
-- Description:	Delete all holiday dates
-- ===================================================================================
CREATE PROCEDURE [dbo].[CWX_BlackOutDates_DeleteAll] 
AS
BEGIN
	DELETE FROM BlackOutDates
	WHERE     (Employee = 0)
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AccountStatus_SoftDeleteAll]    Script Date: 06/12/2008 15:07:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountStatus_SoftDeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountStatus_SoftDeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountStatus_SoftDeleteAll]    Script Date: 06/12/2008 15:07:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountStatus_SoftDeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Soft delete all user defined account status.
-- Parameters:
--		@UserDefineStatusIDRange: indicating a start ID for user define status type.
-- History:
--		2008/06/12	[Binh Truong]	Init version.
-- =============================================
CREATE Procedure [dbo].[CWX_AccountStatus_SoftDeleteAll]
(
	@UserDefineStatusIDRange int
)
AS
BEGIN	
	UPDATE    AccountStatus
	SET              Status = ''R''
	WHERE     (AgencyStatus >= @UserDefineStatusIDRange)
END	
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_UserNotInUse]    Script Date: 06/12/2008 15:09:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_UserNotInUse]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Check whether user is not in use X days after first creation or password reset.
-- Parameters:
--		@UserName: current logged in user
--		@AvailableDays: X days allowed
-- History:
--		2008/06/12	[Thuy Nguyen]	Init version.
-- =============================================

CREATE PROCEDURE [dbo].[CWX_UserNotInUse] 	
	@UserName varchar(16),
	@AvailableDays int

AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @LoginUser varchar(16)	

	IF EXISTS (SELECT * FROM Employee WHERE UserID = @UserName 
					AND UserID NOT IN (SELECT LoginUserID FROM LoginAttemptsLog)
					AND (GETDATE() - CreatedDate) > @AvailableDays)
		RETURN 1
	ELSE
    BEGIN
	
		DECLARE @LastChangeDate DATETIME
		DECLARE @LastLoginDate DATETIME

		SET @LastChangeDate = (SELECT ChangeDate FROM PasswordHistoryLog a LEFT JOIN Employee b
									ON a.EmployeeID = b.EmployeeID
									WHERE b.UserID = @UserName AND ChangeDate > = (SELECT MAX(ChangeDate) FROM PasswordHistoryLog))


		SET @LastLoginDate = (SELECT LoginDateTime FROM LoginAttemptsLog									
									WHERE LoginUserID = @UserName AND LoginDateTime > = (SELECT MAX(LoginDateTime) FROM LoginAttemptsLog))

		IF (@LastChangeDate IS NOT NULL AND @LastLoginDate IS NOT NULL AND (@LastChangeDate - @LastLoginDate) > @AvailableDays)
			RETURN 1	
	END

	RETURN 0
END
'
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Save_Note]    Script Date: 06/12/2008 15:26:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Save_Note]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Save_Note]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Save_Note]    Script Date: 06/12/2008 15:26:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[CWX_Save_Note] 	
	(@EmployeeID int, @DebtorID int, @AccountID int, @NoteDateTime datetime, @NoteType varchar (1), @NoteText varchar(700))
AS
BEGIN

INSERT INTO [dbo].[NotesCurrent] (EmployeeID, DebtorID, BillID, NoteDateTime, NoteType, NoteText)
VALUES (@EmployeeID, @DebtorID, @AccountID, @NoteDateTime, @NoteType, @NoteText )

SELECT @@IDENTITY

END
GO

/******  Script Closed. Go next: Step013_8  ******/