-- Scripts are applied on version 1.6.6 & 1.7.0
DELETE FROM TempDebtorXml
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'TempDebtorXml' and c.name = 'IsDirty')
BEGIN
	ALTER TABLE TempDebtorXml
	ADD IsDirty [bit] NOT NULL
		CONSTRAINT [DF_TempDebtorXml_IsDirty]  DEFAULT ((0))
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_PermanentReassign]    Script Date: 05/24/2008 12:02:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_PermanentReassign]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_PermanentReassign]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_PermanentReassign]    Script Date: 05/24/2008 12:02:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 27, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_PermanentReassign] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@MaintainOfficer bit = 0,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				AssignmentType = 'P',
				EmployeeID = @EmployeeID,
				MaintainOfficer = @MaintainOfficer
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @CurrentUserID
			SET @NoteText = 'AcctMgmt: Permanent Reassignment to ' + @EmployeeName + ' with MaintainOfficer '
			IF @MaintainOfficer = 0
				SET @NoteText = @NoteText + 'unchecked'
			ELSE
				SET @NoteText = @NoteText + 'checked'

			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_TemporaryReassign]    Script Date: 05/24/2008 12:03:08 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_TemporaryReassign]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_TemporaryReassign]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_TemporaryReassign]    Script Date: 05/24/2008 12:03:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 27, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_TemporaryReassign] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				AssignmentType = 'T',
				TempEmployeeID = @EmployeeID
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @EmployeeID
			SET @NoteText = 'AcctMgmt: Temporary Reassignment To ' + @EmployeeName
			
			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ChangeQueueDay]    Script Date: 05/24/2008 12:03:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ChangeQueueDay]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_ChangeQueueDay]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ChangeQueueDay]    Script Date: 05/24/2008 12:04:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 01, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_ChangeQueueDay] 
	-- Add the parameters for the stored procedure here
	@QueueDay int = 0,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				QueueDate = DATEADD(day, @QueueDay, GETDATE())
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SET @NoteText = 'AcctMgmt: Queue Date Changed; ' + CAST(@QueueDay AS varchar(5)) + '  Queue Days Added '

			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ReferToEmployee]    Script Date: 05/24/2008 12:04:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ReferToEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_ReferToEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ReferToEmployee]    Script Date: 05/24/2008 12:05:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Account_ReferToEmployee]
	@EmployeeID int,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @EmployeeName varchar(50)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				ActionEmployee = @EmployeeID
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SELECT @EmployeeName = EmployeeName FROM Employee WHERE EmployeeID = @EmployeeID
			SET @NoteText = 'AcctMgmt: Refer to ' + @EmployeeName
			
			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ChangeAccountStatus]    Script Date: 05/24/2008 12:05:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_ChangeAccountStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_ChangeAccountStatus]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_ChangeAccountStatus]    Script Date: 05/24/2008 12:05:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[CWX_Account_ChangeAccountStatus] 
	@AgencyStatusID int,
	@AccountIDs varchar(8000) = NULL,
	@CurrentUserID int
AS
BEGIN
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)
		DECLARE @StatusDesc varchar(10)		

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				AgencyStatusID = @AgencyStatusID
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID
			
			SELECT @StatusDesc = ShortDesc FROM AccountStatus WHERE AgencyStatus = @AgencyStatusID
			SET @NoteText = 'AcctMgmt: Status Change to ' + @StatusDesc
			
			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_MaintainDelinquencyOfficer]    Script Date: 05/24/2008 12:05:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_MaintainDelinquencyOfficer]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_MaintainDelinquencyOfficer]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_MaintainDelinquencyOfficer]    Script Date: 05/24/2008 12:06:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Binh Truong
-- Create date: April 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_MaintainDelinquencyOfficer] 
	-- Add the parameters for the stored procedure here
	@MaintainOfficer bit,
	@AccountIDs varchar(8000),
	@CurrentUserID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @AccountIDs IS NOT NULL AND @AccountIDs <> ''
	BEGIN
	    DECLARE @TranStarted   bit
		SET @TranStarted = 0

		IF( @@TRANCOUNT = 0 )
		BEGIN
			BEGIN TRANSACTION
			SET @TranStarted = 1
		END

		DECLARE AccountIDsCrsr CURSOR FOR
		SELECT CAST(SplitedText AS int) AS AccountID
		FROM CWX_FnSplitString(@AccountIDs, '|')

		DECLARE @DebtorID int
		DECLARE @NoteText varchar(700)

		OPEN AccountIDsCrsr
		DECLARE @AccountID int
		FETCH NEXT FROM AccountIDsCrsr INTO @AccountID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Update account
			UPDATE Account
			SET
				MaintainOfficer = @MaintainOfficer
			WHERE AccountID = @AccountID

			IF( @@ERROR <> 0)
				GOTO Cleanup

			--Insert Note
			SELECT @DebtorID = DebtorID FROM Account WHERE AccountID = @AccountID

			SET @NoteText = 'AcctMgmt: Maintain Delinquency Officer '
			IF @MaintainOfficer = 0
				SET @NoteText = @NoteText + 'unchecked'
			ELSE
				SET @NoteText = @NoteText + 'checked'

			INSERT INTO NotesCurrent
			VALUES(0, @CurrentUserID, @DebtorID, @AccountID, GETDATE(), 'A', @NoteText)
			IF( @@ERROR <> 0)
				GOTO Cleanup

			--The AccountInfo was changed so set TempDebtorXml IsDirty to true
			UPDATE TempDebtorXml SET IsDirty = 1 WHERE DebtorID = @DebtorID
			IF( @@ERROR <> 0)
				GOTO Cleanup

			FETCH NEXT FROM AccountIDsCrsr INTO @AccountID
		END

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
			COMMIT TRANSACTION
		END

	Cleanup:
		CLOSE AccountIDsCrsr
		DEALLOCATE AccountIDsCrsr

		IF( @TranStarted = 1 )
		BEGIN
			SET @TranStarted = 0
    		ROLLBACK TRANSACTION
		END
	END
END
GO

/******  Script Closed  ******/