-- Scripts are applied on version 1.4.1 build 1


/****** Object:  StoredProcedure [dbo].[CWX_Notes_Get]    Script Date: 04/04/2008 16:36:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Notes_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Notes_Get]
GO
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Notes_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_Notes_Get] 	
	@DebtorID int, @AccountID int, @NoteType varchar(1)	
AS
BEGIN
	Declare @IdentityTableValue int
	Set @IdentityTableValue = (Select FieldValue from IdentityFields where TableName = ''NotesDisplayByAccount'')
	if (@IdentityTableValue < 0 )
		begin 
			Insert into IdentityFields values(''NotesDisplayByAccount'',0)
			if (@NoteType = ''H'')			
				begin
					select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
					where n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID   Order By n.NoteDateTime desc, n.NoteID			
				end
			else
				begin
					select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
					where n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND NoteType  Like @NoteType  Order By n.NoteDateTime desc, n.NoteID			
				end	
		end
	else if (@IdentityTableValue = 0 )
		begin 
			if (@NoteType = ''H'')			
				begin
					select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
					where n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID   Order By n.NoteDateTime desc, n.NoteID			
				end
			else
				begin
					select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
					where n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND NoteType  Like @NoteType  Order By n.NoteDateTime desc, n.NoteID			
				end	
		end
	else		
		begin
			if (@NoteType = ''H'')			
				begin
					select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
					where n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  Order By n.NoteDateTime desc, n.NoteID
				end
			else
				begin
					select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
					where n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  AND NoteType  Like @NoteType Order By n.NoteDateTime desc, n.NoteID
				end	
		end	
END		
' 
END
GO

UPDATE    QueryMaster
SET              [SQL2] = 'EXEC CWX_Account_SearchCollateralByEmployee %E, %1, %2'
WHERE     (ID = 20)

UPDATE    QueryParams
SET              PickList = 'select EmployeeID, EmployeeName from Employee where EmployeeStatus = ' + '''' + ' A ' + '''' + ' order by EmployeeName'
WHERE     (QueryID = 20)

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralByEmployee]    Script Date: 04/21/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchCollateralByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchCollateralByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralByEmployee]    Script Date: 04/21/2008 17:39:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchCollateralByEmployee] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@cEmployeeID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
		a.QueueDate AS [QueueDate],
		a.InvoiceNumber as [Account Number],
		a.AccountAge AS [DPD],
		CAST(a.MCode AS CHAR(2)) AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		s.ShortDesc AS [Status],
		s.SortPriority AS [Priority],
		a.AssignmentType AS [Assignment Type],
		RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
		m1.CodeDesc as [Type],
		m2.CodeDesc as [Stage],
		m3.CodeDesc as [Next Action],
		c.NextActionDate as [NextAction Date],
		e.EmployeeName as [By Whom]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND c.EmployeeID = @cEmployeeID 

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

UPDATE    QueryMaster
SET              [SQL2] = 'EXEC CWX_Account_SearchCollateralItemType %E, %1, %2'
WHERE     (ID = 19)

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralItemType]    Script Date: 04/21/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchCollateralItemType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchCollateralItemType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralItemType]    Script Date: 04/21/2008 17:39:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchCollateralItemType] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@ItemID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
		a.QueueDate AS [QueueDate],
		a.InvoiceNumber as [Account Number],
		a.AccountAge AS [DPD],
		CAST(a.MCode AS CHAR(2)) AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		s.ShortDesc AS [Status],
		s.SortPriority AS [Priority],
		a.AssignmentType AS [Assignment Type],
		RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
		m1.CodeDesc as [Type],
		m2.CodeDesc as [Stage],
		m3.CodeDesc as [Next Action],
		c.NextActionDate as [NextAction Date],
		e.EmployeeName as [By Whom]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND c.CollateralType = @ItemID 

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

UPDATE    QueryMaster
SET              [SQL2] = 'EXEC CWX_Account_SearchCollateralNextAction %E, %1, %2'
WHERE     (ID = 22)

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralNextAction]    Script Date: 04/21/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchCollateralNextAction]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchCollateralNextAction]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralNextAction]    Script Date: 04/21/2008 17:39:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchCollateralNextAction] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@cNextAction int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
		a.QueueDate AS [QueueDate],
		a.InvoiceNumber as [Account Number],
		a.AccountAge AS [DPD],
		CAST(a.MCode AS CHAR(2)) AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		s.ShortDesc AS [Status],
		s.SortPriority AS [Priority],
		a.AssignmentType AS [Assignment Type],
		RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
		m1.CodeDesc as [Type],
		m2.CodeDesc as [Stage],
		m3.CodeDesc as [Next Action],
		c.NextActionDate as [NextAction Date],
		e.EmployeeName as [By Whom]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND c.NextAction = @cNextAction 

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

UPDATE    QueryMaster
SET              [SQL2] = 'EXEC CWX_Account_SearchCollateralStage %E, %1, %2'
WHERE     (ID = 21)

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralStage]    Script Date: 04/21/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchCollateralStage]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchCollateralStage]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralStage]    Script Date: 04/21/2008 17:39:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchCollateralStage] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@cStageID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
		a.QueueDate AS [QueueDate],
		a.InvoiceNumber as [Account Number],
		a.AccountAge AS [DPD],
		CAST(a.MCode AS CHAR(2)) AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		s.ShortDesc AS [Status],
		s.SortPriority AS [Priority],
		a.AssignmentType AS [Assignment Type],
		RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
		m1.CodeDesc as [Type],
		m2.CodeDesc as [Stage],
		m3.CodeDesc as [Next Action],
		c.NextActionDate as [NextAction Date],
		e.EmployeeName as [By Whom]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND c.CollateralStage = @cStageID 

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

UPDATE    QueryMaster
SET              [SQL2] = 'EXEC CWX_Account_SearchByLegalForward %E, %1, %2'
WHERE     (ID = 23)

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 04/21/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalForward]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByLegalForward]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 04/21/2008 17:39:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalForward] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lClientID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
		a.QueueDate AS [QueueDate],
		a.InvoiceNumber as [Account Number],
		a.AccountAge AS [DPD],
		CAST(a.MCode AS CHAR(2)) AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		s.ShortDesc AS [Status],
		s.SortPriority AS [Priority],
		a.AssignmentType AS [Assignment Type],
		RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
		m.CodeDesc as [Next Action],
		l.NextActionDate as [NextAction Date],
		e.EmployeeName as [By Whom]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
    INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction

	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND l.ClientID = @lClientID 
		AND a.EmployeeID = @v_employeeId

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

UPDATE    QueryMaster
SET              [SQL2] = 'EXEC CWX_Account_SearchByLegalEmployee %E, %1, %2'
WHERE     (ID = 24)

UPDATE    QueryParams
SET              PickList = 'select EmployeeID, EmployeeName from Employee where EmployeeStatus = ' + '''' + ' A ' + '''' + ' order by EmployeeName'
WHERE     (QueryID = 24)

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 04/21/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByLegalEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalEmployee]    Script Date: 04/21/2008 17:39:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalEmployee] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
		a.QueueDate AS [QueueDate],
		a.InvoiceNumber as [Account Number],
		a.AccountAge AS [DPD],
		CAST(a.MCode AS CHAR(2)) AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		s.ShortDesc AS [Status],
		s.SortPriority AS [Priority],
		a.AssignmentType AS [Assignment Type],
		RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
		m.CodeDesc as [Next Action],
		l.NextActionDate as [NextAction Date],
		e.EmployeeName as [By Whom]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
    INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction

	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND l.EmployeeID = @v_employeeId

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

UPDATE    QueryMaster
SET              [SQL2] = 'EXEC CWX_Account_SearchByLegalNextAction %E, %1, %2'
WHERE     (ID = 25)


/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalNextAction]    Script Date: 04/21/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalNextAction]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByLegalNextAction]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalNextAction]    Script Date: 04/21/2008 17:39:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalNextAction] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@NextAction int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
		a.QueueDate AS [QueueDate],
		a.InvoiceNumber as [Account Number],
		a.AccountAge AS [DPD],
		CAST(a.MCode AS CHAR(2)) AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		s.ShortDesc AS [Status],
		s.SortPriority AS [Priority],
		a.AssignmentType AS [Assignment Type],
		RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
		m.CodeDesc as [Next Action],
		l.NextActionDate as [NextAction Date],
		e.EmployeeName as [By Whom]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
    INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction

	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND l.NextAction = @NextAction

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByDebtor]    Script Date: 04/21/2008 11:36:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByDebtor]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetListByDebtor]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByDebtor]    Script Date: 04/21/2008 11:36:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetListByDebtor] 
	-- Add the parameters for the stored procedure here
	@DebtorID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  a.AccountID) AS RowNumber,
		a.AccountID,
		a.AccountType,
		a.AccountClass,
		s.ShortDesc,
		c.ClientName,
		a.EmployeeID,
		a.QueueDate,
		a.BillAmount,
		a.BillOtherCharges,
		a.BillBalance,
		a.InvoiceNumber
	INTO #Temp
	FROM Account a
	LEFT JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	LEFT JOIN ClientInformation c ON c.ClientID = a.ClientID
	WHERE
		a.DebtorID = @DebtorID

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_GetListByAccountID]    Script Date: 04/21/2008 11:36:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_GetListByAccountID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CosigneeInformation_GetListByAccountID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_GetListByAccountID]    Script Date: 04/21/2008 11:36:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 18, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_GetListByAccountID] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  (p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + p.LastName)) AS RowNumber,
		(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + p.LastName) AS FullName,
		c.Relationship_no,
		a.Address1,
		a.City,
		a.State,
		a.Zip,
		p.HomePhone,
		p.MobilPhone,
		p.EmploymentPhone
	INTO #Temp
	FROM CosigneeInformation c
	JOIN PersonInformation p ON c.PersonID = p.PersonID
	JOIN PersonAddress a ON a.PersonID = p.PersonID
	WHERE
		a.AddressType = 2
		AND c.Bill = @AccountID

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT *
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_AccountActionOther_Insert]   Script Date: 04/21/2008 15:25:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_AccountActionOther_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_AccountActionOther_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_AccountActionOther_Insert]   Script Date: 04/21/2008 15:25:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_AccountActionOther_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- =============================================
-- Author:		Khoa Duong
-- Create date: Apr 01, 2008
-- Description:	Insert data for account action other table
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_AccountActionOther_Insert]	
	@ActionID int,
	@ActionType int,
	@ActionDate smalldatetime,
	@CompletedBy int,
	@AccountID int	
AS
BEGIN
	SET NOCOUNT ON;	
	INSERT INTO AccountActionsOther VALUES (@ActionID,@ActionType,@ActionDate,@CompletedBy,@AccountID)
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Debtor_HotNote_Update]   Script Date: 04/21/2008 16:10:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Debtor_HotNote_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE  [dbo].[CWX_Debtor_HotNote_Update] 
GO
/****** Object:  StoredProcedure  [dbo].[CWX_Debtor_HotNote_Update]    Script Date: 04/21/2008 16:10:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Debtor_HotNote_Update]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- =============================================
-- Author:		Khoa Duong
-- Create date: Apr 01, 2008
-- Description:	Insert data for account action other table
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Debtor_HotNote_Update]
	@HotNote varchar (255),
	@DebtorID int
AS
BEGIN
	SET NOCOUNT ON;	
	UPDATE DebtorInformation SET HotNote = @HotNote WHERE  DebtorID = @DebtorID
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountActions_Insert]   Script Date: 04/21/2008 16:10:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountActions_Insert] ') AND type in (N'P', N'PC'))
DROP PROCEDURE  [dbo].[CWX_AccountActions_Insert] 
GO
/****** Object:  StoredProcedure  [dbo].[CWX_AccountActions_Insert]    Script Date: 04/21/2008 16:10:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountActions_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- =============================================
-- Author:		Khoa Duong
-- Create date: Apr 01, 2008
-- Description:	Insert data for account action other table
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountActions_Insert]
	@RecordID int,
	@Status  int,
	@ResponsibleParty int,	
	@ActionID int,	
	@CompletedBy int,
	@AccountID int,
	@AdditionalData char(128),
	@BatchNumber varchar(12)
AS
BEGIN

	INSERT INTO AccountActions(RecordID, Status, ResponsibleParty, Deadline, ActionID, DateCompleted, CompletedBy, AccountID, AdditionalData, BatchNumber)
	VALUES (@RecordID, @Status,@ResponsibleParty,getdate(),@ActionID, getdate(), @CompletedBy,@AccountID,@AdditionalData,@BatchNumber)
END
' 
END
GO

