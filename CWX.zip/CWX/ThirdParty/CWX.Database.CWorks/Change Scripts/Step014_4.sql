-- Script is applied on version 2.0.4, 2.0.5 

-- =======================================================================
-- Author:			Tuan Luong
-- Create date:		Jun 26, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_Creditors
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Creditors' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_Creditors
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_Creditors_RowStatus] DEFAULT 'A'
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Creditors_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Tuan Luong
-- Create date: Jun 26, 2008
-- Description:	Delete all records in Legal_Creditors Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_Creditors_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_Creditors
		SET [Status] = ''R''
		WHERE [Status] = ''A''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_Creditors		
	END
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Report_PostLetters]    Script Date: 06/26/2008 20:02:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Report_PostLetters]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Report_PostLetters]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Report_PostLetters]    Script Date: 06/26/2008 20:02:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Report_PostLetters]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Create date: April 09, 2008
-- Description:	Post letter.
-- History:
--		08/04/09	[Binh Truong]	Init version.
--		08/06/26	[Binh Truong]	Specific insert field name.
-- =============================================
CREATE PROCEDURE dbo.CWX_Report_PostLetters 
AS	
	DECLARE @InTrans bit
	SET @InTrans = 0
	
	IF @@TRANCOUNT = 0
	BEGIN
		BEGIN TRANSACTION
		SET @InTrans = 1
	END
		
	INSERT INTO AccountLetter (AccountID, LetterID, LetterStatus, LetterDate, RuleId, EmployeeId, AddressType )
		SELECT AccountID, LetterID, ''S'' as LetterStatus, GETDATE() as LetterDate, RuleId, EmployeeId, AddressType 
		FROM AccountLetterQueue 
		WHERE XmitStatus = ''P''
	
	IF @@ERROR <> 0
		GOTO ProcError
		
	SET NOCOUNT ON
	DELETE FROM AccountLetterQueue
	WHERE XmitStatus = ''P''
	SET NOCOUNT OFF
	
	IF @@ERROR <> 0
		GOTO ProcError
			
	ProcExit:
		IF @InTrans = 1 
		BEGIN
			SET @InTrans = 0
			COMMIT TRANSACTION
		END
	
	ProcError:
		IF @InTrans = 1
		BEGIN
			SET @InTrans = 0
    		ROLLBACK TRANSACTION
		END
	
	' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 06/27/2008 09:29:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByQueueSStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 06/27/2008 09:29:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_SystemStatus int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN Accountother o ON o.AccountID = a.AccountID'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId as varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID <> 2'

	IF @v_SystemStatus = 0 
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'+''
	ELSE
		SET @cStmt=@cStmt+' AND s.SystemStatus = '+CAST(@v_SystemStatus AS char(9))+''


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO

-- 2.0.5 go here

DELETE FROM Interface WHERE InterfaceID = 4
DELETE FROM Interface WHERE InterfaceID = 5

GO

drop table JCIC
drop table JCICItems
drop table AuditTrail
drop table AuditTables
drop table BlackOutDatesPending
drop table CESalary
drop table CESalaryItemDefault
drop table CESalaryItems
drop table Charges
drop table ClientQueue
drop table ClientType
drop table DialerExtension
drop table DialerQueue
drop table DiCol
drop table DiCol_log
drop table EmployeePending
drop table EmployeePermissions
drop table FuncRiskDetailsPending
drop table HoldPersonAddress
drop table HoldPersonInformation
drop table HouseholdReason
drop table LoginAttemptsLog
drop table LoginLog
drop table OA_Inventory
drop table OAAccount
drop table OA_Spindown
drop table OAAccountHistory
drop table OAAccountSnapshot
drop table OAAccountTable
drop table OABatchAccount
drop table OABatchItem
drop table OABatchTable
drop table OACommission
drop table OACommissionTable
drop table OACommRateItem
drop table OACommTemp
drop table OAExcludeEmployee
drop table OAExcludeStatus
drop table OAInformation
drop table OAHistoryTable
drop table OAQueryMaster
drop table OAQueryParams
drop table OARuleCriteria
drop table OARuleTable
drop table OARuleOAAssignment
drop table OAScheduleDate
drop table OAScheduleTable
drop table OATempAccountID
drop table OATempConfirm
drop table OATempEmployeeID
drop table OATempReturn
drop table OATempRounds
drop table OATempSubmit
drop table OAYearMonth
drop table OtherCharges
drop table OtherChargeSummary
drop table Overdue
drop table Permissions
drop table Regular
drop table RepaymentSchedule
drop table Rules
drop table RulesAutoProcDef
drop table RulesAutoProcValue
drop table RulesGridDef
drop table SettlementAccounts
drop table SystemLog
drop table SystemPending
drop table Timezone_Mapping
drop table Trans_Master
drop table TransactionAllocations
drop table XChangeRate
drop table AccountType
drop table DefineFeeLetter
drop table HouseholdCertificate
drop table Locales
drop table OACommRateTable
drop table OAPaymentTable
drop table QueryCallingApp

GO

/****** Object:  StoredProcedure [dbo].[CWX_AdditionalInfo_Get]    Script Date: 06/27/2008 14:49:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AdditionalInfo_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AdditionalInfo_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AdditionalInfo_Get]    Script Date: 06/27/2008 14:49:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AdditionalInfo_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROC [dbo].[CWX_AdditionalInfo_Get]
	@Name varchar(50),
	@AccountID int,
	@PageSize INT = 10,
	@PageIndex INT = 0
AS

DECLARE @ErrMsg varchar(200)
DECLARE @Sql varchar(2000)
DECLARE @TableName nvarchar(50)
DECLARE @ColumnNames nvarchar(400)
DECLARE @IsXSL bit

SELECT @TableName = LOWER(TableName), @ColumnNames = ColumnNames, @IsXSL = XSL
	FROM CWX_AdditionalDataDetails WHERE [Name] = @Name

/* check table name */
DeCLARE @IsExist int
SELECT @IsExist = CHARINDEX(''additional'', @TableName)
IF (@IsExist <> 1)
BEGIN
	SET @ErrMsg = ''The '' + ISNULL(@TableName, '''') + '' table is not valid. The name of the table must start with Additional.''
	GOTO RAISE_ERROR_MESSAGE
END

/* check existing of AccountID column in Table */
IF NOT EXISTS (SELECT ''true'' FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.Name = @TableName AND c.Name = ''AccountId'')
BEGIN
	SET @ErrMsg = ''Invalid AccountID column in '' + ISNULL(@TableName, '''') + '' table.''
	GOTO RAISE_ERROR_MESSAGE
END

/* build sql statement */
IF (@IsXSL = 1)
BEGIN
	SET @ColumnNames = ''*''
END
ELSE
BEGIN
	/* check existing of column names in table */
	DECLARE @Colname varchar(30)
	DECLARE ColNameCursor CURSOR FOR
	SELECT CAST(SplitedText AS varchar(20)) AS ColumnName
			FROM CWX_FnSplitString(@ColumnNames, '','')

	OPEN ColNameCursor
	FETCH NEXT FROM ColNameCursor INTO @ColName
	
	SET @ColumnNames = ''''
	SET @ColName = RTRIM(LTRIM(@ColName))
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF EXISTS (SELECT ''true'' FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.Name = @TableName AND c.Name = @ColName)
		BEGIN
			IF (LEN(@ColumnNames) = 0)
				SET @ColumnNames = @ColName
			ELSE
				SET @ColumnNames = @ColumnNames + '','' + @ColName
		END

		FETCH NEXT FROM ColNameCursor INTO @ColName
		SET @ColName = RTRIM(LTRIM(@ColName))
	END

	CLOSE ColNameCursor
	DEALLOCATE ColNameCursor
END

/* retrieve data that following user settings */
DECLARE @StartRow int, @EndRow int
SET @StartRow = @PageIndex * @PageSize + 1
SET @EndRow = (@PageIndex + 1) * @PageSize

SET @Sql = ''DECLARE @TotalRow int ''
SET @Sql = @Sql + ''SELECT '' + @ColumnNames + '' , ROW_NUMBER() OVER (ORDER BY AccountID) AS RowNumber INTO #RESULT FROM '' + @TableName + '' ''
SET @Sql = @Sql + ''WHERE AccountID='' + STR(@AccountID) + '' ''
SET @Sql = @Sql + ''SET @TotalRow = @@ROWCOUNT ''
SET @Sql = @Sql + ''SELECT '' + @ColumnNames + '' FROM #RESULT WHERE RowNumber BETWEEN '' + STR(@StartRow) + '' AND '' + STR(@EndRow) + '' ''
SET @Sql = @Sql + ''SELECT @TotalRow as [RowCount]''
EXEC(@Sql)
RETURN

RAISE_ERROR_MESSAGE:
	RAISERROR (@ErrMsg, 16, 1)
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_ProductSetting_AddDefaultValues]    Script Date: 06/27/2008 16:24:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_ProductSetting_AddDefaultValues]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_InformationTable_ProductSetting_AddDefaultValues]
GO
/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_ProductSetting_AddDefaultValues]    Script Date: 06/27/2008 16:24:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_ProductSetting_AddDefaultValues]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Khoa Dang
-- =============================================
CREATE PROCEDURE CWX_InformationTable_ProductSetting_AddDefaultValues
	@ProductID int,
	@BucketName varchar(50)
AS
BEGIN
		INSERT INTO InformationTable VALUES(6, @ProductID,  1, @BucketName, ''PercentageToKeepPromise'',			 ''95'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID,  2, @BucketName, ''GracePeriodToPaymentDate'',			  ''3'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID,  3, @BucketName, ''BrokenPromisesCount'',				  ''3'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID,  4, @BucketName, ''HoldDaysCount'',					  ''3'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID,  5, @BucketName, ''MinAcceptCommitmentAmount'',		 ''50'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID,  6, @BucketName, ''MinAcceptCommitmentPercent'',		 ''50'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID,  7, @BucketName, ''MinAcceptOverlimitPercent'',		 ''50'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID,  8, @BucketName, ''NoAnswerCount'',					  ''3'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID,  9, @BucketName, ''NoCommitmentCount'',				  ''3'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID, 10, @BucketName, ''PromiseIntervalDaysCount'',			  ''3'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID, 11, @BucketName, ''MaxAllowableContacts'',				  ''3'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID, 12, @BucketName, ''MaxQueueDateWithPromise'',			 ''10'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID, 13, @BucketName, ''MaxQueueDaysWithoutPromise'',		  ''3'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID, 14, @BucketName, ''DownpaymentPercentForReschedule'',	 ''25'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID, 15, @BucketName, ''DownpaymentPercentForDiscount'',	 ''25'', '''', ''A'')
		INSERT INTO InformationTable VALUES(6, @ProductID, 16, @BucketName, ''MinimumDuePercent'',				''100'', '''', ''A'')
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_ProductSetting_InsertDefaultValues]    Script Date: 06/27/2008 16:24:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_ProductSetting_InsertDefaultValues]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_InformationTable_ProductSetting_InsertDefaultValues]
GO
/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_ProductSetting_InsertDefaultValues]    Script Date: 06/27/2008 16:24:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_ProductSetting_InsertDefaultValues]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_InformationTable_ProductSetting_InsertDefaultValues] 
	-- Add the parameters for the stored procedure here
	@ProductID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @Bucket int
	DECLARE @BucketName varchar(50)

	SET @Bucket = 0
	WHILE @Bucket <= 7
	BEGIN
		IF @Bucket = 7
			SET @BucketName = ''6+''
		ELSE
			SET @BucketName = CAST(@Bucket AS varchar(50))

		exec CWX_InformationTable_ProductSetting_AddDefaultValues @ProductID, @BucketName
		
		IF( @@ERROR <> 0)
			GOTO Cleanup

		SET @Bucket = @Bucket + 1
	END

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
	END

Cleanup:
	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		ROLLBACK TRANSACTION
	END

END


' 
END
GO



IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'AccountActions' and c.name = 'BatchNumber')
	ALTER TABLE AccountActions DROP COLUMN BatchNumber
	
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'AccountPromise' and c.name = 'BatchNumber')
BEGIN
	IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[AccountPromise]') AND name = N'IDX_BatchNumber')
		DROP INDEX [IDX_BatchNumber] ON [dbo].[AccountPromise] WITH ( ONLINE = OFF )
	ALTER TABLE AccountPromise DROP COLUMN BatchNumber
END
	
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Transactions' and c.name = 'BatchNumber')
	ALTER TABLE Transactions DROP COLUMN BatchNumber

GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 06/27/2008 16:59:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXML]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_LoadXML]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 06/27/2008 16:59:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXML]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Load all accounts with debtorID
-- History:
--	08/04/03	[Tai Ly]	Init version.
--	08/06/01	[Long Nguyen]	Add and remove some fields.
--	08/06/27	[Binh Truong]	Remove BatchNumber field.	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int	
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/
	SELECT
			a.AccountID,
			c.COOWNERS,
			ISNULL(l.LetterDesc, '''') AS SENTBY, ISNULL(al.LetterStatus, '''') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			(''Debtor promises to pay '' + CAST(p.AmountPromised AS varchar) + '' for '' + CAST(p.PromiseFrequency AS varchar) + '' '' + ISNULL(p.Term, '''') + '', Next Payment due on '') AS PROMISE, p.DatePromised,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL
	INTO	#AccountTemp
	FROM	Account	 a
	--Count CoSigner for account
	LEFT JOIN (SELECT AccountID, COUNT(CoSignerID) AS COOWNERS FROM CoSigner GROUP BY AccountID) c ON c.AccountID = a.AccountID
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN ''d'' THEN ''day(s)''
						WHEN ''w'' THEN ''week(s)''
						WHEN ''m'' THEN ''month(s)''
						WHEN ''y'' THEN ''year(s)''
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	WHERE DebtorID = @DebtorID

	--If @AdditionalTag = 1 get additional data
	DECLARE @AdditionalTag int
	SELECT @AdditionalTag = FieldValue FROM IdentityFields WHERE TableName = ''AdditionalTag''

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			, #AccountTemp.COOWNERS--, DebtorID as COOWNERS
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE--, InvoiceNumber as SENTBY, '' '' as LETTERSTATUS, QueueDate as LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised--, String1 as PROMISE
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.LASTCONTACTDATE ELSE '''' END AS LASTCONTACTDATE--'' '' as LASTCONTACTDATE
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.LASTCONTACTBY ELSE '''' END AS LASTCONTACTBY--, '' '' as LASTCONTACTBY
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISETOPAY ELSE '''' END AS PROMISETOPAY--, '' '' as PROMISETOPAY
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISEKEPT ELSE '''' END AS PROMISEKEPT--, '' '' as PROMISEKEPT
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISEBROKEN ELSE '''' END AS PROMISEBROKEN--, '' '' as PROMISEBROKEN
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.OUTGOINGCALL ELSE '''' END AS OUTGOINGCALL--, '' '' as OUTGOINGCALL
			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.NOACTIVITYDAYS ELSE '''' END AS NOACTIVITYDAYS--, '' '' as NOACTIVITYDAYS
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END



' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountActions_Get]    Script Date: 06/27/2008 17:04:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountActions_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountActions_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountActions_Insert]    Script Date: 06/27/2008 17:04:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountActions_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountActions_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountActions_OutgoingCall]    Script Date: 06/27/2008 17:04:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountActions_OutgoingCall]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountActions_OutgoingCall]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_PromiseBroken]    Script Date: 06/27/2008 17:04:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_PromiseBroken]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_PromiseBroken]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_PromiseKept]    Script Date: 06/27/2008 17:04:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_PromiseKept]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_PromiseKept]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_PromiseToPay]    Script Date: 06/27/2008 17:04:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_PromiseToPay]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_PromiseToPay]
GO

-- =======================================================================
-- Author:			Tuan Luong
-- Create date:		Jun 27, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_Creditors
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Creditors' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_Creditors
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_Creditors_RowStatus] DEFAULT 'A'
END
GO

-- =======================================================================
-- Author:			Tuan Luong
-- Create date:		Jun 27, 2008
-- Description:		Add column 'ABN'
-- Effected table:	Legal_Creditors
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Creditors' and c.name = 'ABN')
BEGIN
	ALTER TABLE Legal_Creditors
	ADD ABN nvarchar(50) NULL		
END
GO

-- =======================================================================
-- Author:			Tuan Luong
-- Create date:		Jun 27, 2008
-- Description:		Add column 'ACN'
-- Effected table:	Legal_Creditors
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Creditors' and c.name = 'ACN')
BEGIN
	ALTER TABLE Legal_Creditors
	ADD ACN nvarchar(50) NULL		
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Creditors_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Tuan Luong
-- Create date: Jun 23, 2008
-- Description:	Delete all records in Legal_Creditors Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_Creditors_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_Creditors
		SET [Status] = ''R''
		WHERE [Status] = ''A''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_Creditors		
	END
END
' 
END
GO

ALTER TABLE NotesCurrent ALTER COLUMN NoteText varchar(1000)
ALTER TABLE NotesHistory ALTER COLUMN NoteText varchar(1000)
GO

/****** Object:  StoredProcedure [dbo].[CWX_Notes_GetWithType]    Script Date: 06/27/2008 17:21:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Notes_GetWithType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Notes_GetWithType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Notes_GetWithType]    Script Date: 06/27/2008 17:21:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Summary
-- Description:	Get notes from database
-- Tai Ly: May 08, 1008: Init
-- Long Nguyen: June 27, 2008: Update
--		+ Add @SearchHistory to search in NotesHistory
--		+ Remove some redundant code
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Notes_GetWithType] 	
	-- Add the parameters for the stored procedure here
	@DebtorID	int,
	@AccountID	int,
	@NoteText	varchar(1000) = '',
	@NoteType	varchar(1) = ' ',	
	@Month		int = -1,
	@Day		int = -1,
	@FromDate	datetime = '1753-01-01',
	@ToDate		datetime = '9999-12-31',
	@SearchHistory bit = 0,
	@PageSize	int = 10,
	@PageIndex	int = 0
AS
BEGIN
	Declare @IdentityTableValue int

	DECLARE @TempTableVar table(
		RowNumber		int,
		NoteDateTime	datetime,
		NoteText		varchar(1000),
		NoteType		varchar(1),
		UserID			varchar(10)
	);

	IF @Month >= 0
		SET @FromDate = DATEADD(month, -1*@Month, GETDATE())
	ELSE IF @Day >= 0
		SET @FromDate = DATEADD(day, -1*@Day, GETDATE())

	SELECT @IdentityTableValue = ISNULL(FieldValue, -1) FROM IdentityFields WHERE TableName = 'NotesDisplayByAccount'

	IF (@IdentityTableValue < 0)
			INSERT INTO IdentityFields VALUES('NotesDisplayByAccount',0)

	SELECT @NoteText = '%' + @NoteText + '%';

	IF @SearchHistory = 0
		INSERT INTO @TempTableVar
		SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID
		FROM		NotesCurrent n, Employee e
		WHERE		((@IdentityTableValue <= 0 AND n.DebtorID = @DebtorID) OR n.BillID = @AccountID)
					AND n.EmployeeID *= e.EmployeeID 
					AND (@NoteType = ' ' OR UPPER(NoteType) = UPPER(@NoteType))
					AND n.NoteText LIKE @NoteText
					AND n.NoteDateTime BETWEEN @FromDate AND @ToDate
	ELSE
		INSERT INTO @TempTableVar
		SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID
		FROM		NotesHistory n, Employee e
		WHERE		((@IdentityTableValue <= 0 AND n.DebtorID = @DebtorID) OR n.BillID = @AccountID)
					AND n.EmployeeID *= e.EmployeeID 
					AND (@NoteType = ' ' OR UPPER(NoteType) = UPPER(@NoteType))
					AND n.NoteText LIKE @NoteText
					AND n.NoteDateTime BETWEEN @FromDate AND @ToDate

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
	ELSE
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
		WHERE	RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize)		

	RETURN @RowCount

END
GO

/******  Script Closed. Go next: Step015_1  ******/