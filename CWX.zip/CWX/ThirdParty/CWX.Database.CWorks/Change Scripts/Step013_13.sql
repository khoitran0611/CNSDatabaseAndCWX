-- Script is applied on version 1.9.22

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Courts_DeleteAll]    Script Date: 06/23/2008 10:37:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Courts_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Courts_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Courts_DeleteAll]    Script Date: 06/23/2008 10:37:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Courts_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Tuan Luong
-- Create date: Jun 23, 2008
-- Description:	Delete all records in Legal_Courts Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_Courts_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_CommPoints
		SET [Status] = ''R''
		WHERE [Status] = ''A''
		
		UPDATE Legal_CommPointAddresses
		SET [Status] = ''R''
		WHERE [Status] = ''A''
	
		UPDATE Legal_Courts
		SET [Status] = ''R''
		WHERE [Status] = ''A''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_CommPoints
		
		DELETE Legal_CommPointAddresses
		
		DELETE Legal_Courts		
	END
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_ResultProcessingRule_Get]    Script Date: 06/23/2008 11:18:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ResultProcessingRule_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ResultProcessingRule_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ResultProcessingRule_Get]    Script Date: 06/23/2008 11:18:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ResultProcessingRule_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get ResultProcessRule by rule type and rule value.
-- Parameters:
--		@RuleType: Rule type. Ex: STATUS or ACTION.
--		@RuleValue: Value for get specific Processing Rule to apply.
-- History:
--		2008/06/23	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ResultProcessingRule_Get]
(
	@RuleType varchar(20),
	@RuleValue varchar(100)
)
AS
BEGIN
	SELECT	
			RuleTable.*, RuleCriteria.*, Emp1.EmployeeName as ReferalName, Emp2.EmployeeName as CollectorName 
	FROM	RuleTable LEFT JOIN Employee Emp1 
				ON RuleTable.ReferUser=Emp1.EmployeeID 
			LEFT JOIN Employee Emp2
				ON RuleTable.Collector = Emp2.EmployeeID 
			INNER JOIN RuleCriteria 
				ON RuleTable.ID = RuleCriteria.RuleID 
	WHERE	
			RuleTable.RuleType = 3 AND RuleCriteria.Criteria = @RuleType AND RuleCriteria.MatchingCriteria = @RuleValue
END' 
END
GO

/******  Script Closed. Go next: Step013_14  ******/