﻿-- Script is applied on version 3.5.3:

-- Start of Scripts 3.5.3:

/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineGroupId]    Script Date: 01/30/2009 18:05:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineGroupId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineGroupId]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_Validation]    Script Date: 01/30/2009 18:05:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_Validation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_Validation]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_GetGroupStepDetails]    Script Date: 01/30/2009 18:05:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_GetGroupStepDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_GetGroupStepDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_GetLastGroupStepDetails]    Script Date: 01/30/2009 18:05:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_GetLastGroupStepDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_GetLastGroupStepDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_UpdateGroupStepAmount]    Script Date: 01/30/2009 18:05:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_UpdateGroupStepAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_UpdateGroupStepAmount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineAdditionalFieldValues]    Script Date: 01/30/2009 18:05:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineAdditionalFieldValues]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineAdditionalFieldValues]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateAttemptedServiceFee]    Script Date: 01/30/2009 18:05:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateAttemptedServiceFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateAttemptedServiceFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineAgentId]    Script Date: 01/30/2009 18:05:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineAgentId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineAgentId]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateTravelFee]    Script Date: 01/30/2009 18:05:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateTravelFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateTravelFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateSolicitorFee]    Script Date: 01/30/2009 18:05:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateSolicitorFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateSolicitorFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateServiceFee]    Script Date: 01/30/2009 18:05:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateServiceFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateServiceFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateSearchFee]    Script Date: 01/30/2009 18:05:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateSearchFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateSearchFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateLeviFee]    Script Date: 01/30/2009 18:05:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateLeviFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateLeviFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom5Fee]    Script Date: 01/30/2009 18:05:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom5Fee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateCustom5Fee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom4Fee]    Script Date: 01/30/2009 18:05:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom4Fee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateCustom4Fee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom3Fee]    Script Date: 01/30/2009 18:05:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom3Fee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateCustom3Fee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom2Fee]    Script Date: 01/30/2009 18:05:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom2Fee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateCustom2Fee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom1Fee]    Script Date: 01/30/2009 18:05:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom1Fee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateCustom1Fee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCourtFee]    Script Date: 01/30/2009 18:05:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCourtFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateCourtFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateBookkeepingFee]    Script Date: 01/30/2009 18:05:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateBookkeepingFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateBookkeepingFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalSummonServed_Add]    Script Date: 01/30/2009 18:05:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalSummonServed_Add]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_LegalSummonServed_Add]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefinePaymentAllocationRule]    Script Date: 01/30/2009 18:05:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefinePaymentAllocationRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefinePaymentAllocationRule]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineCaseNumber]    Script Date: 01/30/2009 18:05:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineCaseNumber]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineCaseNumber]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineSolicitorId]    Script Date: 01/30/2009 18:05:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineSolicitorId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineSolicitorId]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateInterestAmount]    Script Date: 01/30/2009 18:05:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateInterestAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateInterestAmount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineStateServiced]    Script Date: 01/30/2009 18:05:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineStateServiced]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineStateServiced]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineGroupCode]    Script Date: 01/30/2009 18:05:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineGroupCode]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineGroupCode]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineCreditorId]    Script Date: 01/30/2009 18:05:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineCreditorId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineCreditorId]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalDefendantList_Get]    Script Date: 01/30/2009 18:05:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalDefendantList_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_LegalDefendantList_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineCourtId]    Script Date: 01/30/2009 18:05:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineCourtId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineCourtId]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateDebtAmount]    Script Date: 01/30/2009 18:05:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateDebtAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateDebtAmount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_ChangeAccountCollector]    Script Date: 01/30/2009 18:05:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_ChangeAccountCollector]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_ChangeAccountCollector]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalDefendant_Get]    Script Date: 01/30/2009 18:05:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalDefendant_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_LegalDefendant_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineAgentId]    Script Date: 01/30/2009 18:05:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineAgentId]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineAgentId]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @AgentID INT
	
	SET @AgentID = 0;
	
	SELECT ISNULL(@AgentID, 0) AS ''AgentID''
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalSummonServed_Add]    Script Date: 01/30/2009 18:05:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalSummonServed_Add]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_LegalSummonServed_Add]
	@GroupDebtorID INT, @IsServed BIT, @ServedDate DATETIME, @ServedBy VARCHAR(100), @Attempts INT
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO WF_Legal_ServedSummons (GroupDebtorID, IsServed, Attempts, ServedDate, ServedBy)
	VALUES (@GroupDebtorID, @IsServed, @Attempts, @ServedDate, @ServedBy);

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefinePaymentAllocationRule]    Script Date: 01/30/2009 18:05:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefinePaymentAllocationRule]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefinePaymentAllocationRule]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    SELECT 2 AS ''Payment Allocation ID''
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineCaseNumber]    Script Date: 01/30/2009 18:05:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineCaseNumber]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineCaseNumber]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    SELECT ''CASE1'' AS ''Case Number''
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineAdditionalFieldValues]    Script Date: 01/30/2009 18:05:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineAdditionalFieldValues]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineAdditionalFieldValues]
	@AccountID INT,
	@GroupStepTypeID INT, 
	@ActivityID INT,
	@ActivityTypeID INT
AS
BEGIN
	SET NOCOUNT ON;

		
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineSolicitorId]    Script Date: 01/30/2009 18:05:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineSolicitorId]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineSolicitorId]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @SolicitorID INT
	
	SELECT @SolicitorID = ISNULL(Long1, 0)
	FROM AccountOther 
	WHERE AccountID = @AccountID
	
	SELECT ISNULL(@SolicitorID, 0) AS ''SolicitorID''
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_GetGroupStepDetails]    Script Date: 01/30/2009 18:05:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_GetGroupStepDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_GetGroupStepDetails]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;

    SELECT A.* 
	FROM Legal_GroupSteps A
	INNER JOIN  Legal_Groups B 
		ON A.GroupID = B.GroupID AND B.GroupedAccountID = @AccountID AND B.Status = ''A''
	WHERE GroupStepTypeID = @GroupStepTypeID AND A.Status = ''A''

END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_GetLastGroupStepDetails]    Script Date: 01/30/2009 18:05:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_GetLastGroupStepDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_GetLastGroupStepDetails]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    SELECT TOP 1 A.* 
	FROM Legal_GroupSteps A
	INNER JOIN  Legal_Groups B 
		ON A.GroupID = B.GroupID AND B.GroupedAccountID = @AccountID AND B.Status = ''A''
	WHERE A.Status = ''A''
	ORDER BY A.CreateDate DESC

END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateTravelFee]    Script Date: 01/30/2009 18:05:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateTravelFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateTravelFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateSolicitorFee]    Script Date: 01/30/2009 18:05:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateSolicitorFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateSolicitorFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateServiceFee]    Script Date: 01/30/2009 18:05:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateServiceFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateServiceFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateSearchFee]    Script Date: 01/30/2009 18:05:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateSearchFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateSearchFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateLeviFee]    Script Date: 01/30/2009 18:05:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateLeviFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateLeviFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom5Fee]    Script Date: 01/30/2009 18:05:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom5Fee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateCustom5Fee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom4Fee]    Script Date: 01/30/2009 18:05:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom4Fee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateCustom4Fee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom3Fee]    Script Date: 01/30/2009 18:05:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom3Fee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateCustom3Fee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom2Fee]    Script Date: 01/30/2009 18:05:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom2Fee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateCustom2Fee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom1Fee]    Script Date: 01/30/2009 18:05:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom1Fee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateCustom1Fee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCourtFee]    Script Date: 01/30/2009 18:05:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCourtFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateCourtFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateBookkeepingFee]    Script Date: 01/30/2009 18:05:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateBookkeepingFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateBookkeepingFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateAttemptedServiceFee]    Script Date: 01/30/2009 18:05:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateAttemptedServiceFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateAttemptedServiceFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

			SELECT @Fee = 100			

		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Fee = 100			

		END
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Fee = 100			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Fee = 100			

		END
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineGroupId]    Script Date: 01/30/2009 18:05:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineGroupId]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineGroupId]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @GroupID INT
	
	SELECT @GroupID = ISNULL(A.GroupID, 0)
	FROM Legal_Groups A 
	WHERE A.GroupedAccountID = @AccountID
	
	SELECT ISNULL(@GroupID, 0) AS ''GroupID''
END


' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_UpdateGroupStepAmount]    Script Date: 01/30/2009 18:05:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_UpdateGroupStepAmount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_UpdateGroupStepAmount]
	@GroupStepID INT,
	@TransactionTypeID INT,
	@Amount MONEY
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Transaction Type Code
	*************************/
	DECLARE @TransactionCode VARCHAR(25);
	SELECT @TransactionCode = TransactionCode 
	FROM TransactionType
	WHERE [ID] = @TransactionTypeID;
	
	/*************************
	Create UPDATE script base on transaction type code
	*************************/
	DECLARE @Script VARCHAR(500);
	
	SET @Script = ''UPDATE Legal_GroupSteps SET '' 
	SET @Script = @Script + 
		CASE @TransactionCode 
			WHEN ''Debt'' THEN ''[DebtAmount] = ISNULL([DebtAmount],0) + ''
			WHEN ''Intr'' THEN ''[IntAmount] = ISNULL([IntAmount],0) + '' 
			WHEN ''SolF'' THEN ''[SolicitorFee] = ISNULL([SolicitorFee],0) + '' 
			WHEN ''CourtF'' THEN ''[CourtFee] = ISNULL([CourtFee],0) + '' 
			WHEN ''SrvF'' THEN ''[ServiceFee] = ISNULL([ServiceFee],0) + '' 
			WHEN ''ASrvF'' THEN ''[AttemptedFee] = ISNULL([AttemptedFee],0) + '' 
			WHEN ''KmF'' THEN ''[TravelFee] = ISNULL([TravelFee],0) + '' 
			WHEN ''JrnlF'' THEN ''[BookkeepingFee] = ISNULL([BookkeepingFee],0) + '' 
			WHEN ''AcctF'' THEN ''[LevyFee] = ISNULL([LevyFee],0) + '' 
			WHEN ''SrchF'' THEN ''[SearchFee] = ISNULL([SearchFee],0) + '' 
			WHEN ''OthF'' THEN ''[CustomFee1] = ISNULL([CustomFee1],0) + '' 
		END
	SET @Script = @Script + CAST(@Amount AS VARCHAR(32)); 
	SET @Script = @Script + '', [StepTotal] = ISNULL([StepTotal],0) + '' + CAST(@Amount AS VARCHAR(32));
	SET @Script = @Script + '', LastEditDate = GETDATE()'';
	SET @Script = @Script + '' WHERE GroupStepID = '' + CAST(@GroupStepID AS VARCHAR(10));
	
	IF @TransactionCode IN (''Debt'', ''Intr'', ''SolF'', ''CourtF'', ''ASrvF'', ''SrvF'', ''SrchF'', ''JrnlF'', ''AcctF'', ''KmF'', ''OthF'')
		EXEC (@Script);
	
	
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_Validation]    Script Date: 01/30/2009 18:05:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_Validation]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_Validation]
	@AccountID BIGINT,
	@ValidationType INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @IsValid BIT;
	SET @IsValid = 0;
	
	IF @ValidationType = 1
		BEGIN
			/**** 
			Description: Validates Issued Date of SUMISS process.
			Requirements:	
				1. Group step type = ''SUMISS''
				2. Custom field type code = ''IssD''
				3. Custom field value must have date
			*****/	
			SELECT @IsValid = CASE WHEN ISNULL(D.Value,'''') = '''' THEN 0 ELSE 1 END    
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B
				ON A.GroupID = B.GroupID
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''SUMISS''
			INNER JOIN Legal_CustomFields D
				ON B.GroupStepID = D.ActivityID
			INNER JOIN Legal_CustomFieldTypes E
				ON D.CustomFieldTypeID = E.CustomFieldTypeID AND E.Code = ''IssD''
			WHERE A.GroupedAccountID = @AccountID

		END

	ELSE IF @ValidationType = 2
		BEGIN
			/**** 
			Description: Validates if Case Number is present.
			Requirements:	
				1. Step activity with Case Number
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) < 1 THEN 0 ELSE 1 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B
				ON A.GroupID = B.GroupID
			WHERE A.GroupedAccountID = @AccountID AND ISNULL(B.CaseNumber, '''') <> ''''
			
		END
	
	ELSE IF @ValidationType = 3
		BEGIN
			/**** 
			Description: Validates JUDAPP timeframe expiration.
			Requirements:	
				1. Group step type = ''SUMISS''
				2. Custom field type code = ''IssD''
				3. Current time - custom field value (IssD) must > 21
			*****/
			SELECT @IsValid = 
				CASE WHEN
					CASE WHEN ISDATE(D.Value) = 1 
						THEN DATEDIFF(d, CONVERT(datetime, D.Value, 1), GETDATE())
						ELSE 0
					END > 21	
					THEN 1
					ELSE 0
				END
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B
				ON A.GroupID = B.GroupID
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''SUMISS''
			INNER JOIN Legal_CustomFields D
				ON B.GroupStepID = D.ActivityID
			INNER JOIN Legal_CustomFieldTypes E
				ON D.CustomFieldTypeID = E.CustomFieldTypeID AND E.Code = ''IssD''
			WHERE A.GroupedAccountID = @AccountID
			
		END

	ELSE IF @ValidationType = 4
		BEGIN
			/**** 
			Description: Validates SUMSRV for defended DEFSUM event.
			Requirements:	
				1. Hearing type code = ''DEFSUM''
				2. Group step type = ''SUMSRV''
				3. Custom field value (DefS) = ''1''
				4. Custom field type code = ''DefS''
				5. Must not have successful defense event
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) > 0 THEN 0 ELSE 1 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B
				ON A.GroupID = B.GroupID
			INNER JOIN Legal_Hearings F
				ON B.GroupStepID = F.GroupStepID 
			INNER JOIN Legal_HearingTypes G
				ON F.HearingTypeID = G.HearingTypeID AND G.Code = ''DEFSUM''
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''SUMSRV''
			INNER JOIN Legal_CustomFields D
				ON F.HearingID = D.ActivityID AND D.Value = ''1''
			INNER JOIN Legal_CustomFieldTypes E
				ON D.CustomFieldTypeID = E.CustomFieldTypeID AND E.Code = ''DefS''
			WHERE A.GroupedAccountID = @AccountID
			
		END

	ELSE IF @ValidationType = 5
		BEGIN
			/**** 
			Description: Validates account''s bill balance.
			Requirements:	
				1. Account''s bill balance > 0
			*****/
			SELECT @IsValid = CASE WHEN ISNULL(A.BillBalance, 0) > 0 THEN 1 ELSE 0 END  
			FROM Account A
			WHERE A.AccountID = @AccountID
			
		END

	ELSE IF @ValidationType = 6
		BEGIN
			/**** 
			Description: Validates account''s maximum bill balance base on state.
			Requirements:	
				1. If from state of VIC, account''s bill balance < $100000 or,
				2. If from state of NSW, account''s bill balance < $40000 or,	
				3. If from state of QLD, account''s bill balance < $60000
			*****/
			SELECT @IsValid =  
				CASE 
					WHEN A.Formula_Flag = ''VIC'' AND A.BillBalance < 100000 THEN 1 
					WHEN A.Formula_Flag = ''NSW'' AND A.BillBalance < 40000 THEN 1
					WHEN A.Formula_Flag = ''QLD'' AND A.BillBalance < 60000 THEN 1
					ELSE 0 
				END
			FROM Account A
			WHERE A.AccountID = @AccountID
			
		END

	ELSE IF @ValidationType = 7
		BEGIN
			/**** 
			Description: Validates account if Summons Serviced step exsit.
			Requirements:	
				1. Must have SUMSRV group step type
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) > 0 THEN 1 ELSE 0 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B
				ON A.GroupID = B.GroupID
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''SUMSRV''
			WHERE A.GroupedAccountID = @AccountID
			
		END

	SELECT @IsValid AS ''IsValid''
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateInterestAmount]    Script Date: 01/30/2009 18:05:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateInterestAmount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateInterestAmount]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;

	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;

    DECLARE @Interest REAL;
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			SELECT @Interest = 
				(ISNULL(InterestRate, 0) / 100) * ISNULL(BillBalance, 0) * (CAST(DATEDIFF(DAY, O.Date18, O.Date19) AS DECIMAL)/ CAST(365 as decimal)) -- Start and End Date of Interest
			FROM Account A INNER JOIN AccountOther O ON A.AccountID = O.AccountID AND
				A.AccountID = @AccountID
		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @Interest = 0			

		END
	
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @Interest = 0			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @Interest = 0			

		END
	
	
	SELECT ISNULL(@Interest, 0) AS ''Interest''
END' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineStateServiced]    Script Date: 01/30/2009 18:05:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineStateServiced]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineStateServiced]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @StateServiced VARCHAR(100)
	
	SELECT @StateServiced = ISNULL(Formula_Flag, '''')
	FROM Account 
	WHERE AccountID = @AccountID
	
	SELECT ISNULL(@StateServiced, '''') AS ''StateServiced''
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineGroupCode]    Script Date: 01/30/2009 18:05:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineGroupCode]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineGroupCode]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @GroupCode VARCHAR(100)
	DECLARE @Sequence INT
	SET @Sequence = 1
	
	DECLARE @CustomerNumber VARCHAR(100)
	SELECT @CustomerNumber = ISNULL(P.PString1, '''')
	FROM Account A INNER JOIN DebtorInformation D ON A.DebtorID = D.DebtorID AND A.AccountID = @AccountID
		INNER JOIN PersonInformation P ON D.PersonID = P.PersonID
	
	IF EXISTS(SELECT 1 FROM Legal_Groups 
		WHERE Code LIKE ''G-'' + @CustomerNumber + ''-%'')
	BEGIN
		SELECT TOP 1 @Sequence = CONVERT(INT, SUBSTRING(Code, CHARINDEX(''-'', Code, 3) + 1, LEN(Code))) + 1
		FROM Legal_Groups 
		WHERE Code LIKE ''G-'' + @CustomerNumber + ''-%''
		ORDER BY CODE DESC
	END
	

	SELECT @GroupCode = ''G-'' + @CustomerNumber + ''-''+ 
		CASE WHEN @Sequence < 10 THEN ''0'' ELSE '''' END + CONVERT(VARCHAR, @Sequence)
	
	SELECT ISNULL(@GroupCode, '''') AS GroupCode
	
    /*
	DECLARE @GroupCode VARCHAR(100)

	SELECT @GroupCode = ''G-'' + ISNULL(P.PString1, '''') + ''-''+ CONVERT(VARCHAR, YEAR(GETDATE()))
	FROM Account A INNER JOIN DebtorInformation D ON A.DebtorID = D.DebtorID AND A.AccountID = @AccountID
		INNER JOIN PersonInformation P ON D.PersonID = P.PersonID
	
	SELECT ISNULL(@GroupCode, '''') AS GroupCode
	*/
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateDebtAmount]    Script Date: 01/30/2009 18:05:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateDebtAmount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateDebtAmount]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;

	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;

    DECLARE @DebtAmount MONEY;
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			SELECT @DebtAmount = SUM(ISNULL(A.BillBalance, 0))
			FROM Account A WHERE AccountID = @AccountID
		END
	
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN

			SELECT @DebtAmount = 0			

		END
	
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN

			SELECT @DebtAmount = 0			

		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN

			SELECT @DebtAmount = 0			

		END
	
	
	SELECT ISNULL(@DebtAmount, 0) AS ''DebtAmount''

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_ChangeAccountCollector]    Script Date: 01/30/2009 18:05:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_ChangeAccountCollector]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_ChangeAccountCollector]
	@AccountID INT,
	@EmployeeID INT
AS
BEGIN
	SET NOCOUNT ON;

    UPDATE Account 
	SET EmployeeID = @EmployeeID
	WHERE AccountID = @AccountID
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalDefendant_Get]    Script Date: 01/30/2009 18:05:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalDefendant_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_LegalDefendant_Get]
	@GroupDebtorID INT
AS
BEGIN
	SET NOCOUNT ON;

    SELECT A.GroupDebtorID, A.GroupID, A.DebtorID, A.AccountID, A.IsPrincipal, A.PersonID, A.DefendantNum, 
			B.FirstName + '' '' + B.LastName [Name], 
			C.InvoiceNumber, D.IsServed, D.Attempts, D.ServedDate, D.ServedBy
	FROM Legal_GroupDebtors A
	INNER JOIN PersonInformation B ON A.PersonID = B.PersonID
	INNER JOIN Account C ON A.AccountID = C.AccountID 
	LEFT JOIN WF_Legal_ServedSummons D ON A.GroupDebtorID = D.GroupDebtorID
	WHERE A.GroupDebtorID = @GroupDebtorID
	ORDER BY DefendantNum

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalDefendantList_Get]    Script Date: 01/30/2009 18:05:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalDefendantList_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_LegalDefendantList_Get]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @GroupID INT;
	
	-- get legal group id using group account id
	SELECT @GroupID = ISNULL(A.GroupID, 0)
	FROM Legal_Groups A 
	WHERE A.GroupedAccountID = @AccountID
	
	-- get defendant list using group id
    SELECT A.GroupDebtorID, A.GroupID, A.DebtorID, A.AccountID, A.IsPrincipal, A.PersonID, A.DefendantNum, 
			B.FirstName + '' '' + B.LastName [Name], 
			C.InvoiceNumber, D.IsServed, D.Attempts, D.ServedDate, D.ServedBy
	FROM Legal_GroupDebtors A
	INNER JOIN PersonInformation B ON A.PersonID = B.PersonID
	INNER JOIN Account C ON C.AccountID = @AccountID
	LEFT JOIN WF_Legal_ServedSummons D ON A.GroupDebtorID = D.GroupDebtorID
	WHERE A.IsDefendant = 1 AND A.GroupID = @GroupID AND ISNULL(D.IsServed,0) = 0 AND ISNULL(A.DebtorID, 0) > 0
	ORDER BY DefendantNum

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineCreditorId]    Script Date: 01/30/2009 18:05:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineCreditorId]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineCreditorId]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @CreditorID INT
	
	SELECT @CreditorID = ISNULL(C.CreditorID, 0)
	FROM Account A INNER JOIN ClientInformation C ON A.ClientID = C.ClientID AND
		A.AccountID = @AccountID
	
	SELECT ISNULL(@CreditorID, 0) AS ''CreditorID''
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineCourtId]    Script Date: 01/30/2009 18:05:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineCourtId]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineCourtId]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @CourtID INT
	
	SELECT TOP 1 @CourtID = ISNULL(C.CourtID, 0)
	FROM Account A LEFT OUTER JOIN Legal_Courts C ON A.AccountID = @AccountID AND
		ISNULL(A.Formula_Flag, '''') <> '''' AND
		ISNULL(A.Formula_Flag, '''') BETWEEN ISNULL(C.PostcodeStart, '''') AND ISNULL(C.PostcodeEnd, '''')
	ORDER BY C.CourtID ASC
	
	SELECT ISNULL(@CourtID, 0) AS ''CourtID''
END
' 
END
GO
