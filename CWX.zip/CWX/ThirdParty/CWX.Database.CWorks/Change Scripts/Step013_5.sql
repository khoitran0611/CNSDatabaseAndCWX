-- Scripts are applied on version 1.9.6
  
 /****** Object:  StoredProcedure [dbo].[CWX_Employee_Search]    Script Date: 06/11/2008 10:44:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_Search]    Script Date: 06/11/2008 10:44:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Dec 15, 2007
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_Search]
	@EmployeeID int = 0,
	@EmployeeName varchar(50) = '',
	@Department int = 0,
	@RoleID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--This only used in MainPage (Refer to), if employee is supervisor -> only select supervisor
	DECLARE @Supervisor bit
	IF @EmployeeID > 0
		SELECT	@Supervisor = Supervisor	
		FROM	Employee
		WHERE	EmployeeID = @EmployeeID

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(e.EmployeeID)
	FROM Employee e
	LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID AND (d.Status <> 'R')
	WHERE
		(e.EmployeeName LIKE ('%' + @EmployeeName + '%'))
		AND (@Department = 0 OR e.Department = @Department)
		AND (@RoleID = 0 OR e.RoleID = @RoleID)
		AND (ISNULL(EmployeeStatus, '') <> 'R')
		AND (ISNULL(@Supervisor, 1) = 1 OR e.Supervisor = 1)

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber,
			e.EmployeeID,
			e.UserID,
			e.EmployeeName,
			ISNULL(d.DeptDesc, '') AS Department,
			e.RoleID,
			e.Description,
			CASE e.Supervisor WHEN 1 THEN 'Y' ELSE '' END AS Supervisor
		FROM Employee e
		LEFT JOIN EmployeeDepartment d ON e.Department = d.DeptID AND (d.Status <> 'R')
		WHERE
			(e.EmployeeName LIKE ('%' + @EmployeeName + '%'))
			AND (@Department = 0 OR e.Department = @Department)
			AND (@RoleID = 0 OR e.RoleID = @RoleID)
			AND (ISNULL(EmployeeStatus, '') <> 'R')
			AND (ISNULL(@Supervisor, 1) = 1 OR e.Supervisor = 1)
	)

	SELECT *
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex
	
	RETURN @RowCount
END
GO


-- =============================================
-- Description:	Create Legal tables
-- History:
--		2008/05/23	[Admerex]	Init version.
-- =============================================

/****** Object:  Table [dbo].[Legal_CommPointAddresses]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_CommPointAddresses](
	[CommPointAddressID] [int] IDENTITY(1,1) NOT NULL,
	[Line1] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Line2] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Line3] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LocalityID] [int] NOT NULL,
	[DPID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Barcode] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_CommPointAddresses_LastEditDate]  DEFAULT (getdate()),
	[Suspended] [bit] NOT NULL CONSTRAINT [DF_Legal_CommPointAddresses_Suspended]  DEFAULT ((0)),
 CONSTRAINT [PK_Legal_CommPointAddresses] PRIMARY KEY CLUSTERED 
(
	[CommPointAddressID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_CommPoints]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_CommPoints](
	[CommPointID] [int] IDENTITY(1,1) NOT NULL,
	[PostalAddressID] [int] NULL,
	[LegalAddressID] [int] NULL,
	[StreetAddressID] [int] NULL,
	[OtherAddressID] [int] NULL,
	[PhoneBH] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[PhoneAH] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[PhoneMobile] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Fax] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[PhoneOther] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[EmailBH] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[EmailAH] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[EmailOther] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DX] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_CommPoints_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_CommPoints] PRIMARY KEY CLUSTERED 
(
	[CommPointID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_Courts]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_Courts](
	[CourtID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[CourtCommPointID] [int] NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_Courts_LastEditDate]  DEFAULT (getdate()),
	[StartingCaseNo] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[EndingCaseNo] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
 CONSTRAINT [PK_Legal_Courts] PRIMARY KEY CLUSTERED 
(
	[CourtID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_Creditors]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_Creditors](
	[CreditorID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Legal_Creditors_DateCreated]  DEFAULT (getdate()),
	[DateArchived] [datetime] NULL,
	[Notes] [nvarchar](4000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_Creditors_LastEditDate]  DEFAULT (getdate()),
	[DateClosed] [datetime] NULL,
	[ArchiveReference] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CommonName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LegalName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[BusinessName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ParentCreditorID] [int] NULL,
	[CreditorCommPointID] [int] NOT NULL,
	[CreditorTypeID] [int] NULL,
 CONSTRAINT [PK_Legal_Creditors] PRIMARY KEY CLUSTERED 
(
	[CreditorID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_CustomFields]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_CustomFields](
	[CustomFieldID] [int] IDENTITY(1,1) NOT NULL,
	[CustomFieldTypeID] [int] NOT NULL,
	[AccountID] [int] NOT NULL,
	[Value] [nvarchar](1000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_CustomFields_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_CustomFields] PRIMARY KEY CLUSTERED 
(
	[CustomFieldID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_CustomFieldTypes]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_CustomFieldTypes](
	[CustomFieldTypeID] [int] IDENTITY(1,1) NOT NULL,
	[ClientID] [int] NOT NULL,
	[Code] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Type] [nvarchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Length] [int] NOT NULL,
	[Seq] [int] NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_CustomFieldTypes_LastEditDate]  DEFAULT (getdate()),
	[CustomListID] [int] NULL,
 CONSTRAINT [PK_Legal_CustomFieldTypes] PRIMARY KEY CLUSTERED 
(
	[CustomFieldTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_CustomLists]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_CustomLists](
	[CustomListID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](1000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_CustomLists_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_CustomLists] PRIMARY KEY CLUSTERED 
(
	[CustomListID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_CustomListValues]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_CustomListValues](
	[CustomListValueID] [int] IDENTITY(1,1) NOT NULL,
	[CustomListID] [int] NOT NULL,
	[Name] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](1000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Seq] [int] NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_CustomListValues_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_CustomListValues] PRIMARY KEY CLUSTERED 
(
	[CustomListValueID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_DebtCauses]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_DebtCauses](
	[DebtCauseID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_DebtCauses_LastEditDate]  DEFAULT (getdate()),
	[DebtCauseGroupID] [int] NULL,
	[VicEdiCodeID] [int] NULL,
	[NswEdiCodeID] [int] NULL,
 CONSTRAINT [PK_Legal_DebtCauses] PRIMARY KEY CLUSTERED 
(
	[DebtCauseID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_GroupDebtors]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_GroupDebtors](
	[GroupDebtorID] [int] IDENTITY(1,1) NOT NULL,
	[GroupID] [int] NOT NULL,
	[DebtorID] [int] NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_GroupDebtors_LastEditDate]  DEFAULT (getdate()),
	[RelationshipTypeID] [int] NULL,
	[Liability] [money] NULL,
 CONSTRAINT [PK_Legal_GroupDebtors] PRIMARY KEY CLUSTERED 
(
	[GroupDebtorID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_GroupDebts]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_GroupDebts](
	[GroupDebtID] [int] IDENTITY(1,1) NOT NULL,
	[GroupID] [int] NOT NULL,
	[AccountID] [int] NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_GroupDebts_LastEditDate]  DEFAULT (getdate()),
	[PaymentAllocationRuleID] [int] NULL,
 CONSTRAINT [PK_Legal_GroupDebts] PRIMARY KEY CLUSTERED 
(
	[GroupDebtID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_GroupSteps]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_GroupSteps](
	[GroupStepID] [int] IDENTITY(1,1) NOT NULL,
	[GroupID] [int] NOT NULL,
	[GroupStepTypeID] [int] NULL,
	[DateCommenced] [datetime] NULL,
	[DateFiled] [datetime] NULL,
	[DateIssued] [datetime] NULL,
	[DebtAmount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_DebtAmount]  DEFAULT ((0)),
	[IntAmount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_IntAmount]  DEFAULT ((0)),
	[SolAmount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_SolAmount]  DEFAULT ((0)),
	[CrtAmount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_CrtAmount]  DEFAULT ((0)),
	[SerAmount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_SerAmount]  DEFAULT ((0)),
	[AtsAmount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_AtsAmount]  DEFAULT ((0)),
	[TrvAmount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_TrvAmount]  DEFAULT ((0)),
	[BkpAmount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_BkpAmount]  DEFAULT ((0)),
	[LvyAmount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_LvyAmount]  DEFAULT ((0)),
	[SchAmount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_SchAmount]  DEFAULT ((0)),
	[C1Amount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_C1Amount]  DEFAULT ((0)),
	[C2Amount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_C2Amount]  DEFAULT ((0)),
	[C3Amount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_C3Amount]  DEFAULT ((0)),
	[C4Amount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_C4Amount]  DEFAULT ((0)),
	[C5Amount] [money] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_C5Amount]  DEFAULT ((0)),
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_GroupSteps_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_GroupSteps] PRIMARY KEY CLUSTERED 
(
	[GroupStepID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_GroupStepTypes]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_GroupStepTypes](
	[GroupStepTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Seq] [int] NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_GroupStepTypes_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_GroupStepTypes] PRIMARY KEY CLUSTERED 
(
	[GroupStepTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_Hearings]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_Hearings](
	[HearingID] [int] IDENTITY(1,1) NOT NULL,
	[GroupID] [int] NOT NULL,
	[CourtID] [int] NOT NULL,
	[DateHearing] [datetime] NOT NULL,
	[Purpose] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Attendant] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_Hearings_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_Hearings] PRIMARY KEY CLUSTERED 
(
	[HearingID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_Localities]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_Localities](
	[LocalityID] [int] IDENTITY(1,1) NOT NULL,
	[RegionID] [int] NOT NULL,
	[Name] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Postcode] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_Localities_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_Localities] PRIMARY KEY CLUSTERED 
(
	[LocalityID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_PaymentAllocationRuleItems]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_PaymentAllocationRuleItems](
	[PaymentAllocationRuleItemID] [int] IDENTITY(1,1) NOT NULL,
	[PaymentAllocationRuleID] [int] NOT NULL,
	[TransactionTypeID] [int] NOT NULL,
	[Seq] [int] NOT NULL,
	[ChargeCommission] [bit] NOT NULL CONSTRAINT [DF_Legal_PaymentAllocationRuleItems_ChargeCommission]  DEFAULT ((0)),
	[ChargeSubsidy] [bit] NOT NULL CONSTRAINT [DF_Legal_PaymentAllocationRuleItems_ChargeSubsidy]  DEFAULT ((0)),
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_PaymentAllocationRuleItems_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_PaymentAllocationRuleItems] PRIMARY KEY CLUSTERED 
(
	[PaymentAllocationRuleItemID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_PaymentAllocationRules]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_PaymentAllocationRules](
	[PaymentAllocationRuleID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_PaymentAllocationRules_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_PaymentAllocationRules] PRIMARY KEY CLUSTERED 
(
	[PaymentAllocationRuleID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_Regions]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_Regions](
	[RegionID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[CountryCodeID] [int] NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_Regions_LastEditDate]  DEFAULT (getdate()),
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
 CONSTRAINT [PK_Legal_Regions] PRIMARY KEY CLUSTERED 
(
	[RegionID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_RelationshipTypes]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_RelationshipTypes](
	[RelationshipTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Seq] [int] NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_RelationshipTypes_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_RelationshipTypes] PRIMARY KEY CLUSTERED 
(
	[RelationshipTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_Snapshots]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_Snapshots](
	[SnapshotID] [int] IDENTITY(1,1) NOT NULL,
	[GroupID] [int] NOT NULL,
	[SnapshotTypeID] [int] NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Legal_Snapshots_DateCreated]  DEFAULT (getdate()),
	[DebtAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_DebtAmount]  DEFAULT ((0)),
	[IntAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_IntAmount]  DEFAULT ((0)),
	[SolAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_SolAmount]  DEFAULT ((0)),
	[CrtAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_CrtAmount]  DEFAULT ((0)),
	[SerAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_SerAmount]  DEFAULT ((0)),
	[AtsAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_AtsAmount]  DEFAULT ((0)),
	[TrvAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_TrvAmount]  DEFAULT ((0)),
	[BkpAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_BkpAmount]  DEFAULT ((0)),
	[LvyAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_LvyAmount]  DEFAULT ((0)),
	[SchAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_SchAmount]  DEFAULT ((0)),
	[C1Amount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_C1Amount]  DEFAULT ((0)),
	[C2Amount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_C2Amount]  DEFAULT ((0)),
	[C3Amount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_C3Amount]  DEFAULT ((0)),
	[C4Amount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_C4Amount]  DEFAULT ((0)),
	[C5Amount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_C5Amount]  DEFAULT ((0)),
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_Snapshots_LastEditDate]  DEFAULT (getdate()),
	[ProcessExecutionID] [int] NULL,
 CONSTRAINT [PK_Legal_Snapshots] PRIMARY KEY CLUSTERED 
(
	[SnapshotID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_SnapshotTypes]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_SnapshotTypes](
	[SnapshotTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_SnapshotTypes_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Legal_SnapshotTypes] PRIMARY KEY CLUSTERED 
(
	[SnapshotTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Legal_Solicitors]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_Solicitors](
	[SolicitorID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Firm] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Contact] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Notes] [nvarchar](4000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_Solicitors_LastEditDate]  DEFAULT (getdate()),
	[Code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[CommPointID] [int] NOT NULL,
	[Cc] [bit] NOT NULL CONSTRAINT [DF_Legal_Solicitors_Cc]  DEFAULT ((0)),
	[Inactive] [bit] NOT NULL CONSTRAINT [DF_Legal_Solicitors_Inactive]  DEFAULT ((0)),
 CONSTRAINT [PK_Legal_Solicitors] PRIMARY KEY CLUSTERED 
(
	[SolicitorID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[TransactionAllocations]    Script Date: 05/23/2008 09:01:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TransactionAllocations](
	[TransactionAllocationID] [int] IDENTITY(1,1) NOT NULL,
	[TransactionID] [int] NOT NULL,
	[TransactionTypeID] [int] NOT NULL,
	[Amount] [money] NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_TransactionAllocations_LastEditDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_TransactionAllocations] PRIMARY KEY CLUSTERED 
(
	[TransactionAllocationID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
-- End of Create Legal tables


-- =============================================
-- Description:	Rename column AccountID to ActivityID
-- History:
--		2008/06/10	[Binh Truong]	Init version.
-- =============================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_CustomFields' and c.name = 'ActivityID')
BEGIN
	EXEC sp_rename 'Legal_CustomFields.AccountID', 'ActivityID';
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'AvailableActions' and c.name = 'LoadInProductID')
BEGIN
	ALTER TABLE AvailableActions
	ADD LoadInProductID int NULL
		CONSTRAINT [AvailableActions_LoadInProductID_Default] DEFAULT 0
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'AccountStatus' and c.name = 'LoadInProductID')
BEGIN
	ALTER TABLE AccountStatus
	ADD LoadInProductID int NULL
		CONSTRAINT [AccountStatus_LoadInProductID_Default] DEFAULT 0
END
GO

/******  Script Closed. Go next: Step013_6  ******/