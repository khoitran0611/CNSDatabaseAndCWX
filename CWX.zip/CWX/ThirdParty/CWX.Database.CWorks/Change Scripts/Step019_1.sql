-- Script is applied on version 2.5.1, 2.5.3, 2.5.4, 2.5.5, 2.5.6, 2.5.7, 2.5.8, 2.5.10, 2.5.11, 2.5.12, 2.5.14, 2.5.15, 2.5.16

-- Scripts 2.5.1:
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 08/25/2008 13:46:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXML]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_LoadXML]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 08/25/2008 13:46:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Description:	Load all accounts with debtorID
-- History:
--	08/04/03	[Tai Ly]	Init version.
--	08/06/01	[Long Nguyen]	Add and remove some fields.
--	08/06/27	[Binh Truong]	Remove BatchNumber field.	
--	08/08/25	[Long Nguyen]	Remove @AdditionalTag
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int	
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/
	SELECT
			a.AccountID,
			c.COOWNERS,
			ISNULL(l.LetterDesc, '') AS SENTBY, ISNULL(al.LetterStatus, '') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			p.AmountPromised AS FirstAmountPromised, p.PromiseFrequency AS FirstPromiseFrequency, p.Term AS FirstPromiseTerm, p.DatePromised, '' AS PROMISE,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL,
			lastpromise.LASTPROMISEDATE, lastpromise.LASTPROMISEAMOUNT, lastpromise.LASTPROMISESTATUS, lastpromise.LASTPROMISESTATUSDESC
	INTO	#AccountTemp
	FROM	Account	 a
	--Count CoSigner for account
	LEFT JOIN (SELECT AccountID, COUNT(CoSignerID) AS COOWNERS FROM CoSigner GROUP BY AccountID) c ON c.AccountID = a.AccountID
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN 'd' THEN 'day(s)'
						WHEN 'w' THEN 'week(s)'
						WHEN 'm' THEN 'month(s)'
						WHEN 'y' THEN 'year(s)'
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get last promise
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised AS LASTPROMISEAMOUNT,
					p2.DatePromised AS LASTPROMISEDATE,
					p2.Status AS LASTPROMISESTATUS,
					CASE p2.Status
						WHEN 0 THEN 'Not Due'
						WHEN 1 THEN 'Paid On Time'
						WHEN 2 THEN 'Paid Late'
						WHEN 3 THEN 'Broken Promise'
						WHEN 4 THEN 'Canceled'
						ELSE ''
					END AS LASTPROMISESTATUSDESC
				FROM AccountPromise p2 
				WHERE p2.PromiseID IN 
						(	SELECT TOP 1 PromiseID
							FROM (	SELECT PromiseID, DatePromised
									FROM AccountPromise 
									WHERE AccountID = p2.AccountID -- 69
							) as temp
							ORDER BY DatePromised DESC
						)) lastpromise ON lastpromise.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	WHERE DebtorID = @DebtorID

	--If @AdditionalTag = 1 get additional data
--	DECLARE @AdditionalTag int
--	SELECT @AdditionalTag = FieldValue FROM IdentityFields WHERE TableName = 'AdditionalTag'

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, nextAction.CodeDesc AS CurrentNextActionDesc, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			, #AccountTemp.COOWNERS--, DebtorID as COOWNERS
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE--, InvoiceNumber as SENTBY, ' ' as LETTERSTATUS, QueueDate as LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised, #AccountTemp.FirstAmountPromised, #AccountTemp.FirstPromiseFrequency, #AccountTemp.FirstPromiseTerm--, String1 as PROMISE
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.LASTCONTACTDATE ELSE '' END AS LASTCONTACTDATE--' ' as LASTCONTACTDATE
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.LASTCONTACTBY ELSE '' END AS LASTCONTACTBY--, ' ' as LASTCONTACTBY
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISETOPAY ELSE '' END AS PROMISETOPAY--, ' ' as PROMISETOPAY
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISEKEPT ELSE '' END AS PROMISEKEPT--, ' ' as PROMISEKEPT
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISEBROKEN ELSE '' END AS PROMISEBROKEN--, ' ' as PROMISEBROKEN
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.OUTGOINGCALL ELSE '' END AS OUTGOINGCALL--, ' ' as OUTGOINGCALL
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.NOACTIVITYDAYS ELSE '' END AS NOACTIVITYDAYS--, ' ' as NOACTIVITYDAYS
			, #AccountTemp.LASTPROMISEDATE, #AccountTemp.LASTPROMISEAMOUNT, #AccountTemp.LASTPROMISESTATUS, #AccountTemp.LASTPROMISESTATUSDESC
			, #AccountTemp.LASTCONTACTDATE, #AccountTemp.LASTCONTACTBY, #AccountTemp.PROMISETOPAY, #AccountTemp.PROMISEKEPT, #AccountTemp.PROMISEBROKEN, #AccountTemp.OUTGOINGCALL, #AccountTemp.NOACTIVITYDAYS
			, ISNULL(Account.IsPending, 0) AS IsPending
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID
			LEFT OUTER JOIN AccountCodeMaster nextAction on Account.CurrentNextAction = nextAction.CodeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END
GO

-- Scripts 2.5.3:

ALTER TABLE CWX_TicketPhoneChange ALTER COLUMN PhoneStatus smallint
GO

/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetWorkDetails]    Script Date: 08/26/2008 14:42:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetWorkDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetWorkDetails]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetWorkDetails]    Script Date: 08/26/2008 14:42:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================================
-- Description:	Get employee working details.
-- History:
--	2008/08/13	[Binh Truong]	Init version.
--	2008/08/14	[Binh Truong]	E.EmployeeStatus = 'A'  >>> E.EmployeeStatus <> 'R'
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Employee_GetWorkDetails]
	@SupervisorID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;
                      
	DECLARE @EmployeeID int
	DECLARE @EmployeeName varchar(50)
	DECLARE @RowCount int
	DECLARE @RecordIndex int
	
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END
	
	DECLARE @TempTableVar table(
			EmployeeID			int,
			EmployeeName		varchar(50),
			AccountIDViewing	int,
			ViewedNo			int
		);
		
	SELECT	@RowCount = COUNT(DISTINCT E.EmployeeID)
	FROM	AccountActions as A, Employee as E
	WHERE	A.CompletedBy = E.EmployeeID AND
			(@SupervisorID = 0 OR E.SuperVisorId = @SupervisorID) AND
			E.EmployeeStatus <> 'R' AND A.ActionID = 8 AND 
			CONVERT(varchar(10), A.DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)

	DECLARE AccountActions_cursor CURSOR DYNAMIC READ_ONLY FOR
	SELECT	DISTINCT E.EmployeeID, E.UserID--, E.EmployeeName
	FROM	AccountActions as A, Employee as E
	WHERE	A.CompletedBy = E.EmployeeID AND
			(@SupervisorID = 0 OR E.SuperVisorId = @SupervisorID) AND
			E.EmployeeStatus <> 'R' AND A.ActionID = 8 AND 
			CONVERT(varchar(10), A.DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
	ORDER BY E.EmployeeID

	OPEN AccountActions_cursor
	
	FETCH RELATIVE @BeginIndex FROM AccountActions_cursor 
	INTO @EmployeeID, @EmployeeName

	WHILE @PageSize > 0 AND @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO @TempTableVar
		SELECT	TOP 1	@EmployeeID, 
						@EmployeeName,
						AccountID,
						(SELECT	COUNT(CompletedBy)
						FROM	AccountActions
						WHERE   CompletedBy = @EmployeeID AND ActionID = 8 AND (CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121))) as ViewedNo
		FROM	AccountActions
		WHERE CompletedBy = @EmployeeID
		ORDER BY DateCompleted DESC
		
		FETCH NEXT FROM AccountActions_cursor
		INTO @EmployeeID, @EmployeeName
		
		SET @PageSize = @PageSize - 1
	END
	
	CLOSE AccountActions_cursor
	DEALLOCATE AccountActions_cursor

	SELECT * FROM @TempTableVar
	
	RETURN @RowCount
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ClientInformation' and c.name = 'CreditorID')
BEGIN
	ALTER TABLE ClientInformation ADD CreditorID int
END
GO

-- Scripts 2.5.4:

/****** Object:  Table [dbo].[PersonAddressLog]    Script Date: 08/26/2008 17:55:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PersonAddressLog]') AND type in (N'U'))
DROP TABLE [dbo].[PersonAddressLog]
GO
/****** Object:  Table [dbo].[PersonAddressLog]    Script Date: 08/26/2008 17:56:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PersonAddressLog](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[AddressID] [int] NOT NULL,
	[PersonID] [int] NULL,
	[AddressType] [tinyint] NULL,
	[Address1] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Address2] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Address3] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[City] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[State] [char](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Zip] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Country] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Territory] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Region] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MailingAddress] [bit] NULL,
	[AddressStatus] [smallint] NOT NULL,
	[Description] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[EmployeeID] [int] NULL,
	[CreateDate] [smalldatetime] NULL,
	[UpdateDate] [smalldatetime] NULL,
 CONSTRAINT [PK_PersonAddressLog] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[PersonAddressLog].[AddressStatus]' , @futureonly='futureonly'
GO

/****** Object:  Table [dbo].[TransactionType]    Script Date: 08/27/2008 15:52:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TransactionType]') AND type in (N'U'))
DROP TABLE [dbo].[TransactionType]

GO
/****** Object:  Table [dbo].[TransactionType]    Script Date: 08/27/2008 15:52:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[TransactionType](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[TransactionCode] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AffectBalance] [smallint] NULL,
	[ClientID] [int] NULL CONSTRAINT [DF_TransactionType_ClientID]  DEFAULT ((0)),
	[Status] [char](1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_TransactionType] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[PersonPhoneLog]    Script Date: 08/27/2008 17:29:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PersonPhoneLog]') AND type in (N'U'))
DROP TABLE [dbo].[PersonPhoneLog]
GO

/****** Object:  Table [dbo].[PersonPhoneLog]    Script Date: 08/27/2008 17:29:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PersonPhoneLog](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[PhoneID] [int] NOT NULL,
	[PersonID] [int] NULL,
	[PhoneType] [tinyint] NULL,
	[PhoneNumber] [varchar](18) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PhoneExtension] [varchar](8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PhoneStatus] [smallint] NOT NULL,
	[Description] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[EmployeeID] [int] NULL CONSTRAINT [DF_PersonPhoneLog_EmployeeID]  DEFAULT ((0)),
	[CreateDate] [smalldatetime] NULL,
	[UpdateDate] [smalldatetime] NULL,
 CONSTRAINT [PK_PersonPhoneLog] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[PersonPhoneLog].[PhoneStatus]' , @futureonly='futureonly'
GO

-- Scripts 2.5.5:
-- =============================================
-- Author:		Minh Dam
-- Create date: Aug 28, 2008
-- Description:	Drop columns PostalAddressID, LegalAddressID, StreetAddressID and OtherAddressID in table Legal_CommPoints
-- Effected tables: Legal_CommPoints
-- =============================================
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_CommPoints' and c.name = 'PostalAddressID')
BEGIN
	ALTER TABLE dbo.Legal_CommPoints
		DROP COLUMN PostalAddressID
END

IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_CommPoints' and c.name = 'LegalAddressID')
BEGIN
	ALTER TABLE dbo.Legal_CommPoints
		DROP COLUMN LegalAddressID
END

IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_CommPoints' and c.name = 'StreetAddressID')
BEGIN
	ALTER TABLE dbo.Legal_CommPoints
		DROP COLUMN StreetAddressID
END

IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_CommPoints' and c.name = 'OtherAddressID')
BEGIN
	ALTER TABLE dbo.Legal_CommPoints
		DROP COLUMN OtherAddressID
END
GO
COMMIT

-- =============================================
-- Author:		Minh Dam
-- Create date: Aug 28, 2008
-- Description:	Create new table Legal_CommPointAddresses
-- =============================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Legal_CommPointAddresses]') AND type in (N'U'))
DROP TABLE [dbo].[Legal_CommPointAddresses]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Legal_CommPointAddresses](
	[CommPointAddressID] [int] IDENTITY(1,1) NOT NULL,
	[CommPointID] [int] NULL,
	[AddressType] [tinyint] NULL,
	[Address1] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Address2] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Address3] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[City] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[State] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Zip] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Country] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Territory] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Region] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MailingAddress] [bit] NULL CONSTRAINT [DF_CommPointAddress_MailingAddress]  DEFAULT (0),
	[AddressStatus] [smallint] NOT NULL,
	[Description] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[EmployeeID] [int] NULL CONSTRAINT [DF_CommPointAddress_EmployeeID]  DEFAULT (0),
	[CreateDate] [smalldatetime] NULL,
	[UpdateDate] [smalldatetime] NULL,
CONSTRAINT [PK_Legal_CommPointAddresses] PRIMARY KEY CLUSTERED 
(
	[CommPointAddressID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[Legal_CommPointAddresses].[AddressStatus]' , @futureonly='futureonly'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'City' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Legal_CommPointAddresses', @level2type=N'COLUMN',@level2name=N'City'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ZIPCode' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Legal_CommPointAddresses', @level2type=N'COLUMN',@level2name=N'Zip'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Country Code' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Legal_CommPointAddresses', @level2type=N'COLUMN',@level2name=N'Country'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=NULL , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Legal_CommPointAddresses', @level2type=N'COLUMN',@level2name=N'MailingAddress'

-- =============================================
-- Author:		Minh Dam
-- Create date: Aug 28, 2008
-- Description:	Create new table Legal_CommPointAddressesLog
-- =============================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Legal_CommPointAddressesLog]') AND type in (N'U'))
DROP TABLE [dbo].[Legal_CommPointAddressesLog]

/****** Object:  Table [dbo].[Legal_CommPointAddresses]    Script Date: 08/26/2008 18:23:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Legal_CommPointAddressesLog](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[CommPointAddressID] [int] NOT NULL,
	[CommPointID] [int] NULL,
	[AddressType] [tinyint] NULL,
	[Address1] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Address2] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Address3] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[City] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[State] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Zip] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Country] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Territory] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Region] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MailingAddress] [bit] NULL CONSTRAINT [DF_CommPointAddressesLog_MailingAddress]  DEFAULT (0),
	[AddressStatus] [smallint] NOT NULL,
	[Description] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[EmployeeID] [int] NULL CONSTRAINT [DF_CommPointAddressesLog_EmployeeID]  DEFAULT (0),
	[CreateDate] [smalldatetime] NULL,
	[UpdateDate] [smalldatetime] NULL,
CONSTRAINT [PK_Legal_CommPointAddressesLog] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[Legal_CommPointAddressesLog].[AddressStatus]' , @futureonly='futureonly'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'City' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Legal_CommPointAddressesLog', @level2type=N'COLUMN',@level2name=N'City'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ZIPCode' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Legal_CommPointAddressesLog', @level2type=N'COLUMN',@level2name=N'Zip'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Country Code' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Legal_CommPointAddressesLog', @level2type=N'COLUMN',@level2name=N'Country'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=NULL , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Legal_CommPointAddressesLog', @level2type=N'COLUMN',@level2name=N'MailingAddress'
GO

-- Scripts 2.5.6:

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Groups' and c.name = 'CreateDate')
BEGIN
	ALTER TABLE Legal_Groups ADD CreateDate datetime
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Groups' and c.name = 'PaymentAllocationRuleID')
BEGIN
	ALTER TABLE Legal_Groups ADD PaymentAllocationRuleID int
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 08/28/2008 17:59:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 08/28/2008 17:59:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-14
-- Description:	Get the list of Groups of selecting customer
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
	-- Add the parameters for the stored procedure here
	@debtorID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(G.GroupID)
	FROM 
		(SELECT DISTINCT a.GroupID
		FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
			LEFT JOIN Account c ON b.AccountID = c.AccountID
			LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> 'R') d ON a.GroupID = d.GroupID
		WHERE  a.Status <> 'R' and c.DebtorID = @debtorID) G

	WITH Temp AS
	(	
		SELECT
			ROW_NUMBER() OVER (ORDER BY G.Code) AS RowNumber,
			G.*	
		FROM (SELECT DISTINCT
			a.GroupID,
			a.Code,
			a.[Description],
			Case When d.GroupID is not null then 1 else 0 end HasStep
			FROM Legal_Groups a
				LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
				LEFT JOIN Account c ON b.AccountID = c.AccountID
				LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> 'R') d ON a.GroupID = d.GroupID
			WHERE  a.Status <> 'R' and c.DebtorID = @debtorID) G
	)

	SELECT * FROM Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
	
END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: Aug 28, 2008
-- Description:	Create new store procedure CWX_Legal_Contacts_GetPagingListByParentContactType
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]    Script Date: 08/28/2008 18:40:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]    Script Date: 08/28/2008 18:41:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]
	-- Add the parameters for the stored procedure here
	@ParentContactType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @Sql varchar(5000)

	DECLARE @RowCount int
	SELECT @RowCount=COUNT(ContactID)
	FROM Legal_Contacts
	WHERE ParentType = @ParentContactType AND [Status] <> 'R'

	SET @Sql =
'WITH Temp AS
(
	SELECT
		ROW_NUMBER() OVER (ORDER BY b.Code) AS RowNumber,
		a.ContactID,
		a.ParentType, 
		b.Code [Code], 
		b.@@NameField [Name],
		IsNull(Title,'''') Title, IsNull(FirstName, '''') FirstName, IsNull(LastName, '''') LastName, 
		a.[Description]
	FROM Legal_Contacts a
		LEFT JOIN @@RefTable b ON a.ParentID = b.@@RefField AND a.ParentType = @@ParentContactType
	WHERE a.ParentType = @@ParentContactType AND a.Status <> ''R''
)

SELECT ContactID, ParentType, Code + Case When [Name]<>'''' Then '' - '' + [Name] Else '''' End CodeAndName, 
		LTRIM(Case When Title<>'''' Then Title Else '''' End + Case When FirstName<>'''' Then '' ''+FirstName Else '''' End + 
			Case When LastName<>'''' Then '' '' + LastName Else '''' End) ContactName,
		[Description]
FROM Temp WHERE RowNumber BETWEEN @@PageIndex * @@PageSize + 1 AND (@@PageIndex + 1) * @@PageSize
'

	IF (@ParentContactType = 1) -- Solicitors
	BEGIN
		SET @Sql = REPLACE(@Sql, '@@RefTable', 'Legal_Solicitors')
		SET @Sql = REPLACE(@Sql, '@@RefField', 'SolicitorID')
		SET @Sql = REPLACE(@Sql, '@@NameField', 'Name')
	END
	ELSE IF (@ParentContactType = 2) -- Agents
	BEGIN
		SET @Sql = REPLACE(@Sql, '@@RefTable', 'Legal_Agents')
		SET @Sql = REPLACE(@Sql, '@@RefField', 'AgentID')
		SET @Sql = REPLACE(@Sql, '@@NameField', 'Name')
	END
	ELSE -- Creditors
	BEGIN
		SET @Sql = REPLACE(@Sql, '@@RefTable', 'Legal_Creditors')
		SET @Sql = REPLACE(@Sql, '@@RefField', 'CreditorID')
		SET @Sql = REPLACE(@Sql, '@@NameField', 'CommonName')
	END
	
	SET @Sql = REPLACE(@Sql, '@@ParentContactType', cast(@ParentContactType as varchar))
	SET @Sql = REPLACE(@Sql, '@@PageSize', cast(@PageSize as varchar))
	SET @Sql = REPLACE(@Sql, '@@PageIndex', cast(@PageIndex as varchar))

	--PRINT @Sql
	EXEC sp_sqlexec @Sql
	RETURN @RowCount
END
GO

/****** Object:  Table [dbo].[DialerExtension]    Script Date: 08/25/2008 17:48:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[DialerExtension](
	[Extension] [smallint] NOT NULL,
	[EmployeeID] [int] NULL,
	[Available] [bit] NOT NULL,
	[LineToUse] [smallint] NOT NULL,
	[LineInUse] [smallint] NOT NULL,
	[LoggedIn] [bit] NOT NULL,
	[LoginTime] [datetime] NULL,
	[LogoutTime] [datetime] NULL,
	[MSIStatus] [smallint] NOT NULL,
	[Line] [smallint] NULL,
	[PhoneNumber] [char](16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[NumbersLeft] [int] NOT NULL,
	[DebtorID] [int] NULL,
	[AccountID] [int] NULL,
	[CallResult] [smallint] NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[DialerExtension].[Available]' , @futureonly='futureonly'
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[DialerExtension].[LoggedIn]' , @futureonly='futureonly'
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[DialerExtension].[MSIStatus]' , @futureonly='futureonly'
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[DialerExtension].[NumbersLeft]' , @futureonly='futureonly'


/****** Object:  Table [dbo].[DialerQueue]    Script Date: 08/25/2008 17:49:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[DialerQueue](
	[RecordID] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[DebtorID] [int] NOT NULL,
	[AccountID] [int] NOT NULL,
	[TimeZone] [char](3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[PhoneNumber] [char](16) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[StartTime] [int] NOT NULL,
	[EndingTime] [int] NOT NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF


-- Scripts 2.5.7:

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 08/29/2008 14:47:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 08/29/2008 14:47:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debtors with Account No. and Customer 's fullName
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate] ,ISNULL(g.Relationship_Type, 'Debtor') AS [RelationshipType] ,a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				LEFT JOIN PersonInformation p ON a.PersonID = p.PersonID
				LEFT JOIN Account b ON a.AccountID = b.AccountID
				LEFT JOIN CosigneeInformation g ON g.PersonID = a.PersonID AND g.Bill = b.AccountID
		WHERE a.GroupID = @groupID
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	ELSE
	BEGIN
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,'Debtor' AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
				LEFT JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
				LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate] ,g.Relationship_Type AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
			LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID)
		
		ORDER BY Seq, b.AccountID, FullName
	END
END
GO

---- ThuyNguyen added on 29-August-08 -----

alter table PersonPhone add PhoneTime varchar (50)
alter table PersonPhoneLog add PhoneTime varchar (50)
go
-------------------------------------------

/****** Object:  Table [dbo].[Legal_GroupNotes]    Script Date: 08/29/2008 15:22:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Legal_GroupNotes](
	[NoteID] [int] IDENTITY(1,1) NOT NULL,
	[GroupID] [int] NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[NoteDateTime] [datetime] NULL,
	[NoteType] [varchar](1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[NoteText] [nvarchar](700) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_Legal_GroupNotes] PRIMARY KEY CLUSTERED 
(
	[NoteID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Aug 29, 2008
-- Description:		Add column 'FieldType' to table 'Legal_CustomFieldTypes'
-- Effected table:	Legal_CustomFieldTypes
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_CustomFieldTypes' and c.name = 'FieldType')
BEGIN
	ALTER TABLE Legal_CustomFieldTypes
		ADD FieldType [smallint] NULL CONSTRAINT [DF_Legal_CustomFieldTypes_FieldType]  DEFAULT ((0))
END
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Aug 29, 2008
-- Description:		Add column 'IncludeInGroup' to table 'Legal_RelationshipTypes'
-- Effected table:	Legal_RelationshipTypes
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_RelationshipTypes' and c.name = 'IncludeInGroup')
BEGIN
	ALTER TABLE Legal_RelationshipTypes
		ADD [IncludeInGroup] [bit] NULL CONSTRAINT [DF_Legal_RelationshipTypes_IncludeInGroup]  DEFAULT ((0))
END
GO

-- =======================================================================
-- Author:			Minh Dam
-- Create date:		Aug 29, 2008
-- Description:		Add column 'FeeCode' and 'AffectBalance' to table 'DefineFees'
-- Effected table:	DefineFees
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'DefineFees' and c.name = 'FeeCode')
BEGIN
	ALTER TABLE DefineFees
		ADD [FeeCode] [varchar](25) NULL, 
		[AffectBalance] [smallint] NOT NULL CONSTRAINT [DF_DefineFees_AffectBalance]  DEFAULT ((0))
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupNote_GetPagingList]    Script Date: 08/29/2008 17:33:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupNote_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_GroupNote_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupNote_GetPagingList]    Script Date: 08/29/2008 17:33:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Long Nguyen>
-- Create date: <Aug 28, 2008>
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_GroupNote_GetPagingList]
	@GroupID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
	SELECT @RowCount=COUNT(t.NoteID)
	FROM Legal_GroupNotes t INNER JOIN Employee e ON t.EmployeeID=e.EmployeeID
	WHERE t.NoteType='M' AND t.GroupID=@GroupID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY NoteDateTime DESC) AS RowNumber,
			NoteDateTime,NoteText,e.EmployeeName
		FROM Legal_GroupNotes t INNER JOIN Employee e ON t.EmployeeID=e.EmployeeID
		WHERE t.NoteType='M' AND t.GroupID=@GroupID
	)

	SELECT * FROM Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_GetCustomTransactionList]    Script Date: 09/01/2008 14:16:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetCustomTransactionList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetCustomTransactionList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetCustomTransactionList]    Script Date: 09/01/2008 14:16:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetCustomTransactionList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thuy Nguyen
-- Create date: 29 August, 2008
-- Description:	Get Transaction List by TransactionType with a custom column is "Transaction Code - Description"
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetCustomTransactionList] 		
	@AccountID int = 0,
	@TransactionType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	-- SET NOCOUNT ON;	

	DECLARE @querystring varchar(1000);

	CREATE TABLE #Temp(
		RowNumber int,
		TransactionID int not null,
		DateOfTransaction smalldatetime,
		TransactionAmount money,		
		TransactionComment nvarchar(150),
		TransactionCodeDescription nvarchar(150)
	);

	
	SET @querystring = ''INSERT INTO #Temp
		SELECT 
		ROW_NUMBER() OVER (ORDER BY  t.DateOfTransaction DESC) AS RowNumber,
		t.TransactionID, t.DateOfTransaction, t.TransactionAmount, t.TransactionComment,
		tt.TransactionCode + '''' - '''' + tt.Description as TransactionCodeDescription	
	FROM Transactions t LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID
	WHERE t.AccountID = '' + cast(@AccountID as varchar)

	IF @TransactionType<>0 SET @querystring = @querystring + '' AND t.TransactionType = '' + cast(@TransactionType as varchar);
	
	EXEC (@querystring)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	
	RETURN @RowCount

END
' 
END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: Sep 01, 2008
-- Description:	Create new table Legal_CourtTypes
-- =============================================
/****** Object:  Table [dbo].[Legal_CourtTypes]    Script Date: 09/01/2008 16:26:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Legal_CourtTypes]') AND type in (N'U'))
DROP TABLE [dbo].[Legal_CourtTypes]
GO

/****** Object:  Table [dbo].[Legal_CourtTypes]    Script Date: 09/01/2008 16:26:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Legal_CourtTypes](
	[CourtTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_CourtTypes_LastEditDate]  DEFAULT (getdate()),
	[Status] [char](1) NOT NULL CONSTRAINT [Legal_CourtTypes_RowStatus]  DEFAULT ('A'),
 CONSTRAINT [PK_Legal_CourtType] PRIMARY KEY CLUSTERED 
(
	[CourtTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: Sep 01, 2008
-- Description:	Add three new column CourtType, DebtAmountFrom and DebtAmountTo to table Legal_Courts
-- =============================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Courts' and c.name = 'CourtType')
BEGIN
	ALTER TABLE dbo.Legal_Courts
		ADD CourtType int NOT NULL CONSTRAINT DF_Legal_Courts_CourtType DEFAULT ((0))
END

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Courts' and c.name = 'DebtAmountFrom')
BEGIN
	ALTER TABLE dbo.Legal_Courts
		ADD DebtAmountFrom money NOT NULL CONSTRAINT DF_Legal_Courts_DebtAmountFrom DEFAULT ((0))
END

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Courts' and c.name = 'DebtAmountTo')
BEGIN
	ALTER TABLE dbo.Legal_Courts
		ADD DebtAmountTo money NOT NULL CONSTRAINT DF_Legal_Courts_DebtAmountTo DEFAULT ((0))
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_CollateralNote_GetPagingList]    Script Date: 09/03/2008 09:45:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CollateralNote_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CollateralNote_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CollateralNote_GetPagingList]    Script Date: 09/03/2008 09:45:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CollateralNote_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Thuy Nguyen
-- Create date: 1 Sept, 2008
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CollateralNote_GetPagingList] 		
	@CollateralID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	
	DECLARE @RowCount int, @RowNumber int;	
	
	SELECT @RowCount = COUNT(NoteID) FROM CollateralNotes 
	WHERE CollateralID = @CollateralID	

	IF @PageSize*(@PageIndex+1) > @RowCount 
		SET @RowNumber = @RowCount - (@PageSize*@PageIndex)
	ELSE 
		SET @RowNumber = @PageSize

	SELECT * FROM 
		(SELECT TOP (@RowNumber) * FROM  
			(SELECT TOP ((@PageIndex + 1)*@PageSize) 
				c.*, 
				e.EmployeeName
			FROM CollateralNotes c 
				LEFT JOIN Employee e ON c.EmployeeID = e.EmployeeID
			WHERE CollateralID = @CollateralID
			ORDER BY NoteDateTime DESC) as t1 
		ORDER BY NoteDateTime ASC) as t2 
	ORDER BY NoteDateTime DESC		

	RETURN @RowCount
END
' 
END
GO

-- Scripts 2.5.8:

--- Thuy Nguyen added on 3-Sep-2008
alter table Collateral add [Image] image
alter table Collateral add ImageFileName varchar(255)
Go
----------
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 09/03/2008 13:47:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 15/08/2008
-- Description:	
-- =============================================				
ALTER PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
	@CollateralID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			b.[DataType],
			b.[MaxLength]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], [DisplayOrder]
		FROM CWX_Collateral_Dict
		WHERE Displayed = 1) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], c.[max_length] as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Collateral' and [Type]='U')
			AND (c.[name] LIKE 'CInt%' OR c.[name] LIKE 'CString%' OR c.[name] LIKE 'CDate%' OR c.[name] LIKE 'CMoney%')
		) b 
		ON a.[FieldName] = b.[ColumnName]
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'ID,AccountID,HostCollateralID,EmployeeID,NextActionDate,Image,ImageFileName,'
	SET @FieldNameList = @FieldNameList + 
'(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6) IS NOT NULL THEN CollateralType ELSE 0 END) AS CollateralType,
(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7) IS NOT NULL THEN CollateralStage ELSE 0 END) AS CollateralStage,
(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2) IS NOT NULL THEN NextAction ELSE 0 END) AS NextAction'
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM Collateral WHERE ID = ' + Cast(@CollateralID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_CreateGroupAccount]    Script Date: 09/03/2008 17:00:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CreateGroupAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_CreateGroupAccount]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_CreateGroupAccount]    Script Date: 09/03/2008 17:00:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 03, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_CreateGroupAccount]
	-- Add the parameters for the stored procedure here
	@GroupID int
AS
BEGIN
		--Increase 'Account' by one
	UPDATE IdentityFields SET FieldValue = FieldValue + 1 WHERE TableName = 'Account'

	--Insert new Account with all detail from the primary account of group
	DECLARE @BillBalance money
	DECLARE @BillAmount money
	SELECT @BillBalance=SUM(a.BillBalance), @BillAmount=SUM(a.BillAmount)
	FROM Legal_GroupDebts g
	LEFT JOIN Account a ON a.AccountID = g.AccountID
	WHERE g.IsInclude=1 AND g.GroupID=@GroupID

	DECLARE @PrimaryAccountID int
	SELECT @PrimaryAccountID=AccountID FROM Legal_GroupDebts WHERE GroupID = @GroupID AND IsPrimary = 1

	DECLARE @AccountID int
	SELECT @AccountID=MAX(AccountID)+1 FROM Account

	INSERT INTO Account
	SELECT @AccountID
		  ,DebtorID
		  ,EmployeeID
		  ,ClientID
		  ,AgencyStatusID
		  ,SystemStatusID
		  ,ActionCodeID
		  ,OfficeID
		  ,MCode
		  ,CCode
		  ,InvoiceNumber
		  ,AccountType
		  ,AccountClass
		  ,QueueDate
		  ,DateOfService
		  ,SubmissionDate
		  ,LastClientTransactionDate
		  ,RoutinePayment
		  ,PaymentPlan
		  ,PatientName
		  ,@BillAmount
		  ,@BillBalance
		  ,BillOtherCharges
		  ,ClientPaysLegalFees
		  ,AccountForwarded
		  ,CreditReported
		  ,CreditReportedDate
		  ,ClientPercent
		  ,ClientOCPercent
		  ,SplitPayment
		  ,CurrentAction
		  ,CurrentActionDate
		  ,NoLetterBefore
		  ,NoFeeBefore
		  ,MaintainOfficer
		  ,AccountAge
		  ,LastEditDate
		  ,LastEditBy
		  ,LastVerifyDate
		  ,AllocRuleID
		  ,AutoProcRuleID
		  ,LastExtractionDate
		  ,LastAllocationDate
		  ,LastAutoProcessDate
		  ,ExtractionRuleID
		  ,AccountForwardedTo
		  ,CurrencyCode
		  ,BatchNumber
		  ,InterestRate
		  ,ActionEmployee
		  ,LastPromiseBatch
		  ,CreditReportRequested
		  ,CreditReportRequestedBy
		  ,CreditReportRequestedOn
		  ,CreditReportRequestStatus
		  ,WriteOffDate
		  ,LastInterestDate
		  ,TempEmployeeID
		  ,OAManaged
		  ,InterfaceID
		  ,Delq_string
		  ,SortOrder
		  ,Allocated
		  ,BrokenCount
		  ,CARD_FILE_NO
		  ,ARREAR_PATH
		  ,BUCKET_TYPE
		  ,OLD_BUCKET_TYPE
		  ,CARD_TYPE
		  ,BRANCH_CODE
		  ,FORMULA
		  ,BANK_CODE
		  ,PAID
		  ,OtherAccountNo
		  ,TENOR
		  ,FORMULA_FLAG
		  ,MINIMUM_DUE
		  ,CURRENT_BKT_NUM
		  ,PREV_BKT_NUM
		  ,productivecount
		  ,contactcount
		  ,nocontactcount
		  ,DelqHistory
		  ,BucketMovement
		  ,DPDMovement
		  ,PreviousAllocRuleID
		  ,OnLeaveEmpID
		  ,LeaveLoadRelFlag
		  ,CurrentReason
		  ,CurrentReasonDate
		  ,CurrentNextAction
		  ,CurrentNextActionDate
		  ,CurrentCallResult
		  ,CurrentCallResultDate
		  ,CampaignId
		  ,CloseDate
		  ,MaxContact
		  ,AssignmentType
		  ,PoolSelected
		  ,IsPending
		FROM Account
		WHERE AccountID = @PrimaryAccountID

	--Insert into AccountOther
	INSERT INTO AccountOther
	SELECT @AccountID
		  ,Long1
		  ,Long2
		  ,Long3
		  ,Long4
		  ,Long5
		  ,Long6
		  ,Long7
		  ,Long8
		  ,Long9
		  ,Long10
		  ,Long11
		  ,Long12
		  ,Long13
		  ,Long14
		  ,Long15
		  ,Long16
		  ,Long17
		  ,Long18
		  ,Long19
		  ,Long20
		  ,Long21
		  ,Long22
		  ,Long23
		  ,Long24
		  ,Long25
		  ,Long26
		  ,Long27
		  ,Long28
		  ,Long29
		  ,Long30
		  ,Long31
		  ,Long32
		  ,Long33
		  ,Long34
		  ,Long35
		  ,Long36
		  ,Long37
		  ,Long38
		  ,Long39
		  ,Long40
		  ,Long41
		  ,Long42
		  ,Long43
		  ,Long44
		  ,Long45
		  ,Long46
		  ,Long47
		  ,Long48
		  ,Long49
		  ,Long50
		  ,Money1
		  ,Money2
		  ,Money3
		  ,Money4
		  ,Money5
		  ,Money6
		  ,Money7
		  ,Money8
		  ,Money9
		  ,Money10
		  ,Money11
		  ,Money12
		  ,Money13
		  ,Money14
		  ,Money15
		  ,Money16
		  ,Money17
		  ,Money18
		  ,Money19
		  ,Money20
		  ,Money21
		  ,Money22
		  ,Money23
		  ,Money24
		  ,Money25
		  ,Money26
		  ,Money27
		  ,Money28
		  ,Money29
		  ,Money30
		  ,Money31
		  ,Money32
		  ,Money33
		  ,Money34
		  ,Money35
		  ,Money36
		  ,Money37
		  ,Money38
		  ,Money39
		  ,Money40
		  ,Money41
		  ,Money42
		  ,Money43
		  ,Money44
		  ,Money45
		  ,Money46
		  ,Money47
		  ,Money48
		  ,Money49
		  ,Money50
		  ,Date1
		  ,Date2
		  ,Date3
		  ,Date4
		  ,Date5
		  ,Date6
		  ,Date7
		  ,Date8
		  ,Date9
		  ,Date10
		  ,Date11
		  ,Date12
		  ,Date13
		  ,Date14
		  ,Date15
		  ,Date16
		  ,Date17
		  ,Date18
		  ,Date19
		  ,Date20
		  ,Date21
		  ,Date22
		  ,Date23
		  ,Date24
		  ,Date25
		  ,Date26
		  ,Date27
		  ,Date28
		  ,Date29
		  ,Date30
		  ,Date31
		  ,Date32
		  ,Date33
		  ,Date34
		  ,Date35
		  ,Date36
		  ,Date37
		  ,Date38
		  ,Date39
		  ,Date40
		  ,Date41
		  ,Date42
		  ,Date43
		  ,Date44
		  ,Date45
		  ,Date46
		  ,Date47
		  ,Date48
		  ,Date49
		  ,Date50
		  ,String1
		  ,String2
		  ,String3
		  ,String4
		  ,String5
		  ,String6
		  ,String7
		  ,String8
		  ,String9
		  ,String10
		  ,String11
		  ,String12
		  ,String13
		  ,String14
		  ,String15
		  ,String16
		  ,String17
		  ,String18
		  ,String19
		  ,String20
		  ,String21
		  ,String22
		  ,String23
		  ,String24
		  ,String25
		  ,String26
		  ,String27
		  ,String28
		  ,String29
		  ,String30
		  ,String31
		  ,String32
		  ,String33
		  ,String34
		  ,String35
		  ,String36
		  ,String37
		  ,String38
		  ,String39
		  ,String40
		  ,String41
		  ,String42
		  ,String43
		  ,String44
		  ,String45
		  ,String46
		  ,String47
		  ,String48
		  ,String49
		  ,String50
		  ,Additional1
		  ,Additional2
		  ,Additional3
		  ,Additional4
		  ,ArrearsHistory
		FROM AccountOther
		WHERE AccountID = @PrimaryAccountID

END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: Sep 01, 2008
-- Description:	Add new columns DebtAmountFrom and DebtAmountTo to table Legal_Courts
-- =============================================
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Courts' and c.name = 'DebtAmountFrom')
BEGIN
	ALTER TABLE [Legal_Courts]
		DROP CONSTRAINT [DF_Legal_Courts_DebtAmountFrom]
	ALTER TABLE [Legal_Courts]
		DROP COLUMN [DebtAmountFrom]
END

ALTER TABLE [Legal_Courts]
	ADD [DebtAmountFrom] money NULL
	
	
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Courts' and c.name = 'DebtAmountTo')
BEGIN
	ALTER TABLE [Legal_Courts]
		DROP COLUMN [DebtAmountTo]
END

ALTER TABLE [Legal_Courts]
	ADD [DebtAmountTo] money NULL
	
	
-- Scripts 2.5.10:

/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 09/04/2008 11:50:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Description:	Load all accounts with debtorID
-- History:
--	08/04/03	[Tai Ly]	Init version.
--	08/06/01	[Long Nguyen]	Add and remove some fields.
--	08/06/27	[Binh Truong]	Remove BatchNumber field.	
--	08/08/25	[Long Nguyen]	Remove @AdditionalTag
--	08/09/04	[Thuy Nguyen]	Remove CoSigner table reference
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int	
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/
	SELECT
			a.AccountID,
			--c.COOWNERS,
			ISNULL(l.LetterDesc, '') AS SENTBY, ISNULL(al.LetterStatus, '') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			p.AmountPromised AS FirstAmountPromised, p.PromiseFrequency AS FirstPromiseFrequency, p.Term AS FirstPromiseTerm, p.DatePromised, '' AS PROMISE,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL,
			lastpromise.LASTPROMISEDATE, lastpromise.LASTPROMISEAMOUNT, lastpromise.LASTPROMISESTATUS, lastpromise.LASTPROMISESTATUSDESC
	INTO	#AccountTemp
	FROM	Account	 a
	--Count CoSigner for account
	-- LEFT JOIN (SELECT AccountID, COUNT(CoSignerID) AS COOWNERS FROM CoSigner GROUP BY AccountID) c ON c.AccountID = a.AccountID
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN 'd' THEN 'day(s)'
						WHEN 'w' THEN 'week(s)'
						WHEN 'm' THEN 'month(s)'
						WHEN 'y' THEN 'year(s)'
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get last promise
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised AS LASTPROMISEAMOUNT,
					p2.DatePromised AS LASTPROMISEDATE,
					p2.Status AS LASTPROMISESTATUS,
					CASE p2.Status
						WHEN 0 THEN 'Not Due'
						WHEN 1 THEN 'Paid On Time'
						WHEN 2 THEN 'Paid Late'
						WHEN 3 THEN 'Broken Promise'
						WHEN 4 THEN 'Canceled'
						ELSE ''
					END AS LASTPROMISESTATUSDESC
				FROM AccountPromise p2 
				WHERE p2.PromiseID IN 
						(	SELECT TOP 1 PromiseID
							FROM (	SELECT PromiseID, DatePromised
									FROM AccountPromise 
									WHERE AccountID = p2.AccountID -- 69
							) as temp
							ORDER BY DatePromised DESC
						)) lastpromise ON lastpromise.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	WHERE DebtorID = @DebtorID

	--If @AdditionalTag = 1 get additional data
--	DECLARE @AdditionalTag int
--	SELECT @AdditionalTag = FieldValue FROM IdentityFields WHERE TableName = 'AdditionalTag'

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, nextAction.CodeDesc AS CurrentNextActionDesc, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			--, #AccountTemp.COOWNERS--, DebtorID as COOWNERS
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE--, InvoiceNumber as SENTBY, ' ' as LETTERSTATUS, QueueDate as LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised, #AccountTemp.FirstAmountPromised, #AccountTemp.FirstPromiseFrequency, #AccountTemp.FirstPromiseTerm--, String1 as PROMISE
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.LASTCONTACTDATE ELSE '' END AS LASTCONTACTDATE--' ' as LASTCONTACTDATE
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.LASTCONTACTBY ELSE '' END AS LASTCONTACTBY--, ' ' as LASTCONTACTBY
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISETOPAY ELSE '' END AS PROMISETOPAY--, ' ' as PROMISETOPAY
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISEKEPT ELSE '' END AS PROMISEKEPT--, ' ' as PROMISEKEPT
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.PROMISEBROKEN ELSE '' END AS PROMISEBROKEN--, ' ' as PROMISEBROKEN
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.OUTGOINGCALL ELSE '' END AS OUTGOINGCALL--, ' ' as OUTGOINGCALL
--			, CASE @AdditionalTag WHEN 1 THEN #AccountTemp.NOACTIVITYDAYS ELSE '' END AS NOACTIVITYDAYS--, ' ' as NOACTIVITYDAYS
			, #AccountTemp.LASTPROMISEDATE, #AccountTemp.LASTPROMISEAMOUNT, #AccountTemp.LASTPROMISESTATUS, #AccountTemp.LASTPROMISESTATUSDESC
			, #AccountTemp.LASTCONTACTDATE, #AccountTemp.LASTCONTACTBY, #AccountTemp.PROMISETOPAY, #AccountTemp.PROMISEKEPT, #AccountTemp.PROMISEBROKEN, #AccountTemp.OUTGOINGCALL, #AccountTemp.NOACTIVITYDAYS
			, ISNULL(Account.IsPending, 0) AS IsPending
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID
			LEFT OUTER JOIN AccountCodeMaster nextAction on Account.CurrentNextAction = nextAction.CodeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END

----------------------
Drop table CoSigner
GO
----------------------

-- =============================================
-- Author:		Minh Dam
-- Create date: Sep 04, 2008
-- Description:	Add new SP CWX_Collateral_GetPagingList
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetPagingList]    Script Date: 09/04/2008 14:32:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetPagingList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetPagingList]    Script Date: 09/04/2008 14:33:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Collateral_GetPagingList]
	@AccountID int,
	@EmployeeID int	,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @RowCount int
	SELECT ROW_NUMBER() OVER (ORDER BY [CollateralType], [CollateralStage], [NextAction], [NextActionDate]) as RowNumber,
			[ID], [AccountID], [HostCollateralID], [EmployeeID], [NextActionDate],
			ISNULL(dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6),'') AS CollateralType,
			ISNULL(dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7),'') AS CollateralStage,
			ISNULL(dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2),'') AS NextAction
	INTO #Temp
	FROM [Collateral]
	WHERE [AccountID] = @AccountID AND [EmployeeID] = @EmployeeID
	ORDER BY [CollateralType], [CollateralStage], [NextAction], [NextActionDate]
	
	
	SELECT @RowCount=COUNT(*) FROM #Temp

	SELECT [ID],[AccountID],[HostCollateralID],[EmployeeID],[NextActionDate],[CollateralType],[CollateralStage],[NextAction]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetListWithAccountIDs]    Script Date: 09/04/2008 14:45:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetListWithAccountIDs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetListWithAccountIDs]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetListWithAccountIDs]    Script Date: 09/04/2008 14:45:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 03, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetListWithAccountIDs]
	-- Add the parameters for the stored procedure here
	@DebtorID int,
	@GroupID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT c.GroupID, a.Code, c.AccountID
	FROM Legal_Groups a
	INNER JOIN Legal_GroupDebtors b ON a.GroupID = b.GroupID AND DebtorID IS NOT NULL
	INNER JOIN Legal_GroupDebts c ON c.GroupID = b.GroupID
	WHERE
		a.Status <> 'R'
		AND b.DebtorID = @DebtorID
		AND (a.GroupID <> @GroupID)
		AND c.IsInclude = 1
	ORDER BY a.GroupID, c.AccountID
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtList]    Script Date: 09/04/2008 14:45:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtList]    Script Date: 09/04/2008 14:46:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debts with Account No.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    IF @groupID <> 0
		SELECT [GroupDebtID],a.[GroupID],a.[AccountID],a.[LastEditDate],a.[PaymentAllocationRuleID],a.[IsInclude], a.[IsPrimary], b.InvoiceNumber
				,CAST(0 AS bit) AS IsGrouped
				,'' AS GroupName
		FROM Legal_GroupDebts a
			JOIN Account b ON a.AccountID = b.AccountID
----			LEFT JOIN (Select AccountID, IsInclude, (b.Code+' - '+b.Description) as GroupName 
----						From Legal_GroupDebts a, Legal_Groups b where a.GroupID=b.GroupID and a.GroupID <> @groupID 
----									and IsInclude = 1 and b.Status <> 'R') c ON a.AccountID = c.AccountID
		WHERE a.AccountID = b.AccountID AND GroupID = @groupID
		ORDER BY b.AccountID
	ELSE
		SELECT NULL AS [GroupDebtID], NULL AS [GroupID], b.[AccountID], NULL AS [LastEditDate],
						NULL AS [PaymentAllocationRuleID], CAST(0 AS bit) AS [IsInclude],
						CAST(0 AS bit) AS [IsPrimary], b.InvoiceNumber
				,CAST(0 AS bit) AS IsGrouped
				,'' AS GroupName
		FROM Account b 
--			LEFT JOIN (SELECT * FROM Legal_GroupDebts WHERE GroupID = 0) a ON a.AccountID = b.AccountID
--			LEFT JOIN (Select AccountID, IsInclude, (b.Code+' - '+b.Description) as GroupName 
--						From Legal_GroupDebts a, Legal_Groups b where a.GroupID=b.GroupID and IsInclude = 1 and b.Status <> 'R') c ON b.AccountID = c.AccountID
		WHERE b.DebtorID = @debtorID
		ORDER BY b.AccountID
END
GO

----------- Thuy Nguyen added on 4-Sep-2008
alter table PersonPhoneLog alter column PhoneNumber varchar(50)
alter table PersonPhoneLog alter column PhoneExtension varchar(25)
GO
--------------------------

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_GroupSteps' and c.name = 'CreateDate')
BEGIN
	ALTER TABLE Legal_GroupSteps ADD CreateDate datetime
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_GroupSteps' and c.name = 'CourtID')
BEGIN
	ALTER TABLE Legal_GroupSteps ADD CourtID int
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Hearings' and c.name = 'CreateDate')
BEGIN
	ALTER TABLE Legal_Hearings ADD CreateDate datetime
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_Hearings' and c.name = 'GroupDebtorID')
BEGIN
	ALTER TABLE Legal_Hearings ADD GroupDebtorID int
END
GO

-- Scripts 2.5.11:

/****** Object:  Table [dbo].[Legal_Snapshots]    Script Date: 09/05/2008 14:09:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Legal_Snapshots]') AND type in (N'U'))
DROP TABLE [dbo].[Legal_Snapshots]
GO

/****** Object:  Table [dbo].[Legal_Snapshots]    Script Date: 09/05/2008 14:09:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Legal_Snapshots](
	[SnapshotID] [int] IDENTITY(1,1) NOT NULL,
	[GroupID] [int] NOT NULL,
	[GroupStepID] [int] NOT NULL,
	[SnapshotTypeID] [int] NULL,
	[DateCommenced] [datetime] NULL,
	[DateFiled] [datetime] NULL,
	[DateIssued] [datetime] NULL,
	[DebtAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_DebtAmount]  DEFAULT ((0)),
	[IntAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_IntAmount]  DEFAULT ((0)),
	[SolAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_SolAmount]  DEFAULT ((0)),
	[CrtAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_CrtAmount]  DEFAULT ((0)),
	[SerAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_SerAmount]  DEFAULT ((0)),
	[AtsAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_AtsAmount]  DEFAULT ((0)),
	[TrvAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_TrvAmount]  DEFAULT ((0)),
	[BkpAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_BkpAmount]  DEFAULT ((0)),
	[LvyAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_LvyAmount]  DEFAULT ((0)),
	[SchAmount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_SchAmount]  DEFAULT ((0)),
	[C1Amount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_C1Amount]  DEFAULT ((0)),
	[C2Amount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_C2Amount]  DEFAULT ((0)),
	[C3Amount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_C3Amount]  DEFAULT ((0)),
	[C4Amount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_C4Amount]  DEFAULT ((0)),
	[C5Amount] [money] NOT NULL CONSTRAINT [DF_Legal_Snapshots_C5Amount]  DEFAULT ((0)),
	[LastEditDate] [datetime] NOT NULL CONSTRAINT [DF_Legal_Snapshots_LastEditDate]  DEFAULT (getdate()),
	[AgentID] [int] NULL,
	[Status] [char](1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [Legal_Snapshots_RowStatus]  DEFAULT ('A'),
	[CreateDate] [datetime] NULL,
	[CourtID] [int] NULL,
 CONSTRAINT [PK_Legal_Snapshots] PRIMARY KEY CLUSTERED 
(
	[SnapshotID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Snapshots_GetPagingList]    Script Date: 09/05/2008 14:10:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Snapshots_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Snapshots_GetPagingList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Snapshots_GetPagingList]    Script Date: 09/05/2008 14:10:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [dbo].[CWX_Legal_Snapshots_GetPagingList]
	@GroupStepID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(SnapshotID)
	FROM Legal_Snapshots
	WHERE GroupStepID = @GroupStepID

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER(ORDER BY b.[Code]) as RowNumber,
				a.[SnapshotID], a.[CreateDate], a.[DebtAmount],
				b.[Code] + ' - ' + b.[Description] as SnapshotType,
				a.IntAmount, a.DateFiled, a.DateIssued
		FROM Legal_Snapshots a
		LEFT JOIN Legal_SnapshotTypes b ON a.[SnapshotTypeID] = b.[SnapshotTypeID] AND b.[Status] <> 'R'
		WHERE a.GroupStepID = @GroupStepID
	)

	SELECT 	[SnapshotID], [SnapshotType], [CreateDate], [DebtAmount], IntAmount, DateFiled, DateIssued
	FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END

GO

-- Scripts 2.5.12:

--- Thuy Nguyen added on 5-Sep-2008 --

if not exists (select * from InformationTable where InfoType = 15)
	insert into InformationTable values(1, 15, 0, '', 'EditPhoneAndAddress', '', 'False', 'A')
	
-------------------	
GO

-- =============================================
-- Description:	Get list of Group Steps ordered by Step Type
-- History:
--	2008/07/18	[Thao Nguyen]	Init version.
--	2008/09/05	[Binh Truong]	Join Legal_Courts, Legal_Agents tables.
--								Select SUM(DebtAmount), SUM(IntAmount)
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Legal_GroupSteps_GetList]
	@groupID int
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT 
			b.Code +' - '+ b.Description as CodeDesc, a.*, c.Description as CourtDesc, d.Description as AgentDesc
	FROM	
			Legal_GroupSteps a 
				LEFT JOIN Legal_GroupStepTypes b ON a.GroupStepTypeID = b.GroupStepTypeID AND b.Status <> 'R'
				LEFT JOIN Legal_Courts c ON a.CourtID = c.CourtID
				LEFT JOIN Legal_Agents d ON a.AgentID = d.AgentID		
	WHERE 
			a.GroupID = @groupID AND a.Status <> 'R'
	ORDER BY a.GroupStepID
	
	
	SELECT     SUM(DebtAmount) as TotalDebt, SUM(IntAmount) as TotalInterest
	FROM         Legal_GroupSteps
	WHERE     (GroupID = @groupID) AND (Status <> 'R') 
	
END
GO

/****** Object:  Table [dbo].[Legal_Rates]    Script Date: 09/06/2008 12:59:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Legal_Rates]') AND type in (N'U'))
DROP TABLE [dbo].[Legal_Rates]
GO
/****** Object:  Table [dbo].[Legal_Rates]    Script Date: 09/06/2008 12:59:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Legal_Rates](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[TransactionTypeID] [int] NULL,
	[RateCode] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[StartDate] [smalldatetime] NULL,
	[EndDate] [smalldatetime] NULL,
	[RateType] [tinyint] NULL,
	[RangeValue1] [money] NULL,
	[RangeValue2] [money] NULL,
	[Status] [char](1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_Legal_Rates] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_GetPagingList]    Script Date: 09/06/2008 13:00:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Rates_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Rates_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_GetPagingList]    Script Date: 09/06/2008 13:00:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 05, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Rates_GetPagingList]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
	SELECT @RowCount=COUNT(ID)
	FROM Legal_Rates
	WHERE Status <> 'R'

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY r.RateCode) AS RowNumber,
			r.*, (t.TransactionCode + ' - ' + t.Description) AS TransactionType
		FROM Legal_Rates r
		LEFT JOIN TransactionType t ON t.ID = r.TransactionTypeID
		WHERE r.Status <> 'R'
	)

	SELECT * FROM Temp WHERE (@PageSize <= 0) OR (RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize)
	
	RETURN @RowCount
END
GO

-- Scripts 2.5.14:

/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetEmployeeIDBySupervisor]    Script Date: 09/08/2008 10:34:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetEmployeeIDBySupervisor]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetEmployeeIDBySupervisor]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetEmployeeIDBySupervisor]    Script Date: 09/08/2008 10:34:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetEmployeeIDBySupervisor]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <6-September-2008>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_GetEmployeeIDBySupervisor]
	@SupervisorID int = 0
AS
BEGIN
	SELECT EmployeeID FROM Employee WHERE SupervisorID = @SupervisorID
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetLoginDetails]    Script Date: 09/08/2008 10:34:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetLoginDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetLoginDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetLoginDetails]    Script Date: 09/08/2008 10:34:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetLoginDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <6 September 2008>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_GetLoginDetails]
	@EmployeeIDString varchar(1000),
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount INT
	SET @RowCount = 0

	IF (@EmployeeIDString != '''')
	BEGIN
		DECLARE @querystring varchar(2000);
		CREATE TABLE #Temp(
			RowNumber int,
			EmployeeID int,
			EmployeeName varchar(10),
			ViewedNo int,		
			AccountIDViewing int
		);

		SET @querystring = ''INSERT INTO #Temp
			SELECT 
			ROW_NUMBER() OVER (ORDER BY  e.EmployeeID ASC) AS RowNumber,		
			e.EmployeeID, e.UserID, ISNULL(COUNT(a1.RecordID),0) AS ViewedNo, ISNULL(a2.AccountID,0) AS AccountIDViewing
			FROM Employee e 
			LEFT JOIN 
				(SELECT * FROM AccountActions 
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID=8
				) AS a1
			ON e.EmployeeID = a1.CompletedBy
			LEFT JOIN 
				(SELECT AccountID, CompletedBy FROM AccountActions AS a
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID=8
					AND DateCompleted >= (SELECT MAX(DateCompleted) FROM AccountActions
											WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
												AND CompletedBy=a.CompletedBy)
				) AS a2
			ON e.EmployeeID = a2.CompletedBy
			WHERE e.EmployeeID IN ('' + @EmployeeIDString + '')
			GROUP BY e.EmployeeID, e.UserID, a2.AccountID''
		
		EXEC (@querystring)
		
		SELECT @RowCount = @@ROWCOUNT
		
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
		
		DROP TABLE #Temp
	END
	
	RETURN @RowCount

END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_CreateGroupAccount]    Script Date: 09/08/2008 13:44:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CreateGroupAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_CreateGroupAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_CreateGroupAccount]    Script Date: 09/08/2008 13:44:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 03, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_CreateGroupAccount]
	-- Add the parameters for the stored procedure here
	@GroupID int
AS
BEGIN
		--Increase 'Account' by one
	UPDATE IdentityFields SET FieldValue = FieldValue + 1 WHERE TableName = 'Account'

	--Insert new Account with all detail from the primary account of group
	DECLARE @BillBalance money
	DECLARE @BillAmount money
	SELECT @BillBalance=SUM(a.BillBalance), @BillAmount=SUM(a.BillAmount)
	FROM Legal_GroupDebts g
	LEFT JOIN Account a ON a.AccountID = g.AccountID
	WHERE g.IsInclude=1 AND g.GroupID=@GroupID

	DECLARE @PrimaryAccountID int
	SELECT @PrimaryAccountID=AccountID FROM Legal_GroupDebts WHERE GroupID = @GroupID AND IsPrimary = 1

	DECLARE @AccountID int
	SELECT @AccountID=MAX(AccountID)+1 FROM Account

	INSERT INTO Account
	SELECT @AccountID
		  ,DebtorID
		  ,EmployeeID
		  ,ClientID
		  ,AgencyStatusID
		  ,SystemStatusID
		  ,ActionCodeID
		  ,OfficeID
		  ,MCode
		  ,CCode
		  ,@AccountID --,InvoiceNumber
		  ,AccountType
		  ,AccountClass
		  ,QueueDate
		  ,DateOfService
		  ,SubmissionDate
		  ,LastClientTransactionDate
		  ,RoutinePayment
		  ,PaymentPlan
		  ,PatientName
		  ,@BillAmount
		  ,@BillBalance
		  ,BillOtherCharges
		  ,ClientPaysLegalFees
		  ,AccountForwarded
		  ,CreditReported
		  ,CreditReportedDate
		  ,ClientPercent
		  ,ClientOCPercent
		  ,SplitPayment
		  ,CurrentAction
		  ,CurrentActionDate
		  ,NoLetterBefore
		  ,NoFeeBefore
		  ,MaintainOfficer
		  ,AccountAge
		  ,LastEditDate
		  ,LastEditBy
		  ,LastVerifyDate
		  ,AllocRuleID
		  ,AutoProcRuleID
		  ,LastExtractionDate
		  ,LastAllocationDate
		  ,LastAutoProcessDate
		  ,ExtractionRuleID
		  ,AccountForwardedTo
		  ,CurrencyCode
		  ,BatchNumber
		  ,InterestRate
		  ,ActionEmployee
		  ,LastPromiseBatch
		  ,CreditReportRequested
		  ,CreditReportRequestedBy
		  ,CreditReportRequestedOn
		  ,CreditReportRequestStatus
		  ,WriteOffDate
		  ,LastInterestDate
		  ,TempEmployeeID
		  ,OAManaged
		  ,InterfaceID
		  ,Delq_string
		  ,SortOrder
		  ,Allocated
		  ,BrokenCount
		  ,CARD_FILE_NO
		  ,ARREAR_PATH
		  ,BUCKET_TYPE
		  ,OLD_BUCKET_TYPE
		  ,CARD_TYPE
		  ,BRANCH_CODE
		  ,FORMULA
		  ,BANK_CODE
		  ,PAID
		  ,OtherAccountNo
		  ,TENOR
		  ,FORMULA_FLAG
		  ,MINIMUM_DUE
		  ,CURRENT_BKT_NUM
		  ,PREV_BKT_NUM
		  ,productivecount
		  ,contactcount
		  ,nocontactcount
		  ,DelqHistory
		  ,BucketMovement
		  ,DPDMovement
		  ,PreviousAllocRuleID
		  ,OnLeaveEmpID
		  ,LeaveLoadRelFlag
		  ,CurrentReason
		  ,CurrentReasonDate
		  ,CurrentNextAction
		  ,CurrentNextActionDate
		  ,CurrentCallResult
		  ,CurrentCallResultDate
		  ,CampaignId
		  ,CloseDate
		  ,MaxContact
		  ,AssignmentType
		  ,PoolSelected
		  ,IsPending
		FROM Account
		WHERE AccountID = @PrimaryAccountID

	--Insert into AccountOther
	INSERT INTO AccountOther
	SELECT @AccountID
		  ,Long1
		  ,Long2
		  ,Long3
		  ,Long4
		  ,Long5
		  ,Long6
		  ,Long7
		  ,Long8
		  ,Long9
		  ,Long10
		  ,Long11
		  ,Long12
		  ,Long13
		  ,Long14
		  ,Long15
		  ,Long16
		  ,Long17
		  ,Long18
		  ,Long19
		  ,Long20
		  ,Long21
		  ,Long22
		  ,Long23
		  ,Long24
		  ,Long25
		  ,Long26
		  ,Long27
		  ,Long28
		  ,Long29
		  ,Long30
		  ,Long31
		  ,Long32
		  ,Long33
		  ,Long34
		  ,Long35
		  ,Long36
		  ,Long37
		  ,Long38
		  ,Long39
		  ,Long40
		  ,Long41
		  ,Long42
		  ,Long43
		  ,Long44
		  ,Long45
		  ,Long46
		  ,Long47
		  ,Long48
		  ,Long49
		  ,Long50
		  ,Money1
		  ,Money2
		  ,Money3
		  ,Money4
		  ,Money5
		  ,Money6
		  ,Money7
		  ,Money8
		  ,Money9
		  ,Money10
		  ,Money11
		  ,Money12
		  ,Money13
		  ,Money14
		  ,Money15
		  ,Money16
		  ,Money17
		  ,Money18
		  ,Money19
		  ,Money20
		  ,Money21
		  ,Money22
		  ,Money23
		  ,Money24
		  ,Money25
		  ,Money26
		  ,Money27
		  ,Money28
		  ,Money29
		  ,Money30
		  ,Money31
		  ,Money32
		  ,Money33
		  ,Money34
		  ,Money35
		  ,Money36
		  ,Money37
		  ,Money38
		  ,Money39
		  ,Money40
		  ,Money41
		  ,Money42
		  ,Money43
		  ,Money44
		  ,Money45
		  ,Money46
		  ,Money47
		  ,Money48
		  ,Money49
		  ,Money50
		  ,Date1
		  ,Date2
		  ,Date3
		  ,Date4
		  ,Date5
		  ,Date6
		  ,Date7
		  ,Date8
		  ,Date9
		  ,Date10
		  ,Date11
		  ,Date12
		  ,Date13
		  ,Date14
		  ,Date15
		  ,Date16
		  ,Date17
		  ,Date18
		  ,Date19
		  ,Date20
		  ,Date21
		  ,Date22
		  ,Date23
		  ,Date24
		  ,Date25
		  ,Date26
		  ,Date27
		  ,Date28
		  ,Date29
		  ,Date30
		  ,Date31
		  ,Date32
		  ,Date33
		  ,Date34
		  ,Date35
		  ,Date36
		  ,Date37
		  ,Date38
		  ,Date39
		  ,Date40
		  ,Date41
		  ,Date42
		  ,Date43
		  ,Date44
		  ,Date45
		  ,Date46
		  ,Date47
		  ,Date48
		  ,Date49
		  ,Date50
		  ,String1
		  ,String2
		  ,String3
		  ,String4
		  ,String5
		  ,String6
		  ,String7
		  ,String8
		  ,String9
		  ,String10
		  ,String11
		  ,String12
		  ,String13
		  ,String14
		  ,String15
		  ,String16
		  ,String17
		  ,String18
		  ,String19
		  ,String20
		  ,String21
		  ,String22
		  ,String23
		  ,String24
		  ,String25
		  ,String26
		  ,String27
		  ,String28
		  ,String29
		  ,String30
		  ,String31
		  ,String32
		  ,String33
		  ,String34
		  ,String35
		  ,String36
		  ,String37
		  ,String38
		  ,String39
		  ,String40
		  ,String41
		  ,String42
		  ,String43
		  ,String44
		  ,String45
		  ,String46
		  ,String47
		  ,String48
		  ,String49
		  ,String50
		  ,Additional1
		  ,Additional2
		  ,Additional3
		  ,Additional4
		  ,ArrearsHistory
		FROM AccountOther
		WHERE AccountID = @PrimaryAccountID

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupDebtors_GetDefendantList]    Script Date: 09/08/2008 14:13:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupDebtors_GetDefendantList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_GroupDebtors_GetDefendantList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupDebtors_GetDefendantList]    Script Date: 09/08/2008 14:13:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Long Nguyen
-- Create date: 2008-09-04
-- Description:	Get list of Defendant of selected group
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_GroupDebtors_GetDefendantList] 
	-- Add the parameters for the stored procedure here
	@groupID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		d.GroupDebtorID, (p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
	FROM Legal_GroupDebtors d
	LEFT JOIN PersonInformation p ON d.PersonID = p.PersonID
	WHERE d.GroupID = @groupID
	ORDER BY (p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName)
END
GO

-- Scripts 2.5.15

/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupDebtors_GetDefendantList]    Script Date: 09/08/2008 17:10:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupDebtors_GetDefendantList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_GroupDebtors_GetDefendantList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupDebtors_GetDefendantList]    Script Date: 09/08/2008 17:10:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Long Nguyen
-- Create date: 2008-09-04
-- Description:	Get list of Defendant of selected group
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_GroupDebtors_GetDefendantList] 
	-- Add the parameters for the stored procedure here
	@groupID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		d.GroupDebtorID, (p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
	FROM Legal_GroupDebtors d
	LEFT JOIN PersonInformation p ON d.PersonID = p.PersonID
	WHERE d.GroupID = @groupID AND d.IsDefendant = 1
	ORDER BY (p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName)
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_TicketNote_GetPagingList]    Script Date: 09/08/2008 17:23:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketNote_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TicketNote_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TicketNote_GetPagingList]    Script Date: 09/08/2008 17:23:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TicketNote_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Long Nguyen>
-- Create date: <Aug 28, 2008>
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TicketNote_GetPagingList]
	@TicketID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
	SELECT @RowCount=COUNT(t.NoteID)
	FROM TicketNotes t INNER JOIN Employee e ON t.EmployeeID=e.EmployeeID
	WHERE t.NoteType=''M'' AND t.TicketID=@TicketID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY NoteDateTime DESC) AS RowNumber,
			NoteDateTime,NoteText,e.EmployeeName
		FROM TicketNotes t INNER JOIN Employee e ON t.EmployeeID=e.EmployeeID
		WHERE t.NoteType=''M'' AND t.TicketID=@TicketID
	)

	SELECT * FROM Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
' 
END
GO

/******  Script Closed.  ******/