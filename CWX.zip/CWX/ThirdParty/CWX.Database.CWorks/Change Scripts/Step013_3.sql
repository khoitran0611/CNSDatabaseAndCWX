 -- Scripts are applied on version 1.8.4
 
 /****** Object:  StoredProcedure [dbo].[CWX_BroadCast_GetNewBroadCast]    Script Date: 06/06/2008 10:09:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_BroadCast_GetNewBroadCast]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_BroadCast_GetNewBroadCast]
GO
/****** Object:  StoredProcedure [dbo].[CWX_BroadCast_GetNewBroadCast]    Script Date: 06/06/2008 10:10:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: June 05, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_BroadCast_GetNewBroadCast] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RoleID int
	DECLARE @DepartmentID int

	SELECT @RoleID = RoleID, @DepartmentID = Department
	FROM Employee
	WHERE EmployeeID = @EmployeeID

	SELECT b.*
	FROM BroadCast b
	WHERE
		(
			--RoleID = -1: a supervisor send broadcast message to his collectors
			(b.RoleID = -1 AND @EmployeeID IN (SELECT EmployeeID FROM Employee WHERE SuperVisorId = b.FromEmployee))
			--DeptID = 0 AND RoleID = 0: Broadcast message send to all employees
			OR (DeptID = 0 AND RoleID = 0)
			OR (DeptID = @DepartmentID OR RoleID = @DepartmentID)
		)
		AND (DATEDIFF(mi, DisplayOn, GETDATE()) >= 0)
		AND (DATEDIFF(mi, ExpireOn, GETDATE()) < 0)
END
GO

/******  Script Closed. Go next: Step013_4  ******/