﻿ -- Scripts are applied on version 1.7.20
 /****** Object:  StoredProcedure [dbo].[CWX_DepartmentProductAccess_Save]    Script Date: 05/28/2008 18:09:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DepartmentProductAccess_Save]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DepartmentProductAccess_Save]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DepartmentProductAccess_Save]    Script Date: 05/28/2008 18:09:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DepartmentProductAccess_Save]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<khoa dang>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DepartmentProductAccess_Save]
	@ClientID int,
	@DeptIDList varchar(500)
AS
BEGIN
begin tran
	delete from DepartmentProductAccess where ClientID = @ClientID	

	declare @DeptPos int, @DeptID int
	set @DeptPos = patindex(''%,%'', @DeptIDList)

	while @DeptPos <> 0
	begin
		/* get DeptID in the list */
		set @DeptID = cast(left(@DeptIDList, @DeptPos - 1) as int)
		set @DeptIDList = stuff(@DeptIDList, 1, @DeptPos, '''')
		set @DeptPos = patindex(''%,%'' , @DeptIDList)
		
		/* save data */
		insert into DepartmentProductAccess(ClientID, DeptID) values(@ClientID, @DeptID)
		if (@@error <> 0)
		begin
			rollback tran
			return
		end
	end
	
	/* save last data */
	insert into DepartmentProductAccess(ClientID, DeptID) values(@ClientID, @DeptIDList)
commit
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_DepartmentProductAccess_Select]    Script Date: 05/28/2008 18:09:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DepartmentProductAccess_Select]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DepartmentProductAccess_Select]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DepartmentProductAccess_Select]    Script Date: 05/28/2008 18:09:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DepartmentProductAccess_Select]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<khoa dang>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DepartmentProductAccess_Select]
	@ClientID int
AS
BEGIN
	select DeptID from DepartmentProductAccess where ClientID = @ClientID
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 05/27/2008 14:42:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetListByRule]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 05/27/2008 14:43:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 24, 2008
-- Description:	Retrieve records that match the rulecriterias of a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetListByRule] 
	-- Add the parameters for the stored procedure here
	@RuleID int,
	@PageSize int = 0,
	@PageIndex int = 0,
	@ProcessedAccountIDs varchar(4000) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat, Combining
		FROM RuleCriteria
		WHERE RuleID = @RuleID

	DECLARE @SQLFormat varchar(700)
	DECLARE @Combining varchar(10)
	DECLARE @NeedCombining varchar(10)
	DECLARE @WhereClause varchar(2000)
	SET @NeedCombining = 'And'

	OPEN RuleCriteriaCrsr
	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @WhereClause = ISNULL(@WhereClause, '') + ' ' + @NeedCombining + ' ' + @SQLFormat
		SET @NeedCombining = @Combining /* remember previous value */

		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	END

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr

	--Remove the Account that was processed
	IF @ProcessedAccountIDs IS NOT NULL AND @ProcessedAccountIDs <> ''
	BEGIN
		SELECT CAST(SplitedText AS int) AS AccountID
		INTO #ProcessedAccountIDs
		FROM CWX_FnSplitString(@ProcessedAccountIDs, '|')

		SET @WhereClause = @WhereClause + ' AND Account.AccountId NOT IN (SELECT AccountID FROM #ProcessedAccountIDs)'
	END

	--This is used for AllocationRule, if RuleType=1, append condition <Account.MAINTAINOFFICER = 0>
	DECLARE @RuleType tinyint
	SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID
	IF @RuleType = 1
		SET @WhereClause = ' AND Account.MAINTAINOFFICER = 0' + @WhereClause

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY PRIMARY KEY,
		AccountId int,
		DebtorId int,
		FirstName varchar(50),
		MiddleName varchar(50),
		LastName varchar(50),
		BillBalance money,
		BillAmount money,
		InvoiceNumber varchar(50)
	)

	DECLARE @Sql varchar(4000)

	SET @Sql = 'INSERT INTO #Temp'
				+ ' SELECT'
				+ ' Account.AccountId,Account.DebtorId,PersonInformation.FirstName,PersonInformation.MiddleName,PersonInformation.LastName,Account.BillBalance,Account.BillAmount,Account.InvoiceNumber'
				+ ' FROM Account'
				+ ' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID'
				+ ' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID'
				+ ' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID'
				+ ' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID'
				+ ' WHERE (PersonAddress.MailingAddress = 1)'
				+ @WhereClause
				+ ' ORDER BY Account.AccountId'


	EXEC (@Sql)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	DROP TABLE #Temp

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 05/27/2008 16:08:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByQueueSStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 05/27/2008 16:08:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_SystemStatus int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		KeyField varchar(30),
		QueueDate smalldatetime,
		DPD int,
		Bucket char(1),
		Cycle smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		Status varchar(10),
		Priority int,
		[Assignment Type] char(1),
		[ID] varchar(25),
		[Name] varchar(200)
	)

    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.AccountAge AS [DPD],'
				+ '   CAST(a.MCode AS CHAR(1)) AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN Accountother o ON o.AccountID = a.AccountID'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId as varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID <> 2'

	IF @v_SystemStatus = 0 
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'+''
	ELSE
		SET @cStmt=@cStmt+' AND s.SystemStatus = '+CAST(@v_SystemStatus AS char(9))+''

	--Build OrderByClause
	SET @cStmt=@cStmt+' ORDER BY '
	DECLARE @v_SortOrder varchar(700)

	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
       Set @cStmt = @cStmt + ' "QueueDate" DESC'
    ELSE
       Set @cStmt = @cStmt + @v_SortOrder

	EXEC (@cStmt)

	DECLARE @RowCount int
	SET @RowCount = @@ROWCOUNT

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	--Paging
	SELECT
		KeyField,
		QueueDate,
		DPD,
		Bucket,
		Cycle,
		[Bill Amount],
		[Bill Balance],
		Status,
		Priority,
		[Assignment Type],
		[ID],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	DROP TABLE #Temp

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueAStat]    Script Date: 05/27/2008 16:12:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByQueueAStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueAStat]    Script Date: 05/27/2008 16:12:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_AgencyStatus int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		KeyField varchar(30),
		QueueDate smalldatetime,
		DPD int,
		Bucket char(1),
		Cycle smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		Status varchar(10),
		Priority int,
		[Assignment Type] char(1),
		[ID] varchar(25),
		[Name] varchar(200)
	)

    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.AccountAge AS [DPD],'
				+ '   CAST(a.MCode AS CHAR(1)) AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN AccountOther o ON o.AccountID = a.AccountID'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId AS varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID = '+CAST(@v_AgencyStatus AS varchar(9))

	--Build OrderByClause
	SET @cStmt=@cStmt+' ORDER BY '
	DECLARE @v_SortOrder varchar(700)

	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
       Set @cStmt = @cStmt + ' "QueueDate" DESC'
    ELSE
       Set @cStmt = @cStmt + @v_SortOrder

	EXEC (@cStmt)

	DECLARE @RowCount int
	SET @RowCount = @@ROWCOUNT

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	SELECT
		KeyField,
		QueueDate,
		DPD,
		Bucket,
		Cycle,
		[Bill Amount],
		[Bill Balance],
		Status,
		Priority,
		[Assignment Type],
		[ID],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	DROP TABLE #Temp

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTickets]    Script Date: 05/27/2008 17:41:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetTickets]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetTickets]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTickets]    Script Date: 05/27/2008 17:41:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetTickets] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@TicketClass int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Ticket t
	INNER JOIN TicketStatus s ON s.TicketStatusID = t.TicketStatus
	INNER JOIN Employee e ON e.EmployeeID = t.Requester
	INNER JOIN Employee f ON f.EmployeeID = t.AssignedTo
	INNER JOIN Account a ON a.AccountID = t.AccountID
	WHERE
		(((@TicketClass = 1) and (t.CurrentEmployeeID = @EmployeeID)) or ((@TicketClass = 0) and (t.Requester = @EmployeeID)))
		AND t.TicketStatus <> 9

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  t.TicketID) AS RowNumber,
			CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID) + '|' + CONVERT(varchar(10), t.TicketID) AS KeyField,
			t.TicketID AS [Ticket ID],
			e.EmployeeName AS [Requester],
			f.EmployeeName AS [Assign To],
			t.CurrentStage AS [Current Stage],
			t.TotalStage AS [Total Stage],
			t.RequestDate AS [Request Date],
			t.StartDate AS [Start Date],
			t.DueDate AS [Due Date],
			s.Description AS [Ticket Status],
			CASE t.Priority
				WHEN 0 THEN 'Low'
				WHEN 1 THEN 'Mediuem'
				WHEN 2 THEN 'High'
			END AS Priority
		--INTO #Temp
		FROM Ticket t
		INNER JOIN TicketStatus s ON s.TicketStatusID = t.TicketStatus
		INNER JOIN Employee e ON e.EmployeeID = t.Requester
		INNER JOIN Employee f ON f.EmployeeID = t.AssignedTo
		INNER JOIN Account a ON a.AccountID = t.AccountID
		WHERE
			(((@TicketClass = 1) and (t.CurrentEmployeeID = @EmployeeID)) or ((@TicketClass = 0) and (t.Requester = @EmployeeID)))
			AND t.TicketStatus <> 9
	)

	SELECT
		KeyField,
		[Ticket ID],
		[Requester],
		[Assign To],
		[Current Stage],
		[Total Stage],
		[Request Date],
		[Start Date],
		[Due Date],
		[Ticket Status],
		Priority
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount

END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByAllocQueue]    Script Date: 05/27/2008 18:00:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByAllocQueue]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByAllocQueue]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByAllocQueue]    Script Date: 05/27/2008 18:00:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByAllocQueue] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@v_AllocRule int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	WHERE
		(a.EmployeeID = @v_EmployeeId OR a.TempEmployeeID = @v_EmployeeId)
		AND a.AllocRuleID = @v_AllocRule
		AND a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.QueueDate desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			(a.EmployeeID = @v_EmployeeId OR a.TempEmployeeID = @v_EmployeeId)
			AND a.AllocRuleID = @v_AllocRule
			AND a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchReviewAccounts]    Script Date: 05/27/2008 18:06:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchReviewAccounts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchReviewAccounts]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchReviewAccounts]    Script Date: 05/27/2008 18:06:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchReviewAccounts] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeID
	WHERE
		a.ActionEmployee = @v_EmployeeId
		AND a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND a.AgencyStatusID <> 2

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			e.EmployeeName [Referred From]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeID
		WHERE
			a.ActionEmployee = @v_EmployeeId
			AND a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Referred From]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SVByEmployee]    Script Date: 05/27/2008 18:12:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SVByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SVByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SVByEmployee]    Script Date: 05/27/2008 18:13:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 10, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SVByEmployee] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@CollectorID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
	INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
	WHERE
		e.Supervisor = 1
		AND (a.EmployeeID = @CollectorID OR a.TempEmployeeID = @CollectorID)
		AND a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND a.AgencyStatusID <> 2

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.QueueDate desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			g.UserID [Collector ID]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
		INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
		WHERE
			e.Supervisor = 1
			AND (a.EmployeeID = @CollectorID OR a.TempEmployeeID = @CollectorID)
			AND a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Collector ID]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueByAmtRange]    Script Date: 05/28/2008 09:54:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_QueueByAmtRange]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_QueueByAmtRange]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueByAmtRange]    Script Date: 05/28/2008 09:54:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_QueueByAmtRange] 
	-- Add the parameters for the stored procedure here
	@v_Range int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		[KeyField] varchar(30),
		[QueueDate] char(10),
		[Account Number] varchar(50),
		[DPD] int,
		[Bucket] char(1),
		[Cycle] smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		[Status] varchar(10),
		[Priority] int,
		[Assignment Type] char(1),
		[Name] varchar(200)
	)
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate <= getDate()'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

				if ((@EmpList <> '') and (@EmpList <> 'Null'))
				Begin
					SET @cStmt=@cStmt+' AND a.EmployeeID in (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(''' + @EmpList + ''',' + '''' + ',' + '''' + '))'
				End

				if @v_Range = 1
				Begin
					SET @cStmt = @cStmt +'   AND a.BillBalance < 10000'
				End

				if @v_Range = 2
				Begin
					SET @cStmt = @cStmt +'  AND a.BillBalance >= 10000'
					SET @cStmt = @cStmt +'  AND a.BillBalance < 25000'
				End

				if @v_Range = 3
				Begin
					SET @cStmt = @cStmt +'	AND a.BillBalance >= 25000'
					SET @cStmt = @cStmt +'	AND a.BillBalance < 50000'		
				End

				if @v_Range = 4
				Begin
					SET @cStmt = @cStmt +'	AND a.BillBalance >= 50000'
					SET @cStmt = @cStmt +'	AND a.BillBalance < 150000'		
				End

				if @v_Range = 5
				Begin
					SET @cStmt = @cStmt +'	AND a.BillBalance >= 150000'
				End

				Set @cStmt = @cStmt + ' Order by a.QueueDate DESC'
				EXEC (@cStmt)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	DROP TABLE #Temp

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueFuture]    Script Date: 05/28/2008 10:00:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_QueueFuture]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_QueueFuture]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueFuture]    Script Date: 05/28/2008 10:01:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_QueueFuture] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@Days int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		[KeyField] varchar(30),
		[QueueDate] char(10),
		[Account Number] varchar(50),
		[DPD] int,
		[Bucket] char(1),
		[Cycle] smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		[Status] varchar(10),
		[Priority] int,
		[Assignment Type] char(1),
		[Name] varchar(200)
	)
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.EmployeeID = ' + CAST(@EmployeeID AS varchar(10))
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

--Today|2|GE Today|0|Tomorrow|1|3 Days|3|5 Days|5

				if (@Days = 1) or (@Days = 3) or (@Days = 5)
				Begin
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) <= dateadd(day,' + CAST(@Days AS varchar(10)) + ', getdate())'
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) >= getdate()'
				End

				if @Days = 2
				Begin
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) = getdate()'
				End

				if @Days = 0
				Begin
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) >= getdate()'
				End

				Set @cStmt = @cStmt + ' Order by a.QueueDate DESC'
				EXEC (@cStmt)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	DROP TABLE #Temp

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByName]    Script Date: 05/28/2008 10:14:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchDebtorByName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchDebtorByName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByName]    Script Date: 05/28/2008 10:14:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchDebtorByName] 
	-- Add the parameters for the stored procedure here
	@DebtorName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	WHERE
		a.DebtorID <> 0
		AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) AS [Name],
			a.QueueDate AS [QueueDate],
			a.AccountAge AS [DPD],
			CAST(a.MCode AS CHAR(2)) AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			a.Minimum_due AS [Minimum Due],
			p.SocialSecurityNumber AS [ID]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
	)

	SELECT
		KeyField,
		[Name],
		[QueueDate],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Minimum Due],
		[ID]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_Queue_NoActivityInXDays]    Script Date: 05/28/2008 10:24:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_Queue_NoActivityInXDays]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_Queue_NoActivityInXDays]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_Queue_NoActivityInXDays]    Script Date: 05/28/2008 10:24:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_Queue_NoActivityInXDays] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lNumberOfDays int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			CAST(a.MCode AS CHAR(2)) AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			e.EmployeeName As [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()))
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_Queue_NoContactInXDays]    Script Date: 05/28/2008 10:45:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_Queue_NoContactInXDays]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_Queue_NoContactInXDays]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_Queue_NoContactInXDays]    Script Date: 05/28/2008 10:45:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_Queue_NoContactInXDays] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lNumberOfDays int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()) and ActionID in (select ActionID from AvailableActions where productivityid = 3))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			CAST(a.MCode AS CHAR(2)) AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			e.EmployeeName As [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()) and ActionID in (select ActionID from AvailableActions where productivityid = 3))
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByEmployeeName]    Script Date: 05/28/2008 10:53:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByEmployeeName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByEmployeeName]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByEmployeeName]    Script Date: 05/28/2008 10:54:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByEmployeeName] 
	-- Add the parameters for the stored procedure here
	@EmployeeName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
	WHERE
		a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			g.EmployeeName AS [Employee Name],
			a.QueueDate AS [QueueDate],
			a.AccountAge AS [DPD],
			CAST(a.MCode AS CHAR(2)) AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			a.Minimum_due AS [Minimum Due],
			p.SocialSecurityNumber AS [ID],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [ Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
		WHERE
			a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
	)

	SELECT
		KeyField,
		[Employee Name],
		[QueueDate],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Minimum Due],
		[ID],
		[ Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralItemType]    Script Date: 05/28/2008 11:18:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchCollateralItemType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchCollateralItemType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralItemType]    Script Date: 05/28/2008 11:19:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchCollateralItemType] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@ItemID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND c.CollateralType = @ItemID

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			CAST(a.MCode AS CHAR(2)) AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND c.CollateralType = @ItemID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralStage]    Script Date: 05/28/2008 14:07:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchCollateralStage]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchCollateralStage]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralStage]    Script Date: 05/28/2008 14:07:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchCollateralStage] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@cStageID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND c.CollateralStage = @cStageID 

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			CAST(a.MCode AS CHAR(2)) AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND c.CollateralStage = @cStageID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralNextAction]    Script Date: 05/28/2008 14:11:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchCollateralNextAction]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchCollateralNextAction]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchCollateralNextAction]    Script Date: 05/28/2008 14:11:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchCollateralNextAction] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@cNextAction int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND c.NextAction = @cNextAction 

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			CAST(a.MCode AS CHAR(2)) AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND c.NextAction = @cNextAction
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 05/28/2008 14:21:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalForward]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByLegalForward]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 05/28/2008 14:21:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalForward] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lClientID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
    INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND l.ClientID = @lClientID 
		AND a.EmployeeID = @v_employeeId

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			CAST(a.MCode AS CHAR(2)) AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m.CodeDesc as [Next Action],
			l.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
		INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND l.ClientID = @lClientID 
			AND a.EmployeeID = @v_employeeId
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalEmployee]    Script Date: 05/28/2008 14:41:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByLegalEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalEmployee]    Script Date: 05/28/2008 14:41:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalEmployee] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
    INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND l.EmployeeID = @v_employeeId

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			CAST(a.MCode AS CHAR(2)) AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m.CodeDesc as [Next Action],
			l.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
		INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND l.EmployeeID = @v_employeeId
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalNextAction]    Script Date: 05/28/2008 14:48:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByLegalNextAction]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByLegalNextAction]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalNextAction]    Script Date: 05/28/2008 14:48:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByLegalNextAction] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@NextAction int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
    INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND l.NextAction = @NextAction

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			CAST(a.MCode AS CHAR(2)) AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m.CodeDesc as [Next Action],
			l.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		INNER JOIN AccountLegal l ON l.EmployeeID = e.EmployeeID and l.AccountID = a.AccountID
		INNER JOIN AccountCodeMaster m ON m.CodeID = l.NextAction
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND l.NextAction = @NextAction
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO
UPDATE QueryParams
SET PickList = 'select EmployeeID, EmployeeName from Employee where EmployeeStatus = ''A'' order by EmployeeName'
WHERE QueryID = 20

UPDATE QueryParams
SET PickList = 'select EmployeeID, EmployeeName from Employee where EmployeeStatus = ''A'' order by EmployeeName'
WHERE QueryID = 24

UPDATE QueryMaster
SET SQL2 = 'EXEC CWX_Account_SearchByLegalEmployee %1, %2'
WHERE ID = 24
GO

/****** Object:  StoredProcedure [dbo].[CWX_Product_LetterHeadImage_Get]    Script Date: 05/29/2008 13:27:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_LetterHeadImage_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_LetterHeadImage_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Product_LetterHeadImage_Get]    Script Date: 05/29/2008 13:27:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_LetterHeadImage_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		khoa dang
-- =============================================
CREATE PROCEDURE CWX_Product_LetterHeadImage_Get
	@ClientID int
AS
BEGIN
	SELECT LetterheadImage FROM ClientInformation
		where ClientID=@ClientID
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Product_LetterHeadImage_Save]    Script Date: 05/29/2008 13:27:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_LetterHeadImage_Save]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_LetterHeadImage_Save]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Product_LetterHeadImage_Save]    Script Date: 05/29/2008 13:27:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_LetterHeadImage_Save]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<khoa dang>
-- =============================================
CREATE PROCEDURE CWX_Product_LetterHeadImage_Save
	@ClientID int, 
	@LetterHeadImage image
AS
BEGIN
	update ClientInformation set LetterheadImage=@LetterHeadImage
		where ClientID=@ClientID
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_WebLanguages_SetOptionalLanguage]    Script Date: 05/29/2008 12:05:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WebLanguages_SetOptionalLanguage]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WebLanguages_SetOptionalLanguage]
GO
CREATE PROCEDURE [dbo].[CWX_WebLanguages_SetOptionalLanguage] 	
	@languageID int = 0	
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE WebLanguages SET UseThisLanguage = 0 WHERE UseThisLanguage = 1 and LanguageID <> 0
	UPDATE WebLanguages SET UseThisLanguage = 1 WHERE LanguageID = @languageID
END

GO
/****** Object:  Alter Table WebLanguages    Script Date: 05/29/2008 12:05:51 ******/
IF NOT EXISTS (SELECT * FROM dbo.syscolumns WHERE name='Culture' or name='LanguageIconURL' or name='LanguageIconActiveURL' and id = (SELECT id FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[WebLanguages]') and OBJECTPROPERTY(id, N'IsUserTable') = 1))
ALTER TABLE WebLanguages ADD Culture VARCHAR(5) NOT NULL DEFAULT 'en-US', 
									LanguageIconURL VARCHAR(100) NOT NULL DEFAULT 'images/lang_english.gif',
									LanguageIconActiveURL  VARCHAR(100) NOT NULL DEFAULT 'images/lang_english0.gif';

ALTER TABLE WebLanguages ALTER COLUMN LanguageName NVARCHAR(50) NOT NULL;
									
GO

/****** Insert gold data to CWX_WebLanguages    Script Date: 05/29/2008 12:05:51 ******/
IF NOT EXISTS (SELECT * FROM WebLanguages WHERE LanguageID = 0)
	INSERT INTO WebLanguages VALUES(1, 0, 'English', 1, 'en-US', 'images/lang_english.gif', 'images/lang_englisho.gif')

IF NOT EXISTS (SELECT * FROM WebLanguages WHERE LanguageID = 1)
	INSERT INTO WebLanguages VALUES(2, 1, N'Tiếng Việt', 1, 'vi-VN', 'images/lang_vietnamese.gif', 'images/lang_vietnameseo.gif')

IF NOT EXISTS (SELECT * FROM WebLanguages WHERE LanguageID = 2)
	INSERT INTO WebLanguages VALUES(3, 2, 'French', 0, 'fr-FR', 'images/lang_french.gif', 'images/lang_frencho.gif')
	
IF NOT EXISTS (SELECT * FROM WebLanguages WHERE LanguageID = 2)
	INSERT INTO WebLanguages VALUES(3, 2, N'العربية', 0, 'ar-SA', 'images/lang_arabian.gif', 'images/lang_arabiano.gif')	

/******  Script Closed  ******/