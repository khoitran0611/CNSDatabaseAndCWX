-- Scripts are applied on version 1.5.2

/****** Object:  StoredProcedure [dbo].[CWX_Notes_GetWithType]    Script Date: 04/29/2008 02:21:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Notes_GetWithType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Notes_GetWithType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Notes_GetWithType]    Script Date: 04/28/2008 09:24:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Tai Ly
-- Create date: April 29, 1008
-- Description:	Get notes from database	with type
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Notes_GetWithType] 	
	-- Add the parameters for the stored procedure here
	@DebtorID	int,
	@AccountID	int,
	@NoteText	varchar(256) = '',
	@NoteType	varchar(1) = ' ',	
	@Month		int = -1,
	@Day		int = -1,
	@FromDate	datetime = '1753-01-01',
	@ToDate		datetime = '9999-12-31',
	@PageSize	int = 10,
	@PageIndex	int = 0
AS
BEGIN
	Declare @IdentityTableValue int

	DECLARE @TempTableVar table(
		RowNumber		int,
		NoteDateTime	datetime,
		NoteText		varchar(700),
		NoteType		varchar(1),
		UserID			varchar(10)
	);

	Set @IdentityTableValue = (Select FieldValue from IdentityFields where TableName = 'NotesDisplayByAccount')
	IF (@IdentityTableValue <= 0 )
	BEGIN 						
			IF (@IdentityTableValue < 0)
			BEGIN
				Insert into IdentityFields values('NotesDisplayByAccount',0)
			END
			IF (@NoteType = ' ') -- all note type			
			BEGIN						
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN								
					IF @NoteText = ''
					BEGIN												
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate)								
							ORDER BY	n.NoteDateTime DESC, n.NoteID			
					END	
					ELSE
					BEGIN
						SELECT @NoteText = '%' + @NoteText + '%';											
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate)								
										AND n.NoteText LIKE @NoteText
							ORDER BY	n.NoteDateTime DESC, n.NoteID			
					END				
				END
				ELSE IF @Month = -1	-- no month input
				BEGIN					
					IF @NoteText = ''
					BEGIN						
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID 
										AND (DAY(DATEADD(day, @Day, n.NoteDateTime)) = DAY(GETDATE()) AND 
											 MONTH(DATEADD(day, @Day, n.NoteDateTime)) = MONTH(GETDATE()) AND
											 YEAR(DATEADD(day, @Day, n.NoteDateTime)) = YEAR(GETDATE())												
											)
							ORDER BY	n.NoteDateTime DESC, n.NoteID			
					END
					ELSE
					BEGIN						
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID 
										AND n.NoteText LIKE @NoteText AND							
										(DAY(DATEADD(day, @Day, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(day, @Day, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(day, @Day, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID				
					END
				END
				ELSE	-- no day input
				BEGIN					
					IF @NoteText =''
					BEGIN						
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND 
										(DAY(DATEADD(month, @Month, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(month, @Month, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(month, @Month, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID			
					END
					ELSE
					BEGIN						
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID 
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(month, @Month, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(month, @Month, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(month, @Month, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID				
					END
				END
			END
			ELSE
			BEGIN	-- has note type
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN
					IF @NoteText = ''
					BEGIN
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate)
							ORDER BY	n.NoteDateTime DESC, n.NoteID			
					END
					ELSE
					BEGIN
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) AND n.NoteText LIKE @NoteText
							ORDER BY	n.NoteDateTime DESC, n.NoteID				
					END
				END
				ELSE IF @Month = -1		-- no month input
				BEGIN
					IF @NoteText = ''
					BEGIN
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType) AND 
										(DAY(DATEADD(day, @Day, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(day, @Day, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(day, @Day, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID			
					END
					ELSE
					BEGIN
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(day, @Day, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(day, @Day, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(day, @Day, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID			
					END
				END
				ELSE -- no day input
				BEGIN
					IF @NoteText = ''
					BEGIN
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType) AND 										
										(DAY(DATEADD(month, @Month, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(month, @Month, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(month, @Month, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID			
					END
					ELSE
					BEGIN
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(month, @Month, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(month, @Month, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(month, @Month, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID			
					END
				END
			END
	END	
	ELSE		
	BEGIN
			IF (@NoteType = ' ')	-- no note type			
			BEGIN
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN
					IF @NoteText = ''
					BEGIN
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) 
							ORDER BY	n.NoteDateTime DESC, n.NoteID
					END
					ELSE
					BEGIN
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) 
										AND n.NoteText LIKE @NoteText
							ORDER BY	n.NoteDateTime DESC, n.NoteID
					END
				END
				ELSE IF (@Month = -1)	-- no month input
				BEGIN
					IF @NoteText = ''
					BEGIN
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID AND
										(DAY(DATEADD(day, @Day, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(day, @Day, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(day, @Day, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID
					END
					ELSE
					BEGIN
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID 
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(day, @Day, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(day, @Day, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(day, @Day, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID
					END
				END
				ELSE	-- no day input
				BEGIN
					IF @NoteText = ''
					BEGIN
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID AND
										(DAY(DATEADD(month, @Month, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(month, @Month, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(month, @Month, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID
					END	
					ELSE
					BEGIN
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(month, @Month, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(month, @Month, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(month, @Month, n.NoteDateTime)) = YEAR(GETDATE())												
										)								
							ORDER BY	n.NoteDateTime DESC, n.NoteID
					END
				END				
			END
			ELSE	-- has note type
			BEGIN
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN
					IF (@NoteText = '')
					BEGIN
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  AND UPPER(NoteType) = UPPER(@NoteType) 
										AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) 
							ORDER BY	n.NoteDateTime DESC, n.NoteID
					END
					ELSE
					BEGIN
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  AND UPPER(NoteType) = UPPER(@NoteType) 
										AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) AND n.NoteText LIKE @NoteText
							ORDER BY	n.NoteDateTime DESC, n.NoteID
					END
				END
				ELSE IF @Month = -1			-- no month input
				BEGIN
					IF @NoteText = ''
					BEGIN
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  AND UPPER(NoteType) = UPPER(@NoteType) AND
										(DAY(DATEADD(day, @Day, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(day, @Day, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(day, @Day, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID						
					END
					ELSE
					BEGIN
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  AND UPPER(NoteType) = UPPER(@NoteType) 
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(day, @Day, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(day, @Day, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(day, @Day, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID						
					END
				END
				ELSE						-- no day input
				BEGIN
					IF @NoteText = ''
					BEGIN
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType) AND
										(DAY(DATEADD(month, @Month, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(month, @Month, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(month, @Month, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID						
					END
					ELSE
					BEGIN
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(month, @Month, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(month, @Month, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(month, @Month, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID						
					END
				END					
			END
	END		

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
	ELSE
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
		WHERE	RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize		

	RETURN @RowCount

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_LoadTransactionTypeForAccount]    Script Date: 05/02/2008 11:20:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoadTransactionTypeForAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LoadTransactionTypeForAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_LoadTransactionTypeForAccount]    Script Date: 05/02/2008 11:20:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		KhoaDuong
-- Create date: May 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LoadTransactionTypeForAccount] 
	-- Add the parameters for the stored procedure here
	@AccountID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    Select t.* From TransactionType t, Account a Where t.ClientID  = a.ClientID And  t.ClientID = 0 and a.AccountID = @AccountID 
	
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseStat]    Script Date: 05/02/2008 16:52:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetPromiseStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseStat]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseStat]    Script Date: 05/02/2008 16:52:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetPromiseStat]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Binh Truong
-- Create date: Apr 29, 2008
-- Description:	
-- =============================================
create PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseStat] 	
(
	@EmployeeID int = 0,
	@From datetime = NULL,
	@To datetime = NULL
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @Statement NVARCHAR(4000)
	DECLARE @Select NVARCHAR(1000)
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @GroupBy NVARCHAR(50)
	DECLARE @OrderBy NVARCHAR(50)
	DECLARE @Parms NVARCHAR(500)
	
	SET @Select = ''	
		SELECT		Status, COUNT(*) AS AccountAmount, SUM(AmountPromised) AS Promised, SUM(AmountPaid) AS Paid
		FROM        AccountPromise
		''
	SET @Conditions = '' WHERE (1=1) ''
	SET @GroupBy = '' GROUP BY Status ''
	SET @OrderBy = '' ORDER BY Status ''
	
	IF @EmployeeID <> 0
	BEGIN
		SET @Conditions = @Conditions +
			''
			AND EmployeeID = @EmployeeID
			''
	END
	
	IF @From IS NOT NULL
	BEGIN
		SET @To = DATEADD(day, 1, @To)
		SET @Conditions = @Conditions +
			''
			AND (DatePromised >= @From AND DatePromised < @To)
			''	
	END
	
	SET @Statement = @Select + @Conditions + @GroupBy + @OrderBy
	
	SET @Parms = ''
			@EmployeeID int,
			@From datetime,
			@To datetime
			''
	
	EXEC dbo.sp_executesql @Statement, @Parms,
							@EmployeeID,
							@From,
							@To
	
END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetBrokenPromiseList]    Script Date: 05/02/2008 16:51:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetBrokenPromiseList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetBrokenPromiseList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetBrokenPromiseList]    Script Date: 05/02/2008 16:51:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: May 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetBrokenPromiseList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
		p.PromiseID,
		p.AccountID,
		p.AmountPromised,
		p.DatePromised,
		p.Status,
		p.AmountPaid,
		p.DatePaid,
		p.Period,
		p.Term,
		p.PromiseFrequency,
		e.EmployeeName
	INTO #Temp
	FROM AccountPromise p
	INNER JOIN Employee e ON p.EmployeeID = e.EmployeeID
	WHERE
		p.Status = 3
		AND p.AccountID = @AccountID

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseDueList]    Script Date: 05/02/2008 16:51:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetPromiseDueList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseDueList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseDueList]    Script Date: 05/02/2008 16:51:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: May 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseDueList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
		p.PromiseID,
		p.AccountID,
		p.AmountPromised,
		p.DatePromised,
		p.Status,
		p.AmountPaid,
		p.DatePaid,
		p.Period,
		p.Term,
		p.PromiseFrequency,
		e.EmployeeName,
		a.CodeDesc as PromiseGiver
	INTO #Temp
	FROM AccountPromise p
	INNER JOIN Employee e ON p.EmployeeID = e.EmployeeID
	INNER JOIN AccountCodeMaster a ON p.PromiseGiver = a.CodeID
	WHERE
		p.Status = 0
		AND p.AccountID = @AccountID

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseHistoryList]    Script Date: 05/02/2008 16:51:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetPromiseHistoryList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseHistoryList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseHistoryList]    Script Date: 05/02/2008 16:51:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: May 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseHistoryList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
		p.PromiseID,
		p.AccountID,
		p.AmountPromised,
		p.DatePromised,
		p.Status,
		p.AmountPaid,
		p.DatePaid,
		p.Period,
		p.Term,
		p.PromiseFrequency,
		e.EmployeeName
	INTO #Temp
	FROM AccountPromise p
	INNER JOIN Employee e ON p.EmployeeID = e.EmployeeID
	WHERE
		p.Status in (1,2)
		AND p.AccountID = @AccountID

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_ReportScheduleTable_Insert]    Script Date: 05/02/2008 17:59:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ReportScheduleTable_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ReportScheduleTable_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ReportScheduleTable_GetCustomPagingList]    Script Date: 05/02/2008 17:59:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ReportScheduleTable_GetCustomPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ReportScheduleTable_GetCustomPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ReportScheduleTable_Insert]    Script Date: 05/02/2008 17:59:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ReportScheduleTable_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.CWX_ReportScheduleTable_Insert
	@ReportID int,
	@ScheduleType varchar(10),
	@Description varchar(100), 
	@ScheduleStatus int,
	@ScheduledDay int,
	@BeginDate smalldatetime,
	@EndDate smalldatetime,	
	@ReturnedValue int output
AS
BEGIN
	INSERT ReportScheduleTable (ReportID, ScheduleType, Description, ScheduleStatus, ScheduledDay, BeginDate, EndDate)
	VALUES (@ReportID, @ScheduleType, @Description, @ScheduleStatus, @ScheduledDay, @BeginDate, @EndDate)
	
	SELECT @ReturnedValue = ID FROM ReportScheduleTable
	WHERE	ReportID = @ReportID 
			AND ScheduleType = @ScheduleType 
			AND Description = @Description
			AND ScheduleStatus = @ScheduleStatus
			AND ScheduledDay = @ScheduledDay 
			AND BeginDate = @BeginDate 
			AND EndDate = @EndDate
	
END

	' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_ReportScheduleTable_GetCustomPagingList]    Script Date: 05/02/2008 17:59:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ReportScheduleTable_GetCustomPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.CWX_ReportScheduleTable_GetCustomPagingList 
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SELECT ROW_NUMBER() OVER (ORDER BY r.ID) AS RowNumber,
			r.ID, 
			r.ReportID, 
			r.ScheduleType, 
			r.Description, 
			r.ScheduleStatus, 
			r.ScheduledDay, 
			r.BeginDate, 
			r.EndDate, 
			d.LetterDesc
	INTO #Temp		
	FROM ReportScheduleTable AS r 
	INNER JOIN
         DefineLetters AS d 
    ON r.ReportID = d.LetterID
    
    DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF @PageSize <= 0
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount

END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_ReportScheduleDate_UpdateList]    Script Date: 05/02/2008 17:58:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ReportScheduleDate_UpdateList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ReportScheduleDate_UpdateList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ReportScheduleDate_UpdateList]    Script Date: 05/02/2008 17:58:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ReportScheduleDate_UpdateList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- ======================================================================================
-- Author:		Tuan Luong
-- Create date: May 2nd, 2008
-- Description:	Removes all records which belong to ScheduleID, then inserts new records
-- ======================================================================================
CREATE PROCEDURE [dbo].[CWX_ReportScheduleDate_UpdateList] 	
	@ScheduleID int,
	@ReportScheduleDates xml
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET ARITHABORT ON 
	SET QUOTED_IDENTIFIER ON;

	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	--Delete all records which have ScheduleID = @ScheduleID
	DELETE ReportScheduleDate
	WHERE ScheduleID = @ScheduleID

	DECLARE ReportScheduleDateCrsr CURSOR FOR
    SELECT		
		ParamValues.ReportScheduleDate.value(''./@ScheduleDate'',''smalldatetime'') AS ScheduleDate
	FROM
		@ReportScheduleDates.nodes(''/ReportScheduleDates/ReportScheduleDate'') as ParamValues(ReportScheduleDate) 

	OPEN ReportScheduleDateCrsr

	
	DECLARE @ScheduleDate smalldatetime
	FETCH NEXT FROM ReportScheduleDateCrsr
	INTO @ScheduleDate		

	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT ReportScheduleDate
		VALUES (@ScheduleID, @ScheduleDate)

		IF( @@ERROR <> 0)
			GOTO Cleanup

		FETCH NEXT FROM ReportScheduleDateCrsr
		INTO @ScheduleDate
	END

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE ReportScheduleDateCrsr
	DEALLOCATE ReportScheduleDateCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END


' 
END
GO

/******  Script Closed. Go next: Step010_5  ******/