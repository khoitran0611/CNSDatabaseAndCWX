-- Script is applied on version 2.3.7
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 08/07/2008 10:13:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetPagingList]    Script Date: 08/07/2008 10:13:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-14
-- Description:	Get the list of Groups of selecting customer
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetPagingList]
	-- Add the parameters for the stored procedure here
	@debtorID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(G.GroupID)
	FROM 
		(SELECT DISTINCT a.GroupID
		FROM Legal_Groups a
			LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
			LEFT JOIN Account c ON b.AccountID = c.AccountID
			LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> 'R') d ON a.GroupID = d.GroupID
		WHERE  a.Status <> 'R' and c.DebtorID = @debtorID) G

	WITH Temp AS
	(	
		SELECT
			ROW_NUMBER() OVER (ORDER BY G.Code) AS RowNumber,
			G.*	
		FROM (SELECT DISTINCT
			a.GroupID,
			a.Code,
			a.[Description],
			Case When d.GroupID is not null then 1 else 0 end HasStep
			FROM Legal_Groups a
				LEFT JOIN Legal_GroupDebts b ON a.GroupID = b.GroupID
				LEFT JOIN Account c ON b.AccountID = c.AccountID
				LEFT JOIN (Select distinct GroupID from Legal_GroupSteps Where [Status] <> 'R') d ON a.GroupID = d.GroupID
			WHERE  a.Status <> 'R' and c.DebtorID = @debtorID) G
	)

	SELECT * FROM Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
	
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetBrokenPromiseList]    Script Date: 08/07/2008 11:02:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetBrokenPromiseList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetBrokenPromiseList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseDueList]    Script Date: 08/07/2008 11:02:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetPromiseDueList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseDueList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseHistoryList]    Script Date: 08/07/2008 11:02:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetPromiseHistoryList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseHistoryList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetBrokenPromiseList]    Script Date: 08/07/2008 11:02:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: May 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetBrokenPromiseList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(PromiseID)
	FROM AccountPromise
	WHERE
		Status = 3 AND AccountID = @AccountID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
			p.PromiseID,
			p.AccountID,
			p.AmountPromised,
			p.DatePromised,
			p.Status,
			p.AmountPaid,
			p.DatePaid,
			p.Period,
			p.Term,
			p.PromiseFrequency,
			e.EmployeeName
		FROM AccountPromise p
		LEFT JOIN Employee e ON p.EmployeeID = e.EmployeeID
		WHERE
			p.Status = 3 AND p.AccountID = @AccountID
	)

	SELECT * FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END





GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseDueList]    Script Date: 08/07/2008 11:02:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: May 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseDueList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(PromiseID)
	FROM AccountPromise
	WHERE
		Status = 0 AND AccountID = @AccountID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
			p.PromiseID,
			p.AccountID,
			p.AmountPromised,
			p.DatePromised,
			p.Status,
			p.AmountPaid,
			p.DatePaid,
			p.Period,
			p.Term,
			p.PromiseFrequency,
			e.EmployeeName,
			a.CodeDesc as PromiseGiver
		FROM AccountPromise p
		LEFT JOIN Employee e ON p.EmployeeID = e.EmployeeID
		LEFT JOIN AccountCodeMaster a ON p.PromiseGiver = a.CodeID
		WHERE
			p.Status = 0 AND p.AccountID = @AccountID
	)

	SELECT * FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END




GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseHistoryList]    Script Date: 08/07/2008 11:02:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: May 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseHistoryList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(PromiseID)
	FROM AccountPromise
	WHERE
		Status in (1,2) AND AccountID = @AccountID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
			p.PromiseID,
			p.AccountID,
			p.AmountPromised,
			p.DatePromised,
			p.Status,
			p.AmountPaid,
			p.DatePaid,
			p.Period,
			p.Term,
			p.PromiseFrequency,
			e.EmployeeName
		FROM AccountPromise p
		LEFT JOIN Employee e ON p.EmployeeID = e.EmployeeID
		WHERE
			p.Status in (1,2) AND p.AccountID = @AccountID
	)

	SELECT * FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_GetDynamicEditableFields]    Script Date: 08/07/2008 15:22:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetDynamicEditableFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetDynamicEditableFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetDynamicEditableFields]    Script Date: 08/07/2008 15:22:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Khoa Dang
CREATE PROCEDURE [dbo].[CWX_GetDynamicEditableFields]
	@TableID smallint,
	@RowID int
AS
BEGIN
	DECLARE @TableName varchar(20)
	DECLARE @PrimaryKey varchar(20)
	IF @TableID = 1
	BEGIN
		SET @TableName = 'PersonInformation'
		SET @PrimaryKey = 'PersonID'
	END
	ELSE 
		IF @TableID = 2
		BEGIN
			SET @TableName = 'Account'
			SET @PrimaryKey = 'AccountID'
		END

	/* DataTable 1: get FieldName and Description of DynamicEditableFields table depends on Type field */
	SELECT f.FieldName, f.Description, t.Name as DataType, c.max_length as MaxLength, c.precision, c.is_nullable AS IsNullable INTO #DynamicFields 
		FROM ((sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id)
			INNER JOIN sys.types t ON t.system_type_id = c.system_type_id)
			INNER JOIN CWX_DynamicEditableFields f ON c.Name = f.FieldName
		WHERE o.Name=@TableName AND f.TableID=@TableID
	
	SELECT * FROM #DynamicFields

	/* DataTable 2: return the structure of table that needs to update */
	DECLARE @FieldName varchar(100)
	DECLARE @FieldNames varchar(1000)
	DECLARE DynamicFieldsCursor CURSOR FOR SELECT FieldName FROM #DynamicFields
	OPEN DynamicFieldsCursor
	FETCH NEXT FROM DynamicFieldsCursor INTO @FieldName

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF LEN(@FieldNames) > 0
			SET @FieldNames = @FieldNames + ',' + @FieldName
		ELSE
			SET @FieldNames = @FieldName

		FETCH NEXT FROM DynamicFieldsCursor INTO @FieldName
	END

	CLOSE DynamicFieldsCursor
	DEALLOCATE DynamicFieldsCursor

	DECLARE @sql varchar(2000)
	SET @sql = 'SELECT ' + @FieldNames + ' FROM ' + @TableName + ' WHERE ' + @PrimaryKey + '=' + Str(@RowID)
	EXEC (@sql)

	/* DataTable 3: primary key */
	SELECT @PrimaryKey as PrimaryKey
END
GO
/******  Script Closed. Go next: Step017_3  ******/