-- Script is applied on version 2.6.1, 2.6.2, 2.6.4, 2.6.6, 2.6.7, 2.6.9, 2.6.12, 2.6.13, 2.6.14, 2.6.16, 2.6.17, 2.6.18, 2.6.20, 2.6.22, 2.6.24, 2.6.25, 2.6.26, 2.6.27, 2.6.28, 2.6.29, 2.6.30

-- Scripts 2.6.1:

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDebtorID]    Script Date: 09/09/2008 15:02:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetDebtorID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetDebtorID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDebtorID]    Script Date: 09/09/2008 15:02:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetDebtorID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get debtor ID by account ID.
-- History:
--	2008/09/09	[Binh Truong]	Init version.
-- =============================================
create PROCEDURE [dbo].[CWX_Account_GetDebtorID] 
	@AccountID int
AS
BEGIN	
	SET NOCOUNT ON;
	SELECT DebtorID	FROM Account WHERE AccountID = @AccountID
END
' 
END
GO

-- Scripts 2.6.2:

/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetLoginDetails]    Script Date: 09/10/2008 14:44:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <6 September 2008>
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Employee_GetLoginDetails]
	@EmployeeIDString varchar(1000),
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount INT
	SET @RowCount = 0

	IF (@EmployeeIDString != '')
	BEGIN
		DECLARE @querystring varchar(2000);
		CREATE TABLE #Temp(
			RowNumber int,
			EmployeeID int,
			EmployeeName varchar(10),
			ViewedNo int,		
			AccountIDViewing int
		);

		SET @querystring = 'INSERT INTO #Temp
			SELECT 
			ROW_NUMBER() OVER (ORDER BY  e.EmployeeID ASC) AS RowNumber,		
			e.EmployeeID, e.UserID, ISNULL(COUNT(a1.RecordID),0) AS ViewedNo, ISNULL(a2.AccountID,0) AS AccountIDViewing
			FROM Employee e 
			LEFT JOIN 
				(SELECT * FROM AccountActions 
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID=8
				) AS a1
			ON e.EmployeeID = a1.CompletedBy
			LEFT JOIN 
				(SELECT DISTINCT AccountID, CompletedBy FROM AccountActions AS a
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID=8
					AND DateCompleted >= (SELECT MAX(DateCompleted) FROM AccountActions
											WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
												AND ActionID=8
												AND CompletedBy=a.CompletedBy)
				) AS a2
			ON e.EmployeeID = a2.CompletedBy
			WHERE e.EmployeeID IN (' + @EmployeeIDString + ')
			GROUP BY e.EmployeeID, e.UserID, a2.AccountID'
		
		EXEC (@querystring)
		
		SELECT @RowCount = @@ROWCOUNT
		
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
		
		DROP TABLE #Temp
	END
	
	RETURN @RowCount

END
GO
-- Scripts 2.6.4:

-- Binh Truong
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.DialerQueue ADD
	Status char(1) NOT NULL CONSTRAINT DF_DialerQueue_Status DEFAULT 'A'
GO
COMMIT

/****** Object:  StoredProcedure [dbo].[CWX_Account_CheckExists]    Script Date: 09/12/2008 14:25:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CheckExists]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_CheckExists]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_CheckExists]    Script Date: 09/12/2008 14:25:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CheckExists]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Check account exist by AccountID & DebtorID.
-- History:
--	2008/09/12	[Binh Truong]	Init version.
-- =============================================
create PROCEDURE [dbo].[CWX_Account_CheckExists] 
	@AccountID int,
	@DebtorID int
AS
BEGIN
	
	SET NOCOUNT ON;
	
	SELECT	AccountID  
	FROM    Account
	WHERE	AccountID = @AccountID AND DebtorID = @DebtorID
	
END
' 
END
GO

-- Scripts 2.6.6:

/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetLoginDetails]    Script Date: 09/12/2008 15:04:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <6 September 2008>
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Employee_GetLoginDetails]
	@EmployeeIDString varchar(1000),
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount INT
	SET @RowCount = 0

	IF (@EmployeeIDString != '')
	BEGIN
		DECLARE @querystring varchar(2000);
		CREATE TABLE #Temp(
			RowNumber int,
			EmployeeID int,
			EmployeeName varchar(10),
			ViewedNo int,		
			AccountIDViewing int
		);

		SET @querystring = 'INSERT INTO #Temp
			SELECT 
			ROW_NUMBER() OVER (ORDER BY  e.EmployeeID ASC) AS RowNumber,		
			e.EmployeeID, e.UserID, ISNULL(COUNT(a1.RecordID),0) AS ViewedNo, ISNULL(a2.AccountID,0) AS AccountIDViewing
			FROM Employee e 
			LEFT JOIN 
				(SELECT * FROM AccountActions 
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID=8
				) AS a1
			ON e.EmployeeID = a1.CompletedBy
			LEFT JOIN 
				(SELECT distinct AccountID, CompletedBy FROM AccountActions AS a
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID=8
					AND AccountID = (SELECT TOP 1 AccountID FROM AccountActions 
										WHERE CompletedBy=a.CompletedBy
										AND DateCompleted >=
											(SELECT MAX(DateCompleted) FROM AccountActions
												WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
												AND ActionID=8
												AND CompletedBy=a.CompletedBy))
				) AS a2
			ON e.EmployeeID = a2.CompletedBy
			WHERE e.EmployeeID IN (' + @EmployeeIDString + ')
			GROUP BY e.EmployeeID, e.UserID, a2.AccountID'
		
		EXEC (@querystring)
		
		SELECT @RowCount = @@ROWCOUNT
		
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
		
		DROP TABLE #Temp
	END
	
	RETURN @RowCount

END
GO

-- Scripts 2.6.7:

/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetLoginDetails]    Script Date: 09/12/2008 15:04:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <6 September 2008>
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Employee_GetLoginDetails]
	@EmployeeIDString varchar(1000),
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount INT
	SET @RowCount = 0

	IF (@EmployeeIDString != '')
	BEGIN
		DECLARE @querystring varchar(2000);
		CREATE TABLE #Temp(
			RowNumber int,
			EmployeeID int,
			EmployeeName varchar(10),
			ViewedNo int,		
			AccountIDViewing int
		);

		SET @querystring = 'INSERT INTO #Temp
			SELECT 
			ROW_NUMBER() OVER (ORDER BY  e.EmployeeID ASC) AS RowNumber,		
			e.EmployeeID, e.UserID, ISNULL(COUNT(a1.RecordID),0) AS ViewedNo, ISNULL(a2.AccountID,0) AS AccountIDViewing
			FROM Employee e 
			LEFT JOIN 
				(SELECT * FROM AccountActions 
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID=8
				) AS a1
			ON e.EmployeeID = a1.CompletedBy
			LEFT JOIN 
				(SELECT AccountID, CompletedBy FROM AccountActions AS a
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID=8
					AND RecordID >= (SELECT MAX(RecordID) FROM AccountActions
												WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
												AND ActionID=8
												AND CompletedBy=a.CompletedBy)
				) AS a2
			ON e.EmployeeID = a2.CompletedBy
			WHERE e.EmployeeID IN (' + @EmployeeIDString + ')
			GROUP BY e.EmployeeID, e.UserID, a2.AccountID'
		
		EXEC (@querystring)
		
		SELECT @RowCount = @@ROWCOUNT
		
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
		
		DROP TABLE #Temp
	END
	
	RETURN @RowCount

END
GO
-- Scripts 2.6.9:

/****** Object:  StoredProcedure [dbo].[spEmployeePerformance]    Script Date: 09/15/2008 11:44:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spEmployeePerformance]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spEmployeePerformance]
GO


/****** Object:  StoredProcedure [dbo].[CWX_EmployeePerformance]    Script Date: 09/15/2008 11:44:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeePerformance]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_EmployeePerformance]
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeePerformance]    Script Date: 09/15/2008 11:44:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeePerformance]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'create PROCEDURE dbo.CWX_EmployeePerformance
(@BeginDate datetime, @EndDate datetime,@EmployeeId int)  
AS
/*
BEGIN
Truncate table spTblEmployeePerf
declare @theDate as smalldatetime
declare @HoursWorked as int
declare @logIn as varchar(50) 
declare @logOut as varchar(50)
declare @Attempts as int
declare @Calls as int
declare @OutCalls as int
declare @InCalls as int
declare @Contact as int
declare @Promise as int
declare @KeptPromise as int
declare @BrokenPromise as int
declare @DuePromise as int
declare @AmountPromised as money
declare @PromiseCollected as money
declare @AccAmt as money
declare @v_EmployeeId as int
declare @sEmployees Cursor 
declare @collecterID as int
declare @PromiseInterval as int
declare @AmountPromisedKept as money
if @EmployeeId is Null
	Begin
		Set @sEmployees=Cursor For 
            			Select EmployeeId From Employee 
	end
else
	Begin
		Set @sEmployees=Cursor For 
		            Select EmployeeId From Employee where EmployeeId = @EmployeeId
	End
 
Open @sEmployees
     Fetch Next From @sEmployees Into @v_EmployeeId                    
               While @@Fetch_Status=0
           Begin
	set @theDate = @BeginDate
	set @HoursWorked = 0
	set @Attempts = 0
	set @Calls = 0
	set @Contact = 0
	set @Promise = 0
	set @KeptPromise = 0
	set @BrokenPromise = 0
	set @DuePromise = 0
	set @AmountPromised = 0.00
	set @AmountPromisedKept = 0.00
	set @PromiseCollected = 0.00
	set @AccAmt = 0.00
	set @OutCalls=0
	set @InCalls=0
	set @logIn ='' ''
	set @logOut='' ''
	
	select @BeginDate = convert(char(10), @BeginDate, 121) + '' 00:00:00''
	select @EndDate = convert(char(10), @EndDate, 121) + '' 23:59:29''  
	
	set @theDate = @BeginDate
	insert into spTblEmployeePerf (ReportDate, [Name],[Collector ID])
		select @theDate [ReportDate], e.EmployeeName [Name], e.employeeID [Collector ID]
		from Employee e
			where e.EmployeeId = @v_EmployeeId 
 	select @HoursWorked = sum(MinutesLoggedIn)
		from LoginLog
			where convert(smalldatetime,left(logintime,10)+'' 00:00:00'',20)
			between convert(smalldatetime,@BeginDate) and convert(smalldatetime,@EndDate) and EmployeeId = @v_EmployeeId
 	if @HoursWorked is Null
		 begin
			 set @HoursWorked = 0
		 end 
	select @Attempts = count(*)
		from AccountActions
			where DateCompleted between @BeginDate and @EndDate and
			ActionID in (select Actionid from AvailableActions where Category in (1,2))
				and ResponsibleParty = @v_EmployeeId 
	-- Total Attempts refer to count of all the actions with category (1,2) i.e. Incoming call or outgoing call
 	select @Calls = count(*)
		from AccountActions
			where DateCompleted between convert(smalldatetime,@BeginDate) and convert(smalldatetime,@EndDate) and
			ActionID in (select Actionid from AvailableActions where Category in (1,2)
			and productivityId in (1,2,3)) and ResponsibleParty = @v_EmployeeId
	-- Total Calls refer to count of all the actions with category in (1,2) and productivity in (1,2,3)
	select @OutCalls = count(*)
		from AccountActions
			where DateCompleted between convert(smalldatetime,@BeginDate) and convert(smalldatetime,@EndDate) and
			ActionID in (select Actionid from AvailableActions where Category = 2
			and productivityId in (1,2,3)) and ResponsibleParty = @v_EmployeeId
	-- Total Outcalls refers to count of all the actions with category 2 and productivity in (1,2,3)
	select @InCalls = count(*)
		from AccountActions
			where DateCompleted between convert(smalldatetime,@BeginDate) and convert(smalldatetime,@EndDate) and
			ActionID in (select Actionid from AvailableActions where Category = 1
			and productivityId in (1,2,3))and ResponsibleParty = @v_EmployeeId
	-- Total InCalls refers to count of all the actions with category 1 and productivity in (1,2,3)
	select @Contact = count(*)
		from AccountActions
			where DateCompleted between convert(smalldatetime,@BeginDate) and convert(smalldatetime,@EndDate) and
			ActionID in (select Actionid from AvailableActions where Category = 2
			and productivityId in (1,2)) and ResponsibleParty = @v_EmployeeId
	-- Total Contact refers to count of all the actions with category in (1,2) and productivity in (1,2)
	-- select @Promise = count(*)
	--	from AccountActions
	--		where DateCompleted between @BeginDate and @EndDate and
	--		ActionID = 2 and ResponsibleParty = @v_EmployeeId
	select @Promise = count(*)
		from Accountpromise
			where convert(varchar(10),DateAdd("d",convert(int,left(BatchNumber,5)),convert(smalldatetime,''1980-01-01'')),101) between convert(varchar(10),@BeginDate,101) and convert(varchar(10),@EndDate,101)
			and EmployeeId = @v_EmployeeId
	select @KeptPromise = count(*)
		from AccountPromise
			where Datepaid between convert(smalldatetime,@BeginDate) and convert(smalldatetime,@EndDate)
			and status in (1,2) and EmployeeID = @v_EmployeeId
 	select @BrokenPromise = count(*)
		from AccountPromise
			where Datepaid between convert(smalldatetime,@BeginDate) and convert(smalldatetime,@EndDate)
			and status = 3 and EmployeeID = @v_EmployeeId
	select @DuePromise = count(*)
		from AccountPromise
			where convert(varchar(10),DateAdd("d",convert(int,left(BatchNumber,5)),convert(smalldatetime,''1980-01-01'')),101) between convert(varchar(10),@BeginDate,101) and convert(varchar(10),@EndDate,101)
			and EmployeeId = @v_EmployeeId and status = 0 
	select @AmountPromised = sum(AmountPromised)
		from AccountPromise
		where convert(varchar(10),DateAdd("d",convert(int,left(BatchNumber,5)),convert(smalldatetime,''1980-01-01'')),101) between convert(varchar(10),@BeginDate,101) and convert(varchar(10),@EndDate,101)
		and EmployeeId = @v_EmployeeId and status = 0 
	select @AmountPromisedKept = sum(AmountPromised)
		from AccountPromise
		where convert(varchar(10),DateAdd("d",convert(int,left(BatchNumber,5)),convert(smalldatetime,''1980-01-01'')),101) between convert(varchar(10),@BeginDate,101) and convert(varchar(10),@EndDate,101)
		and EmployeeId = @v_EmployeeId and status in (1,2)
 	if @AmountPromised is Null
		 begin
			 set @AmountPromised = 0
		 end 
 	if @AmountPromisedKept is Null
		 begin
			 set @AmountPromisedKept = 0
		 end 
	select @PromiseCollected = sum(AmountPaid)
		from AccountPromise
			where DatePaid between convert(smalldatetime,@BeginDate) and convert(smalldatetime,@EndDate)
			and Status in (1,2)
			and EmployeeId = @v_EmployeeId 
	if @PromiseCollected is Null
		 begin
			 set @PromiseCollected = 0
		 end 
			
	Update spTblEmployeePerf
		set [Hours Worked] = @HoursWorked,[Attempts] = @Attempts,[Calls] = @Calls,
		[Log In]=@login, [Log Out]=@logout,[Outgoing Calls]=@outCalls, [Incoming Calls]=@inCalls,[Contact] = @Contact,
		[PTP #] = @Promise,
		[Keep Promise #] = @KeptPromise,
		[Broken Promise #] = @BrokenPromise,
		[Due Promise #] = @DuePromise,
		[PTP $] = @AmountPromised,[Payment $] = @AmountPromisedKept,[Avg PTP] = @PromiseCollected
			where [Collector ID] = @v_EmployeeId
 	
 Fetch Next From @sEmployees Into @v_EmployeeId
end --end while
                 Close @sEmployees
select * from spTblEmployeePerf
END
*/' 
END
GO


/****** Object:  StoredProcedure [dbo].[spReportM1PP]    Script Date: 09/15/2008 11:37:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spReportM1PP]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spReportM1PP]
GO


/****** Object:  StoredProcedure [dbo].[CWX_ReportM1PP]    Script Date: 09/15/2008 11:37:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ReportM1PP]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ReportM1PP]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ReportM1PP]    Script Date: 09/15/2008 11:37:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ReportM1PP]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'create PROCEDURE dbo.CWX_ReportM1PP
(@BeginDate smalldatetime, @EndDate smalldatetime)  
AS
/*
BEGIN

update Employee
set NotUsedA = 0
update Employee
set NotUsedA = 1
where [Description] like ''%Cycle%''
update Employee
set NotUsedA = 2
where [Description] like ''%M2%''
update Employee
set NotUsedA = 3
where [Description] like ''%?k%''

truncate table ReportM1PP
--declare @BeginDate as smalldatetime
--declare @EndDate as smalldatetime
declare @theDate as smalldatetime
declare @Cycle as int
--select @BeginDate = ''2003-05-01''
--select @EndDate = ''2003-05-22''
set @theDate = @BeginDate
while @theDate <= @EndDate
begin
	set @Cycle = 0
	while @Cycle <= 5
	begin
		insert into ReportM1PP (ReportDate, [Name], Cycle)
		select convert(char(10), @theDate, 20) ReportDate, e.EmployeeName [Name], @Cycle Cycle
		from Employee e
		where e.NotUsedA = 1
		
		select @Cycle = @Cycle + 1
	end
	set @theDate = dateadd(d, 1, @theDate)
end
select @BeginDate = convert(char(10), @BeginDate, 20) + '' 00:00:00.000''
select @EndDate = convert(char(10), @EndDate, 20) + '' 23:59:59.999''
update ReportM1PP
set [C Today] = s.[C Today]
from ReportM1PP r,
(
select convert(char(10), n.DeadLine, 20) ReportDate, e.EmployeeName [Name], a.CCode Cycle, count(distinct n.AccountID) [C Today]
from AccountActions n, Employee e, Account a
where n.ResponsibleParty = e.EmployeeID
and n.DeadLine between @BeginDate and @EndDate
and e.NotUsedA = 1
and a.AccountID = n.AccountID
group by convert(char(10), n.DeadLine, 20), e.EmployeeName, a.CCode
--order by convert(char(10), n.DeadLine, 20), e.EmployeeName, a.CCode
) as s
where s.ReportDate = r.ReportDate
and s.[Name] = r.[Name]
and s.Cycle = r.Cycle
update ReportM1PP
set [Payment #] = s.[Payment #],
[Payment $] = s.[Payment $],
[Avg Payment] = s.[Avg Payment]
from ReportM1PP r,
(
select convert(char(10), t.DateOfTransaction, 20) ReportDate, e.EmployeeName [Name], a.CCode Cycle, count(TransactionID) [Payment #], sum(TransactionAmount) [Payment $], avg(TransactionAmount) [Avg Payment]
from Transactions t, Employee e, Account a
where t.EmployeeID = e.EmployeeID
and t.DateOfTransaction between @BeginDate and @EndDate
and e.NotUsedA = 1
and a.AccountID = t.AccountID
group by convert(char(10), t.DateOfTransaction, 20), e.EmployeeName, a.CCode
)as s
where s.ReportDate = r.ReportDate
and s.[Name] = r.[Name]
and s.Cycle = r.Cycle
update ReportM1PP
set [Keep Promise #] = s.[Keep Promise #]
from ReportM1PP r,
(
select convert(char(10), p.DatePromised, 20) ReportDate, e.EmployeeName [Name], a.CCode Cycle, count(PromiseID) [Keep Promise #]
from AccountPromise p, Employee e, Account a
where p.EmployeeID = e.EmployeeID
and p.DatePromised between @BeginDate and @EndDate
and e.NotUsedA = 1
and p.Status = 1
and a.AccountID = p.AccountID
group by convert(char(10), p.DatePromised, 20), e.EmployeeName, a.CCode
)as s
where s.ReportDate = r.ReportDate
and s.[Name] = r.[Name]
and s.Cycle = r.Cycle
update ReportM1PP
set [Due Promise #] = s.[Due Promise #]
from ReportM1PP r,
(
select convert(char(10), p.DatePromised, 20) ReportDate, e.EmployeeName [Name], a.CCode Cycle, count(PromiseID) [Due Promise #]
from AccountPromise p, Employee e, Account a
where p.EmployeeID = e.EmployeeID
and p.DatePromised between @BeginDate and @EndDate
and e.NotUsedA = 1
--and p.Status <> 0
and a.AccountID = p.AccountID
group by convert(char(10), p.DatePromised, 20), e.EmployeeName, a.CCode
)as s
where s.ReportDate = r.ReportDate
and s.[Name] = r.[Name]
and s.Cycle = r.Cycle
update ReportM1PP
set [PTP #] = s.[PTP #],
[PTP $] = s.[PTP $],
[Avg PTP] = s.[Avg PTP]
from ReportM1PP r,
(
select convert(char(10), dateadd(d, convert(int, left(p.BatchNumber, 5)), ''1980-01-01''), 20) ReportDate, e.EmployeeName [Name], a.CCode Cycle, count(PromiseID) [PTP #], sum(AmountPromised) [PTP $], avg(AmountPromised) [Avg PTP]
from AccountPromise p, Employee e, Account a
where p.EmployeeID = e.EmployeeID
and dateadd(d, convert(int, left(p.BatchNumber, 5)), ''1980-01-01'') between @BeginDate and @EndDate
and e.NotUsedA = 1
and a.AccountID = p.AccountID
group by convert(char(10), dateadd(d, convert(int, left(p.BatchNumber, 5)), ''1980-01-01''), 20), e.EmployeeName, a.CCode
)as s
where s.ReportDate = r.ReportDate
and s.[Name] = r.[Name]
and s.Cycle = r.Cycle
select * from ReportM1PP



END
*/' 
END
GO


/****** Object:  StoredProcedure [dbo].[RunAllocation]    Script Date: 09/15/2008 11:20:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RunAllocation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[RunAllocation]
GO

/****** Object:  StoredProcedure [dbo].[Sp_Description]    Script Date: 09/15/2008 10:38:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Sp_Description]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Sp_Description]
GO

/****** Object:  StoredProcedure [dbo].[Sp_SaveAfterUpdateTriger]    Script Date: 09/15/2008 10:39:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Sp_SaveAfterUpdateTriger]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Sp_SaveAfterUpdateTriger]
GO

/****** Object:  StoredProcedure [dbo].[sp_Split]    Script Date: 09/15/2008 11:19:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_Split]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_Split]
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'PersonAddress' and c.name = 'UpdateBy')
BEGIN
	ALTER TABLE PersonAddress ADD UpdateBy int NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'PersonAddressLog' and c.name = 'UpdateBy')
BEGIN
	ALTER TABLE PersonAddressLog ADD UpdateBy int NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'PersonPhone' and c.name = 'UpdateBy')
BEGIN
	ALTER TABLE PersonPhone ADD UpdateBy int NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'PersonPhoneLog' and c.name = 'UpdateBy')
BEGIN
	ALTER TABLE PersonPhoneLog ADD UpdateBy int NULL
END
GO


/*
   Monday, September 15, 20084:31:40 PM
   Binh Truong
*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
CREATE TABLE dbo.Tmp_Messages
	(
	ID int NOT NULL IDENTITY (1, 1),
	ToEmployee int NOT NULL,
	FromEmployee int NOT NULL,
	FromName varchar(50) NOT NULL,
	DebtorID int NOT NULL,
	AccountID int NULL,
	DisplayOn smalldatetime NOT NULL,
	Message varchar(250) NOT NULL,
	EntryDate smalldatetime NOT NULL,
	Active bit NOT NULL,
	EmployeeRead bit NOT NULL
	)  ON [PRIMARY]
GO
SET IDENTITY_INSERT dbo.Tmp_Messages ON
GO
IF EXISTS(SELECT * FROM dbo.Messages)
	 EXEC('INSERT INTO dbo.Tmp_Messages (ID, ToEmployee, FromEmployee, FromName, DebtorID, DisplayOn, Message, EntryDate, Active, EmployeeRead)
		SELECT ID, ToEmployee, FromEmployee, FromName, DebtorID, DisplayOn, Message, EntryDate, Active, EmployeeRead FROM dbo.Messages WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_Messages OFF
GO
DROP TABLE dbo.Messages
GO
EXECUTE sp_rename N'dbo.Tmp_Messages', N'Messages', 'OBJECT' 
GO
COMMIT
GO

-- Scripts 2.6.12:

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetQueueDate]    Script Date: 09/16/2008 18:12:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetQueueDate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetQueueDate]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetQueueDate]    Script Date: 09/16/2008 18:12:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetQueueDate]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get QueueDate by account ID.
-- History:
--	2008/09/16	[Binh Truong]	Init version.
-- =============================================
create PROCEDURE [dbo].[CWX_Account_GetQueueDate] 
	@AccountID int
AS
BEGIN	
	SET NOCOUNT ON;
	SELECT QueueDate FROM Account WHERE AccountID = @AccountID
END' 
END
GO

-- Scripts 2.6.13:

/****** Object:  StoredProcedure [dbo].[CWX_Account_CreateGroupAccount]    Script Date: 09/17/2008 15:25:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CreateGroupAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_CreateGroupAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_CreateGroupAccount]    Script Date: 09/17/2008 15:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 03, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_CreateGroupAccount]
	-- Add the parameters for the stored procedure here
	@GroupID int
AS
BEGIN
		--Increase 'Account' by one
	UPDATE IdentityFields SET FieldValue = FieldValue + 1 WHERE TableName = 'Account'

	--Insert new Account with all detail from the primary account of group
	DECLARE @BillBalance money
	DECLARE @BillAmount money
	SELECT @BillBalance=SUM(a.BillBalance), @BillAmount=SUM(a.BillAmount)
	FROM Legal_GroupDebts g
	LEFT JOIN Account a ON a.AccountID = g.AccountID
	WHERE g.IsInclude=1 AND g.GroupID=@GroupID

	DECLARE @PrimaryAccountID int
	SELECT @PrimaryAccountID=AccountID FROM Legal_GroupDebts WHERE GroupID = @GroupID AND IsPrimary = 1

	DECLARE @AccountID int
	SELECT @AccountID=MAX(AccountID)+1 FROM Account

	INSERT INTO Account
	SELECT @AccountID
		  ,DebtorID
		  ,EmployeeID
		  ,ClientID
		  ,AgencyStatusID
		  ,SystemStatusID
		  ,ActionCodeID
		  ,OfficeID
		  ,MCode
		  ,CCode
		  ,@AccountID --,InvoiceNumber
		  ,AccountType
		  ,AccountClass
		  ,QueueDate
		  ,DateOfService
		  ,SubmissionDate
		  ,LastClientTransactionDate
		  ,RoutinePayment
		  ,PaymentPlan
		  ,PatientName
		  ,@BillAmount
		  ,@BillBalance
		  ,BillOtherCharges
		  ,ClientPaysLegalFees
		  ,AccountForwarded
		  ,CreditReported
		  ,CreditReportedDate
		  ,ClientPercent
		  ,ClientOCPercent
		  ,SplitPayment
		  ,CurrentAction
		  ,CurrentActionDate
		  ,NoLetterBefore
		  ,NoFeeBefore
		  ,MaintainOfficer
		  ,AccountAge
		  ,LastEditDate
		  ,LastEditBy
		  ,LastVerifyDate
		  ,AllocRuleID
		  ,AutoProcRuleID
		  ,LastExtractionDate
		  ,LastAllocationDate
		  ,LastAutoProcessDate
		  ,ExtractionRuleID
		  ,AccountForwardedTo
		  ,CurrencyCode
		  ,BatchNumber
		  ,InterestRate
		  ,ActionEmployee
		  ,LastPromiseBatch
		  ,CreditReportRequested
		  ,CreditReportRequestedBy
		  ,CreditReportRequestedOn
		  ,CreditReportRequestStatus
		  ,WriteOffDate
		  ,LastInterestDate
		  ,TempEmployeeID
		  ,OAManaged
		  ,InterfaceID
		  ,Delq_string
		  ,SortOrder
		  ,Allocated
		  ,BrokenCount
		  ,CARD_FILE_NO
		  ,ARREAR_PATH
		  ,BUCKET_TYPE
		  ,OLD_BUCKET_TYPE
		  ,CARD_TYPE
		  ,BRANCH_CODE
		  ,FORMULA
		  ,BANK_CODE
		  ,PAID
		  ,OtherAccountNo
		  ,TENOR
		  ,FORMULA_FLAG
		  ,MINIMUM_DUE
		  ,CURRENT_BKT_NUM
		  ,PREV_BKT_NUM
		  ,productivecount
		  ,contactcount
		  ,nocontactcount
		  ,DelqHistory
		  ,BucketMovement
		  ,DPDMovement
		  ,PreviousAllocRuleID
		  ,OnLeaveEmpID
		  ,LeaveLoadRelFlag
		  ,CurrentReason
		  ,CurrentReasonDate
		  ,CurrentNextAction
		  ,CurrentNextActionDate
		  ,CurrentCallResult
		  ,CurrentCallResultDate
		  ,CampaignId
		  ,CloseDate
		  ,MaxContact
		  ,AssignmentType
		  ,PoolSelected
		  ,IsPending
		FROM Account
		WHERE AccountID = @PrimaryAccountID

	--Delete redundant data
	DELETE AccountOther WHERE AccountID = @PrimaryAccountID
	--Insert into AccountOther
	INSERT INTO AccountOther
	SELECT @AccountID
		  ,Long1
		  ,Long2
		  ,Long3
		  ,Long4
		  ,Long5
		  ,Long6
		  ,Long7
		  ,Long8
		  ,Long9
		  ,Long10
		  ,Long11
		  ,Long12
		  ,Long13
		  ,Long14
		  ,Long15
		  ,Long16
		  ,Long17
		  ,Long18
		  ,Long19
		  ,Long20
		  ,Long21
		  ,Long22
		  ,Long23
		  ,Long24
		  ,Long25
		  ,Long26
		  ,Long27
		  ,Long28
		  ,Long29
		  ,Long30
		  ,Long31
		  ,Long32
		  ,Long33
		  ,Long34
		  ,Long35
		  ,Long36
		  ,Long37
		  ,Long38
		  ,Long39
		  ,Long40
		  ,Long41
		  ,Long42
		  ,Long43
		  ,Long44
		  ,Long45
		  ,Long46
		  ,Long47
		  ,Long48
		  ,Long49
		  ,Long50
		  ,Money1
		  ,Money2
		  ,Money3
		  ,Money4
		  ,Money5
		  ,Money6
		  ,Money7
		  ,Money8
		  ,Money9
		  ,Money10
		  ,Money11
		  ,Money12
		  ,Money13
		  ,Money14
		  ,Money15
		  ,Money16
		  ,Money17
		  ,Money18
		  ,Money19
		  ,Money20
		  ,Money21
		  ,Money22
		  ,Money23
		  ,Money24
		  ,Money25
		  ,Money26
		  ,Money27
		  ,Money28
		  ,Money29
		  ,Money30
		  ,Money31
		  ,Money32
		  ,Money33
		  ,Money34
		  ,Money35
		  ,Money36
		  ,Money37
		  ,Money38
		  ,Money39
		  ,Money40
		  ,Money41
		  ,Money42
		  ,Money43
		  ,Money44
		  ,Money45
		  ,Money46
		  ,Money47
		  ,Money48
		  ,Money49
		  ,Money50
		  ,Date1
		  ,Date2
		  ,Date3
		  ,Date4
		  ,Date5
		  ,Date6
		  ,Date7
		  ,Date8
		  ,Date9
		  ,Date10
		  ,Date11
		  ,Date12
		  ,Date13
		  ,Date14
		  ,Date15
		  ,Date16
		  ,Date17
		  ,Date18
		  ,Date19
		  ,Date20
		  ,Date21
		  ,Date22
		  ,Date23
		  ,Date24
		  ,Date25
		  ,Date26
		  ,Date27
		  ,Date28
		  ,Date29
		  ,Date30
		  ,Date31
		  ,Date32
		  ,Date33
		  ,Date34
		  ,Date35
		  ,Date36
		  ,Date37
		  ,Date38
		  ,Date39
		  ,Date40
		  ,Date41
		  ,Date42
		  ,Date43
		  ,Date44
		  ,Date45
		  ,Date46
		  ,Date47
		  ,Date48
		  ,Date49
		  ,Date50
		  ,String1
		  ,String2
		  ,String3
		  ,String4
		  ,String5
		  ,String6
		  ,String7
		  ,String8
		  ,String9
		  ,String10
		  ,String11
		  ,String12
		  ,String13
		  ,String14
		  ,String15
		  ,String16
		  ,String17
		  ,String18
		  ,String19
		  ,String20
		  ,String21
		  ,String22
		  ,String23
		  ,String24
		  ,String25
		  ,String26
		  ,String27
		  ,String28
		  ,String29
		  ,String30
		  ,String31
		  ,String32
		  ,String33
		  ,String34
		  ,String35
		  ,String36
		  ,String37
		  ,String38
		  ,String39
		  ,String40
		  ,String41
		  ,String42
		  ,String43
		  ,String44
		  ,String45
		  ,String46
		  ,String47
		  ,String48
		  ,String49
		  ,String50
		  ,Additional1
		  ,Additional2
		  ,Additional3
		  ,Additional4
		  ,ArrearsHistory
		FROM AccountOther
		WHERE AccountID = @PrimaryAccountID

	SELECT @AccountID
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateTransactionAmount]    Script Date: 09/17/2008 17:48:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <20 Aug 2008>
-- Description:	<Update Bill Balance, Bill Amount for 1.Add Other Charge 2.Receive Payment>
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_UpdateTransactionAmount] 	
	@AccountID int,
	@TransactionType int, -- 1: Add Other Charge; 2: Receive Payment
	@TransactionAmount money	
AS
BEGIN	
    
	IF @TransactionType = 1		
		UPDATE Account 
		SET --BillAmount = BillAmount + @TransactionAmount, 
			BillBalance = BillBalance + @TransactionAmount,
			BillOtherCharges = @TransactionAmount
		WHERE AccountID = @AccountID		
	ELSE
		UPDATE Account 
		SET --BillAmount = BillAmount - @TransactionAmount, 
			BillBalance = BillBalance - @TransactionAmount
		WHERE AccountID = @AccountID		
END
GO
-------- Thuy Nguyen on 18-Sep-2008 --------

Alter table Legal_CustomFieldTypes add FieldTypeID int
GO
----------------------------------------------

-- 2008/09/18	[Binh Truong]
ALTER TABLE dbo.Legal_Creditors ADD
	PaymentAllocationRuleID int NULL
GO
-------------

/****** Object:  StoredProcedure [dbo].[CWX_PersonAddressLog_GetPagingList]    Script Date: 09/18/2008 11:21:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonAddressLog_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonAddressLog_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonAddressLog_GetPagingList]    Script Date: 09/18/2008 11:21:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Long Nguyen>
-- Create date: <Sep 17, 2008>
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_PersonAddressLog_GetPagingList]
	@DebtorID int,
	@AddressType tinyint,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
	SELECT @RowCount=COUNT(LogID)
	FROM PersonAddressLog
	WHERE PersonID = @DebtorID AND AddressType = @AddressType

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY LogID) AS RowNumber,
			p.*, e.UserID
		FROM PersonAddressLog p
		LEFT JOIN Employee e ON e.EmployeeID = p.UpdateBy
		WHERE p.PersonID = @DebtorID AND p.AddressType = @AddressType
	)

	SELECT * FROM Temp WHERE (@PageSize <= 0) OR (RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize)
	
	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_PersonPhoneLog_GetPagingList]    Script Date: 09/18/2008 11:22:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonPhoneLog_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonPhoneLog_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonPhoneLog_GetPagingList]    Script Date: 09/18/2008 11:22:04 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Long Nguyen>
-- Create date: <Sep 17, 2008>
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_PersonPhoneLog_GetPagingList]
	@PhoneID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
	SELECT @RowCount=COUNT(LogID)
	FROM PersonPhoneLog
	WHERE PhoneID = @PhoneID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY LogID) AS RowNumber,
			p.*, e.UserID
		FROM PersonPhoneLog p
		LEFT JOIN Employee e ON e.EmployeeID = p.UpdateBy
		WHERE p.PhoneID = @PhoneID
	)

	SELECT * FROM Temp WHERE (@PageSize <= 0) OR (RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize)
	
	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]    Script Date: 09/18/2008 11:36:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]    Script Date: 09/18/2008 11:36:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Minh Dam
-- Create date: 2008-08-28
-- Description:	Get paging list of LegalContacts belong to a parent contact type
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]
	-- Add the parameters for the stored procedure here
	@ParentContactType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @Sql varchar(5000)

	DECLARE @RowCount int
	SELECT @RowCount=COUNT(ContactID)
	FROM Legal_Contacts
	WHERE (@ParentContactType = 0 OR ParentType = @ParentContactType) AND [Status] <> 'R'

	SET @Sql =
'WITH Temp AS
(
	SELECT
		ROW_NUMBER() OVER (ORDER BY b.Code) AS RowNumber,
		a.ContactID,
		a.ParentType, 
		b.Code [Code], 
		b.@@NameField [Name],
		IsNull(Title,'''') Title, IsNull(FirstName, '''') FirstName, IsNull(LastName, '''') LastName, 
		a.[Description]
	FROM Legal_Contacts a
		LEFT JOIN @@RefTable b ON a.ParentID = b.@@RefField AND a.ParentType = @@ParentContactType
	WHERE (@@ParentContactType = 0 OR a.ParentType = @@ParentContactType) AND a.Status <> ''R''
)

SELECT ContactID, ParentType, Code + Case When [Name]<>'''' Then '' - '' + [Name] Else '''' End CodeAndName, 
		LTRIM(Case When Title<>'''' Then Title Else '''' End + Case When FirstName<>'''' Then '' ''+FirstName Else '''' End + 
			Case When LastName<>'''' Then '' '' + LastName Else '''' End) ContactName,
		[Description]
FROM Temp WHERE RowNumber BETWEEN @@PageIndex * @@PageSize + 1 AND (@@PageIndex + 1) * @@PageSize
'

	IF (@ParentContactType = 1) -- Solicitors
	BEGIN
		SET @Sql = REPLACE(@Sql, '@@RefTable', 'Legal_Solicitors')
		SET @Sql = REPLACE(@Sql, '@@RefField', 'SolicitorID')
		SET @Sql = REPLACE(@Sql, '@@NameField', 'Name')
	END
	ELSE IF (@ParentContactType = 2) -- Agents
	BEGIN
		SET @Sql = REPLACE(@Sql, '@@RefTable', 'Legal_Agents')
		SET @Sql = REPLACE(@Sql, '@@RefField', 'AgentID')
		SET @Sql = REPLACE(@Sql, '@@NameField', 'Name')
	END
	ELSE -- Creditors
	BEGIN
		SET @Sql = REPLACE(@Sql, '@@RefTable', 'Legal_Creditors')
		SET @Sql = REPLACE(@Sql, '@@RefField', 'CreditorID')
		SET @Sql = REPLACE(@Sql, '@@NameField', 'CommonName')
	END
	
	SET @Sql = REPLACE(@Sql, '@@ParentContactType', cast(@ParentContactType as varchar))
	SET @Sql = REPLACE(@Sql, '@@PageSize', cast(@PageSize as varchar))
	SET @Sql = REPLACE(@Sql, '@@PageIndex', cast(@PageIndex as varchar))

	--PRINT @Sql
	EXEC sp_sqlexec @Sql
	RETURN @RowCount
END
GO

-- Scripts 2.6.14

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_GetPagingListByTransactionType]    Script Date: 09/18/2008 15:28:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Rates_GetPagingListByTransactionType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Rates_GetPagingListByTransactionType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_GetPagingListByTransactionType]    Script Date: 09/18/2008 15:28:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Rates_GetPagingListByTransactionType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		ThuyNguyen
-- Create date: Sep 18, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Rates_GetPagingListByTransactionType]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0,
	@TransactionTypeID int = 0

AS
BEGIN
	
	DECLARE @RowCount int, @RowNumber int;
	DECLARE @CountString varchar(100), @QueryString varchar(500), @WhereClause varchar(100);	
	
	IF @TransactionTypeID=0
		SET @WhereClause = '' WHERE TransactionTypeID = '' + CAST(@TransactionTypeID AS VARCHAR) + '' AND Status <> ''''R''''''
	ELSE 
		SET @WhereClause = '' WHERE Status <> ''''R''''''
	
	SET @CountString = ''SELECT @RowCount = COUNT(ID) FROM Legal_Rates'' + @WhereClause	
	EXEC(@CountString)

	IF @PageSize*(@PageIndex+1) > @RowCount 
		SET @RowNumber = @RowCount - (@PageSize*@PageIndex)
	ELSE 
		SET @RowNumber = @PageSize

	SET @QueryString = ''
	SELECT * FROM 
		(SELECT TOP ('' + CAST(@RowNumber AS VARCHAR) + '') * FROM  
			(SELECT TOP ('' + CAST((@PageIndex + 1)*@PageSize AS VARCHAR) + '') 
				r.*, 
				(t.TransactionCode + '''' - '''' + t.Description) AS TransactionType
			FROM Legal_Rates r 
				LEFT JOIN TransactionType t ON t.ID = r.TransactionTypeID
			'' + @WhereClause + ''			
			ORDER BY RateCode ASC) as t1 
		ORDER BY RateCode DESC) as t2 
	ORDER BY RateCode ASC
	''
	EXEC(@QueryString)

	RETURN @RowCount

END' 
END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: 2008-08-28
-- Description:	Alter SP [CWX_Legal_Contacts_GetPagingListByParentContactType]
--				Get paging list of LegalContacts belong to a parent contact type
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]    Script Date: 09/18/2008 16:00:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]
	-- Add the parameters for the stored procedure here
	@ParentContactType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @Sql varchar(5000)

	DECLARE @RowCount int
	SELECT @RowCount=COUNT(ContactID)
	FROM Legal_Contacts
	WHERE (@ParentContactType = 0 OR ParentType = @ParentContactType) AND [Status] <> 'R'

	SET @Sql =
			'WITH Temp AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY b.Code) AS RowNumber,
					a.ContactID,
					a.ParentType, 
					b.Code [Code], 
					b.@@NameField [Name],
					IsNull(Title,'''') Title, IsNull(FirstName, '''') FirstName, IsNull(LastName, '''') LastName, 
					a.[Description]
				FROM Legal_Contacts a
					LEFT JOIN @@RefTable b ON a.ParentID = b.@@RefField
				WHERE (@@ParentContactType = 0 OR a.ParentType = @@ParentContactType) AND a.Status <> ''R''
			)

			SELECT ContactID, ParentType, Code + Case When [Name]<>'''' Then '' - '' + [Name] Else '''' End CodeAndName, 
					LTRIM(Case When Title<>'''' Then Title Else '''' End + Case When FirstName<>'''' Then '' ''+FirstName Else '''' End + 
						Case When LastName<>'''' Then '' '' + LastName Else '''' End) ContactName,
					[Description]
			FROM Temp WHERE RowNumber BETWEEN @@PageIndex * @@PageSize + 1 AND (@@PageIndex + 1) * @@PageSize
			'

	IF (@ParentContactType = 1) -- Solicitors
	BEGIN
		SET @Sql = REPLACE(@Sql, '@@RefTable', 'Legal_Solicitors')
		SET @Sql = REPLACE(@Sql, '@@RefField', 'SolicitorID')
		SET @Sql = REPLACE(@Sql, '@@NameField', 'Name')
	END
	ELSE IF (@ParentContactType = 2) -- Agents
	BEGIN
		SET @Sql = REPLACE(@Sql, '@@RefTable', 'Legal_Agents')
		SET @Sql = REPLACE(@Sql, '@@RefField', 'AgentID')
		SET @Sql = REPLACE(@Sql, '@@NameField', 'Name')
	END
	ELSE -- Creditors
	BEGIN
		SET @Sql = REPLACE(@Sql, '@@RefTable', 'Legal_Creditors')
		SET @Sql = REPLACE(@Sql, '@@RefField', 'CreditorID')
		SET @Sql = REPLACE(@Sql, '@@NameField', 'CommonName')
	END
	
	SET @Sql = REPLACE(@Sql, '@@ParentContactType', cast(@ParentContactType as varchar))
	SET @Sql = REPLACE(@Sql, '@@PageSize', cast(@PageSize as varchar))
	SET @Sql = REPLACE(@Sql, '@@PageIndex', cast(@PageIndex as varchar))

	--PRINT @Sql
	EXEC sp_sqlexec @Sql
	RETURN @RowCount
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_GetPagingList]    Script Date: 09/18/2008 16:01:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Rates_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Rates_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_GetPagingList]    Script Date: 09/18/2008 16:01:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 05, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Rates_GetPagingList]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
	SELECT @RowCount=COUNT(ID)
	FROM Legal_Rates
	WHERE Status <> 'R'

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY r.RateCode, r.StartDate) AS RowNumber,
			r.*, (t.TransactionCode + ' - ' + t.Description) AS TransactionType
		FROM Legal_Rates r
		LEFT JOIN TransactionType t ON t.ID = r.TransactionTypeID
		WHERE r.Status <> 'R'
	)

	SELECT * FROM Temp WHERE (@PageSize <= 0) OR (RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize)
	
	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_IsLegalRateExisted]    Script Date: 09/18/2008 16:03:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Rates_IsLegalRateExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Rates_IsLegalRateExisted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_IsLegalRateExisted]    Script Date: 09/18/2008 16:04:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 05, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Rates_IsLegalRateExisted]
	-- Add the parameters for the stored procedure here
	@ID int = 0,
	@RateCode nvarchar(50),
	@StartDate smalldatetime = NULL,
	@EndDate smalldatetime = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT COUNT(ID)
	FROM Legal_Rates
	WHERE
		(@ID = 0 OR ID <> @ID)
		AND (RateCode = @RateCode)
		AND
		(
			(@StartDate IS NULL OR EndDate IS NULL OR CONVERT(VARCHAR(10),@StartDate,121) < CONVERT(VARCHAR(10),EndDate,121))
			AND (@EndDate IS NULL OR StartDate IS NULL OR CONVERT(VARCHAR(10),@EndDate,121) > CONVERT(VARCHAR(10),StartDate,121))
		)
END
GO

-------Thuy Nguyen on 18-Sep-2008 -----
alter table Legal_Courts add PostcodeStart varchar(20) null, PostcodeEnd varchar(20) null
alter table Legal_GroupDebtors add DefendantNum int null
go
---------------------------------------



-- 2008/09/18	[Binh Truong]
ALTER TABLE dbo.ClientInformation ADD
	PaymentAllocationRuleID int NULL
GO
---------------

-- Scripts 2.6.16:

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_GetPagingListByTransactionType]    Script Date: 09/19/2008 10:21:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThuyNguyen
-- Create date: Sep 18, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Legal_Rates_GetPagingListByTransactionType]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0,
	@TransactionTypeID int = 0

AS
BEGIN
	
	DECLARE @RowCount int, @RowNumber int;
	DECLARE @CountString varchar(100), @QueryString varchar(500), @WhereClause varchar(100);	
	
	IF @TransactionTypeID<>0
	BEGIN
		SET @WhereClause = ' AND TransactionTypeID = ' + CAST(@TransactionTypeID AS VARCHAR)
		SELECT @RowCount = COUNT(ID) FROM Legal_Rates WHERE Status <> 'R' AND TransactionTypeID = @TransactionTypeID
	END
	ELSE 
	BEGIN
		SET @WhereClause = ''
		SELECT @RowCount = COUNT(ID) FROM Legal_Rates WHERE Status <> 'R'
	END

	IF @PageSize*(@PageIndex+1) > @RowCount 
		SET @RowNumber = @RowCount - (@PageSize*@PageIndex)
	ELSE 
		SET @RowNumber = @PageSize

	SET @QueryString = '
	SELECT * FROM 
		(SELECT TOP (' + CAST(@RowNumber AS VARCHAR) + ') * FROM  
			(SELECT TOP (' + CAST((@PageIndex + 1)*@PageSize AS VARCHAR) + ') 
				r.*, 
				(t.TransactionCode + '' - '' + t.Description) AS TransactionType
			FROM Legal_Rates r 
				LEFT JOIN TransactionType t ON t.ID = r.TransactionTypeID
			WHERE r.Status <> ''R''' + @WhereClause + '			
			ORDER BY RateCode ASC) as t1 
		ORDER BY RateCode DESC) as t2 
	ORDER BY RateCode ASC
	'
	EXEC(@QueryString)
	RETURN @RowCount

END
GO
--- Thuy Nguyen on 19-Sep-2008

alter table TransactionType add TransactionType int null
go

-------------------------------

/****** Object:  StoredProcedure [dbo].[CWX_Account_CreateGroupAccount]    Script Date: 09/19/2008 11:49:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CreateGroupAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_CreateGroupAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_CreateGroupAccount]    Script Date: 09/19/2008 11:49:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CreateGroupAccount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Create a new account by group ID.
-- History:
--	2008/09/03	[LongNguyen]	Init version.
--	2008/09/19	[Binh Truong]	Delete a record in TempDebtorXml where debtorID = debtorID of created account. Purpose: clear cache.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_CreateGroupAccount]
	@GroupID int
AS
BEGIN
	DECLARE @BillBalance money
	DECLARE @BillAmount money
	
	--Increase ''Account'' by one
	UPDATE IdentityFields SET FieldValue = FieldValue + 1 WHERE TableName = ''Account''

	--Insert new Account with all detail from the primary account of group	
	SELECT @BillBalance=SUM(a.BillBalance), @BillAmount=SUM(a.BillAmount)
	FROM Legal_GroupDebts g
	LEFT JOIN Account a ON a.AccountID = g.AccountID
	WHERE g.IsInclude=1 AND g.GroupID=@GroupID

	DECLARE @PrimaryAccountID int
	SELECT @PrimaryAccountID=AccountID FROM Legal_GroupDebts WHERE GroupID = @GroupID AND IsPrimary = 1

	DECLARE @AccountID int
	SELECT @AccountID=MAX(AccountID)+1 FROM Account

	INSERT INTO Account
	SELECT @AccountID
		  ,DebtorID
		  ,EmployeeID
		  ,ClientID
		  ,AgencyStatusID
		  ,SystemStatusID
		  ,ActionCodeID
		  ,OfficeID
		  ,MCode
		  ,CCode
		  ,@AccountID --,InvoiceNumber
		  ,AccountType
		  ,AccountClass
		  ,QueueDate
		  ,DateOfService
		  ,SubmissionDate
		  ,LastClientTransactionDate
		  ,RoutinePayment
		  ,PaymentPlan
		  ,PatientName
		  ,@BillAmount
		  ,@BillBalance
		  ,BillOtherCharges
		  ,ClientPaysLegalFees
		  ,AccountForwarded
		  ,CreditReported
		  ,CreditReportedDate
		  ,ClientPercent
		  ,ClientOCPercent
		  ,SplitPayment
		  ,CurrentAction
		  ,CurrentActionDate
		  ,NoLetterBefore
		  ,NoFeeBefore
		  ,MaintainOfficer
		  ,AccountAge
		  ,LastEditDate
		  ,LastEditBy
		  ,LastVerifyDate
		  ,AllocRuleID
		  ,AutoProcRuleID
		  ,LastExtractionDate
		  ,LastAllocationDate
		  ,LastAutoProcessDate
		  ,ExtractionRuleID
		  ,AccountForwardedTo
		  ,CurrencyCode
		  ,BatchNumber
		  ,InterestRate
		  ,ActionEmployee
		  ,LastPromiseBatch
		  ,CreditReportRequested
		  ,CreditReportRequestedBy
		  ,CreditReportRequestedOn
		  ,CreditReportRequestStatus
		  ,WriteOffDate
		  ,LastInterestDate
		  ,TempEmployeeID
		  ,OAManaged
		  ,InterfaceID
		  ,Delq_string
		  ,SortOrder
		  ,Allocated
		  ,BrokenCount
		  ,CARD_FILE_NO
		  ,ARREAR_PATH
		  ,BUCKET_TYPE
		  ,OLD_BUCKET_TYPE
		  ,CARD_TYPE
		  ,BRANCH_CODE
		  ,FORMULA
		  ,BANK_CODE
		  ,PAID
		  ,OtherAccountNo
		  ,TENOR
		  ,FORMULA_FLAG
		  ,MINIMUM_DUE
		  ,CURRENT_BKT_NUM
		  ,PREV_BKT_NUM
		  ,productivecount
		  ,contactcount
		  ,nocontactcount
		  ,DelqHistory
		  ,BucketMovement
		  ,DPDMovement
		  ,PreviousAllocRuleID
		  ,OnLeaveEmpID
		  ,LeaveLoadRelFlag
		  ,CurrentReason
		  ,CurrentReasonDate
		  ,CurrentNextAction
		  ,CurrentNextActionDate
		  ,CurrentCallResult
		  ,CurrentCallResultDate
		  ,CampaignId
		  ,CloseDate
		  ,MaxContact
		  ,AssignmentType
		  ,PoolSelected
		  ,IsPending
		FROM Account
		WHERE AccountID = @PrimaryAccountID

	--Delete redundant data
	DELETE AccountOther WHERE AccountID = @PrimaryAccountID
	--Insert into AccountOther
	INSERT INTO AccountOther
	SELECT @AccountID
		  ,Long1
		  ,Long2
		  ,Long3
		  ,Long4
		  ,Long5
		  ,Long6
		  ,Long7
		  ,Long8
		  ,Long9
		  ,Long10
		  ,Long11
		  ,Long12
		  ,Long13
		  ,Long14
		  ,Long15
		  ,Long16
		  ,Long17
		  ,Long18
		  ,Long19
		  ,Long20
		  ,Long21
		  ,Long22
		  ,Long23
		  ,Long24
		  ,Long25
		  ,Long26
		  ,Long27
		  ,Long28
		  ,Long29
		  ,Long30
		  ,Long31
		  ,Long32
		  ,Long33
		  ,Long34
		  ,Long35
		  ,Long36
		  ,Long37
		  ,Long38
		  ,Long39
		  ,Long40
		  ,Long41
		  ,Long42
		  ,Long43
		  ,Long44
		  ,Long45
		  ,Long46
		  ,Long47
		  ,Long48
		  ,Long49
		  ,Long50
		  ,Money1
		  ,Money2
		  ,Money3
		  ,Money4
		  ,Money5
		  ,Money6
		  ,Money7
		  ,Money8
		  ,Money9
		  ,Money10
		  ,Money11
		  ,Money12
		  ,Money13
		  ,Money14
		  ,Money15
		  ,Money16
		  ,Money17
		  ,Money18
		  ,Money19
		  ,Money20
		  ,Money21
		  ,Money22
		  ,Money23
		  ,Money24
		  ,Money25
		  ,Money26
		  ,Money27
		  ,Money28
		  ,Money29
		  ,Money30
		  ,Money31
		  ,Money32
		  ,Money33
		  ,Money34
		  ,Money35
		  ,Money36
		  ,Money37
		  ,Money38
		  ,Money39
		  ,Money40
		  ,Money41
		  ,Money42
		  ,Money43
		  ,Money44
		  ,Money45
		  ,Money46
		  ,Money47
		  ,Money48
		  ,Money49
		  ,Money50
		  ,Date1
		  ,Date2
		  ,Date3
		  ,Date4
		  ,Date5
		  ,Date6
		  ,Date7
		  ,Date8
		  ,Date9
		  ,Date10
		  ,Date11
		  ,Date12
		  ,Date13
		  ,Date14
		  ,Date15
		  ,Date16
		  ,Date17
		  ,Date18
		  ,Date19
		  ,Date20
		  ,Date21
		  ,Date22
		  ,Date23
		  ,Date24
		  ,Date25
		  ,Date26
		  ,Date27
		  ,Date28
		  ,Date29
		  ,Date30
		  ,Date31
		  ,Date32
		  ,Date33
		  ,Date34
		  ,Date35
		  ,Date36
		  ,Date37
		  ,Date38
		  ,Date39
		  ,Date40
		  ,Date41
		  ,Date42
		  ,Date43
		  ,Date44
		  ,Date45
		  ,Date46
		  ,Date47
		  ,Date48
		  ,Date49
		  ,Date50
		  ,String1
		  ,String2
		  ,String3
		  ,String4
		  ,String5
		  ,String6
		  ,String7
		  ,String8
		  ,String9
		  ,String10
		  ,String11
		  ,String12
		  ,String13
		  ,String14
		  ,String15
		  ,String16
		  ,String17
		  ,String18
		  ,String19
		  ,String20
		  ,String21
		  ,String22
		  ,String23
		  ,String24
		  ,String25
		  ,String26
		  ,String27
		  ,String28
		  ,String29
		  ,String30
		  ,String31
		  ,String32
		  ,String33
		  ,String34
		  ,String35
		  ,String36
		  ,String37
		  ,String38
		  ,String39
		  ,String40
		  ,String41
		  ,String42
		  ,String43
		  ,String44
		  ,String45
		  ,String46
		  ,String47
		  ,String48
		  ,String49
		  ,String50
		  ,Additional1
		  ,Additional2
		  ,Additional3
		  ,Additional4
		  ,ArrearsHistory
		FROM AccountOther
		WHERE AccountID = @PrimaryAccountID
		
	DELETE FROM TempDebtorXml
	WHERE DebtorID = (SELECT DebtorID FROM Account WHERE AccountID = @AccountID)

	SELECT @AccountID
END' 
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_Collateral_Dict' and c.name = 'ClientID')
BEGIN
	ALTER TABLE CWX_Collateral_Dict ADD ClientID int NULL
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 09/19/2008 13:57:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 09/19/2008 13:57:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Minh Dam
-- Create date: 15/08/2008
-- Description:	
-- =============================================				
CREATE PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
	@CollateralID int,
	@ClientID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			b.[DataType],
			b.[MaxLength]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], [DisplayOrder]
		FROM CWX_Collateral_Dict
		WHERE Displayed = 1	AND (@ClientID = 0 OR ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], c.[max_length] as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Collateral' and [Type]='U')
			AND (c.[name] LIKE 'CInt%' OR c.[name] LIKE 'CString%' OR c.[name] LIKE 'CDate%' OR c.[name] LIKE 'CMoney%')
		) b 
		ON a.[FieldName] = b.[ColumnName]
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'ID,AccountID,HostCollateralID,EmployeeID,NextActionDate,Image,ImageFileName,'
	SET @FieldNameList = @FieldNameList + 
		'(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6) IS NOT NULL THEN CollateralType ELSE 0 END) AS CollateralType,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7) IS NOT NULL THEN CollateralStage ELSE 0 END) AS CollateralStage,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2) IS NOT NULL THEN NextAction ELSE 0 END) AS NextAction'
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM Collateral WHERE ID = ' + Cast(@CollateralID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]    Script Date: 09/19/2008 16:23:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]    Script Date: 09/19/2008 16:23:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get paging list of LegalContacts belong to a parent contact type
-- History:
--	2008/08/28	[Minh Dam]	Init version.
--	2008/09/19	[Binh Truong]	Add @ParentContactID parameter.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Contacts_GetPagingListByParentContactType]
	@ParentContactType int = 0,
	@ParentContactID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @Sql varchar(5000)

	DECLARE @RowCount int
	SELECT	@RowCount=COUNT(ContactID)
	FROM	Legal_Contacts
	WHERE	(@ParentContactType = 0 OR ParentType = @ParentContactType) AND 
			(@ParentContactID = 0 OR ParentID = @ParentContactID) AND
			[Status] <> ''R''

	SET @Sql =
			''WITH Temp AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY b.Code) AS RowNumber,
					a.ContactID,
					a.ParentType, 
					b.Code [Code], 
					b.@@NameField [Name],
					IsNull(Title,'''''''') Title, IsNull(FirstName, '''''''') FirstName, IsNull(LastName, '''''''') LastName, 
					a.[Description]
				FROM Legal_Contacts a
					LEFT JOIN @@RefTable b ON a.ParentID = b.@@RefField
				WHERE	(@@ParentContactType = 0 OR a.ParentType = @@ParentContactType) AND 
						(@@ParentContactID = 0 OR a.ParentID = @@ParentContactID) AND
						a.Status <> ''''R''''
			)

			SELECT ContactID, ParentType, Code + Case When [Name]<>'''''''' Then '''' - '''' + [Name] Else '''''''' End CodeAndName, 
					LTRIM(Case When Title<>'''''''' Then Title Else '''''''' End + Case When FirstName<>'''''''' Then '''' ''''+FirstName Else '''''''' End + 
						Case When LastName<>'''''''' Then '''' '''' + LastName Else '''''''' End) ContactName,
					[Description]
			FROM Temp WHERE RowNumber BETWEEN @@PageIndex * @@PageSize + 1 AND (@@PageIndex + 1) * @@PageSize
			''

	IF (@ParentContactType = 1) -- Solicitors
	BEGIN
		SET @Sql = REPLACE(@Sql, ''@@RefTable'', ''Legal_Solicitors'')
		SET @Sql = REPLACE(@Sql, ''@@RefField'', ''SolicitorID'')
		SET @Sql = REPLACE(@Sql, ''@@NameField'', ''Name'')
	END
	ELSE IF (@ParentContactType = 2) -- Agents
	BEGIN
		SET @Sql = REPLACE(@Sql, ''@@RefTable'', ''Legal_Agents'')
		SET @Sql = REPLACE(@Sql, ''@@RefField'', ''AgentID'')
		SET @Sql = REPLACE(@Sql, ''@@NameField'', ''Name'')
	END
	ELSE -- Creditors
	BEGIN
		SET @Sql = REPLACE(@Sql, ''@@RefTable'', ''Legal_Creditors'')
		SET @Sql = REPLACE(@Sql, ''@@RefField'', ''CreditorID'')
		SET @Sql = REPLACE(@Sql, ''@@NameField'', ''CommonName'')
	END
	
	SET @Sql = REPLACE(@Sql, ''@@ParentContactType'', cast(@ParentContactType as varchar))
	SET @Sql = REPLACE(@Sql, ''@@ParentContactID'', cast(@ParentContactID as varchar))
	SET @Sql = REPLACE(@Sql, ''@@PageSize'', cast(@PageSize as varchar))
	SET @Sql = REPLACE(@Sql, ''@@PageIndex'', cast(@PageIndex as varchar))

	--PRINT @Sql
	EXEC sp_sqlexec @Sql
	RETURN @RowCount
END


' 
END
GO

-- Scripts 2.6.17:
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_GetPagingList]    Script Date: 09/19/2008 17:41:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Rates_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Rates_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_GetPagingList]    Script Date: 09/19/2008 17:41:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 05, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Rates_GetPagingList]
	-- Add the parameters for the stored procedure here
	@TransactionTypeID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
	SELECT @RowCount=COUNT(r.ID)
	FROM Legal_Rates r
	LEFT JOIN TransactionType t ON t.ID = r.TransactionTypeID
	WHERE
		r.Status <> 'R'
		AND (@TransactionTypeID = 0 OR r.TransactionTypeID = @TransactionTypeID)

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY r.RateCode, r.StartDate) AS RowNumber,
			r.*, (t.TransactionCode + ' - ' + t.Description) AS TransactionType
		FROM Legal_Rates r
		LEFT JOIN TransactionType t ON t.ID = r.TransactionTypeID
		WHERE
			r.Status <> 'R'
			AND (@TransactionTypeID = 0 OR r.TransactionTypeID = @TransactionTypeID)
	)

	SELECT * FROM Temp WHERE (@PageSize <= 0) OR (RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize)
	
	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_IsLegalRateExisted]    Script Date: 09/19/2008 17:42:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Rates_IsLegalRateExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Rates_IsLegalRateExisted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_IsLegalRateExisted]    Script Date: 09/19/2008 17:42:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 05, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Rates_IsLegalRateExisted]
	-- Add the parameters for the stored procedure here
	@ID int = 0,
	@RateCode nvarchar(50),
	@StartDate smalldatetime = NULL,
	@EndDate smalldatetime = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT COUNT(ID)
	FROM Legal_Rates
	WHERE
		(@ID = 0 OR ID <> @ID)
		AND (RateCode = @RateCode)
		AND
		(
			(@StartDate IS NULL OR EndDate IS NULL OR CONVERT(VARCHAR(10),@StartDate,121) <= CONVERT(VARCHAR(10),EndDate,121))
			AND (@EndDate IS NULL OR StartDate IS NULL OR CONVERT(VARCHAR(10),@EndDate,121) >= CONVERT(VARCHAR(10),StartDate,121))
		)
		AND Status <> 'R'
END
GO


-- 2008/09/19	[Binh Truong]
ALTER TABLE dbo.Legal_Solicitors ADD
	PrimaryContactID int NULL
GO

-- Scripts 2.6.18:

/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetListByPool]    Script Date: 09/22/2008 11:28:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetListByPool]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetListByPool]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetListByPool]    Script Date: 09/22/2008 11:28:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 22, 2008
-- Description:	Get all employees assigned to the selected pool
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_GetListByPool]
	@PoolID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT e.*
	FROM EmployeePool p
	INNER JOIN Employee e ON e.EmployeeID = p.EmployeeID
	WHERE p.PoolID = @PoolID AND e.EmployeeStatus <> 'R'
END
GO

------ Thuy Nguyen added on 22-Sept-2008


exec sp_RENAME 'Legal_GroupSteps.SolAmount', 'SolicitorFee', 'COLUMN'
exec sp_RENAME 'Legal_GroupSteps.CrtAmount', 'CourtFee', 'COLUMN'
exec sp_RENAME 'Legal_GroupSteps.SerAmount', 'ServiceFee', 'COLUMN'
exec sp_RENAME 'Legal_GroupSteps.AtsAmount', 'AttemptedFee', 'COLUMN'
exec sp_RENAME 'Legal_GroupSteps.TrvAmount', 'TravelFee', 'COLUMN'
exec sp_RENAME 'Legal_GroupSteps.BkpAmount', 'BookKeepingFee', 'COLUMN'
exec sp_RENAME 'Legal_GroupSteps.LvyAmount', 'LeavyFee', 'COLUMN'
exec sp_RENAME 'Legal_GroupSteps.SchAmount', 'SearchFee', 'COLUMN'
exec sp_RENAME 'Legal_GroupSteps.C1Amount', 'CustomFee1', 'COLUMN'
exec sp_RENAME 'Legal_GroupSteps.C2Amount', 'CustomFee2', 'COLUMN'
exec sp_RENAME 'Legal_GroupSteps.C3Amount', 'CustomFee3', 'COLUMN'
exec sp_RENAME 'Legal_GroupSteps.C4Amount', 'CustomFee4', 'COLUMN'
exec sp_RENAME 'Legal_GroupSteps.C5Amount', 'CustomFee5', 'COLUMN'

exec sp_RENAME 'Legal_Snapshots.SolAmount', 'SolicitorFee', 'COLUMN'
exec sp_RENAME 'Legal_Snapshots.CrtAmount', 'CourtFee', 'COLUMN'
exec sp_RENAME 'Legal_Snapshots.SerAmount', 'ServiceFee', 'COLUMN'
exec sp_RENAME 'Legal_Snapshots.AtsAmount', 'AttemptedFee', 'COLUMN'
exec sp_RENAME 'Legal_Snapshots.TrvAmount', 'TravelFee', 'COLUMN'
exec sp_RENAME 'Legal_Snapshots.BkpAmount', 'BookKeepingFee', 'COLUMN'
exec sp_RENAME 'Legal_Snapshots.LvyAmount', 'LeavyFee', 'COLUMN'
exec sp_RENAME 'Legal_Snapshots.SchAmount', 'SearchFee', 'COLUMN'
exec sp_RENAME 'Legal_Snapshots.C1Amount', 'CustomFee1', 'COLUMN'
exec sp_RENAME 'Legal_Snapshots.C2Amount', 'CustomFee2', 'COLUMN'
exec sp_RENAME 'Legal_Snapshots.C3Amount', 'CustomFee3', 'COLUMN'
exec sp_RENAME 'Legal_Snapshots.C4Amount', 'CustomFee4', 'COLUMN'
exec sp_RENAME 'Legal_Snapshots.C5Amount', 'CustomFee5', 'COLUMN'

-----------------

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 09/22/2008 13:39:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debtors with Account No. and Customer 's fullName
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate] ,ISNULL(g.Relationship_Type, 'Debtor') AS [RelationshipType] ,a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[DefendantNum], a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				LEFT JOIN PersonInformation p ON a.PersonID = p.PersonID
				LEFT JOIN Account b ON a.AccountID = b.AccountID
				LEFT JOIN CosigneeInformation g ON g.PersonID = a.PersonID AND g.Bill = b.AccountID
		WHERE a.GroupID = @groupID
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	ELSE
	BEGIN
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,'Debtor' AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum], isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
				LEFT JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
				LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate] ,g.Relationship_Type AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
			LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID)
		
		ORDER BY Seq, b.AccountID, FullName
	END
END
GO

-- 2008/09/22	[Binh Truong]
IF NOT EXISTS(SELECT TableName FROM IdentityFields WHERE TableName='GroupStepTotal')
BEGIN
	INSERT INTO IdentityFields
			(TableName, FieldValue)
	VALUES  ('GroupStepTotal', 1)
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateTransactionAmount]    Script Date: 09/25/2008 11:31:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <20 Aug 2008>
-- Description:	<Update Bill Balance, Bill Amount for 1.Add Other Charge 2.Receive Payment>
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_UpdateTransactionAmount] 	
	@AccountID int,
	@TransactionType int, -- 1: Add Other Charge; 2: Receive Payment
	@TransactionAmount money,
	@EffectToBalance int = 0 -- 0: No effect; 1: increase balance; 2: decrease balance
AS
BEGIN	
    
	IF @TransactionType = 1
		BEGIN
			UPDATE Account 
			SET BillOtherCharges = @TransactionAmount
			WHERE AccountID = @AccountID		

			IF @EffectToBalance = 1
				UPDATE Account 
				SET --BillAmount = BillAmount + @TransactionAmount, 
				BillBalance = BillBalance + @TransactionAmount				
				WHERE AccountID = @AccountID		
			ELSE IF @EffectToBalance = 2
				UPDATE Account 
				SET --BillAmount = BillAmount - @TransactionAmount, 
				BillBalance = BillBalance - @TransactionAmount
				WHERE AccountID = @AccountID	
		END
	ELSE
		UPDATE Account 
		SET --BillAmount = BillAmount - @TransactionAmount, 
			BillBalance = BillBalance - @TransactionAmount
		WHERE AccountID = @AccountID		
END
GO


-- 2008/09/22	[Binh Truong]
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Legal_GroupSteps ADD
	StepTotal money NULL
GO
COMMIT
GO

-- Scripts 2.6.20:

-- 2008/09/23	[Binh Truong]
ALTER TABLE dbo.Legal_GroupSteps
	DROP COLUMN DateCommenced, DateFiled, DateIssued
GO
ALTER TABLE dbo.Legal_Snapshots
	DROP COLUMN DateCommenced, DateFiled, DateIssued
GO	
	
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Snapshots_GetPagingList]    Script Date: 09/23/2008 11:32:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Snapshots_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Snapshots_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Snapshots_GetPagingList]    Script Date: 09/23/2008 11:32:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Snapshots_GetPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get the list of Groups of selecting customer
-- History:
--	2008/07/14	[Thao Nguyen]	Init version.
--	2008/09/23	[Binh Truong]	Remove DateIssued, DateFilled
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Snapshots_GetPagingList]
	@GroupStepID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(SnapshotID)
	FROM Legal_Snapshots
	WHERE GroupStepID = @GroupStepID

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER(ORDER BY b.[Code]) as RowNumber,
				a.[SnapshotID], a.[CreateDate], a.[DebtAmount],
				b.[Code] + '' - '' + b.[Description] as SnapshotType,
				a.IntAmount
		FROM Legal_Snapshots a
		LEFT JOIN Legal_SnapshotTypes b ON a.[SnapshotTypeID] = b.[SnapshotTypeID] AND b.[Status] <> ''R''
		WHERE a.GroupStepID = @GroupStepID
	)

	SELECT 	[SnapshotID], [SnapshotType], [CreateDate], [DebtAmount], IntAmount
	FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END' 
END
GO

/****** Object:  Table [dbo].[Legal_Rates]    Script Date: 09/23/2008 14:49:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Legal_Rates]') AND type in (N'U'))
DROP TABLE [dbo].[Legal_Rates]
GO
/****** Object:  Table [dbo].[Legal_Rates]    Script Date: 09/23/2008 14:49:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Legal_Rates](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[TransactionTypeID] [int] NULL,
	[RateCode] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[StartDate] [smalldatetime] NULL,
	[EndDate] [smalldatetime] NULL,
	[RateType] [tinyint] NULL,
	[RateAmount] [money] NULL,
	[BaseAmount] [money] NULL,
	[Status] [char](1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_Legal_Rates] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[Legal_RateSlabs]    Script Date: 09/23/2008 14:50:08 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Legal_RateSlabs]') AND type in (N'U'))
DROP TABLE [dbo].[Legal_RateSlabs]
GO
/****** Object:  Table [dbo].[Legal_RateSlabs]    Script Date: 09/23/2008 14:50:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Legal_RateSlabs](
	[SlabID] [int] IDENTITY(1,1) NOT NULL,
	[RateID] [int] NULL,
	[RangeValue1] [money] NULL,
	[RangeValue2] [money] NULL,
	[RateAmount] [money] NULL,
 CONSTRAINT [PK_Legal_RatesRange] PRIMARY KEY CLUSTERED 
(
	[SlabID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_GetPagingList]    Script Date: 09/23/2008 14:51:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Rates_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Rates_GetPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_GetPagingList]    Script Date: 09/23/2008 14:51:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 05, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Rates_GetPagingList]
	-- Add the parameters for the stored procedure here
	@TransactionTypeID int = 0,
	@RateCode nvarchar(50) = '',
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
	SELECT @RowCount=COUNT(r.ID)
	FROM Legal_Rates r
	LEFT JOIN TransactionType t ON t.ID = r.TransactionTypeID
	WHERE
		r.Status <> 'R'
		AND (@TransactionTypeID = 0 OR r.TransactionTypeID = @TransactionTypeID)
		AND (@RateCode = '' OR r.RateCode = @RateCode)

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY r.RateCode, r.StartDate) AS RowNumber,
			r.*, (t.TransactionCode + ' - ' + t.Description) AS TransactionType
		FROM Legal_Rates r
		LEFT JOIN TransactionType t ON t.ID = r.TransactionTypeID
		WHERE
			r.Status <> 'R'
			AND (@TransactionTypeID = 0 OR r.TransactionTypeID = @TransactionTypeID)
			AND (@RateCode = '' OR r.RateCode = @RateCode)
	)

	SELECT * FROM Temp WHERE (@PageSize <= 0) OR (RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize)
	
	RETURN @RowCount
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_IsLegalRateExisted]    Script Date: 09/23/2008 14:52:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Rates_IsLegalRateExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Rates_IsLegalRateExisted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_IsLegalRateExisted]    Script Date: 09/23/2008 14:52:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 05, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Rates_IsLegalRateExisted]
	-- Add the parameters for the stored procedure here
	@ID int = 0,
	@RateCode nvarchar(50),
	@StartDate smalldatetime = NULL,
	@EndDate smalldatetime = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT COUNT(ID)
	FROM Legal_Rates
	WHERE
		(@ID = 0 OR ID <> @ID)
		AND (RateCode = @RateCode)
		AND
		(
			(@StartDate IS NULL OR EndDate IS NULL OR CONVERT(VARCHAR(10),@StartDate,121) <= CONVERT(VARCHAR(10),EndDate,121))
			AND (@EndDate IS NULL OR StartDate IS NULL OR CONVERT(VARCHAR(10),@EndDate,121) >= CONVERT(VARCHAR(10),StartDate,121))
		)
		AND Status <> 'R'
END
GO

-- Scripts 2.6.22:


/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionType]    Script Date: 09/25/2008 10:17:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionType]    Script Date: 09/25/2008 10:17:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get transaction type and total amount of each transaction.
-- History:
--	2008/09/24	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_GetTransactionType]
	@AccountID int,
	@ClientID int
AS
BEGIN
	SET NOCOUNT ON
	
	SELECT     Transactions.TransactionType, SUM(ISNULL(Transactions.TransactionAmount, 0)) AS Amount, TransactionType.TransactionCode, 
	                      TransactionType.Description, TransactionType.AffectBalance
	FROM         Transactions INNER JOIN
	                      TransactionType ON Transactions.TransactionID = TransactionType.ID
	WHERE     (Transactions.AccountID = @AccountID) AND (Transactions.ClientID = @ClientID) AND (Transactions.TXN_POSTED = ''N'')
	GROUP BY Transactions.TransactionType, TransactionType.TransactionCode, TransactionType.Description, TransactionType.AffectBalance
END

' 
END
GO

/****** Object:  Table [dbo].[CWX_GroupStepLables]    Script Date: 09/24/2008 13:51:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GroupStepLables]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_GroupStepLables]
GO
/****** Object:  Table [dbo].[CWX_GroupStepLables]    Script Date: 09/24/2008 13:52:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CWX_GroupStepLables](
	[GroupStepID] [int] NOT NULL,
	[CustomFee1] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CustomFee2] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CustomFee3] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CustomFee4] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CustomFee5] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_CWX_GroupStepLables] PRIMARY KEY CLUSTERED 
(
	[GroupStepID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

--Init data for [CWX_GroupStepLables]
IF NOT EXISTS (SELECT GroupStepID FROM CWX_GroupStepLables WHERE GroupStepID = 0)
	INSERT INTO CWX_GroupStepLables VALUES(0, 'Custom Fee 1', 'Custom Fee 2', 'Custom Fee 3', 'Custom Fee 4', 'Custom Fee 5')
GO


-- Scripts 2.6.23:

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalAgent]    Script Date: 09/25/2008 11:34:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	
-- History:
--	2008/04/21	[Sathya]		Init version.
--	2008/08/14	[Binh Truong]	la.Status = 'A'  >>>  la.Status <> 'R'
--	2008/09/25	[Sathya]		la.Status <> 'R'  >>>  la.Status = 'A'
--								Add criteria lg.GroupID = ld.GroupID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalAgent] 
	@AgentId int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
		INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
	WHERE
		a.DebtorID <> 0
		And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
			INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
		WHERE
			a.DebtorID <> 0
            And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByLegalForward]    Script Date: 09/25/2008 11:40:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	
-- History:
--	2008/04/21	[LongNguyen]	Init version.
--	2008/08/14	[Binh Truong]	ls.Status = 'A'  >>>  ls.Status <> 'R'
--	2008/09/25	[Sathya]		la.Status <> 'R'  >>>  la.Status = 'A'
--								Add criteria lg.GroupID = ld.GroupID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalForward] 
	@SolicitorID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
		INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
	WHERE
		a.DebtorID <> 0
        And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
			INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
		WHERE
			a.DebtorID <> 0
			And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO

-- Script 2.6.24:
-- =============================================
-- Author:		Minh Dam
-- Create date: 25/09/2008
-- Description:	Create new store procedure CWX_Legal_CustomFields_DeleteOthers
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFields_DeleteOthers]    Script Date: 09/25/2008 18:09:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_CustomFields_DeleteOthers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_CustomFields_DeleteOthers]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFields_DeleteOthers]    Script Date: 09/25/2008 18:09:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Legal_CustomFields_DeleteOthers]
	-- Add the parameters for the stored procedure here
	@ActivityID int,
	@ActivityType int,
	@FieldType int,
	@FieldTypeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DELETE Legal_CustomFields
	WHERE ActivityID = @ActivityID
	  AND ActivityType = @ActivityType
	  AND CustomFieldTypeID IN (SELECT CustomFieldTypeID 
								FROM Legal_CustomFieldTypes 
								WHERE FieldType = @FieldType
								  AND FieldTypeID <> @FieldTypeID)
END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: 25/09/2008
-- Description:	Create new store procedure CWX_Legal_CustomFields_GetCustomFields
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFields_GetCustomFields]    Script Date: 09/25/2008 18:10:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_CustomFields_GetCustomFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_CustomFields_GetCustomFields]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFields_GetCustomFields]    Script Date: 09/25/2008 18:11:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Legal_CustomFields_GetCustomFields]
	-- Add the parameters for the stored procedure here
	@ActivityID int,
	@ActivityType int,
	@FieldType int,
	@FieldTypeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	a.[CustomFieldTypeID], a.[Description], a.[Type],
			ISNULL(b.[CustomFieldID],0) [CustomFieldID], ISNULL(b.[ActivityID],0) [ActivityID], 
			ISNULL(b.[ActivityType],0) [ActivityType], ISNULL(b.[Value],'') [Value]
	FROM
		(SELECT [CustomFieldTypeID], [Description], [Type]
		FROM Legal_CustomFieldTypes 
		WHERE FieldType = @FieldType AND FieldTypeID = @FieldTypeID) a
		LEFT JOIN
		(SELECT [CustomFieldID], [CustomFieldTypeID], [ActivityID], [ActivityType], [Value]
		FROM Legal_CustomFields WHERE ActivityID = @ActivityID AND ActivityType = @ActivityType) b
		ON a.CustomFieldTypeID = b.CustomFieldTypeID
	ORDER BY a.[Description]
END
GO

-- Scripts 2.6.25:

-- Issue 365 raised by Sathya - Thuy Nguyen added on 26-Sept-2008 ----

DELETE FROM IdentityFields WHERE TableName = 'AccountActions'
DELETE FROM IdentityFields WHERE TableName = 'AccountLetter'
DELETE FROM IdentityFields WHERE TableName = 'AccountPromise'
DELETE FROM IdentityFields WHERE TableName = 'AccountStatus'
DELETE FROM IdentityFields WHERE TableName = 'ActionBatch'
DELETE FROM IdentityFields WHERE TableName = 'Actions'
DELETE FROM IdentityFields WHERE TableName = 'AdditionalInfo'
DELETE FROM IdentityFields WHERE TableName = 'AdditionalTag'
DELETE FROM IdentityFields WHERE TableName = 'AgencyDefinedMaster'
DELETE FROM IdentityFields WHERE TableName = 'AuditTrail'
DELETE FROM IdentityFields WHERE TableName = 'AvailableActions'
DELETE FROM IdentityFields WHERE TableName = 'BlackOutDatesPending'
DELETE FROM IdentityFields WHERE TableName = 'CMSEditMenus'
DELETE FROM IdentityFields WHERE TableName = 'DefineFees'
DELETE FROM IdentityFields WHERE TableName = 'EmployeePending'
DELETE FROM IdentityFields WHERE TableName = 'Experience_Master'
DELETE FROM IdentityFields WHERE TableName = 'FuncRiskDetailsPending'
DELETE FROM IdentityFields WHERE TableName = 'HouseholdCertificate'
DELETE FROM IdentityFields WHERE TableName = 'Image'
DELETE FROM IdentityFields WHERE TableName = 'ImageModule'
DELETE FROM IdentityFields WHERE TableName = 'ImageType'
DELETE FROM IdentityFields WHERE TableName = 'LegalAction'
DELETE FROM IdentityFields WHERE TableName = 'LegalProcess'
DELETE FROM IdentityFields WHERE TableName = 'LegalProcessItem'
DELETE FROM IdentityFields WHERE TableName = 'Nationality_Master'
DELETE FROM IdentityFields WHERE TableName = 'NotesDisplayByAccount'
DELETE FROM IdentityFields WHERE TableName = 'PromiseBatch'
DELETE FROM IdentityFields WHERE TableName = 'ReportSchedule'
DELETE FROM IdentityFields WHERE TableName = 'RuleCriteriaPending'
DELETE FROM IdentityFields WHERE TableName = 'Rules'
DELETE FROM IdentityFields WHERE TableName = 'SearchID'
DELETE FROM IdentityFields WHERE TableName = 'SetupFees'
DELETE FROM IdentityFields WHERE TableName = 'SystemPending'
DELETE FROM IdentityFields WHERE TableName = 'TicketHistory'
DELETE FROM IdentityFields WHERE TableName = 'TransactionBatch'
DELETE FROM IdentityFields WHERE TableName = 'TransactionType'
DELETE FROM IdentityFields WHERE TableName = 'TransPaymentBreakout'
DELETE FROM IdentityFields WHERE TableName = 'DefineLetters'
DELETE FROM IdentityFields WHERE TableName = 'ClientInformation'

----------- issue 371 raised by Sathya -----------------------
ALTER TABLE [dbo].[DefineFees] DROP CONSTRAINT [DF_DefineFees_AffectBalance]
ALTER TABLE DefineFees DROP COLUMN AffectBalance
ALTER TABLE DefineFees ADD TransactionTypeID int null
GO
--------------------------------

/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateFee]    Script Date: 09/26/2008 10:43:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Khoa Dang
ALTER PROCEDURE [dbo].[CWX_Account_UpdateFee]
	@AccountID int,
	@FeeID int
AS
BEGIN
	declare @feeAmount float
	declare @feeType int, @effectBalance smallint	

	/* get fee type and amount of fee */
	select @feeType=FeeType, @feeAmount = case FeeType when 0 then AmountOfFee else FeePercent end,
		@effectBalance = AffectBalance
		from DefineFees d 
			left join TransactionType t on d.TransactionTypeID = t.ID
		where FeeID = @FeeID

	if (@feeType is null) or (@feeAmount is null) /* do not find any information of fee and then cancel transaction */
		return
	
	/* update BillBalance and BillOtherCharge */
	update Account set BillOtherCharges = @feeAmount where AccountID = @AccountID

	if (@feeType = 0)	
		if (@effectBalance = 1)
			update Account set BillBalance = BillBalance + @feeAmount where AccountID = @AccountID
		else if (@effectBalance = 2)
			update Account set BillBalance = BillBalance - @feeAmount where AccountID = @AccountID	
	else 
		if (@feeType = 1)
			if (@effectBalance = 1) update Account set BillBalance = BillBalance + (BillBalance * @feeAmount) where AccountID = @AccountID
			else if (@effectBalance = 2) update Account set BillBalance = BillBalance - (BillBalance * @feeAmount) where AccountID = @AccountID
		else
			if (@effectBalance = 1) update Account set BillBalance = BillBalance + (BillAmount * @feeAmount) where AccountID = @AccountID	
			else if (@effectBalance = 1) update Account set BillBalance = BillBalance - (BillAmount * @feeAmount) where AccountID = @AccountID	
END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: 25/09/2008
-- Description:	Update store procedure CWX_Legal_CustomFields_GetCustomFields
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFields_GetCustomFields]    Script Date: 09/26/2008 16:47:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[CWX_Legal_CustomFields_GetCustomFields]
	-- Add the parameters for the stored procedure here
	@ActivityID int,
	@ActivityType int,
	@FieldType int,
	@FieldTypeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF (@FieldTypeID IS NOT NULL AND @FieldTypeID > 0)
	BEGIN
		SELECT	a.[CustomFieldTypeID], a.[Description], a.[Type],
				ISNULL(b.[CustomFieldID],0) [CustomFieldID], ISNULL(b.[ActivityID],0) [ActivityID], 
				ISNULL(b.[ActivityType],0) [ActivityType], ISNULL(b.[Value],'') [Value]
		FROM
			(SELECT [CustomFieldTypeID], [Description], [Type]
			FROM Legal_CustomFieldTypes 
			WHERE FieldType = @FieldType AND FieldTypeID = @FieldTypeID) a
			LEFT JOIN
			(SELECT [CustomFieldID], [CustomFieldTypeID], [ActivityID], [ActivityType], [Value]
			FROM Legal_CustomFields 
			WHERE ActivityID = @ActivityID AND ActivityType = @ActivityType) b
			ON a.CustomFieldTypeID = b.CustomFieldTypeID
		ORDER BY a.[Description]
	END

	ELSE
	BEGIN
		SELECT	a.[CustomFieldTypeID], a.[Description], a.[Type],
				ISNULL(b.[CustomFieldID],0) [CustomFieldID], ISNULL(b.[ActivityID],0) [ActivityID], 
				ISNULL(b.[ActivityType],0) [ActivityType], ISNULL(b.[Value],'') [Value]
		FROM
			(SELECT [CustomFieldID], [CustomFieldTypeID], [ActivityID], [ActivityType], [Value]
			FROM Legal_CustomFields
			WHERE ActivityID = @ActivityID AND ActivityType = @ActivityType) b
			INNER JOIN
			(SELECT [CustomFieldTypeID], [Description], [Type]
			FROM Legal_CustomFieldTypes
			WHERE FieldType = @FieldType) a
			ON a.CustomFieldTypeID = b.CustomFieldTypeID
		ORDER BY a.[Description]
	END

END
GO

-- Scripts 2.6.26:

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetBillAmountBillBalance]    Script Date: 09/27/2008 19:32:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetBillAmountBillBalance]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetBillAmountBillBalance]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetBillAmountBillBalance]    Script Date: 09/27/2008 19:32:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetBillAmountBillBalance]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get BillAmount and BillBalance by account ID.
-- History:
--	2008/09/27	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetBillAmountBillBalance] 
	@AccountID int
AS
BEGIN
	SET NOCOUNT ON;
	SELECT BillAmount, BillBalance FROM [Account] WHERE [AccountID] = @AccountID
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Messages_GetUnreadMessageAmount]    Script Date: 09/29/2008 10:09:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Get unread messages of specific employee.
-- History:
--		2008/06/03	[Binh Truong]	Init version.
--		2008/09/26	[Thuy Nguyen] add DisplayOn <= Current Date
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Messages_GetUnreadMessageAmount]
(
	@EmployeeID int,
	@CurrentDateTime datetime
)
AS
	SET NOCOUNT ON
	SELECT	COUNT(*)
	FROM    Messages
	WHERE	ToEmployee = @EmployeeID AND EmployeeRead = 0
		AND CONVERT(varchar(19), DisplayOn, 121) <= CONVERT(varchar(19), @CurrentDateTime, 121)

GO


/****** Object:  Table [dbo].[CWX_CosigneeLog]    Script Date: 09/29/2008 10:54:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeLog]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_CosigneeLog]
GO
/****** Object:  Table [dbo].[CWX_CosigneeLog]    Script Date: 09/29/2008 10:54:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CWX_CosigneeLog](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[PersonID] [int] NULL,
	[SocialSecurityNumber] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PString1] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AlternateID1] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AlternateID1Name] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Title] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FirstName] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MiddleName] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[LastName] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DateOfBirth] [smalldatetime] NULL,
	[PString3] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Language] [int] NULL,
	[Email] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[NO_Of_Years_Resi] [varchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PMoney1] [money] NULL,
	[PString2] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PString5] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Nationality] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Fax] [varchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DriversLicenseNumber] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PMoney2] [money] NULL,
	[Profession] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Business_Type] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Position] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Department] [varchar](35) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Employee_Number] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Employment] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Employer_Code] [char](4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[EmploymentPhone] [varchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[EmploymentPhoneExtension] [varchar](8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FriendName] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Friend_Off_Phone] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Friend_Res_Phone] [varchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Friend_FaxNo] [varchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Relationship_Type] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdateBy] [int] NULL,
	[UpdateDate] [smalldatetime] NULL,
 CONSTRAINT [PK_CWX_CosigneeLog] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_Add]    Script Date: 09/29/2008 10:54:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_Add]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CosigneeInformation_Add]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_Add]    Script Date: 09/29/2008 10:55:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 25, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_Add] 
	-- Add the parameters for the stored procedure here
	@PersonID int,
	@SocialSecurityNumber varchar(25),
	@AlternateID1 varchar(50),
	@AlternateID1Name varchar(50),
	@Title varchar(50),
	@FirstName varchar(50),
	@MiddleName varchar(50),
	@LastName varchar(50),
	@DateOfBirth smalldatetime = NULL,
	@PString3 varchar(25),
	@Language int,
	@Email varchar(50),
	@NO_Of_Years_Resi varchar(10),
	@PMoney1 money,
	@PString2 varchar(10),
	@PString5 varchar(50),
	@Nationality varchar(50),
	@Fax varchar(30),
	@DriversLicenseNumber varchar(25),
	@PMoney2 money,
	@Profession varchar(50),
	@Business_Type varchar(50),
	@Position varchar(50),
	@Department varchar(35),
	@Employee_Number varchar(50),
	@Employment varchar(50),
	@Employer_Code char(4),
	@EmploymentPhone varchar(30),
	@EmploymentPhoneExtension varchar(8),
	@FriendName varchar(50),
	@Friend_Off_Phone varchar(50),
	@Friend_Res_Phone varchar(30),
	@Friend_FaxNo varchar(30),

	@AccountID int,
	@Relationship_Type varchar(20),

	@EmployeeID int
AS
BEGIN
	DECLARE @TranStarted bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	--If PersonInformation already existed
	IF @PersonID > 0
		--Update the PersonInformation
		UPDATE PersonInformation
		SET
			SocialSecurityNumber = @SocialSecurityNumber,
			PString1 = @SocialSecurityNumber,
			AlternateID1 = @AlternateID1,
			AlternateID1Name = @AlternateID1Name,
			Title = @Title,
			FirstName = @FirstName,
			MiddleName = @MiddleName,
			LastName = @LastName,
			DateOfBirth = @DateOfBirth,
			PString3 = @PString3,
			[Language] = @Language,
			Email = @Email,
			NO_Of_Years_Resi = @NO_Of_Years_Resi,
			PMoney1 = @PMoney1,
			PString2 = @PString2,
			PString5 = @PString5,
			Nationality = @Nationality,
			Fax = @Fax,
			DriversLicenseNumber = @DriversLicenseNumber,
			PMoney2 = @PMoney2,
			Profession = @Profession,
			Business_Type = @Business_Type,
			Position = @Position,
			Department = @Department,
			Employee_Number = @Employee_Number,
			Employment = @Employment,
			Employer_Code = @Employer_Code,
			EmploymentPhone = @EmploymentPhone,
			EmploymentPhoneExtension = @EmploymentPhoneExtension,
			FriendName = @FriendName,
			Friend_Off_Phone = @Friend_Off_Phone,
			Friend_Res_Phone = @Friend_Res_Phone,
			Friend_FaxNo = @Friend_FaxNo
		WHERE
			PersonID = @PersonID
		IF( @@ERROR <> 0)
        GOTO Cleanup
	ELSE
	BEGIN
		--Generate new PersonID
		SELECT @PersonID = MAX(PersonID) + 1
		FROM PersonInformation

		UPDATE IdentityFields
		SET FieldValue = @PersonID
		WHERE LOWER(TableName) = LOWER('PersonInformation')
		IF( @@ERROR <> 0)
        GOTO Cleanup

		--Add new PersonInformation
		INSERT INTO PersonInformation
		(
			PersonID,
			SocialSecurityNumber,
			PString1,
			AlternateID1,
			AlternateID1Name,
			Title,
			FirstName,
			MiddleName,
			LastName,
			DateOfBirth,
			PString3,
			[Language],
			Email,
			NO_Of_Years_Resi,
			PMoney1,
			PString2,
			PString5,
			Nationality,
			Fax,
			DriversLicenseNumber,
			PMoney2,
			Profession,
			Business_Type,
			Position,
			Department,
			Employee_Number,
			Employment,
			Employer_Code,
			EmploymentPhone,
			EmploymentPhoneExtension,
			FriendName,
			Friend_Off_Phone,
			Friend_Res_Phone,
			Friend_FaxNo
		)
		VALUES
		(
			@PersonID,
			@SocialSecurityNumber,
			@SocialSecurityNumber,
			@AlternateID1,
			@AlternateID1Name,
			@Title,
			@FirstName,
			@MiddleName,
			@LastName,
			@DateOfBirth,
			@PString3,
			@Language,
			@Email,
			@NO_Of_Years_Resi,
			@PMoney1,
			@PString2,
			@PString5,
			@Nationality,
			@Fax,
			@DriversLicenseNumber,
			@PMoney2,
			@Profession,
			@Business_Type,
			@Position,
			@Department,
			@Employee_Number,
			@Employment,
			@Employer_Code,
			@EmploymentPhone,
			@EmploymentPhoneExtension,
			@FriendName,
			@Friend_Off_Phone,
			@Friend_Res_Phone,
			@Friend_FaxNo
		)
		IF( @@ERROR <> 0)
        GOTO Cleanup

		DECLARE @index int
		DECLARE @num int
		SET @num = 9
		
		--Add new 9 PersonAddress and 9 PersonPhone
		DECLARE @AddressID int
		SELECT @AddressID = MAX(AddressID)
		FROM PersonAddress

		UPDATE IdentityFields
		SET FieldValue = @AddressID + @num
		WHERE LOWER(TableName) = LOWER('PersonAddress')

		DECLARE @PhoneID int
		SELECT @PhoneID = MAX(PhoneID)
		FROM PersonPhone

		UPDATE IdentityFields
		SET FieldValue = @PhoneID + @num
		WHERE LOWER(TableName) = LOWER('PersonPhone')
		
		SET @index = 1
		WHILE @index <= @num
		BEGIN
			INSERT INTO PersonAddress
			(
				AddressID,
				PersonID,
				AddressType,
				AddressStatus,
				EmployeeID,
				CreateDate
			)
			VALUES
			(
				@AddressID + @index,
				@PersonID,
				@index,
				0,
				@EmployeeID,
				GETDATE()
			)
			IF( @@ERROR <> 0)
			GOTO Cleanup

			INSERT INTO PersonPhone
			(
				PhoneID,
				PersonID,
				PhoneType,
				PhoneStatus,
				EmployeeID,
				CreateDate
			)
			VALUES
			(
				@PhoneID + @index,
				@PersonID,
				@index,
				0,
				@EmployeeID,
				GETDATE()
			)
			IF( @@ERROR <> 0)
			GOTO Cleanup

			SET @index = @index + 1
		END
	END

	--Insert new CosigneeInformation
	DECLARE @InvoiceNumber varchar(50)
	DECLARE @DebtorID int
	DECLARE @InterfaceID int

	SELECT
		@InvoiceNumber = InvoiceNumber,
		@DebtorID = DebtorID,
		@InterfaceID = InterfaceID
	FROM Account
	WHERE AccountID = @AccountID

	--If CosigneeInformation already existed
	IF EXISTS (SELECT Bill FROM CosigneeInformation WHERE Bill = @AccountID AND PersonID = @PersonID)
	BEGIN
		UPDATE CosigneeInformation
		SET
			DebtorID = @DebtorID,
			Relationship_no = @SocialSecurityNumber,
			Relationship_Type = @Relationship_Type,
			Account_no = @InvoiceNumber,
			InterfaceID = @InterfaceID
		WHERE
			Bill = @AccountID AND PersonID = @PersonID
		IF( @@ERROR <> 0)
        GOTO Cleanup
	END
	ELSE
	BEGIN
		INSERT INTO CosigneeInformation
		(
			Bill,
			PersonID,
			DebtorID,
			Relationship_no,
			Relationship_Type,
			Account_no,
			InterfaceID
		)
		VALUES
		(
			@AccountID,
			@PersonID,
			@DebtorID,
			@SocialSecurityNumber,
			@Relationship_Type,
			@InvoiceNumber,
			@InterfaceID
		)
		IF( @@ERROR <> 0)
        GOTO Cleanup
	END

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_Update]    Script Date: 09/29/2008 10:55:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CosigneeInformation_Update]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_Update]    Script Date: 09/29/2008 10:55:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 25, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_Update] 
	-- Add the parameters for the stored procedure here
	@PersonID int,
	@SocialSecurityNumber varchar(25),
	@AlternateID1 varchar(50),
	@AlternateID1Name varchar(50),
	@Title varchar(50),
	@FirstName varchar(50),
	@MiddleName varchar(50),
	@LastName varchar(50),
	@DateOfBirth smalldatetime = NULL,
	@PString3 varchar(25),
	@Language int,
	@Email varchar(50),
	@NO_Of_Years_Resi varchar(10),
	@PMoney1 money,
	@PString2 varchar(10),
	@PString5 varchar(50),
	@Nationality varchar(50),
	@Fax varchar(30),
	@DriversLicenseNumber varchar(25),
	@PMoney2 money,
	@Profession varchar(50),
	@Business_Type varchar(50),
	@Position varchar(50),
	@Department varchar(35),
	@Employee_Number varchar(50),
	@Employment varchar(50),
	@Employer_Code char(4),
	@EmploymentPhone varchar(30),
	@EmploymentPhoneExtension varchar(8),
	@FriendName varchar(50),
	@Friend_Off_Phone varchar(50),
	@Friend_Res_Phone varchar(30),
	@Friend_FaxNo varchar(30),

	@AccountID int,
	@Relationship_Type varchar(20),

	@EmployeeID int
AS
BEGIN
	DECLARE @TranStarted bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	--Insert a log into CWX_CosigneeLog
	DECLARE @OldRelationShipType varchar(20)
	SELECT @OldRelationShipType = Relationship_Type
	FROM CosigneeInformation
	WHERE
		Bill = @AccountID
		AND PersonID = @PersonID
		
	INSERT INTO CWX_CosigneeLog
	SELECT
		PersonID,
		SocialSecurityNumber,
		PString1,
		AlternateID1,
		AlternateID1Name,
		Title,
		FirstName,
		MiddleName,
		LastName,
		DateOfBirth,
		PString3,
		[Language],
		Email,
		NO_Of_Years_Resi,
		PMoney1,
		PString2,
		PString5,
		Nationality,
		Fax,
		DriversLicenseNumber,
		PMoney2,
		Profession,
		Business_Type,
		Position,
		Department,
		Employee_Number,
		Employment,
		Employer_Code,
		EmploymentPhone,
		EmploymentPhoneExtension,
		FriendName,
		Friend_Off_Phone,
		Friend_Res_Phone,
		Friend_FaxNo,
		@OldRelationShipType,
		@EmployeeID,
		GETDATE()
	FROM PersonInformation
	WHERE PersonID = @PersonID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Update the PersonInformation
	UPDATE PersonInformation
	SET
		SocialSecurityNumber = @SocialSecurityNumber,
		PString1 = @SocialSecurityNumber,
		AlternateID1 = @AlternateID1,
		AlternateID1Name = @AlternateID1Name,
		Title = @Title,
		FirstName = @FirstName,
		MiddleName = @MiddleName,
		LastName = @LastName,
		DateOfBirth = @DateOfBirth,
		PString3 = @PString3,
		[Language] = @Language,
		Email = @Email,
		NO_Of_Years_Resi = @NO_Of_Years_Resi,
		PMoney1 = @PMoney1,
		PString2 = @PString2,
		PString5 = @PString5,
		Nationality = @Nationality,
		Fax = @Fax,
		DriversLicenseNumber = @DriversLicenseNumber,
		PMoney2 = @PMoney2,
		Profession = @Profession,
		Business_Type = @Business_Type,
		Position = @Position,
		Department = @Department,
		Employee_Number = @Employee_Number,
		Employment = @Employment,
		Employer_Code = @Employer_Code,
		EmploymentPhone = @EmploymentPhone,
		EmploymentPhoneExtension = @EmploymentPhoneExtension,
		FriendName = @FriendName,
		Friend_Off_Phone = @Friend_Off_Phone,
		Friend_Res_Phone = @Friend_Res_Phone,
		Friend_FaxNo = @Friend_FaxNo
	WHERE
		PersonID = @PersonID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Update the CosigneeInformation
	DECLARE @InvoiceNumber varchar(50)
	DECLARE @DebtorID int
	DECLARE @InterfaceID int

	SELECT
		@InvoiceNumber = InvoiceNumber,
		@DebtorID = DebtorID,
		@InterfaceID = InterfaceID
	FROM Account
	WHERE AccountID = @AccountID

	UPDATE CosigneeInformation
	SET
		DebtorID = @DebtorID,
		Relationship_no = @SocialSecurityNumber,
		Relationship_Type = @Relationship_Type,
		Account_no = @InvoiceNumber,
		InterfaceID = @InterfaceID
	WHERE
		Bill = @AccountID
		AND PersonID = @PersonID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateFee]    Script Date: 09/29/2008 11:16:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Khoa Dang
ALTER PROCEDURE [dbo].[CWX_Account_UpdateFee]
	@AccountID int,
	@FeeID int
AS
BEGIN
	declare @feeAmount float
	declare @feeType int, @effectBalance smallint	

	/* get fee type and amount of fee */
	select @feeType=FeeType, @feeAmount = case FeeType when 0 then AmountOfFee else FeePercent end,
		@effectBalance = AffectBalance
		from DefineFees d 
			left join TransactionType t on d.TransactionTypeID = t.ID
		where FeeID = @FeeID

	if (@feeType is null) or (@feeAmount is null) /* do not find any information of fee and then cancel transaction */
		return
	
	/* update BillBalance and BillOtherCharge */
	update Account set BillOtherCharges = @feeAmount where AccountID = @AccountID

	if (@feeType = 0)	
	begin		
		if (@effectBalance = 1)
			update Account set BillBalance = BillBalance + @feeAmount where AccountID = @AccountID
		else if (@effectBalance = 2)
			update Account set BillBalance = BillBalance - @feeAmount where AccountID = @AccountID	
	end
	else 
	begin
		if (@feeType = 1)
		begin
			print(@feeType)
			if (@effectBalance = 1) 
				update Account set BillBalance = BillBalance + (BillBalance * @feeAmount) where AccountID = @AccountID
			else if (@effectBalance = 2) update Account set BillBalance = BillBalance - (BillBalance * @feeAmount) where AccountID = @AccountID
		end
		else
		begin
			if (@effectBalance = 1) update Account set BillBalance = BillBalance + (BillAmount * @feeAmount) where AccountID = @AccountID	
			else if (@effectBalance = 1) update Account set BillBalance = BillBalance - (BillAmount * @feeAmount) where AccountID = @AccountID	
		end
	end
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateTransactionAmount]    Script Date: 09/29/2008 13:38:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UpdateTransactionAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_UpdateTransactionAmount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateTransactionAmount]    Script Date: 09/29/2008 13:38:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UpdateTransactionAmount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <20 Aug 2008>
-- Description:	<Update Bill Balance, Bill Amount for 1.Add Other Charge 2.Receive Payment>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_UpdateTransactionAmount] 	
	@AccountID int,
	@TransactionType int, -- 1: Add Other Charge; 2: Receive Payment
	@TransactionAmount money,
	@EffectToBalance int = 0 -- 0: No effect; 1: increase balance; 2: decrease balance
AS
BEGIN	
    
	IF @TransactionType = 1 -- Add Other Charge
		BEGIN
			UPDATE Account 
			SET BillOtherCharges = @TransactionAmount
			WHERE AccountID = @AccountID		

			IF @EffectToBalance = 1
				UPDATE Account 
				SET --BillAmount = BillAmount + @TransactionAmount, 
				BillBalance = BillBalance + @TransactionAmount				
				WHERE AccountID = @AccountID		
			ELSE IF @EffectToBalance = 2
				UPDATE Account 
				SET --BillAmount = BillAmount - @TransactionAmount, 
				BillBalance = BillBalance - @TransactionAmount
				WHERE AccountID = @AccountID	
		END
	ELSE -- Receive Payment
		UPDATE Account 
		SET 
			--BillAmount = BillAmount - @TransactionAmount, 
			BillBalance = BillBalance - @TransactionAmount
		WHERE AccountID = @AccountID		
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionType]    Script Date: 09/29/2008 13:16:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_UpdateTransactionPosted]    Script Date: 09/29/2008 13:16:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_UpdateTransactionPosted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_UpdateTransactionPosted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionType]    Script Date: 09/29/2008 13:16:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get transaction type and total amount of each transaction.
-- History:
--	2008/09/24	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_GetTransactionType]
	@AccountID int,
	@ClientID int
AS
BEGIN
	SET NOCOUNT ON
	
	SELECT     T.TransactionType, SUM(ISNULL(T.TransactionAmount, 0)) AS Amount, TT.Description, TT.TransactionCode, TT.AffectBalance
	FROM         Transactions AS T INNER JOIN
	                      TransactionType AS TT ON T.TransactionType = TT.TransactionType
	WHERE     (T.AccountID = @AccountID) AND (T.ClientID = @ClientID) AND (T.TXN_POSTED = ''N'')
	GROUP BY T.TransactionType, TT.Description, TT.TransactionCode, TT.AffectBalance
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_UpdateTransactionPosted]    Script Date: 09/29/2008 13:16:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_UpdateTransactionPosted]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Update posted transaction.
-- History:
--	2008/09/26	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_UpdateTransactionPosted]
	@AccountID int,
	@ClientID int
AS
BEGIN	
	UPDATE    Transactions
	SET              TXN_POSTED = ''Y''
	WHERE     (AccountID = @AccountID) AND (ClientID = @ClientID) AND (TXN_POSTED = ''N'')
END' 
END
GO

-- Scripts 2.6.27:

EXEC sp_rename @objname = N'[dbo].[CWX_GroupStepLables]', @newname = N'CWX_GroupStepLabels', @objtype = N'OBJECT'
GO

ALTER TABLE PersonInformation ALTER COLUMN [Language] int
GO

ALTER TABLE CosigneeInformation ALTER COLUMN Account_no varchar(50)
GO

/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_GetListByAccountID]    Script Date: 09/29/2008 15:58:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_GetListByAccountID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CosigneeInformation_GetListByAccountID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_GetListByAccountID]    Script Date: 09/29/2008 15:58:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 18, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_GetListByAccountID] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(c.PersonID)
	FROM CosigneeInformation c
	JOIN PersonInformation p ON c.PersonID = p.PersonID
	JOIN PersonAddress a ON a.PersonID = p.PersonID
	WHERE
		a.AddressType = 2
		AND c.Bill = @AccountID

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + p.LastName)) AS RowNumber,
			c.PersonID,
			(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName,
			--c.Relationship_no,
			(r.Code + ' - ' + r.Description) AS Relationship_no,
			a.Address1,
			a.City,
			a.State,
			a.Zip,
			p.HomePhone,
			p.MobilPhone,
			p.EmploymentPhone
		FROM CosigneeInformation c
		JOIN PersonInformation p ON c.PersonID = p.PersonID
		JOIN PersonAddress a ON a.PersonID = p.PersonID
		LEFT JOIN Legal_RelationshipTypes r ON CAST(r.RelationshipTypeID AS varchar(20)) = c.Relationship_Type
		WHERE
			a.AddressType = 2
			AND c.Bill = @AccountID
	)

	SELECT *
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: 29/09/2008
-- Description:	Update store procedure CWX_Legal_CustomFields_GetCustomFields
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFields_GetCustomFields]    Script Date: 09/29/2008 14:10:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Legal_CustomFields_GetCustomFields]
	-- Add the parameters for the stored procedure here
	@ActivityID int,
	@ActivityType int,
	@FieldType int,
	@FieldTypeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF (@FieldTypeID IS NOT NULL AND @FieldTypeID > 0)
	BEGIN
		SELECT	a.[CustomFieldTypeID], a.[Description], a.[Type],
				ISNULL(b.[CustomFieldID],0) [CustomFieldID], ISNULL(b.[ActivityID],0) [ActivityID], 
				ISNULL(b.[ActivityType],0) [ActivityType], ISNULL(b.[Value],'') [Value]
		FROM
			(SELECT [CustomFieldTypeID], [Description], [Type]
			FROM Legal_CustomFieldTypes 
			WHERE [Status] <> 'R' AND FieldType = @FieldType AND FieldTypeID = @FieldTypeID) a
			LEFT JOIN
			(SELECT [CustomFieldID], [CustomFieldTypeID], [ActivityID], [ActivityType], [Value]
			FROM Legal_CustomFields 
			WHERE ActivityID = @ActivityID AND ActivityType = @ActivityType) b
			ON a.CustomFieldTypeID = b.CustomFieldTypeID
		ORDER BY a.[Description]
	END

	ELSE
	BEGIN
		SELECT	a.[CustomFieldTypeID], a.[Description], a.[Type],
				ISNULL(b.[CustomFieldID],0) [CustomFieldID], ISNULL(b.[ActivityID],0) [ActivityID], 
				ISNULL(b.[ActivityType],0) [ActivityType], ISNULL(b.[Value],'') [Value]
		FROM
			(SELECT [CustomFieldID], [CustomFieldTypeID], [ActivityID], [ActivityType], [Value]
			FROM Legal_CustomFields
			WHERE ActivityID = @ActivityID AND ActivityType = @ActivityType) b
			INNER JOIN
			(SELECT [CustomFieldTypeID], [Description], [Type]
			FROM Legal_CustomFieldTypes
			WHERE [Status] <> 'R' AND FieldType = @FieldType) a
			ON a.CustomFieldTypeID = b.CustomFieldTypeID
		ORDER BY a.[Description]
	END

END
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: 29/09/2008
-- Description:	Create store procedure CWX_Account_IsGroupedAccount
-- =============================================
/****** Object:  StoredProcedure [dbo].[CWX_Account_IsGroupedAccount]    Script Date: 09/29/2008 18:14:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_IsGroupedAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_IsGroupedAccount]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_IsGroupedAccount]    Script Date: 09/29/2008 18:14:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_Account_IsGroupedAccount]
	-- Add the parameters for the stored procedure here
	@AccountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	IF EXISTS(	SELECT *
				FROM Legal_GroupDebts a
					INNER JOIN Legal_Groups b ON a.GroupID = b.GroupID
				WHERE a.AccountID = @AccountID AND b.Status <> 'R')
		RETURN 1
	ELSE
		RETURN 0
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_GetDefaultPaymentAllocationRuleOfProduct]    Script Date: 09/30/2008 10:20:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GetDefaultPaymentAllocationRuleOfProduct]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_GetDefaultPaymentAllocationRuleOfProduct]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_GetDefaultPaymentAllocationRuleOfProduct]    Script Date: 09/30/2008 10:20:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GetDefaultPaymentAllocationRuleOfProduct]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get default PaymentAllocationRule of product.
-- History:
--		2008/04/29	[Binh Truong]	Init version
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_GetDefaultPaymentAllocationRuleOfProduct] 	
(
	@ClientID int
)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @PaymentAllocationRuleID int
	
	SELECT @PaymentAllocationRuleID=PaymentAllocationRuleID	FROM ClientInformation WHERE ClientID = @ClientID
	
	SELECT	*
	FROM	Legal_PaymentAllocationRules
	WHERE	PaymentAllocationRuleID = @PaymentAllocationRuleID

END' 
END
GO

-- Scripts 2.6.28:

/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdateFee]    Script Date: 09/30/2008 11:33:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Khoa Dang
ALTER PROCEDURE [dbo].[CWX_Account_UpdateFee]
	@AccountID int,
	@FeeID int
AS
BEGIN
	declare @feeAmount float
	declare @feeType int, @effectBalance smallint	

	/* get fee type and amount of fee */
	select @feeType=FeeType, @feeAmount = case FeeType when 0 then AmountOfFee else FeePercent end,
		@effectBalance = AffectBalance
		from DefineFees d 
			left join TransactionType t on d.TransactionTypeID = t.ID
		where FeeID = @FeeID

	if (@feeType is null) or (@feeAmount is null) /* do not find any information of fee and then cancel transaction */
		return
	
	/* update BillBalance and BillOtherCharge */
	update Account set BillOtherCharges = @feeAmount where AccountID = @AccountID

	if (@feeType = 0)	
	begin		
		if (@effectBalance = 1)
			update Account set BillBalance = BillBalance + @feeAmount where AccountID = @AccountID
		else if (@effectBalance = 2)
			update Account set BillBalance = BillBalance - @feeAmount where AccountID = @AccountID	
	end
	else 
	begin
		if (@feeType = 1)
		begin
			print(@feeType)
			if (@effectBalance = 1) 
				update Account set BillBalance = BillBalance + (BillBalance * @feeAmount) where AccountID = @AccountID
			else if (@effectBalance = 2) update Account set BillBalance = BillBalance - (BillBalance * @feeAmount) where AccountID = @AccountID
		end
		else
		begin
			if (@effectBalance = 1) update Account set BillBalance = BillBalance + (BillAmount * @feeAmount) where AccountID = @AccountID	
			else if (@effectBalance = 2) update Account set BillBalance = BillBalance - (BillAmount * @feeAmount) where AccountID = @AccountID	
		end
	end
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_GetCustomTransactionList]    Script Date: 09/30/2008 14:55:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetCustomTransactionList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetCustomTransactionList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetCustomTransactionList]    Script Date: 09/30/2008 14:55:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetCustomTransactionList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get Transaction List by TransactionType with a custom column is "Transaction Code - Description"
-- History:
--	2008/08/29	[Thuy Nguyen]	Init version.
--	2008/09/29	[Binh Truong]	Select total transaction amount.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetCustomTransactionList] 		
	@AccountID int = 0,
	@TransactionType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;	

	DECLARE @querystring varchar(1000);

	CREATE TABLE #Temp(
		RowNumber int,
		TransactionID int not null,
		DateOfTransaction smalldatetime,
		TransactionAmount money,		
		TransactionComment nvarchar(150),
		TransactionCodeDescription nvarchar(150),
		TransactionType int
	);

	
	SET @querystring = ''INSERT INTO #Temp
		SELECT 
		ROW_NUMBER() OVER (ORDER BY  t.DateOfTransaction DESC) AS RowNumber,
		t.TransactionID, t.DateOfTransaction, t.TransactionAmount, t.TransactionComment,
		tt.TransactionCode + '''' - '''' + tt.Description as TransactionCodeDescription,
		t.TransactionType
	FROM Transactions t LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID
	WHERE t.AccountID = '' + cast(@AccountID as varchar)

	IF @TransactionType<>0 SET @querystring = @querystring + '' AND t.TransactionType = '' + cast(@TransactionType as varchar);
	
	EXEC (@querystring)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	
	SELECT	SUM(TransactionAmount) as TotalAmount
	FROM	Transactions
	WHERE	AccountID = @AccountID AND
			(@TransactionType=0 OR TransactionType = @TransactionType)
			
	
	RETURN @RowCount

END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetChildTransactions]    Script Date: 09/30/2008 14:55:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetChildTransactions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetChildTransactions]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionType]    Script Date: 09/30/2008 14:55:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetChildTransactions]    Script Date: 09/30/2008 14:55:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetChildTransactions]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get child transaction list by parent transaction ID.
-- History:
--	2008/09/29	[Binh Truong]	Init version
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_GetChildTransactions]
	@ParentTransactionID int
	
AS
BEGIN
	SET NOCOUNT ON;	
	SELECT	Transactions.TransactionID, 
			Transactions.TransactionAmount, 
			Transactions.TransactionComment,
			TransactionType.TransactionCode + '' - '' + TransactionType.Description as TransactionCodeDescription	
	FROM         Transactions INNER JOIN
	                      TransactionType ON Transactions.TransactionType = TransactionType.ID
	WHERE	Transactions.PaymentTypeID <> 0 AND
			Transactions.PaymentTypeID = @ParentTransactionID AND
			Transactions.TransactionType NOT IN (901,902,903) AND
			Transactions.TXN_POSTED = ''Y''
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionType]    Script Date: 09/30/2008 14:55:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get transaction type and total amount of each transaction.
-- History:
--	2008/09/24	[Binh Truong]	Init version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transaction_GetTransactionType]
	@AccountID int,
	@ClientID int
AS
BEGIN
	SET NOCOUNT ON
	
	SELECT     T.TransactionType, SUM(ISNULL(T.TransactionAmount, 0)) AS Amount, TT.Description, TT.TransactionCode, TT.AffectBalance
	FROM         Transactions AS T INNER JOIN
	                      TransactionType AS TT ON T.TransactionType = TT.ID
	WHERE     (T.AccountID = @AccountID) AND (T.ClientID = @ClientID) AND (T.TXN_POSTED = ''N'')
	GROUP BY T.TransactionType, TT.Description, TT.TransactionCode, TT.AffectBalance
END

' 
END
GO


-- Scripts 2.6.29:

ALTER TABLE dbo.Transactions ADD
	ParentTransactionID int NULL	
GO

/****** Object:  StoredProcedure [dbo].[CWX_DebtorInfomation_Get]    Script Date: 09/30/2008 17:34:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInfomation_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DebtorInfomation_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInfomation_Get]    Script Date: 09/30/2008 17:35:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		Triet Pham
-- Create date: 03/26/2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DebtorInfomation_Get]
	@DebtorID int,
	@PersonID int = 0
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		TOP 1
		DebtorID, 
		PString3, 
		DebtorInformation.PersonID, 
		CompanyName, 
		DoingBusinessAs, 
		GroupName, 
		HotNote, 
		ZipDelPoint, 
		ZipCart, 
		ReturnedMail, 
		HoldLetters, 
		HoldHomeCalls, 
		HoldWorkCalls, 
		PullCreditReport, 
		SendReminderLetters, 
		DateOfLastCreditReportPull, 
		CreditReportFileName, 
		LastEditDate, 
		LastEditBy, 
		LockedByID, 
		LockedBy, 
		PString1, 
		PString2, 
		PString4, 
		PString5, 
		PString6, 
		PString7, 
		PString8, 
		PString9, 
		PString10, 
		PString11, 
		PString12, 
		PString13, 
		PString14, 
		PString15, 
		PString16, 
		PString17, 
		PString18, 
		PString19, 
		PString20, 
		PString21, 
		PString22, 
		PString23, 
		PString24, 
		PString25, 
		PString26, 
		PString27, 
		PString28, 
		PString29, 
		PString30, 
		PString31, 
		PString32, 
		PString33, 
		PString34, 
		PString35, 
		PString36, 
		PString37, 
		PString38, 
		PString39, 
		PString40, 
		PString41, 
		PString42, 
		PString43, 
		PString44, 
		PString45,
		PMoney1, 
		PMoney2, 
		PMoney3, 
		PMoney4, 
		PMoney5, 
		PMoney6, 
		PMoney7, 
		PMoney8, 
		PMoney9, 
		PMoney10, 
		PMoney11, 
		PMoney12, 
		PMoney13, 
		PMoney14, 
		PMoney15, 
		PMoney16, 
		PMoney17, 
		PMoney18, 
		PMoney19, 
		PMoney20, 
		PMoney21, 
		PMoney22, 
		PMoney23, 
		PMoney24, 
		PMoney25, 
		PLong1, 
		PLong2, 
		PLong3, 
		PLong4, 
		PLong5, 
		PLong6, 
		PLong7, 
		PLong8, 
		PLong9, 
		PLong10, 
		PLong11, 
		PLong12, 
		PLong13, 
		PLong14, 
		PLong15, 
		PLong16, 
		PLong17, 
		PLong18, 
		PLong19, 
		PLong20,
		PLong21, 
		PLong22, 
		PLong23, 
		PLong24, 
		PLong25, 
		PLong26, 
		PLong27, 
		PLong28, 
		PLong29, 
		PLong30, 
		PLong31, 
		PLong32, 
		PLong33, 
		PLong34, 
		PLong35, 
		PLong36, 
		PLong37, 
		PLong38, 
		PLong39, 
		PLong40, 
		PLong41, 
		PLong42, 
		PLong43, 
		PLong44, 
		PLong45, 
		PLong46, 
		PLong47, 
		PLong48, 
		PLong49, 
		PLong50, 
		PString46, 
		PString47, 
		PString48, 
		PString49, 
		PString50, 
		PMoney26, 
		PMoney27, 
		PMoney28, 
		PMoney29, 
		PMoney30, 
		PMoney31, 
		PMoney32, 
		PMoney33, 
		PMoney34, 
		PMoney35, 
		PMoney36, 
		PMoney37, 
		PMoney38, 
		PMoney39, 
		PMoney40, 
		PMoney41, 
		PMoney42, 
		PMoney43, 
		PMoney44, 
		PMoney45, 
		PMoney46, 
		PMoney47, 
		PMoney48, 
		PMoney49, 
		PMoney50, 
		PDate1, 
		PDate2, 
		PDate3, 
		PDate4, 
		PDate5, 
		PDate6, 
		PDate7, 
		PDate8, 
		PDate9, 
		PDate10, 
		LastName, 
		FirstName, 
		MiddleName, 
		Suffix, 
		SocialSecurityNumber, 
		AlternateID1Name, 
		AlternateID1, 
		AlternateID2Name, 
		AlternateID2, 
		DriversLicenseNumber, 
		DateOfBirth, 
		HomePhone, 
		MobilPhone, 
		Employment, 
		EmploymentPhone, 
		EmploymentPhoneExtension, 
		Fax, 
		Email, 
		CallAfter, 
		BankRuptDate, 
		BankRuptType, 
		[Language],
		SpouseID, 
		TimeZone, 
		GMTOffset, 
		Nationality, 
		Other_Phone_Number, 
		Other_Phone_Number1, 
		Home_PO_Box, 
		Nearest_Landmark, 
		NO_Of_Years_Resi, 
		Business_Type, 
		Position, 
		Profession, 
		Department, 
		Employee_Number, 
		Title, 
		Employer_Code, 
		FriendName, 
		Friend_Off_Phone, 
		Friend_Res_Phone, 
		Friend_FaxNo,
		(SELECT COUNT(Account.AccountID) FROM Account WHERE Account.DebtorID = DebtorInformation.DebtorID) AS ACCOUNTCOUNT,
		(SELECT SUM(Account.BillBalance) FROM Account WHERE Account.DebtorID = DebtorInformation.DebtorID) AS ACCOUNTBALANCE
	FROM PersonInformation
	LEFT JOIN DebtorInformation ON DebtorInformation.PersonID = PersonInformation.PersonID
	WHERE
		(@PersonID = 0 AND DebtorInformation.DebtorID = @DebtorID) OR (PersonInformation.PersonID = @PersonID)
	SET NOCOUNT OFF
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_GetCustomTransactionList]    Script Date: 09/30/2008 19:00:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetCustomTransactionList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetCustomTransactionList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 09/30/2008 19:00:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Transaction_GetTransactionPagingList]    Script Date: 09/30/2008 19:00:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionPagingList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get Transaction List by TransactionType with a custom column is "Transaction Code - Description"
-- History:
--	2008/08/29	[Thuy Nguyen]	Init version.
--	2008/09/29	[Binh Truong]	Select total transaction amount.
-- =============================================
create PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList] 		
	@AccountID int = 0,
	@TransactionType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;	

	DECLARE @querystring varchar(1000);

	CREATE TABLE #Temp(
		RowNumber int,
		TransactionID int not null,
		DateOfTransaction smalldatetime,
		TransactionAmount money,		
		TransactionComment nvarchar(150),
		TransactionCodeDescription nvarchar(150),
		TransactionType int
	);

	
	SET @querystring = ''INSERT INTO #Temp
		SELECT 
		ROW_NUMBER() OVER (ORDER BY  t.DateOfTransaction DESC, TransactionID DESC) AS RowNumber,
		t.TransactionID, t.DateOfTransaction, t.TransactionAmount, t.TransactionComment,
		tt.TransactionCode + '''' - '''' + tt.Description as TransactionCodeDescription,
		t.TransactionType
	FROM Transactions t LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID
	WHERE t.AccountID = '' + cast(@AccountID as varchar)

	IF @TransactionType<>0 SET @querystring = @querystring + '' AND t.TransactionType = '' + cast(@TransactionType as varchar);
	
	EXEC (@querystring)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	
	SELECT	SUM(TransactionAmount) as TotalAmount
	FROM	Transactions
	WHERE	AccountID = @AccountID AND
			(@TransactionType=0 OR TransactionType = @TransactionType)
			
	
	RETURN @RowCount

END
' 
END
GO


-- Scripts 2.6.30
GO
-- =============================================
-- Description:	Get Transaction List by TransactionType with a custom column is "Transaction Code - Description"
-- History:
--	2008/08/29	[Thuy Nguyen]	Init version.
--	2008/09/29	[Binh Truong]	Select total transaction amount.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList] 		
	@AccountID int = 0,
	@TransactionType int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;	

	DECLARE @querystring varchar(1000);

	CREATE TABLE #Temp(
		RowNumber int,
		TransactionID int not null,
		DateOfTransaction smalldatetime,
		TransactionAmount money,		
		TransactionComment nvarchar(150),
		TransactionCodeDescription nvarchar(150),
		TransactionType int
	);

	
	SET @querystring = 'INSERT INTO #Temp
		SELECT 
		ROW_NUMBER() OVER (ORDER BY  t.DateOfTransaction DESC, TransactionID DESC) AS RowNumber,
		t.TransactionID, t.DateOfTransaction, t.TransactionAmount, t.TransactionComment,
		tt.TransactionCode + '' - '' + tt.Description as TransactionCodeDescription,
		t.TransactionType
	FROM Transactions t LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID
	WHERE t.AccountID = ' + cast(@AccountID as varchar) + ' AND t.ParentTransactionID IS NULL'

	IF @TransactionType<>0 SET @querystring = @querystring + ' AND t.TransactionType = ' + cast(@TransactionType as varchar);
	
	EXEC (@querystring)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	
	SELECT	SUM(TransactionAmount) as TotalAmount
	FROM	Transactions
	WHERE	AccountID = @AccountID AND
			(@TransactionType=0 OR TransactionType = @TransactionType) AND
			ParentTransactionID IS NULL
			
	
	RETURN @RowCount

END
GO
-- =============================================
-- Description:	Get child transaction list by parent transaction ID.
-- History:
--	2008/09/29	[Binh Truong]	Init version
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Transaction_GetChildTransactions]
	@ParentTransactionID int
	
AS
BEGIN
	SET NOCOUNT ON;	
	SELECT	Transactions.TransactionID, 
			Transactions.TransactionAmount, 
			Transactions.TransactionComment,
			TransactionType.TransactionCode + ' - ' + TransactionType.Description as TransactionCodeDescription	
	FROM         Transactions INNER JOIN
	                      TransactionType ON Transactions.TransactionType = TransactionType.ID
	WHERE	Transactions.PaymentTypeID <> 0 AND
			Transactions.ParentTransactionID = @ParentTransactionID AND
			Transactions.TXN_POSTED = 'Y'
END
GO

--  Script closed