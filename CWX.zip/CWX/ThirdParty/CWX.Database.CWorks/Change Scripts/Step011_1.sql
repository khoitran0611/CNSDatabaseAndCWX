-- Scripts are applied on version 1.6.1
UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_Queue_NoActivityInXDays %E, %1, %2'
WHERE	(ID = 13)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_Queue_NoContactInXDays %E, %1, %2'
WHERE	(ID = 14)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchCollateralItemType %E, %1, %2'
WHERE	(ID = 19)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchCollateralByEmployee %E, %1, %2'
WHERE	(ID = 20)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchCollateralStage %E, %1, %2'
WHERE	(ID = 21)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchCollateralNextAction %E, %1, %2'
WHERE	(ID = 22)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchByLegalForward %E, %1, %2'
WHERE	(ID = 23)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchByLegalEmployee %E, %1, %2'
WHERE	(ID = 24)

UPDATE	QueryMaster
SET		[SQL2] = 'EXEC CWX_Account_SearchByLegalNextAction %E, %1, %2'
WHERE	(ID = 25)

go
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'RuleCriteria' and c.name = 'Combining')
BEGIN
	alter table RuleCriteria add Combining varchar(10) null
END
go


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ReportScheduleParam]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ReportScheduleParam]
GO

CREATE TABLE [dbo].[ReportScheduleParam](
	[PID] [int] IDENTITY(1,1) NOT NULL,
	[ScheduleID] [int] NULL DEFAULT ((0)),
	[ParamName] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ParamType] [varchar](2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ParamValue] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ParamRangeValue] [varchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[NewValue] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[NewRangeValue] [varchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]

GO

 CREATE  INDEX [IDX_ScheduleIDParam] ON [dbo].[ReportScheduleParam]([ScheduleID]) ON [PRIMARY]
GO

GO
/****** Object:  Table [dbo].[CWX_DataDictionary]    Script Date: 05/14/2008 14:12:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DataDictionary]') AND type in (N'U'))
DROP TABLE [dbo].[CWX_DataDictionary]
GO
/****** Object:  Table [dbo].[CWX_DataDictionary]    Script Date: 05/14/2008 14:12:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DataDictionary]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CWX_DataDictionary](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ColumnName] [varchar](100) NOT NULL,
	[Description] [varchar](50) NOT NULL,
	[SQL] [varchar](max) NULL,
 CONSTRAINT [PK_CWX_DataDictionary] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]    Script Date: 05/14/2008 14:11:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]    Script Date: 05/14/2008 14:11:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]
	@RuleType int		
AS
BEGIN
	SET NOCOUNT ON;

	CREATE TABLE #TempTableInfoList
	(
		TableID int,
		TableName varchar(125)
	)
	DECLARE @InterfaceDBName varchar(125)
	SET @InterfaceDBName = ''''	

	IF (@RuleType = 1 or @RuleType = 4) -- Allocation Rule or Temporary Rule
	BEGIN
		DECLARE @AllocationTables VARCHAR(2000)		
		SET @AllocationTables = ''Account,AccountOther,DebtorInformation,PersonInformation,PersonAddress''
		
		INSERT #TempTableInfoList
		SELECT object_id, SplitedText		
		FROM CWX_FnSplitString (@AllocationTables,'','')
		INNER JOIN sys.objects
		ON name = SplitedText
	END
	ELSE IF (@RuleType = 2) -- Extraction Rule
	BEGIN	
		DECLARE @AccountTableName varchar(125)		
		SELECT TOP 1 @InterfaceDBName = InterfaceDBName, @AccountTableName = AccountTable
		FROM Interface WHERE AccountTable is not NULL or AccountTable <> ''''
		ORDER BY InterfaceID

		SET @InterfaceDBName = @InterfaceDBName + ''.''
		SET @AccountTableName = @AccountTableName + '',''

		DECLARE @SelectTableInfoStatement varchar(2000)
		SET @SelectTableInfoStatement = ''INSERT #TempTableInfoList SELECT object_id, SplitedText FROM CWX_FnSplitString ('''''' + @AccountTableName + '''''','''','''')  
										INNER JOIN '' + @InterfaceDBName + ''sys.objects o 
										ON o.name = SplitedText''
		EXEC(@SelectTableInfoStatement)
	END

	DECLARE @SelectDescriptionStatement varchar(2000)
	SET @SelectDescriptionStatement = ''SELECT [COLUMN_NAME] = o.name + ''''.'''' + ltrim(rtrim(c.name)),		  
		[DESCRIPTION] = dbo.CWX_RuleCriteria_FnProcessDescription (ltrim(rtrim(convert(varchar(125), ex.value)))),  
		[DATA_TYPE] = upper(ty.name), c.max_length, 
		[DATABASE] = ''''''
	IF @InterfaceDBName <> ''''	
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + SUBSTRING(@InterfaceDBName, 1, DATALENGTH(@InterfaceDBName) - 1) + ''''''''
	ELSE
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + ''''''''	
	  
	SET @SelectDescriptionStatement = @SelectDescriptionStatement + '' FROM '' +
		@InterfaceDBName + ''sys.objects o 
	INNER JOIN '' +  
		@InterfaceDBName + ''sys.columns c 
	ON 
		o.object_id = c.object_id  
	LEFT OUTER JOIN '' +
		@InterfaceDBName + ''sys.extended_properties ex  
	ON  
		ex.major_id = c.object_id  
		AND ex.minor_id = c.column_id  
		AND ex.name = ''''MS_Description''''  
	LEFT OUTER JOIN '' + 
		@InterfaceDBName + ''sys.types ty  
	ON  
		ty.system_type_id = c.system_type_id  
	WHERE  
		OBJECTPROPERTY(c.object_id, ''''IsMsShipped'''') = 0  
		AND c.object_id in (SELECT TableID FROM #TempTableInfoList)
		AND ex.value is not NULL AND ex.value <> ''''''''
	ORDER  
		BY [DESCRIPTION]''
	
	EXEC (@SelectDescriptionStatement)
	DROP TABLE #TempTableInfoList
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]    Script Date: 05/14/2008 14:11:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]    Script Date: 05/14/2008 14:11:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]
	@InterfaceDBName varchar(125),
	@TableName varchar(125),
	@ColumnName varchar(125)		
AS
BEGIN
	DECLARE @Sql varchar(2000)
	
	select @Sql = [SQL] from CWX_DataDictionary where ColumnName = @TableName + ''.'' + @ColumnName
	if (@Sql is null)
	begin	
		SET @Sql = ''SELECT DISTINCT '' + @ColumnName + '' FROM '' + @InterfaceDBName + ''..'' + @TableName		
		SET @Sql = @Sql + '' WHERE '' + @ColumnName + '' is not NULL''
		SET @Sql = @Sql + '' AND '' + @ColumnName + '' <> ''''''''''
		SET @Sql = @Sql + '' ORDER BY '' + @ColumnName	
	end

	EXEC(@Sql)
END' 
END
GO

alter table CWX_CustomDefinedFields alter column [Value] varchar(750)
go

/****** Object:  StoredProcedure [dbo].[CWX_CustomDefinedFields_Insert]    Script Date: 05/15/2008 09:24:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CustomDefinedFields_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CustomDefinedFields_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CustomDefinedFields_Insert]    Script Date: 05/15/2008 09:24:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CustomDefinedFields_Insert]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Tai Ly
-- Create date: May-06-2005
-- Description:	Insert new tracer information
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CustomDefinedFields_Insert]
	-- Add the parameters for the stored procedure here
	@DebtorID		int,
	@AccountID		int,
	@Description	varchar(100),
	@Value			varchar(1000)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SET ROWCOUNT 0;

    -- Insert statements for procedure here
	INSERT INTO [dbo].[CWX_CustomDefinedFields](AccountID, DebtorID, Description, Value) VALUES(@AccountID, @DebtorID, @Description, @Value)
	
	RETURN @@ROWCOUNT
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetList]    Script Date: 05/15/2008 10:28:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetList]    Script Date: 05/15/2008 10:28:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetList]
	@RuleID int
AS
BEGIN	
	SET NOCOUNT ON;
	CREATE TABLE #Temp
	(
		COLUMN_NAME varchar(125),
		DESCRIPTION varchar(125),
		DATA_TYPE varchar(125),
		[DATABASE] varchar(125)		
	)

	DECLARE @RuleType tinyint
    SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID	

	IF @RuleType <> 3
	BEGIN
		CREATE TABLE #TempTableInfoList
		(
			TableID int,
			TableName varchar(125)
		)
		DECLARE @InterfaceDBName varchar(125)
		SET @InterfaceDBName = ''''	

		IF (@RuleType = 1 or @RuleType = 4) -- Allocation Rule or Temporary Rule
		BEGIN
			DECLARE @AllocationTables VARCHAR(2000)		
			SET @AllocationTables = ''Account,AccountOther,DebtorInformation,PersonInformation,PersonAddress''
			
			INSERT #TempTableInfoList
			SELECT object_id, SplitedText		
			FROM CWX_FnSplitString (@AllocationTables,'','')
			INNER JOIN sys.objects
			ON name = SplitedText
		END
		ELSE IF (@RuleType = 2) -- Extraction Rule
		BEGIN	
			DECLARE @AccountTableName varchar(125)		
			SELECT TOP 1 @InterfaceDBName = InterfaceDBName, @AccountTableName = AccountTable
			FROM Interface WHERE AccountTable is not NULL or AccountTable <> ''''
			ORDER BY InterfaceID

			SET @InterfaceDBName = @InterfaceDBName + ''.''
			SET @AccountTableName = @AccountTableName + '',''

			DECLARE @SelectTableInfoStatement varchar(2000)
			SET @SelectTableInfoStatement = ''INSERT #TempTableInfoList SELECT object_id, SplitedText FROM CWX_FnSplitString ('''''' + @AccountTableName + '''''','''','''')  
											INNER JOIN '' + @InterfaceDBName + ''sys.objects o 
											ON o.name = SplitedText''
			EXEC(@SelectTableInfoStatement)
		END
		
		DECLARE @SelectDescriptionStatement varchar(2000)
		SET @SelectDescriptionStatement = ''INSERT #Temp ''
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + 
			''SELECT [COLUMN_NAME] = o.name + ''''.'''' + ltrim(rtrim(c.name)),		  
			[DESCRIPTION] = dbo.CWX_RuleCriteria_FnProcessDescription (ltrim(rtrim(convert(varchar(125), ex.value)))),  
			[DATA_TYPE] = upper(ty.name), 
			[DATABASE] = ''''''
		IF @InterfaceDBName <> ''''	
			SET @SelectDescriptionStatement = @SelectDescriptionStatement + SUBSTRING(@InterfaceDBName, 1, DATALENGTH(@InterfaceDBName) - 1) + ''''''''
		ELSE
			SET @SelectDescriptionStatement = @SelectDescriptionStatement + ''''''''	
		  
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + '' FROM '' +
			@InterfaceDBName + ''sys.objects o 
		INNER JOIN '' +  
			@InterfaceDBName + ''sys.columns c 
		ON 
			o.object_id = c.object_id  
		LEFT OUTER JOIN '' +
			@InterfaceDBName + ''sys.extended_properties ex  
		ON  
			ex.major_id = c.object_id  
			AND ex.minor_id = c.column_id  
			AND ex.name = ''''MS_Description''''  
		LEFT OUTER JOIN '' + 
			@InterfaceDBName + ''sys.types ty  
		ON  
			ty.system_type_id = c.system_type_id		 		 
		WHERE  
			OBJECTPROPERTY(c.object_id, ''''IsMsShipped'''') = 0  
			AND c.object_id in (SELECT TableID FROM #TempTableInfoList)
			AND ex.value is not NULL AND ex.value <> ''''''''
		ORDER  
			BY [DESCRIPTION]''
		
		EXEC (@SelectDescriptionStatement)		
		
		SELECT r.*, t.DESCRIPTION
		FROM RuleCriteria r
		INNER JOIN #Temp t ON r.Criteria = t.COLUMN_NAME
		WHERE RuleID = @RuleID
		ORDER BY ID

		DROP TABLE #TempTableInfoList
		DROP TABLE #Temp
	END
	ELSE --Result Processing Rule
	BEGIN
		SELECT *, Criteria AS DESCRIPTION
		FROM RuleCriteria
		WHERE RuleID = @RuleID
		ORDER BY ID
	END
END
' 
END
GO

alter table RuleCriteria alter column SQLFormat varchar(350)
go

/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]    Script Date: 05/15/2008 16:06:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetEmployeePortfolio]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]    Script Date: 05/15/2008 16:06:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetEmployeePortfolio]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get employee portfolio.
-- Parameters: 
--		0: Queue Active
--		Other number: All accounts
-- History:
--		2008/04/17	[Binh Truong]	Init version.
--		2008/05/15	[Binh Truong]	Cast BillBalance field to decimal(18,2) to fix Arithmetic overflow error converting expression.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]
	@PorfolioType smallint = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @TotalAccStatement NVARCHAR(1000)
	DECLARE @TotalDollarValueStatement NVARCHAR(1000)
	DECLARE @MainStatement NVARCHAR(4000)
	DECLARE @RowCount INT
	
	SET @Conditions = ''''	

	IF @PorfolioType = 0		
		SET @Conditions = ''
			AND SystemStatusId = 5 
			AND AgencyStatusID <> 2 
			AND QueueDate <= GETDATE()
			''
	
	DECLARE @ParmDefinition NVARCHAR(500);
	DECLARE @TotalAccount INT;
	DECLARE @TotalDollarValue DECIMAL(18,2);

	SET @TotalAccStatement = N''SELECT @TotalAccountOUT = COUNT(*) FROM Account WHERE (1=1) '';
	SET @TotalAccStatement = @TotalAccStatement + @Conditions
	SET @ParmDefinition = N''@TotalAccountOUT INT OUTPUT'';

	EXECUTE sp_executesql @TotalAccStatement, @ParmDefinition, @TotalAccountOUT=@TotalAccount OUTPUT;

	SET @TotalDollarValueStatement = N''SELECT @TotalDollarValueOUT = SUM(BillBalance) FROM Account WHERE (1=1)'';
	SET @TotalDollarValueStatement = @TotalDollarValueStatement + @Conditions
	SET @ParmDefinition = N''@TotalDollarValueOUT DECIMAL(18,2) OUTPUT'';

	EXECUTE sp_executesql @TotalDollarValueStatement, @ParmDefinition, @TotalDollarValueOUT=@TotalDollarValue OUTPUT;
	
	--Build the MainStatement
	SET @MainStatement = ''INSERT INTO #Temp SELECT Employee.EmployeeID, Employee.EmployeeName, ''

	SET @MainStatement = @MainStatement + '' (SELECT COUNT(EmployeeID) AS Expr1
						FROM          Account AS AT
						WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalAccount, ''
	
	SET @MainStatement = @MainStatement + '' (SELECT CAST(((COUNT(EmployeeID) * 100) / CAST('' + CAST(@TotalAccount AS VARCHAR(30)) + '' AS DECIMAL(18,2))) AS DECIMAL(18,2)) AS Expr1
						FROM          Account AS AT
						WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalAccountPercent, ''
    
	SET @MainStatement = @MainStatement + '' (SELECT     CAST(SUM(BillBalance) as decimal(18,2)) 
                    FROM        Account AS AT
                    WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalDollarValue, ''

	SET @MainStatement = @MainStatement + '' (SELECT     CAST(SUM(BillBalance) as decimal(18,2)) * 100 / CAST('' + CAST(@TotalDollarValue AS VARCHAR(30)) + ''AS DECIMAL(18,2)) AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.EmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.EmployeeID) AS TotalDollarValuePercent, ''

	SET @MainStatement = @MainStatement + '' (SELECT     COUNT(TempEmployeeID) AS Expr1
					FROM          Account AS AT
					WHERE      (AT.TempEmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.TempEmployeeID) AS TotalAccountTemp, '' 

	SET @MainStatement = @MainStatement + '' (SELECT     SUM(BillBalance) AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.TempEmployeeID = Employee.EmployeeID) '' + @Conditions + '' GROUP BY AT.TempEmployeeID) AS TotalDollarValueAccountTemp ''

	SET @MainStatement = @MainStatement +	'' FROM  Employee WHERE EmployeeStatus = ''''A'''''' 

	CREATE TABLE #Temp
	(
		Idx int IDENTITY,
		EmployeeID int,
		EmployeeName varchar(50),
		TotalAccount int,
		TotalAccountPercent DECIMAL(18,0),
		TotalDollarValue DECIMAL(18,2),
		TotalDollarValuePercent DECIMAL(18,0),
		TotalAccountTemp int,
		TotalDollarValueAccountTemp DECIMAL(18,2)		
	)

	EXEC dbo.sp_executesql @MainStatement
	
	SELECT @RowCount = Count(Idx) FROM #Temp

	SELECT  EmployeeName,
			EmployeeID,
			ISNULL(TotalAccount, 0) AS TotalAccount,
			CAST(ISNULL(TotalAccountPercent, 0) as varchar(50)) AS TotalAccountPercent,
			ISNULL(TotalDollarValue, 0) AS TotalDollarValue,
			CAST(ISNULL(TotalDollarValuePercent, 0) as varchar(50)) AS TotalDollarValuePercent,
			ISNULL(TotalAccountTemp, 0) AS TotalAccountTemp,
			ISNULL(TotalDollarValueAccountTemp, 0) AS TotalDollarValueAccountTemp
			
	FROM #Temp WHERE Idx between (@PageIndex)*@PageSize + 1 and (@PageIndex + 1)*@PageSize

	DROP TABLE #Temp
	
	RETURN @RowCount
END


' 
END
GO

/****** Object:  Table [dbo].[Referrals]    Script Date: 05/15/2008 16:22:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Referrals]') AND type in (N'U'))
DROP TABLE [dbo].[Referrals]
GO
/****** Object:  Table [dbo].[Referrals]    Script Date: 05/15/2008 16:22:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Referrals]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Referrals](
	[ClientID] [int] NOT NULL,
	[ClientName] [varchar](40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Priority] [int] NULL CONSTRAINT [DF_Referrals_Priority]  DEFAULT (0),
	[Address1] [varchar](40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Address2] [varchar](40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Address3] [varchar](40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[City] [varchar](24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[State] [varchar](16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Zip] [varchar](16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Country] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Region] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Territory] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PhoneNumber] [varchar](16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FaxNumber] [varchar](16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ContactName] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ContactExtension] [varchar](8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[EMail] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FirstReferralDate] [smalldatetime] NULL,
	[LastReferralDate] [smalldatetime] NULL,
	[AccountTypeID] [int] NULL,
	[GrossClientFlag] [tinyint] NULL,
	[ReportDebtorsFlag] [bit] NOT NULL,
	[DeductARBalanceFlag] [bit] NOT NULL,
	[ChargeInterestFlag] [bit] NOT NULL,
	[ReceivedStatement] [bit] NOT NULL,
	[MinimumBalanceToReport] [money] NULL,
	[PreviousARBalance] [money] NULL,
	[PreviousAPBalance] [money] NULL,
	[ClientPercent] [real] NULL,
	[ClientOCPercent] [real] NULL,
	[ClientLegalPercent] [real] NULL,
	[AcknowledgmentReport] [smallint] NULL,
	[InventoryReport] [smallint] NULL,
	[StatementReport] [smallint] NULL,
	[HistoryReport] [smallint] NULL,
	[SalesmanID] [int] NULL,
	[SalesmanPercentage] [real] NULL,
	[ClientPayCycle] [tinyint] NULL,
	[MasterClient] [int] NULL,
	[Referral] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[AgingForReschedule] [money] NULL CONSTRAINT [DF__Referrals__Aging__4CE05A84]  DEFAULT (0),
	[AgingForDiscount] [money] NULL CONSTRAINT [DF__Referrals__Aging__4DD47EBD]  DEFAULT (0),
	[RescheduleAllowed] [int] NULL DEFAULT (0),
	[DiscountAllowed] [int] NULL DEFAULT (0),
	[DeptIDs] [varchar](1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_Referrals_DeptIDs]  DEFAULT (''),
	[LetterheadImage] [image] NULL,
	[Status] [char](1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [Referrals_RowStatus]  DEFAULT ('A')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[Referrals].[ReportDebtorsFlag]' , @futureonly='futureonly'
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[Referrals].[DeductARBalanceFlag]' , @futureonly='futureonly'
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[Referrals].[ChargeInterestFlag]' , @futureonly='futureonly'
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[Referrals].[ReceivedStatement]' , @futureonly='futureonly'
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_false]', @objname=N'[dbo].[Referrals].[Referral]' , @futureonly='futureonly'
GO
EXEC sys.sp_bindefault @defname=N'[dbo].[def_value_true]', @objname=N'[dbo].[Referrals].[Active]' , @futureonly='futureonly'
GO

/****** Object:  Index [IDX_CLIPRIO]    Script Date: 05/15/2008 16:22:37 ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Referrals]') AND name = N'IDX_CLIPRIO')
CREATE CLUSTERED INDEX [IDX_CLIPRIO] ON [dbo].[Referrals] 
(
	[ClientID] ASC,
	[Priority] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
GO

/****** Object:  Index [IDX_CLIENTID]    Script Date: 05/15/2008 16:22:37 ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Referrals]') AND name = N'IDX_CLIENTID')
CREATE NONCLUSTERED INDEX [IDX_CLIENTID] ON [dbo].[Referrals] 
(
	[ClientID] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
GO

/****** Object:  Index [IDX_PRIO]    Script Date: 05/15/2008 16:22:37 ******/
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[Referrals]') AND name = N'IDX_PRIO')
CREATE NONCLUSTERED INDEX [IDX_PRIO] ON [dbo].[Referrals] 
(
	[Priority] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CustomDefinedFields_Insert]    Script Date: 05/15/2008 09:24:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CustomDefinedFields_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CustomDefinedFields_Insert]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Report_Schedule_Param_Update]    Script Date: 05/15/2008 17:52:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Report_Schedule_Param_Update]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Khoa Duong
-- Create date: May-06-2005
-- Description:	Update report schedule parameters
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Report_Schedule_Param_Update]
	-- Add the parameters for the stored procedure here
	@ScheduleID		int,
	@ParamName		varchar(50),
	@ParamValue		varchar(250),	
	@NewValue		varchar(25),
	@NewRangeValue		varchar(250),
	@IsRange		bit
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SET ROWCOUNT 0;

    -- Insert statements for procedure here
    IF (@IsRange = 1)
		BEGIN
			UPDATE [dbo].[ReportScheduleParam] SET ParamRangeValue = @ParamValue WHERE ScheduleID = @ScheduleID AND ParamName = @ParamName
		END	
	ELSE
		BEGIN
			UPDATE [dbo].[ReportScheduleParam] SET ParamValue = @ParamValue WHERE ScheduleID = @ScheduleID AND ParamName = @ParamName
		END	
		
	
	RETURN @@ROWCOUNT
END
' 
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'QueryDebtorInfoMaster' and c.name = 'ExecOrder')
BEGIN
	ALTER TABLE QueryDebtorInfoMaster
	ADD ExecOrder [int] NOT NULL
		CONSTRAINT [DF_QueryDebtorInfoMaster_ExecOrder]  DEFAULT ((0))
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'QueryDebtorInfoMaster' and c.name = 'ExecEnabled')
BEGIN
	ALTER TABLE QueryDebtorInfoMaster
	ADD ExecEnabled [int] NOT NULL
		CONSTRAINT [DF_QueryDebtorInfoMaster_ExecEnabled]  DEFAULT ((1))
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'QueryDebtorInfoMaster' and c.name = 'TableName')
BEGIN
	ALTER TABLE QueryDebtorInfoMaster
	ADD TableName [nvarchar](100) NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'QueryDebtorInfoMaster' and c.name = 'RowName')
BEGIN
	ALTER TABLE QueryDebtorInfoMaster
	ADD RowName [nvarchar](100) NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'QueryDebtorInfoMaster' and c.name = 'ParentXPath')
BEGIN
	ALTER TABLE QueryDebtorInfoMaster
	ADD ParentXPath [nvarchar](100) NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'QueryDebtorInfoMaster' and c.name = 'ParentField')
BEGIN
	ALTER TABLE QueryDebtorInfoMaster
	ADD ParentField [nvarchar](100) NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'QueryDebtorInfoMaster' and c.name = 'ChildField')
BEGIN
	ALTER TABLE QueryDebtorInfoMaster
	ADD ChildField [nvarchar](100) NULL
END
GO

UPDATE QueryDebtorInfoMaster SET ExecOrder = 1
WHERE InfoType = 1

UPDATE QueryDebtorInfoMaster SET ExecOrder = 2, TableName = 'PersonAddresses', RowName = 'PersonAddress'
WHERE InfoType = 2

UPDATE QueryDebtorInfoMaster SET ExecOrder = 3, TableName = 'PersonPhones', RowName = 'PersonPhone'
WHERE InfoType = 3

UPDATE QueryDebtorInfoMaster SET Sql = 'Exec CWX_Spouse_Get %D', ExecOrder = 4, RowName = 'Spouse'
WHERE InfoType = 4

UPDATE QueryDebtorInfoMaster SET Sql = 'Exec CWX_Notes_Get %D, %A, %N', ExecOrder = 7, TableName = 'Notes', RowName = 'Note', ParentXPath = 'Accounts/Account', ParentField = 'AccountID', ChildField = 'BillID'
WHERE InfoType = 5

UPDATE QueryDebtorInfoMaster SET ExecOrder = 5, TableName = 'Tickets', RowName = 'Ticket'
WHERE InfoType = 6

UPDATE QueryDebtorInfoMaster SET ExecOrder = 6, TableName = 'Accounts', RowName = 'Account'
WHERE InfoType = 7

UPDATE QueryDebtorInfoMaster SET ExecOrder = 8, ExecEnabled = 0
WHERE InfoType = 8

UPDATE QueryDebtorInfoMaster SET ExecOrder = 9, ExecEnabled = 0
WHERE InfoType = 9

GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 05/16/2008 11:51:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetListByRule]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 05/16/2008 11:51:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByRule]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 24, 2008
-- Description:	Retrieve records that match the rulecriterias of a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetListByRule] 
	-- Add the parameters for the stored procedure here
	@RuleID int,
	@PageSize int = 10,
	@PageIndex int = 0,
	@ProcessedAccountIDs varchar(4000) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat, Combining
		FROM RuleCriteria
		WHERE RuleID = @RuleID

	DECLARE @SQLFormat varchar(700)
	DECLARE @Combining varchar(10)
	DECLARE @NeedCombining varchar(10)
	DECLARE @WhereClause varchar(2000)
	SET @NeedCombining = ''And''

	OPEN RuleCriteriaCrsr
	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @WhereClause = ISNULL(@WhereClause, '''') + '' '' + @NeedCombining + '' '' + @SQLFormat
		SET @NeedCombining = @Combining /* remember previous value */

		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	END

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr

	--Remove the Account that was processed
	IF @ProcessedAccountIDs IS NOT NULL AND @ProcessedAccountIDs <> ''''
	BEGIN
		SELECT CAST(SplitedText AS int) AS AccountID
		INTO #ProcessedAccountIDs
		FROM CWX_FnSplitString(@ProcessedAccountIDs, ''|'')

		SET @WhereClause = @WhereClause + '' AND Account.AccountId NOT IN (SELECT AccountID FROM #ProcessedAccountIDs)''
	END

	--This is used for AllocationRule, if RuleType=1, append condition <Account.MAINTAINOFFICER = 0>
	DECLARE @RuleType tinyint
	SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID
	IF @RuleType = 1
		SET @WhereClause = '' AND Account.MAINTAINOFFICER = 0'' + @WhereClause

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY PRIMARY KEY,
		AccountId int,
		DebtorId int,
		FirstName varchar(50),
		MiddleName varchar(50),
		LastName varchar(50),
		BillBalance money,
		BillAmount money,
		InvoiceNumber varchar(50)
	)

	DECLARE @Sql varchar(4000)

	SET @Sql = ''INSERT INTO #Temp''
				+ '' SELECT''
				+ '' Account.AccountId,Account.DebtorId,PersonInformation.FirstName,PersonInformation.MiddleName,PersonInformation.LastName,Account.BillBalance,Account.BillAmount,Account.InvoiceNumber''
				+ '' FROM Account''
				+ '' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID''
				+ '' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID''
				+ '' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID''
				+ '' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID''
				+ '' WHERE (PersonAddress.MailingAddress = 1)''
				+ @WhereClause
				+ '' ORDER BY Account.AccountId''


	EXEC (@Sql)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	DROP TABLE #Temp

	RETURN @RowCount
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]    Script Date: 05/16/2008 11:51:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]    Script Date: 05/16/2008 11:51:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]
	@RuleType int		
AS
BEGIN
	SET NOCOUNT ON;

	CREATE TABLE #TempTableInfoList
	(
		TableID int,
		TableName varchar(125)
	)
	DECLARE @InterfaceDBName varchar(125)
	SET @InterfaceDBName = ''''	

	IF (@RuleType = 1 or @RuleType = 4) -- Allocation Rule or Temporary Rule
	BEGIN
		DECLARE @AllocationTables VARCHAR(2000)		
		SET @AllocationTables = ''Account,AccountOther,DebtorInformation,PersonInformation,PersonAddress''
		
		INSERT #TempTableInfoList
		SELECT object_id, SplitedText		
		FROM CWX_FnSplitString (@AllocationTables,'','')
		INNER JOIN sys.objects
		ON name = SplitedText
	END
	ELSE IF (@RuleType = 2) -- Extraction Rule
	BEGIN	
		DECLARE @AccountTableName varchar(125)		
		SELECT TOP 1 @InterfaceDBName = InterfaceDBName, @AccountTableName = AccountTable
		FROM Interface WHERE AccountTable is not NULL or AccountTable <> ''''
		ORDER BY InterfaceID

		SET @InterfaceDBName = @InterfaceDBName + ''.''
		SET @AccountTableName = @AccountTableName + '',''

		DECLARE @SelectTableInfoStatement varchar(2000)
		SET @SelectTableInfoStatement = ''INSERT #TempTableInfoList SELECT object_id, SplitedText FROM CWX_FnSplitString ('''''' + @AccountTableName + '''''','''','''')  
										INNER JOIN '' + @InterfaceDBName + ''sys.objects o 
										ON o.name = SplitedText''
		EXEC(@SelectTableInfoStatement)
	END

	DECLARE @SelectDescriptionStatement varchar(2000)
	SET @SelectDescriptionStatement = ''SELECT [COLUMN_NAME] = o.name + ''''.'''' + ltrim(rtrim(c.name)),		  
		[DESCRIPTION] = dbo.CWX_RuleCriteria_FnProcessDescription (ltrim(rtrim(convert(varchar(125), ex.value)))),  
		[DATA_TYPE] = upper(ty.name), c.max_length, c.precision, 
		[DATABASE] = ''''''
	IF @InterfaceDBName <> ''''	
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + SUBSTRING(@InterfaceDBName, 1, DATALENGTH(@InterfaceDBName) - 1) + ''''''''
	ELSE
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + ''''''''	
	  
	SET @SelectDescriptionStatement = @SelectDescriptionStatement + '' FROM '' +
		@InterfaceDBName + ''sys.objects o 
	INNER JOIN '' +  
		@InterfaceDBName + ''sys.columns c 
	ON 
		o.object_id = c.object_id  
	LEFT OUTER JOIN '' +
		@InterfaceDBName + ''sys.extended_properties ex  
	ON  
		ex.major_id = c.object_id  
		AND ex.minor_id = c.column_id  
		AND ex.name = ''''MS_Description''''  
	LEFT OUTER JOIN '' + 
		@InterfaceDBName + ''sys.types ty  
	ON  
		ty.system_type_id = c.system_type_id  
	WHERE  
		OBJECTPROPERTY(c.object_id, ''''IsMsShipped'''') = 0  
		AND c.object_id in (SELECT TableID FROM #TempTableInfoList)
		AND ex.value is not NULL AND ex.value <> ''''''''
	ORDER  
		BY [DESCRIPTION]''
	
	EXEC (@SelectDescriptionStatement)
	DROP TABLE #TempTableInfoList
END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]    Script Date: 05/16/2008 13:51:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]    Script Date: 05/16/2008 13:51:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]
	@InterfaceDBName varchar(125),
	@TableName varchar(125),
	@ColumnName varchar(125)		
AS
BEGIN
	DECLARE @Sql varchar(2000)
	
	select @Sql = [SQL] from CWX_DataDictionary where ColumnName = @TableName + ''.'' + @ColumnName
	if (@Sql is null)
	begin
		SET @Sql = ''SELECT DISTINCT '' + @ColumnName + '' FROM '' + @InterfaceDBName + ''..'' + @TableName		
		SET @Sql = @Sql + '' WHERE '' + @ColumnName + '' is not NULL''
		SET @Sql = @Sql + '' AND Len('' + @ColumnName + '') > 0''
		SET @Sql = @Sql + '' ORDER BY '' + @ColumnName	
	end

	EXEC(@Sql)
END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_CustomDefinedField_Select]    Script Date: 05/16/2008 18:39:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_CustomDefinedField_Select]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TracerInformation_CustomDefinedField_Select]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]    Script Date: 05/16/2008 18:39:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_CustomDefinedField_Select]    Script Date: 05/16/2008 18:39:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_CustomDefinedField_Select]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Tuan Luong
-- Create date: May 15, 2008
-- Description:	Get custom defined fields.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TracerInformation_CustomDefinedField_Select]	
	@DebtorID	int,
	@AccountID	int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	SELECT ROW_NUMBER() OVER (ORDER BY Description) AS RowNumber, ID, Description, [Value], FormatString		
	INTO #Temp
	FROM CWX_CustomDefinedFields c INNER JOIN AgencyDefinedMaster a
	ON c.AgencyID = a.AgencyDefID
	WHERE c.AgencyID <> 0 AND c.AccountID = @AccountID AND c.DebtorID = @DebtorID AND a.Status <> ''R''

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF @PageSize <= 0
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]    Script Date: 05/16/2008 18:39:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--select * from CWX_CustomDefinedFields
--select * from dbo.AgencyDefinedMaster


-- ===================================================================================
-- Author:		Tuan Luong
-- Create date: May 15, 2008
-- Description:	Initializes CustomDefinedFields within the given debtorID, accountID.
-- ===================================================================================
CREATE PROC CWX_TracerInformation_CustomDefinedFields_Initialize
	@DebtorID INT,
	@AccountID INT
AS
BEGIN
	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE AgencyDefinedMasterCrsr CURSOR FOR
	SELECT AgencyDefID, LongName
	FROM AgencyDefinedMaster
	WHERE AgencyDefID not in (Select AgencyID From CWX_CustomDefinedFields Where AccountID = @AccountID and DebtorID = @DebtorID)
		AND Status <> ''R''


	DECLARE @AvailAgencyID INT
	DECLARE @AvailLongName VARCHAR(100)
	
	OPEN AgencyDefinedMasterCrsr
	FETCH NEXT FROM AgencyDefinedMasterCrsr
	INTO @AvailAgencyID, @AvailLongName

	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT CWX_CustomDefinedFields (AgencyID, AccountID, DebtorID, Description)
		VALUES (@AvailAgencyID, @AccountID, @DebtorID, @AvailLongName)

		IF( @@ERROR <> 0)
			GOTO Cleanup		

		FETCH NEXT FROM AgencyDefinedMasterCrsr
		INTO @AvailAgencyID, @AvailLongName
	END
	
	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

	CLOSE AgencyDefinedMasterCrsr
	DEALLOCATE AgencyDefinedMasterCrsr

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END	
END' 
END
GO

/******  Script Closed. Go next: Step011_2  ******/