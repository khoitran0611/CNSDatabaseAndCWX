-- Script is applied on version 2.3.8

-- Scripts 2.3.8

--Script to truncate data in DBWork
delete dbo.Employee where EmployeeID not in (1001,1002)
delete dbo.EmployeePool where EmployeeID not in (1001,1002)

/******  Script Closed. Go next: Step018_1  ******/