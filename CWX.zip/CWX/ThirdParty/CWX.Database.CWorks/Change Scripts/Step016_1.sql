 -- Script is applied on version 2.2.1, 2.2.2, 2.2.4
/****** Object:  Table [dbo].[TempDebtorXml]    Script Date: 07/14/2008 14:35:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TempDebtorXml]') AND type in (N'U'))
DROP TABLE [dbo].[TempDebtorXml]
GO
/****** Object:  Table [dbo].[TempDebtorXml]    Script Date: 07/14/2008 14:35:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[TempDebtorXml](
	[DebtorID] [int] NOT NULL,
	[SessionID] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DebtorXML] [xml] NOT NULL,
	[IsDirty] [bit] NOT NULL CONSTRAINT [DF_TempDebtorXml_IsDirty]  DEFAULT ((0)),
 CONSTRAINT [PK_TempDebtorXml] PRIMARY KEY CLUSTERED 
(
	[DebtorID] ASC,
	[SessionID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 15, 2008
-- Description:		Add one more columns
-- Effected table:	Legal_GroupDebtors
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id 
WHERE o.name = 'Legal_GroupDebtors' and c.name = 'PersonID')
BEGIN
	ALTER TABLE dbo.Legal_GroupDebtors ADD
		PersonID [int] NOT NULL
	
	ALTER TABLE Legal_GroupDebtors
		ALTER COLUMN DebtorID int NULL
END
GO


update QueryParams set Text='Legal Group', Format='^\d{0,9}$', PickList='' where QueryID=23
GO
update QueryMaster set SQL='EXEC SearchByLegalGroupCode %1', SQL2='EXEC , SearchByLegalGroupCode %1' where ID=23
GO

/****** Object:  StoredProcedure [dbo].[SearchByLegalGroupCode]    Script Date: 07/15/2008 17:48:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchByLegalGroupCode]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SearchByLegalGroupCode]
GO
/****** Object:  StoredProcedure [dbo].[SearchByLegalGroupCode]    Script Date: 07/15/2008 17:48:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SearchByLegalGroupCode]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
CREATE PROCEDURE [dbo].[SearchByLegalGroupCode]
	@GroupID int
AS
BEGIN
DECLARE @cStmt NVARCHAR(4000)
DECLARE @v_SortOrder VarChar(700)
SET @cStmt=''Select  convert(varchar(10), a.DebtorID) + ''''|'''' + convert(varchar(10), a.AccountID) as KeyField,''
	SET @cStmt=@cStmt+''convert(char(10), a.QueueDate, 111) as [QueueDate],''
	SET @cStmt=@cStmt+''a.AccountAge as [DPD],''
	SET @cStmt=@cStmt+''CAST(a.MCode AS CHAR(2)) as [Bucket],''
	SET @cStmt=@cStmt+''a.CCode as [Cycle],''
	SET @cStmt=@cStmt+''a.BillAmount  as [Bill Amount],''
	SET @cStmt=@cStmt+''a.BillBalance  as [Bill Balance],''
	SET @cStmt=@cStmt+''s.ShortDesc as [Status],''
	SET @cStmt=@cStmt+''s.SortPriority as [Priority],''
	SET @cStmt=@cStmt+''a.AssignmentType as [Assignment Type],''
	SET @cStmt=@cStmt+''p.SocialSecurityNumber as [ID],''
	SET @cStmt=@cStmt+''rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName) As [ Name],''
	SET @cStmt=@cStmt+''g.Code as [Legal Group Code]''
SET @cStmt=@cStmt+'' from ''
	SET @cStmt=@cStmt+''Account a,''
	SET @cStmt=@cStmt+''AccountStatus s,''
	SET @cStmt=@cStmt+''Legal_GroupDebts gd,''
	SET @cStmt=@cStmt+''dbo.Legal_Groups g,''
	SET @cStmt=@cStmt+''DebtorInformation d,''
	SET @cStmt=@cStmt+''PersonInformation p''

	SET @cStmt=@cStmt+'' where a.AccountID = gd.AccountID''
	SET @cStmt=@cStmt+'' and gd.GroupID = g.GroupID''
	SET @cStmt=@cStmt+'' and s.AgencyStatus = a.AgencyStatusID''
	SET @cStmt=@cStmt+'' and d.DebtorID = a.DebtorID''
	SET @cStmt=@cStmt+'' and p.PersonID = d.PersonID''
	SET @cStmt=@cStmt+'' and a.DebtorID <> 0 and gd.IsInclude=1 and g.GroupID='' + STR(@GroupID)
	SET @cStmt=@cStmt+'' order by ''
    Exec CW_SORT_ORDER @v_SortOrder Out 
    if @v_SortOrder='''' 
       Set @cStmt=@cStmt+'' "QueueDate" DESC''
    Else
       Set @cStmt=@cStmt+Replace(@v_SortOrder,''Delq_String'',''StrOrder'')
	
Exec SP_ExecuteSQL @cStmt
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_LegalGroupDescription_Get]    Script Date: 07/15/2008 18:04:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LegalGroupDescription_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LegalGroupDescription_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_LegalGroupDescription_Get]    Script Date: 07/15/2008 18:04:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LegalGroupDescription_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
CREATE PROCEDURE CWX_LegalGroupDescription_Get
	@AccountID int
AS
BEGIN
	select STR(g.GroupID) + '' - '' + g.Description from Legal_Groups g, Legal_GroupDebts gd
		where g.GroupID=gd.GroupID and gd.AccountID=@AccountID
END
' 
END
GO

-- =======================================================================
-- Author:			Thao Nguyen
-- Create date:		Jul 16, 2008
-- Description:		Rename column
-- Effected table:	Legal_GroupDebts
-- =======================================================================
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id 
WHERE o.name = 'Legal_GroupDebts' and c.name = 'IsPrincipal')
BEGIN

	ALTER TABLE dbo.Legal_GroupDebts DROP CONSTRAINT
		DF_Legal_GroupDebts_IsPrincipal
		
	ALTER TABLE dbo.Legal_GroupDebts DROP COLUMN
		IsPrincipal
				
	ALTER TABLE dbo.Legal_GroupDebts ADD
		IsPrimary bit NOT NULL CONSTRAINT DF_Legal_GroupDebts_IsPrimary DEFAULT 0
END
GO

update QueryParams set Text='Legal Solicitors', PickList='Select ClientID,ClientName from ClientInformation where Referral = 1 and Status <> ''R'' order by ClientName' where QueryID=25
GO
update QueryMaster set SQL='EXEC SearchByLegalForward %1, %2', SQL2='EXEC CWX_Account_SearchByLegalForward %E, %1, %2' where ID=25
GO
update QueryMaster set Description='Legal Group Code' where ID=23
Go
alter table Account add PoolSelected bit
GO
update Account set PoolSelected=0
GO

-- Scripts 2.2.4:
-- =======================================================================
-- Author:			Tuan Luong
-- Create date:		Jul 16, 2008
-- Description:		Add column 'ActivityType'
-- Effected table:	Legal_CustomFields
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_CustomFields' and c.name = 'ActivityType')
BEGIN
	ALTER TABLE Legal_CustomFields
	ADD ActivityType int NOT NULL		
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]    Script Date: 07/16/2008 18:15:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetTotalQueueStatsByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]    Script Date: 07/16/2008 18:16:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Long Nguyen>
-- Create date: <Jul 11, 2008>
-- Description:	<Get Queue Statistic by Collector>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int
AS
BEGIN

	DECLARE @AccountCount int
	DECLARE @Touched int
	DECLARE @Actioned int
	DECLARE @Worked int
	DECLARE @Contacted int
	DECLARE @Promised int
	DECLARE @AccountBalance money

	IF (@ReportTime = 0)
		BEGIN
			SELECT
				@AccountCount = ISNULL(COUNT(DISTINCT AccountID),0),
				@AccountBalance = ISNULL(SUM(BillBalance),0)
			FROM Account
			WHERE 
				CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID

			SELECT
				@Touched = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			WHERE 
				CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID = 8
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Actioned = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			WHERE 
				CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Worked = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND av.ConsiderWorked = 1
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Contacted = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND av.ProductivityID = 2
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Promised = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND av.ProductivityID = 1
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@AccountCount AS AccountCount,
				@Touched AS Touched,
				@Actioned AS Actioned,
				@Worked AS Worked,
				@Contacted AS Contacted,
				@Promised AS Promised,
				@AccountBalance AS AccountBalance
		END
	ELSE
		BEGIN
			SELECT
				@AccountCount = ISNULL(COUNT(DISTINCT AccountID),0),
				@AccountBalance = ISNULL(SUM(BillBalance),0)
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID

			SELECT
				@Touched = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			WHERE 
				a.AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID = 8
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Actioned = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			WHERE 
				a.AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Worked = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				a.AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND av.ConsiderWorked = 1
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Contacted = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				a.AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND av.ProductivityID = 2
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@Promised = ISNULL(COUNT(DISTINCT ac.RecordID),0)
			FROM Account a
			LEFT JOIN AccountActions ac ON ac.AccountID = a.AccountID
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				a.AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND ac.ActionID <> 8
				AND av.ProductivityID = 1
				AND ac.ResponsibleParty = @EmployeeID

			SELECT
				@AccountCount AS AccountCount,
				@Touched AS Touched,
				@Actioned AS Actioned,
				@Worked AS Worked,
				@Contacted AS Contacted,
				@Promised AS Promised,
				@AccountBalance AS AccountBalance
		END
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdatePoolStatus]    Script Date: 07/17/2008 10:37:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UpdatePoolStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_UpdatePoolStatus]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_UpdatePoolStatus]    Script Date: 07/17/2008 10:37:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_UpdatePoolStatus]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
CREATE PROCEDURE [dbo].[CWX_Account_UpdatePoolStatus]
	@AccountID int,
	@DebtorID int,
	@EmployeeID int
AS
BEGIN
	update Account set PoolSelected=1, OfficeID=@EmployeeID where AccountID=@AccountID and DebtorID=@DebtorID
END
' 
END
GO

-- =======================================================================
-- Description:		Update default value for Relationship Collection - Consolidation setting.
-- History:
--	2008/07/17	[Binh Truong]	Init version
-- =======================================================================
UPDATE InformationTable
SET ValueFormat = '0', [Value] = ''
WHERE     (InfoID = 1) AND (InfoType = 1)
GO


/****** Object:  StoredProcedure [dbo].[CWX_GetEmployeeNextPoolAccount]    Script Date: 07/17/2008 16:43:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetEmployeeNextPoolAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetEmployeeNextPoolAccount]    Script Date: 07/17/2008 16:43:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetEmployeeNextPoolAccount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		KhoaDang
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount] 
	@v_employeeId int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='''' 
		   SET @v_SortOrder = '' "QueueDate" DESC''

    Set @orderByClause = ''ORDER BY '' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = ''WHERE RowIndex BETWEEN '' + CAST(@BeginIndex as varchar(10)) + '' AND '' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = '' ''
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = '' SELECT (CONVERT(varchar(10), a.DebtorID) + ''''|'''' + CONVERT(varchar(10), a.AccountID)) AS KeyField,''
				+ ''   a.QueueDate AS [QueueDate],''
				+ ''   a.AccountAge AS [DPD],''
				+ ''   a.MCode AS [Bucket],''
				+ ''   a.CCode AS [Cycle],''
				+ ''   a.BillAmount AS [Bill Amount],''
				+ ''   a.BillBalance AS [Bill Balance],''
				+ ''   s.ShortDesc AS [Status],''
				+ ''   s.SortPriority AS [Priority],''
				+ ''   a.AssignmentType AS [Assignment Type],''
				+ ''   p.SocialSecurityNumber AS [ID],''
				+ ''   (rtrim(p.FirstName) +'''' ''''+ rtrim(p.MiddleName) +'''' ''''+ rtrim(p.LastName)) AS [Name]''
				+ '' FROM Account a''
				+ '' INNER JOIN Accountother o ON o.AccountID = a.AccountID''
				+ '' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID''
				+ '' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID''
				+ '' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID''
				+ '' WHERE''
				+ ''   a.QueueDate<=GetDate()''
				+ ''   AND (a.EmployeeID = ''+CAST(@v_employeeId as varchar(9))+'' OR a.TempEmployeeID = ''+CAST(@v_employeeId as varchar(9))+'')''
				+ ''   AND a.DebtorID <> 0''
				+ ''   AND a.AgencyStatusID <> 2''
				+ ''	  AND a.SystemStatusID <> 2''
				+ ''	  AND a.PoolSelected = 0''

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = ''WITH AccountResults AS ''
				   + ''( ''
				   + ''  SELECT *, ROW_NUMBER() OVER ('' + @orderByClause + '') as RowIndex ''
				   + ''  FROM ( ''	
				   + ''          {0}''
				   + ''    ) A ''
				   + '') ''
				   + ''   ''
				   + ''SELECT top 1 KeyField, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]''
				   + ''FROM AccountResults ''
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, ''{0}'', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
		
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = ''SELECT @RowCountOut=count(*) FROM ( {0} ) A''
    SET @rowCountStmt = REPLACE(@rowCountStmt, ''{0}'', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = ''@RowCountOut int OUTPUT''
	
	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	if (@RowCount > 1)
		RETURN 2

	RETURN @RowCount
END

' 
END
GO
/******  Script Closed. Go next: Step016_2  ******/