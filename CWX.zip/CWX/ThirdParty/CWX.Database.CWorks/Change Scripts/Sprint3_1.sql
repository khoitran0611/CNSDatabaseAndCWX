﻿-- Start script for Sprint 3 -----
--March 30 2009: Thanh Nguyen
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF(NOT EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'CWX_StandardNotes') and type in (N'U')))
BEGIN
-------Create table CWX_StandardNotes
CREATE TABLE [dbo].[CWX_StandardNotes](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](50) NOT NULL,
	[ClientID] [int] NULL,
 CONSTRAINT [PK_CWX_StandardNote] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

-------Copy data from table InformationTable to table CWX_StandardNotes.Just copy standardnotes row (InfoID = 4 and infotype = 6)
INSERT INTO CWX_StandardNotes(Description)
SELECT it.Description
FROM InformationTable it
WHERE it.InfoID = 4 and it.infotype = 6
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF(EXISTS(SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'CWX_StandardNotes_DeleteAll') and type IN (N'P',N'PC')))
	DROP PROCEDURE [dbo].[CWX_StandardNotes_DeleteAll]
GO
CREATE PROCEDURE [dbo].[CWX_StandardNotes_DeleteAll]	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	DELETE FROM CWX_StandardNotes
END
GO
--End Thanh Nguyen


-- Alter stored procedure [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]    Script Date: 03/31/2009 17:43:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Get employee portfolio.
-- Parameters: 
--		0: Queue Active
--		Other number: All accounts
-- History:
--		2008/04/17	[Binh Truong]	Init version.
--		2008/05/15	[Binh Truong]	Cast BillBalance field to decimal(18,2) to fix Arithmetic overflow error converting expression.
--		2008/07/10	[Binh Truong]	Fix BillBalance NULL returned values.
--		2008/08/14	[Binh Truong]	EmployeeStatus = 'A'  >>>  EmployeeStatus <> 'R' 
--		2009/03/30	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_EmployeeReport_GetEmployeePortfolio]
	@PorfolioType smallint = 0,
	@ClientID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @TotalAccStatement NVARCHAR(1000)
	DECLARE @TotalDollarValueStatement NVARCHAR(1000)
	DECLARE @MainStatement NVARCHAR(4000)
	DECLARE @RowCount INT
	
	SET @Conditions = ''	

	IF @PorfolioType = 0		
		SET @Conditions = '
			AND SystemStatusId = 5 
			AND AgencyStatusID <> 2 
			AND QueueDate <= GETDATE()
			'
	IF @ClientID > 0
		SET @Conditions = @Conditions + 'AND ClientID = ' + cast(@ClientID as varchar)
	
	DECLARE @ParmDefinition NVARCHAR(500);
	DECLARE @TotalAccount INT;
	DECLARE @TotalDollarValue DECIMAL(18,2);

	SET @TotalAccStatement = N'SELECT @TotalAccountOUT = COUNT(*) FROM Account WHERE (1=1) ';
	SET @TotalAccStatement = @TotalAccStatement + @Conditions
	SET @ParmDefinition = N'@TotalAccountOUT INT OUTPUT';

	EXECUTE sp_executesql @TotalAccStatement, @ParmDefinition, @TotalAccountOUT=@TotalAccount OUTPUT;

	SET @TotalDollarValueStatement = N'SELECT @TotalDollarValueOUT = SUM(cast(ISNULL(BillBalance,0) as decimal)) FROM Account WHERE (1=1) ';
	SET @TotalDollarValueStatement = @TotalDollarValueStatement + @Conditions
	SET @ParmDefinition = N'@TotalDollarValueOUT DECIMAL(18,2) OUTPUT';

	EXECUTE sp_executesql @TotalDollarValueStatement, @ParmDefinition, @TotalDollarValueOUT=@TotalDollarValue OUTPUT;
	
	--Build the MainStatement
	SET @MainStatement = 'INSERT INTO #Temp SELECT Employee.EmployeeID, Employee.EmployeeName, '

	SET @MainStatement = @MainStatement + ' (SELECT COUNT(EmployeeID) AS Expr1
						FROM          Account AS AT
						WHERE      (AT.EmployeeID = Employee.EmployeeID) ' + @Conditions + ' GROUP BY AT.EmployeeID) AS TotalAccount, '
	
	SET @MainStatement = @MainStatement + ' (SELECT CAST(((COUNT(EmployeeID) * 100) / CAST(' + CAST(@TotalAccount AS VARCHAR(30)) + ' AS DECIMAL(18,2))) AS DECIMAL(18,2)) AS Expr1
						FROM          Account AS AT
						WHERE      (AT.EmployeeID = Employee.EmployeeID) ' + @Conditions + ' GROUP BY AT.EmployeeID) AS TotalAccountPercent, '
    
	SET @MainStatement = @MainStatement + ' (SELECT     CAST(SUM(cast(ISNULL(BillBalance,0) as decimal)) as decimal(18,2)) 
                    FROM        Account AS AT
                    WHERE      (AT.EmployeeID = Employee.EmployeeID) ' + @Conditions + ' GROUP BY AT.EmployeeID) AS TotalDollarValue, '

	SET @MainStatement = @MainStatement + ' (SELECT     CAST(SUM(cast(ISNULL(BillBalance,0) as decimal)) as decimal(18,2)) * 100 / CAST(' + CAST(@TotalDollarValue AS VARCHAR(30)) + 'AS DECIMAL(18,2)) AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.EmployeeID = Employee.EmployeeID) ' + @Conditions + ' GROUP BY AT.EmployeeID) AS TotalDollarValuePercent, '

	SET @MainStatement = @MainStatement + ' (SELECT     COUNT(TempEmployeeID) AS Expr1
					FROM          Account AS AT
					WHERE      (AT.TempEmployeeID = Employee.EmployeeID) ' + @Conditions + ' GROUP BY AT.TempEmployeeID) AS TotalAccountTemp, ' 

	SET @MainStatement = @MainStatement + ' (SELECT     SUM(cast(ISNULL(BillBalance,0) as decimal)) AS Expr1
                    FROM        Account AS AT
                    WHERE      (AT.TempEmployeeID = Employee.EmployeeID) ' + @Conditions + ' GROUP BY AT.TempEmployeeID) AS TotalDollarValueAccountTemp '

	SET @MainStatement = @MainStatement + ' FROM  Employee WHERE EmployeeStatus <> ''R''' 

	IF (@ClientID > 0)
		SET @MainStatement = @MainStatement + ' AND EmployeeID IN (SELECT EmployeeID FROM CWX_ClientEmployee WHERE ClientID = ' + cast(@ClientID as varchar) + ')'

print @MainStatement
	CREATE TABLE #Temp
	(
		Idx int IDENTITY,
		EmployeeID int,
		EmployeeName varchar(50),
		TotalAccount int,
		TotalAccountPercent DECIMAL(18,0),
		TotalDollarValue DECIMAL(18,2),
		TotalDollarValuePercent DECIMAL(18,0),
		TotalAccountTemp int,
		TotalDollarValueAccountTemp DECIMAL(18,2)		
	)

	EXEC dbo.sp_executesql @MainStatement
	
	SELECT @RowCount = Count(Idx) FROM #Temp

	SELECT  EmployeeName,
			EmployeeID,
			ISNULL(TotalAccount, 0) AS TotalAccount,
			CAST(ISNULL(TotalAccountPercent, 0) as varchar(50)) AS TotalAccountPercent,
			ISNULL(TotalDollarValue, 0) AS TotalDollarValue,
			CAST(ISNULL(TotalDollarValuePercent, 0) as varchar(50)) AS TotalDollarValuePercent,
			ISNULL(TotalAccountTemp, 0) AS TotalAccountTemp,
			ISNULL(TotalDollarValueAccountTemp, 0) AS TotalDollarValueAccountTemp
			
	FROM #Temp WHERE Idx between (@PageIndex)*@PageSize + 1 and (@PageIndex + 1)*@PageSize

	DROP TABLE #Temp
	
	RETURN @RowCount
END
GO


-- Alter stored procedure [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]    Script Date: 03/31/2009 18:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================================
-- Description:	Get total active account and bill balance of collector
-- Parameters: 
--	@PorfolioType	0: Queue Active
--					Other number: All accounts
-- History:
--	2008/04/17	[Binh Truong]	Init version.
--	2008/04/23	[Binh Truong]	Cast BillBalance field to decimal to fix Arithmetic overflow error converting expression.
--	2008/07/10	[Binh Truong]	Fix NULL returned values.
--	2008/08/14	[Binh Truong]	EmployeeStatus = 'A'  >>>  EmployeeStatus <> 'R'
--	2009/03/30	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================================
ALTER PROCEDURE [dbo].[CWX_EmployeeReport_GetTotalAccountAndBillBalance]
	@PorfolioType AS SMALLINT,
	@ClientID int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Select NVARCHAR(1000)
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @Statement NVARCHAR(2000)
	DECLARE @Parms NVARCHAR(500)
	
	SET @Conditions = ' WHERE (Employee.EmployeeStatus <> ''R'') '	
	
	SET @Select = '
		SELECT	COUNT(Account.AccountID) AS TotalAccount,
				ISNULL(SUM(CAST(Account.BillBalance as decimal)),0) as TotalDollarValue 
		FROM         Account INNER JOIN
                      Employee ON Account.EmployeeID = Employee.EmployeeID     
		' 		
		
	IF @PorfolioType = 0		
		SET @Conditions = @Conditions + '
					AND SystemStatusId = 5 
					AND AgencyStatusID <> 2 
					AND QueueDate <= GETDATE()
			'
	IF @ClientID > 0
	BEGIN
		SET @Conditions = @Conditions + ' AND Account.ClientID = ' + cast(@ClientID as varchar)	
		SET @Conditions = @Conditions + ' AND Employee.EmployeeID IN (SELECT EmployeeID FROM CWX_ClientEmployee WHERE ClientID = ' + cast(@ClientID as varchar) + ')'
	END

	SET @Statement = @Select + @Conditions
print @Statement	
	EXEC dbo.sp_executesql @Statement
		
	SET @Select = '
		SELECT	COUNT(Account.TempEmployeeID ) AS TotalTempAccount,
				ISNULL(SUM(CAST(BillBalance as decimal)),0) as TotalTempDollarValue 
		FROM         Account INNER JOIN
                      Employee ON Account.TempEmployeeID = Employee.EmployeeID     
		' 		
		
	SET @Statement = @Select + @Conditions
print @Statement	
	EXEC dbo.sp_executesql @Statement
	
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]    Script Date: 03/31/2009 18:25:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		<Long Nguyen>
-- Create date: <Jul 11, 2008>
-- Description:	<Get Queue Statistic by Collector for the datagrid>
-- History:
--	2008/07/11	[Long Nguyen]	Init version.
--	2009/03/30	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_GetTotalQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int,
	@ClientID int = 0
AS
BEGIN

	DECLARE @AccountCount int
	DECLARE @Touched int
	DECLARE @Actioned int
	DECLARE @Worked int
	DECLARE @Contacted int
	DECLARE @Promised int
	DECLARE @AccountBalance money

	IF (@ReportTime = 0)
		BEGIN

			SELECT
				@AccountCount = ISNULL(COUNT(DISTINCT AccountID),0),
				@AccountBalance = ISNULL(SUM(BillBalance),0)
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
								AND CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
								AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
								AND SystemStatusID in (1,5))
				AND (@ClientID = 0 OR ClientID = @ClientID)

			SELECT
				@Touched = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions 
			WHERE CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ResponsibleParty = @EmployeeID
				AND AccountID not in 
					(SELECT DISTINCT AccountID FROM AccountActions where ActionId <> 8
					AND CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
					AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
					AND ResponsibleParty = @EmployeeID)
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Actioned = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions
			WHERE CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ActionID <> 8
				AND ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Worked = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
				LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ac.ActionID <> 8
				AND av.ConsiderWorked = 1
				AND ac.ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Contacted = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 2
				AND ac.ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Promised = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
				LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
				AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 1
				AND ac.ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@AccountCount AS AccountCount,
				@Touched AS Touched,
				@Actioned AS Actioned,
				@Worked AS Worked,
				@Contacted AS Contacted,
				@Promised AS Promised,
				@AccountBalance AS AccountBalance
		END
	ELSE
		BEGIN
			SELECT
				@AccountCount = ISNULL(COUNT(DISTINCT AccountID),0),
				@AccountBalance = ISNULL(SUM(BillBalance),0)
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
									  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID in (1,5)
				AND (@ClientID = 0 OR ClientID = @ClientID)

			SELECT
				@Touched = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ResponsibleParty = @EmployeeID
				AND AccountID not in 
					(SELECT DISTINCT AccountID FROM AccountActions where ActionId <> 8
					AND CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
					AND ResponsibleParty = @EmployeeID)
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Actioned = ISNULL(COUNT(DISTINCT AccountID),0)
			from AccountActions
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ActionID <> 8
				AND ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Worked = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ac.ActionID <> 8
				AND av.ConsiderWorked = 1
				AND ac.ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Contacted = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 2
				AND ac.ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@Promised = ISNULL(COUNT(DISTINCT AccountID),0)
			FROM AccountActions ac
			LEFT JOIN AvailableActions av ON av.ActionID = ac.ActionID
			WHERE 
				CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121)
				AND ac.ActionID <> 8
				AND av.ProductivityID = 1
				AND ac.ResponsibleParty = @EmployeeID
				AND (@ClientID = 0 OR AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID))

			SELECT
				@AccountCount AS AccountCount,
				@Touched AS Touched,
				@Actioned AS Actioned,
				@Worked AS Worked,
				@Contacted AS Contacted,
				@Promised AS Promised,
				@AccountBalance AS AccountBalance
		END
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_GetRuleAccountsDetail]    Script Date: 03/31/2009 18:27:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Long Nguyen
-- Create date: 2008-11-21
-- Description:	
--		2008/11/21	[Long Nguyen]	Init version.
--		2009/03/30	[Minh Dam]		Add parameter "@ClientiD" and fileter by ClientID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_GetRuleAccountsDetail]
	-- Add the parameters for the stored procedure here
	@EmployeeID int = 0,
	@StartDate smalldatetime = NULL,
	@EndDate smalldatetime = NULL,
	@ClientID int = 0,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int

    SELECT
		@RowCount = COUNT(RowNumber)
	FROM
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.AllocRuleID) AS RowNumber,
			a.AllocRuleID AS RuleID,
			r.Description AS RuleDescription,
			a.EmployeeID,
			e.UserID,
			ISNULL(COUNT(AccountID),0) AS TotalAccounts,
			ISNULL(SUM(BillBalance),0) AS TotalValue
		FROM Account a, Employee e, RuleTable r
		WHERE
			((@StartDate IS NULL) OR CONVERT(VARCHAR(10),a.LastAllocationDate,121) >= CONVERT(VARCHAR(10),@StartDate,121))
			AND ((@EndDate IS NULL) OR CONVERT(VARCHAR(10),a.LastAllocationDate,121) <= CONVERT(VARCHAR(10),@EndDate,121))
			AND a.EmployeeID = e.EmployeeID 
			AND a.AllocRuleID = r.[ID] 
			AND (@EmployeeID=0 OR a.EmployeeID = @EmployeeID)
			AND (@ClientID = 0 OR (a.ClientID = @ClientID AND r.ClientID = @ClientID))
		GROUP BY a.AllocRuleID, a.EmployeeID, e.UserID, r.Description
	) a

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.AllocRuleID) AS RowNumber,
			a.AllocRuleID AS RuleID,
			r.Description AS RuleDescription,
			a.EmployeeID,
			e.UserID,
			ISNULL(COUNT(AccountID),0) AS TotalAccounts,
			ISNULL(SUM(BillBalance),0) AS TotalValue
		FROM Account a, Employee e, RuleTable r 
		WHERE
			((@StartDate IS NULL) OR CONVERT(VARCHAR(10),a.LastAllocationDate,121) >= CONVERT(VARCHAR(10),@StartDate,121))
			AND ((@EndDate IS NULL) OR CONVERT(VARCHAR(10),a.LastAllocationDate,121) <= CONVERT(VARCHAR(10),@EndDate,121))
			AND a.EmployeeID = e.EmployeeID 
			AND a.AllocRuleID = r.[ID] 
			AND (@EmployeeID=0 OR a.EmployeeID = @EmployeeID)
			AND (@ClientID = 0 OR (a.ClientID = @ClientID AND r.ClientID = @ClientID))
		GROUP BY a.AllocRuleID, a.EmployeeID, e.UserID, r.Description
	)

	SELECT * FROM Temp
	WHERE ((@PageSize<=0) OR (RowNumber BETWEEN (@PageSize*@PageIndex+1) AND (@PageSize*(@PageIndex+1))))

	RETURN @RowCount
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetEmployeeIDBySupervisor]    Script Date: 03/31/2009 18:27:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <6-September-2008>
-- History:
--		2008/09/06	[Thuy Nguyen]	Init version.
--		2009/03/30	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Employee_GetEmployeeIDBySupervisor]
	@SupervisorID int = 0,
	@ClientID int = 0
AS
BEGIN
	SELECT EmployeeID 
	FROM Employee 
	WHERE SupervisorID = @SupervisorID
		AND (@ClientID = 0 OR EmployeeID IN (SELECT EmployeeID FROM CWX_ClientEmployee WHERE ClientID = @ClientID))
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetLoginDetails]    Script Date: 03/31/2009 18:28:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <6 September 2008>
-- History:
--		[2008/09/06]	[Thuy Nguyen]	Init version.
--		[2009/03/31]	[Minh Dam]		Add parameter "@ClientID" and fitler by ClientID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Employee_GetLoginDetails]
	@EmployeeIDString varchar(1000),
	@ClientID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount INT
	SET @RowCount = 0

	IF (@EmployeeIDString != '')
	BEGIN
		DECLARE @querystring varchar(2000);
		CREATE TABLE #Temp(
			RowNumber int,
			EmployeeID int,
			EmployeeName varchar(10),
			ViewedNo int,		
			AccountIDViewing int
		);

		SET @querystring = 'INSERT INTO #Temp
			SELECT 
			ROW_NUMBER() OVER (ORDER BY  e.EmployeeID ASC) AS RowNumber,		
			e.EmployeeID, e.UserID, ISNULL(COUNT(a1.RecordID),0) AS ViewedNo, ISNULL(a2.AccountID,0) AS AccountIDViewing
			FROM Employee e		
			LEFT JOIN 
				(SELECT * FROM AccountActions 
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID = 8
					@@ClientCondition1
				) AS a1
			ON e.EmployeeID = a1.CompletedBy
			LEFT JOIN 
				(SELECT AccountID, CompletedBy FROM AccountActions AS a
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID = 8
					AND RecordID >= (SELECT MAX(RecordID) FROM AccountActions
												WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
												AND ActionID=8
												AND CompletedBy=a.CompletedBy)
					@@ClientCondition1
				) AS a2
			ON e.EmployeeID = a2.CompletedBy
			WHERE e.EmployeeID IN (' + @EmployeeIDString + ')				
				@@ClientCondition2
			GROUP BY e.EmployeeID, e.UserID, a2.AccountID'
		
		IF (@ClientID > 0)	
		BEGIN
			SET @querystring = REPLACE(@querystring, '@@ClientCondition1', 'AND AccountID IN (SELECT AccountID FROM Account WHERE ClientID = ' + cast(@ClientID as varchar) + ')')
			SET @querystring = REPLACE(@querystring, '@@ClientCondition2', 'AND e.EmployeeID IN (SELECT EmployeeID FROM CWX_ClientEmployee WHERE ClientID = ' + cast(@ClientID as varchar) + ')')
		END
		ELSE	
		BEGIN
			SET @querystring = REPLACE(@querystring, '@@ClientCondition1', '')
			SET @querystring = REPLACE(@querystring, '@@ClientCondition2', '')
		END
print @QueryString
		EXEC (@querystring)
		
		SELECT @RowCount = @@ROWCOUNT
		
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
		
		DROP TABLE #Temp
	END
	
	RETURN @RowCount

END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseStat]    Script Date: 03/31/2009 18:29:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Get Promise Statistics
-- History:
--		2008/04/29	[Binh Truong]	Init version
--		2008/05/05	[Binh Truong]	Add criteria to exclude closed AccountStatus.
--		2008/05/07	[Binh Truong]	Add specific AccountPromise table name of a column to fix ambiguous 
--									column name 'EmployeeID'
--		2009/03/31	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseStat] 	
(
	@EmployeeID int = 0,
	@From datetime = NULL,
	@To datetime = NULL,
	@ClientID int = 0
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @Statement NVARCHAR(4000)
	DECLARE @Select NVARCHAR(1000)
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @GroupBy NVARCHAR(50)
	DECLARE @OrderBy NVARCHAR(50)
	DECLARE @Parms NVARCHAR(500)
		
	SET @Select = '	
		SELECT		AccountPromise.Status, COUNT(*) AS AccountAmount, SUM(cast(AmountPromised as decimal)) AS Promised, SUM(cast(AmountPaid as decimal)) AS Paid
		FROM        AccountPromise INNER JOIN
							Account ON AccountPromise.AccountID = Account.AccountID
		'
	SET @Conditions = ' WHERE (Account.AgencyStatusID <> 2) '
	SET @GroupBy = ' GROUP BY AccountPromise.Status '
	SET @OrderBy = ' ORDER BY AccountPromise.Status '
	
	IF @EmployeeID <> 0
	BEGIN
		SET @Conditions = @Conditions +
			'
			AND AccountPromise.EmployeeID = @EmployeeID
			AND (@ClientID = 0 OR Account.ClientID = @ClientID)
			'
	END
	
	IF @From IS NOT NULL
	BEGIN
		SET @To = DATEADD(day, 1, @To)
		SET @Conditions = @Conditions +
			'
			AND (DatePromised >= @From AND DatePromised < @To)
			'	
	END
	
	SET @Statement = @Select + @Conditions + @GroupBy + @OrderBy
	
	SET @Parms = '
			@EmployeeID int,
			@From datetime,
			@To datetime,
			@ClientID int = 0
			'
print @Statement
	EXEC dbo.sp_executesql @Statement, @Parms,
							@EmployeeID,
							@From,
							@To,
							@ClientID


END
GO

---------ThanhNguyen--------------------------------
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: First April
-- Description:	Save RelationshipType for Cosignee base on AccountID and PersonID
-- =============================================
IF(EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'CWX_CosigneeInformation_SaveInfo') and type in (N'P')))
	DROP PROCEDURE CWX_CosigneeInformation_SaveInfo
GO
	
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_SaveInfo]
	@AccountID int,
	@PersonID int,
	@RelationshipType int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @InvoiceNumber varchar(50)
	DECLARE @DebtorID int
	DECLARE @InterfaceID int
	DECLARE @SocialSecurityNumber varchar(50)

	SELECT
		@InvoiceNumber = InvoiceNumber,
		@DebtorID = DebtorID,
		@InterfaceID = InterfaceID
	FROM Account
	WHERE AccountID = @AccountID
	
	-- Relationship_no is the GroupName of Debtor of Person that Cosignee belongs to
	SELECT @SocialSecurityNumber = GroupName
	FROM DebtorInformation 
	WHERE PersonID = @PersonID
    -- Insert statements for procedure here
	--Insert data
	IF(NOT EXISTS(SELECT Bill FROM CosigneeInformation Where Bill = @AccountID and PersonID = @PersonID))
	BEGIN
		INSERT INTO CosigneeInformation
		(
			Bill,
			PersonID,
			DebtorID,
			Relationship_no,
			Relationship_Type,
			Account_no,
			InterfaceID
		)
		VALUES
		(
			@AccountID,
			@PersonID,
			@DebtorID,
			@SocialSecurityNumber,
			@RelationshipType,
			@InvoiceNumber,
			@InterfaceID
		)
	END
	ELSE
	BEGIN
	--Update data	
		UPDATE CosigneeInformation
		SET Relationship_Type= @RelationshipType
		WHERE Bill = @AccountID and PersonID = @PersonID
	
	END
END
GO

IF(NOT EXISTS(SELECT * FROM IDENTITYFIELDS WHERE TableName = 'CMSRelatedPartiesClassic'))
BEGIN
	INSERT INTO IDENTITYFIELDS
	VALUES('CMSRelatedPartiesClassic',0)
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_PersonInformation_Dict' AND COLUMN_NAME = 'CMSEditable')
BEGIN
   ALTER TABLE CWX_PersonInformation_Dict ADD CMSEditable bit NOT NULL DEFAULT ((0))
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_AccountInformation_Dict' AND COLUMN_NAME = 'CMSEditable')
BEGIN
	ALTER TABLE CWX_AccountInformation_Dict Add CMSEditable bit NOT NULL DEFAULT ((0))
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'DebtorInformation' AND COLUMN_NAME = 'LockedDate')
BEGIN
	ALTER TABLE DebtorInformation 
		ADD LockedDate datetime NULL
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'AgencyDefinedMaster' AND COLUMN_NAME = 'Type')
BEGIN
	ALTER TABLE AgencyDefinedMaster 
		ADD [Type] tinyint NULL
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an account
-- History:
--	[06 Mar 2009]	Minh Dam		Init version.
--	[20 Mar 2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[10-Apr-2009]	Thanh Nguyen	Add parameter "@CMSEditable"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_GetDynamicFields]
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageNumber int = 1, 
	@ClientID int = 0, -- if @ClientID < 0 then set @ClientID equals ClientID of account
	@PageSize int = 1, -- it's only used for function parameter
	@PageIndex int = 0, -- it's only used for function parameter
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF (@AccountID > 0 AND @ClientID < 0)
		SELECT @ClientID = ClientID
		FROM Account
		WHERE AccountID = @AccountID

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[TableID],
			a.[DropDown],
			b.[DataType],
			b.[MaxLength],
			ISNULL(c.[SQL], '') as SQLDropDown,
			ISNULL(c.Listed, 0) as Listed
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], CASE WHEN @CMSEditable = 1 THEN [CMSEditable] ELSE [Editable] END as [Editable], 
				[GroupID], [GroupDesc], [DisplayOrder], [DropDown], [TableID]
		FROM CWX_AccountInformation_Dict
		WHERE Displayed = 1	AND PageNumber = @PageNumber
			AND (ISNULL(Client, 0) = 0 OR Client = @ClientID)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Account' AND [Type]='U')
			OR object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'AccountOther' AND [Type]='U')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList_Account varchar(4000), @FieldNameList_AccountOther varchar(4000)
	DECLARE @FieldName varchar(50), @TableID int
	SET @FieldNameList_Account = 'AccountID,InvoiceNumber,DebtorID,EmployeeID,ClientID,QueueDate,AgencyStatusID,SystemStatusID,ActionCodeID,OfficeID,MCode,CCode,BucketMovement,SubmissionDate,LastEditDate,LastEditBy,CurrencyCode,InterfaceID,CloseDate'
	SET @FieldNameList_AccountOther = 'AccountID'

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName, TableID FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF (@TableID = 1) -- Account table
			SET @FieldNameList_Account = @FieldNameList_Account + ',' + @FieldName
		ELSE IF (@TableID = 2) -- AccountOther table
			SET @FieldNameList_AccountOther = @FieldNameList_AccountOther + ',' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql1 varchar(1000), @Sql2 varchar(1000)
	SET @Sql1 = 'SELECT ' + @FieldNameList_Account + ' FROM Account WHERE AccountID = ' + Cast(@AccountID as varchar)
	SET @Sql2 = 'SELECT ' + @FieldNameList_AccountOther + ' FROM AccountOther WHERE AccountID = ' + Cast(@AccountID as varchar)
	
	EXEC (@Sql1)
	EXEC (@Sql2)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

	DECLARE @PageCount int
	SELECT @PageCount = MAX(PageNumber) 
	FROM CWX_AccountInformation_Dict 
	WHERE Displayed = 1 AND (ISNULL(Client,0) = 0 OR Client = @ClientID)

	RETURN @PageCount
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thuy Nguyen
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an person
-- History:
--	[06 Mar 2009]	Thuy Nguyen		Init version.
--	[20 Mar 2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
	@PersonID int,
	@PageNumber int = 1,
	@Client int = 0,
	@PageSize int = 10, -- it's only used for function parameter
	@PageIndex int = 0, -- it's only used for function parameter
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 			
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[Editable],			
			b.[DataType],
			b.[MaxLength],			
			a.[DropDown],
			ISNULL(c.[SQL], '') as SQLDropDown,
			ISNULL(c.Listed, 0) as Listed
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [GroupID], [GroupDesc], [DisplayOrder],
				CASE WHEN @CMSEditable = 1 THEN [CMSEditable] ELSE [Editable] END as [Editable] , [DropDown] 
		FROM CWX_PersonInformation_Dict
		WHERE Displayed = 1	and PageNumber = @PageNumber and Client = @Client) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'PersonInformation' and [Type]='U')			
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'PersonID, LastName, FirstName, MiddleName, PString1'
	
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM PersonInformation WHERE PersonID = ' + Cast(@PersonID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup

	DECLARE @PageCount int
	SELECT @PageCount = MAX(PageNumber) 
	FROM CWX_PersonInformation_Dict 
	WHERE Displayed = 1 AND (@Client = 0 OR ISNULL(Client, 0) = 0 OR Client = @Client)

	RETURN @PageCount
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Updated by ThanhNguyen: April 06 2009: Get Get list of Group Debts with Account No. and ClientID
-- Description:	Get list of Group Debts with Account No.
-- =============================================
IF(EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'CWX_Legal_Groups_GetGroupDebtList') and type in (N'P')))
	DROP PROCEDURE CWX_Legal_Groups_GetGroupDebtList

GO

CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@AccountID int = 0,
	@ClientID int=0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    IF @groupID <> 0
		SELECT [GroupDebtID],a.[GroupID],a.[AccountID],a.[LastEditDate],a.[PaymentAllocationRuleID],a.[IsInclude], a.[IsPrimary], b.InvoiceNumber
				,CAST(0 AS bit) AS IsGrouped
				,'' AS GroupName
		FROM Legal_GroupDebts a
			JOIN Account b ON a.AccountID = b.AccountID
		WHERE a.AccountID = b.AccountID AND 
			CASE WHEN @ClientID > 0 THEN b.ClientID ELSE 0 END = @ClientID AND
			GroupID = @groupID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2
		ORDER BY a.[IsPrimary] DESC, b.AccountID
	ELSE
		SELECT	NULL AS [GroupDebtID], NULL AS [GroupID], b.[AccountID], NULL AS [LastEditDate],
				NULL AS [PaymentAllocationRuleID], 
				CAST((CASE b.AccountID WHEN @AccountID THEN 1 ELSE 0 END) AS bit) AS [IsInclude],
				CAST((CASE b.AccountID WHEN @AccountID THEN 1 ELSE 0 END) AS bit) AS [IsPrimary],
				b.InvoiceNumber,
				CAST(0 AS bit) AS IsGrouped,
				'' AS GroupName
		FROM Account b 
		WHERE b.DebtorID = @debtorID AND 
			CASE WHEN @ClientID > 0 THEN b.ClientID ELSE 0 END = @ClientID AND
			b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2
		ORDER BY a.[IsPrimary] DESC, b.AccountID
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Update by:	Aldous Nochefranca / Alvin Marable 
-- Update date: 2009-03-05	
-- Update date: April 06 2009: ThanhNguyen: Get list of Group Debtors with Account No. and Customer 's fullName and ClientID
-- Description:	Get list of Group Debtors with Account No. and Customer 's fullName
-- =============================================
IF(EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'CWX_Legal_Groups_GetGroupDebtorList') and type in (N'P')))
	DROP PROCEDURE CWX_Legal_Groups_GetGroupDebtorList
GO

CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int,
	@ClientID int =0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
	BEGIN
		DECLARE @PersonID int
		SELECT @PersonID=d.PersonID
		FROM DebtorInformation d
		LEFT JOIN CosigneeInformation c ON c.PersonID = d.PersonID
		WHERE d.DebtorID=@debtorID-- AND c.Relationship_Type IS NULL

		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate]
				, CASE a.PersonID WHEN @PersonID THEN 'Debtor' ELSE r.Description END AS [RelationshipType]
				, a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[DefendantNum], a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				LEFT JOIN PersonInformation p ON a.PersonID = p.PersonID
				LEFT JOIN Account b ON a.AccountID = b.AccountID
				LEFT JOIN CosigneeInformation g ON g.PersonID = a.PersonID AND g.Bill = b.AccountID
				LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE a.GroupID = @groupID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2 AND 
				CASE WHEN @ClientID > 0 THEN b.ClientID ELSE 0 END = @ClientID AND
				CASE WHEN ISNULL(r.RelationshipTypeID, 0) = 0 THEN 1 ELSE r.IncludeInGroup END <> 0
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	END
	ELSE
	BEGIN
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,'Debtor' AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum], isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
				LEFT JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
				--LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID AND 
			CASE WHEN @ClientID > 0 THEN b.ClientID ELSE 0 END = @ClientID AND
			b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate], r.Description AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
			LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID) AND 
			CASE WHEN @ClientID > 0 THEN b.ClientID ELSE 0 END = @ClientID AND
			b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2 AND r.IncludeInGroup <> 0
		
		ORDER BY Seq, b.AccountID, FullName
	END
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 19 Mar 2009
-- Description:	Get All clients that are assigned to a @Employee parameter
-- =============================================
IF(EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'CWX_ClientInformation_GetAssignedClients') and type in (N'P')))
	DROP PROCEDURE CWX_ClientInformation_GetAssignedClients
GO	
CREATE PROCEDURE [dbo].[CWX_ClientInformation_GetAssignedClients]
	-- Add the parameters for the stored procedure here
	@EmployeeID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT ci.ClientID, ClientName
	FROM ClientInformation ci
	WHERE ci.ClientID IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID)
		AND [Status] <> 'R'
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 19 Mar 2009
-- Description:	Get All clients that is not assigned to a @Employee parameter
-- =============================================
IF(EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'CWX_ClientInformation_GetAvailableClients') and type in (N'P')))
	DROP PROCEDURE CWX_ClientInformation_GetAvailableClients
GO

CREATE PROCEDURE [dbo].[CWX_ClientInformation_GetAvailableClients]
	-- Add the parameters for the stored procedure here
	@EmployeeID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT ci.ClientID, ClientName
	FROM ClientInformation ci
	WHERE ci.ClientID not in (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID)
		AND [Status] <> 'R'
END

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 19 Mar 2009
-- Description:	Get list of locked debtor
-- =============================================
IF(EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'CWX_DebtorInformation_GetLockedDebtorList') and type in (N'P')))
	DROP PROCEDURE CWX_DebtorInformation_GetLockedDebtorList
GO

CREATE PROCEDURE [dbo].[CWX_DebtorInformation_GetLockedDebtorList]	
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(DebtorID)
	FROM DebtorInformation
	WHERE LockedByID is not null and LockedDate is not NULL

    -- Insert statements for procedure here
	SELECT	d.DebtorID, 
			p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName as [Name],
			e.EmployeeName as LockedBy,
			d.LockedDate			
	FROM DebtorInformation	d
		INNER JOIN PersonInformation p ON d.PersonID = p.PersonID
		INNER JOIN EMPLOYEE e ON e.EmployeeID = d.LockedByID
	WHERE d.LockedByID is not NULL and d.LockedDate is not NULL
	ORDER BY [Name] DESC
	
	return @RowCount
END

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: April 09 2009
-- Description:	Unlock all debtors 
-- =============================================
IF(EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'CWX_DebtorInformation_UnlockAllDebtors') and type in (N'P')))
	DROP PROCEDURE CWX_DebtorInformation_UnlockAllDebtors
GO

CREATE PROCEDURE [dbo].[CWX_DebtorInformation_UnlockAllDebtors]	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE DebtorInformation
	SET LockedByID = null,
		LockedDate = null
END
GO
-----------------End ThanhNguyen------------------------------------

-- Minh Dam: 10 Apr 2009
-- Add parameter %E for stored procedure CWX_Account_LoadXML
UPDATE QueryDebtorInfoMaster
SET [Sql] = 'Exec CWX_Account_LoadXML %D, %E'
WHERE [Sql] = 'Exec CWX_Account_LoadXML %D'


-- Create function [dbo].[CWX_AssignedClientIDTable]
/****** Object:  UserDefinedFunction [dbo].[CWX_AssignedClientIDTable]    Script Date: 04/17/2009 09:53:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AssignedClientIDTable]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CWX_AssignedClientIDTable]
GO

/****** Object:  UserDefinedFunction [dbo].[CWX_AssignedClientIDTable]    Script Date: 04/17/2009 09:53:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <10 April 2009>
-- Description:	<>
-- =============================================
CREATE FUNCTION [dbo].[CWX_AssignedClientIDTable]
(	
	@employeeID int
)
RETURNS @retTable TABLE (ClientID int)
AS
BEGIN

	IF (@EmployeeID > 0 AND EXISTS (SELECT 1 FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID))
	BEGIN
		INSERT INTO @retTable(ClientID)	
			SELECT	ClientID 
			FROM	ClientInformation 
			WHERE	[Status] <> 'R'
				AND ClientID IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID)
	END
	ELSE
	BEGIN
		INSERT INTO @retTable(ClientID)	
			SELECT	ClientID 
			FROM	ClientInformation 
			WHERE	[Status] <> 'R'
	END
	
	RETURN
END
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_AgencyStatus int,
--	@IsPending bit = 0,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.	

    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId AS varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'				
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID = '+CAST(@v_AgencyStatus AS varchar(9))
--				+ '   AND ISNULL(a.IsPending,0) = '+CAST(@IsPending AS varchar(1))

	-- Thuy Nguyen add filter by clientID	
	SELECT * INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@v_employeeId) 
	SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'
	-- End of Thuy Nguyen add filter by clientID

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 04/13/2009 16:48:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================

ALTER PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_SystemStatus int,
	@AccountAge int = -1,
	@MCode int = -1,
	@CCode int = -1,
--	@IsPending bit = 0,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.	
	
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId as varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID <> 2'
--				+ '   AND ISNULL(a.IsPending,0) = '+CAST(@IsPending AS varchar(1))
	
	
	-- Thuy Nguyen add filter by clientID	
	SELECT * INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@v_employeeId)
	SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'
	-- End of Thuy Nguyen add filter by clientID

	IF @v_SystemStatus = 0 
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'

	IF ((@v_SystemStatus = 1) or (@v_SystemStatus = 5))
		SET @cStmt=@cStmt+' AND s.SystemStatus = '+CAST(@v_SystemStatus AS varchar(9))+''

	IF @v_SystemStatus = 2
	BEGIN
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'
		SET @cStmt=@cStmt+' AND convert(varchar(10),a.SubmissionDate,121)=convert(varchar(10),GetDate(),121)'+''
	END

	IF @v_SystemStatus = 6 --Pending account
		SET @cStmt=@cStmt+' AND a.IsPending = 1'
	
	IF @AccountAge <> -1
		SET @cStmt=@cStmt+' AND a.AccountAge = '+CAST(@AccountAge AS varchar(9))
	IF @MCode <> -1
		SET @cStmt=@cStmt+' AND a.MCode = '+CAST(@MCode AS varchar(9))
	IF @CCode <> -1
		SET @cStmt=@cStmt+' AND a.CCode = '+CAST(@CCode AS varchar(9))

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetTickets]    Script Date: 04/13/2009 16:50:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_GetTickets] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@TicketClass int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT * INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@EmployeeID) 

	DECLARE @RowCount int
	SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Ticket t
	INNER JOIN TicketStatus s ON s.TicketStatusID = t.TicketStatus
	INNER JOIN Employee e ON e.EmployeeID = t.Requester
	INNER JOIN Employee f ON f.EmployeeID = t.AssignedTo
	INNER JOIN Account a ON a.AccountID = t.AccountID
	WHERE
		(((@TicketClass = 1) and (t.CurrentEmployeeID = @EmployeeID)) or ((@TicketClass = 0) and (t.Requester = @EmployeeID)))
		AND t.TicketStatus <> 9		
		AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  t.TicketID) AS RowNumber,
			CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID) + '|' + CONVERT(varchar(10), t.TicketID) AS KeyField,
			t.TicketID AS [Ticket ID],
			e.EmployeeName AS [Requester],
			f.EmployeeName AS [Assign To],
			t.CurrentStage AS [Current Stage],
			t.TotalStage AS [Total Stage],
			t.RequestDate AS [Request Date],
			t.StartDate AS [Start Date],
			t.DueDate AS [Due Date],
			s.Description AS [Ticket Status],
			CASE t.Priority
				WHEN 0 THEN 'Low'
				WHEN 1 THEN 'Mediuem'
				WHEN 2 THEN 'High'
			END AS Priority
		--INTO #Temp
		FROM Ticket t
		INNER JOIN TicketStatus s ON s.TicketStatusID = t.TicketStatus
		INNER JOIN Employee e ON e.EmployeeID = t.Requester
		INNER JOIN Employee f ON f.EmployeeID = t.AssignedTo
		INNER JOIN Account a ON a.AccountID = t.AccountID
		WHERE
			(((@TicketClass = 1) and (t.CurrentEmployeeID = @EmployeeID)) or ((@TicketClass = 0) and (t.Requester = @EmployeeID)))
			AND t.TicketStatus <> 9	
			AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
				
	)

	SELECT
		KeyField,
		[Ticket ID],
		[Requester],
		[Assign To],
		[Current Stage],
		[Total Stage],
		[Request Date],
		[Start Date],
		[Due Date],
		[Ticket Status],
		Priority
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount

END

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByAllocQueue]    Script Date: 04/13/2009 16:50:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByAllocQueue] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@v_AllocRule int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT * INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@v_EmployeeId)
	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	WHERE
		(a.EmployeeID = @v_EmployeeId OR a.TempEmployeeID = @v_EmployeeId)
		AND a.AllocRuleID = @v_AllocRule
		AND a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.QueueDate desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			(a.EmployeeID = @v_EmployeeId OR a.TempEmployeeID = @v_EmployeeId)			
			AND a.AllocRuleID = @v_AllocRule
			AND a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

/****** Object:  StoredProcedure [dbo].[SearchAccountByInvoice]    Script Date: 04/13/2009 16:51:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Script is applied on version 1.9.23

ALTER   PROCEDURE [dbo].[SearchAccountByInvoice](@Invoice char(50),@EmpList varchar(3000)) As
BEGIN
DECLARE @cStmt NVARCHAR(4000)

DECLARE @employeeID varchar(50)
DECLARE @index int

SET @index = charindex('|', @EmpList)
SET @employeeID = substring(@EmpList, 1, @index -1)
SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name],'
	SET @cStmt=@cStmt+'a.DebtorID As [DebtorID]'	
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where a.InvoiceNumber = '+''''+Cast(@Invoice As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	
	SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
	SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'

if @EmpList <> ''
begin
	SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'						 
end

SET @cStmt=@cStmt+' and a.DebtorID <> 0'

Exec SP_ExecuteSQL @cStmt
END

/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueByAmtRange]    Script Date: 04/13/2009 16:51:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_QueueByAmtRange] 
	-- Add the parameters for the stored procedure here
	@v_Range int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @employeeID varchar(50)
	DECLARE @index int

	SET @index = charindex('|', @EmpList)
	SET @employeeID = substring(@EmpList, 1, @index -1)
	SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause VARCHAR(50)
	SET @orderByClause = ' ORDER BY a.QueueDate DESC'


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)	

	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate <= getDate()'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

	SELECT * INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
	SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'

	if ((@EmpList <> '') and (@EmpList <> 'Null'))
	Begin
		SET @cStmt=@cStmt+' AND a.EmployeeID in (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(''' + @EmpList + ''',' + '''' + ',' + '''' + '))'						 
	End



	if @v_Range = 1
	Begin
		SET @cStmt = @cStmt +'   AND a.BillBalance < 10000'
	End

	if @v_Range = 2
	Begin
		SET @cStmt = @cStmt +'  AND a.BillBalance >= 10000'
		SET @cStmt = @cStmt +'  AND a.BillBalance < 25000'
	End

	if @v_Range = 3
	Begin
		SET @cStmt = @cStmt +'	AND a.BillBalance >= 25000'
		SET @cStmt = @cStmt +'	AND a.BillBalance < 50000'		
	End

	if @v_Range = 4
	Begin
		SET @cStmt = @cStmt +'	AND a.BillBalance >= 50000'
		SET @cStmt = @cStmt +'	AND a.BillBalance < 150000'		
	End

	if @v_Range = 5
	Begin
		SET @cStmt = @cStmt +'	AND a.BillBalance >= 150000'
	End


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END


/****** Object:  StoredProcedure [dbo].[SearchAccountByBill]    Script Date: 04/13/2009 16:52:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchAccountByBill](@AcctID INT,@EmpList varchar(3000)) As
BEGIN

DECLARE @employeeID varchar(50)
DECLARE @index int

SET @index = charindex('|', @EmpList)
SET @employeeID = substring(@EmpList, 1, @index -1)
SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where a.AccountID = '+Cast(@AcctID As Char(9))
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'

	SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
	SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'
	
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
	end

	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END


set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchDebtorByName]    Script Date: 04/13/2009 16:52:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Account_SearchDebtorByName] 
	@DebtorName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

DECLARE @employeeID varchar(50)
DECLARE @index int
SET @index = charindex('|', @EmpList)
SET @employeeID = substring(@EmpList, 1, @index -1)
SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

IF LEN(ISNULL(@EmpList,'')) = 0
	Begin
		SELECT
			@RowCount = COUNT(a.AccountID)
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')			
			AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

		IF @PageSize > 0
		BEGIN
			SET @BeginIndex = @PageIndex * @PageSize + 1
			SET @EndIndex = (@PageIndex + 1) * @PageSize
		END
		ELSE
		BEGIN
			SET @BeginIndex = 1
			SET @EndIndex = @RowCount
		END

		WITH Temp
		AS
		(
			SELECT
				ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
				(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
				a.QueueDate AS [QueueDate],
				a.InvoiceNumber as [Account Number],
				a.AccountAge AS [DPD],
				a.MCode AS [Bucket],
				a.CCode AS [Cycle],
				a.BillAmount AS [Bill Amount],
				a.BillBalance AS [Bill Balance],
				s.ShortDesc as [Status],
				s.SortPriority AS [Priority],
				a.AssignmentType AS [Assignment Type],
				p.SocialSecurityNumber AS [ID],
				rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
			FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			WHERE
				a.DebtorID <> 0
				AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
				AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
		)

		SELECT
			[KeyField],
			[QueueDate],
			[Account Number],
			[DPD],
			[Bucket],
			[Cycle],
			[Bill Amount],
			[Bill Balance],
			[Status],
			[Priority],
			[Assignment Type],
			[ID],
			[Name]
		FROM Temp
		WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

		RETURN @RowCount
	End
Else
	Begin
		SELECT
			@RowCount = COUNT(a.AccountID)
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
		IF @PageSize > 0
		BEGIN
			SET @BeginIndex = @PageIndex * @PageSize + 1
			SET @EndIndex = (@PageIndex + 1) * @PageSize
		END
		ELSE
		BEGIN
			SET @BeginIndex = 1
			SET @EndIndex = @RowCount
		END

		WITH Temp
		AS
		(
			SELECT
				ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
				(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
				a.QueueDate AS [QueueDate],
				a.InvoiceNumber as [Account Number],
				a.AccountAge AS [DPD],
				a.MCode AS [Bucket],
				a.CCode AS [Cycle],
				a.BillAmount AS [Bill Amount],
				a.BillBalance AS [Bill Balance],
				s.ShortDesc as [Status],
				s.SortPriority AS [Priority],
				a.AssignmentType AS [Assignment Type],
				p.SocialSecurityNumber AS [ID],
				rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
			FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			WHERE
				a.DebtorID <> 0
				AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
				AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
				AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
		)

		SELECT
			[KeyField],
			[QueueDate],
			[Account Number],
			[DPD],
			[Bucket],
			[Cycle],
			[Bill Amount],
			[Bill Balance],
			[Status],
			[Priority],
			[Assignment Type],
			[ID],
			[Name]
		FROM Temp
		WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

		RETURN @RowCount
	End


END

/****** Object:  StoredProcedure [dbo].[SearchDebtorByPhone]    Script Date: 04/13/2009 16:53:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchDebtorByPhone](@PhoneNumber char(25),@EmpList varchar(3000)) As
BEGIN

DECLARE @employeeID varchar(50)
DECLARE @index int

SET @index = charindex('|', @EmpList)
SET @employeeID = substring(@EmpList, 1, @index -1)
SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where p.HomePhone = '+''''+Cast(@PhoneNumber As Char(25))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'

	SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
	SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'

	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'						 
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON

/****** Object:  StoredProcedure [dbo].[SearchAccountByMobile]    Script Date: 04/13/2009 16:53:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchAccountByMobile](@MobilePhone char(50),@EmpList varchar(3000)) As
BEGIN

DECLARE @employeeID varchar(50)
DECLARE @index int

SET @index = charindex('|', @EmpList)
SET @employeeID = substring(@EmpList, 1, @index -1)
SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
SET @cStmt=@cStmt+'a.CCode as [Cycle],'
SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where p.MobilPhone = '+''''+Cast(@MobilePhone As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	
	SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
	SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'
	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'						 
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON

/****** Object:  StoredProcedure [dbo].[SearchByofficePhone]    Script Date: 04/13/2009 16:54:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchByofficePhone](@PhoneNumber char(50),@EmpList varchar(3000)) As
BEGIN

DECLARE @employeeID varchar(50)
DECLARE @index int

SET @index = charindex('|', @EmpList)
SET @employeeID = substring(@EmpList, 1, @index -1)
SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)

DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where p.EmploymentPhone = '+''''+Cast(@PhoneNumber As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	
	SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
	SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'

	if @EmpList <> ''
	begin
		SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'						 
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByEmployeeName]    Script Date: 04/13/2009 16:54:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_Account_SearchByEmployeeName] 
	@EmployeeName varchar(100),
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

	DECLARE @employeeID varchar(50)
	DECLARE @index int

	SET @index = charindex('|', @EmpList)
	SET @employeeID = substring(@EmpList, 1, @index -1)
	SET @EmpList = substring(@EmpList, @index +1, len(@EmpList) - @index)
	
	SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
	WHERE
		a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
		AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			g.EmployeeName AS [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID 
		WHERE
			a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
			AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
	WHERE
		a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			g.EmployeeName AS [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID 
		WHERE
			a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

/****** Object:  StoredProcedure [dbo].[CWX_GetEmployeeNextPoolAccount]    Script Date: 04/13/2009 16:55:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		KhoaDang
-- =============================================
ALTER PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount] 
	@v_currentLoginEmployeeId int,
	@v_employeeId int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
	
    DECLARE @cStmt varchar(8000)
	SET @cStmt =  ' SELECT a.DebtorID, a.AccountID,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN Accountother o ON o.AccountID = a.AccountID'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND a.EmployeeID = '+CAST(@v_employeeId as varchar(9))				
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID in (1,5)'
				+ '	  AND a.PoolSelected = 0'
	
	SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@v_employeeId)
	SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'

	--Step 4: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'
	
	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	--Step 5: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT top 1 DebtorID, AccountID, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name] INTO #PoolAccount '
				   + 'FROM AccountResults '
				   + @pagingWhereClause	
				   + ' DECLARE @AccountID int '
				   + ' DECLARE @DebtorID int '
				   + ' SELECT @AccountID=AccountID, @DebtorID=DebtorID FROM #PoolAccount '
				   + ' EXEC CWX_Account_UpdatePoolStatus @AccountID, @DebtorID, ' + STR(@v_currentLoginEmployeeId)
				   + ' SELECT (CONVERT(varchar(10), DebtorID) + ''|'' + CONVERT(varchar(10), AccountID)) AS KeyField, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name] '
				   + ' FROM #PoolAccount '

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)

	--Step 6: Execute the main SQL command.	
	EXEC (@finalStmt)
		
	if (@RowCount > 1)
		RETURN 2

	RETURN @RowCount
END

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByPoolPending]    Script Date: 04/13/2009 16:55:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByPoolPending] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@PoolID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
	

    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '   AND s.SystemStatus in (1,5)'
--				+ '   AND convert(varchar(10),a.SubmissionDate,121)=convert(varchar(10),GetDate(),121)'
				+ '   AND a.OfficeID = '+CAST(@v_employeeId as varchar(9))
				+ '   AND a.EmployeeID = '+CAST(@PoolID as varchar(9))				
				+ '   AND a.IsPending = 1'
				+ '	  AND a.PoolSelected = 1'

	SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@v_employeeId)
	SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END


-- Alter store procedure CWX_TracerInformation_CustomDefinedField_Select
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_CustomDefinedField_Select]    Script Date: 04/13/2009 10:02:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Tuan Luong
-- Create date: May 15, 2008
-- Description:	Get custom defined fields.
-- History:
--	2008/05/15	[Tuan Luong]	Init version.
--	2009/04/06	[Minh Dam]		Add code: "AND (a.Type IN (1,2))"
--								Add parameter "@ClientID" and filter by ClientID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_TracerInformation_CustomDefinedField_Select]	
	@DebtorID	int,
	@AccountID	int,
	@ClientID int = 0,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(c.ID)
	FROM CWX_CustomDefinedFields c 
	INNER JOIN AgencyDefinedMaster a ON c.AgencyID = a.AgencyDefID
	WHERE c.AgencyID <> 0 AND c.AccountID = @AccountID AND c.DebtorID = @DebtorID AND a.Status <> 'R'
		AND (a.Type IN (1,2)) -- Type equals Account or Debtor	
		AND (@ClientID = 0 OR ISNULL(a.ClientID, 0) = 0 OR a.ClientID = @ClientID)

	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY Description) AS RowNumber, ID, a.LongName as [Description]	, [Value], FormatString		
		FROM CWX_CustomDefinedFields c 
		INNER JOIN AgencyDefinedMaster a ON c.AgencyID = a.AgencyDefID
		WHERE c.AgencyID <> 0 AND c.AccountID = @AccountID AND c.DebtorID = @DebtorID AND a.Status <> 'R'
			AND (a.Type IN (1,2)) -- Type equals Account or Debtor
			AND (@ClientID = 0 OR ISNULL(a.ClientID, 0) = 0 OR a.ClientID = @ClientID)
	)

	SELECT	* FROM	Temp
	WHERE	(@PageSize <= 0) OR (RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize))
	
	RETURN @RowCount

END
GO

-- Alter stored procedure CWX_TracerInformation_CustomDefinedField_Initialize
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]    Script Date: 04/13/2009 10:04:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ===================================================================================
-- Author:		Tuan Luong
-- Create date: May 15, 2008
-- Description:	Initializes CustomDefinedFields within the given debtorID, accountID.
-- Note: Modified on May 20, 2008 by Tuan Luong to improve performance
-- History:
--	2008/05/15	[Tuan Luong]	Init version.
--	2009/04/07	[Minh Dam]		Add code: "AND (a.Type IN (1,2))"
--								Add parameter "@ClientID" and filter by ClientID
-- ===================================================================================
ALTER PROC [dbo].[CWX_TracerInformation_CustomDefinedFields_Initialize]
	@DebtorID INT,
	@AccountID INT,
	@ClientID int = 0
AS
BEGIN
	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	INSERT CWX_CustomDefinedFields (AgencyID, AccountID, DebtorID, Description)
	SELECT AgencyDefID, @AccountID, @DebtorID, LongName
	FROM AgencyDefinedMaster
	WHERE AgencyDefID not in (Select AgencyID From CWX_CustomDefinedFields Where AccountID = @AccountID and DebtorID = @DebtorID)
		AND [Status] <> 'R'
		AND [Type] IN (1,2) -- Type equals Account or Debtor
		AND (@ClientID = 0 OR ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)

	IF( @@ERROR <> 0)
		GOTO Cleanup		


	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END	
END
GO

-- Create stored procedure CWX_CollateralCustomFields_DeleteOthers
/****** Object:  StoredProcedure [dbo].[CWX_CollateralCustomFields_DeleteOthers]    Script Date: 04/13/2009 10:05:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CollateralCustomFields_DeleteOthers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CollateralCustomFields_DeleteOthers]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CollateralCustomFields_DeleteOthers]    Script Date: 04/13/2009 10:05:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 07 Apr 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CollateralCustomFields_DeleteOthers]
	@CollateralID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DELETE CWX_CollateralCustomFields
	WHERE CollateralID = @CollateralID
		AND AgencyID NOT IN (SELECT AgencyDefID 
							FROM AgencyDefinedMaster 
							WHERE [Type] = 3 -- Collateral 
								AND [Status] <> 'R')		
END
GO

-- Create stored procedure CWX_AgencyDefinedMaster_IsEditable
/****** Object:  StoredProcedure [dbo].[CWX_AgencyDefinedMaster_IsEditable]    Script Date: 04/13/2009 10:06:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AgencyDefinedMaster_IsEditable]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AgencyDefinedMaster_IsEditable]
GO

/****** Object:  StoredProcedure [dbo].[CWX_AgencyDefinedMaster_IsEditable]    Script Date: 04/13/2009 10:07:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 07 Apr 2009	
-- Description:	Check whether a custom defined field is editable or not
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AgencyDefinedMaster_IsEditable]
	@AgencyID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF NOT EXISTS (SELECT 1 FROM CWX_CustomDefinedFields WHERE AgencyID = @AgencyID)
		AND NOT EXISTS (SELECT 1 FROM CWX_CollateralCustomFields WHERE AgencyID = @AgencyID)
		RETURN 1
	ELSE
		RETURN 0
END
GO

-- Create stored procedure CWX_TracerInformation_GetCollateralCustomFields
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_GetCollateralCustomFields]    Script Date: 04/13/2009 10:08:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_GetCollateralCustomFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TracerInformation_GetCollateralCustomFields]
GO

/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_GetCollateralCustomFields]    Script Date: 04/13/2009 10:08:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 06 Apr 2009
-- Description:	Get custom defined fields and their values belong to a collateral
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TracerInformation_GetCollateralCustomFields]
	@CollateralID int,
	@ClientID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT c.ID, a.AgencyDefID, a.LongName as [Description], c.Value, a.FormatString
	FROM AgencyDefinedMaster a
		LEFT JOIN CWX_CollateralCustomFields c 
		ON a.AgencyDefID = c.AgencyID AND c.CollateralID = @CollateralID
	WHERE a.Type = 3 -- Collateral
		AND a.Status <> 'R'
		AND (@ClientID = 0 OR ISNULL(a.ClientID, 0) = 0 OR a.ClientID = @ClientID)
	ORDER BY a.LongName
END
GO

-- Alter stored procedure CWX_GetQueueStatsByEmployee
/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 04/13/2009 10:09:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <17 June 2008>
-- Description:	<Get Queue Statistic by Collector for chart>
-- History:
--	2008/07/11	[Thuy Nguyen]	Init version.
--	2009/03/30	[Minh Dam]		Add parameter "@ClientID" and filter by ClientID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int,
	@ClientID int = 0
AS
BEGIN

	DECLARE @BeforeDays INT
	DECLARE @AfterDays INT

	IF (@ReportTime = 0)
		BEGIN
			SELECT
				CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) as QueueDate,
				ISNULL(COUNT(DISTINCT AccountID),0) AS AccountCount,
				ISNULL(SUM(BillBalance),0) AS AccountBalance
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
									  AND CONVERT(VARCHAR(10),DateCompleted,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
									  AND CONVERT(VARCHAR(10),DateCompleted,121) <= CONVERT(VARCHAR(10),GETDATE() + 6,121))
				AND SystemStatusID in (1,5)
				AND (@ClientID = 0 OR ClientID = @ClientID)
			GROUP BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
			ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))
		END
	ELSE
		BEGIN
			SELECT
				CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) as QueueDate,
				ISNULL(COUNT(DISTINCT AccountID),0) AS AccountCount,
				ISNULL(SUM(BillBalance),0) AS AccountBalance
			FROM Account
			WHERE 
				AccountID in (SELECT AccountID
								FROM AccountActions
								WHERE ResponsibleParty = @EmployeeID 
									  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))
				AND SystemStatusID in (1,5)
				AND (@ClientID = 0 OR ClientID = @ClientID)
			GROUP BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
			ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))
		END
END
GO

-- Create stored procedure CWX_DebtorInformation_LockAccounts
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_LockAccounts]    Script Date: 04/13/2009 10:10:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInformation_LockAccounts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DebtorInformation_LockAccounts]
GO

/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_LockAccounts]    Script Date: 04/13/2009 10:10:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 08 Apr 2009
-- Description:	Lock all accounts of a debtor
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DebtorInformation_LockAccounts]
	@DebtorID int,
	@LockedByEmployeeID int,
	@LockedDate datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE DebtorInformation
	SET LockedByID = @LockedByEmployeeID,
		LockedDate = @LockedDate
	WHERE DebtorID = @DebtorID
END
GO

-- Create stored procedure CWX_DebtorInformation_UnlockAccounts
/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_UnlockAccounts]    Script Date: 04/13/2009 10:11:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DebtorInformation_UnlockAccounts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DebtorInformation_UnlockAccounts]
GO

/****** Object:  StoredProcedure [dbo].[CWX_DebtorInformation_UnlockAccounts]    Script Date: 04/13/2009 10:11:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 08 Apr 2009
-- Description:	Unlock all accounts of a debtor
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DebtorInformation_UnlockAccounts]
	@DebtorID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE DebtorInformation
	SET LockedByID = null,
		LockedDate = null
	WHERE DebtorID = @DebtorID
END
GO

-- Alter stored procedure CWX_Account_LoadXML
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 04/13/2009 10:12:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description:	Load all accounts with debtorID
-- History:
--	2008/04/03	[Tai Ly]	Init version.
--	2008/06/01	[Long Nguyen]	Add and remove some fields.
--	2008/06/27	[Binh Truong]	Remove BatchNumber field.	
--	2008/08/25	[Long Nguyen]	Remove @AdditionalTag
--	2008/09/04	[Thuy Nguyen]	Remove CoSigner table reference
--	2009/03/19	[Thuy Nguyen]	Remove ClientInformation.ContactName
--  2009/04/10	[Minh Dam]		Add parameter "@EmployeeID" that is the id of current login user 
--									and filter Account by ClientID belong to this user.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int,
	@EmployeeID int
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/	
	WITH ClientListTable AS
	(
		SELECT * FROM dbo.CWX_AssignedClientIDTable(@EmployeeID)
	)

	SELECT
			a.AccountID,
			ISNULL(l.LetterDesc, '') AS SENTBY, ISNULL(al.LetterStatus, '') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			p.AmountPromised AS FirstAmountPromised, p.PromiseFrequency AS FirstPromiseFrequency, p.Term AS FirstPromiseTerm, p.DatePromised, '' AS PROMISE,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL,
			lastpromise.LASTPROMISEDATE, lastpromise.LASTPROMISEAMOUNT, lastpromise.LASTPROMISESTATUS, lastpromise.LASTPROMISESTATUSDESC,
			(CASE ISNULL(lg.GroupedAccountID, 0) WHEN 0 THEN 0 ELSE 1 END) AS IsGroupedAccount
	INTO	#AccountTemp
	FROM	Account	 a
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN 'd' THEN 'day(s)'
						WHEN 'w' THEN 'week(s)'
						WHEN 'm' THEN 'month(s)'
						WHEN 'y' THEN 'year(s)'
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get last promise
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised AS LASTPROMISEAMOUNT,
					p2.DatePromised AS LASTPROMISEDATE,
					p2.Status AS LASTPROMISESTATUS,
					CASE p2.Status
						WHEN 0 THEN 'Not Due'
						WHEN 1 THEN 'Paid On Time'
						WHEN 2 THEN 'Paid Late'
						WHEN 3 THEN 'Broken Promise'
						WHEN 4 THEN 'Canceled'
						ELSE ''
					END AS LASTPROMISESTATUSDESC
				FROM AccountPromise p2 
				WHERE p2.PromiseID IN 
						(	SELECT TOP 1 PromiseID
							FROM (	SELECT PromiseID, DatePromised
									FROM AccountPromise 
									WHERE AccountID = p2.AccountID -- 69
							) as temp
							ORDER BY DatePromised DESC
						)) lastpromise ON lastpromise.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	--Check if account is GroupAccount
	LEFT JOIN Legal_Groups lg ON lg.GroupedAccountID = a.AccountID
	WHERE DebtorID = @DebtorID
		AND (NOT EXISTS(SELECT 1 FROM ClientListTable) OR a.ClientID IN (SELECT ClientID FROM ClientListTable))

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, nextAction.CodeDesc AS CurrentNextActionDesc, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, --ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised, #AccountTemp.FirstAmountPromised, #AccountTemp.FirstPromiseFrequency, #AccountTemp.FirstPromiseTerm
			, #AccountTemp.LASTPROMISEDATE, #AccountTemp.LASTPROMISEAMOUNT, #AccountTemp.LASTPROMISESTATUS, #AccountTemp.LASTPROMISESTATUSDESC
			, #AccountTemp.LASTCONTACTDATE, #AccountTemp.LASTCONTACTBY, #AccountTemp.PROMISETOPAY, #AccountTemp.PROMISEKEPT, #AccountTemp.PROMISEBROKEN, #AccountTemp.OUTGOINGCALL, #AccountTemp.NOACTIVITYDAYS
			, ISNULL(Account.IsPending, 0) AS IsPending
			, #AccountTemp.IsGroupedAccount
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID
			LEFT OUTER JOIN AccountCodeMaster nextAction on Account.CurrentNextAction = nextAction.CodeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END
GO

-- Thuy Nguyen create new table Client Information  ---

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

IF(EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'ClientInformation_New') and type in (N'U')))
	DROP TABLE ClientInformation_New

CREATE TABLE [dbo].[ClientInformation_New](
	[ClientID] [int] IDENTITY(1,1) NOT NULL,
	[ClientName] [nvarchar](50) NOT NULL,
	[Priority] [int] NULL,
	[Active] [bit] NOT NULL,
	[ClientTypeID] [int] NULL,
	[CurrencyID] [int] NULL,
	[ReallocationDay] [tinyint] NULL,
	[AgingForReschedule] [money] NULL,
	[AgingForDiscount] [money] NULL,
	[RescheduleAllowed] [int] NULL,
	[DiscountAllowed] [int] NULL,
	[DeptIDs] [varchar](1000) NULL,
	[LetterheadImage] [image] NULL,
	[Status] [char](1) NOT NULL DEFAULT ('A'),
	[CreditorID] [int] NULL,
	[PaymentAllocationRuleID] [int] NULL,
	[AgingForApportion] [money] NULL,
	[ApportionAllowed] [money] NULL,
	[CString1] [nvarchar](25) NULL,
	[CString2] [nvarchar](25) NULL,
	[CString3] [nvarchar](25) NULL,
	[CString4] [nvarchar](25) NULL,
	[CString5] [nvarchar](25) NULL,
	[CString6] [nvarchar](25) NULL,
	[CString7] [nvarchar](25) NULL,
	[CString8] [nvarchar](25) NULL,
	[CString9] [nvarchar](25) NULL,
	[CString10] [nvarchar](25) NULL,
	[CString11] [nvarchar](50) NULL,
	[CString12] [nvarchar](50) NULL,
	[CString13] [nvarchar](50) NULL,
	[CString14] [nvarchar](50) NULL,
	[CString15] [nvarchar](50) NULL,
	[CString16] [nvarchar](50) NULL,
	[CString17] [nvarchar](50) NULL,
	[CString18] [nvarchar](50) NULL,
	[CString19] [nvarchar](50) NULL,
	[CString20] [nvarchar](50) NULL,
	[CString21] [nvarchar](100) NULL,
	[CString22] [nvarchar](100) NULL,
	[CString23] [nvarchar](100) NULL,
	[CString24] [nvarchar](100) NULL,
	[CString25] [nvarchar](100) NULL,
	[CInt1] [int] NULL DEFAULT ((0)),
	[CInt2] [int] NULL DEFAULT ((0)),
	[CInt3] [int] NULL DEFAULT ((0)),
	[CInt4] [int] NULL DEFAULT ((0)),
	[CInt5] [int] NULL DEFAULT ((0)),
	[CInt6] [int] NULL DEFAULT ((0)),
	[CInt7] [int] NULL DEFAULT ((0)),
	[CInt8] [int] NULL DEFAULT ((0)),
	[CInt9] [int] NULL DEFAULT ((0)),
	[CInt10] [int] NULL DEFAULT ((0)),
	[CMoney1] [money] NULL DEFAULT ((0)),
	[CMoney2] [money] NULL DEFAULT ((0)),
	[CMoney3] [money] NULL DEFAULT ((0)),
	[CMoney4] [money] NULL DEFAULT ((0)),
	[CMoney5] [money] NULL DEFAULT ((0)),
	[CMoney6] [money] NULL DEFAULT ((0)),
	[CMoney7] [money] NULL DEFAULT ((0)),
	[CMoney8] [money] NULL DEFAULT ((0)),
	[CMoney9] [money] NULL DEFAULT ((0)),
	[CMoney10] [money] NULL DEFAULT ((0)),
	[CBit1] [bit] NULL DEFAULT ((0)),
	[CBit2] [bit] NULL DEFAULT ((0)),
	[CBit3] [bit] NULL DEFAULT ((0)),
	[CBit4] [bit] NULL DEFAULT ((0)),
	[CBit5] [bit] NULL DEFAULT ((0)),
	[CBit6] [bit] NULL DEFAULT ((0)),
	[CBit7] [bit] NULL DEFAULT ((0)),
	[CBit8] [bit] NULL DEFAULT ((0)),
	[CFLoat1] [float] NULL DEFAULT ((0)),
	[CFLoat2] [float] NULL DEFAULT ((0)),
	[CFLoat3] [float] NULL DEFAULT ((0)),
	[CFLoat4] [float] NULL DEFAULT ((0)),
	[CFLoat5] [float] NULL DEFAULT ((0)),
	[CFLoat6] [float] NULL DEFAULT ((0)),
	[CFLoat7] [float] NULL DEFAULT ((0)),
	[CFLoat8] [float] NULL DEFAULT ((0)),
	[CFLoat9] [float] NULL DEFAULT ((0)),
	[CFLoat10] [float] NULL DEFAULT ((0)),
 CONSTRAINT [PK_CWX_ClientInformation] PRIMARY KEY CLUSTERED 
(
	[ClientID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

SET IDENTITY_INSERT ClientInformation_New ON
INSERT INTO [dbo].[ClientInformation_New]
           ([ClientID],[ClientName],[Priority],[Active],[ClientTypeID],[CurrencyID]
           ,[ReallocationDay],[AgingForReschedule],[AgingForDiscount],[RescheduleAllowed]
           ,[DiscountAllowed],[DeptIDs],[LetterheadImage],[Status],[CreditorID]
           ,[PaymentAllocationRuleID],[AgingForApportion],[ApportionAllowed]
           ,[CString1],[CString2],[CString3],[CString4],[CString5],[CString6]
           ,[CString7],[CString8],[CString9],[CString10],[CString11],[CString12]
           ,[CString13],[CString14],[CString15],[CString16],[CString17]
           ,[CString18],[CString19],[CString20],[CString21],[CString22]
           ,[CString23],[CString24],[CString25]
           ,[CInt1],[CInt2],[CInt3],[CInt4],[CInt5],[CInt6],[CInt7],[CInt8],[CInt9],[CInt10]
           ,[CMoney1],[CMoney2],[CMoney3],[CMoney4],[CMoney5],[CMoney6],[CMoney7],[CMoney8]
           ,[CMoney9],[CMoney10]
           ,[CBit1],[CBit2],[CBit3],[CBit4],[CBit5],[CBit6],[CBit7],[CBit8]
           ,[CFLoat1],[CFLoat2],[CFLoat3],[CFLoat4],[CFLoat5],[CFLoat6],[CFLoat7],[CFLoat8],[CFLoat9],[CFLoat10])

SELECT		[ClientID],[ClientName],[Priority],[Active],null,null
           ,[ClientPayCycle],[AgingForReschedule],[AgingForDiscount],[RescheduleAllowed]
           ,[DiscountAllowed],[DeptIDs],[LetterheadImage],[Status],[CreditorID]
           ,[PaymentAllocationRuleID],[AgingForApportion],[ApportionAllowed]
           ,null, null, null, null, null, null, null, null, null, null
           ,null, null, null, null, null, null, null, null, null, null 
           ,null, null, null, null, null, null, null, null, null, null 
           ,null, null, null, null, null, null, null, null, null, null 
           ,null, null, null, null, null, null, null, null, null, null 
           ,null, null, null, null, null, null, null, null, null, null 
           ,null, null, null
		FROM ClientInformation

SET IDENTITY_INSERT ClientInformation_New OFF

EXECUTE sp_rename N'dbo.ClientInformation', N'ClientInformation_Old', 'OBJECT' 
EXECUTE sp_rename N'dbo.ClientInformation_New', N'ClientInformation', 'OBJECT' 

GO
SET ANSI_PADDING OFF

-- End of Thuy Nguyen create new table Client Information  ---

 --------------ThanhNguyen--------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DropDownDataDictionary]') AND type in (N'U'))
BEGIN
	
	INSERT INTO CWX_DropdownDataDictionary
	VALUES('Select CodeID, CodeDesc FROM AccountCodeMaster WHERE CodeType = 2 AND Status <> ''R''',0)

	INSERT INTO CWX_DropdownDataDictionary
	ValueS('Select LanguageID, Description FROM Languages WHERE Status <> ''R''',0) 

	INSERT INTO CWX_DropdownDataDictionary
	VALUES('Early in the Morning|Morning|Afternoon|EveningNight',1)

	INSERT INTO CWX_DropdownDataDictionary
	VALUES('Accounting|Software|Human Resources|Admin|IT',1)
	
	INSERT INTO CWX_DropdownDataDictionary
	VALUES('Select CodeID, CodeDesc FROM AccountCodeMaster WHERE CodeType = 1 AND Status <> ''R''',0)
	
	INSERT INTO CWX_DropdownDataDictionary
	VALUES('Select CodeID, CodeDesc FROM AccountCodeMaster WHERE CodeType = 3 AND Status <> ''R''',0)

END

------INSERT TEST DATA TO CWX_PersonInformation_Dict
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonInformation_Dict]') AND type in (N'U'))
BEGIN		
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'HomePhone'))
	BEGIN	
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('HomePhone','Home Phone',1,1,0,'Contact Information',1,1,0,0,1)
    END
    
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'MobilPhone'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('MobilPhone','Mobil Phone',1,1,0,'Contact Information',2,1,0,0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'EmploymentPhone'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('EmploymentPhone','Employment Phone',1,1,0,'Contact Information',3,1,0,0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'EmploymentPhoneExtension'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('EmploymentPhoneExtension','Employment Phone Extension',1,1,0,'Contact Information',4,1,0,0,1)
	END
		
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'Position'))
	BEGIN		
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('Position','Position',1,1,1,'Debtor Career',1,2,11,0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'Profession'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('Profession','Profession',1,1,1,'Debtor Career',2,2,11,0,1)
    END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'Language'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('Language','Language',1,1,1,'Debtor Career',3,2,11,2,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'Department'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('Department','Department',1,1,1,'Debtor Career',4,2,11,4,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PMoney1'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('PMoney1','Total Income Per Month',1,1,2,'Income',1,3,0,0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PMoney2'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('PMoney2','Husband Income',1,1,2,'Income',2,3,0,0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PMoney3'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('PMoney3','Wife Income',1,1,2,'Income',3,3,0,0,1)
	END

	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PLong1'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('PLong1','Number Of Childs',1,1,3,'Debtor Children Information',1,4,0,0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PLong2'))
	BEGIN	
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('PLong2','Age Of First Child',1,1,3,'Debtor Children Information',2,4,0,0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PLong3'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[PageNumber],[Client],[DropDown],[CMSEditable])
    VALUES('PLong3','Age Of Last Child',1,1,3,'Debtor Children Information',3,4,0,0,1)
	END
END

-------INSERT DATA TO CWX_AccountInformation_Dict
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountInformation_Dict]') AND type in (N'U'))
BEGIN
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'RountinePayment'))
	BEGIN	
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('RountinePayment','Rountine Payment',1,1,2,'Account Payment Information',0,1,0,2,1,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'BillAmount'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('BillAmount','Bill Amount',1,1,2,'Account Payment Information',1,1,0,2,1,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'PaymentPlan'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('PaymentPlan','Payment Plan',1,1,2,'Account Payment Information',2,1,0,2,1,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'AccountType'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('AccountType','Account Type',1,1,1,'Account Information',1,1,0,1,2,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'InvoiceNumber'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('InvoiceNumber','Invoice Number',1,1,1,'Account Information',2,1,0,1,2,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'AccountClass'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('AccountClass','Account Class',1,1,1,'Account Information',3,1,0,1,2,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'Long1'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('Long1','Credit',1,1,1,'Account Credit',1,2,0,3,0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'Long2'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('Long2','Credit',1,1,2,'Account Credit',1,2,0,3,0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentNextAction'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('CurrentNextAction','Current Next Action',1,1,2,'Account Action',1,1,1,3,3,1)
	END

	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentNextActionDate'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('CurrentNextActionDate','Current Next Action Date',1,1,2,'Account Action',2,1,0,3,3,1)
	END

	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentCallResult'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('CurrentCallResult','Current Call Result',1,1,2,'Account Action',3,1,6,3,3,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentCallResultDate'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('CurrentCallResultDate','Current CallResult Date',1,1,2,'Account Action',4,1,0,3,3,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentReason'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('CurrentReason','Current Reason',1,1,2,'Account Action',5,1,5,3,3,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentReasonDate'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[PageNumber],[Client],[CMSEditable])
    VALUES('CurrentReasonDate','Current Reason Date',1,1,2,'Account Action',6,1,0,3,0,1)		
    END
END

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_Dict]') AND type in (N'U'))
BEGIN	
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString1'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString1','Address1',1,1,1,'ClientInformation',1,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString2'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString2','Address2',1,1,1,'ClientInformation',2,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString3'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString3','Email',1,1,1,'ClientInformation',3,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString4'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString4','City',1,1,1,'ClientInformation',4,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString5'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString5','State',1,1,1,'ClientInformation',5,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString6'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString6','Zip',1,1,1,'ClientInformation',6,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString7'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString7','Country',1,1,1,'ClientInformation',7,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString8'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString8','Region',1,1,1,'ClientInformation',8,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString9'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString9','PhoneNumber',1,1,1,'ClientInformation',9,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString10'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString10','FaxNumber',1,1,1,'ClientInformation',10,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CInt1'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CInt1','Client Percent',1,1,1,'Client Percent Information',1,3,'Client Percent Information',1,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CInt2'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CInt2','Client Old Percent',1,1,1,'Client Percent Information',2,3,'Client Percent Information',1,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CInt3'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CInt3','Client Percent',1,1,1,'Client Percent Information',3,3,'Client Percent Information',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CFloat1'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CFloat1','Previous Balance',1,1,2,'Client Balance Information',1,2,'Client Balance Information',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CFloat2'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CFloat2','Previous AP Balance',1,1,2,'Client Balance Information',2,2,'Client Balance Information',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CFloat3'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CFloat3','Deduct AR Balance',1,1,2,'Client Balance Information',3,2,'Client Balance Information',0,0)
	END	
END
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Person_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thuy Nguyen
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an person
-- History:
--	[06 Mar 2009]	Thuy Nguyen		Init version.
--	[20 Mar 2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[10 Apr 2009]	Thanh Nguyen	Add parameter "@CMSEditable"
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
	@PersonID int,
	@PageNumber int = 1,
	@Client int = 0,
	@PageSize int = 10, -- it's only used for function parameter
	@PageIndex int = 0, -- it's only used for function parameter
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 			
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[Editable],			
			b.[DataType],
			b.[MaxLength],			
			a.[DropDown],
			ISNULL(c.[SQL], '') as SQLDropDown,
			ISNULL(c.Listed, 0) as Listed
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [GroupID], [GroupDesc], [DisplayOrder],
				CASE WHEN @CMSEditable = 1 THEN [CMSEditable] ELSE [Editable] END as [Editable] , [DropDown] 
		FROM	CWX_PersonInformation_Dict
		WHERE	Displayed = 1	and PageNumber = @PageNumber and 
				(Client = @Client or ISNULL(Client, 0) = 0  )) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'PersonInformation' and [Type]='U')			
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'PersonID, LastName, FirstName, MiddleName, PString1'
	
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM PersonInformation WHERE PersonID = ' + Cast(@PersonID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup

	DECLARE @PageCount int
	SELECT @PageCount = MAX(PageNumber) 
	FROM CWX_PersonInformation_Dict 
	WHERE Displayed = 1 AND (Client = @Client or (Client = @Client or ISNULL(Client, 0) = 0  ))
	
	RETURN @PageCount

END
------------------End of ThanhNguyen-------------------------


-- Alter stored procedure [dbo].[CWX_Product_GetDynamicFields]
/****** Object:  StoredProcedure [dbo].[CWX_Product_GetDynamicFields]    Script Date: 04/17/2009 09:44:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 17 Mar 2009
-- Description:	Get dynamic fields and data of an client
-- History:
--	[17 Mar 2009]	Minh Dam	Init version.
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Product_GetDynamicFields]
	-- Add the parameters for the stored procedure here
	@ClientID int,
	@TabID int = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			b.[DataType],
			b.[MaxLength],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as SQLDropDown,
			ISNULL(c.Listed, 0) as Listed
			
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], [DisplayOrder], [DropDown], [RangeID]
		FROM CWX_ClientInformation_Dict
		WHERE Displayed = 1	AND TabID = @TabID
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'ClientInformation' AND [Type]='U')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000)
	DECLARE @FieldName varchar(50)
	SET @FieldNameList = 'ClientID,ClientName,Priority,AgingForReschedule,AgingForDiscount,RescheduleAllowed,DiscountAllowed,LetterheadImage,CreditorID,PaymentAllocationRuleID,AgingForApportion,ApportionAllowed' --ClientActive

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(1000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM ClientInformation WHERE ClientID = ' + Cast(@ClientID as varchar)
	
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

	DECLARE @PageCount int
	SELECT @PageCount = MAX(PageNumber) 
	FROM CWX_AccountInformation_Dict 
	WHERE Displayed = 1 AND (@ClientID = 0 OR ISNULL(Client,0) = 0 OR Client = @ClientID)

	RETURN @PageCount
END


-- Create stored procedure [dbo].[CWX_Product_GetByEmployee]
/****** Object:  StoredProcedure [dbo].[CWX_Product_GetByEmployee]    Script Date: 04/17/2009 09:51:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_GetByEmployee]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Product_GetByEmployee]    Script Date: 04/17/2009 09:52:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 15 Apr 2009
-- Description:	Get clients of an employee 
--				if @EmployeeID = 0 or this employee hasn't assigned any clients then load all clients,
--				otherwise get clients of that employee						
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Product_GetByEmployee]
	-- Add the parameters for the stored procedure here
	@EmployeeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @sql nvarchar(1000)
	DECLARE @param nvarchar(100)
	SET @param = '@EmployeeID int'

	SET @sql = 	'SELECT * FROM ClientInformation WHERE [Status] <> ''R'''
	IF (@EmployeeID > 0 AND EXISTS (SELECT 1 FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID))
		SET @sql = @sql + ' AND ClientID IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID)'

	SET @sql = @sql + ' ORDER BY ClientName'
	Exec sp_executesql @sql, @param, @EmployeeID
END
GO


-- Alter stored procedure [dbo].[CWX_ClientInformation_GetAssignedClients]
/****** Object:  StoredProcedure [dbo].[CWX_ClientInformation_GetAssignedClients]    Script Date: 04/16/2009 11:01:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 10 Apr 2009
-- Description:	Get assigned clients of an employee
-- History:
--	[2009/04/10]	Thanh Nguyen	Init version.
--	[2009/04/16]	Minh Dam		Add parameter "@ReportTo"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_ClientInformation_GetAssignedClients]
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@ReportTo int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	WITH ReportToClientList AS
	(
		SELECT * FROM dbo.CWX_AssignedClientIDTable(@ReportTo)
	)
	
	SELECT ClientID, ClientName
	FROM ClientInformation
	WHERE [Status] <> 'R'		
		AND ClientID IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID)
		AND ClientID IN (SELECT ClientID FROM ReportToClientList)
	ORDER BY ClientName
END
GO


-- Alter stored proceudre [dbo].[CWX_ClientInformation_GetAvailableClients]
/****** Object:  StoredProcedure [dbo].[CWX_ClientInformation_GetAvailableClients]    Script Date: 04/16/2009 13:32:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thanh Nguyen
-- Create date: 10 Apr 2009
-- Description:	Get assigned clients of an employee
-- History:
--	[2009/04/10]	Thanh Nguyen	Init version.
--	[2009/04/16]	Minh Dam		Add parameter "@ReportTo"
-- =============================================
ALTER PROCEDURE [dbo].[CWX_ClientInformation_GetAvailableClients]
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@ReportTo int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	WITH ReportToClientList AS
	(
		SELECT * FROM dbo.CWX_AssignedClientIDTable(@ReportTo)
	)

	SELECT ClientID, ClientName
	FROM ClientInformation
	WHERE [Status] <> 'R'
		AND ClientID NOT IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID)
		AND ClientID IN (SELECT ClientID FROM ReportToClientList)
	ORDER BY ClientName
END
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'CosigneeInformation' AND COLUMN_NAME = 'Relationship_no')
BEGIN
	ALTER TABLE CosigneeInformation
	ALTER COLUMN [Relationship_no] [varchar](50) NULL
END
GO




