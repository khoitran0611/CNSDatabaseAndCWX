﻿-- Create procedure [CWX_Commission_GetSystemStatusRates]
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Commission_GetSystemStatusRates]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[CWX_Commission_GetSystemStatusRates]
GO

CREATE PROCEDURE [dbo].[CWX_Commission_GetSystemStatusRates]
	@ClientCommPlanID int, 	
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT *
	FROM (
		SELECT	ROW_NUMBER() OVER (ORDER BY sr.ID) AS RowNumber,
				sr.ClientCommPlanID, sr.SystemStatusID, sr.RatePercent, sr.FixedAmount,
				sr.Minimum, sr.Maximum, sr.Status, sr.CreatedBy, sr.CreatedDate, sr.UpdatedBy,
				sr.UpdatedDate, a.ShortDesc as SystemStatusDesc
		FROM	CWX_ClientSystemStatusRates as sr
				INNER JOIN AccountStatus as a ON sr.SystemStatusID = a.AgencyStatus		
		WHERE	(sr.ClientCommPlanID = @ClientCommPlanID) AND sr.Status = 'A'
	) b
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DECLARE @rowCount int
	SELECT @rowCount = count(*)
	FROM	CWX_ClientSystemStatusRates sr
	INNER JOIN AccountStatus a ON sr.SystemStatusID = a.AgencyStatus		
	WHERE	(sr.ClientCommPlanID = @ClientCommPlanID) AND sr.Status = 'A'

	RETURN @rowCount
END
GO


-- Create procedure [CWX_Commission_GetSystemTransactionRates]
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Commission_GetSystemTransactionRates]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[CWX_Commission_GetSystemTransactionRates]
GO

CREATE PROCEDURE [dbo].[CWX_Commission_GetSystemTransactionRates]
	@ClientCommPlanID int, 	
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT *
	FROM (
		SELECT	ROW_NUMBER() OVER (ORDER BY tr.ID) AS RowNumber,
				tr.ClientCommPlanID, tr.FinancialTypeID, tr.TransactionTypeID,
				tr.RatePercent, tr.FixedAmount, tr.Minimum, tr.Maximum, tr.Status,
				tr.CreatedBy, tr.CreatedDate, tr.UpdatedBy, tr.UpdatedDate,
				t.Description as TransactionTypeDesc, f.Description as FinancialTypeDesc
		FROM	CWX_ClientTransactionTypeRates as tr
				LEFT JOIN TransactionType as t ON tr.TransactionTypeID = t.ID
				LEFT JOIN dbo.CWX_FinancialType as f on tr.FinancialTypeID = f.FinancialTypeID
		WHERE	tr.ClientCommPlanID = @ClientCommPlanID
				AND tr.Status = 'A'
	) b
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DECLARE @rowCount int
	SELECT @rowCount = count(*)
	FROM	CWX_ClientTransactionTypeRates as tr
				LEFT JOIN TransactionType as t ON tr.TransactionTypeID = t.ID
				LEFT JOIN dbo.CWX_FinancialType as f on tr.FinancialTypeID = f.FinancialTypeID
		WHERE	tr.ClientCommPlanID = @ClientCommPlanID
				AND tr.Status = 'A'

	RETURN @rowCount
END
GO


-- Add column AllowDuplicateKey to CWX_CDL_ImportDestTable_Dict table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_CDL_ImportDestTable_Dict' AND COLUMN_NAME = 'AllowDuplicateKey')
BEGIN
	ALTER TABLE [dbo].[CWX_CDL_ImportDestTable_Dict] 
		ADD AllowDuplicateKey bit not null default 0
END
GO


-- Create procedure [CWX_CDL_SourceMapTemplate_CheckAllowDuplicateKey]
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SourceMapTemplate_CheckAllowDuplicateKey]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[CWX_CDL_SourceMapTemplate_CheckAllowDuplicateKey]
GO

CREATE PROCEDURE [dbo].[CWX_CDL_SourceMapTemplate_CheckAllowDuplicateKey]
	@TemplateID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @allowDuplicateKey bit    
	SELECT @allowDuplicateKey = ISNULL(AllowDuplicateKey,0)
	FROM CWX_CDL_ImportDestTable_Dict a
	WHERE EXISTS ( SELECT 1 FROM CWX_CDL_SourceMapTemplate b
					WHERE b.TemplateID = @TemplateID
						AND b.Status <> 'R'
						AND b.DestDatabase = a.DatabaseID 
						AND b.DestTable = a.TableName)

	SELECT Isnull(@allowDuplicateKey,0)
END
GO


-- Add column [DateFormat] to [CWX_CDL_ImportSource] table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_CDL_ImportSource' AND COLUMN_NAME = 'DateFormat')
BEGIN
	ALTER TABLE [dbo].[CWX_CDL_ImportSource] 
		ADD [DateFormat] varchar(50) not null default 'MM/dd/yyyy'
END
GO

-- Add column KeyColumnID to CWX_CDL_SourceMapTemplate table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_CDL_SourceMapTemplate' AND COLUMN_NAME = 'KeyColumnID')
BEGIN
	ALTER TABLE [dbo].[CWX_CDL_SourceMapTemplate] 
		ADD KeyColumnID bit null
END
GO

-- Add column SequenceOrder to CWX_CDL_SourceMapDetails table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_CDL_SourceMapDetails' AND COLUMN_NAME = 'SequenceOrder')
BEGIN
	ALTER TABLE [dbo].[CWX_CDL_SourceMapDetails] 
		ADD SequenceOrder bit null
END
GO

-- Reorder columns of CWX_CDL_ImportSource table
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO

IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_ImportSource_Fixed]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_ImportSource
	DROP CONSTRAINT DF_CWX_ImportSource_Fixed
GO
IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_ImportSource_FirstLineContainsLabels]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_ImportSource
	DROP CONSTRAINT DF_CWX_ImportSource_FirstLineContainsLabels
GO
IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_ImportSource_Type]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_ImportSource
	DROP CONSTRAINT DF_CWX_ImportSource_Type
GO

IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_CDL_ImportSource_NumberOfGeneratedColumns]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_ImportSource
	DROP CONSTRAINT DF_CWX_CDL_ImportSource_NumberOfGeneratedColumns
GO

IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF__CWX_CDL_I__DateF__23AAD175]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_ImportSource
	DROP CONSTRAINT DF__CWX_CDL_I__DateF__23AAD175
GO

IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_ImportSource_Status]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_ImportSource
	DROP CONSTRAINT DF_CWX_ImportSource_Status
GO

IF(EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'Tmp_CWX_CDL_ImportSource') and type in (N'U')))
	DROP TABLE Tmp_CWX_CDL_ImportSource
GO

CREATE TABLE dbo.Tmp_CWX_CDL_ImportSource
	(
	SourceID int NOT NULL IDENTITY (1, 1),
	ClientID int NOT NULL,
	[Name] nvarchar(50) NOT NULL,
	[Description] nvarchar(100) NULL,
	Fixed bit NOT NULL,
	FieldDelimiter varchar(20) NULL,
	RecordDelimiter varchar(20) NULL,
	FirstLineContainsLabels bit NOT NULL,
	Type tinyint NOT NULL,
	AutoGeneratedColumns int NULL,
	EnforceTotalColumnsInTemplate bit NULL,
	DateFormat varchar(50) NOT NULL,
	CreatedBy int NOT NULL,
	CreatedDate datetime NOT NULL,
	UpdatedBy int NULL,
	UpdatedDate datetime NULL,
	Status char(1) NOT NULL
	)  ON [PRIMARY]
GO

ALTER TABLE dbo.Tmp_CWX_CDL_ImportSource ADD CONSTRAINT
	DF_CWX_ImportSource_Fixed DEFAULT ((0)) FOR Fixed
GO

ALTER TABLE dbo.Tmp_CWX_CDL_ImportSource ADD CONSTRAINT
	DF_CWX_ImportSource_FirstLineContainsLabels DEFAULT ((0)) FOR FirstLineContainsLabels
GO

ALTER TABLE dbo.Tmp_CWX_CDL_ImportSource ADD CONSTRAINT
	DF_CWX_ImportSource_Type DEFAULT ((0)) FOR Type
GO

ALTER TABLE dbo.Tmp_CWX_CDL_ImportSource ADD CONSTRAINT
	DF_CWX_CDL_ImportSource_NumberOfGeneratedColumns DEFAULT ((0)) FOR AutoGeneratedColumns
GO

ALTER TABLE dbo.Tmp_CWX_CDL_ImportSource ADD CONSTRAINT
	DF__CWX_CDL_I__DateF__23AAD175 DEFAULT ('MM/dd/yyyy') FOR DateFormat
GO

ALTER TABLE dbo.Tmp_CWX_CDL_ImportSource ADD CONSTRAINT
	DF_CWX_ImportSource_Status DEFAULT ('A') FOR Status
GO

SET IDENTITY_INSERT dbo.Tmp_CWX_CDL_ImportSource ON
GO

IF EXISTS(SELECT * FROM dbo.CWX_CDL_ImportSource)
	 EXEC('INSERT INTO dbo.Tmp_CWX_CDL_ImportSource (SourceID, ClientID, Name, Description, Fixed, FieldDelimiter, RecordDelimiter, FirstLineContainsLabels, Type, AutoGeneratedColumns, EnforceTotalColumnsInTemplate, DateFormat, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, Status)
		SELECT SourceID, ClientID, Name, Description, Fixed, FieldDelimiter, RecordDelimiter, FirstLineContainsLabels, Type, AutoGeneratedColumns, EnforceTotalColumnsInTemplate, DateFormat, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, Status FROM dbo.CWX_CDL_ImportSource WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_CWX_CDL_ImportSource OFF
GO
DROP TABLE dbo.CWX_CDL_ImportSource
GO
EXECUTE sp_rename N'dbo.Tmp_CWX_CDL_ImportSource', N'CWX_CDL_ImportSource', 'OBJECT' 
GO

ALTER TABLE dbo.CWX_CDL_ImportSource ADD CONSTRAINT
	PK_CWX_ImportSource PRIMARY KEY CLUSTERED 
	(
	SourceID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO

COMMIT
GO


-- Reorder columns of CWX_CDL_SourceMapTemplate table
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO

IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_SourceMapTemplates_Active]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_SourceMapTemplate
	DROP CONSTRAINT DF_CWX_SourceMapTemplates_Active
GO
IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_SourceMapTemplate_Unicode]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_SourceMapTemplate
	DROP CONSTRAINT DF_CWX_SourceMapTemplate_Unicode
GO
IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_SourceMapTemplate_LocaleID]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_SourceMapTemplate
	DROP CONSTRAINT DF_CWX_SourceMapTemplate_LocaleID
GO
IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_SourceMapTemplate_CodeBaseID]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_SourceMapTemplate
	DROP CONSTRAINT DF_CWX_SourceMapTemplate_CodeBaseID
GO
IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_SourceMapTemplate_Status]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_SourceMapTemplate
	DROP CONSTRAINT DF_CWX_SourceMapTemplate_Status
GO

IF(EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'Tmp_CWX_CDL_SourceMapTemplate') and type in (N'U')))
	DROP TABLE Tmp_CWX_CDL_SourceMapTemplate
GO

CREATE TABLE dbo.Tmp_CWX_CDL_SourceMapTemplate
	(
	TemplateID int NOT NULL IDENTITY (1, 1),
	SourceID int NOT NULL,
	Description nvarchar(100) NULL,
	DestDatabase tinyint NOT NULL,
	DestTable varchar(200) NULL,
	KeyColumnID int NULL,
	Active bit NULL,
	Unicode bit NULL,
	LocaleID int NOT NULL,
	CodeBaseID int NOT NULL,
	CreatedBy int NULL,
	CreatedDate datetime NULL,
	UpdatedBy int NULL,
	UpdatedDate datetime NULL,
	Status char(1) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_CWX_CDL_SourceMapTemplate ADD CONSTRAINT
	DF_CWX_SourceMapTemplates_Active DEFAULT ((0)) FOR Active
GO
ALTER TABLE dbo.Tmp_CWX_CDL_SourceMapTemplate ADD CONSTRAINT
	DF_CWX_SourceMapTemplate_Unicode DEFAULT ((0)) FOR Unicode
GO
ALTER TABLE dbo.Tmp_CWX_CDL_SourceMapTemplate ADD CONSTRAINT
	DF_CWX_SourceMapTemplate_LocaleID DEFAULT ((0)) FOR LocaleID
GO
ALTER TABLE dbo.Tmp_CWX_CDL_SourceMapTemplate ADD CONSTRAINT
	DF_CWX_SourceMapTemplate_CodeBaseID DEFAULT ((0)) FOR CodeBaseID
GO
ALTER TABLE dbo.Tmp_CWX_CDL_SourceMapTemplate ADD CONSTRAINT
	DF_CWX_SourceMapTemplate_Status DEFAULT ('A') FOR Status
GO
SET IDENTITY_INSERT dbo.Tmp_CWX_CDL_SourceMapTemplate ON
GO
IF EXISTS(SELECT * FROM dbo.CWX_CDL_SourceMapTemplate)
	 EXEC('INSERT INTO dbo.Tmp_CWX_CDL_SourceMapTemplate (TemplateID, SourceID, Description, DestDatabase, DestTable, KeyColumnID, Active, Unicode, LocaleID, CodeBaseID, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, Status)
		SELECT TemplateID, SourceID, Description, DestDatabase, DestTable, KeyColumnID, Active, Unicode, LocaleID, CodeBaseID, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, Status FROM dbo.CWX_CDL_SourceMapTemplate WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_CWX_CDL_SourceMapTemplate OFF
GO
DROP TABLE dbo.CWX_CDL_SourceMapTemplate
GO
EXECUTE sp_rename N'dbo.Tmp_CWX_CDL_SourceMapTemplate', N'CWX_CDL_SourceMapTemplate', 'OBJECT' 
GO
ALTER TABLE dbo.CWX_CDL_SourceMapTemplate ADD CONSTRAINT
	PK_CWX_ImportTemplates PRIMARY KEY CLUSTERED 
	(
	TemplateID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
COMMIT
GO


-- Reorder columns of CWX_CDL_SourceMapDetails
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_CDL_SourceMapDetails_Nullable]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_SourceMapDetails
	DROP CONSTRAINT DF_CWX_CDL_SourceMapDetails_Nullable
GO
IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_CDL_SourceMapDetails_SystemDefined]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_SourceMapDetails
	DROP CONSTRAINT DF_CWX_CDL_SourceMapDetails_SystemDefined
GO
IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_CDL_SourceMapDetails_ColumnWidth]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_SourceMapDetails
	DROP CONSTRAINT DF_CWX_CDL_SourceMapDetails_ColumnWidth
GO
IF(EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[DF_CWX_CDL_SourceMapDetails_Status]') and Type in (N'D')))
ALTER TABLE dbo.CWX_CDL_SourceMapDetails
	DROP CONSTRAINT DF_CWX_CDL_SourceMapDetails_Status
GO

IF(EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'Tmp_CWX_CDL_SourceMapDetails') and type in (N'U')))
	DROP TABLE Tmp_CWX_CDL_SourceMapDetails
GO	
CREATE TABLE dbo.Tmp_CWX_CDL_SourceMapDetails
	(
	ID int NOT NULL IDENTITY (1, 1),
	TemplateID int NOT NULL,
	SourceCol varchar(50) NOT NULL,
	DestField varchar(50) NULL,
	StartPosition int NULL,
	EndPosition int NULL,
	FieldType tinyint NULL,
	Length int NULL,
	Validation varchar(200) NULL,
	IsDerived bit NULL,
	DerivedFrom varchar(200) NULL,
	DateFormat varchar(50) NULL,
	ColCollation varchar(50) NULL,
	AllowsNull bit NULL,
	IsSystemDefined bit NULL,
	SequenceOrder int NULL,
	ColumnWidth int NOT NULL,
	DefaultValue nvarchar(50) NULL,
	HostFieldName varchar(50) NULL,
	HostFieldDescription nvarchar(200) NULL,
	CreatedBy int NOT NULL,
	CreatedDate datetime NOT NULL,
	UpdatedBy int NULL,
	UpdatedDate datetime NULL,
	Status char(1) NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_CWX_CDL_SourceMapDetails ADD CONSTRAINT
	DF_CWX_CDL_SourceMapDetails_Nullable DEFAULT ((1)) FOR AllowsNull
GO
ALTER TABLE dbo.Tmp_CWX_CDL_SourceMapDetails ADD CONSTRAINT
	DF_CWX_CDL_SourceMapDetails_SystemDefined DEFAULT ((0)) FOR IsSystemDefined
GO
ALTER TABLE dbo.Tmp_CWX_CDL_SourceMapDetails ADD CONSTRAINT
	DF_CWX_CDL_SourceMapDetails_ColumnWidth DEFAULT ((0)) FOR ColumnWidth
GO
ALTER TABLE dbo.Tmp_CWX_CDL_SourceMapDetails ADD CONSTRAINT
	DF_CWX_CDL_SourceMapDetails_Status DEFAULT ('A') FOR Status
GO
SET IDENTITY_INSERT dbo.Tmp_CWX_CDL_SourceMapDetails ON
GO
IF EXISTS(SELECT * FROM dbo.CWX_CDL_SourceMapDetails)
	 EXEC('INSERT INTO dbo.Tmp_CWX_CDL_SourceMapDetails (ID, TemplateID, SourceCol, DestField, StartPosition, EndPosition, FieldType, Length, Validation, IsDerived, DerivedFrom, DateFormat, ColCollation, AllowsNull, IsSystemDefined, SequenceOrder, ColumnWidth, DefaultValue, HostFieldName, HostFieldDescription, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, Status)
		SELECT ID, TemplateID, SourceCol, DestField, StartPosition, EndPosition, FieldType, Length, Validation, IsDerived, DerivedFrom, DateFormat, ColCollation, AllowsNull, IsSystemDefined, SequenceOrder, ColumnWidth, DefaultValue, HostFieldName, HostFieldDescription, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, Status FROM dbo.CWX_CDL_SourceMapDetails WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_CWX_CDL_SourceMapDetails OFF
GO
DROP TABLE dbo.CWX_CDL_SourceMapDetails
GO
EXECUTE sp_rename N'dbo.Tmp_CWX_CDL_SourceMapDetails', N'CWX_CDL_SourceMapDetails', 'OBJECT' 
GO
ALTER TABLE dbo.CWX_CDL_SourceMapDetails ADD CONSTRAINT
	PK_CWX_ImportTemplateDetails PRIMARY KEY CLUSTERED 
	(
	ID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
COMMIT
GO


-- [21-Oct-2009] [Minh Dam] Remove column 'SetupTo' from CWX_ClientCommModel table
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientCommModel' AND COLUMN_NAME = 'SetupTo')
BEGIN
	ALTER TABLE CWX_ClientCommModel
		DROP COLUMN SetupTo
END


-- [21-Oct-2009] [Minh Dam] Remove column 'FinancialTypeID' from CWX_ClientCommModel table
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientCommModel' AND COLUMN_NAME = 'FinancialTypeID')
BEGIN
	ALTER TABLE CWX_ClientCommModel
		DROP COLUMN FinancialTypeID
END


-- [21-Oct-2009] [Minh Dam] Remove column 'TransactionTypeID' from CWX_ClientCommModel table
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientCommModel' AND COLUMN_NAME = 'TransactionTypeID')
BEGIN
	ALTER TABLE CWX_ClientCommModel
		DROP COLUMN TransactionTypeID
END


-- [21-Oct-2009] [Minh Dam] Remove column 'SystemStatusID' from CWX_ClientCommModel table
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientCommModel' AND COLUMN_NAME = 'SystemStatusID')
BEGIN
	ALTER TABLE CWX_ClientCommModel
		DROP COLUMN SystemStatusID
END


-- [21-Oct-2009] [Minh Dam] Add BillClientOtherCharges column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'BillClientOtherCharges')
BEGIN
	ALTER TABLE CWX_ClientProperties
		ADD BillClientOtherCharges bit NULL

	ALTER TABLE CWX_ClientPropertiesLog
		ADD BillClientOtherCharges bit NULL		
END
GO


-- [21-Oct-2009] [Minh Dam] Add AutoInterest column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'AutoInterest')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD AutoInterest bit NULL
	    
	ALTER TABLE CWX_ClientPropertiesLog
	    ADD AutoInterest bit NULL	    
END
GO


-- [21-Oct-2009] [Minh Dam] Add InterestDefaultRate column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'InterestDefaultRate')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD InterestDefaultRate money NULL
	    
	ALTER TABLE CWX_ClientPropertiesLog
	    ADD InterestDefaultRate money NULL
END
GO


-- [21-Oct-2009] [Minh Dam] Add InterestDays column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'InterestDays')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD InterestDays int NULL

	ALTER TABLE CWX_ClientPropertiesLog
	    ADD InterestDays int NULL
END
GO


-- [21-Oct-2009] [Minh Dam] Add ReportToCreditBureau column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'ReportToCreditBureau')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD ReportToCreditBureau bit NULL
	    
	ALTER TABLE CWX_ClientPropertiesLog
	    ADD ReportToCreditBureau bit NULL
END
GO


-- [21-Oct-2009] [Minh Dam] Add ReportAfter column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'ReportAfter')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD ReportAfter int NULL

	ALTER TABLE CWX_ClientPropertiesLog
	    ADD ReportAfter int NULL
END
GO


-- [21-Oct-2009] [Minh Dam] Add LetterCharge column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'LetterCharge')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD LetterCharge money NULL

	ALTER TABLE CWX_ClientPropertiesLog
	    ADD LetterCharge money NULL
END
GO


-- [21-Oct-2009] [Minh Dam] Add Overpayments column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'Overpayments')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD Overpayments int NULL
	    
	ALTER TABLE CWX_ClientPropertiesLog
	    ADD Overpayments int NULL
END
GO


-- [21-Oct-2009] [Minh Dam] Add MinSettlementAmt column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'MinSettlementAmt')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD MinSettlementAmt int NULL
	    
	ALTER TABLE CWX_ClientPropertiesLog
	    ADD MinSettlementAmt int NULL
END
GO


-- [21-Oct-2009] [Minh Dam] Add CollectorDiscount column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'CollectorDiscount')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD CollectorDiscount money NULL

	ALTER TABLE CWX_ClientPropertiesLog
	    ADD CollectorDiscount money NULL
END
GO


-- [21-Oct-2009] [Minh Dam] Add CollectorDiscountAfterDays column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'CollectorDiscountAfterDays')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD CollectorDiscountAfterDays int NULL

	ALTER TABLE CWX_ClientPropertiesLog
	    ADD CollectorDiscountAfterDays int NULL
END
GO


-- [21-Oct-2009] [Minh Dam] Add CollectorDiscountAfterDays column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'CollectorDiscountAfterDays')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD CollectorDiscountAfterDays int NULL

	ALTER TABLE CWX_ClientPropertiesLog
	    ADD CollectorDiscountAfterDays int NULL
END
GO


-- [21-Oct-2009] [Minh Dam] Add SupervisorDiscount column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'SupervisorDiscount')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD SupervisorDiscount int NULL
	    
	ALTER TABLE CWX_ClientPropertiesLog
	    ADD SupervisorDiscount int NULL
END
GO


-- [21-Oct-2009] [Minh Dam] Add SupervisorDiscountAfterDays column to CWX_ClientProperties table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientProperties' AND COLUMN_NAME = 'SupervisorDiscountAfterDays')
BEGIN
	ALTER TABLE CWX_ClientProperties
	    ADD SupervisorDiscountAfterDays int NULL

	ALTER TABLE CWX_ClientPropertiesLog
	    ADD SupervisorDiscountAfterDays int NULL
END
GO


-- [21-Oct-2009] [Minh Dam] Add 'CommCalType' column to CWX_ClientCommPlan table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientCommPlan' AND COLUMN_NAME = 'CommCalType')
BEGIN
	ALTER TABLE CWX_ClientCommPlan
	    ADD CommCalType tinyint NOT NULL DEFAULT (1)
END
GO


-- [21-Oct-2009] [Minh Dam] Create CWX_ClientCommission table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommission]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_ClientCommission](
		[RecordID] [int] IDENTITY(1,1) NOT NULL,
		[TransactionID] [int] NOT NULL,
		[AccountID] [int] NOT NULL,
		[EmployeeID] [int] NOT NULL,
		[PaymentAmount] [money] NOT NULL,
		[ClientPart] [money] NULL,
		[AgencyPart] [money] NULL,
		[CollectorPart] [money] NULL,
		[CommissionAmount] [money] NULL,
		[TaxAmount] [money] NULL,
		[RatePercent] [decimal](19, 5) NULL,
		[FixedAmount] [money] NULL,
		[MinAmount] [money] NULL,
		[MaxAmount] [money] NULL,
		[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientCommissions_Status]  DEFAULT ('A'),
	 CONSTRAINT [PK_CWX_ClientCommission] PRIMARY KEY CLUSTERED 
	(
		[RecordID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO


-- [21-Oct-2009] [Minh Dam] Create 'CWX_ClientSystemStatusRates' table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientSystemStatusRates]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_ClientSystemStatusRates](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[ClientCommPlanID] [int] NOT NULL,
		[SystemStatusID] [int] NOT NULL,
		[RatePercent] [decimal](19, 5) NULL,
		[FixedAmount] [money] NULL,
		[Minimum] [money] NULL,
		[Maximum] [money] NULL,		
		[CreatedBy] [int] NOT NULL,
		[CreatedDate] [datetime] NOT NULL,
		[UpdatedBy] [int] NULL,
		[UpdatedDate] [datetime] NULL,
		[Status] [char](1) NOT NULL
		 CONSTRAINT [PK_CWX_ClientSystemStatusRates] PRIMARY KEY CLUSTERED 
		(
			[ID] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO


-- [21-Oct-2009] [Minh Dam] Create 'CWX_ClientTransactionTypeRates' table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientTransactionTypeRates]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_ClientTransactionTypeRates](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[ClientCommPlanID] [int] NOT NULL,
		[FinancialTypeID] [int] NOT NULL,
		[TransactionTypeID] [int] NULL,
		[RatePercent] [decimal](19, 5) NULL,
		[FixedAmount] [money] NULL,
		[Minimum] [money] NULL,
		[Maximum] [money] NULL,
		[Status] [char](1) NOT NULL,
		[CreatedBy] [int] NOT NULL,
		[CreatedDate] [datetime] NOT NULL,
		[UpdatedBy] [int] NULL,
		[UpdatedDate] [datetime] NULL,
	 CONSTRAINT [PK_CWX_ClientTransactionTypeRates] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO


-- [21-Oct-2009] [Minh Dam] Create procdure CWX_ClientCommission_GetPagingList
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_GetPagingList]    Script Date: 10/21/2009 16:59:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommission_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommission_GetPagingList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_GetPagingList]    Script Date: 10/21/2009 16:59:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 15 Oct, 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommission_GetPagingList]
	@ClientID int,
	@TransDateFrom datetime,
	@TransDateTo datetime,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Insert statements for procedure here
	DECLARE @rowCount int
	
	SELECT @rowCount = COUNT(*)
	FROM CWX_ClientCommission
	WHERE TransactionID IN (SELECT	TransactionID
							FROM Transactions
							WHERE AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID)
								AND DATEDIFF(day, @TransDateFrom, DateOfTransaction) >= 0
								AND DATEDIFF(day, DateOfTransaction, @TransDateTo) >= 0)
		AND [Status] <> 'R'


	WITH temp AS
	(
		SELECT ROW_NUMBER() OVER(ORDER BY TransactionID) AS RowNumber,
				a.RecordID, a.TransactionID, a.AccountID, a.PaymentAmount,
				a.ClientPart, a.AgencyPart, a.CommissionAmount, a.TaxAmount, a.RatePercent,
				ISNULL(b.InvoiceNumber,'') AS AccountNumber
		FROM CWX_ClientCommission a
			LEFT JOIN Account b ON a.AccountID = b.AccountID
		WHERE a.TransactionID IN  (	SELECT	TransactionID
									FROM Transactions
									WHERE AccountID IN (SELECT AccountID FROM Account WHERE ClientID = @ClientID)
										AND DATEDIFF(day, @TransDateFrom, DateOfTransaction) >= 0
										AND DATEDIFF(day, DateOfTransaction, @TransDateTo) >= 0)
			AND a.[Status] <> 'R'
	)

	SELECT * 
	FROM temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @rowCount
END
GO


-- [21-Oct-2009] [Minh Dam] Create procdure [CWX_ClientCommPlanRule_GetAccountIDsByRule]
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanRule_GetAccountIDsByRule]    Script Date: 10/21/2009 17:01:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommPlanRule_GetAccountIDsByRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommPlanRule_GetAccountIDsByRule]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommPlanRule_GetAccountIDsByRule]    Script Date: 10/21/2009 17:02:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 20 Oct, 2009
-- Description:	Gets list of account IDs by commission plan rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommPlanRule_GetAccountIDsByRule] 
(
	@CommPlanRuleID int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	--Step 1: Populate the main SELECT command.
    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat, Combining
		FROM CWX_ClientCommPlanCriteria
		WHERE ClientCommPlanRuleID = @CommPlanRuleID

	DECLARE @SQLFormat varchar(700)
	DECLARE @Combining varchar(10)
	DECLARE @NeedCombining varchar(10)
	DECLARE @WhereClause varchar(2000)
	DECLARE @IsOpenningBracket bit
	SET @NeedCombining = 'And'
	SET @WhereClause = ''
	SET @IsOpenningBracket = 0

	OPEN RuleCriteriaCrsr
	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF (LOWER(@Combining) = 'or')
			IF (@IsOpenningBracket = 0)
			BEGIN
				SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' (' + @SQLFormat
				SET @IsOpenningBracket = 1
			END
			ELSE
				SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' ' + @SQLFormat
		ELSE
		BEGIN
			SET @WhereClause = @WhereClause + ' ' + @NeedCombining + ' ' + @SQLFormat			
			IF (@IsOpenningBracket = 1)
			BEGIN
				SET @WhereClause = @WhereClause + ') '
				SET @IsOpenningBracket = 0
			END
		END

		SET @NeedCombining = @Combining /* remember previous value */
		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	END

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr


	DECLARE @Sql nvarchar(max)
	SET @Sql = ' SELECT DISTINCT '
				+ cast(@CommPlanRuleID as varchar(10)) + ' AS PlanRuleID,'
				+ ' Account.AccountId'
				+ ' FROM Account'
				+ ' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID'
				+ ' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID'
				+ ' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID'
				+ ' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID'
				+ ' WHERE 1=1'
				--+ ' AND (PersonAddress.MailingAddress = 1)'
				+ ' AND Account.AgencyStatusID <> 2'-- Donot show closed account
				+ @WhereClause

	--Step 2: Execute the main SQL command.
	EXEC sp_executesql @Sql
	
END
GO


-- [21-Oct-2009] [Minh Dam] 
IF NOT EXISTS (SELECT 1 FROM CWX_ClientPropertySettings WHERE Type = 4 AND Value='Based on Commission Amount')
BEGIN
	INSERT INTO CWX_ClientPropertySettings(Type, Value)
	VALUES (4, 'Based on Commission Amount')
END


-- [21-Oct-2009] [Minh Dam] Create procedure [CWX_ClientCommission_CalculateCommissionByCommRate]
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_CalculateCommissionByCommRate]    Script Date: 10/21/2009 17:10:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommission_CalculateCommissionByCommRate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionByCommRate]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_CalculateCommissionByCommRate]    Script Date: 10/21/2009 17:10:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 07 Oct, 2009
-- Description:	Calculate commission and tax for each client by commission rate
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionByCommRate]
	@ClientID int,
	@TransDateFrom datetime,
	@TransDateTo datetime,
	@Recalculate bit = 0,
	@CalculatedDate datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	DECLARE @result tinyint
	DECLARE @commModel_ModelType tinyint, @commModel_CommRateID int
	DECLARE @commModel_CommPlanID int, @commModel_Minimum money, @commModel_Maximum money

	-- Get commission model info. of the client
	SELECT	@commModel_ModelType = ModelType,
			@commModel_CommRateID = ClientCommRateID,
			@commModel_CommPlanID = ClientCommPlanID,
			@commModel_Minimum = Minimum,
			@commModel_Maximum = Maximum
	FROM CWX_ClientCommModel 
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'

	
	-- Get commission rate info.
	DECLARE @commRate_ID int, @commRate_StartDate datetime, @commRate_EndDate datetime
	DECLARE @commRate_RateType int, @commRate_RateAmount money	
	SELECT	@commRate_ID = ID,
			@commRate_StartDate = StartDate,
			@commRate_EndDate = EndDate,
			@commRate_RateType = RateType,
			@commRate_RateAmount = RateAmount
	FROM CWX_ClientCommRate
	WHERE ID = @commModel_CommRateID


	-- Get the client properties info
	DECLARE @properties_TaxExempt bit, @properties_AddCommissionToOwing bit		
	SELECT  @properties_TaxExempt = TaxExempt,
			@properties_AddCommissionToOwing = AddCommissionToOwing
	FROM CWX_ClientProperties
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Get the client tax info.
	DECLARE @tax_TaxType int, @tax_TaxRate decimal(19,5), @tax_CalculateTax bit, @tax_TaxTypeValue nvarchar(50)
	SELECT	@tax_TaxType = TaxType,
			@tax_TaxRate = TaxRate,
			@tax_CalculateTax = CalculateTax,
			@tax_TaxTypeValue = ISNULL(b.Value, '')
	FROM CWX_ClientTax a
		LEFT JOIN CWX_ClientPropertySettings b ON a.TaxType = b.ID
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Retrieve suitable transactions of accounts of client
	DECLARE curTrans CURSOR FOR
		SELECT	TransactionID, AccountID, EmployeeID, 
				DateOfTransaction, TransactionAmount
		FROM Transactions
		WHERE ClientID = @ClientID
			AND DATEDIFF(day, @TransDateFrom, DateOfTransaction) >= 0
			AND DATEDIFF(day, DateOfTransaction, @TransDateTo) >= 0
			AND TransactionType = 901 -- Receive Payment
			AND ReversedFlag = 0
			AND ISNULL(ParentTransactionID, 0) = 0
			AND (@Recalculate = 1 OR TransactionID NOT IN (SELECT TransactionID FROM CWX_ClientCommission WHERE [Status] <> 'R'))


	DECLARE @transactionID int, @accountID int, @employeeID int, @dateOfTransaction datetime, @transactionAmount money
	DECLARE @commissionAmount money, @taxAmount money
	DECLARE @commRateAmount money -- used to store rate percent or rate amount
	DECLARE @rateSlab_Minimum money, @rateSlab_Maximum money
	DECLARE @commAmountMinimum money, @commAmountMaximum money
	DECLARE @clientPart money, @agencyPart money, @collectorPart money
	
	BEGIN TRAN
	BEGIN TRY
		-- Go thru each transaction record to calculate commission and tax
		OPEN curTrans
		FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
										@dateOfTransaction, @transactionAmount
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			-- CALCULATE COMMISSION BASE ON RATE TYPE
			SET @commRateAmount = 0
			SET @commAmountMinimum = @commModel_Minimum
			SET @commAmountMaximum = @commModel_Maximum

			-- Check if the transaction date is valid for this commission rate.
			IF (DATEDIFF(day, @commRate_StartDate, @dateOfTransaction) >= 0)
				AND (@commRate_EndDate IS NULL OR DATEDIFF(day, @dateOfTransaction, @commRate_EndDate) >= 0)
			BEGIN
				IF @commRate_RateType IN (1,3) -- Flat Rate or Flat Amount
					SET @commRateAmount = @commRate_RateAmount	
				ELSE IF @commRate_RateType IN (2, 4) -- Tiered Rate or Tiered Amount
				BEGIN
					SEt @rateSlab_Minimum = NULL; SET @rateSlab_Maximum =  NULL
					SELECT TOP 1 @commRateAmount = RateAmount,
								@rateSlab_Minimum = Minimum,
								@rateSlab_Maximum = Maximum							
					FROM CWX_ClientCommRateSlab
					WHERE ClientCommRateID = @commRate_ID
						AND @transactionAmount BETWEEN FromValue AND ToValue
				END

				IF @commRate_RateType IN (1,2) -- Flat Rate or Tiered Rate					
				BEGIN
					IF (@properties_AddCommissionToOwing = 1)
						SET @commissionAmount = @transactionAmount * (@commRateAmount/100) / (1 + @commRateAmount/100)
					ELSE
						SET @commissionAmount = @transactionAmount * @commRateAmount/100
				END
				ELSE
				BEGIN
					SET @commissionAmount = @commRateAmount
				END

				-- Check the min and max for commssion amount
				IF @commRate_RateType IN (2,4)
				BEGIN
					IF @rateSlab_Minimum IS NOT NULL
						SET @commAmountMinimum = @rateSlab_Minimum

					IF @rateSlab_Maximum IS NOT NULL
						SET @commAmountMaximum = @rateSlab_Maximum
				END
				
				-- Adjust commission amount base on min and max
				IF @commissionAmount < @commAmountMinimum
					SET @commissionAmount = @commAmountMinimum

				IF @commissionAmount > @commAmountMaximum
					SET @commissionAmount = @commAmountMaximum

			END
			ELSE -- The rate is no more valid, set commision amount to minimum value of model
				SET @commissionAmount = @commModel_Minimum


			-- Calculate ClientPart, AgencyPart, CollectorPart amount
			SET @clientPart = @transactionAmount - @commissionAmount
			SET @agencyPart = @commissionAmount
			SET @collectorPart = 0


			-- CALCULATE TAX BASE ON COMMISSION
			SET @taxAmount = 0
			IF (@tax_CalculateTax = 1 AND @properties_TaxExempt = 0)
			BEGIN
				IF (@tax_TaxTypeValue LIKE '%Commission Amount%')
					SET @taxAmount = @commissionAmount * @tax_TaxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Payment Amount%')
					SET @taxAmount = @transactionAmount * @tax_TaxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Agency Part%')
					SET @taxAmount = @agencyPart * @tax_TaxRate/100
			END
		
			-- Delete children transactions of this transaction
			DELETE CWX_ClientCommission
			WHERE TransactionID IN (SELECT TransactionID FROM Transactions WHERE ParentTransactionID = @transactionID)
			
			--Mark delete current transantions were computed
			UPDATE CWX_ClientCommission SET [Status] = 'R' WHERE TransactionID = @transactionID AND [Status] <> 'R'			
			
			-- Insert or Update commission data into CWX_ClientCommission table
			IF NOT EXISTS (SELECT 1 FROM CWX_ClientCommission WHERE TransactionID = @transactionID AND [Status] <> 'R')
				INSERT INTO CWX_ClientCommission (
						TransactionID, 
						AccountID, 
						EmployeeID, 
						PaymentAmount, 
						ClientPart, 
						AgencyPart, 
						CollectorPart, 
						CommissionAmount,
						TaxAmount, 
						RatePercent,
						FixedAmount,
						MinAmount,
						MaxAmount)
				VALUES (
						@transactionID, 
						@accountID, 
						@employeeID, 
						@transactionAmount, 
						@clientPart, 
						@agencyPart, 
						@collectorPart, 
						@commissionAmount, 
						@taxAmount, 
						CASE @commRate_RateType WHEN 1 THEN @commRateAmount WHEN 2 THEN @commRateAmount ELSE NULL END,
						CASE @commRate_RateType WHEN 3 THEN @commRateAmount WHEN 4 THEN @commRateAmount ELSE NULL END,
						@commAmountMinimum,
						@commAmountMaximum)
			--ELSE
			--	UPDATE CWX_ClientCommission 
			--	SET		AccountID = @accountID, 
			--			EmployeeID = @employeeID, 
			--			PaymentAmount = @transactionAmount, 
			--			ClientPart = @clientPart, 
			--			AgencyPart = @agencyPart,
			--			CollectorPart = @collectorPart, 
			--			CommissionAmount = @commissionAmount,
			--			TaxAmount = @taxAmount, 
			--			RatePercent = CASE @commRate_RateType WHEN 1 THEN @commRateAmount WHEN 2 THEN @commRateAmount ELSE NULL END,
			--			FixedAmount = CASE @commRate_RateType WHEN 3 THEN @commRateAmount WHEN 4 THEN @commRateAmount ELSE NULL END,
			--			MinAmount = @commAmountMinimum,
			--			MaxAmount = @commAmountMaximum
			--	WHERE	TransactionID = @transactionID
			--		AND [Status] <> 'R'


			-- Retrieve next record to calculate
			FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
											@dateOfTransaction, @transactionAmount											
		END

		COMMIT TRAN
		SET @result = 1
	END TRY
	-- Catch exception
	BEGIN CATCH
		ROLLBACK TRAN
		SET @result = 0
	END CATCH

	IF (CURSOR_STATUS('global', 'curTrans') >= 0)
	BEGIN
		CLOSE curTrans		
	END
	DEALLOCATE curTrans

	RETURN @result
END
GO


-- [21-Oct-2009] [Minh Dam] Create procedure [CWX_ClientCommission_CalculateCommissionByCommRate]
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_CalculateCommissionByRuleRate]    Script Date: 10/21/2009 17:11:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommission_CalculateCommissionByRuleRate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionByRuleRate]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_CalculateCommissionByRuleRate]    Script Date: 10/21/2009 17:11:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 20 Oct, 2009
-- Description:	Calculate commission and tax for each client 
--				by commission plan with commission plan rule rates
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionByRuleRate]
	@ClientID int,
	@TransDateFrom datetime,
	@TransDateTo datetime,
	@Recalculate bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @result tinyint
	DECLARE @commModel_ModelType tinyint, @commModel_CommRateID int
	DECLARE @commModel_CommPlanID int, @commModel_Minimum money, @commModel_Maximum money

	-- Get commission model info. of the client
	SELECT	@commModel_ModelType = ModelType,
			@commModel_CommRateID = ClientCommRateID,
			@commModel_CommPlanID = ClientCommPlanID,
			@commModel_Minimum = Minimum,
			@commModel_Maximum = Maximum
	FROM CWX_ClientCommModel 
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Get the client properties info
	DECLARE @properties_TaxExempt bit, @properties_AddCommissionToOwing bit		
	SELECT  @properties_TaxExempt = TaxExempt,
			@properties_AddCommissionToOwing = AddCommissionToOwing
	FROM CWX_ClientProperties
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Get the client tax info.
	DECLARE @tax_TaxType int, @tax_TaxRate decimal(19,5), @tax_CalculateTax bit, @tax_TaxTypeValue nvarchar(50)
	SELECT	@tax_TaxType = TaxType,
			@tax_TaxRate = TaxRate,
			@tax_CalculateTax = CalculateTax,
			@tax_TaxTypeValue = ISNULL(b.Value, '')
	FROM CWX_ClientTax a
		LEFT JOIN CWX_ClientPropertySettings b ON a.TaxType = b.ID
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Retrieve suitable transactions of accounts of client
	DECLARE curTrans CURSOR FOR
		SELECT	TransactionID, AccountID, EmployeeID,
				DateOfTransaction, ABS(TransactionAmount) AS TransactionAmount
		FROM Transactions
		WHERE ClientID = @ClientID
			AND DATEDIFF(day, @TransDateFrom, DateOfTransaction) >= 0
			AND DATEDIFF(day, DateOfTransaction, @TransDateTo) >= 0
			AND TransactionType = 901 -- Receive Payment
			AND ReversedFlag = 0
			AND ISNULL(ParentTransactionID, 0) = 0
			AND (@Recalculate = 1 OR TransactionID NOT IN (SELECT TransactionID FROM CWX_ClientCommission WHERE [Status] <> 'R'))
			AND AccountID IN (SELECT AccountID FROM Account WHERE AgencyStatusID <> 2 AND SystemStatusID <> 2) -- exclude Closed Accounts


	-- BEGIN Get account id list base on each comm plan rule
	CREATE TABLE #CommPlanRuleTemp (
		PlanRuleID int,
		AccountID int,		
		RatePercent decimal(19,5), 
		FixedAmount money, 
		Minimum money,
		Maximum money,
		[Order] int IDENTITY(1,1)
	)
	
	DECLARE @planRule_ID int, @planRule_RatePercent decimal(19,5), @planRule_FixedAmount money
	DECLARE @planRule_Minimum money, @planRule_Maximum money
	DECLARE @accountIDs varchar(max)

	DECLARE curCommPlanRule CURSOR FOR
		SELECT ID, RatePercent, FixedAmount, Minimum, Maximum
		FROM CWX_ClientCommPlanRule
		WHERE ClientCommPlanID = @commModel_CommPlanID
			--AND [Status] <> 'R'
	OPEN curCommPlanRule
	FETCH NEXT FROM curCommPlanRule INTO @planRule_ID, @planRule_RatePercent, @planRule_FixedAmount,
										 @planRule_Minimum, @planRule_Maximum
	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO #CommPlanRuleTemp(PlanRuleID, AccountID)
			EXEC [CWX_ClientCommPlanRule_GetAccountIDsByRule] @planRule_ID

		UPDATE #CommPlanRuleTemp
		SET RatePercent = @planRule_RatePercent,
			FixedAmount = @planRule_FixedAmount,
			Minimum = @planRule_Minimum,
			Maximum = @planRule_Maximum
		WHERE PlanRuleID = @planRule_ID
		
		FETCH NEXT FROM curCommPlanRule INTO @planRule_ID, @planRule_RatePercent, @planRule_FixedAmount,
											 @planRule_Minimum, @planRule_Maximum
	END

	CLOSE curCommPlanRule
	DEALLOCATE curCommPlanRule
	-- END Get account id list base on each comm plan rule


	DECLARE @transactionID int, @accountID int, @employeeID int, @dateOfTransaction datetime, @transactionAmount money
	DECLARE @commissionAmount money, @taxAmount money, @taxRate decimal(19,5)
	DECLARE @commAmountMinimum money, @commAmountMaximum money
	DECLARE @clientPart money, @agencyPart money, @collectorPart money
	
	BEGIN TRAN
	BEGIN TRY
		-- Go thru each transaction record to calculate commission and tax
		OPEN curTrans
		FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
										@dateOfTransaction, @transactionAmount

		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			SET @commissionAmount = NULL
			SET @clientPart = NULL
			SET @agencyPart = NULL
			SET @collectorPart = NULL

			SET @commAmountMinimum = @commModel_Minimum
			SET @commAmountMaximum = @commModel_Maximum
			
			SET @planRule_RatePercent = NULL 
			SET @planRule_FixedAmount = NULL
			SET @planRule_Minimum = NULL
			SET @planRule_Maximum = NULL
			
			-- Get plan rule rate info.
			SELECT	TOP 1
					@planRule_RatePercent = RatePercent,
					@planRule_FixedAmount = FixedAmount,
					@planRule_Minimum = Minimum,
					@planRule_Maximum = Maximum
			FROM #CommPlanRuleTemp
			WHERE @accountID = AccountID
			ORDER BY [Order]
			

			-- Calculate Commission Amount
			IF @planRule_RatePercent IS NOT NULL -- Rate Percent is prior than Fixed Amount
			BEGIN				
				IF (@properties_AddCommissionToOwing = 1)
					SET @commissionAmount = @transactionAmount * (@planRule_RatePercent/100) / (1 + @planRule_RatePercent/100)
				ELSE
					SET @commissionAmount = @transactionAmount * @planRule_RatePercent/100

				SET @planRule_FixedAmount = NULL
			END				
			ELSE IF @planRule_FixedAmount IS NOT NULL -- Fixed Amount
			BEGIN
				SET @commissionAmount = @planRule_FixedAmount

				SET @planRule_RatePercent = NULL				
			END
			ELSE
			BEGIN
				SET @commissionAmount = 0
			END 

			-- Check the min and max for commssion amount
			IF @planRule_Minimum IS NOT NULL
				SET @commAmountMinimum = @planRule_Minimum

			IF @planRule_Maximum IS NOT NULL
				SET @commAmountMaximum = @planRule_Maximum
			
			-- Adjust commission amount base on min and max
			IF @commissionAmount < @commAmountMinimum
				SET @commissionAmount = @commAmountMinimum

			IF @commissionAmount > @commAmountMaximum
				SET @commissionAmount = @commAmountMaximum


			-- CALCULATE ClientPart, AgencyPart, CollectorPart amount
			SET @clientPart = @transactionAmount - @commissionAmount
			SET @agencyPart = @commissionAmount
			SET @collectorPart = 0


			-- CALCULATE TAX BASE ON COMMISSION
			-- Check CalculateTax property of transaction type
			SET @taxAmount = NULL

			IF @tax_CalculateTax = 1 AND @properties_TaxExempt = 0
			BEGIN
				IF (@tax_TaxTypeValue LIKE '%Commission Amount%')
					SET @taxAmount = @commissionAmount * @tax_TaxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Payment Amount%')
					SET @taxAmount = @transactionAmount * @tax_TaxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Agency Part%')
					SET @taxAmount = @agencyPart * @tax_TaxRate/100
			END
			

			-- Delete children transactions of this transaction
			DELETE CWX_ClientCommission
			WHERE TransactionID IN (SELECT TransactionID FROM Transactions WHERE ParentTransactionID = @transactionID)

			--Mark delete current transantions were computed
			UPDATE CWX_ClientCommission SET [Status] = 'R' WHERE TransactionID = @transactionID AND [Status] <> 'R'			

			-- Insert or Update commission data into CWX_ClientCommission table
			IF NOT EXISTS (SELECT 1 FROM CWX_ClientCommission WHERE TransactionID = @transactionID AND [Status] <> 'R')
				INSERT INTO CWX_ClientCommission (
						TransactionID, 
						AccountID, 
						EmployeeID, 
						PaymentAmount, 
						ClientPart, 
						AgencyPart, 
						CollectorPart, 
						CommissionAmount,
						TaxAmount, 
						RatePercent,
						FixedAmount,
						MinAmount,
						MaxAmount)
				VALUES (
						@transactionID, 
						@accountID, 
						@employeeID, 
						@transactionAmount, 
						@clientPart, 
						@agencyPart, 
						@collectorPart, 
						@commissionAmount, 
						@taxAmount, 
						CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @planRule_RatePercent END,
						CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @planRule_FixedAmount END,
						@commAmountMinimum,
						@commAmountMaximum)
			--ELSE
			--	UPDATE CWX_ClientCommission 
			--	SET		AccountID = @accountID, 
			--			EmployeeID = @employeeID, 
			--			PaymentAmount = @transactionAmount, 
			--			ClientPart = @clientPart, 
			--			AgencyPart = @agencyPart,
			--			CollectorPart = @collectorPart, 
			--			CommissionAmount = @commissionAmount,
			--			TaxAmount = @taxAmount, 
			--			RatePercent = CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @planRule_RatePercent END,
			--			FixedAmount = CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @planRule_FixedAmount END,
			--			MinAmount = @commAmountMinimum,
			--			MaxAmount = @commAmountMaximum
			--	WHERE	TransactionID = @transactionID
			--		AND [Status] <> 'R'


			-- Retrieve next record to calculate
			FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
											@dateOfTransaction, @transactionAmount
		END

		COMMIT TRAN
		SET @result = 1
	END TRY
	-- Catch exception
	BEGIN CATCH
		ROLLBACK TRAN
		SET @result = 0
	END CATCH


	IF (CURSOR_STATUS('global', 'curTrans') >= 0)
	BEGIN
		CLOSE curTrans		
	END
	DEALLOCATE curTrans

	RETURN @result
END
GO


-- [21-Oct-2009] [Minh Dam] Create procedure [CWX_ClientCommission_CalculateCommissionBySystemStatusRate]
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_CalculateCommissionBySystemStatusRate]    Script Date: 10/21/2009 17:11:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommission_CalculateCommissionBySystemStatusRate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionBySystemStatusRate]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_CalculateCommissionBySystemStatusRate]    Script Date: 10/21/2009 17:11:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Phuong Le
-- Create date: 20 Oct, 2009
-- Description:	Calculate commission and tax for each client by system status
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionBySystemStatusRate]
	@ClientID int,
	@TransDateFrom datetime,
	@TransDateTo datetime,
	@Recalculate bit = 0	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	DECLARE @result tinyint	
	DECLARE @commModel_CommPlanID int, @commModel_Minimum money, @commModel_Maximum money
	
	-- Get commission model info. of the client
	SELECT	@commModel_CommPlanID = ClientCommPlanID,
			@commModel_Minimum = Minimum,
			@commModel_Maximum = Maximum
	FROM CWX_ClientCommModel 
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'
	
	-- Get the client properties info
	DECLARE @properties_TaxExempt bit, @properties_AddCommissionToOwing bit		
	SELECT  @properties_TaxExempt = TaxExempt,
			@properties_AddCommissionToOwing = AddCommissionToOwing
	FROM CWX_ClientProperties
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'

	-- Get the client tax info.
	DECLARE @tax_TaxType int, @tax_TaxRate decimal(19,5), @tax_CalculateTax bit, @tax_TaxTypeValue nvarchar(50)
	SELECT	@tax_TaxType = TaxType,
			@tax_TaxRate = TaxRate,
			@tax_CalculateTax = CalculateTax,
			@tax_TaxTypeValue = ISNULL(b.Value, '')
	FROM CWX_ClientTax a
		LEFT JOIN CWX_ClientPropertySettings b ON a.TaxType = b.ID
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'
	
	--Retrieve suitable transactions of accounts of client
	DECLARE curTrans CURSOR FOR
		SELECT	TransactionID, AccountID, EmployeeID, 
				DateOfTransaction, TransactionAmount
		FROM Transactions
		WHERE ClientID = @ClientID
			AND DATEDIFF(day, @TransDateFrom, DateOfTransaction) >= 0
			AND DATEDIFF(day, DateOfTransaction, @TransDateTo) >= 0
			AND TransactionType = 901 -- Receive Payment
			AND ReversedFlag = 0
			AND ISNULL(ParentTransactionID, 0) = 0 
			AND (@Recalculate = 1 OR TransactionID NOT IN (SELECT TransactionID FROM CWX_ClientCommission WHERE [Status] <> 'R'))

	
	DECLARE @transactionID int, @accountID int, @employeeID int, @dateOfTransaction datetime, @transactionAmount money
	DECLARE @commissionAmount money
	DECLARE @taxAmount money
	DECLARE @StatusRate_RatePercent decimal(19,5)
	DECLARE @StatusRate_FixedAmount money
	DECLARE @StatusRate_Minimum money
	DECLARE @StatusRate_Maximum money	
	DECLARE @commAmountMinimum money, @commAmountMaximum money	
	DECLARE @clientPart money, @agencyPart money, @collectorPart money

	BEGIN TRAN

	BEGIN TRY		
		OPEN curTrans
		FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
										@dateOfTransaction, @transactionAmount
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			SET @commissionAmount = null	
			SET @StatusRate_RatePercent =null
			SET @StatusRate_FixedAmount =null
			SET @StatusRate_Minimum =null
			SET @StatusRate_Maximum =null
			SET @commAmountMinimum = @commModel_Minimum
			SET @commAmountMaximum = @commModel_Maximum
			
			SELECT @StatusRate_RatePercent = r.RatePercent, @StatusRate_FixedAmount= r.FixedAmount,
				@StatusRate_Minimum= r.Minimum, @StatusRate_Maximum = r.Maximum
			FROM CWX_ClientSystemStatusRates r
			INNER JOIN Account a
			ON r.SystemStatusID = a.AgencyStatusID
			WHERE ClientCommPlanID = @commModel_CommPlanID
				AND a.AccountID = @accountID
				AND r.Status <> 'R'
			
			IF @StatusRate_RatePercent IS NOT NULL -- Rate Percent is prior than Fixed Amount
			BEGIN				
				IF  @properties_AddCommissionToOwing = 1
					SET @commissionAmount = @transactionAmount * (@StatusRate_RatePercent/100) / (1 + @StatusRate_RatePercent/100)
				ELSE
					SET @commissionAmount = @transactionAmount * @StatusRate_RatePercent/100

				SET @StatusRate_FixedAmount = NULL
			END				
			ELSE IF @StatusRate_FixedAmount IS NOT NULL -- Fixed Amount
			BEGIN
				SET @commissionAmount = @StatusRate_FixedAmount

				SET @StatusRate_RatePercent = NULL				
			END
			ELSE
			BEGIN
				SET @commissionAmount = 0
			END
		
			-- Check the min and max for commssion amount
			IF @StatusRate_Minimum IS NOT NULL
				SET @commAmountMinimum = @StatusRate_Minimum

			IF @StatusRate_Maximum IS NOT NULL
				SET @commAmountMaximum = @StatusRate_Maximum
			
			-- Adjust commission amount base on min and max
			IF @commissionAmount < @commAmountMinimum
				SET @commissionAmount = @commAmountMinimum

			IF @commissionAmount > @commAmountMaximum
				SET @commissionAmount = @commAmountMaximum
				
			-- CALCULATE ClientPart, AgencyPart, CollectorPart amount
			SET @clientPart = @transactionAmount - @commissionAmount
			SET @agencyPart = @commissionAmount
			SET @collectorPart = 0			
			
			-- CALCULATE TAX BASE ON COMMISSION
			SET @taxAmount = 0
			IF (@tax_CalculateTax = 1 AND @properties_TaxExempt = 0)
			BEGIN
				IF (@tax_TaxTypeValue LIKE '%Commission Amount%')
					SET @taxAmount = @commissionAmount * @tax_TaxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Payment Amount%')
					SET @taxAmount = @transactionAmount * @tax_TaxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Agency Part%')
					SET @taxAmount = @agencyPart * @tax_TaxRate/100
			END

			-- Delete children transactions of this transaction
			DELETE CWX_ClientCommission
			WHERE TransactionID IN (SELECT TransactionID FROM Transactions WHERE ParentTransactionID = @transactionID)

			--Mark delete current transantions were computed
			UPDATE CWX_ClientCommission SET [Status] = 'R' WHERE TransactionID = @transactionID AND [Status] <> 'R'			
			
			-- Insert or Update commission data into CWX_ClientCommission table
			IF NOT EXISTS (SELECT 1 FROM CWX_ClientCommission WHERE TransactionID = @transactionID AND [Status] <> 'R')
				INSERT INTO CWX_ClientCommission (
						TransactionID, 
						AccountID, 
						EmployeeID, 
						PaymentAmount, 
						ClientPart, 
						AgencyPart, 
						CollectorPart, 
						CommissionAmount,
						TaxAmount, 
						RatePercent,
						FixedAmount,
						MinAmount,
						MaxAmount)
				VALUES (
						@transactionID, 
						@accountID, 
						@employeeID, 
						@transactionAmount, 
						@clientPart, 
						@agencyPart, 
						@collectorPart, 
						@commissionAmount, 
						@taxAmount, 
						CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @StatusRate_RatePercent END,
						CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @StatusRate_FixedAmount END,
						@commAmountMinimum,
						@commAmountMaximum)
			--ELSE
			--	UPDATE CWX_ClientCommission 
			--	SET		AccountID = @accountID, 
			--			EmployeeID = @employeeID, 
			--			PaymentAmount = @transactionAmount, 
			--			ClientPart = @clientPart, 
			--			AgencyPart = @agencyPart,
			--			CollectorPart = @collectorPart, 
			--			CommissionAmount = @commissionAmount,
			--			TaxAmount = @taxAmount, 
			--			RatePercent = CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @StatusRate_RatePercent END,
			--			FixedAmount = CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @StatusRate_FixedAmount END,
			--			MinAmount = @commAmountMinimum,
			--			MaxAmount = @commAmountMaximum
			--	WHERE	TransactionID = @transactionID
			--		AND [Status] <> 'R'

			FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
										@dateOfTransaction, @transactionAmount
		END

		COMMIT TRAN
		SET @result = 1
	END TRY
	BEGIN CATCH
		ROLLBACK TRAN
		SET @result = 0
	END CATCH
	

	
	IF (CURSOR_STATUS('global', 'curTrans') >= 0)
	BEGIN		
		CLOSE curTrans		
	END

	DEALLOCATE curTrans

	RETURN @result
END
GO


-- [21-Oct-2009] [Minh Dam] Create procedure [CWX_ClientCommission_CalculateCommissionBySystemStatusRate]
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_CalculateCommissionByTransactionTypeRate]    Script Date: 10/21/2009 17:12:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommission_CalculateCommissionByTransactionTypeRate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionByTransactionTypeRate]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_CalculateCommissionByTransactionTypeRate]    Script Date: 10/21/2009 17:12:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 19 Oct, 2009
-- Description:	Calculate commission and tax for each client 
--				by commission plan with transaction type rates
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionByTransactionTypeRate]
	@ClientID int,
	@TransDateFrom datetime,
	@TransDateTo datetime,
	@Recalculate bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @result tinyint
	DECLARE @commModel_ModelType tinyint, @commModel_CommRateID int
	DECLARE @commModel_CommPlanID int, @commModel_Minimum money, @commModel_Maximum money

	-- Get commission model info. of the client
	SELECT	@commModel_ModelType = ModelType,
			@commModel_CommRateID = ClientCommRateID,
			@commModel_CommPlanID = ClientCommPlanID,
			@commModel_Minimum = Minimum,
			@commModel_Maximum = Maximum
	FROM CWX_ClientCommModel 
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Get the client properties info
	DECLARE @properties_TaxExempt bit, @properties_AddCommissionToOwing bit		
	SELECT  @properties_TaxExempt = TaxExempt,
			@properties_AddCommissionToOwing = AddCommissionToOwing
	FROM CWX_ClientProperties
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Get the client tax info.
	DECLARE @tax_TaxType int, @tax_TaxRate decimal(19,5), @tax_CalculateTax bit, @tax_TaxTypeValue nvarchar(50)
	SELECT	@tax_TaxType = TaxType,
			@tax_TaxRate = TaxRate,
			@tax_CalculateTax = CalculateTax,
			@tax_TaxTypeValue = ISNULL(b.Value, '')
	FROM CWX_ClientTax a
		LEFT JOIN CWX_ClientPropertySettings b ON a.TaxType = b.ID
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Retrieve suitable transactions of accounts of client
	DECLARE curTrans CURSOR FOR
		SELECT	TransactionID, AccountID, EmployeeID,
				DateOfTransaction, ABS(TransactionAmount) AS TransactionAmount, 
				TransactionType, ParentTransactionID
		FROM Transactions
		WHERE ClientID = @ClientID
			AND DATEDIFF(day, @TransDateFrom, DateOfTransaction) >= 0
			AND DATEDIFF(day, DateOfTransaction, @TransDateTo) >= 0
			--AND TransactionType = 901 -- Receive Payment
			AND ReversedFlag = 0
			AND ISNULL(ParentTransactionID, 0) > 0
			AND (@Recalculate = 1 OR TransactionID NOT IN (SELECT TransactionID FROM CWX_ClientCommission WHERE [Status] <> 'R'))


	DECLARE @transactionID int, @accountID int, @employeeID int, @dateOfTransaction datetime, @transactionAmount money
	DECLARE @transactionType int, @parentTransactionID int

	DECLARE @commissionAmount money, @taxAmount money, @taxRate decimal(19,5)
	DECLARE @commAmountMinimum money, @commAmountMaximum money
	DECLARE @clientPart money, @agencyPart money, @collectorPart money
	
	DECLARE @transTypeRate_RatePercent decimal(19,5), @transTypeRate_FixedAmount money
	DECLARE @transTypeRate_Minimum money, @transTypeRate_Maximum money
	
	DECLARE @transTypeProp_CalculateComm bit, @transTypeProp_CalculateTax bit, @transTypeProp_AddToOwing bit

	DECLARE @tranTypeTax_TaxRate decimal(19,5)

	BEGIN TRAN
	BEGIN TRY
		-- Go thru each transaction record to calculate commission and tax
		OPEN curTrans
		FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
										@dateOfTransaction, @transactionAmount, 
										@transactionType, @parentTransactionID

		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			SET @commissionAmount = NULL
			SET @clientPart = NULL
			SET @agencyPart = NULL
			SET @collectorPart = NULL
			SET @transTypeProp_CalculateComm = NULL
			SET @transTypeProp_CalculateTax = NULL
			SET @transTypeProp_AddToOwing = NULL

			-- Get transaction type property info.
			SELECT	@transTypeProp_CalculateComm = CalculateComm,
					@transTypeProp_CalculateTax = CalculateTax,
					@transTypeProp_AddToOwing = AddToOwing
			FROM CWX_ClientTranTypeProperties
			WHERE ClientID = @ClientID
				AND TransactionTypeID = @transactionType
				AND [Status] <> 'R'

			-- Check CalculateComm property of transaction type
			IF 	@transTypeProp_CalculateComm IS NULL OR @transTypeProp_CalculateComm = 1
			BEGIN
				SET @commAmountMinimum = @commModel_Minimum
				SET @commAmountMaximum = @commModel_Maximum
				
				SET @transTypeRate_RatePercent = NULL
				SET @transTypeRate_FixedAmount = NULL
				SET @transTypeRate_Minimum = NULL
				SET @transTypeRate_Maximum = NULL
				
				-- Get transaction type rate info. base on Transaction Type
				SELECT	@transTypeRate_RatePercent = RatePercent,
						@transTypeRate_FixedAmount = FixedAmount,
						@transTypeRate_Minimum = Minimum,
						@transTypeRate_Maximum = Maximum
				FROM CWX_ClientTransactionTypeRates
				WHERE ClientCommPlanID = @commModel_CommPlanID
					AND [Status] <> 'R'
					AND TransactionTypeID = @transactionType

				-- Get transaction type rate info. base on Financial Type
				IF @@ROWCOUNT = 0
					SELECT	@transTypeRate_RatePercent = RatePercent,
							@transTypeRate_FixedAmount = FixedAmount,
							@transTypeRate_Minimum = Minimum,
							@transTypeRate_Maximum = Maximum
					FROM CWX_ClientTransactionTypeRates
					WHERE ClientCommPlanID = @commModel_CommPlanID
						AND [Status] <> 'R'
						AND ISNULL(TransactionTypeID, 0) = 0 
						AND FinancialTypeID IN (SELECT FinancialTypeID 
												FROM TransactionType 
												WHERE ID = @transactionType AND [Status] <> 'R')

				-- Calculate Commission Amount
				IF @transTypeRate_RatePercent IS NOT NULL -- Rate Percent is prior than Fixed Amount
				BEGIN				
					IF (@transTypeProp_AddToOwing IS NULL AND @properties_AddCommissionToOwing = 1)
						OR @transTypeProp_AddToOwing = 1
						SET @commissionAmount = @transactionAmount * (@transTypeRate_RatePercent/100) / (1 + @transTypeRate_RatePercent/100)
					ELSE
						SET @commissionAmount = @transactionAmount * @transTypeRate_RatePercent/100

					SET @transTypeRate_FixedAmount = NULL
				END				
				ELSE IF @transTypeRate_FixedAmount IS NOT NULL -- Fixed Amount
				BEGIN
					SET @commissionAmount = @transTypeRate_FixedAmount

					SET @transTypeRate_RatePercent = NULL				
				END
				ELSE
				BEGIN
					SET @commissionAmount = 0
				END

				-- Check the min and max for commssion amount
				IF @transTypeRate_Minimum IS NOT NULL
					SET @commAmountMinimum = @transTypeRate_Minimum

				IF @transTypeRate_Maximum IS NOT NULL
					SET @commAmountMaximum = @transTypeRate_Maximum
				
				-- Adjust commission amount base on min and max
				IF @commissionAmount < @commAmountMinimum
					SET @commissionAmount = @commAmountMinimum

				IF @commissionAmount > @commAmountMaximum
					SET @commissionAmount = @commAmountMaximum

	
				-- CALCULATE ClientPart, AgencyPart, CollectorPart amount
				SET @clientPart = @transactionAmount - @commissionAmount
				SET @agencyPart = @commissionAmount
				SET @collectorPart = 0

			END


			-- CALCULATE TAX BASE ON COMMISSION
			-- Check CalculateTax property of transaction type
			SET @taxAmount = NULL
			SET @taxRate = @tax_TaxRate

			IF ((@transTypeProp_CalculateTax IS NULL AND @tax_CalculateTax = 1) OR @transTypeProp_CalculateTax = 1)
				AND @properties_TaxExempt = 0
			BEGIN
				-- Get tax rate base on Transaction Type
				SELECT @taxRate = TaxRate
				FROM CWX_ClientTaxTranType
				WHERE ClientID = @ClientID
					AND [Status] <> 'R'
					AND TransactionTypeID = @transactionType

				-- Get tax rate base on Financial Type
				IF @@ROWCOUNT = 0				
					SELECT @taxRate = TaxRate
					FROM CWX_ClientTaxTranType
					WHERE ClientID = @ClientID
						AND [Status] <> 'R'
						AND ISNULL(TransactionTypeID, 0) = 0 
						AND FinancialTypeID IN (SELECT FinancialTypeID 
												FROM TransactionType 
												WHERE ID = @transactionType AND [Status] <> 'R')

				IF (@tax_TaxTypeValue LIKE '%Commission Amount%')
					SET @taxAmount = @commissionAmount * @taxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Payment Amount%')
					SET @taxAmount = @transactionAmount * @taxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Agency Part%')
					SET @taxAmount = @agencyPart * @taxRate/100
			END
			

			-- Delete parent transaction of this transaction
			DELETE CWX_ClientCommission
			WHERE TransactionID = @parentTransactionID

			--Mark delete current transantions were computed
			UPDATE CWX_ClientCommission SET [Status] = 'R' WHERE TransactionID = @transactionID AND [Status] <> 'R'			
			
			-- Insert or Update commission data into CWX_ClientCommission table
			IF NOT EXISTS (SELECT 1 FROM CWX_ClientCommission WHERE TransactionID = @transactionID AND [Status] <> 'R')
				INSERT INTO CWX_ClientCommission (
						TransactionID, 
						AccountID, 
						EmployeeID, 
						PaymentAmount, 
						ClientPart, 
						AgencyPart, 
						CollectorPart, 
						CommissionAmount,
						TaxAmount, 
						RatePercent,
						FixedAmount,
						MinAmount,
						MaxAmount)
				VALUES (
						@transactionID, 
						@accountID, 
						@employeeID, 
						@transactionAmount, 
						@clientPart, 
						@agencyPart, 
						@collectorPart, 
						@commissionAmount, 
						@taxAmount, 
						CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @transTypeRate_RatePercent END,
						CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @transTypeRate_FixedAmount END,
						@commAmountMinimum,
						@commAmountMaximum)
			--ELSE
			--	UPDATE CWX_ClientCommission 
			--	SET		AccountID = @accountID, 
			--			EmployeeID = @employeeID, 
			--			PaymentAmount = @transactionAmount, 
			--			ClientPart = @clientPart, 
			--			AgencyPart = @agencyPart,
			--			CollectorPart = @collectorPart, 
			--			CommissionAmount = @commissionAmount,
			--			TaxAmount = @taxAmount, 
			--			RatePercent = CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @transTypeRate_RatePercent END,
			--			FixedAmount = CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @transTypeRate_FixedAmount END,
			--			MinAmount = @commAmountMinimum,
			--			MaxAmount = @commAmountMaximum
			--	WHERE	TransactionID = @transactionID
			--		AND [Status] <> 'R'


			-- Retrieve next record to calculate
			FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
											@dateOfTransaction, @transactionAmount, 
											@transactionType, @parentTransactionID
		END

		COMMIT TRAN
		SET @result = 1
	END TRY
	-- Catch exception
	BEGIN CATCH
		print ERROR_MESSAGE()
		ROLLBACK TRAN
		SET @result = 0
	END CATCH

	IF (CURSOR_STATUS('global', 'curTrans') >= 0)
	BEGIN
		CLOSE curTrans		
	END
	DEALLOCATE curTrans

	RETURN @result

END
GO


-- [21-Otc-2009] [Minh Dam] Change procedure [CWX_ClientCommission_GetPagingList]
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommModel_GetPagingList]    Script Date: 10/21/2009 17:40:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 25 May 2009
-- Description:	Get list of client commission model with paging
-- =============================================
ALTER PROCEDURE [dbo].[CWX_ClientCommModel_GetPagingList]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @RowCount int

	SELECT @RowCount = Count(*)
	FROM CWX_ClientCommModel a
		INNER JOIN ClientInformation b ON a.ClientID = b.ClientID AND b.Status <> 'R'
	WHERE a.Status <> 'R'

    -- Insert statements for procedure here
	WITH temp AS
	(
		SELECT	ROW_NUMBER() OVER (ORDER BY b.ClientName) as RowNumber,
				a.ID,
				b.ClientID, 
				b.ClientName,
				c.Description as ClientType, 
				a.Code as ModelCode, 
				a.Description as ModelDescription,
				a.IsActive
		FROM CWX_ClientCommModel a
			INNER JOIN ClientInformation b ON a.ClientID = b.ClientID AND b.Status <> 'R'
			LEFT JOIN CWX_ClientType c ON b.ClientTypeID = c.ClientTypeID AND c.Status <> 'R'
		WHERE a.Status <> 'R'
	)

	SELECT ID, ClientID, ClientName, ClientType, ModelCode, ModelDescription, IsActive
	FROM temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] =  7 AND [Value] = 'No Split on Overpayments' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(7,'No Split on Overpayments')
END

GO
IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] =  7 AND [Value] = 'Agency gets overpayments' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(7,'Agency gets overpayments')
END

GO
IF(NOT EXISTS(	SELECT * FROM [CWX_ClientPropertySettings]
				WHERE [Type] =  7 AND [Value] = 'Client gets overpayments' ))
BEGIN
	INSERT INTO [dbo].[CWX_ClientPropertySettings]([Type],[Value])VALUES(7,'Client gets overpayments')
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommission_GetTransactionsWithPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientCommission_GetTransactionsWithPagingList]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Phuong Le
-- Create date: 26 Oct, 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommission_GetTransactionsWithPagingList]
	@ClientID int,
	@TransDateFrom datetime,
	@TransDateTo datetime,
	@GetForTransactionTypePlan bit,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @SQLBuilder nvarchar(max)
	SET @SQLBuilder = 'SELECT ROW_NUMBER() OVER (ORDER BY t.TransactionID) as RowNumber, '
	SET @SQLBuilder = @SQLBuilder + 't.TransactionID, t.DateOfTransaction, t.TransactionAmount, '
	SET @SQLBuilder = @SQLBuilder + 't.TransactionComment, ISNULL(tt.TransactionCode + '' - '' + tt.Description, '''') as TransactionCodeDescription, '
	SET @SQLBuilder = @SQLBuilder + 'ISNULL(e.UserID,'''') as UserID, Case WHEN c.RecordID is null then ''false'' else ''true'' end as Calculated '
	SET @SQLBuilder = @SQLBuilder + 'FROM transactions t '
	SET @SQLBuilder = @SQLBuilder + 'LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID '
	SET @SQLBuilder = @SQLBuilder + 'LEFT JOIN CWX_ClientCommission c ON t.TransactionID = c.TransactionID and c.[status] <> ''R'' '
	SET @SQLBuilder = @SQLBuilder + 'LEFT JOIN Employee e ON e.EmployeeID = t.EmployeeID '
	SET @SQLBuilder = @SQLBuilder + 'WHERE t.ClientID = @ClientID '
	SET @SQLBuilder = @SQLBuilder + 'AND DATEDIFF(day, @TransDateFrom, t.DateOfTransaction) >= 0 '
	SET @SQLBuilder = @SQLBuilder + 'AND DATEDIFF(day, t.DateOfTransaction, @TransDateTo) >= 0 '
	SET @SQLBuilder = @SQLBuilder + 'AND t.ReversedFlag = 0 '

	IF @GetForTransactionTypePlan = 0
	BEGIN
		SET @SQLBuilder = @SQLBuilder + 'AND t.TransactionType = 901 '
		SET @SQLBuilder = @SQLBuilder + 'AND ISNULL(ParentTransactionID, 0) = 0 '
	END
	ELSE
	BEGIN
		SET @SQLBuilder = @SQLBuilder + 'AND ISNULL(ParentTransactionID, 0) > 0 '
	END
	
    -- Insert statements for procedure here
	DECLARE @rowCount int		
	
	DECLARE	@Params nvarchar(2000) 
	SET @Params = '@ClientID int,
		@TransDateFrom datetime,
		@TransDateTo datetime,
		@rowCount int output'
	
	DECLARE @SQLMain nvarchar(max)	
	SET @SQLMain = 'SELECT @rowCount = count(*) FROM ( ' + @SQLBuilder + ') as result'
	exec sp_executesql	@SQLMain , @Params, @ClientID= @ClientID,
															@TransDateFrom = @TransDateFrom,
															@TransDateTo = @TransDateTo,
															@rowCount = @rowCount output
	SET @Params = '@ClientID int,
		@TransDateFrom datetime,
		@TransDateTo datetime,
		@PageIndex int,
		@PageSize int'
	
	SET @SQLMain = 'SELECT * FROM ( ' + @SQLBuilder + ') as result '
	SET @SQLMain = @SQLMain + 'WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize'
	exec sp_executesql	@SQLMain , @Params, @ClientID= @ClientID,
											@TransDateFrom = @TransDateFrom,
											@TransDateTo = @TransDateTo,
											@PageIndex = @PageIndex,
											@PageSize = @PageSize

	RETURN @rowCount
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_Views_GroupByAccountStatus]    Script Date: 10/27/2009 14:36:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 26, 2009
-- Description:	Summary Account info follow format:
--	Status	Total Account		TotalListAmount		TotalBillBalance
--	Active	5					140.000				15365
--	Legal	6					150.000				165.000		
-- =============================================

/****** Object:  StoredProcedure [dbo].[CWX_Views_GroupByAccountStatus]    Script Date: 10/27/2009 14:37:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Views_GroupByAccountStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Views_GroupByAccountStatus]
GO

CREATE PROCEDURE [dbo].[CWX_Views_GroupByAccountStatus]
	@ClientID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	ast.ShortDesc as [Status], count(a.accountID) as TotalAccount, sum(a.BillAmount) as TotalListAmount, 
			sum(a.BillBalance) as TotalBillBalance

	FROM	Account a INNER JOIN AccountStatus ast ON a.AgencyStatusID = ast.AgencyStatus
	WHERE	(a.ClientID = @ClientID OR @ClientID = 0) AND ast.Type IN ('D','S')
	GROUP BY ast.ShortDesc			
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_Views_GroupByFinancialType]    Script Date: 10/27/2009 14:37:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Object:  StoredProcedure [dbo].[CWX_Views_GroupByFinancialType]    Script Date: 10/27/2009 14:38:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Views_GroupByFinancialType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Views_GroupByFinancialType]
GO

CREATE PROCEDURE [dbo].[CWX_Views_GroupByFinancialType]
	@ClientID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	fnct.description ,sum(t.TransactionAmount) as TotalAmount
	FROM	account c INNER JOIN transactions t ON c.accountid = t.accountid
			LEFT JOIN transactiontype tt ON t.transactiontype = tt.id
			LEFT JOIN cwx_financialtype fnct ON tt.financialtypeid = fnct.financialtypeid
	WHERE	(c.clientid = @ClientID OR @ClientID = 0)
	GROUP BY fnct.Description
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_GetInformationForRecordPaging]    Script Date: 10/27/2009 14:40:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_GetInformationForRecordPaging]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleTable_GetInformationForRecordPaging]
GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_GetInformationForRecordPaging]    Script Date: 10/27/2009 14:40:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: 26-October-2009
-- Description:	Get row order of a RuleID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleTable_GetInformationForRecordPaging]
	-- Add the parameters for the stored procedure here	
	@RuleTye int,
	@FilterByClientID int = 0,
	@FilterByRuleID int = 0,
	@FilterByDescription varchar(200) = '',
	@RuleIDToSearch int,
	@TotalRecords int output,
	@RowNumber int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;    	
	SELECT @TotalRecords = count(*)
	FROM RuleTable
	WHERE	RuleType = @RuleTye AND 
			(ClientID = @FilterByClientID OR @FilterByClientID = 0) AND
			(ID = @FilterByRuleID OR @FilterByRuleID = 0)	AND
			([Description] LIKE ('%' + @FilterByDescription + '%'))
	
	SELECT @RowNumber =  a.RowNumber
	FROM ( SELECT ROW_NUMBER() OVER (ORDER BY ID) as RowNumber, * FROM	RuleTable WHERE RuleType = @RuleTye AND 
																		(ClientID = @FilterByClientID OR @FilterByClientID = 0) AND 
																		(ID = @FilterByRuleID OR @FilterByRuleID = 0)	AND
																		([Description] LIKE ('%' + @FilterByDescription + '%'))
																		) a
	WHERE a.ID = @RuleIDToSearch	

	RETURN @TotalRecords
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_GetRuleBySequenceOrder]    Script Date: 10/27/2009 14:41:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_GetRuleBySequenceOrder]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleTable_GetRuleBySequenceOrder]
GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_GetRuleBySequenceOrder]    Script Date: 10/27/2009 14:41:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: 26-October-2009
-- Description:	Get Rule Table by sequence order
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleTable_GetRuleBySequenceOrder]
	-- Add the parameters for the stored procedure here	
	@RuleTyeID int,
	@FilterByClientID int =0,
	@FilterByRuleID int =0,
	@FilterByDescription varchar(200) = '',
	@SequenceOrder int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY ID) as RowNumber,
				*
		FROM	RuleTable
		WHERE	RuleType = @RuleTyeID AND 
				(ClientID = @FilterByClientID OR @FilterByClientID = 0) AND
				(ID = @FilterByRuleID OR @FilterByRuleID = 0)	AND
				([Description] LIKE ('%' + @FilterByDescription + '%'))
	)

	SELECT *
	FROM Temp
	WHERE RowNumber = @SequenceOrder
	ORDER BY ID
END
GO


