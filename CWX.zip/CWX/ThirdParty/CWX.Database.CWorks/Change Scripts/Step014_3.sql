-- Script is applied on version 2.0.3 
/****** Object:  StoredProcedure [dbo].[CWX_AdditionalInfo_Get]    Script Date: 06/26/2008 15:17:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AdditionalInfo_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AdditionalInfo_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AdditionalInfo_Get]    Script Date: 06/26/2008 15:17:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AdditionalInfo_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROC [dbo].[CWX_AdditionalInfo_Get]
	@Name varchar(50),
	@AccountID int,
	@PageSize INT = 10,
	@PageIndex INT = 0
AS

DECLARE @ErrMsg varchar(150)
DECLARE @Sql varchar(2000)
DECLARE @TableName nvarchar(50)
DECLARE @ColumnNames nvarchar(400)

SELECT @TableName = TableName, @ColumnNames = ColumnNames 
	FROM CWX_AdditionalDataDetails WHERE [Name] = @Name

/* check existing of AccountID column in Table */
IF NOT EXISTS (SELECT ''true'' FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.Name = @TableName AND c.Name = ''AccountId'')
BEGIN
	SET @ErrMsg = ''Invalid AccountID column in '' + ISNULL(@TableName, '''') + '' table.''
	RAISERROR (@ErrMsg, 16, 1)
	RETURN
END

/* check existing of column names in table */
DECLARE @Colname varchar(30)
DECLARE ColNameCursor CURSOR FOR
SELECT CAST(SplitedText AS varchar(20)) AS ColumnName
		FROM CWX_FnSplitString(@ColumnNames, '','')

OPEN ColNameCursor
FETCH NEXT FROM ColNameCursor INTO @ColName
SET @ColumnNames = ''''
SET @ColName = RTRIM(LTRIM(@ColName))
WHILE @@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT ''true'' FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.Name = @TableName AND c.Name = @ColName)
	BEGIN
		IF (LEN(@ColumnNames) = 0)
			SET @ColumnNames = @ColName
		ELSE
			SET @ColumnNames = @ColumnNames + '','' + @ColName
	END

	FETCH NEXT FROM ColNameCursor INTO @ColName
	SET @ColName = RTRIM(LTRIM(@ColName))
END
CLOSE ColNameCursor
DEALLOCATE ColNameCursor

/* retrieve data that folowing user settings */
DECLARE @StartRow int, @EndRow int
SET @StartRow = @PageIndex * @PageSize + 1
SET @EndRow = (@PageIndex + 1) * @PageSize

SET @Sql = ''DECLARE @TotalRow int ''
SET @Sql = @Sql + ''SELECT '' + @ColumnNames + '' , ROW_NUMBER() OVER (ORDER BY AccountID) AS RowNumber INTO #RESULT FROM '' + @TableName + '' ''
SET @Sql = @Sql + ''WHERE AccountID='' + STR(@AccountID) + '' ''
SET @Sql = @Sql + ''SET @TotalRow = @@ROWCOUNT ''
SET @Sql = @Sql + ''SELECT '' + @ColumnNames + '' FROM #RESULT WHERE RowNumber BETWEEN '' + STR(@StartRow) + '' AND '' + STR(@EndRow) + '' ''
SET @Sql = @Sql + ''SELECT @TotalRow as [RowCount]''
EXEC(@Sql)
' 
END
GO

-- =======================================================================
-- Author:			Tuan Luong
-- Create date:		Jun 24, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_DebtCauses
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_DebtCauses' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_DebtCauses
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_DebtCauses_RowStatus] DEFAULT 'A'
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_DebtCauses_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Tuan Luong
-- Create date: Jun 23, 2008
-- Description:	Delete all records in Legal_DebtCauses Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_DebtCauses_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_DebtCauses
		SET [Status] = ''R''
		WHERE [Status] = ''A''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_DebtCauses		
	END
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 06/26/2008 16:41:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetListByRule]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 06/26/2008 16:41:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByRule]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'



-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 24, 2008
-- Description:	Retrieve records that match the rulecriterias of a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetListByRule] 
	-- Add the parameters for the stored procedure here
	@RuleID int,
	@PageSize int = 0,
	@PageIndex int = 0,
	@ProcessedAccountIDs varchar(4000) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	Set @orderByClause = '' ORDER BY AccountId''


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = ''WHERE RowIndex BETWEEN '' + CAST(@BeginIndex as varchar(10)) + '' AND '' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = '' ''


	--Step 3: Populate the main SELECT command.
    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat, Combining
		FROM RuleCriteria
		WHERE RuleID = @RuleID

	DECLARE @SQLFormat varchar(700)
	DECLARE @Combining varchar(10)
	DECLARE @NeedCombining varchar(10)
	DECLARE @WhereClause varchar(2000)
	DECLARE @IsOpenningBracket bit
	SET @NeedCombining = ''And''
	SET @WhereClause = ''''
	SET @IsOpenningBracket = 0

	OPEN RuleCriteriaCrsr
	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF (LOWER(@Combining) = ''or'')
			IF (@IsOpenningBracket = 0)
			BEGIN
				SET @WhereClause = @WhereClause + '' '' + @NeedCombining + '' ('' + @SQLFormat
				SET @IsOpenningBracket = 1
			END
			ELSE
				SET @WhereClause = @WhereClause + '' '' + @NeedCombining + '' '' + @SQLFormat
		ELSE
		BEGIN
			SET @WhereClause = @WhereClause + '' '' + @NeedCombining + '' '' + @SQLFormat			
			IF (@IsOpenningBracket = 1)
			BEGIN
				SET @WhereClause = @WhereClause + '') ''
				SET @IsOpenningBracket = 0
			END
		END

		SET @NeedCombining = @Combining /* remember previous value */
		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	END

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr

	--Remove the Account that was processed
	IF @ProcessedAccountIDs IS NOT NULL AND @ProcessedAccountIDs <> ''''
	BEGIN
		SELECT CAST(SplitedText AS int) AS AccountID
		INTO #ProcessedAccountIDs
		FROM CWX_FnSplitString(@ProcessedAccountIDs, ''|'')

		SET @WhereClause = @WhereClause + '' AND Account.AccountId NOT IN (SELECT AccountID FROM #ProcessedAccountIDs)''
	END

	--This is used for AllocationRule, if RuleType=1, append condition <Account.MAINTAINOFFICER = 0>
	/* disable this statement code that was raise by Sathya - June 26 2008
	DECLARE @RuleType tinyint
	SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID
	IF @RuleType = 1
		SET @WhereClause = '' AND Account.MAINTAINOFFICER = 0'' + @WhereClause
	*/

	DECLARE @Sql varchar(8000)
	SET @Sql = '' SELECT''
				+ '' Account.AccountId,Account.DebtorId,PersonInformation.FirstName,PersonInformation.MiddleName,PersonInformation.LastName,Account.BillBalance,Account.BillAmount,Account.InvoiceNumber''
				+ '' FROM Account''
				+ '' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID''
				+ '' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID''
				+ '' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID''
				+ '' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID''
				+ '' WHERE (PersonAddress.MailingAddress = 1)''
				+ '' AND Account.AgencyStatusID <> 2 AND Account.SystemStatusID <> 2''-- Donot show closed account
				+ @WhereClause


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = ''WITH AccountResults AS ''
				   + ''( ''
				   + ''  SELECT *, ROW_NUMBER() OVER ('' + @orderByClause + '') as RowIndex ''
				   + ''  FROM ( ''	
				   + ''          {0}''
				   + ''    ) A ''
				   + '') ''
				   + ''   ''
				   + ''SELECT * ''
				   + ''FROM AccountResults ''
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, ''{0}'', @Sql)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = ''SELECT @RowCountOut=count(*) FROM ( {0} ) A''
    SET @rowCountStmt = REPLACE(@rowCountStmt, ''{0}'', @Sql)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = ''@RowCountOut int OUTPUT''

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END

' 
END
GO
/******  Script Closed. Go next: Step014_4  ******/