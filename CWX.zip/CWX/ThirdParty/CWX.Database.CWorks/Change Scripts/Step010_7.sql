  -- Scripts are applied on version 1.5.7 & 1.6.0
  
  
-- =============================================
-- Author:		Tai Ly
-- Create date: May 08, 1008
-- Description:	Get notes from database
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Notes_GetWithType] 	
	-- Add the parameters for the stored procedure here
	@DebtorID	int,
	@AccountID	int,
	@NoteText	varchar(256) = '',
	@NoteType	varchar(1) = ' ',	
	@Month		int = -1,
	@Day		int = -1,
	@FromDate	datetime = '1753-01-01',
	@ToDate		datetime = '9999-12-31',
	@PageSize	int = 10,
	@PageIndex	int = 0
AS
BEGIN
	Declare @IdentityTableValue int

	DECLARE @TempTableVar table(
		RowNumber		int,
		NoteDateTime	datetime,
		NoteText		varchar(700),
		NoteType		varchar(1),
		UserID			varchar(10)
	);

	Set @IdentityTableValue = (Select FieldValue from IdentityFields where TableName = 'NotesDisplayByAccount')
	IF (@IdentityTableValue <= 0 )
	BEGIN 						
			IF (@IdentityTableValue < 0)
			BEGIN
				Insert into IdentityFields values('NotesDisplayByAccount',0)
			END
			IF (@NoteType = ' ') -- all note type			
			BEGIN						
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN													
						SELECT @NoteText = '%' + @NoteText + '%';											
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate)								
										AND n.NoteText LIKE @NoteText										
					
				END
				ELSE IF @Month = -1	-- no month input
				BEGIN													
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID 
										AND n.NoteText LIKE @NoteText AND																	
										n.NoteDateTime >= DATEADD(day, -1*@Day, GETDATE())  																					
					
				END
				ELSE	-- no day input
				BEGIN													
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID 
										AND n.NoteText LIKE @NoteText AND										
										n.NoteDateTime >= DATEADD(month, -1*@Month, GETDATE())
				END
			END
			ELSE
			BEGIN	-- has note type
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) AND n.NoteText LIKE @NoteText											

				END
				ELSE IF @Month = -1		-- no month input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND n.NoteText LIKE @NoteText AND
										n.NoteDateTime >= DATEADD(day, -1*@Day, GETDATE())
							ORDER BY	n.NoteDateTime DESC, n.NoteID			
				END
				ELSE -- no day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND n.NoteText LIKE @NoteText AND
										n.NoteDateTime >= DATEADD(month, -1*@Month, GETDATE())													
				END
			END
	END	
	ELSE		
	BEGIN
			IF (@NoteType = ' ')	-- no note type			
			BEGIN
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) 
										AND n.NoteText LIKE @NoteText							

				END
				ELSE IF (@Month = -1)	-- no month input
				BEGIN
					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID 
										AND n.NoteText LIKE @NoteText AND
										n.NoteDateTime >= DATEADD(day, -1*@Day, GETDATE())						
					
				END
				ELSE	-- no day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID
										AND n.NoteText LIKE @NoteText AND
										n.NoteDateTime >= DATEADD(month, -1*@Month, GETDATE())														
				END				
			END
			ELSE	-- has note type
			BEGIN
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  AND UPPER(NoteType) = UPPER(@NoteType) 
										AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) AND n.NoteText LIKE @NoteText							
					
				END
				ELSE IF @Month = -1			-- no month input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  AND UPPER(NoteType) = UPPER(@NoteType) 
										AND n.NoteText LIKE @NoteText AND
										n.NoteDateTime >= DATEADD(day, -1*@Day, GETDATE())																	
				END
				ELSE						-- no day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)
										AND n.NoteText LIKE @NoteText AND
										n.NoteDateTime >= DATEADD(month, -1*@Month, GETDATE())					

				END					
			END
	END		

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
	ELSE
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
		WHERE	RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize)		

	RETURN @RowCount

END
go



/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_Get]    Script Date: 05/09/2008 14:42:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TracerInformation_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_Get]    Script Date: 05/09/2008 14:42:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TracerInformation_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Tai Ly
-- Create date: May 7, 2008
-- Description:	Get items tracer information.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TracerInformation_Get]
	-- Add the parameters for the stored procedure here
	@DebtorID	int,
	@AccountID	int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT ROW_NUMBER() OVER (ORDER BY Description) AS RowNumber, ID, Description, Value		
	INTO #Temp
	FROM CWX_CustomDefinedFields
	WHERE AgencyID = 0 AND AccountID = @AccountID AND DebtorID = @DebtorID

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF @PageSize <= 0
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount

END
' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetAmountPromised]    Script Date: 05/09/2008 16:59:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetAmountPromised]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetAmountPromised]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetAmountPromised]    Script Date: 05/09/2008 16:59:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetAmountPromised]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get total outstanding, amount promised, amount remain money of an account.
-- History:
--		2008/05/06	[Binh Truong]	Init version.
--		2008/05/07	[Binh Truong]	Remove Amount Paid information.
--		2008/05/09	[Binh Truong]	Add ISNULL check. 
--									Add try catch to fix Arithmetic overflow error converting expression.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetAmountPromised]
(
	@AccountID int = NULL
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @CurrentAmountPromised decimal(18,2)
	-- DECLARE @AmountPaid decimal(18,2)
	DECLARE @TotalOutstanding decimal(18,2)
	DECLARE @RemainingAccount decimal(18,2)
	DECLARE @ErrorNumber int
	DECLARE @ArithmeticOverflowErrorNumber int
	
	SET @ArithmeticOverflowErrorNumber = 8115 -- Arithmetic overflow error converting expression to data type money
	SET @CurrentAmountPromised = 0
	SET @TotalOutstanding = 0
	SET @RemainingAccount = 0
	
	
	BEGIN TRY
		SELECT	@TotalOutstanding = ISNULL(SUM(BillBalance), 0)
		FROM	Account
		WHERE	(ISNULL(@AccountID, 0) = 0 OR AccountID = @AccountID)
	END TRY
	BEGIN CATCH
		SELECT @ErrorNumber = ERROR_NUMBER()
		IF @ErrorNumber = @ArithmeticOverflowErrorNumber  
			SET @TotalOutstanding = -1
	END CATCH;	
	
	BEGIN TRY
		SELECT	@CurrentAmountPromised = ISNULL(SUM(AmountPromised), 0) - ISNULL(SUM(AmountPaid), 0)
		FROM	AccountPromise
		WHERE	(ISNULL(@AccountID, 0) = 0 OR AccountID = @AccountID) AND
				Status = 0 -- Not due
	END TRY
	BEGIN CATCH
		SELECT @ErrorNumber = ERROR_NUMBER()
		IF @ErrorNumber = @ArithmeticOverflowErrorNumber
			SET @CurrentAmountPromised = -1
	END CATCH;	
	
	
	BEGIN TRY
		SET @RemainingAccount = ISNULL(@TotalOutstanding - @CurrentAmountPromised, 0)
	END TRY
	BEGIN CATCH
		SELECT @ErrorNumber = ERROR_NUMBER()
		IF @ErrorNumber = @ArithmeticOverflowErrorNumber
			SET @RemainingAccount = -1
	END CATCH;	
					
	SELECT	ISNULL(@TotalOutstanding, 0) as TotalOutstanding,
			ISNULL(@CurrentAmountPromised, 0) as CurrentAmountPromised,
			@RemainingAccount as RemainingAmount
	
END' 
END
GO
/******  Script Closed. Go next: Step011_1  ******/