﻿ --  Worklow Stored procedures
 --	 26 February 2009

/****** Object:  StoredProcedure [dbo].[CWX_WF_DefinePaymentAllocationRule]    Script Date: 02/26/2009 18:38:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefinePaymentAllocationRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefinePaymentAllocationRule]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom4Fee]    Script Date: 02/26/2009 18:38:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom4Fee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateCustom4Fee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom5Fee]    Script Date: 02/26/2009 18:38:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom5Fee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateCustom5Fee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineAgentId]    Script Date: 02/26/2009 18:38:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineAgentId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineAgentId]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineSolicitorId]    Script Date: 02/26/2009 18:38:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineSolicitorId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineSolicitorId]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineCaseNumber]    Script Date: 02/26/2009 18:38:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineCaseNumber]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineCaseNumber]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_GetLastGroupStepDetails]    Script Date: 02/26/2009 18:38:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_GetLastGroupStepDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_GetLastGroupStepDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_GetGroupStepDetails]    Script Date: 02/26/2009 18:38:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_GetGroupStepDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_GetGroupStepDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_SUMREQ_External]    Script Date: 02/26/2009 18:38:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_SUMREQ_External]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_SUMREQ_External]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_JUDAPP_External]    Script Date: 02/26/2009 18:38:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_JUDAPP_External]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_JUDAPP_External]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineCourtId]    Script Date: 02/26/2009 18:38:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineCourtId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineCourtId]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateSolicitorFee]    Script Date: 02/26/2009 18:38:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateSolicitorFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateSolicitorFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCourtFee]    Script Date: 02/26/2009 18:38:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCourtFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateCourtFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateServiceFee]    Script Date: 02/26/2009 18:38:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateServiceFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateServiceFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateSearchFee]    Script Date: 02/26/2009 18:38:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateSearchFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateSearchFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_QueueMultipleLetters]    Script Date: 02/26/2009 18:38:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_QueueMultipleLetters]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_QueueMultipleLetters]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateTravelFee]    Script Date: 02/26/2009 18:38:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateTravelFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateTravelFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateLeviFee]    Script Date: 02/26/2009 18:38:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateLeviFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateLeviFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateBookkeepingFee]    Script Date: 02/26/2009 18:38:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateBookkeepingFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateBookkeepingFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateAttemptedServiceFee]    Script Date: 02/26/2009 18:38:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateAttemptedServiceFee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateAttemptedServiceFee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom3Fee]    Script Date: 02/26/2009 18:38:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom3Fee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateCustom3Fee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom2Fee]    Script Date: 02/26/2009 18:38:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom2Fee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateCustom2Fee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom1Fee]    Script Date: 02/26/2009 18:38:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom1Fee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateCustom1Fee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalSummonServed_Add]    Script Date: 02/26/2009 18:38:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalSummonServed_Add]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_LegalSummonServed_Add]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalExamServed_Add]    Script Date: 02/26/2009 18:38:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalExamServed_Add]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_LegalExamServed_Add]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineGroupId]    Script Date: 02/26/2009 18:38:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineGroupId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineGroupId]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_UpdateGroupStepAmount]    Script Date: 02/26/2009 18:38:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_UpdateGroupStepAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_UpdateGroupStepAmount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateDebtAmount]    Script Date: 02/26/2009 18:38:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateDebtAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateDebtAmount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_Validation]    Script Date: 02/26/2009 18:38:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_Validation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_Validation]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineAdditionalFieldValues]    Script Date: 02/26/2009 18:38:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineAdditionalFieldValues]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineAdditionalFieldValues]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineCreditorId]    Script Date: 02/26/2009 18:38:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineCreditorId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineCreditorId]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_UnserviceDefendantList_Get]    Script Date: 02/26/2009 18:38:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_UnserviceDefendantList_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_UnserviceDefendantList_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_UnserviceExamineeList_Get]    Script Date: 02/26/2009 18:38:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_UnserviceExamineeList_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_UnserviceExamineeList_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalExaminee_Get]    Script Date: 02/26/2009 18:38:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalExaminee_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_LegalExaminee_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_ChangeAccountCollector]    Script Date: 02/26/2009 18:38:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_ChangeAccountCollector]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_ChangeAccountCollector]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineAdditionalFieldValues_OLD]    Script Date: 02/26/2009 18:38:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineAdditionalFieldValues_OLD]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineAdditionalFieldValues_OLD]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalDefendant_Get]    Script Date: 02/26/2009 18:38:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalDefendant_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_LegalDefendant_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineStateServiced]    Script Date: 02/26/2009 18:38:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineStateServiced]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineStateServiced]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineGroupCode]    Script Date: 02/26/2009 18:38:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineGroupCode]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineGroupCode]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalDefendantList_Get]    Script Date: 02/26/2009 18:38:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalDefendantList_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_LegalDefendantList_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateInterestAmount_old]    Script Date: 02/26/2009 18:38:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateInterestAmount_old]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateInterestAmount_old]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateInterestAmount]    Script Date: 02/26/2009 18:38:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateInterestAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_CalculateInterestAmount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_EXMREQ_External]    Script Date: 02/26/2009 18:38:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_EXMREQ_External]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_EXMREQ_External]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_WARREQ_External]    Script Date: 02/26/2009 18:38:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_WARREQ_External]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_WARREQ_External]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_EXMORD_External]    Script Date: 02/26/2009 18:38:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_EXMORD_External]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_EXMORD_External]
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefinePaymentAllocationRule]    Script Date: 02/26/2009 18:38:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefinePaymentAllocationRule]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefinePaymentAllocationRule]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    SELECT 2 AS ''Payment Allocation ID''
END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_GetGroupStepDetails]    Script Date: 02/26/2009 18:38:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_GetGroupStepDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_GetGroupStepDetails]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;

    SELECT A.* 
	FROM Legal_GroupSteps A
	INNER JOIN  Legal_Groups B 
		ON A.GroupID = B.GroupID AND B.GroupedAccountID = @AccountID AND B.Status = ''A''
	WHERE GroupStepTypeID = @GroupStepTypeID AND A.Status = ''A''

END

 
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON


/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom5Fee]    Script Date: 02/26/2009 18:38:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom5Fee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateCustom5Fee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	SELECT @Fee = 0
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			SELECT @Fee = 0
		END
	
	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			DECLARE @GroupID INT
	
			SELECT @GroupID=L.GroupID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
			ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

			SELECT @Fee= (G.SolicitorFee+G.ServiceFee+G.SearchFee+G.CourtFee+G.AttemptedFee+G.TravelFee+G.BookKeepingFee+G.LeavyFee+G.CustomFee1+G.CustomFee2+G.CustomFee3+G.CustomFee4+G.CustomFee5) FROM Legal_GroupSteps G INNER JOIN 
					Legal_GroupStepTypes S ON G.GroupStepTypeID=S.GroupStepTypeID
					WHERE S.Code=''SUMSRV'' and G.GroupID=@GroupID

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN
	
			SELECT @GroupID=L.GroupID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
			ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

			SELECT @Fee= (G.StepTotal) FROM Legal_GroupSteps G INNER JOIN 
					Legal_GroupStepTypes S ON G.GroupStepTypeID=S.GroupStepTypeID
					WHERE S.Code=''JUDENT'' and G.GroupID=@GroupID

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

			SELECT @GroupID=L.GroupID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
			ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

			SELECT @Fee= (G.StepTotal) FROM Legal_GroupSteps G INNER JOIN 
					Legal_GroupStepTypes S ON G.GroupStepTypeID=S.GroupStepTypeID
					WHERE S.Code=''JUDENT'' and G.GroupID=@GroupID

		END

	/*************************/
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineSolicitorId]    Script Date: 02/26/2009 18:38:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineSolicitorId]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineSolicitorId]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @GroupID INT
	DECLARE @Grouped INT
    DECLARE @SolicitorID INT

	SELECT @Grouped = GroupedAccountID from Legal_Groups WHERE GroupedAccountID=@Accountid

	IF (@Grouped='''' or @Grouped IS NULL)
	BEGIN

		SELECT @SolicitorID = ISNULL(Long1, 0) FROM AccountOther 
			WHERE AccountID = @AccountID
		
		SELECT ISNULL(@SolicitorID, 0) AS ''SolicitorID''
	END

	ELSE
	BEGIN

		SELECT @GroupID = GroupID from Legal_Groups WHERE GroupedAccountID=@Accountid

		SELECT @SolicitorID= G.SolicitorID FROM Legal_GroupSteps G INNER JOIN 
						Legal_GroupStepTypes S ON G.GroupStepTypeID=S.GroupStepTypeID
						WHERE S.Code=''SUMISS'' and G.GroupID=@GroupID

		SELECT ISNULL(@SolicitorID, 0) AS ''SolicitorID''
	END
END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom4Fee]    Script Date: 02/26/2009 18:38:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom4Fee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateCustom4Fee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	SELECT @Fee = 0
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			SELECT @Fee = 0
		END
	
	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

				DECLARE @GroupID INT
				DECLARE @IntAmount Money

				SELECT @GroupID=L.GroupID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
				ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

				SELECT @Fee= G.IntAmount FROM Legal_GroupSteps G INNER JOIN 
					Legal_GroupStepTypes S ON G.GroupStepTypeID=S.GroupStepTypeID
					WHERE S.Code=''SUMSRV'' and G.GroupID=@GroupID

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN
			SELECT @Fee = 0
		END


	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN
			SELECT @Fee = 0
		END
	/*************************/

	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineCaseNumber]    Script Date: 02/26/2009 18:38:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineCaseNumber]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineCaseNumber]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

--    SELECT ''CASE1'' AS ''Case Number''
	DECLARE @GroupID INT
    DECLARE @casenumber Varchar(30)
		
	SELECT @GroupID=L.GroupID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
	ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

	SELECT @casenumber=G.CaseNumber FROM Legal_GroupSteps G INNER JOIN 
					Legal_GroupStepTypes S ON G.GroupStepTypeID=S.GroupStepTypeID
					WHERE S.Code=''SUMISS'' and G.GroupID=@GroupID

	SELECT ISNULL(@casenumber, 0) AS ''casenumber''

END


/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineAgentId]    Script Date: 02/26/2009 18:38:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineAgentId]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineAgentId]
	@AccountID INT
	
AS
BEGIN
	SET NOCOUNT ON;

		DECLARE @AgentID varchar(10)		
		DECLARE @GroupID INT
    		
	SELECT @GroupID=L.GroupID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
	ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

	
			SELECT @AgentID = '''' FROM Legal_GroupSteps G 
								WHERE  G.GroupID=@GroupID
	
			SELECT @AgentID 
END


/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_GetLastGroupStepDetails]    Script Date: 02/26/2009 18:38:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_GetLastGroupStepDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_GetLastGroupStepDetails]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    SELECT TOP 1 A.* 
	FROM Legal_GroupSteps A
	INNER JOIN  Legal_Groups B 
		ON A.GroupID = B.GroupID AND B.GroupedAccountID = @AccountID AND B.Status = ''A''
	WHERE A.Status = ''A''
	ORDER BY A.CreateDate DESC

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_SUMREQ_External]    Script Date: 02/26/2009 18:38:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_SUMREQ_External]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_SUMREQ_External]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;


	DECLARE @Groupstep VARCHAR(20)
	SELECT @Groupstep= Code FROM Legal_GroupStepTypes Ls INNER JOIN Legal_GroupSteps Lg ON Ls.GroupStepTypeID=@GroupStepTypeID 
	DECLARE @StepTotal money	

	IF @Groupstep =''SUMREQ''
	BEGIN

		-- CASE NUMBER
		DECLARE @NewCaseNumber AS VARCHAR(25);
		SET @NewCaseNumber = '''';

		SELECT TOP 1 @NewCaseNumber =
		CASE 
			WHEN CAST(REPLACE(A.CaseNumber, RIGHT(A.CaseNumber, LEN(A.CaseNumber) - CHARINDEX(''/'',A.CaseNumber, 1) + 1), '''') AS INT) + 1 BETWEEN C.StartingCaseNo AND C.EndingCaseNo
				THEN CAST(CAST(REPLACE(A.CaseNumber, RIGHT(A.CaseNumber, LEN(A.CaseNumber) - CHARINDEX(''/'',A.CaseNumber, 1) + 1), '''') AS INT) + 1 AS VARCHAR) + ''/'' + RIGHT(CAST(DATEPART(YEAR,GETDATE())AS VARCHAR),2)
			WHEN (ISNULL(C.StartingCaseNo,0) > 0 AND ISNULL(C.EndingCaseNo, 0) > 0) AND ISNULL(A.CaseNumber,'''') = ''''
				THEN CAST(C.StartingCaseNo AS VARCHAR) + ''/'' + RIGHT(CAST(DATEPART(YEAR,GETDATE())AS VARCHAR),2)
			ELSE ''''
		END	
		FROM Legal_GroupSteps A
		INNER JOIN Legal_Courts C
			ON A.CourtID = C.CourtID AND (ISNULL(C.StartingCaseNo,0) > 0 AND ISNULL(C.EndingCaseNo, 0) > 0)
		INNER JOIN Legal_Groups D
			ON A.GroupID = D.GroupID AND D.GroupedAccountID = @AccountID
		WHERE ((ISNULL(A.CaseNumber,'''') <> '''' AND A.CaseNumber LIKE ''%/%'') AND 
					ISNUMERIC(REPLACE(A.CaseNumber, RIGHT(A.CaseNumber, LEN(A.CaseNumber) - CHARINDEX(''/'',A.CaseNumber, 1) + 1), ''''))  = 1 )
			OR (ISNULL(C.StartingCaseNo,0) > 0 AND ISNULL(C.EndingCaseNo, 0) > 0)
		ORDER BY CAST(REPLACE(A.CaseNumber, RIGHT(A.CaseNumber, LEN(A.CaseNumber) - CHARINDEX(''/'',A.CaseNumber, 1) + 1), '''') AS INT) DESC

		
		IF @NewCaseNumber <> ''''
			UPDATE Legal_GroupSteps
			SET CaseNumber  = @NewCaseNumber
			WHERE GroupID IN (SELECT GroupID FROM Legal_Groups WHERE GroupedAccountId = @AccountID);

	--Steptotal
	
		DECLARE @GroupID INT 
		SELECT @GroupID = L.GroupID FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
		ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1
				
					
		SELECT @StepTotal= (DebtAmount+IntAmount+SolicitorFee+CourtFee+ServiceFee+AttemptedFee+
						   TravelFee+BookKeepingFee+LeavyFee+SearchFee+CustomFee1+CustomFee2+CustomFee3+CustomFee4+CustomFee5)
						   FROM Legal_GroupSteps L INNER JOIN Legal_Groups lg ON L.GroupID=lg.GroupID
						   WHERE lg.GroupedAccountID=@AccountID and L.GroupID=@GroupID and L.GroupStepTypeID=@GroupStepTypeID
				
		UPDATE Legal_GroupSteps
		SET StepTotal= ISNULL(@StepTotal,0.00)
		WHERE GroupID IN (SELECT GroupID FROM Legal_Groups WHERE GroupedAccountId = @AccountID)

	--Initialise Money2/5/6/7 to 0.0
		UPDATE Accountother
		SET Money2=0.0, Money5=0.0, Money6=0.0, Money7=0.0 where AccountID=@AccountID

							
	END

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineCourtId]    Script Date: 02/26/2009 18:38:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineCourtId]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineCourtId]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;


	DECLARE @GroupID INT
    DECLARE @courtID INT
		
	SELECT @GroupID=L.GroupID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
	ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

	SELECT @courtID= G.CourtID FROM Legal_GroupSteps G INNER JOIN 
					Legal_GroupStepTypes S ON G.GroupStepTypeID=S.GroupStepTypeID
					WHERE S.Code=''SUMISS'' and G.GroupID=@GroupID

	SELECT ISNULL(@CourtID, 0) AS ''CourtID''

		
END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateServiceFee]    Script Date: 02/26/2009 18:38:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateServiceFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateServiceFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;

	Declare @CountIND int
	Declare @CountCMP int
	Declare @CountBUS int
	Declare @StateServiced varchar(30)
    DECLARE @Fee MONEY
	SELECT @Fee = 0			
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

--Find legal types
----Count of Individual
			Select @CountIND = count(*) From Legal_GroupDebtors 
				Where IsInclude = 1 and 
					  LegalTypeID = 4 and
					  GroupID = (Select GroupId from Legal_Groups Where GroupedAccountId=@AccountID)
----Count of Company
			Select @CountCMP = count(*) From Legal_GroupDebtors 
				Where IsInclude = 1 and 
					  LegalTypeID = 3 and
					  GroupID = (Select GroupId from Legal_Groups Where GroupedAccountId=@AccountID)
----Count of Business
			Select @CountBUS = count(*) From Legal_GroupDebtors 
				Where IsInclude = 1 and 
					  LegalTypeID = 2 and
					  GroupID = (Select GroupId from Legal_Groups Where GroupedAccountId=@AccountID)

-- Retrieve state of service
			Select @StateServiced = [StateServiced] From Legal_Groups
				Where GroupedAccountId = @AccountID

--Compute fees based on state of service.
			IF @StateServiced = ''NSW''
			BEGIN
				Select @Fee = @Fee + (@CountIND * 50.00)
				Select @Fee = @Fee + (@CountCMP * 50.00)
				Select @Fee = @Fee + (@CountBUS * 50.00)
			END
			ELSE IF @StateServiced = ''VIC''
			BEGIN
				Select @Fee = @Fee + (@CountIND * 54.00)
				Select @Fee = @Fee + (@CountCMP * 10.00)
				Select @Fee = @Fee + (@CountBUS *  0.00)
			END
			ELSE IF @StateServiced = ''QLD''
			BEGIN
				Select @Fee = @Fee + (@CountIND * 36.50)
				Select @Fee = @Fee + (@CountCMP *  5.00)
				Select @Fee = @Fee + (@CountBUS *  0.00)
			END
			ELSE
			BEGIN
				Select @Fee = @Fee + (@CountIND * 25.00)
				Select @Fee = @Fee + (@CountCMP * 25.00)
				Select @Fee = @Fee + (@CountBUS *  0.00)
			END
		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN
			SELECT @Fee = 0			
		END


	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

--Find legal types
----Count of Individual
			Select @CountIND = count(*) From Legal_GroupDebtors 
				Where IsInclude = 1 and 
					  LegalTypeID = 4 and
					  GroupID = (Select GroupId from Legal_Groups Where GroupedAccountId=@AccountID)
----Count of Company
			Select @CountCMP = count(*) From Legal_GroupDebtors 
				Where IsInclude = 1 and 
					  LegalTypeID = 3 and
					  GroupID = (Select GroupId from Legal_Groups Where GroupedAccountId=@AccountID)
----Count of Business
			Select @CountBUS = count(*) From Legal_GroupDebtors 
				Where IsInclude = 1 and 
					  LegalTypeID = 2 and
					  GroupID = (Select GroupId from Legal_Groups Where GroupedAccountId=@AccountID)

-- Retrieve state of service
			Select @StateServiced = [StateServiced] From Legal_Groups
				Where GroupedAccountId = @AccountID

--Default fees
			SELECT @Fee = 0
--Compute fees based on state of service.
			IF @StateServiced = ''NSW''
			BEGIN
				Select @Fee = @Fee + (@CountIND * 50.00)
				Select @Fee = @Fee + (@CountCMP * 50.00)
				Select @Fee = @Fee + (@CountBUS *  0.00)
			END
			ELSE IF @StateServiced = ''VIC''
			BEGIN
				Select @Fee = @Fee + (@CountIND * 54.00)
				Select @Fee = @Fee + (@CountCMP * 54.00)
				Select @Fee = @Fee + (@CountBUS *  0.00)
			END
			ELSE IF @StateServiced = ''QLD''
			BEGIN
				Select @Fee = @Fee + (@CountIND *  0.00)
				Select @Fee = @Fee + (@CountCMP *  0.00)
				Select @Fee = @Fee + (@CountBUS *  0.00)
			END

		END


	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN
			SELECT @Fee = 0			
		END
	/*************************/
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateSearchFee]    Script Date: 02/26/2009 18:38:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateSearchFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateSearchFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	SELECT @Fee = 0			

	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
-- Retrieve state of service
			Declare @StateServiced varchar(30)
			Select @StateServiced = [StateServiced] From Legal_Groups
				Where GroupedAccountId = @AccountID
--Default fees
			SELECT @Fee = 0
--If VIC, compute fees based on Legal type. 
			IF @StateServiced = ''VIC''
			BEGIN
				Declare @Count int
----If Individual $0.00
				Select @Count = count(*) From Legal_GroupDebtors 
					Where IsInclude = 1 and 
						  LegalTypeID = 4 and
						  GroupID = (Select GroupId from Legal_Groups Where GroupedAccountId=@AccountID)
				Select @Fee = @Fee + (@Count * 0.00)
----If Company $25.00
				Select @Count = count(*) From Legal_GroupDebtors 
					Where IsInclude = 1 and 
						  LegalTypeID = 3 and
						  GroupID = (Select GroupId from Legal_Groups Where GroupedAccountId=@AccountID)
				Select @Fee = @Fee + (@Count * 25.00)
----If Business $20.00
				Select @Count = count(*) From Legal_GroupDebtors 
					Where IsInclude = 1 and 
						  LegalTypeID = 2 and
						  GroupID = (Select GroupId from Legal_Groups Where GroupedAccountId=@AccountID)
				Select @Fee = @Fee + (@Count * 20.00)
			END
		END
	

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN
			SELECT @Fee = 0			
		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN
			SELECT @Fee = 0
		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN
			SELECT @Fee = 0
		END
	/*************************/
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateTravelFee]    Script Date: 02/26/2009 18:38:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateTravelFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateTravelFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	SELECT @Fee = 0

	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			SELECT @Fee = 0
		END
	
	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN
			SELECT @Fee = 0			
		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN
			SELECT @Fee = 0
		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN
			SELECT @Fee = 0
		END
	/*************************/
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateLeviFee]    Script Date: 02/26/2009 18:38:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateLeviFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateLeviFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	SELECT @Fee = 0
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			SELECT @Fee = 0
		END
	
	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN
			SELECT @Fee = 0			
		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN
			SELECT @Fee = 0
		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN
			SELECT @Fee = 0
		END
	/*************************/
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END


/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateBookkeepingFee]    Script Date: 02/26/2009 18:38:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateBookkeepingFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateBookkeepingFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	SELECT @Fee = 0

	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			SELECT @Fee = 0
		END
	
	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN
			SELECT @Fee = 0			
		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN
			SELECT @Fee = 0
		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN
			SELECT @Fee = 0
		END
	/*************************/
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END


/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateAttemptedServiceFee]    Script Date: 02/26/2009 18:38:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateAttemptedServiceFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateAttemptedServiceFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	SELECT @Fee = 0

	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			SELECT @Fee = 0
		END
	
	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN
			SELECT @Fee = 0			
		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN
			SELECT @Fee = 0
		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN
			SELECT @Fee = 0
		END
	/*************************/
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END


/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom3Fee]    Script Date: 02/26/2009 18:38:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom3Fee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateCustom3Fee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	SELECT @Fee = 0
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			SELECT @Fee = 0
		END
	
	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN
			SELECT @Fee = 0			
		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN
			SELECT @Fee = 0
		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN
			SELECT @Fee = 0
		END
	/*************************/
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom2Fee]    Script Date: 02/26/2009 18:38:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom2Fee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateCustom2Fee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	SELECT @Fee = 0

	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			SELECT @Fee = 0
		END
	
	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN
			SELECT @Fee = 0			
		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN
			SELECT @Fee = 0
		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN
			SELECT @Fee = 0
		END
	/*************************/
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalExamServed_Add]    Script Date: 02/26/2009 18:38:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalExamServed_Add]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_LegalExamServed_Add]
	@AccountID INT,
	@GroupDebtorID INT, 
	@IsServed BIT, 
	@ServedDate DATETIME, 
	@ServedBy VARCHAR(100), 
	@Attempts INT
AS
BEGIN
	SET NOCOUNT ON;

	/*** Get group id ***/
	DECLARE @GroupID INT
	SELECT @GroupID = ISNULL(A.GroupID, 0)
	FROM Legal_Groups A 
	WHERE A.GroupedAccountID = @AccountID

	DECLARE @Count INT;
	SELECT @Count = COUNT(*) FROM WF_Legal_ServedExams
	WHERE GroupID = @GroupID AND GroupDebtorID = @GroupDebtorID;

	IF @Count < 1 OR @Count <> null
		BEGIN
			INSERT INTO WF_Legal_ServedExams (GroupID, GroupDebtorID, IsServed, Attempts, ServedDate, ServedBy)
			VALUES (@GroupID, @GroupDebtorID, @IsServed, @Attempts, @ServedDate, @ServedBy);
		END
	ELSE 
		BEGIN
			UPDATE WF_Legal_ServedExams
			SET IsServed = @IsServed, 
				Attempts = @Attempts,
				ServedDate = @ServedDate,
				ServedBy = @ServedBy
			WHERE GroupID = @GroupID AND GroupDebtorID = @GroupDebtorID;
		END
	
	SELECT ServedId FROM WF_Legal_ServedExams
	WHERE GroupID = @GroupID AND GroupDebtorID = @GroupDebtorID;

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalSummonServed_Add]    Script Date: 02/26/2009 18:38:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalSummonServed_Add]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_LegalSummonServed_Add]
	@AccountID INT,
	@GroupDebtorID INT, 
	@IsServed BIT, 
	@ServedDate DATETIME, 
	@ServedBy VARCHAR(100), 
	@Attempts INT
AS
BEGIN
	SET NOCOUNT ON;

	/*** Get group id ***/
	DECLARE @GroupID INT
	SELECT @GroupID = ISNULL(A.GroupID, 0)
	FROM Legal_Groups A 
	WHERE A.GroupedAccountID = @AccountID

	DECLARE @Count INT;
	SELECT @Count = COUNT(*) FROM WF_Legal_ServedSummons
	WHERE GroupID = @GroupID AND GroupDebtorID = @GroupDebtorID;

	IF @Count < 1 OR @Count <> null
		BEGIN
			INSERT INTO WF_Legal_ServedSummons (GroupID, GroupDebtorID, IsServed, Attempts, ServedDate, ServedBy)
			VALUES (@GroupID, @GroupDebtorID, @IsServed, @Attempts, @ServedDate, @ServedBy);
		END
	ELSE 
		BEGIN
			UPDATE WF_Legal_ServedSummons
			SET IsServed = @IsServed, 
				Attempts = @Attempts,
				ServedDate = @ServedDate,
				ServedBy = @ServedBy
			WHERE GroupID = @GroupID AND GroupDebtorID = @GroupDebtorID;
		END
	
	SELECT ServedId FROM WF_Legal_ServedSummons
	WHERE GroupID = @GroupID AND GroupDebtorID = @GroupDebtorID;

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineGroupId]    Script Date: 02/26/2009 18:38:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineGroupId]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineGroupId]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @GroupID INT
	
	SELECT @GroupID = ISNULL(A.GroupID, 0)
	FROM Legal_Groups A 
	WHERE A.GroupedAccountID = @AccountID
	
	SELECT ISNULL(@GroupID, 0) AS ''GroupID''
END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_UpdateGroupStepAmount]    Script Date: 02/26/2009 18:38:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_UpdateGroupStepAmount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_UpdateGroupStepAmount]
	@GroupStepID INT,
	@TransactionTypeID INT,
	@Amount MONEY
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Transaction Type Code
	*************************/
	DECLARE @TransactionCode VARCHAR(25);
	SELECT @TransactionCode = TransactionCode 
	FROM TransactionType
	WHERE [ID] = @TransactionTypeID;
	
	/*************************
	Create UPDATE script base on transaction type code
	*************************/
	DECLARE @Script VARCHAR(500);
	
	SET @Script = ''UPDATE Legal_GroupSteps SET '' 
	SET @Script = @Script + 
		CASE @TransactionCode 
			WHEN ''Debt'' THEN ''[DebtAmount] = ISNULL([DebtAmount],0) + ''
			WHEN ''Intr'' THEN ''[IntAmount] = ISNULL([IntAmount],0) + '' 
			WHEN ''SolF'' THEN ''[SolicitorFee] = ISNULL([SolicitorFee],0) + '' 
			WHEN ''CourtF'' THEN ''[CourtFee] = ISNULL([CourtFee],0) + '' 
			WHEN ''SrvF'' THEN ''[ServiceFee] = ISNULL([ServiceFee],0) + '' 
			WHEN ''ASrvF'' THEN ''[AttemptedFee] = ISNULL([AttemptedFee],0) + '' 
			WHEN ''KmF'' THEN ''[TravelFee] = ISNULL([TravelFee],0) + '' 
			WHEN ''JrnlF'' THEN ''[BookkeepingFee] = ISNULL([BookkeepingFee],0) + '' 
			WHEN ''AcctF'' THEN ''[LevyFee] = ISNULL([LevyFee],0) + '' 
			WHEN ''SrchF'' THEN ''[SearchFee] = ISNULL([SearchFee],0) + '' 
			WHEN ''OthF'' THEN ''[CustomFee1] = ISNULL([CustomFee1],0) + '' 
		END
	SET @Script = @Script + CAST(@Amount AS VARCHAR(32)); 
	SET @Script = @Script + '', [StepTotal] = ISNULL([StepTotal],0) + '' + CAST(@Amount AS VARCHAR(32));
	SET @Script = @Script + '', LastEditDate = GETDATE()'';
	SET @Script = @Script + '' WHERE GroupStepID = '' + CAST(@GroupStepID AS VARCHAR(10));
	
	IF @TransactionCode IN (''Debt'', ''Intr'', ''SolF'', ''CourtF'', ''ASrvF'', ''SrvF'', ''SrchF'', ''JrnlF'', ''AcctF'', ''KmF'', ''OthF'')
		EXEC (@Script);
	
	
END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateSolicitorFee]    Script Date: 02/26/2009 18:38:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateSolicitorFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateSolicitorFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;

	--Retrieve debt amount
		Declare @EdiM Varchar(1)
		Declare @totaljud money
		Declare @sumamount money
		Declare @commdate datetime
		Declare @DebtAmt money
		Declare @DebtAmount money
		Declare @IntAmount money
		Declare @DebtInt money
		Set @DebtAmt = 0.00
		Set @DebtAmount = 0.00
		Set @IntAmount = 0.00
		

	DECLARE @groupID INT
    DECLARE @Fee MONEY
	SELECT @Fee = 100			
	SELECT @groupID FROM Legal_groups WHERE GroupedAccountID=@AccountID
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
		Select @DebtAmount = isnull((Select money2 From AccountOther Where AccountId=@AccountID),0.00)
		Select @IntAmount = isnull((Select money5 From AccountOther Where AccountId=@AccountID),0.00)

		set @DebtInt = @DebtAmount+@IntAmount
		
		-- Retrieve state of service
		Declare @StateServiced varchar(30)
		Select @StateServiced = [StateServiced] From Legal_Groups
			Where GroupedAccountId = @AccountID

		--Retrieve rate amount from rate slab using debt amount - NSW
		Declare @RateAmount money
		Set @RateAmount = 0.00

		IF @StateServiced = ''NSW''
			BEGIN
				Select @RateAmount = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''LC.SLCS'') and
					  @DebtInt >= RangeValue1 and @DebtInt <= RangeValue2
			END
		--Retrieve rate amount from rate slab using debt amount - VIC
			ELSE IF @StateServiced = ''VIC''
			BEGIN
				Select @RateAmount = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MC.SOLC'') and
					  @DebtInt >= RangeValue1 and @DebtInt <= RangeValue2
			END
		--Retrieve rate amount from rate slab using debt amount - QLD
			ELSE IF @StateServiced = ''QLD''
			BEGIN
				Select @RateAmount = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MCRTSOLC'') and
						@DebtInt >= RangeValue1 and @DebtInt <= RangeValue2
			END

			SELECT @Fee = isnull(@RateAmount,0.00)			

		END
	

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN
		
		Set @DebtAmt = 0.00
		Select @DebtAmt = ISNULL((SELECT DebtAmount FROM Legal_groupSteps s INNER JOIN Legal_GroupStepTypes t 
									ON s.GroupStepTypeID=t.GroupStepTypeID WHERE t.Code=''SUMREQ'' AND Groupid=@GroupID) ,0.00)


			-- Retrieve state of service
		Declare @StateServd varchar(30)
		Select @StateServd = [StateServiced] From Legal_Groups
			Where GroupedAccountId = @AccountID

		--Retrieve rate amount from rate slab using debt amount - NSW
		Declare @RateAmt money
		Set @RateAmt = 0.00

		IF @StateServd = ''NSW''
			BEGIN
				Select @RateAmt = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''2JUDATT'') and
					  @DebtAmt >= RangeValue1 and @DebtAmt <= RangeValue2
			END
		--Retrieve rate amount from rate slab using debt amount - VIC
			ELSE IF @StateServd = ''VIC''
			BEGIN
				Select @RateAmount = 0.00
			END
		--Retrieve rate amount from rate slab using debt amount - QLD
			ELSE IF @StateServd = ''QLD''
			BEGIN
				Select @DebtAmount = isnull((Select money2 From AccountOther Where AccountId=@AccountID),0.00)
				Select @IntAmount = isnull((Select money5 From AccountOther Where AccountId=@AccountID),0.00)

				set @DebtInt = @DebtAmount+@IntAmount

				Select @RateAmt = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MCRTJUDG'') and
						@DebtInt >= RangeValue1 and @DebtInt <= RangeValue2
			END

			SELECT @Fee = isnull(@RateAmt,0.00)			

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

		Set @DebtAmt = 0.00
		Select @DebtAmt = isnull((Select money2 From AccountOther Where AccountId=@AccountID),0.00)

			-- Retrieve state of service
		Select @StateServd = [StateServiced] From Legal_Groups
			Where GroupedAccountId = @AccountID

		--Retrieve rate amount from rate slab using debt amount - NSW
		Set @RateAmt = 0.00

		IF @StateServd = ''NSW''
			BEGIN
				Set @RateAmt = 0.00
			END
		--Retrieve rate amount from rate slab using debt amount - VIC
			ELSE IF @StateServd = ''VIC''

			BEGIN
					SELECT @EdiM = ISNULL(L.Value,'''') FROM Legal_CustomFields L INNER JOIN
					Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
					WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID

					--Retrieve steptotal from ''JUDAPP''
					SELECT @totaljud=ISNULL((SELECT StepTotal FROM Legal_groupSteps s INNER JOIN Legal_GroupStepTypes t 
									ON s.GroupStepTypeID=t.GroupStepTypeID WHERE t.Code=''JUDAPP'' AND Groupid=@GroupID) ,0.00)

					--Commence date
					SELECT @commdate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''CmDt'' and T.Code=''JUDAPP''and S.GroupID=@GroupID
		
					--Retrive paymenttransaction
					SELECT @sumamount=  ISNULL(SUM(T.TransactionAmount),0.00) FROM Transactions T 
								   WHERE (T.TransactionType=901 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') 
										AND T.Datetopost between @commdate and getdate() AND T.AccountID=@AccountID
					--calculating debtamount
					SET @DebtAmt=0				
					SELECT @DebtAmt=ISNULL(@totaljud,0.0)-ISNULL(@sumamount,0.0)
				--Non EDI
					IF (@EdiM = '''' or @EdiM IS NULL or @EdiM = ''0'')
					BEGIN

						Select @RateAmt = isnull(RateAmount,0.00) From Legal_RateSlabs
						Where RateID = (Select ID From Legal_Rates Where RateCode = ''MC.SOLS'') and
						@DebtAmt >= RangeValue1 and @DebtAmt <= RangeValue2
					END
				--EDI
					ELSE IF (@EdiM = ''1'')
					BEGIN
						Select @RateAmt = isnull(RateAmount,0.00) From Legal_RateSlabs
						Where RateID = (Select ID From Legal_Rates Where RateCode = ''MC.SOLS'') and
						@DebtAmt >= RangeValue1 and @DebtAmt <= RangeValue2

					END
			
				
			END
		--Retrieve rate amount from rate slab using debt amount - QLD
			ELSE IF @StateServd = ''QLD''
			BEGIN
				--Get Debt and interest 
				Select @DebtAmount = isnull((Select money2 From AccountOther Where AccountId=@AccountID),0.00)
				Select @IntAmount = isnull((Select money5 From AccountOther Where AccountId=@AccountID),0.00)

				set @DebtInt = @DebtAmount+@IntAmount

				Select @RateAmt = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MCRTEHP'') and
					  @DebtInt >= RangeValue1 and @DebtInt <= RangeValue2
			END

			SELECT @Fee = isnull(@RateAmt,0.00)			

		END


	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

		-- Retrieve state of service
		Select @StateServd = [StateServiced] From Legal_Groups
			Where GroupedAccountId = @AccountID

		--Retrieve debt amount
		Set @DebtAmt = 0.00
		Select @DebtAmt = ISNULL((SELECT DebtAmount FROM Legal_groupSteps s INNER JOIN Legal_GroupStepTypes t 
									ON s.GroupStepTypeID=t.GroupStepTypeID WHERE t.Code=''SUMREQ'' AND Groupid=@GroupID) ,0.00)

		--Retrieve rate amount from rate slab using debt amount - NSW
		Set @RateAmt = 0.00

		IF @StateServd = ''NSW''
			BEGIN
				Select @RateAmt = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''2WRITATT'') and
					  @DebtAmt >= RangeValue1 and @DebtAmt <= RangeValue2
			END
		--Retrieve rate amount from rate slab using debt amount - VIC
			ELSE IF @StateServd = ''VIC''
			BEGIN
				SELECT @EdiM = ISNULL(L.Value,'''') FROM Legal_CustomFields L INNER JOIN
					Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
				WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID
		 
				--Retrieve steptotal from ''JUDAPP''
				SELECT @totaljud=ISNULL((SELECT StepTotal FROM Legal_groupSteps s INNER JOIN Legal_GroupStepTypes t 
					ON s.GroupStepTypeID=t.GroupStepTypeID WHERE t.Code=''JUDAPP'' AND Groupid=@GroupID) ,0.00)
				--Commence date
				SELECT @commdate=L.Value FROM Legal_CustomFields L INNER JOIN
					 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
					 WHERE C.Code=''CmDt'' and T.Code=''JUDAPP''and S.GroupID=@GroupID
				--Retrive paymenttransaction
				SELECT @sumamount=  ISNULL(SUM(T.TransactionAmount),0.00) FROM Transactions T 
					WHERE (T.TransactionType=901 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') 
						AND T.Datetopost between @commdate and getdate() AND T.AccountID=@AccountID
				--Calculate DebtAmount	
				SET @DebtAmt = 0.0				
				SELECT @DebtAmt=ISNULL(@totaljud,0.0)-ISNULL(@sumamount,0.0)

				IF (@EdiM = '''' or @EdiM IS NULL or @EdiM = ''0'')
				BEGIN
					Select @RateAmt = isnull(RateAmount,0.00) From Legal_RateSlabs
						Where RateID = (Select ID From Legal_Rates Where RateCode = ''WAR.SOL'') and
						  @DebtAmt >= RangeValue1 and @DebtAmt <= RangeValue2
				END

				ELSE IF  (@EdiM = ''1'')
				BEGIN
					Select @RateAmt = isnull(RateAmount,0.00) From Legal_RateSlabs
						Where RateID = (Select ID From Legal_Rates Where RateCode = ''WAR.SOL'') and
						  @DebtAmt >= RangeValue1 and @DebtAmt <= RangeValue2
				END
			END

		--Retrieve rate amount from rate slab using debt amount - QLD
			ELSE IF @StateServd = ''QLD''
			BEGIN
				Select @DebtAmount = isnull((Select money2 From AccountOther Where AccountId=@AccountID),0.00)
				Select @IntAmount = isnull((Select money5 From AccountOther Where AccountId=@AccountID),0.00)

				set @DebtInt = @DebtAmount+@IntAmount

				Select @RateAmt = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MCRTSOLW'') and
					  @DebtInt >= RangeValue1 and @DebtInt <= RangeValue2
			END

			SELECT @Fee = isnull(@RateAmt,0.00)			

		END

	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCourtFee]    Script Date: 02/26/2009 18:38:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCourtFee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateCourtFee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	SELECT @Fee = 0
	Declare @DebtAmt Money
	Declare @totaljud money
	Declare @sumamount money
	Declare @commdate datetime
	Declare @EdiM varchar(1)
	Declare @DebtAmount money
	Declare @IntAmount money
	Declare @DebtInt money
	Declare @groupID INT
	Declare @RateAmount money
	SELECT @groupID FROM Legal_groups WHERE GroupedAccountID=@AccountID
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN

		--Retrieve debt amount
		
		Set @DebtAmount = 0.00
		Set @IntAmount = 0.00
		Select @DebtAmount = isnull((Select money2 From AccountOther Where AccountId=@AccountID),0.00)
		Select @IntAmount = isnull((Select money5 From AccountOther Where AccountId=@AccountID),0.00)

		Set @DebtInt = @debtAmount + @IntAmount

		-- Retrieve state of service
		Declare @StateServiced varchar(30)
		Select @StateServiced = [StateServiced] From Legal_Groups
			Where GroupedAccountId = @AccountID

		--Retrieve rate amount from rate slab using debt amount - NSW
		
		Set @RateAmount = 0.00

		IF @StateServiced = ''NSW''
			BEGIN
				Select @RateAmount = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''LC.SLCC'') and
					  @DebtInt >= RangeValue1 and @DebtInt <= RangeValue2
			END
		--Retrieve rate amount from rate slab using debt amount - VIC
			ELSE IF @StateServiced = ''VIC''
			BEGIN
				Select @RateAmount = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MC.SDC'') and
					  @DebtInt >= RangeValue1 and @DebtInt <= RangeValue2
			END
		--Retrieve rate amount from rate slab using debt amount - QLD
			ELSE IF @StateServiced = ''QLD''
			BEGIN
				Select @RateAmount = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MCRTCOST'') and
						@DebtInt >= RangeValue1 and @DebtInt <= RangeValue2
			END

			SELECT @Fee = isnull(@RateAmount,0.00)			

		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
	BEGIN

		--Retrieve debt amount
		Set @DebtAmount = 0.00
		Set @IntAmount = 0.00
		Select @DebtAmount = isnull((Select money2 From AccountOther Where AccountId=@AccountID),0.00)
		Select @IntAmount = isnull((Select money5 From AccountOther Where AccountId=@AccountID),0.00)

		Set @DebtInt = @debtAmount + @IntAmount

		-- Retrieve state of service
		Select @StateServiced = [StateServiced] From Legal_Groups
			Where GroupedAccountId = @AccountID

		--Retrieve rate amount from rate slab using debt amount - NSW
		Declare @RateAmt money
		Set @RateAmt = 0.00

		IF @StateServiced = ''NSW''
			BEGIN
				Select @RateAmt = 0.00
			END
		--Retrieve rate amount from rate slab using debt amount - VIC
		ELSE IF @StateServiced = ''VIC''
		BEGIN
			SELECT @EdiM = ISNULL(L.Value,'''') FROM Legal_CustomFields L INNER JOIN
				Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
				Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
				Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
			WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID
		--Non EDI
			IF (@EdiM = '''' or @EdiM IS NULL or @EdiM = ''0'')
			BEGIN
				Select @RateAmount = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MC.SDJ'') and
					  @DebtInt >= RangeValue1 and @DebtInt <= RangeValue2
			END
		--EDI
			ELSE IF (@EdiM = ''1'')
				BEGIN
				Select @RateAmount = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MC.SDJM'') and
					  @DebtInt >= RangeValue1 and @DebtInt <= RangeValue2
			END
		END
		--Retrieve rate amount from rate slab using debt amount - QLD
		ELSE IF @StateServiced = ''QLD''
		BEGIN
			Select @RateAmt = 0.00
		END

		SELECT @Fee = isnull(@RateAmt,0.00)			

	END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

			--Retrieve debt amount
		Set @DebtAmount = 0.00
		Select @DebtAmount = isnull((Select money2 From AccountOther Where AccountId=@AccountID),0.00)

		-- Retrieve state of service
		Select @StateServiced = [StateServiced] From Legal_Groups
			Where GroupedAccountId = @AccountID

		--Retrieve rate amount from rate slab using debt amount - NSW
		Set @RateAmt = 0.00

		IF @StateServiced = ''NSW''
			BEGIN
				Select @RateAmt = 0.00
			END
		--Retrieve rate amount from rate slab using debt amount - VIC
			IF @StateServiced = ''VIC''
			BEGIN
				
					SELECT @EdiM = ISNULL(L.Value,'''') FROM Legal_CustomFields L INNER JOIN
					Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
					WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID

					--Retrieve steptotal from ''JUDAPP''
					SELECT @totaljud=ISNULL((SELECT StepTotal FROM Legal_groupSteps s INNER JOIN Legal_GroupStepTypes t 
									ON s.GroupStepTypeID=t.GroupStepTypeID WHERE t.Code=''JUDAPP'' AND Groupid=@GroupID) ,0.00)

					--Commence date
					SELECT @commdate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''CmDt'' and T.Code=''JUDAPP''and S.GroupID=@GroupID
		
					--Retrive paymenttransaction
					SELECT @sumamount=  ISNULL(SUM(T.TransactionAmount),0.00) FROM Transactions T 
								   WHERE (T.TransactionType=901 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') 
										AND T.Datetopost between @commdate and getdate() AND T.AccountID=@AccountID
					--calculating debtamount
					SET @DebtAmt=0				
					SELECT @DebtAmt=ISNULL(@totaljud,0.0)-ISNULL(@sumamount,0.0)
				--Non EDI
					IF (@EdiM = '''' or @EdiM IS NULL or @EdiM = ''0'')
					BEGIN

						Select @RateAmt = isnull(RateAmount,0.00) From Legal_RateSlabs
						Where RateID = (Select ID From Legal_Rates Where RateCode = ''MC.SDEM'') and
						@DebtAmt >= RangeValue1 and @DebtAmt <= RangeValue2
					END
				--EDI
					ELSE IF (@EdiM = ''1'')
					BEGIN
						Select @RateAmt = isnull(RateAmount,0.00) From Legal_RateSlabs
						Where RateID = (Select ID From Legal_Rates Where RateCode = ''MC.SDE'') and
						@DebtAmt >= RangeValue1 and @DebtAmt <= RangeValue2

					END
			END
		--Retrieve rate amount from rate slab using debt amount - QLD
			ELSE IF @StateServiced = ''QLD''
			BEGIN
				Select @RateAmt = 0.00
			END

			SELECT @Fee = isnull(@RateAmt,0.00)			
			

		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

		--Retrieve debt amount
		Set @DebtAmount = 0.00
		Select @DebtAmount = ISNULL((SELECT DebtAmount FROM Legal_groupSteps s INNER JOIN Legal_GroupStepTypes t 
									ON s.GroupStepTypeID=t.GroupStepTypeID WHERE t.Code=''SUMREQ'' AND Groupid=@GroupID) ,0.00)
		 
		-- Retrieve state of service
		Select @StateServiced = [StateServiced] From Legal_Groups
			Where GroupedAccountId = @AccountID

		--Retrieve rate amount from rate slab using debt amount - NSW
		Set @RateAmt = 0.00

		IF @StateServiced = ''NSW''
			BEGIN
				Select @RateAmt = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''LC.WRTC'') and
					  @DebtAmount>= RangeValue1 and @DebtAmount <= RangeValue2
			END
		--Retrieve rate amount from rate slab using debt amount - VIC
			IF @StateServiced = ''VIC''
			BEGIN
				SELECT @EdiM = ISNULL(L.Value,'''') FROM Legal_CustomFields L INNER JOIN
					Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
				WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID

				--Retrieve steptotal from ''JUDAPP''
				SELECT @totaljud=ISNULL((SELECT StepTotal FROM Legal_groupSteps s INNER JOIN Legal_GroupStepTypes t 
					ON s.GroupStepTypeID=t.GroupStepTypeID WHERE t.Code=''JUDAPP'' AND Groupid=@GroupID) ,0.00)
				--Retrieve commence date
				SELECT @commdate=L.Value FROM Legal_CustomFields L INNER JOIN
					 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
					 WHERE C.Code=''CmDt'' and T.Code=''JUDAPP''and S.GroupID=@GroupID
				--Retrive paymenttransaction
				SELECT @sumamount=  ISNULL(SUM(T.TransactionAmount),0.00) FROM Transactions T 
					WHERE (T.TransactionType=901 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') 
						AND T.Datetopost between @commdate and getdate() AND T.AccountID=@AccountID
				--Calculate DebtAmount
				SET @DebtAmount = 0.0				
				SELECT @DebtAmount=ISNULL(@totaljud,0.0)-ISNULL(@sumamount,0.0)

				IF (@EdiM = '''' or @EdiM IS NULL or @EdiM = ''0'')
				BEGIN
					Select @RateAmount = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MC.SDWM'') and
					  @DebtAmount>= RangeValue1 and @DebtAmount <= RangeValue2
				END

				ELSE IF  (@EdiM = ''1'')
				BEGIN
					Select @RateAmount = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MC.SDW'') and
					  @DebtAmount>= RangeValue1 and @DebtAmount <= RangeValue2
				END
			END
		--Retrieve rate amount from rate slab using debt amount - QLD
			ELSE IF @StateServiced = ''QLD''
			BEGIN
				Select @RateAmount = 0.00
			END

			SELECT @Fee = isnull(@RateAmount,0.00)			
			

		END
	/*************************/
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_JUDAPP_External]    Script Date: 02/26/2009 18:38:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_JUDAPP_External]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_JUDAPP_External]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;

		--Steptotal

	DECLARE @Groupstep VARCHAR(20)
	SELECT @Groupstep= Code FROM Legal_GroupStepTypes Ls INNER JOIN Legal_GroupSteps Lg ON Ls.GroupStepTypeID=@GroupStepTypeID 
	DECLARE @StepTotal money	

	IF @Groupstep =''JUDAPP''
	BEGIN
			DECLARE @commdate datetime
			DECLARE @sumamount Money
			DECLARE @GroupID INT 
			SELECT @GroupID = L.GroupID FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
			ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

			SELECT @commdate=Convert(datetime,L.Value) FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''ComD'' and T.Code=''SUMREQ''and S.GroupID=@GroupID

			SELECT @sumamount=  ISNULL(SUM(T.TransactionAmount),0.00) FROM Transactions T 
								   WHERE (T.TransactionType=901 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') 
										AND T.Datetopost between @commdate and getdate() AND T.AccountID=@AccountID
				
			SELECT @StepTotal= ((DebtAmount+IntAmount+SolicitorFee+CourtFee+ServiceFee+AttemptedFee+
						   TravelFee+BookKeepingFee+LeavyFee+SearchFee+CustomFee1+CustomFee2+CustomFee3+CustomFee4+CustomFee5)-@sumamount)
						   FROM Legal_GroupSteps L INNER JOIN Legal_Groups lg ON L.GroupID=lg.GroupID
						   WHERE lg.GroupedAccountID=@AccountID and L.GroupID=@GroupID and L.GroupStepTypeID=@GroupStepTypeID
			
			UPDATE Legal_GroupSteps
			SET StepTotal= ISNULL(@StepTotal,0.00)
			WHERE GroupID IN (SELECT GroupID FROM Legal_Groups WHERE GroupedAccountId = @AccountID)


	--Initialise Money2/5/6/7 to 0.0
	UPDATE Accountother
	SET Money2=0.0, Money5=0.0, Money6=0.0, Money7=0.0 where AccountID=@AccountID
	
									
	END

	SELECT @StepTotal;

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateDebtAmount]    Script Date: 02/26/2009 18:38:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateDebtAmount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateDebtAmount]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;

	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25)
	DECLARE @GroupID INT
	DECLARE @paytran MONEY
	DECLARE @startdate DATETIME
	DECLARE @prvDebtAmt MONEY
    DECLARE @DebtAmount MONEY

	SELECT @DebtAmount = 0		
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;

	CREATE TABLE #temp_Payments (SN INT IDENTITY(1,1),TransactionID INT,AccountID INT)
	CREATE TABLE #debtAllocations(TransactionID int,AccountID int,TransactionAmount money)

	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			/***Description: Compute debt amount using account(s) bill amount.
			Steps:	
				1. Sum bill amount of each account included in legal group
				2. DebtAmount will be sum of billbalace for all the Accounts with in legal Group 
				3. Update AccountOther.Money2
			***/
			
			SELECT @DebtAmount=ISNULL(BillAmount,0) FROM Account where AccountID=@AccountID

		END

	/*************************
	 Judgement Applied
	
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

			DECLARE @GroupID INT
			DECLARE @DebtAmountsummon Money
			DECLARE @commdate datetime
			DECLARE @sumtrans money
		
		SELECT @GroupID=L.GroupID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
		ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

		SELECT @DebtAmountsummon= G.DebtAmount FROM Legal_GroupSteps G INNER JOIN 
					Legal_GroupStepTypes S ON G.GroupStepTypeID=S.GroupStepTypeID
					WHERE S.Code=''SUMREQ'' and G.GroupID=@GroupID
		
		SELECT @DebtAmount = ISNULL(@DebtAmountsummon,0.00)
		--	Update AccountOther Money2 (DebtAmount field)
		UPDATE AccountOther
		SET	Money2 = @DebtAmount
		WHERE AccountID = @AccountID
		
	END

*************************/

ELSE IF @StepTypeCode <> ''SUMREQ''

	BEGIN
		--Getting groupid
 
		SELECT @GroupID=L.GroupID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
		ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1
		
		-- getting DebtAmount from previous group step
 
		SELECT @prvDebtAmt= ISNULL((SELECT TOP 1 DebtAmount FROM Legal_Groupsteps S
									 WHERE  S.GroupID=@GroupID ORDER BY GroupSteptypeid DESC),0.0)	

		--Getting commencedate from previous group step 	

		SELECT @startdate= ISNULL((SELECT TOP 1 Convert(datetime,ISNULL(L.Value,getdate()))
								  FROM Legal_CustomFields L 
								  INNER JOIN  Legal_groupSteps S 
											ON L.ActivityID=S.GroupstepID 
								 	 WHERE S.GroupID=@GroupID ORDER BY S.GroupStepTypeID DESC),0.0)
		
		--Getting all payment transaction in to temp_Payments
				
		INSERT INTO #temp_Payments
		SELECT T.TransactionID,T.AccountID FROM  Transactions T 
					 Where T.datetopost Between @startdate and getdate() 
				    AND (T.Transactiontype=901 AND TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'')
					AND T.AccountID=@AccountID

		-- getting debtallocation for all payments transactions from #debtAllocations

		INSERT INTO #debtAllocations
		SELECT T.TransactionID,T.AccountID,T.TransactionAmount FROM Transactions T INNER JOIN 
						  #temp_Payments p ON T.ParentTransactionID=p.TransactionID 
						  WHERE T.TransactionType=1 AND T.AccountID=@AccountID

		--Sum up all debtallocation 

		SELECT @paytran=  ISNULL(SUM(T.TransactionAmount),0.00) FROM #debtAllocations T 

		SELECT @DebtAmount = ISNULL((@prvDebtAmt - @paytran),0.0)		
	

	END

	/******************************************************/
	--	Update AccountOther Money2 (DebtAmount field)
		UPDATE AccountOther
			SET	Money2 = @DebtAmount
			WHERE AccountID = @AccountID
	/******************************************************/
	
	SELECT ISNULL(@DebtAmount, 0) AS ''DebtAmount''

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_QueueMultipleLetters]    Script Date: 02/26/2009 18:38:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_QueueMultipleLetters]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_QueueMultipleLetters]
	@AccountID INT,
	@EmployeeID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
	DECLARE @EdiM INT
    DECLARE @RecordID INT
	DECLARE @LetterID INT
	DECLARE @TelstraCopies INT
	DECLARE @DefendantCopies INT
	DECLARE @TotalCopies INT

	DECLARE @NoDefendant INT
	SELECT @NoDefendant= Count(*) FROM Legal_groupdebts d INNER JOIN Legal_groups g ON d.GroupID=g.GroupID  where isinclude=1 and g.GroupedAccountID=@AccountID 

	DECLARE @StateServiced varchar(30)
		Select @StateServiced = [StateServiced] From Legal_Groups
			Where GroupedAccountId = @AccountID

	DECLARE @GroupID INT
	SELECT @GroupID=GroupID FROM Legal_Groups where GroupedACcountID=@ACcountID

	SET @TelstraCopies=2	
	SET @DefendantCopies=1	
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			
		--Total copies = 2 for Telstra, 1 each for defendant
			SET @TotalCopies = @TelstraCopies + (@DefendantCopies * @NoDefendant)
		--NSW
			IF @StateServiced = ''NSW''
			BEGIN
				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%2SLC%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	
			END
		--VIC: Only Non-EDI
			IF @StateServiced = ''VIC''
			BEGIN

				SELECT @EdiM = ISNULL(L.Value,'''') FROM Legal_CustomFields L INNER JOIN
					Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
				WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID

				IF (@EdiM = '''' or @EdiM IS NULL or @EdiM = ''0'')
				BEGIN
					SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%3SUMTEL%''
					INSERT INTO AccountLetterQueue
					SELECT
							@AccountID,
							@LetterID,
							GETDATE(),
							''O'',
							0,
							@EmployeeID,
							2,NULL,NULL,NULL,NULL,0	
				END
			END
		--QLD
			ELSE IF @StateServiced = ''QLD'' 
			BEGIN
				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%4QSC''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	
			END
		
		END
	
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN
	--VIC only has legal doc for SUMSRV
			IF @StateServiced = ''VIC''
			BEGIN

				SELECT @EdiM = ISNULL(L.Value,'''') FROM Legal_CustomFields L INNER JOIN
					Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
				WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID
	--Manual
				IF (@EdiM = '''' or @EdiM IS NULL or @EdiM = ''0'')
				BEGIN
					SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%3MCAFFS%''
					INSERT INTO AccountLetterQueue
					SELECT
							@AccountID,
							@LetterID,
							GETDATE(),
							''O'',
							0,
							@EmployeeID,
							2,NULL,NULL,NULL,NULL,0	
				END
	--EDI. Currently it orders same doc as manual
				ELSE IF (@EdiM = ''1'')
					BEGIN
						SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%3MCAFFS%''
						INSERT INTO AccountLetterQueue
						SELECT
								@AccountID,
								@LetterID,
								GETDATE(),
								''O'',
								0,
								@EmployeeID,
								2,NULL,NULL,NULL,NULL,0	
					END
			END		
		END


	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN

		--Total copies = 2 for Telstra, 1 each for defendant
			SET @TotalCopies = @TelstraCopies + (@DefendantCopies * @NoDefendant)
		--NSW
			IF @StateServiced = ''NSW''
			BEGIN
				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%AFFDEBTNE%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	
			END
	--VIC only has legal doc for JUDAPP
			IF @StateServiced = ''VIC''
			BEGIN

				SELECT @EdiM = ISNULL(L.Value,'''') FROM Legal_CustomFields L INNER JOIN
					Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
				WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID
	--Manual
				IF (@EdiM = '''' or @EdiM IS NULL or @EdiM = ''0'')
				BEGIN
					SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%3MCORDER%''
					INSERT INTO AccountLetterQueue
					SELECT
							@AccountID,
							@LetterID,
							GETDATE(),
							''O'',
							0,
							@EmployeeID,
							2,NULL,NULL,NULL,NULL,0	
				END
			END
		--QLD
			ELSE IF @StateServiced = ''QLD'' 
			BEGIN
				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%4QAFFJU%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	

				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%4QREQJU%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	

				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%4QJU%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	
			END

		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN

	/** Find out if there exists any legal type of Company or Business ***/
			Declare @CountCMPBUS int
	----Count of Company,Business
			Select @CountCMPBUS = count(*) From Legal_GroupDebtors 
				Where IsInclude = 1 and 
					  (LegalTypeID = 3 or LegalTypeID = 2) and
					  GroupID = (Select GroupId from Legal_Groups Where GroupedAccountId=@AccountID)

		--Total copies = 2 for Telstra, 1 each for defendant
			SET @TotalCopies = @TelstraCopies + (@DefendantCopies * @NoDefendant)

		--NSW
			IF @StateServiced = ''NSW''
			BEGIN
				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%EXAMNOT%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	
		--Individual legal types
				IF (@CountCMPBUS = 0)
				BEGIN
					SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%AFFSERVEXAMI%''
					INSERT INTO AccountLetterQueue
					SELECT
							@AccountID,
							@LetterID,
							GETDATE(),
							''O'',
							0,
							@EmployeeID,
							2,NULL,NULL,NULL,NULL,0	
				END
		--Company,Business legal types
				ELSE IF (@CountCMPBUS > 0)
				BEGIN
					SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%AFFSERVEXAMC%''
					INSERT INTO AccountLetterQueue
					SELECT
							@AccountID,
							@LetterID,
							GETDATE(),
							''O'',
							0,
							@EmployeeID,
							2,NULL,NULL,NULL,NULL,0	
				END
			END

	--VIC only has legal doc for JUDAPP
			IF @StateServiced = ''VIC''
			BEGIN

				SELECT @EdiM = ISNULL(L.Value,'''') FROM Legal_CustomFields L INNER JOIN
					Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
				WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID

	--Individual
				IF (@CountCMPBUS = 0)
				BEGIN
		--Manual
					IF (@EdiM = '''' or @EdiM IS NULL or @EdiM = ''0'')
					BEGIN
						SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%3MCSOE1%''
						INSERT INTO AccountLetterQueue
						SELECT
								@AccountID,
								@LetterID,
								GETDATE(),
								''O'',
								0,
								@EmployeeID,
								2,NULL,NULL,NULL,NULL,0	
					END
		--Manual & EDI.
					SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%3FM27CC%''
					INSERT INTO AccountLetterQueue
					SELECT
							@AccountID,
							@LetterID,
							GETDATE(),
							''O'',
							0,
							@EmployeeID,
							2,NULL,NULL,NULL,NULL,0	
				END
		--Company,Business legal types
				ELSE IF (@CountCMPBUS > 0)
				BEGIN
		--Manual
					IF (@EdiM = '''' or @EdiM IS NULL or @EdiM = ''0'')
					BEGIN
						SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%3MCSOE1%''
						INSERT INTO AccountLetterQueue
						SELECT
								@AccountID,
								@LetterID,
								GETDATE(),
								''O'',
								0,
								@EmployeeID,
								2,NULL,NULL,NULL,NULL,0	
					END
		--Manual & EDI.
					SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%3FM27CD%''
					INSERT INTO AccountLetterQueue
					SELECT
							@AccountID,
							@LetterID,
							GETDATE(),
							''O'',
							0,
							@EmployeeID,
							2,NULL,NULL,NULL,NULL,0	
				END
			END

		--QLD
			ELSE IF @StateServiced = ''QLD'' 
			BEGIN
				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%4QAFFEXAM%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	

				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%4QAPPSUM%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	

				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%4QEHORDER%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	

				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%4QSMENT%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	
			END

		END
	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN

		--Total copies = 2 for Telstra, 1 each for defendant
			SET @TotalCopies = @TelstraCopies + (@DefendantCopies * @NoDefendant)
		--NSW
			IF @StateServiced = ''NSW''
			BEGIN
				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%NOMWLOPNe%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	
			END
	--VIC only has legal doc for JUDAPP
			IF @StateServiced = ''VIC''
			BEGIN

				SELECT @EdiM = ISNULL(L.Value,'''') FROM Legal_CustomFields L INNER JOIN
					Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
				WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID
	--Manual
				IF (@EdiM = '''' or @EdiM IS NULL or @EdiM = ''0'')
				BEGIN
					SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%3MCWARR%''
					INSERT INTO AccountLetterQueue
					SELECT
							@AccountID,
							@LetterID,
							GETDATE(),
							''O'',
							0,
							@EmployeeID,
							2,NULL,NULL,NULL,NULL,0	
				END
			END
		--QLD
			ELSE IF @StateServiced = ''QLD'' 
			BEGIN
				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%4QEWSSP%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	

				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%4QEWAPPSSPRO%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	

				SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%4QEWSTA%''
				INSERT INTO AccountLetterQueue
				SELECT
						@AccountID,
						@LetterID,
						GETDATE(),
						''O'',
						0,
						@EmployeeID,
						2,NULL,NULL,NULL,NULL,0	
			END

		END



	
--	SELECT ISNULL(@RecordID, 0) AS ''RecordID''

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateCustom1Fee]    Script Date: 02/26/2009 18:38:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateCustom1Fee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateCustom1Fee]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
	
    DECLARE @Fee MONEY
	Declare @totaljud money
	Declare @sumamount money
	Declare @commdate datetime
	Declare @EdiM varchar(1)
	Declare @DebtAmount money
	Declare @groupID INT
	Declare @RateAmount money
	Declare @StateServiced varchar(30)

	SELECT @Fee = 0
	SELECT @groupID FROM Legal_groups WHERE GroupedAccountID=@AccountID
	Select @StateServiced = [StateServiced] From Legal_Groups
		Where GroupedAccountId = @AccountID

	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
		BEGIN
			SELECT @Fee = 0
		END
	
	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN
			SELECT @Fee = 0			
		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN
			SELECT @Fee = 0
		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN
			SELECT @Fee = 0
		--Retrieve rate amount from rate slab using debt amount - VIC
			IF @StateServiced = ''VIC''
			BEGIN
				SELECT @EdiM = ISNULL(L.Value,'''') FROM Legal_CustomFields L INNER JOIN
					Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
				WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID

				--Retrieve steptotal from ''JUDAPP''
				SELECT @totaljud=ISNULL((SELECT StepTotal FROM Legal_groupSteps s INNER JOIN Legal_GroupStepTypes t 
					ON s.GroupStepTypeID=t.GroupStepTypeID WHERE t.Code=''JUDAPP'' AND Groupid=@GroupID) ,0.00)
				--Retrieve commence date
				SELECT @commdate=L.Value FROM Legal_CustomFields L INNER JOIN
					 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
					 WHERE C.Code=''CmDt'' and T.Code=''JUDAPP''and S.GroupID=@GroupID
				--Retrive paymenttransaction
				SELECT @sumamount=  ISNULL(SUM(T.TransactionAmount),0.00) FROM Transactions T 
					WHERE (T.TransactionType=901 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') 
						AND T.Datetopost between @commdate and getdate() AND T.AccountID=@AccountID
				--Calculate DebtAmount
				SET @DebtAmount = 0.0				
				SELECT @DebtAmount=ISNULL(@totaljud,0.0)-ISNULL(@sumamount,0.0)

				IF (@EdiM = '''' or @EdiM IS NULL or @EdiM = ''0'')
				BEGIN
					Select @RateAmount = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MC.SFW'') and
					  @DebtAmount>= RangeValue1 and @DebtAmount <= RangeValue2
				END

				ELSE IF  (@EdiM = ''1'')
				BEGIN
					Select @RateAmount = isnull(RateAmount,0.00) From Legal_RateSlabs
					Where RateID = (Select ID From Legal_Rates Where RateCode = ''MC.SFW'') and
					  @DebtAmount>= RangeValue1 and @DebtAmount <= RangeValue2
				END
				SELECT @Fee = isnull(@RateAmount,0.00)			
			END

		END
	/*************************/
	
	SELECT ISNULL(@Fee, 0) AS ''Fee''

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_Validation]    Script Date: 02/26/2009 18:38:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_Validation]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_Validation]
	@AccountID BIGINT,
	@ValidationType INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @IsValid BIT;
	DECLARE @GroupStepID INT;
	DECLARE @Date DATETIME;

	DECLARE @GroupID INT
	SELECT @GroupID=GroupID FROM Legal_Groups where GroupedACcountID=@ACcountID

	SET @IsValid = 0;
-------------------------------------------------------------------------------------

	IF @ValidationType = 1
		BEGIN
			/**** 
			Description: Validates if Issued Date exists.
			Requirements:	
				1. Group step type = ''SUMISS''
				2. Custom field type code = ''IssD''
				3. Custom field value must have date
			*****/	
			SELECT @IsValid = CASE WHEN ISNULL(D.Value,'''') = '''' THEN 0 ELSE 1 END    
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B
				ON A.GroupID = B.GroupID AND B.Status <> ''R''
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''SUMISS''
			INNER JOIN Legal_CustomFields D
				ON B.GroupStepID = D.ActivityID
			INNER JOIN Legal_CustomFieldTypes E
				ON D.CustomFieldTypeID = E.CustomFieldTypeID AND E.Code = ''IssD''
			WHERE A.GroupedAccountID = @AccountID

		END
-------------------------------------------------------------------------------------

	ELSE IF @ValidationType = 2
		BEGIN
			/**** 
			Description: Validates if Case Number is present.
			Requirements:	
				1. Step activity with Case Number
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) < 1 THEN 0 ELSE 1 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B
				ON A.GroupID = B.GroupID AND B.Status <> ''R''
			WHERE A.GroupedAccountID = @AccountID AND ISNULL(B.CaseNumber, '''') <> ''''
			
		END
-------------------------------------------------------------------------------------
	
	ELSE IF @ValidationType = 3
		BEGIN
			/**** 
			Description: Validates timeframe expiration for JUDAPP.
			Requirements:	
				1. Group step type = ''SUMSRV''
				2. Custom field type code = ''DSrv1'', ''DSrv2'', ''DSrv3'', ''DSrv4'', ''DSrv5'', ''DSrv6''.
				3. Find the latest date from custom field type codes.
				4. Current date - Latest date should be greater than date specified for state,
			*****/

			SELECT @Groupstepid = GroupStepID FROM legal_groupsteps lgs 
					inner join legal_groups lg on lg.groupid=lgs.groupid 
			Where GroupedAccountID=@AccountID

			SELECT @Date = ISNULL((SELECT TOP 1 [value]
							FROM legal_customfields lc inner join legal_customfieldtypes lct on lct.customfieldtypeid=lc.customfieldtypeid
							WHERE lc.activityid=@GroupStepID and IsDate([value]) = 1 and
								  lct.code in (''DSrv1'', ''DSrv2'', ''DSrv3'', ''DSrv4'', ''DSrv5'', ''DSrv6'') and lc.value <> '''' 
							ORDER BY cast([value] as datetime) DESC),'''')

			SELECT @IsValid = 
				CASE WHEN
						CASE WHEN (ISDATE(@Date) = 1 and (@Date <> ''1900-01-01 00:00:00''))
							THEN DATEDIFF(d, CAST(@Date AS DATETIME), GETDATE())
							ELSE 0
						END > 
						CASE WHEN A.StateServiced = ''NSW'' THEN 35
							 WHEN A.StateServiced = ''VIC'' THEN 21
							 WHEN A.StateServiced = ''QLD'' THEN 28
							 ELSE 0
						END			
						THEN 1
					ELSE 0
				END
			FROM Legal_Groups A

		END
-------------------------------------------------------------------------------------

	ELSE IF @ValidationType = 4
		BEGIN
			/**** 
			Description: Validates if DEFEND event has been created on SUMSRV step.
			Requirements:	
				1. Hearing type code = ''DEFSUM''
				2. Group step type = ''SUMSRV''
				3. Custom field value (DefS) = ''1''
				4. Custom field type code = ''DefS''
				5. Must not have successful defense event
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) > 0 THEN 0 ELSE 1 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B
				ON A.GroupID = B.GroupID AND B.Status <> ''R''
			INNER JOIN Legal_Hearings F
				ON B.GroupStepID = F.GroupStepID 
			INNER JOIN Legal_HearingTypes G
				ON F.HearingTypeID = G.HearingTypeID AND G.Code = ''DEFEND''
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''SUMSRV''
			INNER JOIN Legal_CustomFields D
				ON F.HearingID = D.ActivityID AND D.Value = ''1''
			INNER JOIN Legal_CustomFieldTypes E
				ON D.CustomFieldTypeID = E.CustomFieldTypeID AND E.Code = ''DefS''
			WHERE A.GroupedAccountID = @AccountID
			
		END
-------------------------------------------------------------------------------------

	ELSE IF @ValidationType = 5
		BEGIN
			/**** 
			Description: Validates if paid in full by checking account''s balance.
			Requirements:	
				1. Account''s bill balance > 0
			*****/
			SELECT @IsValid = CASE WHEN ISNULL(A.BillBalance, 0) > 0 THEN 1 ELSE 0 END  
			FROM Account A
			WHERE A.AccountID = @AccountID
			
		END
-------------------------------------------------------------------------------------

	ELSE IF @ValidationType = 6
		BEGIN
			/**** 
			Description: Validates account''s maximum bill balance base on state.
			Requirements:	
				1. If from state of VIC, account''s bill balance < $100000 or,
				2. If from state of NSW, account''s bill balance < $60000 or,	
				3. If from state of QLD, account''s bill balance < $50000
			Return value: 1=valid, 0=invalid
			*****/
			SELECT @IsValid =  
				CASE 
					WHEN A.Formula_Flag IN (''VIC'',''SA'',''NT'',''TAS'',''ACT'', ''WA'') AND A.BillBalance <= 100000 THEN 1 
					WHEN A.Formula_Flag = ''NSW'' AND A.BillBalance <= 60000 THEN 1
					WHEN A.Formula_Flag = ''QLD'' AND A.BillBalance <= 50000 THEN 1
					ELSE 0 
				END
			FROM Account A
			WHERE A.AccountID = @AccountID
			
		END
-------------------------------------------------------------------------------------

	ELSE IF @ValidationType = 7
		BEGIN
			/**** 
			Description: Validates GROUP Account''s maximum bill balance base on state.
			Requirements:	
				1. If from state of VIC, account''s bill balance < $100000 or,
				2. If from state of NSW, account''s bill balance < $60000 or,	
				3. If from state of QLD, account''s bill balance < $50000
			Return value: 1=valid, 0=invalid
			*****/
			SELECT @IsValid =  
				CASE 
					WHEN G.StateServiced IN (''VIC'',''SA'',''NT'',''TAS'',''ACT'', ''WA'') AND A.BillBalance <= 100000 THEN 1 
					WHEN G.StateServiced = ''NSW'' AND A.BillBalance <= 60000 THEN 1
					WHEN G.StateServiced = ''QLD'' AND A.BillBalance <= 50000 THEN 1
					ELSE 0 
				END
			FROM Legal_Groups G INNER JOIN Account A ON A.AccountID=G.GroupedAccountID
			WHERE G.GroupedAccountID = @AccountID
			
		END
-------------------------------------------------------------------------------------

		ELSE IF @ValidationType = 8
		BEGIN
			/**** 
			Description: Validates account if Sommons Reqest step exist.
			Requirements:	
				1. Must have SUMREQ group steps
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) > 0 THEN 1 ELSE 0 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B 
				ON A.GroupID = B.GroupID AND B.Status <> ''R''
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''SUMREQ''
			WHERE A.GroupedAccountID = @AccountID
			
		END
-------------------------------------------------------------------------------------

		ELSE IF @ValidationType = 9
		BEGIN
			/**** 
			Description: Validates account if Sommons issued step exist.
			Requirements:	
				1. Must have SUMISS group steps
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) > 0 THEN 1 ELSE 0 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B 
				ON A.GroupID = B.GroupID AND B.Status <> ''R''
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''SUMISS''
			WHERE A.GroupedAccountID = @AccountID
			
		END
-------------------------------------------------------------------------------------

	ELSE IF @ValidationType = 10
		BEGIN
			/**** 
			Description: Validates account if Summons Serviced step exist.
			Requirements:	
				1. Must have SUMSRV group step type
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) > 0 THEN 1 ELSE 0 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B 
				ON A.GroupID = B.GroupID AND B.Status <> ''R''
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''SUMSRV''
			WHERE A.GroupedAccountID = @AccountID
			
		END
-------------------------------------------------------------------------------------

	ELSE IF @ValidationType = 11
		BEGIN
			/**** 
			Description: Validates account if Judgement Applied step exist.
			Requirements:	
				1. Must have JUDAPP group steps
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) > 0 THEN 1 ELSE 0 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B 
				ON A.GroupID = B.GroupID AND B.Status <> ''R''
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''JUDAPP''
			WHERE A.GroupedAccountID = @AccountID
			
		END
-------------------------------------------------------------------------------------
		
		ELSE IF @ValidationType = 12
		BEGIN
			/**** 
			Description: Validates account if Judgment Entered step exist.
			Requirements:	
				1. Must have JUDENT group steps
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) > 0 THEN 1 ELSE 0 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B 
				ON A.GroupID = B.GroupID AND B.Status <> ''R''
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''JUDENT''
			WHERE A.GroupedAccountID = @AccountID
			
		END		
-------------------------------------------------------------------------------------

		ELSE IF @ValidationType = 13
		BEGIN
			/**** 
			Description: Validates account if Warrant Request step exist.
			Requirements:	
				1. Must have WARREQ group steps
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) > 0 THEN 1 ELSE 0 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B 
				ON A.GroupID = B.GroupID AND B.Status <> ''R''
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''WARREQ''
			WHERE A.GroupedAccountID = @AccountID
			
		END
-------------------------------------------------------------------------------------
		
		ELSE IF @ValidationType = 14
		BEGIN
			/**** 
			Description: Validates account if Exam Request step exist.
			Requirements:	
				1. Must have EXMREQ group steps
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) > 0 THEN 1 ELSE 0 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B 
				ON A.GroupID = B.GroupID AND B.Status <> ''R''
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''EXMREQ''
			WHERE A.GroupedAccountID = @AccountID
			
		END

-------------------------------------------------------------------------------------

		ELSE IF @ValidationType = 15
		BEGIN
			/**** 
			Description: Validates account if Exam Issued step exist.
			Requirements:	
				1. Must have EXMISS group steps
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) > 0 THEN 1 ELSE 0 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B 
				ON A.GroupID = B.GroupID AND B.Status <> ''R''
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''EXMISS''
			WHERE A.GroupedAccountID = @AccountID
			
		END
-------------------------------------------------------------------------------------

		ELSE IF @ValidationType = 16
		BEGIN
			/**** 
			Description: Does the account have a defendant of Legal type COMPANY or BUSINESS
			Requirements:	
				1. Must have group creation details
			*****/
			Declare @CountCMP int
			Declare @CountBUS int

----Count of Company
			Select @CountCMP = count(*) From Legal_GroupDebtors 
				Where IsInclude = 1 and 
					  LegalTypeID = 3 and
					  GroupID = (Select GroupId from Legal_Groups Where GroupedAccountId=@AccountID)
----Count of Business
			Select @CountBUS = count(*) From Legal_GroupDebtors 
				Where IsInclude = 1 and 
					  LegalTypeID = 2 and
					  GroupID = (Select GroupId from Legal_Groups Where GroupedAccountId=@AccountID)

			Select @IsValid = CASE WHEN (@CountCMP > 0  or  @CountBUS > 0) THEN 1 ELSE 0 END  
			
		END
-------------------------------------------------------------------------------------
	
	ELSE IF @ValidationType = 17
		BEGIN
			/**** 
			Description: Validates timeframe expiration for JUDENT.
			Requirements:	
				1. Group step type = ''JUDENT''
				2. Custom field type code = ''CmDt''
				3. Find if date exists
				4. Current date - retrieved date should be greater than date specified for state,
			*****/

			SELECT @Date = ISNULL(D.Value,'''')
				FROM Legal_Groups A
				INNER JOIN Legal_GroupSteps B
					ON A.GroupID = B.GroupID AND B.Status <> ''R''
				INNER JOIN Legal_GroupStepTypes C
					ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = ''JUDAPP''
				INNER JOIN Legal_CustomFields D
					ON B.GroupStepID = D.ActivityID
				INNER JOIN Legal_CustomFieldTypes E
					ON D.CustomFieldTypeID = E.CustomFieldTypeID AND E.Code = ''CmDt''
				WHERE A.GroupedAccountID = @AccountID

			SELECT @IsValid = 
				CASE WHEN
						CASE WHEN ISDATE(@Date) = 1 
							THEN DATEDIFF(d, CAST(@Date AS DATETIME), GETDATE())
							ELSE 0
						END > 
						CASE WHEN A.StateServiced = ''NSW'' THEN 35
							 WHEN A.StateServiced = ''VIC'' THEN 21
							 WHEN A.StateServiced = ''QLD'' THEN 28
							 ELSE 0
						END			
						THEN 1
					ELSE 0
				END
			FROM Legal_Groups A

		END

-------------------------------------------------------------------------------------

		ELSE IF @ValidationType = 18
		BEGIN
			/**** 
			Description: Does the account have active arrangements
			Requirements:	
				1. verify against promise table for arrangements >= today
			*****/

			SELECT @IsValid = CASE WHEN COUNT(*) <= 0 THEN 1 ELSE 0 END  
			FROM AccountPromise AP INNER JOIN Account A ON A.AccountID=AP.AccountID
			Where AP.DatePromised >= getdate() and A.AgencyStatusID <> 10 and
				  A.AccountID = AP.AccountID and AP.Accountid = @AccountID
		
		END

-------------------------------------------------------------------------------------

		ELSE IF @ValidationType = 20
		BEGIN
			/**** 
			Description: Does SUMREQ has EDI set to YES?
			Requirements:	
				1. SUMREQ
				2. EDI (Y/N)
			*****/

			DECLARE @EdiM INT
			SELECT @EdiM = ISNULL(L.Value,'''') FROM Legal_CustomFields L INNER JOIN
				Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
				Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
				Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
			WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID

			SELECT @IsValid = CASE WHEN (@EdiM = '''' or @EdiM IS NULL or @EdiM = 0) THEN 0 ELSE 1 END

		
		END



	SELECT @IsValid AS ''IsValid''

END 


/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineAdditionalFieldValues]    Script Date: 02/26/2009 18:38:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineAdditionalFieldValues]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineAdditionalFieldValues]
	@AccountID INT,  --Grp acct id
	@GroupStepTypeID INT,  --Step type id/Hearing type Id  eg., 1=SUMREQ, DEFEND
	@ActivityID INT, --Step id, Hearing id
	@ActivityTypeID INT  --1=GS, 2=Event
AS
BEGIN --Main
	SET NOCOUNT ON;

	DECLARE @ActTypeID INT
	SELECT @ActTypeID = FieldType FROM Legal_CustomFieldTypes
	WHERE FieldType = @ActivityTypeID

	DECLARE @commdate Datetime
	DECLARE @sumamount Money
	DECLARE @cdate Datetime
	DECLARE @filedate Datetime
	DECLARE @issuedate Datetime
	DECLARE @edi varchar(1)
	DECLARE @TransactionID INT
	DECLARE @ActID INT
	SELECT @ActID= GroupStepID From Legal_GroupSteps WHERE GroupStepID=@ActivityID
	
	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25);
	DECLARE @GroupID INT;
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID;
--	SELECT @GroupID=L.GroupID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
--	ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1
	SELECT @GroupID=GroupID FROM Legal_Groups where GroupedACcountID=@ACcountID

					
	/************************
	Create temporary table for custom field
	************************/	
	CREATE TABLE #Temp_Customfield
	(GroupID int, AccountID int,CustomFieldTypeID int,ActivityID int,Code varchar(50),ActivityType int,value varchar(3000) );

	/************************
	Create and populate temporary table for grouped accounts
	************************/	
	CREATE TABLE #groupedAccounts(SN INT IDENTITY(1,1),AccountID INT,GroupID int,sumoftransaction money )
	INSERT INTO #groupedAccounts
	SELECT AccountID,L.GroupID,0  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
	ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1;

	/************************
	Populate #Temp_Customfield
	************************/
	INSERT INTO #Temp_Customfield
	SELECT A.GroupID, C.ActivityID, D.CustomFieldTypeID, C.ActivityID, D.Code, C.ActivityType, C.[Value]
	FROM Legal_Groups A
	INNER JOIN Legal_GroupSteps B
		ON A.GroupID = B.GroupID AND B.[Status] <> ''R'' AND B.GroupStepID = @ActivityID
	INNER JOIN Legal_CustomFields C
		ON B.GroupStepID = C.ActivityID AND C.ActivityType = @ActivityTypeID
	LEFT JOIN Legal_CustomFieldTypes D
		ON C.CustomFieldTypeID = D.CustomFieldTypeID
	WHERE A.GroupedAccountID = @AccountID;


		/*************************
		 Summons Request
		*************************/
		IF @StepTypeCode = ''SUMREQ''
			BEGIN	-- SUMREQ
				
				--	ComD, FilD
						UPDATE #Temp_Customfield
						SET value= convert(varchar(19),convert (datetime,Getdate()),101)
						Where Code=''ComD'' or Code=''FilD'';
				
						--	EdIM
						UPDATE #Temp_Customfield
						SET value= CASE   WHEN G.StateServiced=''VIC'' THEN 1
						ELSE 0  END FROM Legal_Groups G INNER JOIN  #Temp_Customfield T
						ON G.GroupID=T.GroupID AND G.GroupedAccountID= @AccountID
						Where T.Code=''EdiM'';
						------------------------------------------------Account1---------------------
						-- DoDf1
						UPDATE #Temp_Customfield
						SET value=Case When (A.Date17 =''1900-01-01'' or A.Date17 IS NULL) then ''''Else A.Date17 end FROM  Accountother A INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''DoDf1'' AND G.SN=1
						-- DoDb1
						UPDATE #Temp_Customfield
						SET value=Case When A.Date14 =''1900-01-01''or A.Date14 IS NULL then '''' Else A.Date14 end FROM  Accountother A  INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''DoDb1''AND G.SN=1
						-- ConV1
						UPDATE #Temp_Customfield
						SET value=Case When  A.Money4 IS NULL then '''' Else convert(varchar(50),A.Money4) end FROM  Accountother A  INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''ConV1'' AND G.SN=1
						-------------------------------------Account2----------------------------------
						-- DoDf2
						UPDATE #Temp_Customfield
						SET value=Case When (A.Date17 =''1900-01-01'' or A.Date17 IS NULL) then ''''Else A.Date17 end FROM  Accountother A INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''DoDf2'' AND G.SN=2
						-- DoDb2
						UPDATE #Temp_Customfield
						SET value=Case When A.Date14 =''1900-01-01''or A.Date14 IS NULL then '''' Else A.Date14 end FROM  Accountother A  INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''DoDb2''AND G.SN=2
						-- ConV2
						UPDATE #Temp_Customfield
						SET value=Case When A.Money4 =''''or A.Money4 IS NULL then '''' Else convert(varchar(50),A.Money4) end FROM  Accountother A  INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''ConV2'' AND G.SN=2
						----------------------------------Account3-----------------------------------
						-- DoDf3
						UPDATE #Temp_Customfield
						SET value=Case When (A.Date17 =''1900-01-01'' or A.Date17 IS NULL) then ''''Else A.Date17 end FROM  Accountother A INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''DoDf3'' AND G.SN=3
						-- DoDb3
						UPDATE #Temp_Customfield
						SET value=Case When A.Date14 =''1900-01-01''or A.Date14 IS NULL then '''' Else A.Date14 end FROM  Accountother A  INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''DoDb3''AND G.SN=3
						-- ConV3
						UPDATE #Temp_Customfield
						SET value=Case When A.Money4 =''''or A.Money4 IS NULL then '''' Else convert(varchar(50),A.Money4)  end FROM  Accountother A  INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''ConV3'' AND G.SN=3
						--------------------------------Account4--------------------------------------
						-- DoDf4
						UPDATE #Temp_Customfield
						SET value=Case When (A.Date17 =''1900-01-01'' or A.Date17 IS NULL) then ''''Else A.Date17 end FROM  Accountother A INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''DoDf4'' AND G.SN=4
						-- DoDb3
						UPDATE #Temp_Customfield
						SET value=Case When A.Date14 =''1900-01-01''or A.Date14 IS NULL then '''' Else A.Date14 end FROM  Accountother A  INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''DoDb4''AND G.SN=4
						-- ConV3
						UPDATE #Temp_Customfield
						SET value=Case When A.Money4 =''''or A.Money4 IS NULL then '''' Else convert(varchar(50),A.Money4) end FROM  Accountother A  INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''ConV4'' AND G.SN=4
						------------------------------Account5---------------------------------------
						-- DoDf5
						UPDATE #Temp_Customfield
						SET value=Case When (A.Date17 =''1900-01-01'' or A.Date17 IS NULL) then ''''Else A.Date17 end FROM  Accountother A INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''DoDf5'' AND G.SN=5
						-- DoDb3
						UPDATE #Temp_Customfield
						SET value=Case When A.Date14 =''1900-01-01''or A.Date14 IS NULL then '''' Else A.Date14 end FROM  Accountother A  INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''DoDb5''AND G.SN=5
						-- ConV3
						UPDATE #Temp_Customfield
						SET value=Case When A.Money4 =''''or A.Money4 IS NULL then '''' Else convert(varchar(50),A.Money4) end FROM  Accountother A  INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''ConV5'' AND G.SN=5
						-----------------------------Account6---------------------------------------
						-- DoDf6
						UPDATE #Temp_Customfield
						SET value=Case When (A.Date17 =''1900-01-01'' or A.Date17 IS NULL) then ''''Else A.Date17 end FROM  Accountother A INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''DoDf6'' AND G.SN=6
						-- DoDb3
						UPDATE #Temp_Customfield
						SET value=Case When A.Date14 =''1900-01-01''or A.Date14 IS NULL then '''' Else A.Date14 end FROM  Accountother A  INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''DoDb6''AND G.SN=6
						-- ConV3
						UPDATE #Temp_Customfield
						SET value=Case When A.Money4 =''''or A.Money4 IS NULL then '''' Else convert(varchar(50),A.Money4) end FROM  Accountother A  INNER JOIN  #groupedAccounts G ON G.AccountID=A.AccountID 
						INNER JOIN Legal_GroupSteps S ON S.GroupID=G.GroupID INNER JOIN #Temp_Customfield C ON S.GroupID=C.GroupID 
						Where C.Code=''ConV6'' AND G.SN=6
					
						DECLARE @Maxcount INT
						Declare @sumtotal money
						DECLARE @sumtrans money
						SELECT @Maxcount = MAX(SN) FROM #groupedAccounts
						DECLARE @SN INT
						SET @SN =1

						WHILE (@SN<=@Maxcount)
						BEGIN
							--	PPS

							SELECT @sumtrans=ISNULL(SUM(ISNULL(T.TransactionAmount,0.00)),0.00) FROM Transactions T INNER JOIN 
							 #groupedAccounts G ON G.AccountID=T.AccountID INNER JOIN Account A ON A.AccountID=G.AccountID 
						    WHERE G.SN=@SN and (T.TransactionType=901 and T.ReversedFlag=0 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') ;
						
							UPDATE #groupedAccounts
							SET sumoftransaction=@sumtrans WHERE SN=@SN
							
												
							SET @SN=@SN+1
					   END

					  SELECT @sumtotal=SUM(ISNULL(sumoftransaction,0.00))FROM  #groupedAccounts
					  UPDATE #Temp_Customfield
						SET Value= @sumtotal 
						WHERE 	Code=''PPS''		

				SET dateformat mdy;
				UPDATE #Temp_Customfield 
				SET value= CASE WHEN value =''Jan  1 1900 12:00AM'' or value =''1900-01-01'' or value=''01-01-1900'' or value= '''' or value IS NULL THEN '''' ELSE
				convert(varchar(19),convert (datetime,value),101)END  where code in (''DoDb1'',''DoDb2'',''DoDb3'',''DoDb4'',''DoDb5'',''DoDb6'',''DoDf1'',''DoDf2'',''DoDf3'',''DoDf4'',''DoDf5'',''DoDf6'',''ComD'',''FilD'')


			END	-- SUMREQ


		
		/*************************
		 Summons Issued
		*************************/
		ELSE IF @StepTypeCode = ''SUMISS''
			BEGIN	--	SUMISS
				
				--	ComD, FilD
				UPDATE #Temp_Customfield
				SET value= L.value FROM Legal_CustomFields L INNER JOIN Legal_GroupSteps G ON L.ActivityID=G.GroupStepID
				INNER JOIN  Legal_CustomFieldTypes C ON G.GroupStepTypeID=C.FieldTypeID INNER JOIN #Temp_Customfield t
				ON t.GroupID=G.GroupID and t.Code in (''ComD'',''FilD'')
				WHERE C.FieldTypeID=1 and C.Code in (''ComD'',''FilD'')

				--	IssD
				UPDATE #Temp_Customfield
				SET value= convert(varchar(19),convert (datetime,Getdate()),101)
				Where Code=''IssD''


				--	Defendant 1
				UPDATE #Temp_Customfield
				SET value= CASE WHEN t.Code=''C'' THEN ''M''  
								WHEN t.Code=''I'' THEN ''P''  
								WHEN t.Code=''B'' THEN ''''
								WHEN t.Code=''A'' THEN ''''
						   END  
							FROM legal_groupdebtors l INNER JOIN Legal_LegalTypes T ON T.LegalTypeID=l.LegalTypeID
							INNER JOIN  Legal_GroupSteps G ON l.GroupID=G.GroupID 
							INNER JOIN #Temp_Customfield C ON G.GroupID=C.GroupID 
							WHERE C.Code = ''SrvM1''and l.DefendantNum=1 and l.IsDefendant=1  
							
				--	Defendant 2
				UPDATE #Temp_Customfield
				SET value= CASE WHEN t.Code=''C'' THEN ''M''  
								WHEN t.Code=''I'' THEN ''P''  
								WHEN t.Code=''B'' THEN ''''
								WHEN t.Code=''A'' THEN ''''
						   END  
							FROM legal_groupdebtors l INNER JOIN Legal_LegalTypes T ON T.LegalTypeID=l.LegalTypeID
							INNER JOIN  Legal_GroupSteps G ON l.GroupID=G.GroupID 
							INNER JOIN #Temp_Customfield C ON G.GroupID=C.GroupID 
							WHERE C.Code = ''SrvM2''and l.DefendantNum=2 and l.IsDefendant=1  
				
				--	Defendant 3
				UPDATE #Temp_Customfield
				SET value= CASE WHEN t.Code=''C'' THEN ''M''  
								WHEN t.Code=''I'' THEN ''P''  
								WHEN t.Code=''B'' THEN ''''
								WHEN t.Code=''A'' THEN ''''
						   END  
							FROM legal_groupdebtors l INNER JOIN Legal_LegalTypes T ON T.LegalTypeID=l.LegalTypeID
							INNER JOIN  Legal_GroupSteps G ON l.GroupID=G.GroupID 
							INNER JOIN #Temp_Customfield C ON G.GroupID=C.GroupID 
							WHERE C.Code = ''SrvM3''and l.DefendantNum=3 and l.IsDefendant=1 
										
				--	Defendant 4
				UPDATE #Temp_Customfield
				SET value= CASE WHEN t.Code=''C'' THEN ''M''  
								WHEN t.Code=''I'' THEN ''P''  
								WHEN t.Code=''B'' THEN ''''
								WHEN t.Code=''A'' THEN ''''
						   END  
							FROM legal_groupdebtors l INNER JOIN Legal_LegalTypes T ON T.LegalTypeID=l.LegalTypeID
							INNER JOIN  Legal_GroupSteps G ON l.GroupID=G.GroupID 
							INNER JOIN #Temp_Customfield C ON G.GroupID=C.GroupID 
							WHERE C.Code = ''SrvM4''and l.DefendantNum=4 and l.IsDefendant=1  
							
				--	Defendant 5
				UPDATE #Temp_Customfield
				SET value= CASE WHEN t.Code=''C'' THEN ''M''  
								WHEN t.Code=''I'' THEN ''P''  
								WHEN t.Code=''B'' THEN ''''
								WHEN t.Code=''A'' THEN ''''
						   END  
							FROM legal_groupdebtors l INNER JOIN Legal_LegalTypes T ON T.LegalTypeID=l.LegalTypeID
							INNER JOIN  Legal_GroupSteps G ON l.GroupID=G.GroupID 
							INNER JOIN #Temp_Customfield C ON G.GroupID=C.GroupID 
							WHERE C.Code = ''SrvM5''and l.DefendantNum=5 and l.IsDefendant=1  
				
				--	Defendant 6
				UPDATE #Temp_Customfield
				SET value= CASE WHEN t.Code=''C'' THEN ''M''  
								WHEN t.Code=''I'' THEN ''P''  
								WHEN t.Code=''B'' THEN ''''
								WHEN t.Code=''A'' THEN ''''
						   END  
							FROM legal_groupdebtors l INNER JOIN Legal_LegalTypes T ON T.LegalTypeID=l.LegalTypeID
							INNER JOIN  Legal_GroupSteps G ON l.GroupID=G.GroupID 
							INNER JOIN #Temp_Customfield C ON G.GroupID=C.GroupID 
							WHERE C.Code = ''SrvM6''and l.DefendantNum=6 and l.IsDefendant=1  

			END	-- SUMISS


		/*************************
		 Summons Served
		*************************/
		ELSE IF @StepTypeCode = ''SUMSRV''
			BEGIN	--	SUMSRV
				
					--ComD
					SELECT @cdate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''ComD'' and T.Code=''SUMISS''and S.GroupID=@GroupID
					
					--FilD
					SELECT @filedate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''FilD'' and T.Code=''SUMISS''and S.GroupID=@GroupID
					--IssD
					SELECT @issuedate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''IssD'' and T.Code=''SUMISS''and S.GroupID=@GroupID

					 --ComD
					UPDATE #Temp_Customfield
					SET value=convert(varchar(19),convert (datetime,@cdate),101) where Code=''ComD''
					--FilD
					UPDATE #Temp_Customfield
					SET value=convert(varchar(19),convert (datetime,@filedate),101) where Code=''FilD''
					--IssD
					UPDATE #Temp_Customfield
					SET value=convert(varchar(19),convert (datetime,@filedate),101) where Code=''IssD''
					
			END	--	SUMSRV

		/*************************
		 Judgement Applied
		*************************/
		ELSE IF @StepTypeCode = ''JUDAPP''			

				BEGIN	--	JUDAPP

					
					--	CmDt,FlDt
					UPDATE #Temp_Customfield
					SET value= convert(varchar(19),convert (datetime,Getdate()),101)
					Where Code=''CmDt'' or Code=''FlDt'';
					
					--EdiM
					SELECT @edi=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''EdiM'' and T.Code=''SUMREQ''and S.GroupID=@GroupID
					
				  UPDATE #Temp_Customfield
					SET Value= @edi 
					WHERE 	Code=''EdiM''
				
					--PPJ
					SELECT @commdate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''ComD'' and T.Code=''SUMREQ''and S.GroupID=@GroupID
		
		
				SELECT @sumamount=  ISNULL(SUM(T.TransactionAmount),0.00) FROM Transactions T 
								   WHERE (T.TransactionType=901 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') 
										AND T.Datetopost between @commdate and getdate() AND T.AccountID=@AccountID
				
				UPDATE #Temp_Customfield
				SET Value= @sumamount 
				WHERE 	Code=''PPJ''
				--------------------------------------INTEREST BREAK DOWN -----------------------------------------------
				--Select transactionid for last interestcharge

				SELECT @TransactionID =ISNULL((SELECT TOP 1 T.TransactionID FROM Transactions T  INNER JOIN TransactionType ty ON T.TransactionType=ty.ID 
			    WHERE AccountID=@AccountID AND ty.TransactionCode=''Intr'' ORDER BY TransactionID DESC),0) 

				UPDATE CWX_InterestBreakdown
				SET TransactionTypeID=@TransactionID
					WHERE AccountID=@AccountID and TransactionTypeID=0
				
			END	--	JUDAPP	

			

		/*************************
		 Judgement Entered
		*************************/
		ELSE IF @StepTypeCode = ''JUDENT''

			BEGIN--JUDENT

					--''JudEnt''
					UPDATE #Temp_Customfield
					SET value= convert(varchar(19),convert (datetime,Getdate()),101)
					Where Code=''JudEnt'' ;
				
									
					--CmDt
					SELECT @cdate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''CmDt'' and T.Code=''JUDAPP''and S.GroupID=@GroupID
					
					--FiDt
					SELECT @filedate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''FlDt'' and T.Code=''JUDAPP''and S.GroupID=@GroupID
					
					--EdiM
					SELECT @edi=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''EdiM'' and T.Code=''JUDAPP''and S.GroupID=@GroupID
					
				--CmDt
				UPDATE #Temp_Customfield
				SET value=convert(varchar(19),convert (datetime,@cdate),101) where Code=''CmDt''
				--FiDt
				UPDATE #Temp_Customfield
				SET value=convert(varchar(19),convert (datetime,@filedate),101) where Code=''FiDt''
				--EdiM
				UPDATE #Temp_Customfield
				SET value=@edi where Code=''EdiM''	

			END--JUDENT

		/*************************
		 Exam Request
		*************************/
		ELSE IF @StepTypeCode = ''EXMREQ''
			BEGIN
			 
			-- 	CmDt,FiDt

					UPDATE #Temp_Customfield
					SET value= convert(varchar(19),convert (datetime,Getdate()),101)
					Where Code=''CmDt'' or Code=''FiDt'';

				--	EdIM

					 SELECT @edi=L.Value FROM Legal_CustomFields L INNER JOIN
					 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
					 WHERE C.Code=''EdiM'' and T.Code=''JUDAPP''and S.GroupID=@GroupID

				---- 	PyPJ
						SELECT @commdate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''CmDt'' and T.Code=''JUDAPP''and S.GroupID=@GroupID
		
		
				SELECT @sumamount=  ISNULL(SUM(T.TransactionAmount),0.00) FROM Transactions T 
								   WHERE (T.TransactionType=901 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') 
										AND T.Datetopost between @commdate and getdate() AND T.AccountID=@AccountID
				
				--EDI
				UPDATE #Temp_Customfield
				SET value=@edi where Code=''EdiM''
				--PyPJ	 
				UPDATE #Temp_Customfield
				SET Value= @sumamount 
				WHERE 	Code=''PyPJ''

				--------------------------------------INTEREST BREAK DOWN -----------------------------------------------
				--Select transactionid for last interestcharge

				SELECT @TransactionID =ISNULL((SELECT TOP 1 T.TransactionID FROM Transactions T  INNER JOIN TransactionType ty ON T.TransactionType=ty.ID 
			    WHERE AccountID=@AccountID AND ty.TransactionCode=''Intr'' ORDER BY TransactionID DESC),0) 

				UPDATE CWX_InterestBreakdown
				SET TransactionTypeID=@TransactionID
					WHERE AccountID=@AccountID and TransactionTypeID=0

			END

		/*************************
		 Exam Issued
		*************************/
		ELSE IF @StepTypeCode = ''EXMISS''
			BEGIN

				-- IssDt

				UPDATE #Temp_Customfield
					SET value= convert(varchar(19),convert (datetime,Getdate()),101)
					Where Code=''IssDt'' 

				--CmDt
					SELECT @cdate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''CmDt'' and T.Code=''EXMREQ''and S.GroupID=@GroupID
					
					--FiDt
					SELECT @filedate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''FiDt'' and T.Code=''EXMREQ''and S.GroupID=@GroupID

						

				  --CmDt
				UPDATE #Temp_Customfield
				SET value=convert(varchar(19),convert (datetime,@cdate),101) where Code=''CmDt''
				--FiDt
				UPDATE #Temp_Customfield
				SET value=convert(varchar(19),convert (datetime,@filedate),101) where Code=''FiDt''

			END

		/*************************
		 Exam Served
		*************************/
		ELSE IF @StepTypeCode = ''EXMSRV''
			BEGIN
				--CmDt
					SELECT @cdate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''CmDt'' and T.Code=''EXMISS''and S.GroupID=@GroupID
					
					--FiDt
					SELECT @filedate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''FiDt'' and T.Code=''EXMISS''and S.GroupID=@GroupID
					--IssDt
					SELECT @issuedate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''IssDt'' and T.Code=''EXMISS''and S.GroupID=@GroupID

					 --CmDt
					UPDATE #Temp_Customfield
					SET value=convert(varchar(19),convert (datetime,@cdate),101) where Code=''CmDt''
					--FiDt
					UPDATE #Temp_Customfield
					SET value=convert(varchar(19),convert (datetime,@filedate),101) where Code=''FiDt''
					--IssDt
					UPDATE #Temp_Customfield
					SET value=convert(varchar(19),convert (datetime,@filedate),101) where Code=''IssDt''
					
			END

		/*************************
		 Warrant Request
		*************************/
		ELSE IF @StepTypeCode = ''WARREQ''
			BEGIN

				 -- 	CmDt,FiDt

					UPDATE #Temp_Customfield
					SET value= convert(varchar(19),convert (datetime,Getdate()),101)
					Where Code=''CmDt'' or Code=''FiDt'';

				--	EdIM

					 SELECT @edi=L.Value FROM Legal_CustomFields L INNER JOIN
					 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
					 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
					 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
					 WHERE C.Code=''EdiM'' and T.Code=''JUDAPP''and S.GroupID=@GroupID

				-- SOS
						UPDATE #Temp_Customfield
						SET Value= G.StateServiced FROM Legal_Groups G INNER JOIN  #Temp_Customfield T
						ON G.GroupID=T.GroupID AND G.GroupedAccountID= @AccountID
						Where T.Code=''SoS''	
				-- 	PyPJ
						SELECT @commdate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''CmDt'' and T.Code=''JUDAPP''and S.GroupID=@GroupID
		
		
				SELECT @sumamount=  ISNULL(SUM(T.TransactionAmount),0.00) FROM Transactions T 
								   WHERE (T.TransactionType=901 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') 
										AND T.Datetopost between @commdate and getdate() AND T.AccountID=@AccountID
				
				UPDATE #Temp_Customfield
				SET value=@edi where Code=''EdiM''
						 
				UPDATE #Temp_Customfield
				SET Value= @sumamount 
				WHERE 	Code=''PyPJ''

				--------------------------------------INTEREST BREAK DOWN -----------------------------------------------
				--Select transactionid for last interestcharge

				SELECT @TransactionID =ISNULL((SELECT TOP 1 T.TransactionID FROM Transactions T  INNER JOIN TransactionType ty ON T.TransactionType=ty.ID 
			    WHERE AccountID=@AccountID AND ty.TransactionCode=''Intr'' ORDER BY TransactionID DESC),0) 

				UPDATE CWX_InterestBreakdown
				SET TransactionTypeID=@TransactionID
					WHERE AccountID=@AccountID and TransactionTypeID=0

			END

		/*************************
		 Warrant Issued
		*************************/
		ELSE IF @StepTypeCode = ''WARISS''
			BEGIN
			
				-- WrIsDt

				UPDATE #Temp_Customfield
					SET value= convert(varchar(19),convert (datetime,Getdate()),101)
					Where Code=''WrIsDt'' 

				--CmDt
					SELECT @cdate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''CmDt'' and T.Code=''WARREQ''and S.GroupID=@GroupID
					
					--FiDt
					SELECT @filedate=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''FlDt'' and T.Code=''WARREQ''and S.GroupID=@GroupID

						--EdiM
						 SELECT @edi=L.Value FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''EdiM'' and T.Code=''WARREQ''and S.GroupID=@GroupID


				  --CmDt
				UPDATE #Temp_Customfield
				SET value=convert(varchar(19),convert (datetime,@cdate),101) where Code=''CmDt''
				--FiDt
				UPDATE #Temp_Customfield
				SET value=convert(varchar(19),convert (datetime,@filedate),101) where Code=''FiDt''

				UPDATE #Temp_Customfield
				SET value=@edi where Code=''EdiM''

			END
	

	/************************
	Update custom field value(s)
	************************/	
	UPDATE [Legal_CustomFields] 
	SET [Value] = tempCustomFields.Value
	FROM [Legal_CustomFields] A
	INNER JOIN  Legal_CustomFieldTypes B
		ON A.CustomFieldTypeID = B.CustomFieldTypeID
	INNER JOIN #Temp_Customfield tempCustomFields
		ON	B.Code = tempCustomFields.Code AND A.ActivityID = tempCustomFields.ActivityID
			AND A.ActivityType = @ActivityTypeID;


	DROP TABLE #Temp_Customfield;
	DROP TABLE #groupedAccounts;
	

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateInterestAmount]    Script Date: 02/26/2009 18:38:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateInterestAmount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateInterestAmount]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;

	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25)
	DECLARE @startdate datetime
	DECLARE @enddate datetime
	DECLARE @iExistTransactions int 
	DECLARE @iNewTransactions int
	DECLARE @tranAmount Money
	DECLARE @Gcode varchar(20)
	DECLARE @DatefoTran datetime
	DECLARE @maxSN int
	DECLARE @count int
	DECLARE @interesttable varchar(20)
	DECLARE @AcctID INT 
	DECLARE @instartdate datetime 
	DECLARE @inenddate datetime
	DECLARE @LastSN int
	DECLARE @firstSN int
	DECLARE @IntRate Varchar(50)
	DECLARE @GroupID INT
	DECLARE @interestCharges INT
    DECLARE @Interest Money
	DECLARE @Maxcount INT
	DECLARE @DebtAmount Money
	DECLARE @ID INT

	SELECT @Interest = 0			
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID

			CREATE TABLE #groupedAccounts(SN INT IDENTITY(1,1),AccountID INT )
			INSERT INTO #groupedAccounts
			SELECT AccountID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
			ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

			CREATE TABLE #Temp_Interestcharge1(SN int identity(1,1),TransactionID int,AccountID int,TransactionAmount money,DateofTransaction smalldatetime ,Interestrate Real,Billbalance money,startdate smalldatetime,Enddate smalldatetime,numberofdays int,Interestcharged money,AffectBalance tinyint)
			CREATE TABLE #Temp_Interestcharge(SN int identity(1,1),TransactionID int,AccountID int,TransactionAmount money,DateofTransaction smalldatetime ,Interestrate Real,Billbalance money,startdate smalldatetime,Enddate smalldatetime,numberofdays int,Interestcharged money,AffectBalance tinyint)
			CREATE TABLE #Transactions(SN int identity(1,1),TransactionID int,AccountID int,AccountNumber varchar(20),TransactionAmount money )
			CREATE TABLE #Temp_TotalInterestcharged(SN int identity(1,1),TransactionID int,AccountID int,TransactionAmount money,DateofTransaction smalldatetime ,Interestrate Real,Billbalance money,startdate smalldatetime,Enddate smalldatetime,numberofdays int,Interestcharged money,AffectBalance tinyint)
			CREATE TABLE #Temp_TieredInterestcharge(SN int identity(1,1) ,TransactionID int,AccountID int,TransactionAmount money,DateofTransaction smalldatetime ,Interestrate Real,Billbalance money,startdate smalldatetime,Enddate smalldatetime,numberofdays int,Interestcharged money,AffectBalance tinyint)
			CREATE TABLE #Temp_tieredrate(SN int identity(1,1),TransactionID int,AccountID int,TransactionAmount money,DateofTransaction smalldatetime ,Interestrate Real,Billbalance money,startdate smalldatetime,Enddate smalldatetime,numberofdays int,Interestcharged money,AffectBalance tinyint)
			CREATE TABLE #Temp_Getallpayments (SN int identity(1,1),TransactionID int,AccountID int)

	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
	BEGIN
			
			
			SELECT @Maxcount = MAX(SN) FROM #groupedAccounts
			DECLARE @SN INT
			SET @SN =1

			WHILE (@SN<=@Maxcount)
			BEGIN
	   
				
				---***Get all Accounts included in a Groups***---
		

				SELECT @startdate=O.Date18 FROM Accountother O INNER JOIN #groupedAccounts g ON O.AccountID=g.AccountID AND g.SN=@SN
				SELECT @enddate= O.Date19 FROM Accountother O INNER JOIN #groupedAccounts g ON O.AccountID=g.AccountID  AND g.SN=@SN

				---***Create #Temp_Interestcharge to get transactions for a groupedAccount***---


				INSERT INTO #Temp_Interestcharge1
				SELECT 0,T.AccountID,T.TransactionAmount,T.DateToPost,A.InterestRate,A.Billbalance,ISNULL(O.Date18,''01-01-1900'') as startdate,ISNULL(O.Date19,''01-01-1900'') as Enddate,0,0,2 From Transactions T INNER JOIN #groupedAccounts g ON T.AccountID=g.AccountID INNER JOIN Account A ON A.AccountID=T.AccountID INNER JOIN AccountOther O ON 
					A.AccountID = O.AccountID  Where T.datetopost Between O.Date18 and O.Date19 AND g.SN=@SN
				    AND (T.Transactiontype=901 AND TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'' )

				INSERT INTO #Temp_Interestcharge1
				SELECT 0,T.AccountID,T.TransactionAmount,T.DateToPost,A.InterestRate,A.Billbalance,ISNULL(O.Date18,''01-01-1900'') as startdate,ISNULL(O.Date19,''01-01-1900'') as Enddate,0,0,ty.AffectBalance From Transactions T INNER JOIN #groupedAccounts g ON T.AccountID=g.AccountID INNER JOIN Account A ON A.AccountID=T.AccountID INNER JOIN AccountOther O ON 
					A.AccountID = O.AccountID INNER JOIN TransactionType ty ON T.TransactionType=ty.ID  Where T.datetopost Between O.Date18 and O.Date19 AND g.SN=@SN
				    AND (ty.AffectBalance <>0 AND T.Transactiontype=1 AND T.Descriptor=''O'' and TransactionComment not like''MIGR%'')
				
				INSERT INTO #Temp_Interestcharge1
				SELECT 0,T.AccountID,T.TransactionAmount,O.Date18,A.InterestRate,A.Billbalance,ISNULL(O.Date18,''01-01-1900'') as startdate,ISNULL(O.Date19,''01-01-1900'') as Enddate,0,0,ty.AffectBalance From Transactions T INNER JOIN #groupedAccounts g ON T.AccountID=g.AccountID INNER JOIN Account A ON A.AccountID=T.AccountID INNER JOIN AccountOther O ON 
					A.AccountID = O.AccountID INNER JOIN TransactionType ty ON T.TransactionType=ty.ID  Where T.datetopost Between O.Date18 and O.Date19 AND g.SN=@SN
				    AND (ty.AffectBalance <>0 AND T.Transactiontype=1 AND T.Descriptor=''O'' and TransactionComment like''MIGR%'')

						
				UPDATE #Temp_Interestcharge1
				SET DateofTransaction=O.Date18 FROM AccountOther O INNER JOIN  #Temp_Interestcharge1 T ON O.AccountID=T.AccountID
			    INNER JOIN Account A ON T.AccountID=A.AccountID	WHERE T.DateofTransaction>=A.SubmissionDate and T.AffectBalance=1

				SELECT @DatefoTran= MIN(DateofTransaction) FROM #Temp_Interestcharge1
	
				IF (@startdate < MIN(@DatefoTran))
				BEGIN
					INSERT INTO #Temp_Interestcharge1
					SELECT 0,O.AccountID,0.00,O.Date18,A.Interestrate,0.00,ISNULL(O.Date18,''01-01-1900'') as startdate,
					ISNULL(O.Date19,''01-01-1900'') as Enddate,0,0,1 From #groupedAccounts g INNER JOIN Account A ON g.AccountID=A.AccountID
					INNER JOIN AccountOther O ON A.AccountID = O.AccountID  WHERE g.SN=@SN
				END

				---***Rearrange transactions orderby DateofTransaction***---

				INSERT INTO #Temp_Interestcharge
				SELECT 0,AccountID,TransactionAmount,DateofTransaction,Interestrate,Billbalance,Startdate,Enddate,numberofdays,Interestcharged,AffectBalance 
				FROM #Temp_Interestcharge1 order by DateofTransaction

				UPDATE #Temp_Interestcharge
				SET startdate =  dateadd(minute,SN,DateOfTransaction) 

				UPDATE #Temp_Interestcharge 
				SET EndDate = ISNULL(		
					(SELECT TOP 1 startdate-1 FROM #Temp_Interestcharge 
						WHERE 
							I.AccountID = AccountID AND
							 I.SN < SN AND
							startdate >=I.startdate
						 ORDER BY DateofTransaction ASC), EndDate)
					 FROM #Temp_Interestcharge I


				SELECT @tranamount= ISNULL(sum(t.transactionamount),0.00) from transactions t,#Temp_interestcharge i,Accountother a where t.Accountid=i.AccountID
				and i.Accountid=a.Accountid and t.Transactiontype=1 and t.datetopost <a.Date18 

				
				SELECT @interestCharges = count(*) FROM #Temp_interestcharge

				IF (@interestCharges > 0)
					SELECT @tranamount =@tranamount/(SELECT count(*) FROM #Temp_interestcharge)

				UPDATE #Temp_Interestcharge
				SET TransactionAmount=@tranAmount+TransactionAmount WHERE SN=1

				UPDATE #Temp_Interestcharge
				SET Billbalance=TransactionAmount

    
				
				SELECT @maxSN=Max(SN) FROM #Temp_Interestcharge  GROUP BY Accountid
				SET @count=1

				WHILE(@count<=@maxSN)
					BEGIN
							UPDATE  #Temp_Interestcharge
									 SET Billbalance= ISNULL((SELECT TOP 1 (t2.billbalance-t.TransactionAmount)
									 FROM  #Temp_Interestcharge t2
									 WHERE t2.sn = @count-1 and t.Affectbalance=2),billbalance)
									 FROM #Temp_Interestcharge t where t.SN=@count

							UPDATE  #Temp_Interestcharge
									 SET Billbalance= ISNULL((SELECT TOP 1 (t2.billbalance+t.TransactionAmount)
									 FROM  #Temp_Interestcharge t2
									 WHERE t2.sn = @count-1 and  t.Affectbalance=1),billbalance)
									 FROM #Temp_Interestcharge t where t.SN=@count
	
						SET @count=@count+1
				END

				---***Calculates Numberofdays***--- 

				UPDATE 	#Temp_Interestcharge
				SET Numberofdays=ABS(DATEDIFF(DAY, Enddate,Startdate))+1

				---***Delete records if Numberofdays<=0***--

				DELETE FROM #Temp_Interestcharge WHERE Numberofdays<=0 

			/*=================================================================================
									TIERED RATE INTEREST CALCULATION (SUMMONS)
			==================================================================================*/

				
				select @instartdate= min(startdate) from #Temp_Interestcharge
				select @inenddate= min(enddate) from #Temp_Interestcharge where enddate is not null
				SELECT @interesttable= ao.string21 FROM Accountother ao INNER JOIN 
									 #Temp_Interestcharge t ON ao.AccountID=t.AccountID
				SELECT @AcctID = AccountID FROM #Temp_Interestcharge Group by AccountID
				
				--*** Calculating interest from interesttable  
				IF  @interesttable <>''''
				BEGIN --tiered start
						
						--Insert into Temporary table to get all tiered rate values 
						
						INSERT INTO #Temp_tieredrate
						SELECT 0,ao.AccountID,0.00,r.StartDate,r.RateAmount,0.00,r.StartDate,r.EndDate,0,0.00,0
						FROM Accountother ao INNER JOIN Legal_Rates r ON ao.String21=r.RateCode WHERE
						ao.string21=@interesttable and ao.AccountID=@AcctID

						--Select only those rates which fall between startdate of interest and enddateof interest	
						DELETE FROM #Temp_tieredrate WHERE 
						(enddate < @instartdate) and (enddate < @inenddate )               
					
						-- Set up startdate as startdate of interest(Accountother.date18)
						UPDATE #Temp_tieredrate
						SET startdate=@startdate,dateoftransaction=@startdate where startdate <@startdate

						-- Set up enddate as enddate of interest(Accountother.date19)
						UPDATE #Temp_tieredrate
						SET Enddate=@enddate where Enddate is null
					
						---merge interest rates and transactions in to #Temp_Interestcharge
						INSERT INTO #Temp_Interestcharge 
						SELECT 0,AccountID,TransactionAmount,DateofTransaction,Interestrate,
						Billbalance,Startdate,Enddate,numberofdays,Interestcharged,AffectBalance FROM
						#Temp_tieredrate 
						UPDATE #Temp_Interestcharge
						SET startdate=substring(convert(varchar(19),startdate),1,11)

						---- Insert into #Temp_TieredInterestcharge to store sorted values from #Temp_Interestcharge
					
						INSERT INTO #Temp_TieredInterestcharge
						SELECT TransactionID,AccountID,TransactionAmount,DateofTransaction,Interestrate,Billbalance,startdate,Enddate,numberofdays,Interestcharged,AffectBalance 
						FROM #Temp_Interestcharge order by startdate,Enddate

						----copies dateoftransaction to startdate

						UPDATE 	#Temp_TieredInterestcharge
						SET startdate=DateofTransaction	

						----set interestrate from legal_rates where interestrate=0

						UPDATE #Temp_TieredInterestcharge
						SET Interestrate= r.RateAmount FROM Legal_Rates r INNER JOIN 
						Accountother ao  ON ao.String21=r.RateCode INNER JOIN 
						#Temp_TieredInterestcharge t ON ao.AccountID=t.AccountID  WHERE
						ao.string21=@interesttable and ao.AccountID=@AcctID and t.Interestrate=0 
						and t.startdate between r.Startdate and ISNULL(r.Enddate,getdate())

						 ----Calculating billbalance 

						
						SELECT @LastSN=Max(SN) FROM #Temp_TieredInterestcharge  GROUP BY Accountid
						SET @firstSN=1

						WHILE(@firstSN<=@LastSN)
						BEGIN
								UPDATE  #Temp_TieredInterestcharge
									 SET Billbalance= ISNULL((SELECT TOP 1 (t2.billbalance-t.TransactionAmount)
									 FROM  #Temp_TieredInterestcharge t2
									 WHERE t2.sn = @firstSN-1 and t.Affectbalance=2),billbalance)
									 FROM #Temp_TieredInterestcharge t where t.SN=@firstSN

								UPDATE  #Temp_TieredInterestcharge
									 SET Billbalance= ISNULL((SELECT TOP 1 (t2.billbalance+t.TransactionAmount)
									 FROM  #Temp_TieredInterestcharge t2
									 WHERE t2.sn = @firstSN-1 and  t.Affectbalance in (1,0)),billbalance)
									 FROM #Temp_TieredInterestcharge t where t.SN=@firstSN
	
							SET @firstSN=@firstSN+1
						END
						---Setting Enddate

						UPDATE #Temp_TieredInterestcharge 
						SET EndDate = ISNULL(		
						(SELECT TOP 1 startdate-1 FROM #Temp_TieredInterestcharge 
							WHERE 
							I.AccountID = AccountID AND
							 I.SN < SN AND
							startdate >=I.startdate
						 ORDER BY DateofTransaction ASC),Enddate)
						 FROM #Temp_TieredInterestcharge I

						---***Calculates Numberofdays***--- 

						UPDATE 	#Temp_TieredInterestcharge
						SET Numberofdays=ABS(DATEDIFF(DAY, Enddate,Startdate))+1
		
						---Eliminate records where enddate<startdate

						DELETE FROM #Temp_TieredInterestcharge WHERE enddate<startdate
						
						---truncate table #Temp_Interestcharge to copies all records from #Temp_TieredInterestcharge
						TRUNCATE TABLE #Temp_Interestcharge
						--Insert into #Temp_Interestcharge
						INSERT INTO #Temp_Interestcharge
						SELECT 0,AccountID,TransactionAmount,DateofTransaction,Interestrate,
						Billbalance,Startdate,Enddate,numberofdays,Interestcharged,AffectBalance
						  FROM #Temp_TieredInterestcharge

				END --tiered END
			/*===========================================================================================
						FLAT RATE INTEREST CALCULATION (SUMMONS)
			==========================================================================================*/
			
	
--			END IF  @interesttable =''''
--				BEGIN-- non tiered START
				
				SELECT @IntRate= ao.string21 FROM Accountother ao INNER JOIN 
										  #groupedAccounts g ON ao.AccountID=g.AccountID WHERE g.SN=@SN 

				IF (@IntRate='''' or @IntRate IS NULL )
				BEGIN
					SELECT 	@IntRate= convert(varchar(10),A.InterestRate)+''%''	FROM Account A INNER JOIN #groupedAccounts g 
									 ON A.AccountID=g.AccountID WHERE g.SN=@SN 
					
				END
				ELSE IF(@IntRate <>'''')
				BEGIN
					SELECT 	@IntRate=  ''tiered rate table ''+ ao.string21 FROM Accountother ao INNER JOIN 
										  #groupedAccounts g ON ao.AccountID=g.AccountID WHERE g.SN=@SN 
					
				END

				---***Calculates Interestcharged ***---

				UPDATE #Temp_Interestcharge
				SET interestcharged=CASE WHEN (InterestRate <> 0 and BillBalance <> 0) THEN (ISNULL(InterestRate, 0) * ISNULL(BillBalance, 0) * numberofdays)/(365 * 100)
									ELSE 0.00 END -- Start and End Date of Interest
	
				---***Create Temporary table #Transactions***---

				INSERT INTO #Transactions 	
				SELECT 0,i.AccountID,a.invoicenumber,SUM(i.Interestcharged)FROM #Temp_Interestcharge i 
				INNER JOIN Account a ON i.AccountID=a.AccountID GROUP BY i.AccountID ,a.invoicenumber
	
				--SELECT @iExistTransactions = FieldValue	FROM IdentityFields WHERE lower(TableName) = lower(''Transactions'')
				  SELECT @iExistTransactions=ISNULL(COUNT(TransactionID),0) FROM Transactions
					
				UPDATE #Transactions
				SET  TransactionID= SN+@iExistTransactions

				SELECT @Gcode= code FROM legal_groups WHERE GroupedAccountID=@AccountID

				---***Post Comment transactions***---
 
				INSERT INTO Transactions(TransactionID,AccountID,ClerkID,clientpart,PaidWhere,ReportedToClient,OnHoldFlag,ImportedTransactionID,TransactionName
				,ShortPayment_Flag,DateOfTransaction,DateToPost,TransactionType,TransactionAmount,TransactionComment,Descriptor,TXN_POSTED)
				SELECT 
					T.TransactionID,
					T.AccountID,
					1001,
					'''',
					'''',
					0,
					'''',
					'''',
					NULL,
					'''',
					GETDATE(),
					GETDATE(),
					15,
					T.TransactionAmount,
					''Summons interest calculated, posted to group account : ''+@Gcode,
					''P'',
					''Y''
				FROM #Transactions T 
		
				SELECT @iNewTransactions =  ISNULL(COUNT(TransactionID),0) FROM Transactions
				UPDATE IdentityFields
				SET FieldValue = @iNewTransactions where lower(TableName) = lower(''Transactions'')
	
			---***Insert into CWX_InterestBreakdown***---

				INSERT INTO CWX_InterestBreakdown
				 (AccountID
				 ,TransactionTypeID
				 ,StartDate
				 ,EndDate
				 ,NumOfDays
				 ,InterestRate
				 ,DebtAmount
				 ,InterestAmount)
				SELECT 
				 i.AccountID,
				 t.TransactionID,
				 i.startdate,
				 i.enddate,
				 i.numberofdays,
				 i.interestrate,
				 i.billbalance,
				 i.Interestcharged
				FROM #Temp_Interestcharge i INNER JOIN #Transactions t ON i.AccountID=t.AccountID WHERE i.numberofdays >0

			---***Insert into NotesCurrent***---
				INSERT INTO NotesCurrent
				(EmployeeID
				,DebtorID
				,BillID
				,NoteDateTime
			    ,NoteType
			    ,NoteText)
			
				SELECT
				1001,
				A.DebtorID ,
				i.AccountID,
				Getdate(),
				''A'',
				''Summons interest calculated at ''+ @IntRate +'' for group account : ''+@Gcode

				FROM #Temp_Interestcharge i INNER JOIN Account A ON i.AccountID=A.AccountID 
			
   
	
			---*** Calculates total Interest charged for all Accounts within a group***---

			INSERT INTO #Temp_TotalInterestcharged
			SELECT 	TransactionID ,AccountID ,TransactionAmount, DateofTransaction  ,Interestrate ,Billbalance ,startdate ,Enddate ,numberofdays,Interestcharged,AffectBalance 
			FROM #Temp_Interestcharge

			Truncate Table #Temp_Interestcharge
			Truncate Table #Transactions
			Truncate Table #Temp_Interestcharge1
	
			SET @SN=@SN+1
		END
		---***Calculated interest on grouped Account***---

		SELECT @Interest =Sum(Interestcharged)	FROM #Temp_TotalInterestcharged 
		
	
	END
----------------------------------------------------------------------------------------------------------------			
	/*****************************************************************************
	 Judgement Applied, Exam Request, Warrant Request (Any step OTHER THAN SUMREQ)
	******************************************************************************/
	
	ELSE IF @StepTypeCode <> ''SUMREQ''
	BEGIN
				
	   					
				SELECT @GroupID=GroupID FROM Legal_Groups WHERE GroupedAccountID=@AccountID

				SELECT @DebtAmount= ISNULL((SELECT TOP 1 DebtAmount FROM Legal_Groupsteps S
									 WHERE  S.GroupID=@GroupID ORDER BY GroupSteptypeid DESC),0.0)

				---***get startdateof interest and enddate of interest***---

				SELECT @startdate= ISNULL((SELECT TOP 1 Convert(datetime,ISNULL(L.Value,getdate()))
								  FROM Legal_CustomFields L 
								  INNER JOIN  Legal_groupSteps S 
											ON L.ActivityID=S.GroupstepID 
								 	 WHERE S.GroupID=@GroupID ORDER BY S.GroupStepTypeID DESC),0.0)
								
				SELECT @enddate= GETDATE()

				---***Create #Temp_Interestcharge to get transactions for a groupedAccount***---
				INSERT INTO #Temp_Getallpayments
				SELECT T.TransactionID,T.AccountID FROM  Transactions T INNER JOIN #groupedAccounts g ON T.AccountID=g.AccountID INNER JOIN Account A 
						ON A.AccountID=T.AccountID   Where T.datetopost Between @startdate and @enddate 
				    AND (T.Transactiontype=901 AND TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'' )

				INSERT INTO #Temp_Interestcharge1
				SELECT 0,A.AccountID,@DebtAmount,@startdate,A.InterestRate,A.Billbalance,@startdate,@enddate,0,0,1 From #groupedAccounts g  INNER JOIN Account A 
						ON A.AccountID=g.AccountID
				
				SET @ID=1
				WHILE(SELECT Max(SN) FROM #Temp_Getallpayments)>=@ID 
					BEGIN
				   
						INSERT INTO #Temp_Interestcharge1
						SELECT 0,T.AccountID,T.TransactionAmount,T.DateToPost,A.InterestRate,A.Billbalance,@startdate,@enddate,0,0,2 From Transactions T INNER JOIN #groupedAccounts g ON T.AccountID=g.AccountID INNER JOIN Account A 
						ON A.AccountID=T.AccountID INNER JOIN #Temp_Getallpayments p ON p.TransactionID=T.ParentTransactionID   Where T.datetopost Between @startdate and @enddate 
					    AND (T.Transactiontype=1 AND TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'')
					
						SELECT @ID=@ID+1

					END
				

				INSERT INTO #Temp_Interestcharge1
				SELECT 0,T.AccountID,T.TransactionAmount,T.DateToPost,A.InterestRate,A.Billbalance,@startdate,@enddate,0,0,ty.AffectBalance From Transactions T INNER JOIN #groupedAccounts g ON T.AccountID=g.AccountID INNER JOIN Account A ON A.AccountID=T.AccountID  
					INNER JOIN TransactionType ty ON T.TransactionType=ty.ID  Where T.datetopost Between @startdate and @enddate 
				    AND (ty.AffectBalance <>0 AND T.Transactiontype=1 AND T.Descriptor=''O'' and TransactionComment not like''MIGR%'')
				
--				INSERT INTO #Temp_Interestcharge1
--				SELECT 0,T.AccountID,T.TransactionAmount,T.DateToPost,A.InterestRate,A.Billbalance,@startdate,@enddate,0,0,ty.AffectBalance From Transactions T INNER JOIN #groupedAccounts g ON T.AccountID=g.AccountID INNER JOIN Account A ON A.AccountID=T.AccountID  
--					INNER JOIN TransactionType ty ON T.TransactionType=ty.ID  Where T.datetopost Between @startdate and @enddate 
--				    AND (ty.AffectBalance <>0 AND T.Transactiontype=1 AND T.Descriptor=''O'' and TransactionComment like''MIGR%'')

					
				UPDATE #Temp_Interestcharge1
				SET DateofTransaction=StartDate FROM  #Temp_Interestcharge1 T INNER JOIN Account A ON T.AccountID=A.AccountID
										WHERE T.DateofTransaction>=A.SubmissionDate and T.AffectBalance=1


				SELECT @DatefoTran= MIN(DateofTransaction) FROM #Temp_Interestcharge1
	
				IF (@startdate < MIN(@DatefoTran))
				BEGIN
					INSERT INTO #Temp_Interestcharge1
					SELECT 0,g.AccountID,0.00,@startdate,A.Interestrate,0.00,@startdate,
					@enddate,0,0,1 From #groupedAccounts g INNER JOIN Account A ON g.AccountID=A.AccountID
					
				END

				---***Rearrange transactions orderby DateofTransaction***---

				INSERT INTO #Temp_Interestcharge
				SELECT 0,AccountID,TransactionAmount,DateofTransaction,Interestrate,Billbalance,Startdate,Enddate,numberofdays,Interestcharged,AffectBalance 
				FROM #Temp_Interestcharge1 order by DateofTransaction

				UPDATE #Temp_Interestcharge
				SET startdate =  dateadd(minute,SN,DateOfTransaction) 

				UPDATE #Temp_Interestcharge 
				SET EndDate = ISNULL(		
					(SELECT TOP 1 startdate-1 FROM #Temp_Interestcharge 
						WHERE 
							I.AccountID = AccountID AND
							 I.SN < SN AND
							startdate >=I.startdate
						 ORDER BY DateofTransaction ASC), EndDate)
					 FROM #Temp_Interestcharge I


				SELECT @tranamount= ISNULL(sum(t.transactionamount),0.00) from transactions t,#Temp_interestcharge i where t.Accountid=i.AccountID
				and t.Transactiontype=1 and t.datetopost <@startdate 

				
				SELECT @interestCharges = count(*) FROM #Temp_interestcharge

				IF (@interestCharges > 0)
					SELECT @tranamount =@tranamount/(SELECT count(*) FROM #Temp_interestcharge)

				UPDATE #Temp_Interestcharge
				SET TransactionAmount=@tranAmount+TransactionAmount WHERE SN=1

				UPDATE #Temp_Interestcharge
				SET Billbalance=TransactionAmount

    				
				SELECT @maxSN=Max(SN) FROM #Temp_Interestcharge  GROUP BY Accountid
				SET @count=1

				WHILE(@count<=@maxSN)
					BEGIN
							UPDATE  #Temp_Interestcharge
									 SET Billbalance= ISNULL((SELECT TOP 1 (t2.billbalance-t.TransactionAmount)
									 FROM  #Temp_Interestcharge t2
									 WHERE t2.sn = @count-1 and t.Affectbalance=2),billbalance)
									 FROM #Temp_Interestcharge t where t.SN=@count

							UPDATE  #Temp_Interestcharge
									 SET Billbalance= ISNULL((SELECT TOP 1 (t2.billbalance+t.TransactionAmount)
									 FROM  #Temp_Interestcharge t2
									 WHERE t2.sn = @count-1 and  t.Affectbalance=1),billbalance)
									 FROM #Temp_Interestcharge t where t.SN=@count
	
						SET @count=@count+1
				END

				---***Calculates Numberofdays***--- 

				UPDATE 	#Temp_Interestcharge
				SET Numberofdays=ABS(DATEDIFF(DAY, Enddate,Startdate))+1

				---***Delete records if Numberofdays<=0***--

				DELETE FROM #Temp_Interestcharge WHERE Numberofdays<=0 

			/*=================================================================================
									TIERED RATE INTEREST CALCULATION
			==================================================================================*/

				
				select @instartdate= min(startdate) from #Temp_Interestcharge
				select @inenddate= min(enddate) from #Temp_Interestcharge where enddate is not null
				SELECT @interesttable= ao.string21 FROM Accountother ao INNER JOIN 
									 #Temp_Interestcharge t ON ao.AccountID=t.AccountID
				SELECT @AcctID = AccountID FROM #Temp_Interestcharge Group by AccountID
				
				--*** Calculating interest from interesttable  
				IF  @interesttable <>''''
				BEGIN --tiered start
						
						--Insert into Temporary table to get all tiered rate values 
						
						INSERT INTO #Temp_tieredrate
						SELECT 0,ao.AccountID,0.00,r.StartDate,r.RateAmount,0.00,r.StartDate,r.EndDate,0,0.00,0
						FROM Accountother ao INNER JOIN Legal_Rates r ON ao.String21=r.RateCode WHERE
						ao.string21=@interesttable and ao.AccountID=@AcctID


						--Select only those rates which fall between startdate of interest and enddateof interest	
						DELETE FROM #Temp_tieredrate WHERE 
						(enddate < @instartdate) and (enddate < @inenddate )               
					
						-- Set up startdate as startdate of interest(Accountother.date18)
						UPDATE #Temp_tieredrate
						SET startdate=@startdate,dateoftransaction=@startdate where startdate <@startdate
						-- Set up enddate as enddate of interest(Accountother.date19)
						UPDATE #Temp_tieredrate
						SET Enddate=@enddate where Enddate is null
					
						---merge interest rates and transactions in to #Temp_Interestcharge
						INSERT INTO #Temp_Interestcharge 
						SELECT 0,AccountID,TransactionAmount,DateofTransaction,Interestrate,
						Billbalance,Startdate,Enddate,numberofdays,Interestcharged,AffectBalance FROM
						#Temp_tieredrate 
						UPDATE #Temp_Interestcharge
						SET startdate=substring(convert(varchar(19),startdate),1,11)

						---- Insert into #Temp_TieredInterestcharge to store sorted values from #Temp_Interestcharge
					
						INSERT INTO #Temp_TieredInterestcharge
						SELECT TransactionID,AccountID,TransactionAmount,DateofTransaction,Interestrate,Billbalance,startdate,Enddate,numberofdays,Interestcharged,AffectBalance 
						FROM #Temp_Interestcharge order by startdate,Enddate

						----copies dateoftransaction to startdate

						UPDATE 	#Temp_TieredInterestcharge
						SET startdate=DateofTransaction	

						----set interestrate from legal_rates where interestrate=0

						UPDATE #Temp_TieredInterestcharge
						SET Interestrate= r.RateAmount FROM Legal_Rates r INNER JOIN 
						Accountother ao  ON ao.String21=r.RateCode INNER JOIN 
						#Temp_TieredInterestcharge t ON ao.AccountID=t.AccountID  WHERE
						ao.string21=@interesttable and ao.AccountID=@AcctID and t.Interestrate=0 
						and t.startdate between r.Startdate and ISNULL(r.Enddate,getdate())

						 ----Calculating billbalance 
						
						SELECT @LastSN=Max(SN) FROM #Temp_TieredInterestcharge  GROUP BY Accountid
						SET @firstSN=1

						WHILE(@firstSN<=@LastSN)
						BEGIN
								UPDATE  #Temp_TieredInterestcharge
									 SET Billbalance= ISNULL((SELECT TOP 1 (t2.billbalance-t.TransactionAmount)
									 FROM  #Temp_TieredInterestcharge t2
									 WHERE t2.sn = @firstSN-1 and t.Affectbalance=2),billbalance)
									 FROM #Temp_TieredInterestcharge t where t.SN=@firstSN

								UPDATE  #Temp_TieredInterestcharge
									 SET Billbalance= ISNULL((SELECT TOP 1 (t2.billbalance+t.TransactionAmount)
									 FROM  #Temp_TieredInterestcharge t2
									 WHERE t2.sn = @firstSN-1 and  t.Affectbalance in (1,0)),billbalance)
									 FROM #Temp_TieredInterestcharge t where t.SN=@firstSN
	
							SET @firstSN=@firstSN+1
						END
						---Setting Enddate

						UPDATE #Temp_TieredInterestcharge 
						SET EndDate = ISNULL(		
						(SELECT TOP 1 startdate-1 FROM #Temp_TieredInterestcharge 
							WHERE 
							I.AccountID = AccountID AND
							 I.SN < SN AND
							startdate >=I.startdate
						 ORDER BY DateofTransaction ASC),Enddate)
						 FROM #Temp_TieredInterestcharge I

						---***Calculates Numberofdays***--- 

--						UPDATE 	#Temp_TieredInterestcharge
--						SET Numberofdays=ABS(DATEDIFF(DAY, Enddate,Startdate))+1
						UPDATE 	#Temp_TieredInterestcharge
						SET Numberofdays=ABS(DATEDIFF(DAY, Enddate,Startdate))
		
						---Eliminate records where enddate<startdate

						DELETE FROM #Temp_TieredInterestcharge WHERE enddate<startdate
						
						---truncate table #Temp_Interestcharge to copies all records from #Temp_TieredInterestcharge
						TRUNCATE TABLE #Temp_Interestcharge
						--Insert into #Temp_Interestcharge
						INSERT INTO #Temp_Interestcharge
						SELECT 0,AccountID,TransactionAmount,DateofTransaction,Interestrate,
						Billbalance,Startdate,Enddate,numberofdays,Interestcharged,AffectBalance
						  FROM #Temp_TieredInterestcharge

				END --tiered END
			/*=================================================================================
						FLAT RATE INTEREST CALCULATION 
			================================================================================*/
			
	
--			END IF  @interesttable =''''
--				BEGIN-- non tiered START
				
				SELECT @IntRate= ao.string21 FROM Accountother ao INNER JOIN 
										  #groupedAccounts g ON ao.AccountID=g.AccountID 

				IF (@IntRate='''' or @IntRate IS NULL )
				BEGIN
					SELECT 	@IntRate= convert(varchar(10),A.InterestRate)+''%''	FROM Account A INNER JOIN #groupedAccounts g 
										 ON A.AccountID=g.AccountID 
					
				END
				ELSE IF(@IntRate <>'''')
				BEGIN
					SELECT 	@IntRate=  ''tiered rate table''+ ao.string21 FROM Accountother ao INNER JOIN 
										  #groupedAccounts g ON ao.AccountID=g.AccountID 
					
				END

				---***Calculates Interestcharged ***---

				UPDATE #Temp_Interestcharge
				SET interestcharged=CASE WHEN (InterestRate <> 0 and BillBalance <> 0) THEN (ISNULL(InterestRate, 0) * ISNULL(BillBalance, 0) * numberofdays)/(365 * 100)
									ELSE 0.00 END -- Start and End Date of Interest
	

				---***Insert into CWX_InterestBreakdown***---

				INSERT INTO CWX_InterestBreakdown
				 (AccountID
				 ,TransactionTypeID
				 ,StartDate
				 ,EndDate
				 ,NumOfDays
				 ,InterestRate
				 ,DebtAmount
				 ,InterestAmount)
				SELECT 
				 @AccountID,
				 0,
				 i.startdate,
				 i.enddate,
				 i.numberofdays,
				 i.interestrate,
				 i.billbalance,
				 i.Interestcharged
				FROM #Temp_Interestcharge i 

   
	
			---*** Calculates total Interest charged for all Accounts within a group***---

			INSERT INTO #Temp_TotalInterestcharged
			SELECT 	TransactionID ,AccountID ,TransactionAmount, DateofTransaction  ,Interestrate ,Billbalance ,startdate ,Enddate ,numberofdays,Interestcharged,AffectBalance 
			FROM #Temp_Interestcharge

			
			---***Calculated interest on grouped Account***---

			SELECT @Interest =Sum(Interestcharged)	FROM #Temp_TotalInterestcharged 
		
	
	END

	/******************************************************/
	--	Update AccountOther Money5 (InterestAmount field)
		UPDATE AccountOther
			SET	Money5 = @Interest
			WHERE AccountID = @AccountID
	/******************************************************/


	SELECT ISNULL(@Interest, 0) AS ''Interest''
END 


/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_WARREQ_External]    Script Date: 02/26/2009 18:38:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_WARREQ_External]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_WARREQ_External]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;

		--Steptotal

	DECLARE @Groupstep VARCHAR(20)
	SELECT @Groupstep= Code FROM Legal_GroupStepTypes Ls INNER JOIN Legal_GroupSteps Lg ON Ls.GroupStepTypeID=@GroupStepTypeID 
	DECLARE @StepTotal money	

	IF @Groupstep =''WARREQ''
	BEGIN
			DECLARE @commdate datetime
			DECLARE @sumamount Money
			DECLARE @GroupID INT 
			SELECT @GroupID = L.GroupID FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
			ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

			SELECT @commdate=Convert(datetime,L.Value) FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''CmDt'' and T.Code=''JUDAPP''and S.GroupID=@GroupID

			SELECT @sumamount=  ISNULL(SUM(T.TransactionAmount),0.00) FROM Transactions T 
								   WHERE (T.TransactionType=901 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') 
										AND T.Datetopost between @commdate and getdate() AND T.AccountID=@AccountID
				
			SELECT @StepTotal= ((IntAmount+SolicitorFee+CourtFee+ServiceFee+AttemptedFee+
						   TravelFee+BookKeepingFee+LeavyFee+SearchFee+CustomFee1+CustomFee2+CustomFee3+CustomFee4+CustomFee5)-@sumamount)
						   FROM Legal_GroupSteps L INNER JOIN Legal_Groups lg ON L.GroupID=lg.GroupID
						   WHERE lg.GroupedAccountID=@AccountID and L.GroupID=@GroupID and L.GroupStepTypeID=@GroupStepTypeID
			
			UPDATE Legal_GroupSteps
			SET StepTotal= ISNULL(@StepTotal,0.00)
			WHERE GroupID IN (SELECT GroupID FROM Legal_Groups WHERE GroupedAccountId = @AccountID)


	--Initialise Money2/5/6/7 to 0.0
		UPDATE Accountother
		SET Money2=0.0, Money5=0.0, Money6=0.0, Money7=0.0 where AccountID=@AccountID

									
	END

	SELECT @StepTotal;

END

/**********************************************************************************************************/
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_EXMREQ_External]    Script Date: 02/26/2009 18:38:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_EXMREQ_External]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_EXMREQ_External]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;

		--Steptotal

	DECLARE @Groupstep VARCHAR(20)
	SELECT @Groupstep= Code FROM Legal_GroupStepTypes Ls INNER JOIN Legal_GroupSteps Lg ON Ls.GroupStepTypeID=@GroupStepTypeID 
	DECLARE @StepTotal money	

	IF @Groupstep =''EXMREQ''
	BEGIN
			DECLARE @commdate datetime
			DECLARE @sumamount Money
			DECLARE @GroupID INT 
			SELECT @GroupID = L.GroupID FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
			ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

			SELECT @commdate=Convert(datetime,L.Value) FROM Legal_CustomFields L INNER JOIN
						 Legal_groupSteps S ON L.ActivityID=S.GroupstepID INNER JOIN 
						 Legal_CustomFieldTypes C ON L.CustomFieldTypeID=C.CustomFieldTypeID INNER JOIN
						 Legal_GroupStepTypes T ON S.GroupStepTypeID=T.GroupStepTypeID
						 WHERE C.Code=''CmDt'' and T.Code=''JUDAPP''and S.GroupID=@GroupID

			SELECT @sumamount=  ISNULL(SUM(T.TransactionAmount),0.00) FROM Transactions T 
								   WHERE (T.TransactionType=901 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') 
										AND T.Datetopost between @commdate and getdate() AND T.AccountID=@AccountID
				
			SELECT @StepTotal= ((IntAmount+SolicitorFee+CourtFee+ServiceFee+AttemptedFee+
						   TravelFee+BookKeepingFee+LeavyFee+SearchFee+CustomFee1+CustomFee2+CustomFee3+CustomFee4+CustomFee5)-@sumamount)
						   FROM Legal_GroupSteps L INNER JOIN Legal_Groups lg ON L.GroupID=lg.GroupID
						   WHERE lg.GroupedAccountID=@AccountID and L.GroupID=@GroupID and L.GroupStepTypeID=@GroupStepTypeID
			
			UPDATE Legal_GroupSteps
			SET StepTotal= ISNULL(@StepTotal,0.00)
			WHERE GroupID IN (SELECT GroupID FROM Legal_Groups WHERE GroupedAccountId = @AccountID)

	--Initialise Money2/5/6/7 to 0.0
		UPDATE Accountother
		SET Money2=0.0, Money5=0.0, Money6=0.0, Money7=0.0 where AccountID=@AccountID

									
	END

	SELECT @StepTotal;

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineAdditionalFieldValues_OLD]    Script Date: 02/26/2009 18:38:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineAdditionalFieldValues_OLD]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineAdditionalFieldValues_OLD]
	@AccountID INT,  --Grp acct id
	@GroupStepTypeID INT,  --Step type id/Hearing type Id  eg., 1=SUMREQ, DEFEND
	@ActivityID INT, --Step id, Hearing id
	@ActivityTypeID INT  --1=GS, 2=Event
AS
BEGIN --Main
	SET NOCOUNT ON;

	DECLARE @ActTypeID INT
	SELECT @ActTypeID = FieldType FROM Legal_CustomFieldTypes
	WHERE FieldType = @ActivityTypeID
	

	IF @ActTypeID=1
	BEGIN

		DECLARE @ActID INT
--		SET @ActivityID=82
		SELECT @ActID= GroupStepID From Legal_GroupSteps WHERE GroupStepID=@ActivityID
		
		/*************************
		Get Step Type Code
		*************************/
		DECLARE @StepTypeCode VARCHAR(25);
--		SET @StepTypeCode=''SUMREQ''
		SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
		WHERE GroupStepTypeID = @GroupStepTypeID;
	
	
		/*************************
		Summons Request
		*************************/
		

				
				CREATE TABLE #groupedAccounts(SN INT IDENTITY(1,1),AccountID INT,GroupID int )
				INSERT INTO #groupedAccounts
				SELECT AccountID,L.GroupID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
				ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

			select * from #groupedAccounts
					---***Create table #Temp_Customfield***---

					CREATE TABLE #Temp_Customfield
					(GroupID int, AccountID int,CustomFieldTypeID int,GroupStepID int,Code varchar(50),FieldType int,value varchar(3000) )
					

				--select * from #Temp_Customfield where groupid=256
--				  drop table #Temp_Customfield
		IF @StepTypeCode = ''SUMREQ''
		BEGIN
					INSERT INTO #Temp_Customfield
					SELECT 
					G.GroupID as groupid,
					A.AccountID,
					C.CustomFieldTypeID as customfieldtypeid,--CustomFieldTypeID
					82,--@ActivityID as groupsteptypeid, --ActivityID
					C.Code as code,--Value
					C.FieldType,--ActivityType
					 '''' 
					FROM Legal_CustomFieldTypes C INNER JOIN Legal_GroupSteps G ON
			     	 G.GroupStepTypeID=C.FieldTypeID INNER JOIN #groupedAccounts A ON A.GroupID=G.GroupID 
					WHERE FieldTypeID=1 AND FieldType=@ActTypeID Order by G.GroupID

					UPDATE #Temp_Customfield
					SET value= convert(varchar(19),convert (datetime,Getdate()),101)
					Where Code=''ComD'' or Code=''FilD''

					UPDATE #Temp_Customfield
					SET value= CASE   WHEN G.StateServiced=''VIC'' THEN 1
									  ELSE 0  END FROM Legal_Groups G INNER JOIN  #Temp_Customfield T
									  ON G.GroupID=T.GroupID AND G.GroupedAccountID= @AccountID
									  Where T.Code=''EdiM''
					

					Declare @sumtrans money
					SELECT @sumtrans=  ISNULL(SUM(T.TransactionAmount),0.00) FROM Transactions T INNER JOIN 
							  #groupedAccounts G ON G.AccountID=T.AccountID INNER JOIN Account A ON A.AccountID=G.AccountID 
							    WHERE (T.TransactionType=901 and TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'') 
							   and T.Datetopost >= A.SubmissionDate					

					UPDATE #Temp_Customfield
					SET Value= @sumtrans WHERE 	Code=''PPS''	
					
					---***Insert into [Legal_CustomFields] for groupstep Summons Request***---

					INSERT INTO [Legal_CustomFields]
					([CustomFieldTypeID]
					 ,[ActivityID]
					 ,[Value]
					 ,[LastEditDate]
					 ,[ActivityType])
				   SELECT 
		  
					C.CustomFieldTypeID,--CustomFieldTypeID
					C.GroupStepID, --ActivityID
					C.Value,--Value
					getdate(),--LastEditDate
					C.FieldType--ActivityType
				FROM #Temp_Customfield C

			--**Truncate table #Temp_Customfield**--
	
			Truncate table #Temp_Customfield
					
		END
	
		/*************************
		 Summons Issued
		*************************/
	
		ELSE IF @StepTypeCode = ''SUMISS''
			BEGIN
				
				INSERT INTO #Temp_Customfield
					SELECT 
					G.GroupID as groupid,
					A.AccountID,
					C.CustomFieldTypeID as customfieldtypeid,--CustomFieldTypeID
					@ActivityID as groupsteptypeid, --ActivityID
					C.Code as code,--Value
					C.FieldType,--ActivityType
					 '''' 
					FROM Legal_CustomFieldTypes C INNER JOIN Legal_GroupSteps G ON
			     	 G.GroupStepTypeID=C.FieldTypeID INNER JOIN #groupedAccounts A ON A.GroupID=G.GroupID 
					WHERE FieldTypeID=2 AND FieldType=@ActTypeID Order by G.GroupID


			 UPDATE #Temp_Customfield
			 SET value= L.value FROM Legal_CustomFields L INNER JOIN Legal_GroupSteps G ON L.ActivityID=G.GroupStepID
						INNER JOIN  Legal_CustomFieldTypes C ON G.GroupStepTypeID=C.FieldTypeID INNER JOIN #Temp_Customfield t
						ON t.GroupID=G.GroupID and t.Code in (''ComD'',''FilD'')
						WHERE C.FieldTypeID=1 and C.Code in (''ComD'',''FilD'')
			
			UPDATE #Temp_Customfield
			SET value= convert(varchar(19),convert (datetime,Getdate()),101)
					Where Code=''IssD''

			--***For Defendent 1***--
			UPDATE #Temp_Customfield
			SET value= CASE WHEN t.Code=''C'' THEN ''M''  
							WHEN t.Code=''I'' THEN ''P''  
							WHEN t.Code=''B'' THEN ''''
					   END  
						FROM legal_groupdebtors l INNER JOIN Legal_LegalTypes T ON T.LegalTypeID=l.LegalTypeID
						INNER JOIN  Legal_GroupSteps G ON l.GroupID=G.GroupID 
						INNER JOIN #Temp_Customfield C ON G.GroupID=C.GroupID 
						WHERE C.Code = ''SrvM1''and l.DefendantNum=1 and l.IsPrincipal=1 and l.IsInclude=1 and l.IsDefendant=1  
						
			--***For Defendent 2***--
			UPDATE #Temp_Customfield
			SET value= CASE WHEN t.Code=''C'' THEN ''M''  
							WHEN t.Code=''I'' THEN ''P''  
							WHEN t.Code=''B'' THEN ''''
					   END  
						FROM legal_groupdebtors l INNER JOIN Legal_LegalTypes T ON T.LegalTypeID=l.LegalTypeID
						INNER JOIN  Legal_GroupSteps G ON l.GroupID=G.GroupID 
						INNER JOIN #Temp_Customfield C ON G.GroupID=C.GroupID 
						WHERE C.Code = ''SrvM2''and l.DefendantNum=2 and l.IsPrincipal=1 and l.IsInclude=1 and l.IsDefendant=1  
			
			--***For Defendent 3***--
			UPDATE #Temp_Customfield
			SET value= CASE WHEN t.Code=''C'' THEN ''M''  
							WHEN t.Code=''I'' THEN ''P''  
							WHEN t.Code=''B'' THEN ''''
					   END  
						FROM legal_groupdebtors l INNER JOIN Legal_LegalTypes T ON T.LegalTypeID=l.LegalTypeID
						INNER JOIN  Legal_GroupSteps G ON l.GroupID=G.GroupID 
						INNER JOIN #Temp_Customfield C ON G.GroupID=C.GroupID 
						WHERE C.Code = ''SrvM3''and l.DefendantNum=3 and l.IsPrincipal=1 and l.IsInclude=1 and l.IsDefendant=1 
									
			--***For Defendent 4***--
			UPDATE #Temp_Customfield
			SET value= CASE WHEN t.Code=''C'' THEN ''M''  
							WHEN t.Code=''I'' THEN ''P''  
							WHEN t.Code=''B'' THEN ''''
					   END  
						FROM legal_groupdebtors l INNER JOIN Legal_LegalTypes T ON T.LegalTypeID=l.LegalTypeID
						INNER JOIN  Legal_GroupSteps G ON l.GroupID=G.GroupID 
						INNER JOIN #Temp_Customfield C ON G.GroupID=C.GroupID 
						WHERE C.Code = ''SrvM4''and l.DefendantNum=4 and l.IsPrincipal=1 and l.IsInclude=1 and l.IsDefendant=1  
						
			--***For Defendent 5***--
			UPDATE #Temp_Customfield
			SET value= CASE WHEN t.Code=''C'' THEN ''M''  
							WHEN t.Code=''I'' THEN ''P''  
							WHEN t.Code=''B'' THEN ''''
					   END  
						FROM legal_groupdebtors l INNER JOIN Legal_LegalTypes T ON T.LegalTypeID=l.LegalTypeID
						INNER JOIN  Legal_GroupSteps G ON l.GroupID=G.GroupID 
						INNER JOIN #Temp_Customfield C ON G.GroupID=C.GroupID 
						WHERE C.Code = ''SrvM5''and l.DefendantNum=5 and l.IsPrincipal=1 and l.IsInclude=1 and l.IsDefendant=1  
			
			--***For Defendent 6***--
			UPDATE #Temp_Customfield
			SET value= CASE WHEN t.Code=''C'' THEN ''M''  
							WHEN t.Code=''I'' THEN ''P''  
							WHEN t.Code=''B'' THEN ''''
					   END  
						FROM legal_groupdebtors l INNER JOIN Legal_LegalTypes T ON T.LegalTypeID=l.LegalTypeID
						INNER JOIN  Legal_GroupSteps G ON l.GroupID=G.GroupID 
						INNER JOIN #Temp_Customfield C ON G.GroupID=C.GroupID 
						WHERE C.Code = ''SrvM6''and l.DefendantNum=6 and l.IsPrincipal=1 and l.IsInclude=1 and l.IsDefendant=1  
								
			---***Insert into [Legal_CustomFields] for groupstep Summons Issue***---

					INSERT INTO [Legal_CustomFields]
					([CustomFieldTypeID]
					 ,[ActivityID]
					 ,[Value]
					 ,[LastEditDate]
					 ,[ActivityType])
				   SELECT 
		  
					C.CustomFieldTypeID,--CustomFieldTypeID
					C.GroupStepID, --ActivityID
					C.Value,--Value
					getdate(),--LastEditDate
					C.FieldType--ActivityType
				FROM #Temp_Customfield C

			--**Truncate table #Temp_Customfield**--
	
			Truncate table #Temp_Customfield


	END
		/*************************
		 Summons Served
		*************************/
		ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN

				INSERT INTO #Temp_Customfield
					SELECT 
					G.GroupID as groupid,
					A.AccountID,
					C.CustomFieldTypeID as customfieldtypeid,--CustomFieldTypeID
					@ActivityID as groupsteptypeid, --ActivityID
					C.Code as code,--Value
					C.FieldType,--ActivityType
					 '''' 
					FROM Legal_CustomFieldTypes C INNER JOIN Legal_GroupSteps G ON
			     	 G.GroupStepTypeID=C.FieldTypeID INNER JOIN #groupedAccounts A ON A.GroupID=G.GroupID 
					WHERE FieldTypeID=3 AND FieldType=@ActTypeID Order by G.GroupID	

	select * from #Temp_Customfield

					UPDATE #Temp_Customfield
					SET value= L.value FROM Legal_CustomFields L INNER JOIN Legal_GroupSteps G ON L.ActivityID=G.GroupStepID
						INNER JOIN  Legal_CustomFieldTypes C ON G.GroupStepTypeID=C.FieldTypeID INNER JOIN #Temp_Customfield t
						ON t.GroupID=G.GroupID and t.Code =''ComD''
						WHERE C.FieldTypeID=2 and C.Code =''ComD''

					UPDATE #Temp_Customfield
					SET value= L.value FROM Legal_CustomFields L INNER JOIN Legal_GroupSteps G ON L.ActivityID=G.GroupStepID
						INNER JOIN  Legal_CustomFieldTypes C ON G.GroupStepTypeID=C.FieldTypeID INNER JOIN #Temp_Customfield t
						ON t.GroupID=G.GroupID and t.Code =''FilD''
						WHERE C.FieldTypeID=2 and C.Code =''FilD''

				   UPDATE #Temp_Customfield
					SET value= L.value FROM Legal_CustomFields L INNER JOIN Legal_GroupSteps G ON L.ActivityID=G.GroupStepID
						INNER JOIN  Legal_CustomFieldTypes C ON G.GroupStepTypeID=C.FieldTypeID INNER JOIN #Temp_Customfield t
						ON t.GroupID=G.GroupID and t.Code =''IssD''
						WHERE C.FieldTypeID=2 and C.Code =''IssD''

				---***Insert into [Legal_CustomFields] for groupstep Summons Serviced***---

					INSERT INTO [Legal_CustomFields]
					([CustomFieldTypeID]
					 ,[ActivityID]
					 ,[Value]
					 ,[LastEditDate]
					 ,[ActivityType])
				   SELECT 
		  
					C.CustomFieldTypeID,--CustomFieldTypeID
					C.GroupStepID, --ActivityID
					C.Value,--Value
					getdate(),--LastEditDate
					C.FieldType--ActivityType
				FROM #Temp_Customfield C




		END

		
END--Activityid=1

--ELSE IF @ActivityTypeID=2
--	BEGIN
--
--
--	END--Activityid=2

END--Main ' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalDefendant_Get]    Script Date: 02/26/2009 18:38:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalDefendant_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_LegalDefendant_Get]
	@AccountID INT,
	@GroupDebtorID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @GroupID INT
	/*** Get group id ***/
	SELECT @GroupID = ISNULL(A.GroupID, 0)
	FROM Legal_Groups A 
	WHERE A.GroupedAccountID = @AccountID

	
    SELECT A.GroupDebtorID, A.GroupID, A.DebtorID, A.AccountID, A.IsPrincipal, A.PersonID, A.DefendantNum, 
			B.FirstName + '' '' + B.LastName [Name], 
			C.InvoiceNumber, D.IsServed, D.Attempts, D.ServedDate, D.ServedBy
	FROM Legal_GroupDebtors A
	INNER JOIN PersonInformation B ON A.PersonID = B.PersonID
	INNER JOIN Account C ON A.AccountID = C.AccountID 
	LEFT JOIN WF_Legal_ServedSummons D ON A.GroupDebtorID = D.GroupDebtorID
	WHERE A.GroupDebtorID = @GroupDebtorID AND A.GroupID = @GroupID
	ORDER BY A.DefendantNum

END



/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineStateServiced]    Script Date: 02/26/2009 18:38:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineStateServiced]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineStateServiced]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @StateServiced VARCHAR(100)
	
	SELECT @StateServiced = 
		CASE WHEN  ISNULL(Formula_Flag, '''') IN (''VIC'',''SA'',''NT'',''TAS'',''ACT'', ''WA'') THEN ''VIC''
			 ELSE ISNULL(Formula_Flag, '''')
		END
	FROM Account 
	WHERE AccountID = @AccountID
	
	SELECT ISNULL(@StateServiced, '''') AS ''StateServiced''
END


 
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineGroupCode]    Script Date: 02/26/2009 18:38:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineGroupCode]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineGroupCode]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @GroupCode VARCHAR(100)
	DECLARE @Sequence INT
	SET @Sequence = 1
	
	DECLARE @CustomerNumber VARCHAR(100)
	SELECT @CustomerNumber = ISNULL(P.PString1, '''')
	FROM Account A INNER JOIN DebtorInformation D ON A.DebtorID = D.DebtorID AND A.AccountID = @AccountID
		INNER JOIN PersonInformation P ON D.PersonID = P.PersonID
	
	IF EXISTS(SELECT 1 FROM Legal_Groups 
		WHERE Code LIKE ''G-'' + @CustomerNumber + ''-%'')
	BEGIN
		SELECT TOP 1 @Sequence = CONVERT(INT, SUBSTRING(Code, CHARINDEX(''-'', Code, 3) + 1, LEN(Code))) + 1
		FROM Legal_Groups 
		WHERE Code LIKE ''G-'' + @CustomerNumber + ''-%''
		ORDER BY CODE DESC
	END
	

	SELECT @GroupCode = ''G-'' + @CustomerNumber + ''-''+ 
		CASE WHEN @Sequence < 10 THEN ''0'' ELSE '''' END + CONVERT(VARCHAR, @Sequence)
	
	SELECT ISNULL(@GroupCode, '''') AS GroupCode
	
    /*
	DECLARE @GroupCode VARCHAR(100)

	SELECT @GroupCode = ''G-'' + ISNULL(P.PString1, '''') + ''-''+ CONVERT(VARCHAR, YEAR(GETDATE()))
	FROM Account A INNER JOIN DebtorInformation D ON A.DebtorID = D.DebtorID AND A.AccountID = @AccountID
		INNER JOIN PersonInformation P ON D.PersonID = P.PersonID
	
	SELECT ISNULL(@GroupCode, '''') AS GroupCode
	*/
END


/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalDefendantList_Get]    Script Date: 02/26/2009 18:38:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalDefendantList_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_LegalDefendantList_Get]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @GroupID INT;
	
	-- get legal group id using group account id
	SELECT @GroupID = ISNULL(A.GroupID, 0)
	FROM Legal_Groups A 
	WHERE A.GroupedAccountID = @AccountID
	
	-- get defendant list using group id
    SELECT A.GroupDebtorID, A.GroupID, A.DebtorID, A.AccountID, A.IsPrincipal, A.PersonID, A.DefendantNum, 
			B.FirstName + '' '' + B.LastName [Name], 
			C.InvoiceNumber, D.IsServed, D.Attempts, D.ServedDate, D.ServedBy
	FROM Legal_GroupDebtors A
	INNER JOIN PersonInformation B ON A.PersonID = B.PersonID
	INNER JOIN Account C ON C.AccountID = @AccountID
	LEFT JOIN WF_Legal_ServedSummons D ON A.GroupDebtorID = D.GroupDebtorID
	WHERE A.IsDefendant = 1 AND A.GroupID = @GroupID AND ISNULL(D.IsServed,0) = 0 AND ISNULL(A.DebtorID, 0) > 0
	ORDER BY DefendantNum

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_ChangeAccountCollector]    Script Date: 02/26/2009 18:38:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_ChangeAccountCollector]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_ChangeAccountCollector]
	@AccountID INT,
	@EmployeeID INT
AS
BEGIN
	SET NOCOUNT ON;

    UPDATE Account 
	SET EmployeeID = @EmployeeID
	WHERE AccountID = @AccountID
END


/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineCreditorId]    Script Date: 02/26/2009 18:38:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineCreditorId]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_DefineCreditorId]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @CreditorID INT
	
	SELECT @CreditorID = ISNULL(C.CreditorID, 0)
	FROM Account A INNER JOIN ClientInformation C ON A.ClientID = C.ClientID AND
		A.AccountID = @AccountID
	
	SELECT ISNULL(@CreditorID, 0) AS ''CreditorID''
END


/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_UnserviceDefendantList_Get]    Script Date: 02/26/2009 18:38:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_UnserviceDefendantList_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_UnserviceDefendantList_Get]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @GroupID INT;
	
	-- get legal group id using group account id
	SELECT @GroupID = ISNULL(A.GroupID, 0)
	FROM Legal_Groups A 
	WHERE A.GroupedAccountID = @AccountID
	
	-- get defendant list using group id
    SELECT A.GroupDebtorID, A.GroupID, A.DebtorID, A.AccountID, A.IsPrincipal, A.PersonID, A.DefendantNum, 
			B.FirstName + '' '' + B.LastName [Name], 
			C.InvoiceNumber, D.IsServed, D.Attempts, D.ServedDate, D.ServedBy
	FROM Legal_GroupDebtors A
	INNER JOIN PersonInformation B ON A.PersonID = B.PersonID
	INNER JOIN Account C ON C.AccountID = @AccountID
	LEFT JOIN WF_Legal_ServedSummons D ON A.GroupDebtorID = D.GroupDebtorID
	WHERE A.IsDefendant = 1 AND A.GroupID = @GroupID AND ISNULL(D.IsServed,0) = 0 AND ISNULL(A.DebtorID, 0) > 0
	ORDER BY DefendantNum

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_UnserviceExamineeList_Get]    Script Date: 02/26/2009 18:38:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_UnserviceExamineeList_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_UnserviceExamineeList_Get]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @GroupID INT;
	
	-- get legal group id using group account id
	SELECT @GroupID = ISNULL(A.GroupID, 0)
	FROM Legal_Groups A 
	WHERE A.GroupedAccountID = @AccountID
	
	-- get defendant list using group id
    SELECT A.GroupDebtorID, A.GroupID, A.DebtorID, A.AccountID, A.IsPrincipal, A.PersonID, A.DefendantNum, 
			B.FirstName + '' '' + B.LastName [Name], 
			C.InvoiceNumber, D.IsServed, D.Attempts, D.ServedDate, D.ServedBy
	FROM Legal_GroupDebtors A
	INNER JOIN PersonInformation B ON A.PersonID = B.PersonID
	INNER JOIN Account C ON C.AccountID = @AccountID
	LEFT JOIN WF_Legal_ServedExams D ON A.GroupDebtorID = D.GroupDebtorID
	WHERE A.IsDefendant = 1 AND A.GroupID = @GroupID AND ISNULL(D.IsServed,0) = 0 AND ISNULL(A.DebtorID, 0) > 0
	ORDER BY DefendantNum

END

 
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON


/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_LegalExaminee_Get]    Script Date: 02/26/2009 18:38:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_LegalExaminee_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_LegalExaminee_Get]
	@AccountID INT,
	@GroupDebtorID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @GroupID INT
	/*** Get group id ***/
	SELECT @GroupID = ISNULL(A.GroupID, 0)
	FROM Legal_Groups A 
	WHERE A.GroupedAccountID = @AccountID

	
    SELECT A.GroupDebtorID, A.GroupID, A.DebtorID, A.AccountID, A.IsPrincipal, A.PersonID, A.DefendantNum, 
			B.FirstName + '' '' + B.LastName [Name], 
			C.InvoiceNumber, D.IsServed, D.Attempts, D.ServedDate, D.ServedBy
	FROM Legal_GroupDebtors A
	INNER JOIN PersonInformation B ON A.PersonID = B.PersonID
	INNER JOIN Account C ON A.AccountID = C.AccountID 
	LEFT JOIN WF_Legal_ServedExams D ON A.GroupDebtorID = D.GroupDebtorID
	WHERE A.GroupDebtorID = @GroupDebtorID AND A.GroupID = @GroupID
	ORDER BY A.DefendantNum

END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_CalculateInterestAmount_old]    Script Date: 02/26/2009 18:38:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_CalculateInterestAmount_old]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_WF_CalculateInterestAmount_old]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;

	/*************************
	Get Step Type Code
	*************************/
	DECLARE @StepTypeCode VARCHAR(25)
	SELECT @StepTypeCode = [Code] FROM Legal_GroupStepTypes
	WHERE GroupStepTypeID = @GroupStepTypeID

    DECLARE @Interest Money
	
	/*************************
	 Summons Request
	*************************/
	IF @StepTypeCode = ''SUMREQ''
	BEGIN
			CREATE TABLE #groupedAccounts(SN INT IDENTITY(1,1),AccountID INT )
			INSERT INTO #groupedAccounts
			SELECT AccountID  FROM Legal_GroupDebts L INNER JOIN Legal_Groups G 
			ON L.GroupID=G.GroupID AND G.GroupedAccountID=@AccountID Where L.Isinclude=1

			CREATE TABLE #Temp_Interestcharge1(SN int identity(1,1),TransactionID int,AccountID int,TransactionAmount money,DateofTransaction smalldatetime ,Interestrate Real,Billbalance money,startdate smalldatetime,Enddate smalldatetime,numberofdays int,Interestcharged money,AffectBalance tinyint)
			CREATE TABLE #Temp_Interestcharge(SN int identity(1,1),TransactionID int,AccountID int,TransactionAmount money,DateofTransaction smalldatetime ,Interestrate Real,Billbalance money,startdate smalldatetime,Enddate smalldatetime,numberofdays int,Interestcharged money,AffectBalance tinyint)
			CREATE TABLE #Transactions(SN int identity(1,1),TransactionID int,AccountID int,AccountNumber varchar(20),TransactionAmount money )
			CREATE TABLE #Temp_TotalInterestcharged(SN int identity(1,1),TransactionID int,AccountID int,TransactionAmount money,DateofTransaction smalldatetime ,Interestrate Real,Billbalance money,startdate smalldatetime,Enddate smalldatetime,numberofdays int,Interestcharged money,AffectBalance tinyint)

			DECLARE @Maxcount INT
			SELECT @Maxcount = MAX(SN) FROM #groupedAccounts
			DECLARE @SN INT
			SET @SN =1

			WHILE (@SN<=@Maxcount)
			BEGIN

	   
				DECLARE @iExistTransactions int 
				DECLARE @iNewTransactions int
				DECLARE @tranAmount Money
				DECLARE @Gcode varchar(20)
				DECLARE @startdate datetime
				DECLARE @enddate datetime
				DECLARE @DatefoTran datetime

				---***Get all Accounts included in a Groups***---
		

				SELECT @startdate=O.Date18 FROM Accountother O INNER JOIN #groupedAccounts g ON O.AccountID=g.AccountID AND g.SN=@SN
				SELECT @enddate= O.Date19 FROM Accountother O INNER JOIN #groupedAccounts g ON O.AccountID=g.AccountID  AND g.SN=@SN

				---***Create #Temp_Interestcharge to get transactions for a groupedAccount***---


				INSERT INTO #Temp_Interestcharge1
				SELECT 0,T.AccountID,T.TransactionAmount,T.DateToPost,A.InterestRate,A.Billbalance,ISNULL(O.Date18,''01-01-1900'') as startdate,ISNULL(O.Date19,''01-01-1900'') as Enddate,0,0,2 From Transactions T INNER JOIN #groupedAccounts g ON T.AccountID=g.AccountID INNER JOIN Account A ON A.AccountID=T.AccountID INNER JOIN AccountOther O ON 
					A.AccountID = O.AccountID  Where T.datetopost > O.Date18-1 and T.datetopost < O.Date19+1 AND g.SN=@SN
				    AND (T.Transactiontype=901 AND TransactionComment not like''MIGR%'' and TransactionComment not like''PEND%'' )

				INSERT INTO #Temp_Interestcharge1
				SELECT 0,T.AccountID,T.TransactionAmount,T.DateToPost,A.InterestRate,A.Billbalance,ISNULL(O.Date18,''01-01-1900'') as startdate,ISNULL(O.Date19,''01-01-1900'') as Enddate,0,0,ty.AffectBalance From Transactions T INNER JOIN #groupedAccounts g ON T.AccountID=g.AccountID INNER JOIN Account A ON A.AccountID=T.AccountID INNER JOIN AccountOther O ON 
					A.AccountID = O.AccountID INNER JOIN TransactionType ty ON T.TransactionType=ty.ID  Where T.datetopost > O.Date18-1 and T.datetopost < O.Date19+1 AND g.SN=@SN
				    AND (ty.AffectBalance <>0 AND T.Transactiontype=1 AND T.Descriptor=''O'' and TransactionComment not like''MIGR%'')

				INSERT INTO #Temp_Interestcharge1
				SELECT 0,T.AccountID,T.TransactionAmount,O.Date18,A.InterestRate,A.Billbalance,ISNULL(O.Date18,''01-01-1900'') as startdate,ISNULL(O.Date19,''01-01-1900'') as Enddate,0,0,ty.AffectBalance From Transactions T INNER JOIN #groupedAccounts g ON T.AccountID=g.AccountID INNER JOIN Account A ON A.AccountID=T.AccountID INNER JOIN AccountOther O ON 
					A.AccountID = O.AccountID INNER JOIN TransactionType ty ON T.TransactionType=ty.ID  Where T.datetopost > O.Date18-1 and T.datetopost < O.Date19+1 AND g.SN=@SN
				    AND (ty.AffectBalance <>0 AND T.Transactiontype=1 AND T.Descriptor=''O'' and TransactionComment like''MIGR%'')

				UPDATE #Temp_Interestcharge1
				SET DateofTransaction=O.Date18 FROM AccountOther O INNER JOIN  #Temp_Interestcharge1 T ON O.AccountID=T.AccountID
			    INNER JOIN Account A ON T.AccountID=A.AccountID	WHERE T.DateofTransaction>=A.SubmissionDate and T.AffectBalance=1

				SELECT @DatefoTran= MIN(DateofTransaction) FROM #Temp_Interestcharge1
	
				IF (@startdate < MIN(@DatefoTran))
				BEGIN
					INSERT INTO #Temp_Interestcharge1
					SELECT 0,O.AccountID,0.00,O.Date18,A.Interestrate,0.00,ISNULL(O.Date18,''01-01-1900'') as startdate,
					ISNULL(O.Date19,''01-01-1900'') as Enddate,0,0,1 From #groupedAccounts g INNER JOIN Account A ON g.AccountID=A.AccountID
					INNER JOIN AccountOther O ON A.AccountID = O.AccountID  WHERE g.SN=@SN
				END

				---***Rearrange transactions orderby DateofTransaction***---

				INSERT INTO #Temp_Interestcharge
				SELECT 0,AccountID,TransactionAmount,DateofTransaction,Interestrate,Billbalance,Startdate,Enddate,numberofdays,Interestcharged,AffectBalance 
				FROM #Temp_Interestcharge1 order by DateofTransaction

				-----------------------------**************Calculating interest for Summons **************-------------------------

				UPDATE #Temp_Interestcharge
				SET startdate =  dateadd(minute,SN,DateOfTransaction) 

				UPDATE #Temp_Interestcharge 
				SET EndDate = ISNULL(		
					(SELECT TOP 1 startdate FROM #Temp_Interestcharge 
						WHERE 
							I.AccountID = AccountID AND
							 I.SN < SN AND
							startdate >=I.startdate
						 ORDER BY DateofTransaction ASC), EndDate)
					 FROM #Temp_Interestcharge I


				SELECT @tranamount= ISNULL(sum(t.transactionamount),0.00) from transactions t,#Temp_interestcharge i,Accountother a where t.Accountid=i.AccountID
				and i.Accountid=a.Accountid and t.Transactiontype=1 and t.datetopost <a.Date18 

				DECLARE @interestCharges INT
				SELECT @interestCharges = count(*) FROM #Temp_interestcharge

				IF (@interestCharges > 0)
					SELECT @tranamount =@tranamount/(SELECT count(*) FROM #Temp_interestcharge)

				UPDATE #Temp_Interestcharge
				SET TransactionAmount=@tranAmount+TransactionAmount WHERE SN=1

				UPDATE #Temp_Interestcharge
				SET Billbalance=TransactionAmount

    
				DECLARE @maxSN int
				DECLARE @count int
				SELECT @maxSN=Max(SN) FROM #Temp_Interestcharge  GROUP BY Accountid
				SET @count=1

				WHILE(@count<=@maxSN)
					BEGIN
							UPDATE  #Temp_Interestcharge
									 SET Billbalance= ISNULL((SELECT TOP 1 (t2.billbalance-t.TransactionAmount)
									 FROM  #Temp_Interestcharge t2
									 WHERE t2.sn = @count-1 and t.Affectbalance=2),billbalance)
									 FROM #Temp_Interestcharge t where t.SN=@count

							UPDATE  #Temp_Interestcharge
									 SET Billbalance= ISNULL((SELECT TOP 1 (t2.billbalance+t.TransactionAmount)
									 FROM  #Temp_Interestcharge t2
									 WHERE t2.sn = @count-1 and  t.Affectbalance=1),billbalance)
									 FROM #Temp_Interestcharge t where t.SN=@count
	
						SET @count=@count+1
				END

				---***Calculates Numberofdays***--- 

				UPDATE 	#Temp_Interestcharge
				SET Numberofdays=ABS(DATEDIFF(DAY, Enddate,Startdate))

				---***Calculates Interestcharged ***---

				UPDATE #Temp_Interestcharge
				SET interestcharged=(ISNULL(InterestRate, 0) * ISNULL(BillBalance, 0) * ABS(DATEDIFF(DAY, Startdate, Enddate)))/(365 * 100) -- Start and End Date of Interest
	
				---***Create Temporary table #Transactions***---

				INSERT INTO #Transactions 	
				SELECT 0,i.AccountID,a.invoicenumber,SUM(i.Interestcharged)FROM #Temp_Interestcharge i 
				INNER JOIN Account a ON i.AccountID=a.AccountID GROUP BY i.AccountID ,a.invoicenumber
	
				SELECT @iExistTransactions = FieldValue	FROM IdentityFields WHERE lower(TableName) = lower(''Transactions'')

				UPDATE #Transactions
				SET  TransactionID= SN+@iExistTransactions

				SELECT @Gcode= code FROM legal_groups WHERE GroupedAccountID=@AccountID

				---***Post Comment transactions***---
 
				INSERT INTO Transactions(TransactionID,AccountID,ClerkID,clientpart,PaidWhere,ReportedToClient,OnHoldFlag,ImportedTransactionID,TransactionName
				,ShortPayment_Flag,DateOfTransaction,DateToPost,TransactionType,TransactionAmount,TransactionComment,Descriptor,TXN_POSTED)
				SELECT 
					T.TransactionID,
					T.AccountID,
					1001,
					'''',
					'''',
					0,
					'''',
					'''',
					NULL,
					'''',
					GETDATE(),
					GETDATE(),
					15,
					T.TransactionAmount,
					''Summons interest calculated, posted to group account : ''+@Gcode,
					''P'',
					''Y''
				FROM #Transactions T 
		
				SELECT @iNewTransactions =  ISNULL(Max(TransactionID),0) FROM Transactions
				UPDATE IdentityFields
				SET FieldValue = @iNewTransactions where lower(TableName) = lower(''Transactions'')
	
			---***Insert into CWX_InterestBreakdown***---

				INSERT INTO CWX_InterestBreakdown
				 (AccountID
				 ,TransactionTypeID
				 ,StartDate
				 ,EndDate
				 ,NumOfDays
				 ,InterestRate
				 ,DebtAmount
				 ,InterestAmount)
				SELECT 
				 i.AccountID,
				 t.TransactionID,
				 i.startdate,
				 i.enddate,
				 i.numberofdays,
				 i.interestrate,
				 i.billbalance,
				 i.Interestcharged
				FROM #Temp_Interestcharge i INNER JOIN #Transactions t ON i.AccountID=t.AccountID WHERE i.numberofdays >0

			---***Insert into NotesCurrent***---
				INSERT INTO NotesCurrent
				(EmployeeID
				,DebtorID
				,BillID
				,NoteDateTime
			    ,NoteType
			    ,NoteText)
			
				SELECT
				1001,
				A.DebtorID ,
				i.AccountID,
				Getdate(),
				''A'',
				''Summons interest calculated, posted to group account : ''+@Gcode

				FROM #Temp_Interestcharge i INNER JOIN Account A ON i.AccountID=A.AccountID 
			
   
	
			---*** Calculates total Interest charged for all Accounts within a group***---

			INSERT INTO #Temp_TotalInterestcharged
			SELECT 	TransactionID ,AccountID ,TransactionAmount, DateofTransaction  ,Interestrate ,Billbalance ,startdate ,Enddate ,numberofdays,Interestcharged,AffectBalance 
			FROM #Temp_Interestcharge

			Truncate Table #Temp_Interestcharge
			Truncate Table #Transactions
			Truncate Table #Temp_Interestcharge1
	
			SET @SN=@SN+1
		END
		---***Calculated interest on grouped Account***---

		SELECT @Interest =Sum(Interestcharged)	FROM #Temp_TotalInterestcharged 
		SELECT ISNULL(@Interest, 0) AS ''Interest''
	
	END
			
	/*************************
	 Summons Issued
	*************************/
	
	ELSE IF @StepTypeCode = ''SUMISS''
		BEGIN
			SELECT @Interest = 0			
		END
	
	/*************************
	 Summons Served
	*************************/
	ELSE IF @StepTypeCode = ''SUMSRV''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Summons Defended
	*************************/
	ELSE IF @StepTypeCode = ''DEFSUM''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Judgement Applied
	*************************/
	ELSE IF @StepTypeCode = ''JUDAPP''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Judgement Entered
	*************************/
	ELSE IF @StepTypeCode = ''JUDENT''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Exam Request
	*************************/
	ELSE IF @StepTypeCode = ''EXMREQ''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Exam Issued
	*************************/
	ELSE IF @StepTypeCode = ''EXMISS''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Exam Served
	*************************/
	ELSE IF @StepTypeCode = ''EXMSRV''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Writ Requested
	*************************/
	ELSE IF @StepTypeCode = ''WRITREQ''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Writ Issued
	*************************/
	ELSE IF @StepTypeCode = ''WRITISS''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Garnishee Request
	*************************/
	ELSE IF @StepTypeCode = ''GARREQ''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Garnishee Issued
	*************************/
	ELSE IF @StepTypeCode = ''GARISS''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Warrant Request
	*************************/
	ELSE IF @StepTypeCode = ''WARREQ''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Warrant Issued
	*************************/
	ELSE IF @StepTypeCode = ''WARISS''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Bankrupt
	*************************/
	ELSE IF @StepTypeCode = ''BNKRPT''
		BEGIN
			SELECT @Interest = 0			
		END

	/*************************
	 Liquidation
	*************************/
	ELSE IF @StepTypeCode = ''LIQUID''
		BEGIN
			SELECT @Interest = 0			
		END
	
	
	SELECT ISNULL(@Interest, 0) AS ''Interest''
END 

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_EXMORD_External]    Script Date: 02/26/2009 18:38:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_EXMORD_External]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
--This external SP is ONLY called by EXAM ORDER action code.
--The purpose is to place order to 2 legal docs.

CREATE PROCEDURE [dbo].[CWX_WF_EXMORD_External]
	@AccountID INT,
	@GroupStepTypeID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @LetterID INT

		SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%NOMEXAMNEW%''
		INSERT INTO AccountLetterQueue
		SELECT
				@AccountID,
				@LetterID,
				GETDATE(),
				''O'',
				0,''1001'',2,NULL,NULL,NULL,NULL,0	

		SELECT @LetterID=LetterID FROM DefineLetters WHERE FileName LIKE ''%EXAMORDER%''
		INSERT INTO AccountLetterQueue
		SELECT
				@AccountID,
				@LetterID,
				GETDATE(),
				''O'',
				0,''1001'',2,NULL,NULL,NULL,NULL,0	
END

/**********************************************************************************************************/
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
END
GO

