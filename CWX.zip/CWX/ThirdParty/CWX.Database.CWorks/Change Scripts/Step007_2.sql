-- Script apply to fix defects on version 1.2 build 2

-- =============================================================================
-- Author:		Tuan Luong
-- Create date: Mar 13, 2008
-- Description:	Selects all records on the given @ColumnName and @TableName 
-- Parameters: 
--	@TableName
--	@ColumnName		     
-- Database:    CWorks
-- =============================================================================
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]
GO
CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetMatchingCriteriaListByCriteria]
	@TableName varchar(125),
	@ColumnName varchar(125)		
AS
BEGIN
	DECLARE @Sql varchar(2000)
	SET @Sql = 'SELECT DISTINCT ' + @ColumnName + ' FROM ' + @TableName		
	SET @Sql = @Sql + ' WHERE ' + @ColumnName + ' is not NULL'
	SET @Sql = @Sql + ' AND ' + @ColumnName + ' <> '''''
	SET @Sql = @Sql + ' ORDER BY ' + @ColumnName	

	EXEC(@Sql)
END
GO

-- =============================================================
-- Author:		Tuan Luong
-- Create date: Mar 17, 2008
-- Description:	Delete all records in RuleCriteria Table
--				with the given RuleID 
-- Parameters:  Rule ID of the Rule contains all needed records 
--				in RuleCriteria table to delete
-- Database:    CWorks
-- =============================================================
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].CWX_RuleCriteria_DeleteAllByRuleID') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].CWX_RuleCriteria_DeleteAllByRuleID
GO
CREATE PROCEDURE [dbo].CWX_RuleCriteria_DeleteAllByRuleID
	@RuleID int		
AS
BEGIN	
	DELETE RuleCriteria
	WHERE RuleID = @RuleID	
END
GO

-- =============================================
-- Author:		Tuan Luong
-- Create date: Mar 14, 2008
-- Description:	
-- Database:    CWorks
-- =============================================
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CWX_TicketDefinition_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TicketDefinition_GetPagingList]
GO
CREATE PROCEDURE [dbo].[CWX_TicketDefinition_GetPagingList]	
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		ROW_NUMBER() OVER (ORDER BY t.TktDefID) AS RowNumber,
		t.TktDefID as TicketDefinitionID,
		t.Description,
		t.ApprovalLevel,
		t.ApproverDays,
		t.RoleID,		
		ISNULL(e.EmployeeName, '') as EmployeeName,
		t.EmpDDays,
		t.TicketType		
	INTO #Temp
	FROM TicketDefinition t LEFT JOIN Employee e 
	ON t.EmployeeID = e.EmployeeID AND e.EmployeeStatus <> 'R'
	WHERE  t.Status <> 'R'		

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	ORDER BY TicketDefinitionID
	
	RETURN @RowCount
END
GO 

/****** Object:  UserDefinedFunction [dbo].[CWX_Interface_FnGetCriteriaTableNames]    Script Date: 03/17/2008 17:31:13 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Interface_FnGetCriteriaTableNames]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CWX_Interface_FnGetCriteriaTableNames]
GO
/****** Object:  UserDefinedFunction [dbo].[CWX_Interface_FnGetCriteriaTableNames]    Script Date: 03/17/2008 17:31:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Interface_FnGetCriteriaTableNames]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[CWX_Interface_FnGetCriteriaTableNames]
(
	@RuleType int
)
RETURNS 
@CriteriaTableNames TABLE 
(
	TableName varchar(125)
)
AS
BEGIN
	IF (@RuleType = 1)
	BEGIN
		INSERT @CriteriaTableNames
		SELECT TOP 1 AccountTable FROM Interface 
		WHERE AccountTable is not NULL or AccountTable <> ''''
		ORDER BY InterfaceID
		
		INSERT @CriteriaTableNames
		SELECT TOP 1 CustomerTable FROM Interface 
		WHERE AccountTable is not NULL or AccountTable <> ''''
		ORDER BY InterfaceID	
	END
	
	IF (@RuleType = 2)
	BEGIN
		INSERT @CriteriaTableNames
		SELECT TOP 1 AccountTable FROM Interface 
		WHERE AccountTable is not NULL or AccountTable <> ''''
		ORDER BY InterfaceID
		
		INSERT @CriteriaTableNames
		SELECT TOP 1 CustomerTable FROM Interface 
		WHERE AccountTable is not NULL or AccountTable <> ''''
		ORDER BY InterfaceID
	END
	RETURN 
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_DeleteAll]    Script Date: 03/18/2008 09:16:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleTable_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_DeleteAll]    Script Date: 03/18/2008 09:16:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleTable_DeleteAll] 
	@RuleType tinyint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END
	
	-- Delete RulesAllocUsers
	DELETE RulesAllocUsers WHERE RuleId IN (SELECT ID FROM RuleTable WHERE RuleType = @RuleType)
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Delete RuleOther
	DELETE RuleOthers WHERE RuleId IN (SELECT ID FROM RuleTable WHERE RuleType = @RuleType)
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Delete RuleCriteria
	DELETE RuleCriteria WHERE RuleId IN (SELECT ID FROM RuleTable WHERE RuleType = @RuleType)
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Delete RuleTable
	DELETE RuleTable WHERE RuleType = @RuleType
	IF( @@ERROR <> 0)
        GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_Delete]    Script Date: 03/18/2008 09:32:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_Delete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleTable_Delete]

GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_DeleteAll]    Script Date: 03/18/2008 09:29:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 18, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleTable_Delete] 
	@RuleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END
	
	-- Delete RulesAllocUsers
	DELETE RulesAllocUsers WHERE RuleId = @RuleID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Delete RuleOther
	DELETE RuleOthers WHERE RuleId = @RuleID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Delete RuleCriteria
	DELETE RuleCriteria WHERE RuleId = @RuleID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	--Delete RuleTable
	DELETE RuleTable WHERE ID = @RuleID
	IF( @@ERROR <> 0)
        GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
END



GO
/****** Object:  UserDefinedFunction [dbo].[CWX_RuleCriteria_FnGetCriteriaByRuleType]    Script Date: 03/19/2008 11:52:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_FnGetCriteriaByRuleType]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CWX_RuleCriteria_FnGetCriteriaByRuleType]

GO
/****** Object:  UserDefinedFunction [dbo].[CWX_RuleCriteria_FnGetCriteriaByRuleType]    Script Date: 03/19/2008 11:53:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[CWX_RuleCriteria_FnGetCriteriaByRuleType]
(
	@RuleType int
)
RETURNS 
@Criterias TABLE 
(
	[COLUMN_NAME] varchar(125),
	[DESCRIPTION] varchar(125),
	[DATA_TYPE] varchar(125)
)
AS
BEGIN
	INSERT INTO @Criterias
	SELECT  
		[COLUMN_NAME] = o.name + '.' + ltrim(rtrim(c.name)),		  
		[DESCRIPTION] = dbo.CWX_RuleCriteria_FnProcessDescription (ltrim(rtrim(convert(varchar(125), ex.value)))),  
		[DATA_TYPE] = upper(ty.name) 
	FROM
		sys.objects o
	INNER JOIN   
		sys.columns c 
	ON
		o.object_id = c.object_id  
	LEFT OUTER JOIN  
		sys.extended_properties ex  
	ON  
		ex.major_id = c.object_id  
		AND ex.minor_id = c.column_id  
		AND ex.name = 'MS_Description'  
	LEFT OUTER JOIN  
		sys.types ty  
	ON  
		ty.system_type_id = c.system_type_id  
	WHERE  
		OBJECTPROPERTY(c.object_id, 'IsMsShipped') = 0  
		AND OBJECT_NAME(c.object_id) in (SELECT * FROM CWX_Interface_FnGetCriteriaTableNames (@RuleType))
		AND ex.value is not NULL AND ex.value <> ''
	ORDER  
		BY [DESCRIPTION]

	RETURN 
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]    Script Date: 03/19/2008 11:51:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]

GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]    Script Date: 03/19/2008 11:52:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]
	@RuleType int		
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM CWX_RuleCriteria_FnGetCriteriaByRuleType (@RuleType)
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetList]    Script Date: 03/19/2008 14:52:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetList]

GO
/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetList]    Script Date: 03/19/2008 14:51:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 19, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetList] 
	@RuleID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RuleType tinyint
    SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID

	IF @RuleType <> 3
	BEGIN
		SELECT *
		INTO #Temp
		FROM CWX_RuleCriteria_FnGetCriteriaByRuleType(@RuleType)

		SELECT r.*, t.DESCRIPTION
		FROM RuleCriteria r
		INNER JOIN #Temp t ON r.Criteria = t.COLUMN_NAME
		WHERE RuleID = @RuleID
	END
	ELSE --Result Processing Rule
		SELECT *, Criteria AS DESCRIPTION
		FROM RuleCriteria
		WHERE RuleID = @RuleID
END
