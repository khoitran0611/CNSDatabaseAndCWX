 -- Scripts are applied on version 1.4 build 3
 
 /****** Object:  StoredProcedure [dbo].[CWX_Report_DeleteReportSchedule]    Script Date: 04/10/2008 16:39:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Report_DeleteReportSchedule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Report_DeleteReportSchedule]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Report_DeleteReportSchedule]    Script Date: 04/10/2008 16:39:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Report_DeleteReportSchedule]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Binh Truong
-- Create date: April 10, 2008
-- Description:	Delete report schedule and its relating child.
-- =============================================
create PROCEDURE dbo.CWX_Report_DeleteReportSchedule
	@ScheduleID INT
AS	
	DECLARE @InTrans bit
	SET @InTrans = 0
	
	IF @@TRANCOUNT = 0
	BEGIN
		BEGIN TRANSACTION
		SET @InTrans = 1
	END
	
	DELETE ReportScheduleTable 
	WHERE ID = @ScheduleID
	
	IF @@ERROR <> 0
		GOTO ProcError
		
	DELETE ReportScheduleDate 
	WHERE ScheduleID = @ScheduleID
	
	IF @@ERROR <> 0
		GOTO ProcError
		
	DELETE ReportScheduleParam 
	WHERE ScheduleID = @ScheduleID
			
	ProcExit:
		IF @InTrans = 1 
		BEGIN
			SET @InTrans = 0
			COMMIT TRANSACTION
		END
	
	ProcError:
		IF @InTrans = 1
		BEGIN
			SET @InTrans = 0
    		ROLLBACK TRANSACTION
		END
	
	' 
END
GO


 /****** Object:  StoredProcedure [dbo].[CWX_Account_GetListInfo]    Script Date: 04/11/2008 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetListInfo]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListInfo]    Script Date: 04/10/2008 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListInfo]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Tai Ly
-- Create date: April 11, 2008
-- Description:	Get List of Account Information from DebtorID
-- =============================================

CREATE PROCEDURE [dbo].[CWX_Account_GetListInfo]
	-- Add the parameters for the stored procedure here
	@DebtorID	int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT		a.BILLBALANCE,a.MCODE,a.CLIENTID,a.INTERFACEID,a.ACCOUNTID,a.DEBTORID,a.INVOICENUMBER,a.EMPLOYEEID,a.ACTIONEMPLOYEE,a.QUEUEDATE,a.AGENCYSTATUSID,a.MAINTAINOFFICER,a.NOFEEBEFORE,a.NOLETTERBEFORE,A.ACCOUNTAGE,C.CLIENTNAME,C.RescheduleAllowed,c.DiscountAllowed,B.MONEY36,A.CURRENTREASON,A.CURRENTNEXTACTION,A.CURRENTCALLRESULT 
	FROM		[dbo].[Account] a, [dbo].[AccountOther] b, [dbo].[ClientInformation] c
	WHERE		a.AccountID = b.AccountID AND a.DebtorID = @DebtorID AND a.ClientID = c.ClientID
	ORDER BY	b.AccountID	
END

' 
END
GO

UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_SearchByAllocQueue %E, %1' WHERE ID = 4
UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_SearchReviewAccounts %E' WHERE ID = 5
UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_SVByEmployee %E, %1' WHERE ID = 6
UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_QueueByAmtRange %E, %1, %2' WHERE ID = 8
UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_QueueFuture %E, %1' WHERE ID = 9
UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_Queue_NoActivityInXDays %E, %1, %2' WHERE ID = 13
UPDATE QueryMaster SET SQL2 = 'EXEC CWX_Account_Queue_NoContactInXDays %E, %1, %2' WHERE ID = 14
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByAllocQueue]    Script Date: 04/09/2008 10:00:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByAllocQueue]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByAllocQueue]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByAllocQueue]    Script Date: 04/09/2008 10:00:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByAllocQueue] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@v_AllocRule int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY a.QueueDate desc) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
		a.QueueDate AS [QueueDate],
		a.InvoiceNumber as [Account Number],
		a.AccountAge AS [DPD],
		a.MCode AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		s.ShortDesc as [Status],
		s.SortPriority AS [Priority],
		a.AssignmentType AS [Assignment Type],
		rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	WHERE
	(a.EmployeeID = @v_EmployeeId or a.TempEmployeeID = @v_EmployeeId)
	and a.AllocRuleID = @v_AllocRule
	and a.QueueDate <= getdate()
	and a.DebtorID <> 0

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchReviewAccounts]    Script Date: 04/09/2008 10:00:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchReviewAccounts]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchReviewAccounts]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchReviewAccounts]    Script Date: 04/09/2008 10:00:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchReviewAccounts] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
		a.QueueDate AS [QueueDate],
		a.InvoiceNumber as [Account Number],
		a.AccountAge AS [DPD],
		a.MCode AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		s.ShortDesc as [Status],
		s.SortPriority AS [Priority],
		a.AssignmentType AS [Assignment Type],
		rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
		e.EmployeeName [Referred From]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeID
	WHERE
	a.ActionEmployee = @v_EmployeeId
	and a.QueueDate <= getdate()
	and a.DebtorID <> 0
	and a.AgencyStatusID <> 2

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Referred From]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SVByEmployee]    Script Date: 04/10/2008 10:00:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SVByEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SVByEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SVByEmployee]    Script Date: 04/10/2008 10:00:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 10, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SVByEmployee] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@CollectorID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY a.QueueDate desc) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
		a.QueueDate AS [QueueDate],
		a.InvoiceNumber as [Account Number],
		a.AccountAge AS [DPD],
		a.MCode AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		s.ShortDesc as [Status],
		s.SortPriority AS [Priority],
		a.AssignmentType AS [Assignment Type],
		rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
		g.UserID [Collector ID]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID
	INNER JOIN Employee e ON e.EmployeeID = @v_EmployeeId
	WHERE
	e.Supervisor = 1
	and (a.EmployeeID = @CollectorID or a.TempEmployeeID = @CollectorID)
	and a.QueueDate <= getdate()
	and a.DebtorID <> 0
	and a.AgencyStatusID <> 2

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Collector ID]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueByAmtRange]    Script Date: 04/10/2008 10:00:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_QueueByAmtRange]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_QueueByAmtRange]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueByAmtRange]    Script Date: 04/10/2008 10:00:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_QueueByAmtRange] 
	-- Add the parameters for the stored procedure here
	@v_Range int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		[KeyField] varchar(30),
		[QueueDate] char(10),
		[Account Number] varchar(50),
		[DPD] int,
		[Bucket] char(1),
		[Cycle] smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		[Status] varchar(10),
		[Priority] int,
		[Assignment Type] char(1),
		[Name] varchar(200)
	)
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate <= getDate()'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

				if ((@EmpList <> '') and (@EmpList <> 'Null'))
				Begin
					SET @cStmt=@cStmt+' AND a.EmployeeID in (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(' + @EmpList + ',' + '''' + ',' + '''' + '))'
				End

				if @v_Range = 1
				Begin
					SET @cStmt = @cStmt +'   AND a.BillBalance < 10000'
				End

				if @v_Range = 2
				Begin
					SET @cStmt = @cStmt +'  AND a.BillBalance >= 10000'
					SET @cStmt = @cStmt +'  AND a.BillBalance < 25000'
				End

				if @v_Range = 3
				Begin
					SET @cStmt = @cStmt +'	AND a.BillBalance >= 25000'
					SET @cStmt = @cStmt +'	AND a.BillBalance < 50000'		
				End

				if @v_Range = 4
				Begin
					SET @cStmt = @cStmt +'	AND a.BillBalance >= 50000'
					SET @cStmt = @cStmt +'	AND a.BillBalance < 150000'		
				End

				if @v_Range = 5
				Begin
					SET @cStmt = @cStmt +'	AND a.BillBalance >= 150000'
				End

				Set @cStmt = @cStmt + ' Order by a.QueueDate DESC'
				EXEC (@cStmt)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueFuture]    Script Date: 04/10/2008 10:00:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_QueueFuture]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_QueueFuture]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueFuture]    Script Date: 04/10/2008 10:00:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_QueueFuture] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@Days int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		[KeyField] varchar(30),
		[QueueDate] char(10),
		[Account Number] varchar(50),
		[DPD] int,
		[Bucket] char(1),
		[Cycle] smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		[Status] varchar(10),
		[Priority] int,
		[Assignment Type] char(1),
		[Name] varchar(200)
	)
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.EmployeeID = ' + @EmployeeID
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

--Today|2|GE Today|0|Tomorrow|1|3 Days|3|5 Days|5

				if (@Days = 1) or (@Days = 3) or (@Days = 5)
				Begin
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) <= dateadd(day,' + @Days + ', getdate())'
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) >= getdate()'
				End

				if @Days = 2
				Begin
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) = getdate()'
				End

				if @Days = 0
				Begin
					SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) >= getdate()'
				End

				Set @cStmt = @cStmt + ' Order by a.QueueDate DESC'
				EXEC (@cStmt)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_Queue_NoActivityInXDays]    Script Date: 04/04/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_Queue_NoActivityInXDays]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_Queue_NoActivityInXDays]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_Queue_NoActivityInXDays]    Script Date: 04/04/2008 17:39:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_Queue_NoActivityInXDays] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lNumberOfDays int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
		a.QueueDate AS [QueueDate],
		a.InvoiceNumber as [Account Number],
		a.AccountAge AS [DPD],
		CAST(a.MCode AS CHAR(2)) AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		s.ShortDesc AS [Status],
		s.SortPriority AS [Priority],
		a.AssignmentType AS [Assignment Type],
		RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
		e.EmployeeName As [Employee Name]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()))

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_Queue_NoContactInXDays]    Script Date: 04/04/2008 17:39:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_Queue_NoContactInXDays]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_Queue_NoContactInXDays]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_Queue_NoContactInXDays]    Script Date: 04/04/2008 17:39:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_Queue_NoContactInXDays] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lNumberOfDays int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
		(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
		a.QueueDate AS [QueueDate],
		a.InvoiceNumber as [Account Number],
		a.AccountAge AS [DPD],
		CAST(a.MCode AS CHAR(2)) AS [Bucket],
		a.CCode AS [Cycle],
		a.BillAmount AS [Bill Amount],
		a.BillBalance AS [Bill Balance],
		s.ShortDesc AS [Status],
		s.SortPriority AS [Priority],
		a.AssignmentType AS [Assignment Type],
		RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
		e.EmployeeName As [Employee Name]
	INTO #Temp
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()) and ActionID in (select ActionID from AvailableActions where productivityid = 3))

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Document_GetProcessedLetters]    Script Date: 04/11/2008 18:09:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Document_GetProcessedLetters]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Document_GetProcessedLetters]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Document_GetProcessedLetters]    Script Date: 04/11/2008 18:09:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Document_GetProcessedLetters]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.CWX_Document_GetProcessedLetters
AS
BEGIN
	SELECT * 
	FROM DefineLetters
	WHERE LetterID in (Select LetterID From AccountLetterQueue WHERE XmitStatus = ''P'')
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AccountStatus_LoadInQueue]    Script Date: 04/11/2008 18:12:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER Procedure [dbo].[CWX_AccountStatus_LoadInQueue]
	(
		@LoadInQueue bit = 1		
	)
AS
BEGIN	
	SELECT * 
	FROM [dbo].[AccountStatus]
	WHERE LoadInQueue = @LoadInQueue AND Status <> 'R'
END	
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ReportScheduleTable_GetCustomPagingList ]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ReportScheduleTable_GetCustomPagingList ]
GO

CREATE PROCEDURE dbo.CWX_ReportScheduleTable_GetCustomPagingList 
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SELECT ROW_NUMBER() OVER (ORDER BY r.ID) AS RowNumber,
			r.ID, 
			r.ReportID, 
			r.ScheduleType, 
			r.Description, 
			r.ScheduleStatus, 
			r.ScheduledDay, 
			r.BeginDate, 
			r.EndDate, 
			d.LetterDesc
	INTO #Temp		
	FROM ReportScheduleTable AS r 
	INNER JOIN
         DefineLetters AS d 
    ON r.ReportID = d.LetterID
    
    DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF @PageSize <= 0
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount

END
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LetterHistory_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LetterHistory_Get]
GO
-- =============================================
-- Author:		TaiLy
-- Create date: April 16, 2008
-- Description:	Load letter history
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LetterHistory_Get]
	-- Add the parameters for the stored procedure here
	@AccountID	int,
	@PageSize	int = 10,
	@PageIndex	int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	ROW_NUMBER() OVER (ORDER BY ID) AS RowNumber, 
			ID, a.LetterID as LetterID, LetterDesc, LetterDate, AddressType, ViewLetterPath
	INTO	#Temp
	FROM	[dbo].[AccountLetter] a INNER JOIN [dbo].[DefineLetters] d ON a.LetterID = d.LetterID
	WHERE	a.AccountID = @AccountID
	
	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	IF @PageSize <= 0
		SELECT * 
		FROM #Temp
	ELSE
		SELECT	*
		FROM	#Temp
		WHERE	RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize)	

	RETURN @RowCount
	
END
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonAddress_GetDetail]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonAddress_GetDetail]
GO
-- =============================================
-- Author:		TaiLy
-- Create date: April 16, 2008
-- Description:	Load letter history
-- =============================================

CREATE PROCEDURE [dbo].[CWX_PersonAddress_GetDetail]
	-- Add the parameters for the stored procedure here
	@PersonID		int,
	@AddressType	tinyint	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	AddressID,PersonID,AddressType,Address1,Address2,Address3,Territory,
			City,State,Zip,Country,MailingAddress,AddressStatus,Description,Region,
			EmployeeID,CreateDate,UpdateDate

    FROM	[dbo].[PersonAddress]
	WHERE	personid = (SELECT	PersonID 
						FROM	[dbo].[DebtorInformation]
						WHERE	DebtorID = @PersonID)
			AND AddressType = @AddressType
END
GO


-- =======================================================================
-- Author:		Tuan Luong
-- Create date: April 17, 2008
-- Description:	Add column 'NewValue'
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'ReportScheduleParam' and c.name = 'NewValue')
BEGIN
	ALTER TABLE ReportScheduleParam
	ADD NewValue varchar(25) NULL
END
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountLetterQueue_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountLetterQueue_Get]
GO
-- =============================================
-- Author:		KhoaDuong	
-- Create date: April 17, 2008
-- Description:	Order letter - Get Account Letter Queue
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountLetterQueue_Get]
	-- Add the parameters for the stored procedure here
	@LetterID	int,
	@AccountID	int
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT AccountID, LetterID from AccountLetterQueue Where AccountID = @AccountID And LetterID = @LetterID
	
	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	IF @RowCount >0
		Begin
			Select LetterDesc from DefineLetters where LetterID =  @LetterID
			SELECT @RowCount = @@ROWCOUNT			
		End	
	ELSE
		SELECT @RowCount = -1
	
	RETURN @RowCount
	
END
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonAddress_Update]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonAddress_Update]
GO
-- =============================================
-- Author:		TaiLy	
-- Create date: April 17, 2008
-- Description:	Letter History - Update PersonAddress
-- =============================================

CREATE PROCEDURE [dbo].[CWX_PersonAddress_Update]
	-- Add the parameters for the stored procedure here
	@DebtorID		int,
	@AccountID		int,
	@EmployeeID		int,
	@AddressType	tinyint,
	@Address1		varchar(255),
	@Address2		varchar(255),
	@Address3		varchar(255),
	@City			varchar(255),
	@State			varchar(50),
	@Zip			varchar(25),
	@Country		varchar(50),
	@AddressStatus	smallint,
	@Description	varchar(255)		
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Insert to log table
	IF @AddressType > 4 	
	BEGIN		
		DECLARE Result_Cursor	CURSOR FOR
		SELECT	AddressID, PersonID, Address1, Address2, Address3, City, State, Zip, CreateDate
		FROM	[dbo].[PersonAddress]
		WHERE	PersonID = (SELECT	PersonID
							FROM	[dbo].[DebtorInformation]	
							WHERE	DebtorID = @DebtorID ) 
				AND AddressType = @AddressType
							
		DECLARE @AddressID int, @PersonID int;
		DECLARE @Address1_Var varchar(255), @Address2_Var varchar(255), @Address3_Var varchar(255);
		DECLARE @City_Var varchar(255), @State_Var varchar(50), @Zip_Var varchar(25);
		DECLARE @CreateDate smalldatetime;

		OPEN Result_Cursor

		FETCH NEXT FROM Result_Cursor 
		INTO @AddressID, @PersonID, @Address1_Var, @Address2_Var, @Address3_Var, @City_Var, @State_Var, @Zip_Var, @CreateDate

		IF @@FETCH_STATUS = 0
		BEGIN					
			IF (@Address1 <> @Address1_Var OR @Address2 <> @Address2_Var OR @Address3 <> @Address3_Var OR @City <> @City_Var OR @State <> @State_Var OR @Zip <> @Zip_Var) AND 
				(LTRIM(RTRIM(@Address1_Var)) <> '' AND LTRIM(RTRIM(@Address2_Var)) <> '' AND LTRIM(RTRIM(@Address3_Var)) <> '' AND LTRIM(RTRIM(@City_Var)) <> '' AND LTRIM(RTRIM(@State_Var)) <> '' AND LTRIM(RTRIM(@Zip_Var)) <> '' )	
			BEGIN
				INSERT INTO [dbo].[PersonAddressLog](AddressID,PersonID,AddressType,Address1,Address2,Address3,City,State,Country,Zip,AddressStatus,Description,EmployeeID,UpdateDate,CreateDate) 
				VALUES(@AddressID, @PersonID, @AddressType, @Address1, @Address2, @Address3, @City, @State, @Zip, @Country, @AddressStatus, @Description, @EmployeeID, @CreateDate, GETDATE())
			END
			
		END

		-- release cursor
		CLOSE Result_Cursor
		DEALLOCATE Result_Cursor
	END	

	-- Update PersonAddress
	UPDATE	[dbo].[PersonAddress]
	SET		Address1=@Address1, Address2=@Address2, Address3=@Address3, City=@City, State=@State, Zip=@Zip, Country=@Country, AddressStatus=@AddressStatus, Description=@Description
	WHERE	PersonID = (SELECT	PersonID
						FROM	[dbo].[DebtorInformation]
						WHERE	DebtorID = @DebtorID
						)	
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetTotalEmployee]    Script Date: 04/17/2008 21:58:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetTotalEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_GetTotalEmployee]
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetTotalActiveAccountAndValue]    Script Date: 04/17/2008 21:58:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetTotalActiveAccountAndValue]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_EmployeeReport_GetTotalActiveAccountAndValue]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_GetTotalEmployee]    Script Date: 04/17/2008 21:58:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_GetTotalEmployee]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Binh Truong
-- Create date: April 17, 2008
-- Description:	
-- =============================================================
create PROCEDURE CWX_Employee_GetTotalEmployee
AS
BEGIN
	SET NOCOUNT ON;
	SELECT COUNT(*) FROM Employee WHERE EmployeeStatus = ''A''
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_EmployeeReport_GetTotalActiveAccountAndValue]    Script Date: 04/17/2008 21:58:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_EmployeeReport_GetTotalActiveAccountAndValue]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Binh Truong
-- Create date: April 17, 2008
-- Description:	Get total active account and total dollar value of account for Porfolio
-- Parameters: 
--	@PorfolioType	0: Queue Active
--					1: Active Accounts
--					Other number: All accounts
-- =============================================================
CREATE PROCEDURE CWX_EmployeeReport_GetTotalActiveAccountAndValue
	@PorfolioType AS INT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Select NVARCHAR(1000)
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @Statement NVARCHAR(2000)
	DECLARE @Parms NVARCHAR(500)
	
	
	SET @Select = ''
		SELECT	COUNT(*) AS TotalAccount,
				SUM(BillBalance) as TotalDollarValue 
		FROM Account
		'' 
	IF @PorfolioType = 0		
		SET @Conditions = ''
			WHERE	SystemStatusId = 5 
					AND AgencyStatusID <> 2 
					AND QueueDate <= GETDATE()
			''
	
	IF @PorfolioType = 1
		SET @Conditions = ''
			WHERE	SystemStatusId = 5 
					AND AgencyStatusID <> 2
			''
	
	SET @Statement = @Select + @Conditions
	
	EXEC dbo.sp_executesql @Statement
END
' 
END
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountLetterQueue_Delete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountLetterQueue_Delete]
GO
-- =============================================
-- Author:		KhoaDuong	
-- Create date: April 18, 2008
-- Description:	Order letter - Delete Account Letter Queue
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountLetterQueue_Delete]
	-- Add the parameters for the stored procedure here
	@LetterID	int,
	@AccountID	int
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DELETE FROM dbo.AccountLetterQueue WHERE LetterID = @LetterID AND AccountID = @AccountID
END
GO



/****** Object:  StoredProcedure [dbo].[CWX_Notes_Get]    Script Date: 04/04/2008 16:36:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Notes_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Notes_Get]
GO
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Notes_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CWX_Notes_Get] 	
	@DebtorID int, @AccountID int, @NoteType varchar(1)	
AS
BEGIN
	Declare @IdentityTableValue int
	Set @IdentityTableValue = (Select FieldValue from IdentityFields where TableName = ''NotesDisplayByAccount'')
	if (@IdentityTableValue < 0 )
		begin 
			Insert into IdentityFields values(''NotesDisplayByAccount'',0)
			if (@NoteType = '''')			
				begin
					select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
					where n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID   Order By n.NoteDateTime desc, n.NoteID			
				end
			else
				begin
					select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
					where n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND NoteType  Like @NoteType  Order By n.NoteDateTime desc, n.NoteID			
				end	
		end
	else if (@IdentityTableValue = 0 )
		begin 
			if (@NoteType = '''')			
				begin
					select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
					where n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID   Order By n.NoteDateTime desc, n.NoteID			
				end
			else
				begin
					select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
					where n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND NoteType  Like @NoteType  Order By n.NoteDateTime desc, n.NoteID			
				end	
		end
	else		
		begin
			if (@NoteType = '''')			
				begin
					select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
					where n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  Order By n.NoteDateTime desc, n.NoteID
				end
			else
				begin
					select n.NoteDateTime, n.NoteText, n.NoteType, e.UserID from NotesCurrent n, Employee e 
					where n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  AND NoteType  Like @NoteType Order By n.NoteDateTime desc, n.NoteID
				end	
		end	
END		
' 
END

GO
/****** Object:  Table [dbo].[QueryDebtorInfoMaster]    Script Date: 04/21/2008 09:48:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[QueryDebtorInfoMaster]') AND type in (N'U'))
BEGIN 
DELETE FROM [dbo].[QueryDebtorInfoMaster] 

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (1,1, 'Exec CWX_DebtorInfomation_Get %D', 'Load debtor information' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (1,2, 'Exec CWX_PersonAddress_Get %D', 'Load personal address details' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (1,3, 'Exec CWX_PersonPhone_Get %D', 'Load phone details' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (1,4, 'Exec CWX_Spouse_Get %D', 'Load spouse details' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (1,5, 'Exec CWX_Notes_Get %D %A %N', 'Load hot notes' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (1,6, 'Exec CWX_TicketHistory_Get %D', 'Load ticket history' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (1,7, 'Exec CWX_Account_LoadXML %D', 'Load acount information' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (1,8, 'Exec CWX_PromiseFrequency_Get', 'Load promise frequency' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (1,9, 'sdfasdf', 'Load delinquency history' )


INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (2,1, 'Exec CWX_DebtorInfomation_Get %D', 'Load debtor information' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (2,2, 'Exec CWX_PersonAddress_Get %D', 'Load personal address details' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (2,3, 'Exec CWX_PersonPhone_Get %D', 'Load phone details' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (2,4, 'Exec CWX_Spouse_Get %D', 'Load spouse details' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (2,5, 'Exec CWX_Notes_Get %D %A %N', 'Load hot notes' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (2,6, 'Exec CWX_TicketHistory_Get %D', 'Load ticket history' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (2,7, 'Exec CWX_Account_LoadXML %D', 'Load acount information' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (2,8, 'Exec CWX_PromiseFrequency_Get', 'Load promise frequency' )

INSERT INTO [dbo].[QueryDebtorInfoMaster] (InterfaceID, InfoType, [Sql], Description )
VALUES (2,9, 'sdfasdf', 'Load delinquency history' )

END

GO

/****** Object:  StoredProcedure [dbo].[CWX_PersonAddress_Get]    Script Date: 04/21/2008 15:06:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonAddress_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonAddress_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonAddress_Get]    Script Date: 04/21/2008 15:06:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonAddress_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Triet Pham
-- Create date: Mar 26th, 2008
-- Description:	Retrieve all personal addresses
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_PersonAddress_Get]	
	@DebtorID int
AS
BEGIN

	SET NOCOUNT ON	

	Select 
		p.AddressType, 
		p.Address1, 
		p.Address2, 
		p.Address3, 
		p.City, 
		p.[State], 
		p.Zip, 
		p.Country, 
		p.Territory, 
		p.Region, 
		p.MailingAddress 
	from PersonAddress p INNER JOIN DebtorInformation d ON p.PersonID = d.PersonID
	Where d.DebtorID = @DebtorID 
	Order by AddressType

	SET NOCOUNT OFF
END
' 
END
GO
