﻿-- Script is applied on version 3.6.3:

-- Start of Scripts 3.6.3: 

/****** Object:  StoredProcedure [dbo].[CWX_Customer_AddAccountSubProductDetails]    Script Date: 03/06/2009 18:21:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Customer_AddAccountSubProductDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Customer_AddAccountSubProductDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Customer_UpdateAccountSubProductDetails]    Script Date: 03/06/2009 18:21:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Customer_UpdateAccountSubProductDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Customer_UpdateAccountSubProductDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetSubProductTotalUnAllocatedAmount]    Script Date: 03/06/2009 18:21:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetSubProductTotalUnAllocatedAmount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetSubProductTotalUnAllocatedAmount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Customer_AddAccountSubProductDetails]    Script Date: 03/06/2009 18:21:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Customer_AddAccountSubProductDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Suzette M. Dimasaca
-- Create date: Jan 26, 2009
-- Description:	This will insert data to AdditionalAcctSubProd table
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Customer_AddAccountSubProductDetails]
	-- Add the parameters for the stored procedure here
	@AccountID	Int
	, @SubProductId Int
	, @Issue	Int
	, @GST		Money
	, @OriginalDebt Money
	, @Paid		Money
	, @Notes	VarChar(100)
	, @CreatedBy	Int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TotalDebt	Money
		,@Due			Money

	SET @TotalDebt = (@OriginalDebt + @GST)
	SET @Due = (@TotalDebt - @Paid)

	INSERT INTO AdditionalAcctSubProd
	VALUES (@AccountID
		, @SubProductID
		, @Issue
		, @OriginalDebt
		, @GST
		, @TotalDebt
		, @Paid
		, @Due
		, @Notes
		, @CreatedBy
		, getdate())
    
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Customer_UpdateAccountSubProductDetails]    Script Date: 03/06/2009 18:21:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Customer_UpdateAccountSubProductDetails]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Alvin Marable
-- Create date: Mar 03, 2009
-- Description:	This will update AdditionalAcctSubProd table record
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Customer_UpdateAccountSubProductDetails]
	-- Add the parameters for the stored procedure here
	@AccountID	Int
	, @SubProductId Int
	, @Issue	Int
	, @GST		Money
	, @OriginalDebt Money
	, @Paid		Money
	, @Notes	VarChar(100)
	, @RecordID Int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TotalDebt	Money
		,@Due			Money

	SET @TotalDebt = (@OriginalDebt + @GST)
	SET @Due = (@TotalDebt - @Paid)

	UPDATE AdditionalAcctSubProd
	SET AccountId = @AccountID,
		SubProductId = @SubProductID,
		Issue = @Issue,
		OriginalDebt = @OriginalDebt,
		GST = @GST,
		TotalDebt = @TotalDebt,
		Paid = @Paid,
		Due = @Due,
		Notes = @Notes
	WHERE RecordId = @RecordID
    
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetSubProductTotalUnAllocatedAmount]    Script Date: 03/06/2009 18:21:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetSubProductTotalUnAllocatedAmount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Compute total un-allocated amount for account sub-product.
-- History:
--	2009/03/03	[Alvin Marable]	Initial version.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetSubProductTotalUnAllocatedAmount] 
	@AccountID int,
	@RecorID int,
	@OriginalDebt MONEY,
	@GST MONEY,
	@Paid MONEY,
	@BillAmount MONEY
AS
BEGIN	
	SET NOCOUNT ON;
	
	-- Formula: 
	-- Total un-allocated amount = (BillAmount) – (Sum of original debt of given account)  
	--			- (Sum of GST of given account) – (original debt from screen input) – (GST from screen input)
	
	DECLARE @SumOfOriginalDebt MONEY;
	DECLARE @SumOfGST MONEY;
	DECLARE @SumOfPaid MONEY;

	DECLARE @TotalUnAllocatedAmount MONEY;
	SET @TotalUnAllocatedAmount = 0;
		
	SELECT @SumOfOriginalDebt = SUM(ISNULL(OriginalDebt,0)), 
		   @SumOfGST = SUM(ISNULL(GST,0)) ,
		   @SumOfPaid = SUM(ISNULL(Paid,0))	
	FROM AdditionalAcctSubProd
	WHERE AccountId = @AccountID AND
		RecordId = CASE WHEN ISNULL(@RecorID,0) <> 0 THEN -1 ELSE RecordId END ;

	SET @TotalUnAllocatedAmount = 
		ISNULL(@BillAmount,0) - 
		(ISNULL(@SumOfOriginalDebt,0) + ISNULL(@SumOfGST,0)) - 
		(@OriginalDebt + @GST ) + (ISNULL(@SumOfPaid,0) + @Paid);

	SELECT ISNULL (@TotalUnAllocatedAmount, 0 ) TotalAmount;	


END' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 03/06/2009 18:21:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Groups_GetGroupDebtorList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 03/06/2009 15:52:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Update by:	Aldous Nochefranca / Alvin Marable 
-- Update date: 2009-03-05	
-- Description:	Get list of Group Debtors with Account No. and Customer 's fullName
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
	BEGIN
		DECLARE @PersonID int
		SELECT @PersonID=d.PersonID
		FROM DebtorInformation d
		LEFT JOIN CosigneeInformation c ON c.PersonID = d.PersonID
		WHERE d.DebtorID=@debtorID-- AND c.Relationship_Type IS NULL

		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate]
				, CASE a.PersonID WHEN @PersonID THEN 'Debtor' ELSE r.Description END AS [RelationshipType]
				, a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[DefendantNum], a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				LEFT JOIN PersonInformation p ON a.PersonID = p.PersonID
				LEFT JOIN Account b ON a.AccountID = b.AccountID
				LEFT JOIN CosigneeInformation g ON g.PersonID = a.PersonID AND g.Bill = b.AccountID
				LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE a.GroupID = @groupID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2 AND 
				CASE WHEN ISNULL(r.RelationshipTypeID, 0) = 0 THEN 1 ELSE r.IncludeInGroup END <> 0
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	END
	ELSE
	BEGIN
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,'Debtor' AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum], isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
				LEFT JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
				--LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate], r.Description AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
			LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID) AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2 AND 
				r.IncludeInGroup <> 0
		
		ORDER BY Seq, b.AccountID, FullName
	END
END

GO


SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Sep 25, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_CosigneeInformation_Add] 
	-- Add the parameters for the stored procedure here
	@PersonID int,
	@SocialSecurityNumber varchar(25),
	@AlternateID1 varchar(50),
	@AlternateID1Name varchar(50),
	@Title varchar(50),
	@FirstName varchar(50),
	@MiddleName varchar(50),
	@LastName varchar(50),
	@DateOfBirth smalldatetime = NULL,
	@PString3 varchar(25),
	@Language int,
	@Email varchar(50),
	@NO_Of_Years_Resi varchar(10),
	@PMoney1 money,
	@PString2 varchar(10),
	@PString5 varchar(50),
	@Nationality varchar(50),
	@Fax varchar(30),
	@DriversLicenseNumber varchar(25),
	@PMoney2 money,
	@Profession varchar(50),
	@Business_Type varchar(50),
	@Position varchar(50),
	@Department varchar(35),
	@Employee_Number varchar(50),
	@Employment varchar(50),
	@Employer_Code char(4),
	@EmploymentPhone varchar(30),
	@EmploymentPhoneExtension varchar(8),
	@FriendName varchar(50),
	@Friend_Off_Phone varchar(50),
	@Friend_Res_Phone varchar(30),
	@Friend_FaxNo varchar(30),

	@AccountID int,
	@Relationship_Type varchar(20),

	@EmployeeID int
AS
BEGIN
	DECLARE @TranStarted bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	--If PersonInformation already existed
	IF @PersonID > 0
		--Update the PersonInformation
		UPDATE PersonInformation
		SET
			SocialSecurityNumber = @SocialSecurityNumber,
			PString1 = @SocialSecurityNumber,
			AlternateID1 = @AlternateID1,
			AlternateID1Name = @AlternateID1Name,
			Title = @Title,
			FirstName = @FirstName,
			MiddleName = @MiddleName,
			LastName = @LastName,
			DateOfBirth = @DateOfBirth,
			PString3 = @PString3,
			[Language] = @Language,
			Email = @Email,
			NO_Of_Years_Resi = @NO_Of_Years_Resi,
			PMoney1 = @PMoney1,
			PString2 = @PString2,
			PString5 = @PString5,
			Nationality = @Nationality,
			Fax = @Fax,
			DriversLicenseNumber = @DriversLicenseNumber,
			PMoney2 = @PMoney2,
			Profession = @Profession,
			Business_Type = @Business_Type,
			Position = @Position,
			Department = @Department,
			Employee_Number = @Employee_Number,
			Employment = @Employment,
			Employer_Code = @Employer_Code,
			EmploymentPhone = @EmploymentPhone,
			EmploymentPhoneExtension = @EmploymentPhoneExtension,
			FriendName = @FriendName,
			Friend_Off_Phone = @Friend_Off_Phone,
			Friend_Res_Phone = @Friend_Res_Phone,
			Friend_FaxNo = @Friend_FaxNo
		WHERE
			PersonID = @PersonID
		IF( @@ERROR <> 0)
        GOTO Cleanup
	ELSE
	BEGIN
		--Generate new PersonID
		SELECT @PersonID = MAX(PersonID) + 1
		FROM PersonInformation

		UPDATE IdentityFields
		SET FieldValue = @PersonID
		WHERE LOWER(TableName) = LOWER('PersonInformation')
		IF( @@ERROR <> 0)
        GOTO Cleanup

/*  Add New Debtor Records */
		DECLARE @cDebtorID int
		SELECT @cDebtorID = MAX(DebtorID) + 1
		FROM DebtorInformation

		UPDATE IdentityFields
		SET FieldValue = @cDebtorID
		WHERE LOWER(TableName) = LOWER('DebtorInformation')

		INSERT INTO DebtorInformation 
			(DebtorID,  PersonID, GROUPNAME, LASTEDITDATE)
		values
		(@cDebtorID,@PersonID,@SocialSecurityNumber,getdate())

		--Add new PersonInformation
		INSERT INTO PersonInformation
		(
			PersonID,
			SocialSecurityNumber,
			PString1,
			AlternateID1,
			AlternateID1Name,
			Title,
			FirstName,
			MiddleName,
			LastName,
			DateOfBirth,
			PString3,
			[Language],
			Email,
			NO_Of_Years_Resi,
			PMoney1,
			PString2,
			PString5,
			Nationality,
			Fax,
			DriversLicenseNumber,
			PMoney2,
			Profession,
			Business_Type,
			Position,
			Department,
			Employee_Number,
			Employment,
			Employer_Code,
			EmploymentPhone,
			EmploymentPhoneExtension,
			FriendName,
			Friend_Off_Phone,
			Friend_Res_Phone,
			Friend_FaxNo
		)
		VALUES
		(
			@PersonID,
			@SocialSecurityNumber,
			@SocialSecurityNumber,
			@AlternateID1,
			@AlternateID1Name,
			@Title,
			@FirstName,
			@MiddleName,
			@LastName,
			@DateOfBirth,
			@PString3,
			@Language,
			@Email,
			@NO_Of_Years_Resi,
			@PMoney1,
			@PString2,
			@PString5,
			@Nationality,
			@Fax,
			@DriversLicenseNumber,
			@PMoney2,
			@Profession,
			@Business_Type,
			@Position,
			@Department,
			@Employee_Number,
			@Employment,
			@Employer_Code,
			@EmploymentPhone,
			@EmploymentPhoneExtension,
			@FriendName,
			@Friend_Off_Phone,
			@Friend_Res_Phone,
			@Friend_FaxNo
		)
		IF( @@ERROR <> 0)
        GOTO Cleanup

		DECLARE @index int
		DECLARE @num int
		SET @num = 9
		
		--Add new 9 PersonAddress and 9 PersonPhone
		DECLARE @AddressID int
		SELECT @AddressID = MAX(AddressID)
		FROM PersonAddress

		UPDATE IdentityFields
		SET FieldValue = @AddressID + @num
		WHERE LOWER(TableName) = LOWER('PersonAddress')

		DECLARE @PhoneID int
		SELECT @PhoneID = MAX(PhoneID)
		FROM PersonPhone

		UPDATE IdentityFields
		SET FieldValue = @PhoneID + @num
		WHERE LOWER(TableName) = LOWER('PersonPhone')
		
		SET @index = 1
		WHILE @index <= @num
		BEGIN
			INSERT INTO PersonAddress
			(
				AddressID,
				PersonID,
				AddressType,
				AddressStatus,
				EmployeeID,
				CreateDate
			)
			VALUES
			(
				@AddressID + @index,
				@PersonID,
				@index,
				0,
				@EmployeeID,
				GETDATE()
			)
			IF( @@ERROR <> 0)
			GOTO Cleanup

			INSERT INTO PersonPhone
			(
				PhoneID,
				PersonID,
				PhoneType,
				PhoneStatus,
				EmployeeID,
				CreateDate
			)
			VALUES
			(
				@PhoneID + @index,
				@PersonID,
				@index,
				0,
				@EmployeeID,
				GETDATE()
			)
			IF( @@ERROR <> 0)
			GOTO Cleanup

			SET @index = @index + 1
		END
	END

	--Insert new CosigneeInformation
	DECLARE @InvoiceNumber varchar(50)
	DECLARE @DebtorID int
	DECLARE @InterfaceID int

	SELECT
		@InvoiceNumber = InvoiceNumber,
		@DebtorID = DebtorID,
		@InterfaceID = InterfaceID
	FROM Account
	WHERE AccountID = @AccountID

	--If CosigneeInformation already existed
	IF EXISTS (SELECT Bill FROM CosigneeInformation WHERE Bill = @AccountID AND PersonID = @PersonID)
	BEGIN
		UPDATE CosigneeInformation
		SET
			DebtorID = @DebtorID,
			Relationship_no = @SocialSecurityNumber,
			Relationship_Type = @Relationship_Type,
			Account_no = @InvoiceNumber,
			InterfaceID = @InterfaceID
		WHERE
			Bill = @AccountID AND PersonID = @PersonID
		IF( @@ERROR <> 0)
        GOTO Cleanup
	END
	ELSE
	BEGIN
		INSERT INTO CosigneeInformation
		(
			Bill,
			PersonID,
			DebtorID,
			Relationship_no,
			Relationship_Type,
			Account_no,
			InterfaceID
		)
		VALUES
		(
			@AccountID,
			@PersonID,
			@DebtorID,
			@SocialSecurityNumber,
			@Relationship_Type,
			@InvoiceNumber,
			@InterfaceID
		)
		IF( @@ERROR <> 0)
        GOTO Cleanup
	END

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

	SELECT @PersonID
END

GO