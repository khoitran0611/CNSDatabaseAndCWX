﻿-- Script is applied on version 3.6.1:

-- Start of Scripts 3.6.1:


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debtors with Account No. and Customer 's fullName
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
	BEGIN
		DECLARE @PersonID int
		SELECT @PersonID=d.PersonID
		FROM DebtorInformation d
		LEFT JOIN CosigneeInformation c ON c.PersonID = d.PersonID
		WHERE d.DebtorID=@debtorID-- AND c.Relationship_Type IS NULL

		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate]
				, CASE a.PersonID WHEN @PersonID THEN 'Debtor' ELSE r.Description END AS [RelationshipType]
				, a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[DefendantNum], a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				LEFT JOIN PersonInformation p ON a.PersonID = p.PersonID
				LEFT JOIN Account b ON a.AccountID = b.AccountID
				LEFT JOIN CosigneeInformation g ON g.PersonID = a.PersonID AND g.Bill = b.AccountID
				LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE a.GroupID = @groupID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2 AND r.IncludeInGroup <> 0
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	END
	ELSE
	BEGIN
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,'Debtor' AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum], isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
				LEFT JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
				--LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate], r.Description AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
			LEFT JOIN Legal_RelationshipTypes r ON r.RelationshipTypeID = g.Relationship_Type
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID) AND b.AgencyStatusID <> 2 AND b.SystemStatusID <> 2 AND r.IncludeInGroup <> 0
		
		ORDER BY Seq, b.AccountID, FullName
	END
END
GO

IF (Select count(*) From IdentityFields where tablename = 'DisplayIntForecast') = 0
	BEGIN
		INSERT INTO IDENTITYFIELDS VALUES('DisplayIntForecast',1)
	END
GO

ALTER TABLE AccountPromise
ADD Rate DECIMAL(18,2) NULL
GO

ALTER TABLE AccountPromise
ADD InterestAmount Money null
GO

ALTER TABLE AccountPromise ALTER COLUMN Period int
GO

ALTER PROCEDURE [dbo].[CWX_AccountPromise_GetBrokenPromiseList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(PromiseID)
	FROM AccountPromise
	WHERE
		Status = 3 AND AccountID = @AccountID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
			p.PromiseID,
			p.AccountID,
			p.AmountPromised,
			p.DatePromised,
			p.Status,
			p.AmountPaid,
			p.DatePaid,
			p.Period,
			p.Term,
			p.PromiseFrequency,
			p.Rate,
			p.InterestAmount,
			e.EmployeeName
		FROM AccountPromise p
		LEFT JOIN Employee e ON p.EmployeeID = e.EmployeeID
		WHERE
			p.Status = 3 AND p.AccountID = @AccountID
	)

	SELECT * FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
GO

ALTER PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseDueList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(PromiseID)
	FROM AccountPromise
	WHERE
		Status = 0 AND AccountID = @AccountID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
			p.PromiseID,
			p.AccountID,
			p.AmountPromised,
			p.DatePromised,
			p.Status,
			p.AmountPaid,
			p.DatePaid,
			p.Period,
			p.Term,
			p.PromiseFrequency,
			p.Rate,
			p.InterestAmount,
			e.EmployeeName,
			a.CodeDesc as PromiseGiver
		FROM AccountPromise p
		LEFT JOIN Employee e ON p.EmployeeID = e.EmployeeID
		LEFT JOIN AccountCodeMaster a ON p.PromiseGiver = a.CodeID
		WHERE
			p.Status = 0 AND p.AccountID = @AccountID
	)

	SELECT * FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
GO
ALTER PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseHistoryList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(PromiseID)
	FROM AccountPromise
	WHERE
		Status in (1,2) AND AccountID = @AccountID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
			p.PromiseID,
			p.AccountID,
			p.AmountPromised,
			p.DatePromised,
			p.Status,
			p.AmountPaid,
			p.DatePaid,
			p.Period,
			p.Term,
			p.PromiseFrequency,
			p.Rate,
			p.InterestAmount,
			e.EmployeeName
		FROM AccountPromise p
		LEFT JOIN Employee e ON p.EmployeeID = e.EmployeeID
		WHERE
			p.Status in (1,2) AND p.AccountID = @AccountID
	)

	SELECT * FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END
GO
ALTER PROCEDURE [dbo].[CWX_AccountPromise_GetBrokenPromiseList] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount=COUNT(PromiseID)
	FROM AccountPromise
	WHERE
		Status = 3 AND AccountID = @AccountID

	WITH Temp AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY p.DatePromised) AS RowNumber,
			p.PromiseID,
			p.AccountID,
			p.AmountPromised,
			p.DatePromised,
			p.Status,
			p.AmountPaid,
			p.DatePaid,
			p.Period,
			p.Term,
			p.PromiseFrequency,
			p.Rate,
			p.InterestAmount,
			e.EmployeeName
		FROM AccountPromise p
		LEFT JOIN Employee e ON p.EmployeeID = e.EmployeeID
		WHERE
			p.Status = 3 AND p.AccountID = @AccountID
	)

	SELECT * FROM Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount
END

GO