/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_AddRemove]    Script Date: 02/28/2008 15:34:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AllocationSortMaster_AddRemove]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AllocationSortMaster_AddRemove]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_GetAvailable]    Script Date: 02/28/2008 15:34:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AllocationSortMaster_GetAvailable]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AllocationSortMaster_GetAvailable]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_UpdateList]    Script Date: 02/28/2008 15:34:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AllocationSortMaster_UpdateList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AllocationSortMaster_UpdateList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Document_CanDelete]    Script Date: 02/28/2008 15:34:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Document_CanDelete]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Document_CanDelete]

GO
/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_AddRemove]    Script Date: 02/28/2008 15:34:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 20, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AllocationSortMaster_AddRemove] 
	@AccountAllocationSorts varchar(1000)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	IF RTRIM(LTRIM(@AccountAllocationSorts)) <> ''
	BEGIN
		DECLARE @tbAccountAllocationSort table
		(
			QueueID int,
			Description varchar(60),
			QueueColumn varchar(30),
			SortID int,
			SortDirection char(4),
			SQLFormat varchar(100)
		)

		DECLARE @Pos int
		DECLARE @NextPos int
		DECLARE @NewQueueID int
		DECLARE @QueueID int
		DECLARE @Description varchar(60)
		DECLARE @SQLFormat varchar(100)

		SET @Pos = 1
		SET @NewQueueID = 1

		DECLARE @SortID int
		IF EXISTS (SELECT QueueId FROM AllocationSortMaster WHERE sortid = 0)
			SET @SortID = 0
		ELSE
			SET @SortID = @NewQueueID

		WHILE(@Pos <= LEN(@AccountAllocationSorts))
		BEGIN
			SELECT @NextPos = CHARINDEX(N',', @AccountAllocationSorts,  @Pos)
			IF (@NextPos = 0 OR @NextPos IS NULL)
				SELECT @NextPos = LEN(@AccountAllocationSorts) + 1
			SELECT @QueueID = CAST(RTRIM(LTRIM(SUBSTRING(@AccountAllocationSorts, @Pos, @NextPos - @Pos))) AS int)
			SELECT @Pos = @NextPos+1

			SELECT @NextPos = CHARINDEX(N',', @AccountAllocationSorts,  @Pos)
			IF (@NextPos = 0 OR @NextPos IS NULL)
				SELECT @NextPos = LEN(@AccountAllocationSorts) + 1
			SELECT @Description = RTRIM(LTRIM(SUBSTRING(@AccountAllocationSorts, @Pos, @NextPos - @Pos)))
			SELECT @Pos = @NextPos+1

			SELECT @NextPos = CHARINDEX(N',', @AccountAllocationSorts,  @Pos)
			IF (@NextPos = 0 OR @NextPos IS NULL)
				SELECT @NextPos = LEN(@AccountAllocationSorts) + 1
			SELECT @SQLFormat = RTRIM(LTRIM(SUBSTRING(@AccountAllocationSorts, @Pos, @NextPos - @Pos)))
			SELECT @Pos = @NextPos+1

			IF @SortID > 0
				SET @SortID = @NewQueueID

			IF @QueueID = 0
				INSERT INTO @tbAccountAllocationSort
				VALUES(@NewQueueID, @Description, '"' + @Description + '"', @SortID, 'ASC ', @SQLFormat)
			ELSE
				INSERT INTO @tbAccountAllocationSort
				SELECT
					@NewQueueID, Description, QueueColumn, @SortID, SortDirection, SQLFormat
				FROM
					AllocationSortMaster
				WHERE
					QueueId = @QueueID
			
			SET @NewQueueID = @NewQueueID + 1
		END

		DELETE FROM AllocationSortMaster
		IF( @@ERROR <> 0)
			GOTO Cleanup

		INSERT INTO AllocationSortMaster SELECT * FROM @tbAccountAllocationSort
		IF( @@ERROR <> 0)
			GOTO Cleanup
	END
	ELSE
	BEGIN
		DELETE FROM AllocationSortMaster
		IF( @@ERROR <> 0)
			GOTO Cleanup
	END

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END




GO
/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_GetAvailable]    Script Date: 02/28/2008 15:34:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 27th, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AllocationSortMaster_GetAvailable] 
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		CASE SUBSTRING(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))), LEN(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value])))) - 1, 2)
			WHEN '_Q' THEN SUBSTRING(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))), 1, LEN(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value])))) - 2)
			ELSE LTRIM(RTRIM(CONVERT(varchar(125), ex.[value])))
		END AS [Description],
		OBJECT_NAME(c.[object_id]) + '.' + c.[name] AS SQLFormat
	INTO #Temp
	FROM
		sys.[columns] c
		LEFT OUTER JOIN sys.[extended_properties] ex ON ex.[major_id] = c.[object_id]
	WHERE
		OBJECTPROPERTY(c.[object_id], 'IsMsShipped')=0
		AND ex.[minor_id] = c.[column_id]
		AND ex.[name] = 'MS_Description'
		AND (
				OBJECT_NAME(c.[object_id]) = 'Account'
				OR OBJECT_NAME(c.[object_id]) = 'PersonInformation'
				OR OBJECT_NAME(c.[object_id]) = 'DebtorInformation'
				OR OBJECT_NAME(c.[object_id]) = 'PersonAddress'
				OR OBJECT_NAME(c.[object_id]) = 'AccountOther'
			)
		AND LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))) <> ''
	ORDER BY
		ex.[value]

	SELECT
		0 AS QueueId,
		Description,
		('"' + Description + '"') AS QueueColumn,
		0 AS sortid,
		'ASC ' AS SortDirection,
		SQLFormat
	FROM
		#Temp
	WHERE
		[Description] NOT IN (SELECT Description FROM AllocationSortMaster)
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_UpdateList]    Script Date: 02/28/2008 15:34:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 27th, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AllocationSortMaster_UpdateList] 
	@AccountAllocationSorts varchar(1000),
	@Enabled bit
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @QueueID int
	DECLARE @SortDirection char(4)
	DECLARE @SortID int

	IF @Enabled = 1
		SET @SortID = 1
	ELSE
		SET @SortID = 0

	DECLARE @tbAccountAllocationSort table
	(
		QueueID int,
		Description varchar(60),
		QueueColumn varchar(30),
		SortID int,
		SortDirection char(4),
		SQLFormat varchar(100)
	)

	DECLARE @Pos int
	DECLARE @NextPos int
	DECLARE @NewQueueID int

	SET @Pos = 1
	SET @NewQueueID = 1

	WHILE(@Pos <= LEN(@AccountAllocationSorts))
	BEGIN
		SELECT @NextPos = CHARINDEX(N',', @AccountAllocationSorts,  @Pos)
		IF (@NextPos = 0 OR @NextPos IS NULL)
			SELECT @NextPos = LEN(@AccountAllocationSorts) + 1
		SELECT @QueueID = CAST(RTRIM(LTRIM(SUBSTRING(@AccountAllocationSorts, @Pos, @NextPos - @Pos))) AS int)
		SELECT @Pos = @NextPos+1

		SELECT @NextPos = CHARINDEX(N',', @AccountAllocationSorts,  @Pos)
		IF (@NextPos = 0 OR @NextPos IS NULL)
			SELECT @NextPos = LEN(@AccountAllocationSorts) + 1
		SELECT @SortDirection = RTRIM(LTRIM(SUBSTRING(@AccountAllocationSorts, @Pos, @NextPos - @Pos)))
		SELECT @Pos = @NextPos+1

		INSERT INTO @tbAccountAllocationSort
		SELECT
			@NewQueueID, Description, QueueColumn, @SortID, @SortDirection, SQLFormat
		FROM
			AllocationSortMaster
		WHERE
			QueueId = @QueueID

		IF @Enabled = 1
			SET @SortID = @SortID + 1
		SET @NewQueueID = @NewQueueID + 1
	END

	DELETE FROM AllocationSortMaster
	IF( @@ERROR <> 0)
        GOTO Cleanup

	INSERT INTO AllocationSortMaster SELECT * FROM @tbAccountAllocationSort
	IF( @@ERROR <> 0)
        GOTO Cleanup

	IF( @TranStarted = 1 )
	BEGIN
		SET @TranStarted = 0
		COMMIT TRANSACTION

		--SET ROWCOUNT 1
    END

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

END


GO
/****** Object:  StoredProcedure [dbo].[CWX_Document_CanDelete]    Script Date: 02/28/2008 15:34:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 18, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Document_CanDelete] 
	-- Add the parameters for the stored procedure here
	@DocumentID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @CanDelete bit
    IF EXISTS(SELECT ID FROM RuleTable WHERE Letter = @DocumentID)
		SET @CanDelete = 0
	ELSE
		SET @CanDelete = 1
	SELECT @CanDelete
END
 
 -- =======================================================================
-- Author:		Tuan Luong
-- Create date: Feb 26, 2008
-- Description:	Add column 'Status' with default value 'A'
--			    use this field to mark the row is active 'A' or retire 'R'
-- Database:    CWorks_V6
-- =======================================================================
ALTER TABLE TicketDefinition
ADD Status char(1) NOT NULL
	CONSTRAINT [TicketDefinition_RowStatus] DEFAULT 'A'
GO

-- =============================================
-- Author:		Tuan Luong
-- Create date: Feb 26, 2008
-- Description:	
-- Database:    CWorks_V6
-- =============================================
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CWX_TicketDefinition_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TicketDefinition_GetPagingList]
GO
CREATE PROCEDURE [dbo].[CWX_TicketDefinition_GetPagingList]	
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		ROW_NUMBER() OVER (ORDER BY t.EmployeeID) AS RowNumber,
		t.TktDefID as TicketDefinitionID,
		t.Description,
		t.ApprovalLevel,
		t.ApproverDays,
		t.RoleID,		
		ISNULL(e.EmployeeName, '') as EmployeeName,
		t.EmpDDays,
		t.TicketType		
	INTO #Temp
	FROM TicketDefinition t LEFT JOIN Employee e 
	ON t.EmployeeID = e.EmployeeID AND e.EmployeeStatus <> 'R'
	WHERE  t.Status <> 'R'		

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT * FROM #Temp WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	ORDER BY TicketDefinitionID
	
	RETURN @RowCount
END
GO

-- =============================================================
-- Author:		Tuan Luong
-- Create date: Feb 29, 2008
-- Description:	Delete all records in TicketDefinition Table
--				where TicketType is other than 'S'
-- Parameters: 
--	@Type: 'S' - Soft delete
--		   'P' - Permanently delete
-- Database:    CWorks_V6
-- =============================================================
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CWX_TicketDefinition_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TicketDefinition_DeleteAll]
GO
CREATE PROCEDURE [dbo].[CWX_TicketDefinition_DeleteAll]
	@Status char(1) = 'S'		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = 'S'
	BEGIN
		UPDATE TicketDefinition
		SET [Status] = 'R'
		WHERE [Status] = 'A' and TicketType <> 'S'
	END
	ELSE IF UPPER(@Status) = 'P'
	BEGIN    
		DELETE TicketDefinition
		WHERE TicketType <> 'S'
	END
END
GO