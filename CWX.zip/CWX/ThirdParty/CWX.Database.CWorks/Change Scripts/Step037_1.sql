﻿-- Script is applied on version 3.6.7 Build 2:

PRINT 'Start of Scripts 3.6.7 Build 2'
GO

 --Add DefaultPrinter column in DefineLetters
ALTER TABLE DefineLetters
ADD DefaultPrinter varchar(250) null
GO


PRINT 'Completed execution of Scripts 3.6.7 Build 2'
GO