﻿-- [2010-01-06]	[Minh Dam]	Add "PersonID" cloumn to AccountLetterQueue table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'AccountLetterQueue' AND COLUMN_NAME = 'PersonID')
BEGIN
       ALTER TABLE AccountLetterQueue
            ADD PersonID int NULL
END
GO


-- [2010-01-06] [Minh Dam]	Alter SP CWX_AccountLetterQueue_InsertLetterQueueForCMSScreen
/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterQueue_InsertLetterQueueForCMSScreen]    Script Date: 01/06/2010 15:36:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Insert new record of AccountLetterQueue table. AddressType field handle the default value.
-- History:
--	2008/12/01	[Binh Truong]	Init version.
--	2010/01/06	[Minh Dam]		Insert PersonID to AccountLetterQueue
-- =============================================
ALTER PROCEDURE [dbo].[CWX_AccountLetterQueue_InsertLetterQueueForCMSScreen]
	@LetterID	int,
	@AccountID	int,
	@DebtorID	int,
	@EmployeeID	int,
	@RunDate	datetime	
AS
BEGIN
	DECLARE @personID int
	SELECT @personID = PersonID
	FROM DebtorInformation
	WHERE DebtorID = @DebtorID

	INSERT INTO AccountLetterQueue
	            (AccountID, LetterID, RunDate, XmitStatus, EmployeeID, PersonID)
	VALUES		(@AccountID,@LetterID,@RunDate, 'O',      @EmployeeID, @personID)
END
GO