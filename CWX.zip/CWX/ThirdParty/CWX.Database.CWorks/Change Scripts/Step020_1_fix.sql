 /****** Object:  StoredProcedure [dbo].[CWX_Employee_GetLoginDetails]    Script Date: 10/15/2008 13:31:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <6 September 2008>
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Employee_GetLoginDetails]
	@EmployeeIDString varchar(1000),
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount INT
	SET @RowCount = 0

	IF (@EmployeeIDString != '')
	BEGIN
		DECLARE @querystring varchar(2000);
		CREATE TABLE #Temp(
			RowNumber int,
			EmployeeID int,
			EmployeeName varchar(10),
			ViewedNo int,		
			AccountIDViewing int
		);

		SET @querystring = 'INSERT INTO #Temp
			SELECT 
			ROW_NUMBER() OVER (ORDER BY  e.EmployeeID ASC) AS RowNumber,		
			e.EmployeeID, e.UserID, ISNULL(COUNT(a1.RecordID),0) AS ViewedNo, ISNULL(a2.AccountID,0) AS AccountIDViewing
			FROM Employee e 
			LEFT JOIN 
				(SELECT * FROM AccountActions 
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID=8
				) AS a1
			ON e.EmployeeID = a1.CompletedBy
			LEFT JOIN 
				(SELECT AccountID, CompletedBy FROM AccountActions AS a
					WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
					AND ActionID=8
					AND RecordID >= (SELECT MAX(RecordID) FROM AccountActions
												WHERE CONVERT(varchar(10), DateCompleted, 121) = CONVERT(varchar(10), GETDATE(), 121)
												AND ActionID=8
												AND CompletedBy=a.CompletedBy)
				) AS a2
			ON e.EmployeeID = a2.CompletedBy
			WHERE e.EmployeeID IN (' + @EmployeeIDString + ')
			GROUP BY e.EmployeeID, e.UserID, a2.AccountID'
		
		EXEC (@querystring)
		
		SELECT @RowCount = @@ROWCOUNT
		
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
		
		DROP TABLE #Temp
	END
	
	RETURN @RowCount

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Rates_GetPagingListByTransactionType]    Script Date: 10/15/2008 13:44:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThuyNguyen
-- Create date: Sep 18, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Legal_Rates_GetPagingListByTransactionType]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0,
	@TransactionTypeID int = 0

AS
BEGIN
	
	DECLARE @RowCount int, @RowNumber int;
	DECLARE @CountString varchar(100), @QueryString varchar(500), @WhereClause varchar(100);	
	
	IF @TransactionTypeID<>0
	BEGIN
		SET @WhereClause = ' AND TransactionTypeID = ' + CAST(@TransactionTypeID AS VARCHAR)
		SELECT @RowCount = COUNT(ID) FROM Legal_Rates WHERE Status <> 'R' AND TransactionTypeID = @TransactionTypeID
	END
	ELSE 
	BEGIN
		SET @WhereClause = ''
		SELECT @RowCount = COUNT(ID) FROM Legal_Rates WHERE Status <> 'R'
	END

	IF @PageSize*(@PageIndex+1) > @RowCount 
		SET @RowNumber = @RowCount - (@PageSize*@PageIndex)
	ELSE 
		SET @RowNumber = @PageSize

	SET @QueryString = '
	SELECT * FROM 
		(SELECT TOP (' + CAST(@RowNumber AS VARCHAR) + ') * FROM  
			(SELECT TOP (' + CAST((@PageIndex + 1)*@PageSize AS VARCHAR) + ') 
				r.*, 
				(t.TransactionCode + '' - '' + t.Description) AS TransactionType
			FROM Legal_Rates r 
				LEFT JOIN TransactionType t ON t.ID = r.TransactionTypeID
			WHERE r.Status <> ''R''' + @WhereClause + '			
			ORDER BY RateCode ASC) as t1 
		ORDER BY RateCode DESC) as t2 
	ORDER BY RateCode ASC
	'
	EXEC(@QueryString)
	RETURN @RowCount

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_Groups_GetGroupDebtorList]    Script Date: 10/15/2008 13:50:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thao Nguyen
-- Create date: 2008-07-16
-- Description:	Get list of Group Debtors with Account No. and Customer 's fullName
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Legal_Groups_GetGroupDebtorList] 
	-- Add the parameters for the stored procedure here
	@groupID int,
	@debtorID int,
	@accountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @groupID <> 0
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate] ,ISNULL(g.Relationship_Type, 'Debtor') AS [RelationshipType] ,a.[Liability] ,a.[AccountID] ,a.[LegalTypeID] ,a.[IsDefendant] ,a.[DefendantNum], a.[IsInclude] ,a.[IsPrincipal] ,a.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
		FROM Legal_GroupDebtors a
				LEFT JOIN PersonInformation p ON a.PersonID = p.PersonID
				LEFT JOIN Account b ON a.AccountID = b.AccountID
				LEFT JOIN CosigneeInformation g ON g.PersonID = a.PersonID AND g.Bill = b.AccountID
		WHERE a.GroupID = @groupID
		ORDER BY IsNull(a.DebtorID, 0) DESC, a.AccountID
	ELSE
	BEGIN
		SELECT a.[GroupDebtorID] ,a.[GroupID] ,b.[DebtorID] ,a.[LastEditDate] ,'Debtor' AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum], isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal],g.[PersonID]
			, b.InvoiceNumber
			,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
			,1 as Seq
			FROM DebtorInformation g
				LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
				LEFT JOIN Account b ON g.DebtorID = b.DebtorID
				LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
				LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.DebtorID = @debtorID AND b.AccountID = @accountID

		UNION

		SELECT  a.[GroupDebtorID] ,a.[GroupID] ,a.[DebtorID] ,a.[LastEditDate] ,g.Relationship_Type AS [RelationshipType] ,a.[Liability] ,b.[AccountID] ,a.[LegalTypeID] ,IsNull(a.[IsDefendant], 0) [IsDefendant],a.[DefendantNum],isNull(a.[IsInclude], 0) [IsInclude],IsNull(a.[IsPrincipal], 0) [IsPrincipal] ,g.[PersonID]
				, b.InvoiceNumber
				,(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName
				,2 as Seq
		FROM
			CosigneeInformation g 
			LEFT JOIN Account b ON g.Bill = b.AccountID
			LEFT JOIN PersonInformation p ON g.PersonID = p.PersonID
			LEFT JOIN (SELECT * FROM Legal_GroupDebtors WHERE GroupID = 0) a ON g.PersonID = a.PersonID
			LEFT JOIN Legal_RelationshipTypes r ON a.[RelationshipTypeID] = r.[RelationshipTypeID]
		WHERE g.Bill IN (SELECT AccountID FROM Account WHERE DebtorID = @debtorID)
		
		ORDER BY Seq, b.AccountID, FullName
	END
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_IsGroupedAccount]    Script Date: 10/15/2008 14:15:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER PROCEDURE [dbo].[CWX_Account_IsGroupedAccount]
	-- Add the parameters for the stored procedure here
	@AccountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	IF EXISTS(	SELECT *
				FROM Legal_GroupDebts a
					INNER JOIN Legal_Groups b ON a.GroupID = b.GroupID
				WHERE a.AccountID = @AccountID AND a.IsInclude = 1 AND b.Status <> 'R')
		RETURN 1
	ELSE
		RETURN 0
END
GO


