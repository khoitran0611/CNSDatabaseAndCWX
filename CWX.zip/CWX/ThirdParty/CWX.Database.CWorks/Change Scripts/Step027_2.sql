﻿-- Script is applied on version 3.5.1:

-- Scripts 3.5.1

set ANSI_NULLS ON
go
set QUOTED_IDENTIFIER ON
go


IF EXISTS(SELECT 1 FROM sys.objects where [name]=N'CWX_CosigneeInformation_GetListByAccountID' and [type]='P')
   drop procedure CWX_CosigneeInformation_GetListByAccountID
go

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 18, 2008
-- Description:	
-- =============================================
create PROCEDURE [dbo].[CWX_CosigneeInformation_GetListByAccountID] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(c.PersonID)
	FROM CosigneeInformation c
	JOIN PersonInformation p ON c.PersonID = p.PersonID
	JOIN PersonAddress a ON a.PersonID = p.PersonID
	WHERE
		a.AddressType = 2
		AND c.Bill = @AccountID

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + p.LastName)) AS RowNumber,
			c.PersonID,
			(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName,			
			(r.Code + ' - ' + r.Description) AS Relationship_no,
            c.Relationship_no as Relationship_no1,   
			a.Address1,
			a.City,
			a.State,
			a.Zip,
			p.HomePhone,
			p.MobilPhone,
			p.EmploymentPhone
		FROM CosigneeInformation c
		JOIN PersonInformation p ON c.PersonID = p.PersonID
		JOIN PersonAddress a ON a.PersonID = p.PersonID
		LEFT JOIN Legal_RelationshipTypes r ON CAST(r.RelationshipTypeID AS varchar(20)) = c.Relationship_Type
		WHERE
			a.AddressType = 2
			AND c.Bill = @AccountID
	)

	SELECT *
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END
go

IF EXISTS(SELECT 1 FROM sys.objects where [name]=N'CWX_CosigneeInformation_Delete' and [type]='P')
   drop procedure CWX_CosigneeInformation_Delete
go

-- =============================================
-- Author:		Jhessie Boy Gabitanan
-- Create date: 10:17 AM 1/14/2009
-- Description:
-- =============================================
CREATE PROCEDURE CWX_CosigneeInformation_Delete
	@accountID int,
    @relationship_no varchar(30)
AS
BEGIN
	delete from CosigneeInformation where Bill = @accountID and Relationship_no = @relationship_no
END
GO

if (exists(select 1 from sys.objects where [name]=N'CWX_Account_GetGroupedAccountID' and [type]=N'P'))
   drop procedure CWX_Account_GetGroupedAccountID
go

-- =============================================
-- Author:		Jhessie Boy B. Gabitanan
-- Create date: 3:38 PM 1/15/2009
-- Description:	
-- =============================================
CREATE PROCEDURE CWX_Account_GetGroupedAccountID
	@accountID int
AS
BEGIN	

select lg.GroupID
from  dbo.legal_groups lg
      inner join dbo.legal_groupdebts lgd
        on (lg.GroupID = lgd.GroupID) and (lg.Status <> 'R')
where (lgd.IsInclude = 1) and ((lgd.AccountID = @accountID) or (lg.GroupedAccountID = @accountID))

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Product_GetSubProductList]    Script Date: 01/15/2009 20:03:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetSubProductList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_GetSubProductList]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Product_GetSubProductList]    Script Date: 01/15/2009 20:01:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Aldous Nochefranca
-- Create date: 9:50 AM 1/13/2009
-- Description:	
-- =============================================
CREATE Procedure [CWX_Product_GetSubProductList]
(
@ParentProductID int
)
AS
BEGIN

	SELECT ClientSubProductInfo.SubClientID, ClientSubProductInfo.ProductCode, 
		ClientSubProductInfo.ProductName, ClientSubProductInfo.Status, 
		ClientSubProductInfo.Note, ClientSubProductInfo.ParentClientID, 
		ClientSubProductInfo.SalesCanvass, ClientSubProductInfo.ProductGroup, 
		ClientSubProductInfo.ProductType, ClientInformation.ClientName AS ParentProductName
	FROM ClientSubProductInfo INNER JOIN
		ClientInformation ON ClientSubProductInfo.ParentClientID = ClientInformation.ClientID
	Where ClientSubProductInfo.[Status] = 'A' AND ParentClientID = @ParentProductID

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Product_GetSubProductList]    Script Date: 01/15/2009 20:03:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_SeachPersonInformation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_SeachPersonInformation]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Employee_SeachPersonInformation]    Script Date: 01/16/2009 11:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Morris Mervin Mendoza
-- Create date: 9:50 AM 1/15/2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Employee_SeachPersonInformation]
	-- Add the parameters for the stored procedure here
	@CustomerName varchar(50) = '',
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN

	SET NOCOUNT ON;	

	DECLARE @RowCount int
	CREATE TABLE #Temp
	(
		RowNumber int,	
		PersonID int,
		CustomerName varchar(50),
		RelationshipNumber varchar(50),
		ID		varchar(25)
	)

	IF @CustomerName = ''
		BEGIN
			INSERT INTO #Temp
			SELECT ROW_NUMBER() OVER (ORDER BY a.PersonID) as RowNumber, a.PersonID,
			(a.FirstName + ' ,' + a.MiddleName + ' ,' + a.LastName) as CustomerName, 
			b.GroupName,
			a.SocialSecurityNumber
			FROM [dbo].[PersonInformation] a
			INNER JOIN [dbo].[DebtorInformation] b on a.PersonID = b.PersonID
		END
	ELSE
		BEGIN
			INSERT INTO #Temp
			SELECT ROW_NUMBER() OVER (ORDER BY a.PersonID) as RowNumber, a.PersonID,
			a.FirstName + ' ,' + a.MiddleName + ' ,' + a.LastName as CustomerName, 
			b.GroupName,
			a.SocialSecurityNumber
			FROM [dbo].[PersonInformation] a
			INNER JOIN [dbo].[DebtorInformation] b on a.PersonID = b.PersonID
			WHERE a.FirstName LIKE ('%' + @CustomerName + '%') 
			OR a.MiddleName LIKE ('%' + @CustomerName + '%') 
			OR a.LastName LIKE ('%' + @CustomerName + '%') 
		END

	SELECT @RowCount = @@ROWCOUNT

	IF @PageSize <= 0
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_AdditionalDataDetails_AddDynamicFields]    Script Date: 01/26/2009 07:48:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AdditionalDataDetails_AddDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AdditionalDataDetails_AddDynamicFields]

GO
/****** Object:  StoredProcedure [dbo].[CWX_AdditionalDataDetails_AddDynamicFields]    Script Date: 01/26/2009 19:50:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Morris Mendoza
-- Create date: 20/01/2008
-- Description:	
-- =============================================				
CREATE PROCEDURE [dbo].[CWX_AdditionalDataDetails_AddDynamicFields]
	@AdditionalDataID int,
	@AccountID int,
	@PrimaryID int,
	@columns varchar(4000),
	@values varchar(4000),
	@updatesql varchar(4000)
AS

BEGIN
	DECLARE @tablename varchar(4000)	
--delete existing values in AdditionalDetails table
	SELECT @tablename = tablename from CWX_AdditionalDataDetails Where ID = @AdditionalDataID

	--DELETE FROM AdditionalFields WHERE AccountID = @AccountID
	
	DECLARE @Sql varchar(4000)

	IF @AccountID = 0 OR @AccountID = null
		BEGIN
			SET @Sql = 'INSERT INTO ' +  @tablename + ' (' + @columns + ') VALUES (' + @values + ')'
		END
	ELSE
		BEGIN
		Declare @ColumnName varchar(4000)
		SELECT @ColumnName = [name]
		FROM syscolumns 
		WHERE [id] IN (SELECT [id] FROM sysobjects 
						 WHERE [name] = @TableName)
		   AND colid IN (SELECT SIK.colid FROM sysindexkeys SIK 
						   JOIN sysobjects SO ON SIK.[id] = SO.[id]  
						  WHERE SIK.indid = 1
							AND SO.[name] = @TableName)
			SET @Sql = 'UPDATE ' + @tablename + ' ' + @updatesql + ' WHERE AccountID = ' + cast(@AccountID as varchar)
			--+ ' and ' + @ColumnName + '=' + cast(@PrimaryID as varchar)
		END
	EXEC(@sql)

	SELECT @@RowCOUNT
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_AdditionalDataDetails_GetDynamicFields]    Script Date: 01/26/2009 07:48:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AdditionalDataDetails_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AdditionalDataDetails_GetDynamicFields]

GO
/****** Object:  StoredProcedure [dbo].[CWX_AdditionalDataDetails_GetDynamicFields]    Script Date: 01/26/2009 16:50:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Morris Mendoza
-- Create date: 20/01/2008
-- Description:	
-- =============================================				
CREATE PROCEDURE [dbo].[CWX_AdditionalDataDetails_GetDynamicFields]
	@AdditionalDataID int,
	@AccountID int,
	@PrimaryID int
AS
BEGIN
DECLARE @TableName varchar(100),@count int

SELECT a.ColumnNames,a.TableName INTO #ColumnSetTable 
FROM (Select ColumnNames, TableName from CWX_AdditionalDataDetails Where ID = @AdditionalDataID) a
SELECT @count = Count(*) From #ColumnSetTable
SELECT @TableName = Tablename From #ColumnSetTable

	DECLARE @FieldName varchar(4000)
	DECLARE curColumn CURSOR FOR
		SELECT ColumnNames FROM #ColumnSetTable
	OPEN curColumn
	FETCH NEXT FROM curColumn INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		select txt_value as [ColumnName] INTO #finaltable From fn_ParseText2Table(@FieldName, ',')
		Select a.ColumnName,b.[DataType],b.[MaxLength] 
		From #finaltable a
		INNER JOIN 
				(SELECT c.[name] as [ColumnName], t.[name] as [DataType], c.[max_length] as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id]
WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = @TableName and [Type]='U')
		) b 
		ON a.[ColumnName] = b.[ColumnName]

		FETCH NEXT FROM curColumn INTO @FieldName
	END
	CLOSE curColumn
	DEALLOCATE curColumn
	DROP TABLE #ColumnSetTable
	
	DECLARE @FieldNameList varchar(4000)
	SET @FieldNameList = ''
	IF(@count > 0)
	BEGIN
		DECLARE currField CURSOR FOR
			SELECT [ColumnName] FROM #finaltable	
		OPEN currField
		FETCH NEXT FROM currField INTO @FieldName
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			SET @FieldNameList = @FieldNameList + @FieldName + ',';
			FETCH NEXT FROM currField INTO @FieldName
		END
		SET @FieldNameList = Left(@FieldNameList, Len(@FieldNameList)-1)
		--PRINT @FIeldNameList
		CLOSE currField
		DEALLOCATE currField

		DROP TABLE #finaltable	
	END

Declare @ColumnName varchar(4000)
SELECT @ColumnName = [name]
FROM syscolumns 
WHERE [id] IN (SELECT [id] FROM sysobjects 
                 WHERE [name] = @TableName)
   AND colid IN (SELECT SIK.colid FROM sysindexkeys SIK 
                   JOIN sysobjects SO ON SIK.[id] = SO.[id]  
                  WHERE SIK.indid = 1
                    AND SO.[name] = @TableName)

	DECLARE @Sql varchar(4000)

	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM '+ @TableName + ' WHERE ACCOUNTID = ' + cast(@AccountID as varchar)
		--+ ' AND ' + @ColumnName + '=' + cast(@PrimaryID as varchar)
	PRINT @SQL	
EXEC (@Sql)

END


GO
/****** Object:  UserDefinedFunction [dbo].[fn_ParseText2Table]    Script Date: 01/26/2009 07:49:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn_ParseText2Table]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[fn_ParseText2Table]

GO
/****** Object:  UserDefinedFunction [dbo].[fn_ParseText2Table]    Script Date: 01/26/2009 07:49:58 ******/
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER ON
GO
create   function [dbo].[fn_ParseText2Table] 
 (
 @p_SourceText  varchar(8000)
 ,@p_Delimeter varchar(100) = ',' --default to comma delimited.

 )
RETURNS @retTable TABLE 
 (
  Position  int identity(1,1)
 ,Int_Value int 
 ,Num_value Numeric(18,3)
 ,txt_value varchar(2000)
 )
AS
/*
********************************************************************************
Purpose: Parse values from a delimited string
  & return the result as an indexed table
Copyright 1996, 1997, 2000, 2003 Clayton Groom (Clayton_Groom@hotmail.com)
Posted to the public domain Aug, 2004
06-17-03 Rewritten as SQL 2000 function.
 Reworked to allow for delimiters > 1 character in length 
 and to convert Text values to numbers
********************************************************************************
*/
BEGIN
 DECLARE @w_Continue  int
  ,@w_StartPos  int
  ,@w_Length  int
  ,@w_Delimeter_pos int
  ,@w_tmp_int  int
  ,@w_tmp_num  numeric(18,3)
  ,@w_tmp_txt   varchar(2000)
  ,@w_Delimeter_Len tinyint
 if len(@p_SourceText) = 0
 begin
  SET  @w_Continue = 0 -- force early exit

 end 
 else
 begin
 -- parse the original @p_SourceText array into a temp table

  SET  @w_Continue = 1
  SET @w_StartPos = 1
  SET @p_SourceText = RTRIM( LTRIM( @p_SourceText))
  SET @w_Length   = DATALENGTH( RTRIM( LTRIM( @p_SourceText)))
  SET @w_Delimeter_Len = len(@p_Delimeter)
 end
 WHILE @w_Continue = 1
 BEGIN
  SET @w_Delimeter_pos = CHARINDEX( @p_Delimeter
      ,(SUBSTRING( @p_SourceText, @w_StartPos
      ,((@w_Length - @w_StartPos) + @w_Delimeter_Len)))
      )
 
  IF @w_Delimeter_pos > 0  -- delimeter(s) found, get the value

  BEGIN
   SET @w_tmp_txt = LTRIM(RTRIM( SUBSTRING( @p_SourceText, @w_StartPos 
        ,(@w_Delimeter_pos - 1)) ))
   if isnumeric(@w_tmp_txt) = 1
   begin
    set @w_tmp_int = cast( cast(@w_tmp_txt as numeric) as int)
    set @w_tmp_num = cast( @w_tmp_txt as numeric(18,3))
   end
   else
   begin
    set @w_tmp_int =  null
    set @w_tmp_num =  null
   end
   SET @w_StartPos = @w_Delimeter_pos + @w_StartPos + (@w_Delimeter_Len- 1)
  END
  ELSE -- No more delimeters, get last value

  BEGIN
   SET @w_tmp_txt = LTRIM(RTRIM( SUBSTRING( @p_SourceText, @w_StartPos 
      ,((@w_Length - @w_StartPos) + @w_Delimeter_Len)) ))
   if isnumeric(@w_tmp_txt) = 1
   begin
    set @w_tmp_int = cast( cast(@w_tmp_txt as numeric) as int)
    set @w_tmp_num = cast( @w_tmp_txt as numeric(18,3))
   end
   else
   begin
    set @w_tmp_int =  null
    set @w_tmp_num =  null
   end
   SELECT @w_Continue = 0
  END
  INSERT INTO @retTable VALUES( @w_tmp_int, @w_tmp_num, @w_tmp_txt )
 END
RETURN
END
GO


--Create By: Jhessie Boy Gabitanan
--Description: This script is only intended for Telstra Dynamic Screen under CMS
-- 3:37PM 20-01-2009
IF EXISTS(SELECT 1 FROM sys.objects where [name] = N'AdditionalAcctSubProd' And [type] = N'U')
   drop table AdditionalAcctSubProd;
go
create table AdditionalAcctSubProd(
 AccountID int,
 SubProductID int,
 Issue int,
 OriginalDebt money not null default 0,
 GST money not null default 0,
 TotalDebt money not null default 0,
 Paid money not null default 0,
 Due money not null default 0,
 Notes varchar(100),
 CreatedBy int,
 CreatedOn datetime  
)
go

/****** Object:  Table [dbo].[CWX_AdditionalDataDetails]    Script Date: 01/19/2009 16:18:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

if exists(select * from sys.objects where [name] = N'CWX_AdditionalDataDetails' and [type] = N'U')
   begin
       declare @dc_name varchar(100) 
       if exists(select c.[name], o.[name] from sys.objects o
                     inner join sys.columns c
                               on (o.[object_id] = c.[object_id]) and (c.[name] = N'Editable')
                 where o.[name] = N'CWX_AdditionalDataDetails' and o.[type] = N'U')
          begin                           
			   select @dc_name = dc.[name] 
			   from sys.objects o       
					inner join sys.columns c 
						  on o.[object_id] = c.[object_id] and c.[name] = N'Editable'          
						     inner join sys.default_constraints dc
						           on c.[default_object_id] = dc.[object_id]   
			   where o.[name] = N'CWX_AdditionalDataDetails' and o.[type] = N'U';
               if (@dc_name is not null)                  
                   exec ('ALTER TABLE CWX_AdditionalDataDetails DROP CONSTRAINT ' + @dc_name);                   
               ALTER TABLE CWX_AdditionalDataDetails DROP COLUMN Editable;               
          end     
       if exists(select c.* from sys.objects o
                     inner join sys.columns c
                               on o.[object_id] = c.[object_id] and c.[name] = N'PageName'
                 where o.[name] = N'CWX_AdditionalDataDetails' and o.[type] = N'U')
          begin
               ALTER TABLE CWX_AdditionalDataDetails DROP COLUMN PageName 
          end                                                        
   end 
go

ALTER TABLE [dbo].[CWX_AdditionalDataDetails]
	ADD Editable bit not null default 0, PageName varchar(100) null        
go

SET ANSI_PADDING OFF
go

-- Script is applied on version 3.5.0:

-- Scripts 3.5.0
IF NOT Exists(select * from sys.columns where Name = N'PrintBatchID' and Object_ID = Object_ID(N'AccountLetter'))
	BEGIN
		ALTER TABLE AccountLetter
		ADD PrintBatchID int
		
		ALTER TABLE AccountLetter
		ADD DefaultPrinter nvarchar(50)
	END
GO


IF EXISTS(SELECT 1 FROM sys.objects WHERE [name]=N'CWX_AccountLetterPrintBatch_GetPrintBatch' and [type]='P')
DROP PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_GetPrintBatch]
GO
IF EXISTS(SELECT 1 FROM sys.objects WHERE [name]=N'CWX_AccountLetterPrintBatch_GetPrintBatches' and [type]='P')
DROP PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_GetPrintBatches]
GO
IF EXISTS(SELECT 1 FROM sys.objects WHERE [name]=N'CWX_AccountLetterPrintBatch_CreatePrintBatch' and [type]='P')
DROP PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_CreatePrintBatch]
GO
IF EXISTS(SELECT 1 FROM sys.objects WHERE [name]=N'CWX_AccountLetterPrintBatch_UpdateAccountLetterByPrintBatch' and [type]='P')
DROP PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_UpdateAccountLetterByPrintBatch]
GO
IF EXISTS(SELECT 1 FROM sys.objects WHERE [name]=N'CWX_AccountLetterPrintBatch_GetRules' and [type]='P')
DROP PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_GetRules]
GO
IF EXISTS(SELECT 1 FROM sys.objects WHERE [name]=N'CWX_AccountLetterPrintBatch_UpdateStatus' and [type]='P')
DROP PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_UpdateStatus]
GO
IF EXISTS(SELECT 1 FROM sys.objects WHERE [name]=N'CWX_AccountLetterPrintBatch_GetEmployees' and [type]='P')
DROP PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_GetEmployees]
GO
IF EXISTS(SELECT 1 FROM sys.objects WHERE [name]=N'CWX_AccountLetterPrintBatch_GetLettersByPrintBatch' and [type]='P')
DROP PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_GetLettersByPrintBatch]
GO
IF EXISTS(SELECT 1 FROM sys.objects WHERE [name]=N'AccountLetterPrintBatch' and [type]='P')
DROP TABLE [dbo].[AccountLetterPrintBatch]
GO

/****** Object:  Table [dbo].[AccountLetterPrintBatch]    Script Date: 11/27/2008 14:53:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AccountLetterPrintBatch](
	[PrintBatchID] [int] IDENTITY(1,1) NOT NULL,
	[PrinterName] [nvarchar](50) NOT NULL,
	[RuleID] [int] NULL,
	[EmployeeID] [int] NULL,
	[UserID] [int] NOT NULL CONSTRAINT [DF_AccountLetterPrintBatch_UserID]  DEFAULT ((0)),
	[Team] [nvarchar](50) NULL,
	[PrinterTray] [nvarchar](50) NULL,
	[NumberOfCopies] [int] NOT NULL CONSTRAINT [DF_AccountLetterPrintBatch_NumberOfCopies]  DEFAULT ((1)),
	[DatePrinted] [datetime] NULL,
	[PrintStatus] [int] NOT NULL CONSTRAINT [DF_AccountLetterPrintBatch_PrintStatus]  DEFAULT ((0)),
	[ErrorLog] [nvarchar](500) NULL,
 CONSTRAINT [PK_AccountLetterPrintBatch] PRIMARY KEY CLUSTERED 
(
	[PrintBatchID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterPrintBatch_UpdateAccountLetterByPrintBatch]    Script Date: 11/27/2008 14:53:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Michael Pacana
-- Create date: 11/21/2008
-- Description:	Updates all the account letters of a given print batch
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_UpdateAccountLetterByPrintBatch]
	@PrintBatchId int,
	@AccountLetterID int

AS
BEGIN
	SET NOCOUNT ON;

    UPDATE [AccountLetter] SET [PrintBatchID] = @PrintBatchId
    WHERE ID = @AccountLetterID
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterPrintBatch_GetRules]    Script Date: 11/27/2008 14:53:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Michael Pacana
-- Create date: 11/21/2008
-- Description:	Get all the rules
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_GetRules]
AS
BEGIN
	SET NOCOUNT ON;

    Select DISTINCT a.ID as RuleId, Description from RuleTable a 
		INNER JOIN AccountLetter b ON a.Id = b.Ruleid
        ORDER by a.Description
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterPrintBatch_UpdateStatus]    Script Date: 11/27/2008 14:53:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Michael Pacana
-- Create date: 11/24/2008
-- Description:	Updates the print status of the given print batch
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_UpdateStatus]
	@PrintBatchId int,
	@PrintStatus int,
	@ErrorLog nvarchar(500)

AS
BEGIN
	SET NOCOUNT ON;

    UPDATE [AccountLetterPrintBatch] 
	SET [PrintStatus] = @PrintStatus, [ErrorLog] = @ErrorLog, [DatePrinted] = GetDate()
    WHERE PrintBatchId = @PrintBatchId
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterPrintBatch_GetPrintBatch]    Script Date: 11/27/2008 14:53:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Michael Pacana
-- Create date: 11/21/2008
-- Description:	Get the current print batch given the printbatchId
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_GetPrintBatch]
	@PrintBatchID int
AS
BEGIN
	SET NOCOUNT ON;

    SELECT * from [AccountLetterPrintBatch] WHERE [PrintBatchID] = @PrintBatchID
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterPrintBatch_GetPrintBatches]    Script Date: 11/27/2008 14:53:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Michael Pacana
-- Create date: 11/21/2008
-- Description:	Gets all the print batches
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_GetPrintBatches]
	
AS
BEGIN
	SET NOCOUNT ON;

    SELECT PrintBatchID, RuleID, EmployeeID, PrinterName from [AccountLetterPrintBatch]
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterPrintBatch_CreatePrintBatch]    Script Date: 11/27/2008 14:53:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Michael Pacana
-- Create date: 11/21/2008
-- Description:	Creates a new Print Batch record
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_CreatePrintBatch]
	@UserId int,
	@RuleId int,
	@EmployeeId int,
	@Team nvarchar(50),
	@PrinterName nvarchar(50),
	@PrinterTray nvarchar(50),
	@NumberOfCopies int,
	@DatePrinted datetime
AS
BEGIN
	SET NOCOUNT ON;

    INSERT INTO [AccountLetterPrintBatch]
       ([UserID]
       ,[RuleID]
       ,[EmployeeID]
       ,[Team]
       ,[PrinterName]
       ,[PrinterTray]
       ,[NumberOfCopies]
       ,[DatePrinted])
    VALUES
   (@UserId
   ,@RuleId
   ,@EmployeeId
   ,@Team
   ,@PrinterName
   ,@PrinterTray
   ,@NumberOfCopies
   ,@DatePrinted)

    SELECT @@IDENTITY as 'NewId'
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterPrintBatch_GetLettersByPrintBatch]    Script Date: 11/27/2008 14:53:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Michael Pacana
-- Create date: 11/24/2008
-- Description:	Gets all the letters based on the PrintbatchID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_GetLettersByPrintBatch]
	@PrintBatchID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    Select DISTINCT a.ID as AccountLetterID, a.LetterID, a.AccountID, b.LetterDesc, a.ViewLetterPath, a.RuleId, a.EmployeeId
    from AccountLetter a 
    INNER JOIN DefineLetters b ON a.LetterID = b.LetterID
    WHERE (a.ViewLetterPath IS NOT NULL 
        AND a.ViewLetterPath <> '')
        AND (a.PrintBatchId = @PrintBatchID) ORDER by b.LetterDesc
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountLetterPrintBatch_GetEmployees]    Script Date: 11/27/2008 14:53:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Michael Pacana
-- Create date: 11/21/2008
-- Description:	Get all the employees
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountLetterPrintBatch_GetEmployees]
AS
BEGIN
	SET NOCOUNT ON;

    Select DISTINCT a.EmployeeID, EmployeeName from Employee a 
		INNER JOIN AccountLetter b ON a.EmployeeID = b.EmployeeID
        ORDER by a.EmployeeName
END
GO
 
 GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineGroupId]    Script Date: 01/22/2009 17:36:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_DefineGroupId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_DefineGroupId]

GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_DefineGroupId]    Script Date: 01/22/2009 18:21:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CWX_WF_DefineGroupId]
	@AccountID INT
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @GroupID INT
	
	SELECT @GroupID = ISNULL(A.GroupID, 0)
	FROM Legal_Groups A 
	WHERE A.GroupedAccountID = @AccountID
	
	SELECT ISNULL(@GroupID, 0) AS 'GroupID'
END


GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_Validation]    Script Date: 01/22/2009 17:37:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_WF_Validation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_WF_Validation]

GO
/****** Object:  StoredProcedure [dbo].[CWX_WF_Validation]    Script Date: 01/22/2009 17:37:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CWX_WF_Validation]
	@AccountID BIGINT,
	@ValidationType INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @IsValid BIT;
	SET @IsValid = 0;
	
	IF @ValidationType = 1
		BEGIN
			/**** 
			Description: Validates Issued Date of SUMISS process.
			Requirements:	
				1. Group step type = 'SUMISS'
				2. Custom field type code = 'IssD'
				3. Custom field value must have date
			*****/	
			SELECT @IsValid = CASE WHEN ISNULL(D.Value,'') = '' THEN 0 ELSE 1 END    
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B
				ON A.GroupID = B.GroupID
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = 'SUMISS'
			INNER JOIN Legal_CustomFields D
				ON B.GroupStepID = D.ActivityID
			INNER JOIN Legal_CustomFieldTypes E
				ON D.CustomFieldTypeID = E.CustomFieldTypeID AND E.Code = 'IssD'
			WHERE A.GroupedAccountID = @AccountID

		END

	ELSE IF @ValidationType = 2
		BEGIN
			/**** 
			Description: Validates if Case Number is present.
			Requirements:	
				1. Step activity with Case Number
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) < 1 THEN 0 ELSE 1 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B
				ON A.GroupID = B.GroupID
			WHERE A.GroupedAccountID = @AccountID AND ISNULL(B.CaseNumber, '') <> ''
			
		END
	
	ELSE IF @ValidationType = 3
		BEGIN
			/**** 
			Description: Validates JUDAPP timeframe expiration.
			Requirements:	
				1. Group step type = 'SUMISS'
				2. Custom field type code = 'IssD'
				3. Current time - custom field value (IssD) must > 21
			*****/
			SELECT @IsValid = 
				CASE WHEN
					CASE WHEN ISDATE(D.Value) = 1 
						THEN DATEDIFF(d, CONVERT(datetime, D.Value, 1), GETDATE())
						ELSE 0
					END > 21	
					THEN 1
					ELSE 0
				END
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B
				ON A.GroupID = B.GroupID
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = 'SUMISS'
			INNER JOIN Legal_CustomFields D
				ON B.GroupStepID = D.ActivityID
			INNER JOIN Legal_CustomFieldTypes E
				ON D.CustomFieldTypeID = E.CustomFieldTypeID AND E.Code = 'IssD'
			WHERE A.GroupedAccountID = @AccountID
			
		END

	ELSE IF @ValidationType = 4
		BEGIN
			/**** 
			Description: Validates SUMSRV for defended DEFSUM event.
			Requirements:	
				1. Hearing type code = 'DEFSUM'
				2. Group step type = 'SUMSRV'
				3. Custom field value (DefS) = '1'
				4. Custom field type code = 'DefS'
				5. Must not have successful defense event
			*****/
			SELECT @IsValid = CASE WHEN COUNT(A.GroupID) > 0 THEN 0 ELSE 1 END  
			FROM Legal_Groups A
			INNER JOIN Legal_GroupSteps B
				ON A.GroupID = B.GroupID
			INNER JOIN Legal_Hearings F
				ON B.GroupStepID = F.GroupStepID 
			INNER JOIN Legal_HearingTypes G
				ON F.HearingTypeID = G.HearingTypeID AND G.Code = 'DEFSUM'
			INNER JOIN Legal_GroupStepTypes C
				ON B.GroupStepTypeID = C.GroupStepTypeID AND C.Code = 'SUMSRV'
			INNER JOIN Legal_CustomFields D
				ON F.HearingID = D.ActivityID AND D.Value = '1'
			INNER JOIN Legal_CustomFieldTypes E
				ON D.CustomFieldTypeID = E.CustomFieldTypeID AND E.Code = 'DefS'
			WHERE A.GroupedAccountID = @AccountID
			
		END

	ELSE IF @ValidationType = 5
		BEGIN
			/**** 
			Description: Validates account's bill balance.
			Requirements:	
				1. Account's bill balance > 0
			*****/
			SELECT @IsValid = CASE WHEN ISNULL(A.BillBalance, 0) > 0 THEN 1 ELSE 0 END  
			FROM Account A
			WHERE A.AccountID = @AccountID
			
		END

	ELSE IF @ValidationType = 6
		BEGIN
			/**** 
			Description: Validates account's maximum bill balance base on state.
			Requirements:	
				1. If from state of VIC, account's bill balance < $100000 or,
				2. If from state of NSW, account's bill balance < $40000 or,	
				3. If from state of QLD, account's bill balance < $60000
			*****/
			SELECT @IsValid =  
				CASE 
					WHEN A.Formula_Flag = 'VIC' AND A.BillBalance < 100000 THEN 1 
					WHEN A.Formula_Flag = 'NSW' AND A.BillBalance < 40000 THEN 1
					WHEN A.Formula_Flag = 'QLD' AND A.BillBalance < 60000 THEN 1
					ELSE 0 
				END
			FROM Account A
			WHERE A.AccountID = @AccountID
			
		END

	SELECT @IsValid AS 'IsValid'
END

/****** Object:  StoredProcedure [dbo].[CWX_Customer_AddAccountSubProductDetails]    Script Date: 01/26/2009 23:33:15 ******/
DROP PROCEDURE [dbo].[CWX_Customer_AddAccountSubProductDetails]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Customer_AddAccountSubProductDetails]    Script Date: 01/26/2009 23:33:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Suzette M. Dimasaca
-- Create date: Jan 26, 2009
-- Description:	This will insert data to AdditionalAcctSubProd table
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Customer_AddAccountSubProductDetails]
	-- Add the parameters for the stored procedure here
	@AccountID	Int
	, @SubProductId Int
	, @Issue	Int
	, @GST		Money
	, @OriginalDebt Money
	, @Paid		Money
	, @Notes	VarChar(100)
	, @CreatedBy	Int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @TotalDebt	Money
		,@Due			Money

	SET @TotalDebt = (@OriginalDebt - @GST)
	SET @Due = (@TotalDebt - @Paid)

	INSERT INTO AdditionalAcctSubProd
	VALUES (@AccountID
		, @SubProductID
		, @Issue
		, @OriginalDebt
		, @GST
		, @TotalDebt
		, @Paid
		, @Due
		, @Notes
		, @CreatedBy
		, getdate())
    
END
GO

-- =============================================
-- Author:		Suzette M. Dimasaca
-- Create date: 4:40 PM 1/27/2009
-- Description:	This will return the remaining balance of AddtionalSubProdAcct for particular account selected
-- =============================================
IF EXISTS(SELECT 1 FROM sys.objects where [name] = N'CWX_GetSubProdAcctRemainingBalance' and [type] = N'P' )
   drop proc CWX_GetSubProdAcctRemainingBalance
go
CREATE procedure [dbo].[CWX_GetSubProdAcctRemainingBalance]
@accountID int
as
begin

declare @result int

select @result = (ac.BillAmount - sum(ap.OriginalDebt) - sum(ap.GST))
               from AdditionalAcctSubProd ap
  		            inner join Account ac
                          on (ap.AccountID = ac.AccountID)
               where ap.AccountID = @accountID
               group by ac.BillAmount

return @result
end


if exists(select * from sys.objects where [name] = N'AdditionalFields' and [type] = N'U')
   begin
       declare @kc_name varchar(100) 
       if exists(select c.[name], o.[name] from sys.objects o
                     inner join sys.columns c
                               on (o.[object_id] = c.[object_id]) and (c.[name] = N'RecordID')
                 where o.[name] = N'AdditionalFields' and o.[type] = N'U')
          begin
                  
                select @kc_name = kc.[name] 
				from sys.objects o       
				  	 inner join sys.columns c 
						   on o.[object_id] = c.[object_id] and c.[name] = N'RecordID'          
						      inner join sys.identity_columns idc
						            on c.[object_id] = idc.[object_id] 
                                       inner join sys.key_constraints kc
                                             on idc.[object_id] = kc.[parent_object_id]    
                where o.[name] = N'AdditionalFields' and o.[type] = N'U';

          
               if (@kc_name is not null)                  
                   exec ('ALTER TABLE AdditionalFields DROP CONSTRAINT ' + @kc_name);                   
                              
               ALTER TABLE AdditionalFields DROP COLUMN RecordID;               
          end                                                             
   end 
go

ALTER TABLE [dbo].[AdditionalFields]
	ADD RecordID int not null identity primary key
go








