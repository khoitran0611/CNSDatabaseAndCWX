  -- Scripts are applied on version 1.9.11
  
  /****** Object:  StoredProcedure [dbo].[CWX_UserNotInUse]    Script Date: 06/12/2008 16:22:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CWX_UserNotInUse] 	
	@UserName varchar(16),
	@AvailableDays int

AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @LoginUser varchar(16)	
	DECLARE @Result int
	IF EXISTS (SELECT * FROM Employee WHERE UserID = @UserName 
					AND UserID NOT IN (SELECT LoginUserID FROM LoginAttemptsLog)
					AND (GETDATE() - CreatedDate) > @AvailableDays)
		SET @Result= 1
	ELSE
    BEGIN
	
		DECLARE @LastChangeDate DATETIME
		DECLARE @LastLoginDate DATETIME

		SET @LastChangeDate = (SELECT ChangeDate FROM PasswordHistoryLog a LEFT JOIN Employee b
									ON a.EmployeeID = b.EmployeeID
									WHERE b.UserID = @UserName AND ChangeDate > = (SELECT MAX(ChangeDate) FROM PasswordHistoryLog))


		SET @LastLoginDate = (SELECT LoginDateTime FROM LoginAttemptsLog									
									WHERE LoginUserID = @UserName AND LoginDateTime > = (SELECT MAX(LoginDateTime) FROM LoginAttemptsLog))

		IF (@LastChangeDate IS NOT NULL AND @LastLoginDate IS NOT NULL AND (@LastChangeDate - @LastLoginDate) > @AvailableDays)
			SET @Result = 1	
		ELSE 
			SET @Result = 0
	END

	SELECT @Result
END
  
  /****** Object:  StoredProcedure [dbo].[CWX_DefineFees_DeleteAll]    Script Date: 06/12/2008 16:07:30 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DefineFees_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DefineFees_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_DefineFees_DeleteAll]    Script Date: 06/12/2008 16:07:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DefineFees_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Delete all Define Fees.
-- History:
--		2008/06/12	[Binh Truong]	Init version.
-- =============================================
create Procedure [dbo].[CWX_DefineFees_DeleteAll]
AS
BEGIN	
	DELETE FROM DefineFees
END	
' 
END
GO

-- =======================================================================
-- Author:		Tuan Luong
-- Create date: Jun 12, 2008
-- Description:	Add column 'Status' with default value 'A'
--			    use this field to mark the row is active 'A' or retire 'R'
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_GroupStepTypes' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_GroupStepTypes
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_GroupStepTypes_RowStatus] DEFAULT 'A'
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupStepTypes_DeleteAll]    Script Date: 06/12/2008 17:57:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupStepTypes_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_GroupStepTypes_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_GroupStepTypes_DeleteAll]    Script Date: 06/12/2008 17:57:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_GroupStepTypes_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =============================================================
-- Author:		Tuan Luong
-- Create date: Jun 12, 2008
-- Description:	Delete all records in Legal_GroupStepTypes Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_GroupStepTypes_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_GroupStepTypes
		SET [Status] = ''R''
		WHERE [Status] = ''A''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_GroupStepTypes
	END
END


' 
END
GO

/******  Script Closed. Go next: Step013_9  ******/