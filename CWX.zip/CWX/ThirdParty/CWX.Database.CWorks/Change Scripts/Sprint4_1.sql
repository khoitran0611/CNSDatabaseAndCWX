﻿-- ================================================
-- Author:		Minh Dam
-- Date:		22 Apr 2009
-- Description: Changes on 'CWX_AccountInformation_Dict' table
-- ================================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_AccountInformation_Dict' AND COLUMN_NAME = 'Mandatory')
BEGIN
   ALTER TABLE CWX_AccountInformation_Dict 
		ADD Mandatory bit NOT NULL DEFAULT ((0))
END
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_AccountInformation_Dict' AND COLUMN_NAME = 'PageNumber')
BEGIN
	EXEC sp_rename 'CWX_AccountInformation_Dict.PageNumber', 'TabID'
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_AccountInformation_Dict' AND COLUMN_NAME = 'TabDesc')
BEGIN
   ALTER TABLE CWX_AccountInformation_Dict 
		ADD TabDesc nvarchar(30) NULL
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_AccountInformation_Dict' AND COLUMN_NAME = 'RangeID')
BEGIN
   ALTER TABLE CWX_AccountInformation_Dict 
		ADD RangeID tinyint NULL DEFAULT ((0))
END
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_AccountInformation_Dict' AND COLUMN_NAME = 'Client')
BEGIN
	EXEC sp_rename 'CWX_AccountInformation_Dict.Client', 'ClientID'
END
GO
---------------------------------------------

-- ================================================
-- Author:		Minh Dam
-- Date:		22 Apr 2009
-- Description: Changes on 'CWX_ClientInformation_Dict' table
-- ================================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientInformation_Dict' AND COLUMN_NAME = 'Mandatory')
BEGIN
   ALTER TABLE CWX_ClientInformation_Dict 
		ADD Mandatory bit NOT NULL DEFAULT ((0))
END
GO
---------------------------------------------

-- ================================================
-- Author:		Minh Dam
-- Date:		22 Apr 2009
-- Description: Changes on 'CWX_PersonInformation_Dict' table
-- ================================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_PersonInformation_Dict' AND COLUMN_NAME = 'Mandatory')
BEGIN
   ALTER TABLE CWX_PersonInformation_Dict 
		ADD Mandatory bit NOT NULL DEFAULT ((0))
END
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_PersonInformation_Dict' AND COLUMN_NAME = 'PageNumber')
BEGIN
	EXEC sp_rename 'CWX_PersonInformation_Dict.PageNumber', 'TabID'
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_PersonInformation_Dict' AND COLUMN_NAME = 'TabDesc')
BEGIN
   ALTER TABLE CWX_PersonInformation_Dict 
		ADD TabDesc nvarchar(30) NULL
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_PersonInformation_Dict' AND COLUMN_NAME = 'RangeID')
BEGIN
   ALTER TABLE CWX_PersonInformation_Dict 
		ADD RangeID tinyint NULL DEFAULT ((0))
END
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_PersonInformation_Dict' AND COLUMN_NAME = 'Client')
BEGIN
	EXEC sp_rename 'CWX_PersonInformation_Dict.Client', 'ClientID'
END
GO
----------------------------------------------

-- ================================================
-- Author:		Minh Dam
-- Date:		22 Apr 2009
-- Description: Changes on 'CWX_Collateral_Dict' table
-- ================================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_Collateral_Dict' AND COLUMN_NAME = 'TabID')
BEGIN
   ALTER TABLE CWX_Collateral_Dict 
		ADD TabID int NOT NULL DEFAULT ((1))
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_Collateral_Dict' AND COLUMN_NAME = 'TabDesc')
BEGIN
   ALTER TABLE CWX_Collateral_Dict 
		ADD TabDesc nvarchar(30) NULL
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_Collateral_Dict' AND COLUMN_NAME = 'RangeID')
BEGIN
   ALTER TABLE CWX_Collateral_Dict 
		ADD RangeID tinyint NULL DEFAULT ((0))
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_Collateral_Dict' AND COLUMN_NAME = 'DropDown')
BEGIN
   ALTER TABLE CWX_Collateral_Dict 
		ADD DropDown int NOT NULL DEFAULT ((0))
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_Collateral_Dict' AND COLUMN_NAME = 'Mandatory')
BEGIN
   ALTER TABLE CWX_Collateral_Dict 
		ADD Mandatory bit NOT NULL DEFAULT ((0))
END
GO
------------------------------------------

-- ================================================
-- Author:		Minh Dam
-- Date:		22 Apr 2009
-- Description: Changes on 'CWX_DropDownDataDictionary' table
-- ================================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_DropDownDataDictionary' AND COLUMN_NAME = 'Lookup')
BEGIN
   ALTER TABLE CWX_DropDownDataDictionary 
		ADD Lookup bit NOT NULL DEFAULT ((0))
END
GO


---------------------------------------------------

--------------------------ThanhNguyen: April 28,2009-------------------------
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'CWX_AccountInformation_Dict' AND COLUMN_NAME = 'CMSEditable')
BEGIN
	exec sp_rename 'CWX_AccountInformation_Dict.CMSEditable', 'CMSEdit'
END
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'CWX_PersonInformation_Dict' AND COLUMN_NAME = 'CMSEditable')
BEGIN
	exec sp_rename 'CWX_PersonInformation_Dict.CMSEditable','CMSEdit'
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Employee_SeachPersonInformation]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Employee_SeachPersonInformation]

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CWX_Employee_SeachPersonInformation]
	-- Add the parameters for the stored procedure here
	@CustomerName varchar(50) = '',
	@PhoneNumber varchar(50) = '',
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN

	SET NOCOUNT ON;	

	DECLARE @RowCount int
	CREATE TABLE #Temp
	(
		RowNumber int,	
		PersonID int,
		CustomerName varchar(50),
		RelationshipNumber varchar(50),
		ID		varchar(25)
	)

	IF @CustomerName = ''
		BEGIN
			IF(@PhoneNumber <> '')
			BEGIN
				INSERT INTO #Temp
				SELECT ROW_NUMBER() OVER (ORDER BY a.PersonID) as RowNumber, a.PersonID,
				(a.FirstName + ' ,' + a.MiddleName + ' ,' + a.LastName) as CustomerName, 
				b.GroupName,
				a.SocialSecurityNumber
				FROM [dbo].[PersonInformation] a
				INNER JOIN [dbo].[DebtorInformation] b on a.PersonID = b.PersonID
				INNER JOIN [dbo].[PersonPhone] p on a.PersonID = p.PersonID
				WHERE p.PhoneNumber LIKE ('%'+ @PhoneNumber + '%')
			END
			ELSE
			BEGIN
				INSERT INTO #Temp
				SELECT ROW_NUMBER() OVER (ORDER BY a.PersonID) as RowNumber, a.PersonID,
				(a.FirstName + ' ,' + a.MiddleName + ' ,' + a.LastName) as CustomerName, 
				b.GroupName,
				a.SocialSecurityNumber
				FROM [dbo].[PersonInformation] a
				INNER JOIN [dbo].[DebtorInformation] b on a.PersonID = b.PersonID				
			END
			
		END
	ELSE
		BEGIN
			IF(@PhoneNumber <> '')
			BEGIN
				INSERT INTO #Temp
					SELECT ROW_NUMBER() OVER (ORDER BY a.PersonID) as RowNumber, a.PersonID,
					a.FirstName + ' ,' + a.MiddleName + ' ,' + a.LastName as CustomerName, 
					b.GroupName,
					a.SocialSecurityNumber
					FROM [dbo].[PersonInformation] a
					INNER JOIN [dbo].[DebtorInformation] b on a.PersonID = b.PersonID					
					INNER JOIN [dbo].[PersonPhone] p ON a.PersonID = p.PersonID
					WHERE a.FirstName LIKE ('%' + @CustomerName + '%') 
					OR a.MiddleName LIKE ('%' + @CustomerName + '%') 
					OR a.LastName LIKE ('%' + @CustomerName + '%') 	
					AND p.PhoneNumber LIKE('%' + @PhoneNumber + '%')
				END
			ELSE
				BEGIN
					SELECT ROW_NUMBER() OVER (ORDER BY a.PersonID) as RowNumber, a.PersonID,
					a.FirstName + ' ,' + a.MiddleName + ' ,' + a.LastName as CustomerName, 
					b.GroupName,
					a.SocialSecurityNumber
					FROM [dbo].[PersonInformation] a
					INNER JOIN [dbo].[DebtorInformation] b on a.PersonID = b.PersonID										
					WHERE a.FirstName LIKE ('%' + @CustomerName + '%') 
					OR a.MiddleName LIKE ('%' + @CustomerName + '%') 
					OR a.LastName LIKE ('%' + @CustomerName + '%') 						
				END						
		END
	
	
	SELECT @RowCount = @@ROWCOUNT

	IF @PageSize <= 0
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DROP TABLE #Temp
	RETURN @RowCount
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'DebtorInformation' AND COLUMN_NAME = 'ClientID')
BEGIN
	ALTER TABLE DebtorInformation
	ADD ClientID int  default 0
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'CWX_ClientInformation_Dict' AND COLUMN_NAME = 'ClientID')
BEGIN
	ALTER TABLE CWX_ClientInformation_Dict
	ADD ClientID int default 0
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'ClientInformation' AND COLUMN_NAME = 'ClientDictID')
BEGIN
	ALTER TABLE ClientInformation
	ADD ClientDictID int default 0
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetAllTabs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_GetAllTabs]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 27 Apr 2009
-- Description:	Get all tabs for account information
-- ThanhNguyen: April 28, 2009: Get all tab of @ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Product_GetAllTabs]
	@ClientID int = 0
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @TabID int
	DECLARE curTab CURSOR FOR
		SELECT DISTINCT TabID
		FROM CWX_ClientInformation_Dict
		WHERE ClientID = @ClientID OR ISNULL(ClientID,0) = 0
		ORDER BY TabID

	CREATE TABLE #temp(TabID int, TabDesc nvarchar(30))

	OPEN curTab
	FETCH NEXT FROM curTab INTO @TabID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		INSERT INTO #temp
			SELECT TOP 1 TabID, ISNULL(TabDesc,'') FROM CWX_ClientInformation_Dict WHERE TabID = @TabID
		FETCH NEXT FROM curTab INTO @TabID
	END

	CLOSE curTab
	DEALLOCATE curTab

	SELECT * FROM #temp
	DROP TABLE #temp
END
GO

/****** Object:  UserDefinedFunction [dbo].[CWX_AssignedClientIDTable]    Script Date: 04/28/2009 19:42:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <10 April 2009>
-- Description:	<>
-- =============================================
ALTER FUNCTION [dbo].[CWX_AssignedClientIDTable]
(	
	@employeeID int
)
RETURNS @retTable TABLE (ClientID int)
AS
BEGIN

	IF (@EmployeeID > 0 AND EXISTS (SELECT 1 FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID))
	BEGIN
		INSERT INTO @retTable(ClientID)	
			SELECT	ClientID 
			FROM	ClientInformation 
			WHERE	[Status] <> 'R'
				AND (ClientID IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @EmployeeID))
	END
	ELSE
	BEGIN
		INSERT INTO @retTable(ClientID)	
			SELECT	ClientID 
			FROM	ClientInformation 
			WHERE	[Status] <> 'R'
	END
	
	INSERT INTO @retTable(ClientID) VALUES(0)
	
	RETURN

--	SELECT ClientID 
--	FROM ClientInformation 
--	WHERE ClientID IN (SELECT ClientID FROM CWX_ClientEmployee WHERE EmployeeID = @employeeID)
--		AND [Status] <> 'R'
END

GO
/****** Object:  StoredProcedure [dbo].[CWX_GetDropDownLookupValues]    Script Date: 04/29/2009 15:07:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_GetDropDownLookupValues]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_GetDropDownLookupValues]
GO
/****** Object:  StoredProcedure [dbo].[CWX_GetDropDownLookupValues]    Script Date: 04/29/2009 15:08:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 24 Apr 2009
-- Description:	Get drop down lookup values
-- =============================================
CREATE PROCEDURE [dbo].[CWX_GetDropDownLookupValues]
	-- Add the parameters for the stored procedure here
	@DropDownID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @Sql varchar(max)
	SELECT @Sql = [SQL]
	FROM CWX_DropDownDataDictionary
	WHERE ID = @DropDownID

	EXEC (@Sql)
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountInformation_GetAllTabs]    Script Date: 04/29/2009 15:08:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountInformation_GetAllTabs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountInformation_GetAllTabs]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountInformation_GetAllTabs]    Script Date: 04/29/2009 15:08:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 27 Apr 2009
-- Description:	Get all tabs for account information
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountInformation_GetAllTabs]
	@ClientID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @TabID int
	DECLARE curTab CURSOR FOR
		SELECT DISTINCT TabID
		FROM CWX_AccountInformation_Dict
		WHERE ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID
		ORDER BY TabID

	CREATE TABLE #temp(TabID int, TabDesc nvarchar(30))

	OPEN curTab
	FETCH NEXT FROM curTab INTO @TabID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		INSERT INTO #temp
			SELECT TOP 1 TabID, ISNULL(TabDesc,'') FROM CWX_AccountInformation_Dict WHERE TabID = @TabID
		FETCH NEXT FROM curTab INTO @TabID
	END

	CLOSE curTab
	DEALLOCATE curTab

	SELECT * FROM #temp
	DROP TABLE #temp
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetAllTabs]    Script Date: 04/29/2009 15:09:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetAllTabs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetAllTabs]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetAllTabs]    Script Date: 04/29/2009 15:09:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 27 Apr 2009
-- Description:	Get all tabs for account information
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Collateral_GetAllTabs]
	-- Add the parameters for the stored procedure here
	@CollateralID int,
	@ClientID int = 0,
	@CollateralTypeID int = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @CollateralID > 0 AND @CollateralTypeID IS NULL
		SELECT @CollateralTypeID = CollateralType FROM Collateral WHERE ID = @CollateralID

	DECLARE @TabID int
	DECLARE curTab CURSOR FOR
		SELECT DISTINCT TabID
		FROM CWX_Collateral_Dict
		WHERE (@ClientID = 0 OR ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)
			AND (@CollateralTypeID = 0 OR ISNULL(CollateralTypeID, 0) = 0 OR CollateralTypeID = @CollateralTypeID)
		ORDER BY TabID

	CREATE TABLE #temp(TabID int, TabDesc nvarchar(30))

	OPEN curTab
	FETCH NEXT FROM curTab INTO @TabID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		INSERT INTO #temp
			SELECT TOP 1 TabID, ISNULL(TabDesc,'') FROM CWX_Collateral_Dict WHERE TabID = @TabID
		FETCH NEXT FROM curTab INTO @TabID
	END

	CLOSE curTab
	DEALLOCATE curTab

	SELECT * FROM #temp
	DROP TABLE #temp
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_PersonInformation_GetAllTabs]    Script Date: 04/29/2009 15:10:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonInformation_GetAllTabs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonInformation_GetAllTabs]
GO
/****** Object:  StoredProcedure [dbo].[CWX_PersonInformation_GetAllTabs]    Script Date: 04/29/2009 15:10:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 27 Apr 2009
-- Description:	Get all tabs for account information
-- =============================================
CREATE PROCEDURE [dbo].[CWX_PersonInformation_GetAllTabs]
	-- Add the parameters for the stored procedure here
	@ClientID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @TabID int
	DECLARE curTab CURSOR FOR
		SELECT DISTINCT TabID
		FROM CWX_PersonInformation_Dict
		WHERE ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID
		ORDER BY TabID

	CREATE TABLE #temp(TabID int, TabDesc nvarchar(30))

	OPEN curTab
	FETCH NEXT FROM curTab INTO @TabID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		INSERT INTO #temp
			SELECT TOP 1 TabID, ISNULL(TabDesc,'') FROM CWX_PersonInformation_Dict WHERE TabID = @TabID
		FETCH NEXT FROM curTab INTO @TabID
	END

	CLOSE curTab
	DEALLOCATE curTab

	SELECT * FROM #temp
	DROP TABLE #temp
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDynamicFields]    Script Date: 04/29/2009 15:11:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an account
-- History:
--	[06-Mar-2009]	Minh Dam		Init version.
--	[20-Mar-2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[10-Apr-2009]	Thanh Nguyen	Add parameter "@CMSEditable"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam		Remove parameters @PageSize, @PageIndex
--									Rename parameter @PageNumber to @TabID
--									Change from Page view to Tab view
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_GetDynamicFields]
	@AccountID int,
	@TabID int = 1, 
	@ClientID int = 0, -- if @ClientID < 0 then set @ClientID equals ClientID of account
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF (@AccountID > 0 AND @ClientID < 0)
		SELECT @ClientID = ClientID
		FROM Account
		WHERE AccountID = @AccountID

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[TableID],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], CASE WHEN @CMSEditable = 1 THEN [CMSEdit] ELSE [Editable] END as [Editable], 
				[GroupID], [GroupDesc], [DisplayOrder], [RangeID], [DropDown], [TableID], [Mandatory]
		FROM CWX_AccountInformation_Dict
		WHERE Displayed = 1	AND TabID = @TabID
			AND (@CMSEditable = 0 OR (@CMSEditable = 1 AND [CMSEdit] = 1))
			AND (ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Account' AND [Type]='U')
			OR object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'AccountOther' AND [Type]='U')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList_Account varchar(4000), @FieldNameList_AccountOther varchar(4000)
	DECLARE @FieldName varchar(50), @TableID int
	SET @FieldNameList_Account = 'AccountID,InvoiceNumber,DebtorID,EmployeeID,ClientID,QueueDate,AgencyStatusID,SystemStatusID,ActionCodeID,OfficeID,MCode,CCode,BucketMovement,SubmissionDate,LastEditDate,LastEditBy,CurrencyCode,InterfaceID,CloseDate'
	SET @FieldNameList_AccountOther = 'AccountID'

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName, TableID FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF (@TableID = 1) -- Account table
			SET @FieldNameList_Account = @FieldNameList_Account + ',' + @FieldName
		ELSE IF (@TableID = 2) -- AccountOther table
			SET @FieldNameList_AccountOther = @FieldNameList_AccountOther + ',' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql1 varchar(1000), @Sql2 varchar(1000)
	SET @Sql1 = 'SELECT ' + @FieldNameList_Account + ' FROM Account WHERE AccountID = ' + Cast(@AccountID as varchar)
	SET @Sql2 = 'SELECT ' + @FieldNameList_AccountOther + ' FROM AccountOther WHERE AccountID = ' + Cast(@AccountID as varchar)
	
	EXEC (@Sql1)
	EXEC (@Sql2)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 04/29/2009 15:12:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Minh Dam
-- Create date: 15/08/2008
-- Description:	Get dynamic fields of a collateral
-- History:
--	[06 Mar 2009]	Thuy Nguyen		Init version.
--	[20 Mar 2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory", "RangeID", "DropDown", "SQLDropDown", "Listed" field columns into returned dynamic fields tables
-- =============================================				
ALTER PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
	@CollateralID int,
	@TabID int = 1,
	@ClientID int = 0,
	@CollateralTypeID int = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @CollateralID > 0 AND @CollateralTypeID IS NULL
		SELECT @CollateralTypeID = CollateralType FROM Collateral WHERE ID = @CollateralID

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc],
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc],
			a.[DisplayOrder],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], 
				[DisplayOrder], [DropDown], [RangeID], [Mandatory]
		FROM CWX_Collateral_Dict
		WHERE Displayed = 1 AND TabID = @TabID
			AND (@ClientID = 0 OR ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)
			AND (@CollateralTypeID = 0 OR ISNULL(CollateralTypeID, 0) = 0 OR CollateralTypeID = @CollateralTypeID)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Collateral' and [Type]='U')
			AND (c.[name] LIKE 'CInt%' OR c.[name] LIKE 'CString%' OR c.[name] LIKE 'CDate%' OR c.[name] LIKE 'CMoney%')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'ID,AccountID,HostCollateralID,EmployeeID,NextActionDate,Image,ImageFileName,'
	SET @FieldNameList = @FieldNameList + 
		'(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6) IS NOT NULL THEN CollateralType ELSE 0 END) AS CollateralType,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7) IS NOT NULL THEN CollateralStage ELSE 0 END) AS CollateralStage,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2) IS NOT NULL THEN NextAction ELSE 0 END) AS NextAction'
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM Collateral WHERE ID = ' + Cast(@CollateralID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields

	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Person_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Person_GetDynamicFields]    Script Date: 04/29/2009 15:13:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thuy Nguyen
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an person
-- History:
--	[06-Mar-2009]	Thuy Nguyen		Init version.
--	[20-Mar-2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[10-Apr-2009]	Thanh Nguyen	Add parameter "@CMSEditable"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam		Rename parameter @PageNumber to @TabID
--									Rename parameter @Client to @ClientID
--									Remove parameters @PageSize, @PageIndex
--									Change from Page view to Tab view
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
	@PersonID int,
	@TabID int = 1,
	@ClientID int = 0,
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc],
			b.[DataType],
			b.[MaxLength],
			a.[Editable],
			a.[GroupID],
			a.[GroupDesc], 
			a.[DisplayOrder],			
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], CASE WHEN @CMSEditable = 1 THEN [CMSEdit] ELSE [Editable] END as [Editable],
				[GroupID], [GroupDesc], [DisplayOrder], [RangeID], [DropDown], [Mandatory]
		FROM	CWX_PersonInformation_Dict
		WHERE	Displayed = 1 AND TabID = @TabID
				AND (@CMSEditable = 0 OR (@CMSEditable = 1 AND [CMSEdit] = 1))
				AND (ClientID = @ClientID OR ISNULL(ClientID, 0) = 0)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'PersonInformation' and [Type]='U')			
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'PersonID, LastName, FirstName, MiddleName, PString1'
	
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM PersonInformation WHERE PersonID = ' + Cast(@PersonID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup

END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Product_GetDynamicFields]    Script Date: 04/29/2009 15:13:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 17 Mar 2009
-- Description:	Get dynamic fields and data of an client
-- History:
--	[17 Mar 2009]	Minh Dam	Init version.
--	[22-Apr-2009]	Minh Dam	Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam	Remove parameters @PageSize, @PageIndex
--								Rename parameter @PageNumber to @TabID
--								Change from Page view to Tab view
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Product_GetDynamicFields]
	-- Add the parameters for the stored procedure here
	@ClientID int,
	@TabID int = 1,
	@ClientDictID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.[Listed], 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], 
				[DisplayOrder], [DropDown], [RangeID], [Mandatory]
		FROM CWX_ClientInformation_Dict
		WHERE Displayed = 1	AND TabID = @TabID AND (ClientID = @ClientDictID OR ISNULL(ClientID,0) = 0)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'ClientInformation' AND [Type]='U')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000)
	DECLARE @FieldName varchar(50)
	SET @FieldNameList = 'ClientID,ClientName,Priority,AgingForReschedule,AgingForDiscount,RescheduleAllowed,DiscountAllowed,LetterheadImage,CreditorID,PaymentAllocationRuleID,AgingForApportion,ApportionAllowed' --ClientActive

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(1000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM ClientInformation WHERE ClientID = ' + Cast(@ClientID as varchar)
	
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

END
GO
--- Create table CWX_CollateralCustomFields --
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF(NOT EXISTS (SELECT * FROM sys.objects WHERE sys.objects.object_id = OBJECT_ID(N'CWX_CollateralCustomFields') and type in (N'U')))
BEGIN
	CREATE TABLE [dbo].[CWX_CollateralCustomFields](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[CollateralID] [int] NOT NULL,
		[AgencyID] [int] NOT NULL,
		[Value] [varchar](1000) NULL,
	 CONSTRAINT [PK_Collateral_CustomFields] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF

---------------------

------INSERT TEST DATA TO CWX_PersonInformation_Dict

DELETE CWX_PersonInformation_Dict

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonInformation_Dict]') AND type in (N'U'))
BEGIN		
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'HomePhone'))
	BEGIN	
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('HomePhone','Home Phone',1,1,0,'Contact Information',1,1,'Contact Information',0,0,1)
    END
    
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'MobilPhone'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('MobilPhone','Mobil Phone',1,1,0,'Contact Information',2,1,'Contact Information',0,0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'EmploymentPhone'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('EmploymentPhone','Employment Phone',1,1,0,'Contact Information',3,1,'Contact Information',0,0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'EmploymentPhoneExtension'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('EmploymentPhoneExtension','Employment Phone Extension',1,1,0,'Contact Information',4,1,'Contact Information',0,0,1)
	END
		
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'Position'))
	BEGIN		
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('Position','Position',1,1,1,'Debtor Career',1,2,'Debtor Career',11,0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'Profession'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('Profession','Profession',1,1,1,'Debtor Career',2,2,'Debtor Career',11,0,1)
    END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'Language'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('Language','Language',1,1,1,'Debtor Career',3,2,'Debtor Career',11,2,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'Department'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('Department','Department',1,1,1,'Debtor Career',4,2,'Debtor Career',11,4,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PMoney1'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('PMoney1','Total Income Per Month',1,1,2,'Income',1,3,'Income',0,0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PMoney2'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('PMoney2','Husband Income',1,1,2,'Income',2,3,'Income',0,0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PMoney3'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('PMoney3','Wife Income',1,1,2,'Income',3,3,'Income',0,0,1)
	END

	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PLong1'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('PLong1','Number Of Childs',1,1,3,'Debtor Children Information',1,4,'Debtor Children Information',0,0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PLong2'))
	BEGIN	
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('PLong2','Age Of First Child',1,1,3,'Debtor Children Information',2,4,'Debtor Children Information',0,0,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_PersonInformation_Dict WHERE FieldName = 'PLong3'))
	BEGIN
	INSERT INTO  [dbo].[CWX_PersonInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[ClientID],[DropDown],[CMSEdit])
    VALUES('PLong3','Age Of Last Child',1,1,3,'Debtor Children Information',3,4,'Debtor Children Information',0,0,1)
	END
END
DELETE CWX_AccountInformation_Dict
-------INSERT DATA TO CWX_AccountInformation_Dict
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountInformation_Dict]') AND type in (N'U'))
BEGIN
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'RountinePayment'))
	BEGIN	
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('RountinePayment','Rountine Payment',1,1,2,'Account Payment Information',0,1,0,2,'Account Payment Information',1,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'BillAmount'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('BillAmount','Bill Amount',1,1,2,'Account Payment Information',1,1,0,2,'Account Payment Information',1,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'PaymentPlan'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('PaymentPlan','Payment Plan',1,1,2,'Account Payment Information',2,1,0,2,'Account Payment Information',1,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'AccountType'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('AccountType','Account Type',1,1,1,'Account Information',1,1,0,1,'Account Information',2,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'InvoiceNumber'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('InvoiceNumber','Invoice Number',1,1,1,'Account Information',2,1,0,1,'Account Information',2,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'AccountClass'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('AccountClass','Account Class',1,1,1,'Account Information',3,1,0,1,'Account Information',2,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'Long1'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('Long1','Credit',1,1,1,'Account Credit',1,2,0,3,'Account Credit',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'Long2'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('Long2','Credit',1,1,2,'Account Credit',1,2,0,3,'Account Credit',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentNextAction'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('CurrentNextAction','Current Next Action',1,1,2,'Account Action',1,1,1,3,'Account Credit',3,1)
	END

	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentNextActionDate'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('CurrentNextActionDate','Current Next Action Date',1,1,2,'Account Action',2,1,0,3,'Account Credit',3,1)
	END

	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentCallResult'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('CurrentCallResult','Current Call Result',1,1,2,'Account Action',3,1,6,3,'Account Credit',3,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentCallResultDate'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('CurrentCallResultDate','Current CallResult Date',1,1,2,'Account Action',4,1,0,3,'Account Credit',3,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentReason'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('CurrentReason','Current Reason',1,1,2,'Account Action',5,1,5,3,'Account Credit',3,1)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_AccountInformation_Dict WHERE FieldName = 'CurrentReasonDate'))
	BEGIN
	INSERT INTO [dbo].[CWX_AccountInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TableID],[DropDown],[TabID],[TabDesc],[ClientID],[CMSEdit])
    VALUES('CurrentReasonDate','Current Reason Date',1,1,2,'Account Action',6,1,0,3,'Account Credit',0,1)		
    END
END

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_Dict]') AND type in (N'U'))
BEGIN	
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString1'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString1','Address1',1,1,1,'ClientInformation',1,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString2'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString2','Address2',1,1,1,'ClientInformation',2,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString3'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString3','Email',1,1,1,'ClientInformation',3,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString4'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString4','City',1,1,1,'ClientInformation',4,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString5'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString5','State',1,1,1,'ClientInformation',5,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString6'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString6','Zip',1,1,1,'ClientInformation',6,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString7'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString7','Country',1,1,1,'ClientInformation',7,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString8'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString8','Region',1,1,1,'ClientInformation',8,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString9'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString9','PhoneNumber',1,1,1,'ClientInformation',9,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CString10'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CString10','FaxNumber',1,1,1,'ClientInformation',10,1,'ClientInformation',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CInt1'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CInt1','Client Percent',1,1,1,'Client Percent Information',1,3,'Client Percent Information',1,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CInt2'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CInt2','Client Old Percent',1,1,1,'Client Percent Information',2,3,'Client Percent Information',1,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CInt3'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CInt3','Client Percent',1,1,1,'Client Percent Information',3,3,'Client Percent Information',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CFloat1'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CFloat1','Previous Balance',1,1,2,'Client Balance Information',1,2,'Client Balance Information',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CFloat2'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CFloat2','Previous AP Balance',1,1,2,'Client Balance Information',2,2,'Client Balance Information',0,0)
	END
	
	IF(NOT EXISTS(	SELECT * FROM CWX_ClientInformation_Dict WHERE FieldName = 'CFloat3'))
	BEGIN
	INSERT INTO [dbo].[CWX_ClientInformation_Dict]([FieldName],[FieldDesc],[Displayed],[Editable],[GroupID],[GroupDesc],[DisplayOrder],[TabID],[TabDesc],[RangeID],[DropDown])
    VALUES('CFloat3','Deduct AR Balance',1,1,2,'Client Balance Information',3,2,'Client Balance Information',0,0)
	END	
END
GO
