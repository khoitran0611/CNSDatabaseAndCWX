﻿
-- [17-Sep-2009] [Minh Dam] Create table CWX_CDL_ImportSource
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_ImportSource]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_CDL_ImportSource](
		[SourceID] [int] IDENTITY(1,1) NOT NULL,
		[ClientID] [int] NOT NULL,
		[Name] [nvarchar](50) NOT NULL,
		[Description] [nvarchar](100) NULL,
		[Fixed] [bit] NOT NULL CONSTRAINT [DF_CWX_ImportSource_Fixed]  DEFAULT ((0)),
		[FieldDelimiter] [varchar](20) NULL,
		[RecordDelimiter] [varchar](20) NULL,
		[FirstLineContainsLabels] [bit] NOT NULL CONSTRAINT [DF_CWX_ImportSource_FirstLineContainsLabels]  DEFAULT ((0)),
		[Type] [tinyint] NOT NULL CONSTRAINT [DF_CWX_ImportSource_Type]  DEFAULT ((0)),
		[CreatedBy] [int] NOT NULL,
		[CreatedDate] [datetime] NOT NULL,
		[UpdatedBy] [int] NULL,
		[UpdatedDate] [datetime] NULL,
		[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ImportSource_Status]  DEFAULT ('A'),
	 CONSTRAINT [PK_CWX_ImportSource] PRIMARY KEY CLUSTERED 
	(
		[SourceID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END 
GO


-- [17-Sep-2009] [Minh Dam] Create table CWX_CDL_SourceMapTemplate
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SourceMapTemplate]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_CDL_SourceMapTemplate](
		[TemplateID] [int] IDENTITY(1,1) NOT NULL,
		[SourceID] [int] NOT NULL,
		[Name] [nvarchar](100) NOT NULL,
		[Description] [nvarchar](100) NULL,
		[DestDatabase] [tinyint] NOT NULL,
		[DestTable] [varchar](200) NULL,
		[Active] [bit] NULL CONSTRAINT [DF_CWX_SourceMapTemplates_Active]  DEFAULT ((0)),
		[Unicode] [bit] NULL CONSTRAINT [DF_CWX_SourceMapTemplate_Unicode]  DEFAULT ((0)),
		[LocaleID] [int] NOT NULL CONSTRAINT [DF_CWX_SourceMapTemplate_LocaleID]  DEFAULT ((0)),
		[CodeBaseID] [int] NOT NULL CONSTRAINT [DF_CWX_SourceMapTemplate_CodeBaseID]  DEFAULT ((0)),
		[CreatedBy] [int] NOT NULL,
		[CreatedDate] [datetime] NOT NULL,
		[UpdatedBy] [int] NULL,
		[UpdatedDate] [datetime] NULL,
		[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_SourceMapTemplate_Status]  DEFAULT ('A'),
	 CONSTRAINT [PK_CWX_ImportTemplates] PRIMARY KEY CLUSTERED 
	(
		[TemplateID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO


-- [17-Sep-2009] [Minh Dam] Create table CWX_CDL_SourceMapDetails
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SourceMapDetails]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_CDL_SourceMapDetails](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[TemplateID] [int] NOT NULL,
		[SourceCol] [varchar](50) NOT NULL,
		[DestField] [varchar](50) NULL,
		[StartPosition] [int] NULL,
		[EndPosition] [int] NULL,
		[FieldType] [tinyint] NULL,
		[Length] [int] NULL,
		[Validation] [varchar](200) NULL,
		[IsDerived] [bit] NULL,
		[DerivedFrom] [varchar](200) NULL,
		[DateFormat] [varchar](50) NULL,
		[ColCollation] [varchar](50) NULL,
		[AllowsNull] [bit] NULL CONSTRAINT [DF_CWX_CDL_SourceMapDetails_Nullable]  DEFAULT ((1)),
		[IsSystemDefined] [bit] NULL CONSTRAINT [DF_CWX_CDL_SourceMapDetails_SystemDefined]  DEFAULT ((0)),
		[CreatedBy] [int] NOT NULL,
		[CreatedDate] [datetime] NOT NULL,
		[UpdatedBy] [int] NULL,
		[UpdatedDate] [datetime] NULL,
		[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_CDL_SourceMapDetails_Status]  DEFAULT ('A'),
	CONSTRAINT [PK_CWX_ImportTemplateDetails] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO


-- [17-Sep-2009] [Minh Dam] Create table CWX_CDL_SourceMapDetails_Validation
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SourceMapDetails_Validation]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_CDL_SourceMapDetails_Validation](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[MapDetailID] [int] NOT NULL,
		[Operator] [varchar](2) NOT NULL,
		[MatchingValue] [nvarchar](255) NULL,
		[Combining] [varchar](2) NULL,
		[DataType] [tinyint] NULL,
	 CONSTRAINT [PK_CWX_CDL_SourceMapDetails_Validation] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO


-- [17-Sep-2009] [Minh Dam] Create table CWX_CDL_ImportDestTable_Dict
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_ImportDestTable_Dict]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_CDL_ImportDestTable_Dict](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[DatabaseID] [tinyint] NOT NULL,
		[TableName] [varchar](50) NULL,
	 CONSTRAINT [PK_CWX_ImportDestTable_Dict] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO


-- [17-Sep-2009] [Minh Dam] Create SP CWX_CDL_GetAllColumnsDefinitions
/****** Object:  StoredProcedure [dbo].[CWX_CDL_GetAllColumnsDefinitions]    Script Date: 09/17/2009 09:32:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_GetAllColumnsDefinitions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CDL_GetAllColumnsDefinitions]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CDL_GetAllColumnsDefinitions]    Script Date: 09/17/2009 09:32:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 07 Sep, 2009
-- Description:	Get all column definitions of a table
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CDL_GetAllColumnsDefinitions]
	-- Add the parameters for the stored procedure here
	@DatabaseName nvarchar(50),
	@TableName nvarchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @Sql nvarchar(500)
	SET @Sql = 
'SELECT c.[name] as [ColumnName], t.[name] as [DataType],
	CASE WHEN t.[name] IN (''nvarchar'', ''nchar'') THEN STR(c.[max_length] / 2) -- nvarchar, nchar are stored 2 bytes
		ELSE STR(c.[max_length])
	END as [MaxLength]
FROM @@DatabaseName.sys.columns c 
	INNER JOIN @@DatabaseName.sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
WHERE c.[object_id] = (SELECT [object_id] FROM @@DatabaseName.sys.objects WHERE [Name] = N''@@TableName'' and [Type]=''U'')'

	SET @Sql = REPLACE(@Sql, '@@DatabaseName', @DatabaseName)
	SET @Sql = REPLACE(@Sql, '@@TableName', @TableName)
	EXEC (@Sql)
END
GO


-- [17-Sep-2009] [Minh Dam] Create SP CWX_CDL_GetNumberOfSourceMapDetails
/****** Object:  StoredProcedure [dbo].[CWX_CDL_GetNumberOfSourceMapDetails]    Script Date: 09/17/2009 09:33:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_GetNumberOfSourceMapDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CDL_GetNumberOfSourceMapDetails]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CDL_GetNumberOfSourceMapDetails]    Script Date: 09/17/2009 09:33:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 01 Sep, 2009
-- Description:	Get the number of source map details of a template
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CDL_GetNumberOfSourceMapDetails]
	@TemplateID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT COUNT(*)
	FROM CWX_CDL_SourceMapDetails
	WHERE TemplateID = @TemplateID
END
GO


-- [17-Sep-2009] [Minh Dam] Create SP [CWX_CDL_ImportSource_GetList]
/****** Object:  StoredProcedure [dbo].[CWX_CDL_ImportSource_GetList]    Script Date: 09/17/2009 09:34:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_ImportSource_GetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CDL_ImportSource_GetList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CDL_ImportSource_GetList]    Script Date: 09/17/2009 09:34:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		MinH Dam
-- Create date: 26 Aug, 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CDL_ImportSource_GetList]
	-- Add the parameters for the stored procedure here
	@ClientID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT a.SourceID, a.Name, a.Description, a.Fixed,
			a.FieldDelimiter, a.RecordDelimiter, a.FirstLineContainsLabels, a.Type,
			a.ClientID, ISNULL(b.ClientName, '') AS ClientName
	FROM CWX_CDL_ImportSource a
		LEFT JOIN ClientInformation b ON b.ClientID = a.ClientID AND b.Status <> 'R'
	WHERE (@ClientID = 0 OR a.ClientID = @ClientID)
		AND a.Status <> 'R'
	ORDER BY a.Name, b.ClientName
END
GO


-- [17-Sep-2009] [Minh Dam] Create SP [CWX_CDL_SourceMapTemplate_UpdateActiveStatus]
/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapTemplate_UpdateActiveStatus]    Script Date: 09/17/2009 09:36:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SourceMapTemplate_UpdateActiveStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CDL_SourceMapTemplate_UpdateActiveStatus]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapTemplate_UpdateActiveStatus]    Script Date: 09/17/2009 09:36:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 28 Aug, 2009
-- Description:	Update active status for all templates of a source
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CDL_SourceMapTemplate_UpdateActiveStatus]
	-- Add the parameters for the stored procedure here
	@TemplateID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @sourceID int
	SELECT @sourceID = SourceID
	FROM CWX_CDL_SourceMapTemplate
	WHERE TemplateID = @TemplateID

	IF (@SourceID IS NOT NULL AND @SourceID > 0)
	BEGIN
		UPDATE CWX_CDL_SourceMapTemplate
		SET Active = 0
		WHERE SourceID = @sourceID
			AND TemplateID <> @TemplateID
	END
END
GO


--[17-Sep-2009] [Minh Dam] Create SP [CWX_CDL_SourceMapDetails_GetBySequenceOrder]
/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapDetails_GetBySequenceOrder]    Script Date: 09/17/2009 16:19:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SourceMapDetails_GetBySequenceOrder]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CDL_SourceMapDetails_GetBySequenceOrder]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapDetails_GetBySequenceOrder]    Script Date: 09/17/2009 16:20:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 17 Sep, 2009
-- Description:	Get a unique SourceMapDetails of a template by sequence order
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CDL_SourceMapDetails_GetBySequenceOrder]
	-- Add the parameters for the stored procedure here
	@TemplateID int,
	@SequenceOrder int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY ID) as RowNumber,
				*
		FROM CWX_CDL_SourceMapDetails
		WHERE TemplateID = @TemplateID
			AND Status <> 'R'		
	)

	SELECT *
	FROM Temp
	WHERE RowNumber = @SequenceOrder
	ORDER BY ID
END
GO


-- [22-Sep-2009] [Minh Dam] Create CreatedBy and CreatedDate column for CWX_CDL_SourceMapDetails table
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_CDL_SourceMapDetails' and c.name = 'CreatedBy')
BEGIN
    ALTER TABLE CWX_CDL_SourceMapDetails
        ADD CreatedBy int NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_CDL_SourceMapDetails' and c.name = 'CreatedDate')
BEGIN
    ALTER TABLE CWX_CDL_SourceMapDetails
        ADD CreatedDate datetime NULL
END
GO

-- [22-Sep-2009] [Minh Dam] Create UpdatedBy and UpdatedDate column for CWX_CDL_SourceMapDetails table
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_CDL_SourceMapDetails' and c.name = 'UpdatedBy')
BEGIN
    ALTER TABLE CWX_CDL_SourceMapDetails
        ADD UpdatedBy int NULL
END
GO

IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_CDL_SourceMapDetails' and c.name = 'UpdatedDate')
BEGIN
    ALTER TABLE CWX_CDL_SourceMapDetails
        ADD UpdatedBy datetime NULL
END
GO


-- [24-Sep-2009] [Minh Dam] Add column 'AutoGeneratedColumns' to CWX_CDL_ImportSource table
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_CDL_ImportSource' and c.name = 'AutoGeneratedColumns')
BEGIN
    ALTER TABLE CWX_CDL_ImportSource
        ADD AutoGeneratedColumns int NULL DEFAULT ((0))
END
GO


-- [24-Sep-2009] [Minh Dam] Add column 'ColumnWidth' to CWX_CDL_SourceMapDetails table
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'CWX_CDL_SourceMapDetails' and c.name = 'ColumnWidth')
BEGIN
    ALTER TABLE CWX_CDL_SourceMapDetails
        ADD ColumnWidth int NULL
END
GO


-- [24-Sep-2009] [Minh Dam] Create SP [CWX_CDL_SourceMapDetails_GenerateMappingColumns]
/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapDetails_GenerateMappingColumns]    Script Date: 09/24/2009 17:27:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SourceMapDetails_GenerateMappingColumns]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CDL_SourceMapDetails_GenerateMappingColumns]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapDetails_GenerateMappingColumns]    Script Date: 09/24/2009 17:28:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 24 Sep, 2009
-- Description:	Auto-generate columns when creating source map template
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CDL_SourceMapDetails_GenerateMappingColumns]
	@TemplateID int,
	@NumberOfColumns int,
	@CreatedBy int,
	@CreatedDate datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	BEGIN TRAN
	BEGIN TRY
		DECLARE @i int
		SET @i = 1
		WHILE (@i <= @NumberOfColumns)
		BEGIN				
			INSERT INTO CWX_CDL_SourceMapDetails
			(
				TemplateID,
				SourceCol,
				DestField,
				FieldType,
				IsDerived,
				AllowsNull,
				IsSystemDefined,
				CreatedBy,
				CreatedDate
			)
			VALUES
			(
				@TemplateID,
				'Col' + cast(@i as varchar(3)),
				'',
				4, -- String
				0,
				1,
				1,
				@CreatedBy,
				@CreatedDate
			)

			SET @i = @i + 1
		END

		COMMIT TRAN
		RETURN 1
	END TRY

	-- Catch exception
	BEGIN CATCH
		ROLLBACK TRAN
		RETURN 0
	END CATCH
END
GO


-- [24-Sep-2009] [Minh Dam] Create SP [CWX_CDL_SourceMapTemplate_ExistAtLeastOneMapping]
/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapTemplate_ExistAtLeastOneMapping]    Script Date: 09/24/2009 17:31:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SourceMapTemplate_ExistAtLeastOneMapping]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CDL_SourceMapTemplate_ExistAtLeastOneMapping]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapTemplate_ExistAtLeastOneMapping]    Script Date: 09/24/2009 17:31:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 24 Sep, 2009
-- Description:	Checks if a Source Map Template has at least one column that maps to destination field.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CDL_SourceMapTemplate_ExistAtLeastOneMapping]
	-- Add the parameters for the stored procedure here
	@TemplateID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS	(SELECT 1
				FROM CWX_CDL_SourceMapDetails
				WHERE TemplateID = @TemplateID
					AND [Status] <> 'R'
					AND LTRIM(RTRIM(ISNULL(DestField,''))) <> '')
		SELECT 1
	ELSE
		SELECT 0
END
GO


-- [25-Sep-2009] [Minh Dam] Create SP [CWX_CDL_SourceMapDetails_GetMinimumStartPositionByID]
/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapDetails_GetMinimumStartPositionByID]    Script Date: 09/25/2009 10:09:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CDL_SourceMapDetails_GetMinimumStartPositionByID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CDL_SourceMapDetails_GetMinimumStartPositionByID]
GO

/****** Object:  StoredProcedure [dbo].[CWX_CDL_SourceMapDetails_GetMinimumStartPositionByID]    Script Date: 09/25/2009 10:09:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 25 Sep, 2009
-- Description:	Get the minimum start position of a source map detail
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CDL_SourceMapDetails_GetMinimumStartPositionByID]
	@TemplateID int,
	@MapDetailID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @Sql varchar(1000)
	SET @Sql = '
	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY ID) AS RowNumber,
				ID, ISNULL(ColumnWidth, 0) AS ColumnWidth
		FROM CWX_CDL_SourceMapDetails
		WHERE TemplateID = ' + cast(@TemplateID as varchar(10)) + '
			AND Status <> ''R''
	)
	'
	
	SET @Sql = @Sql + 'SELECT ISNULL(SUM(ColumnWidth), 0) + 1 AS MinStartPosition FROM Temp'

	IF (@MapDetailID > 0)
	BEGIN				
		SET @Sql = @Sql + ' WHERE RowNumber < (SELECT RowNumber FROM Temp WHERE ID = ' + cast(@MapDetailID as varchar(10)) + ')'
	END

	EXEC (@Sql)
END
GO
