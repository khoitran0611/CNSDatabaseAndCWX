﻿-- Script is applied on version 3.6.6:

PRINT 'Start of Scripts 3.6.6'
GO

/****** Object:  Index [IDX_BILLID2]    Script Date: 04/07/2009 12:03:55 ******/
CREATE NONCLUSTERED INDEX [IDX_BILLID2] ON [dbo].[NotesHistory] 
(
	[BillID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

/****** Object:  Index [IDX_DEBTOR_EMPLOYEE_TYPE2]    Script Date: 04/07/2009 12:04:01 ******/
CREATE NONCLUSTERED INDEX [IDX_DEBTOR_EMPLOYEE_TYPE2] ON [dbo].[NotesHistory] 
(
	[DebtorID] ASC,
	[EmployeeID] ASC,
	[NoteType] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = OFF) ON [PRIMARY]
GO

/****** Object:  Index [IDX_DebtorID2]    Script Date: 04/07/2009 12:04:17 ******/
CREATE NONCLUSTERED INDEX [IDX_DebtorID2] ON [dbo].[NotesHistory] 
(
	[DebtorID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

/****** Object:  Index [IDX_DEBTORID_EMPLOYEEID2]    Script Date: 04/07/2009 12:04:26 ******/
CREATE NONCLUSTERED INDEX [IDX_DEBTORID_EMPLOYEEID2] ON [dbo].[NotesHistory] 
(
	[DebtorID] ASC,
	[EmployeeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = OFF) ON [PRIMARY]
GO

/****** Object:  Index [IDX_NDNT2]    Script Date: 04/07/2009 12:04:36 ******/
CREATE NONCLUSTERED INDEX [IDX_NDNT2] ON [dbo].[NotesHistory] 
(
	[NoteDateTime] DESC,
	[NoteType] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_GetAvailable]    Script Date: 04/09/2009 16:30:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_AllocationSortMaster_GetAvailable]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_AllocationSortMaster_GetAvailable]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AllocationSortMaster_GetAvailable]    Script Date: 04/09/2009 16:30:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_AllocationSortMaster_GetAvailable]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'



-- =============================================
-- Author:		LongNguyen
-- Create date: Feb 27th, 2008
-- Description:	
-- History:
--	[2008-02-20]	Long Nguyen		Init version
--	[2008-12-02]	Minh Dam		Add @AccountProcessingRuleId
-- =============================================
CREATE PROCEDURE [CWX_AllocationSortMaster_GetAvailable] 
	@AccountProcessingRuleId int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT
		CASE SUBSTRING(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))), LEN(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value])))) - 1, 2)
			WHEN ''_Q'' THEN SUBSTRING(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))), 1, LEN(LTRIM(RTRIM(CONVERT(varchar(125), ex.[value])))) - 2)
			ELSE LTRIM(RTRIM(CONVERT(varchar(125), ex.[value])))
		END AS [Description],
		OBJECT_NAME(c.[object_id]) + ''.'' + c.[name] AS SQLFormat
	INTO #Temp
	FROM
		sys.[columns] c
		LEFT OUTER JOIN sys.[extended_properties] ex ON ex.[major_id] = c.[object_id]
	WHERE
		OBJECTPROPERTY(c.[object_id], ''IsMsShipped'')=0
		AND ex.[minor_id] = c.[column_id]
		AND ex.[name] = ''MS_Description''
		AND (
				OBJECT_NAME(c.[object_id]) = ''Account''
				OR OBJECT_NAME(c.[object_id]) = ''PersonInformation''
				OR OBJECT_NAME(c.[object_id]) = ''DebtorInformation''
				OR OBJECT_NAME(c.[object_id]) = ''PersonAddress''
				OR OBJECT_NAME(c.[object_id]) = ''AccountOther''
			)
		AND LTRIM(RTRIM(CONVERT(varchar(125), ex.[value]))) <> ''''
	ORDER BY
		ex.[value]

	SELECT
		0 AS QueueId,
		Description,
		(''"'' + Description + ''"'') AS QueueColumn,
		0 AS sortid,
		''ASC '' AS SortDirection,
		SQLFormat
	FROM
		#Temp
	--WHERE
		--[Description] NOT IN (SELECT Description FROM AllocationSortMaster WHERE RuleId = @AccountProcessingRuleId)
END


' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeProductivity_Get]    Script Date: 04/10/2009 12:11:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeProductivity_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [CWX_MC_EmployeeProductivity_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_MC_EmployeeProductivity_Get]    Script Date: 04/10/2009 12:11:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_MC_EmployeeProductivity_Get]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--CWX_MC_EmployeeProductivity_Get 1001,''1/1/2006'',''1/1/2009''
	CREATE Procedure [CWX_MC_EmployeeProductivity_Get]
	(
		@EmployeeID int,
		@StartDate datetime,
		@EndDate datetime
	)
	As
	Begin

	Set @StartDate=Cast(Convert(varchar(10), @StartDate, 101) as datetime)
	Set @EndDate=Cast(Convert(varchar(10), @EndDate, 101) as datetime)

	Create Table #EmployeeProductivity(FieldID int, metaName varchar(50), FieldName varchar(50), TotalCount float, Target float, TargetAchieved float, AveragePerDay float,
			InboundCallsTarget float, OutboundCallsTarget float, AccountsWorkedTarget float, AccountsContactedTarget float,
			AccountsPromisedTarget float, PromiseAmountTakenTarget float)

	Insert #EmployeeProductivity
		Select id as FieldID, metaName, caption as FieldName, 0 as TotalCount,null,null,null,null,null,null,null,null,null From MC_DataDictionary Where parentID=423

	IF(@EmployeeID>0 AND @StartDate IS NOT NULL AND @EndDate IS NOT NULL)
	Begin

	Declare @AccountsReviewed float
	Declare @AccountsActioned float
	Declare @TotalActions float
	Declare @TotalInbound float
	Declare @TotalOutbound float
	Declare @TotalCalls float
	Declare @AccountsWorked float
	Declare @AccountsContacted float
	Declare @AccountsPromised float
	Declare @TotalPromiseTaken float

	Declare @InboundCallsTarget float
	Declare @OutboundCallsTarget float
	Declare @TotalCallsTarget float
	Declare @AccountsWorkedTarget float
	Declare @AccountsContactedTarget float
	Declare @AccountsPromisedTarget float
	Declare @PromiseAmountTakenTarget float

	Declare @EmployeeWorkingDays float

	SET @EmployeeWorkingDays = (Select dbo.MC_fnEmployeeWorkingDays(@EmployeeID, @StartDate, @EndDate))

	SET @AccountsReviewed = dbo.MC_fnAccountsReviewed(@EmployeeID, @StartDate, @EndDate)
	SET @AccountsActioned = dbo.MC_fnAccountsActioned(@EmployeeID, @StartDate, @EndDate)
	SET @TotalActions = dbo.MC_fnTotalActions(@EmployeeID, @StartDate, @EndDate)

	SET @TotalInbound = dbo.MC_fnInboundCalls(@EmployeeID, @StartDate, @EndDate)
	SET @TotalOutbound = dbo.MC_fnOutboundCalls(@EmployeeID, @StartDate, @EndDate)
	SET @TotalCalls = @TotalInbound + @TotalOutbound
	SET @AccountsWorked = dbo.MC_fnAccountsWorked(@EmployeeID, @StartDate, @EndDate)
	SET @AccountsContacted = dbo.MC_fnAccountsContacted(@EmployeeID, @StartDate, @EndDate)
	SET @AccountsPromised = dbo.MC_fnAccountsPromised(@EmployeeID, @StartDate, @EndDate)
	SET @TotalPromiseTaken = dbo.MC_fnTotalPromiseTaken(@EmployeeID, @StartDate, @EndDate)

	SET @InboundCallsTarget = ISNULL((Select Top 1 Sum(GoalCount) From EmployeeGoals Where (StartDate>=@StartDate And StartDate<@EndDate) AND EmployeeID = @EmployeeID And ActionID = 1),0)*@EmployeeWorkingDays
	SET @OutboundCallsTarget = ISNULL((Select Top 1 Sum(GoalCount) From EmployeeGoals Where (StartDate>=@StartDate And StartDate<@EndDate) AND EmployeeID = @EmployeeID And ActionID = 2),0)*@EmployeeWorkingDays
	SET @TotalCallsTarget = ISNULL(@InboundCallsTarget + @OutboundCallsTarget,0)*@EmployeeWorkingDays
	SET @AccountsWorkedTarget = ISNULL((Select Top 1 GoalCount From EmployeeGoals Where (StartDate>=@StartDate And StartDate<@EndDate) AND EmployeeID = @EmployeeID And ActionID = 4),0)*@EmployeeWorkingDays
	SET @AccountsContactedTarget = ISNULL((Select Top 1 GoalCount From EmployeeGoals Where (StartDate>=@StartDate And StartDate<@EndDate) AND EmployeeID = @EmployeeID And ActionID = 5),0)*@EmployeeWorkingDays
	SET @AccountsPromisedTarget = ISNULL((Select Top 1 GoalCount From EmployeeGoals Where (StartDate>=@StartDate And StartDate<@EndDate) AND EmployeeID = @EmployeeID And ActionID = 6),0)*@EmployeeWorkingDays
	SET @PromiseAmountTakenTarget = ISNULL((Select Top 1 GoalAmount From EmployeeGoals Where (StartDate>=@StartDate And StartDate<@EndDate) AND EmployeeID = @EmployeeID And ActionID = 6),0)*@EmployeeWorkingDays

	-- Count Numbers
	Update #EmployeeProductivity Set TotalCount= @AccountsReviewed,
		Target=null,
		TargetAchieved=null,
		AveragePerDay=null
		Where metaName=''AccountsReviewed'' --Accounts Reviewed

	Update #EmployeeProductivity Set TotalCount= @AccountsActioned,
		Target=null,
		TargetAchieved=null,
		AveragePerDay=null
		Where metaName=''AccountsActioned'' --Accounts Actioned

	Update #EmployeeProductivity Set TotalCount= @TotalActions,
		Target=null,
		TargetAchieved=null,
		AveragePerDay=null
		Where metaName=''TotalActions'' --Actions

	Update #EmployeeProductivity Set TotalCount= @TotalCalls,
		Target=ISNULL(@TotalCallsTarget,0),
		TargetAchieved=(CASE WHEN (@InboundCallsTarget + @OutboundCallsTarget)=0 THEN 0 ELSE @TotalCalls/(@InboundCallsTarget + @OutboundCallsTarget) END),
		AveragePerDay=(CASE WHEN @EmployeeWorkingDays=0 THEN 0 ELSE @TotalCalls/@EmployeeWorkingDays END)
		Where metaName=''TotalCalls'' --Total Calls

	Update #EmployeeProductivity Set TotalCount= @AccountsWorked, 
		Target=ISNULL(@AccountsWorkedTarget,0),
		TargetAchieved=(CASE WHEN @AccountsWorkedTarget=0 THEN 0 ELSE @AccountsWorked/@AccountsWorkedTarget END),
		AveragePerDay=(CASE WHEN @EmployeeWorkingDays=0 THEN 0 ELSE @AccountsWorked/@EmployeeWorkingDays END)
		Where metaName=''AccountsWorked'' --Accounts Worked

	Update #EmployeeProductivity Set TotalCount= @AccountsContacted,
		Target=ISNULL(@AccountsContactedTarget,0),
		TargetAchieved=(CASE WHEN @AccountsContactedTarget=0 THEN 0 ELSE @AccountsContacted/@AccountsContactedTarget END),
		AveragePerDay=(CASE WHEN @EmployeeWorkingDays=0 THEN 0 ELSE @AccountsContacted/@EmployeeWorkingDays END)
		Where metaName=''AccountsContacted'' --Accounts Contacted

	Update #EmployeeProductivity Set TotalCount= @AccountsPromised,
		Target=ISNULL(@AccountsPromisedTarget,0),
		TargetAchieved=(CASE WHEN @AccountsPromisedTarget=0 THEN 0 ELSE @AccountsPromised/@AccountsPromisedTarget END),
		AveragePerDay=(CASE WHEN @EmployeeWorkingDays=0 THEN 0 ELSE @AccountsPromised/@EmployeeWorkingDays END)
		Where metaName=''AccountsPromised'' --Accounts Promised

	Update #EmployeeProductivity Set TotalCount= ISNULL(@TotalPromiseTaken,0),
		Target=ISNULL(@PromiseAmountTakenTarget,0),
		TargetAchieved=(CASE WHEN @PromiseAmountTakenTarget=0 THEN 0 ELSE @TotalPromiseTaken/@PromiseAmountTakenTarget END),
		AveragePerDay=(CASE WHEN @EmployeeWorkingDays=0 THEN 0 ELSE @TotalPromiseTaken/@EmployeeWorkingDays END)
		Where metaName=''TotalPromiseTaken'' --Total Promise Taken


	End

	Select * From #EmployeeProductivity

	End' 
END
GO

PRINT 'Completed execution of Update Scripts 3.6.6'
GO
