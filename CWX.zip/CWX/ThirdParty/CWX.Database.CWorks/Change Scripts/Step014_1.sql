-- Script is applied on version 2.0.1
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Countries_DeleteAll]    Script Date: 06/24/2008 10:59:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Countries_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_Countries_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_Countries_DeleteAll]    Script Date: 06/24/2008 10:59:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_Countries_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Tuan Luong
-- Create date: Jun 24, 2008
-- Description:	Delete all records in Legal_Countries Table
-- Parameters: 
--	@Type: ''''S'''' - Soft delete
--		   ''''P'''' - Permanently delete
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_Countries_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_Countries
		SET [Status] = ''R''
		WHERE [Status] = ''A''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_Countries
	END
END
' 
END
GO

-- =======================================================================
-- Author:			Tuan Luong
-- Create date:		Jun 24, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_SnapshotTypes
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_SnapshotTypes' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_SnapshotTypes
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_SnapshotTypes_RowStatus] DEFAULT 'A'
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_SnapshotTypes_DeleteAll]    Script Date: 06/24/2008 10:59:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_SnapshotTypes_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_SnapshotTypes_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_SnapshotTypes_DeleteAll]    Script Date: 06/24/2008 10:59:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_SnapshotTypes_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Tuan Luong
-- Create date: Jun 24, 2008
-- Description:	Delete all records in Legal_SnapshotTypes Table
-- Parameters: 
--	@Type: ''''S'''' - Soft delete
--		   ''''P'''' - Permanently delete
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_SnapshotTypes_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_SnapshotTypes
		SET [Status] = ''R''
		WHERE [Status] = ''A''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_SnapshotTypes
	END
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_GetQueueStatsByEmployee]    Script Date: 06/24/2008 14:54:04 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Thuy Nguyen>
-- Create date: <17 June 2008>
-- Description:	<Get Queue Statistic by Collector>
-- =============================================
ALTER PROCEDURE [dbo].[CWX_GetQueueStatsByEmployee]
	@EmployeeID int,
	@ReportTime int
	
AS
BEGIN

	DECLARE @BeforeDays INT
	DECLARE @AfterDays INT

	IF (@ReportTime = 0)
		BEGIN
			SELECT EmployeeID, CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) as QueueDate, ISNULL(COUNT(AccountID),0) AS AccountCount, ISNULL(SUM(BillBalance),0) AS AccountBalance 
			FROM Account 
			WHERE CONVERT(VARCHAR(10),QueueDate,121) >= CONVERT(VARCHAR(10),GETDATE() - 7,121)
			AND CONVERT(VARCHAR(10),QueueDate,121) <= CONVERT(VARCHAR(10),GETDATE() + 7,121)
			AND SystemStatusID = 5 
			AND EmployeeID = @EmployeeID		

			GROUP BY EmployeeID, CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
			ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))
		END
	ELSE
		BEGIN
			SELECT EmployeeID, CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) as QueueDate, ISNULL(COUNT(AccountID),0) AS AccountCount, ISNULL(SUM(BillBalance),0) AS AccountBalance 
			FROM Account 
			WHERE SystemStatusID = 5 
				AND EmployeeID = @EmployeeID
				AND AccountID in (SELECT AccountID FROM AccountActions WHERE ResponsibleParty = @EmployeeID 
												  and CONVERT(VARCHAR(10),DateCompleted,121)= CONVERT(VARCHAR(10),GETDATE(),121))

			GROUP BY EmployeeID, CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121)) 
			ORDER BY CONVERT(datetime, CONVERT(VARCHAR(10),QueueDate,121))
		END
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 06/24/2008 15:34:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetListByRule]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 06/24/2008 15:34:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByRule]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 24, 2008
-- Description:	Retrieve records that match the rulecriterias of a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetListByRule] 
	-- Add the parameters for the stored procedure here
	@RuleID int,
	@PageSize int = 0,
	@PageIndex int = 0,
	@ProcessedAccountIDs varchar(4000) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat, Combining
		FROM RuleCriteria
		WHERE RuleID = @RuleID

	DECLARE @SQLFormat varchar(700)
	DECLARE @Combining varchar(10)
	DECLARE @NeedCombining varchar(10)
	DECLARE @WhereClause varchar(2000)
	SET @NeedCombining = ''And''

	OPEN RuleCriteriaCrsr
	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	
	SET @NeedCombining = @NeedCombining + '' (''   /* closed all searching criteria in bracket */
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @WhereClause = ISNULL(@WhereClause, '''') + '' '' + @NeedCombining + '' '' + @SQLFormat
		SET @NeedCombining = @Combining /* remember previous value */

		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	END
	SET @WhereClause = @WhereClause + '' )''

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr

	--Remove the Account that was processed
	IF @ProcessedAccountIDs IS NOT NULL AND @ProcessedAccountIDs <> ''''
	BEGIN
		SELECT CAST(SplitedText AS int) AS AccountID
		INTO #ProcessedAccountIDs
		FROM CWX_FnSplitString(@ProcessedAccountIDs, ''|'')

		SET @WhereClause = @WhereClause + '' AND Account.AccountId NOT IN (SELECT AccountID FROM #ProcessedAccountIDs)''
	END

	--This is used for AllocationRule, if RuleType=1, append condition <Account.MAINTAINOFFICER = 0>
	DECLARE @RuleType tinyint
	SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID
	IF @RuleType = 1
		SET @WhereClause = '' AND Account.MAINTAINOFFICER = 0'' + @WhereClause

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY PRIMARY KEY,
		AccountId int,
		DebtorId int,
		FirstName varchar(50),
		MiddleName varchar(50),
		LastName varchar(50),
		BillBalance money,
		BillAmount money,
		InvoiceNumber varchar(50)
	)

	DECLARE @Sql varchar(4000)

	SET @Sql = ''INSERT INTO #Temp''
				+ '' SELECT''
				+ '' Account.AccountId,Account.DebtorId,PersonInformation.FirstName,PersonInformation.MiddleName,PersonInformation.LastName,Account.BillBalance,Account.BillAmount,Account.InvoiceNumber''
				+ '' FROM Account''
				+ '' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID''
				+ '' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID''
				+ '' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID''
				+ '' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID''
				+ '' WHERE (PersonAddress.MailingAddress = 1)''
				+ @WhereClause
				+ '' ORDER BY Account.AccountId''

	EXEC (@Sql)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	DROP TABLE #Temp

	RETURN @RowCount
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueAStat]    Script Date: 06/24/2008 15:43:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByQueueAStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueAStat]    Script Date: 06/24/2008 15:43:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_AgencyStatus int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN AccountOther o ON o.AccountID = a.AccountID'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId AS varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID = '+CAST(@v_AgencyStatus AS varchar(9))


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 06/24/2008 15:45:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_SearchByQueueSStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_SearchByQueueSStat]    Script Date: 06/24/2008 15:45:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_SystemStatus int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.AccountAge AS [DPD],'
				+ '   CAST(a.MCode AS CHAR(1)) AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN Accountother o ON o.AccountID = a.AccountID'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId as varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID <> 2'

	IF @v_SystemStatus = 0 
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'+''
	ELSE
		SET @cStmt=@cStmt+' AND s.SystemStatus = '+CAST(@v_SystemStatus AS char(9))+''


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueByAmtRange]    Script Date: 06/24/2008 16:12:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_QueueByAmtRange]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_QueueByAmtRange]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueByAmtRange]    Script Date: 06/24/2008 16:13:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_QueueByAmtRange] 
	-- Add the parameters for the stored procedure here
	@v_Range int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause VARCHAR(50)
	SET @orderByClause = ' ORDER BY a.QueueDate DESC'


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate <= getDate()'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

	if ((@EmpList <> '') and (@EmpList <> 'Null'))
	Begin
		SET @cStmt=@cStmt+' AND a.EmployeeID in (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(''' + @EmpList + ''',' + '''' + ',' + '''' + '))'
	End

	if @v_Range = 1
	Begin
		SET @cStmt = @cStmt +'   AND a.BillBalance < 10000'
	End

	if @v_Range = 2
	Begin
		SET @cStmt = @cStmt +'  AND a.BillBalance >= 10000'
		SET @cStmt = @cStmt +'  AND a.BillBalance < 25000'
	End

	if @v_Range = 3
	Begin
		SET @cStmt = @cStmt +'	AND a.BillBalance >= 25000'
		SET @cStmt = @cStmt +'	AND a.BillBalance < 50000'		
	End

	if @v_Range = 4
	Begin
		SET @cStmt = @cStmt +'	AND a.BillBalance >= 50000'
		SET @cStmt = @cStmt +'	AND a.BillBalance < 150000'		
	End

	if @v_Range = 5
	Begin
		SET @cStmt = @cStmt +'	AND a.BillBalance >= 150000'
	End


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueFuture]    Script Date: 06/24/2008 16:13:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_QueueFuture]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_QueueFuture]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueFuture]    Script Date: 06/24/2008 16:14:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_QueueFuture] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@Days int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		[KeyField] varchar(30),
		[QueueDate] char(10),
		[Account Number] varchar(50),
		[DPD] int,
		[Bucket] smallint,
		[Cycle] smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		[Status] varchar(10),
		[Priority] int,
		[Assignment Type] char(1),
		[Name] varchar(200)
	)
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause VARCHAR(50)
	SET @orderByClause = ' ORDER BY a.QueueDate DESC'


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.EmployeeID = ' + CAST(@EmployeeID AS varchar(10))
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

	--Today|2|GE Today|0|Tomorrow|1|3 Days|3|5 Days|5
	if (@Days = 1) or (@Days = 3) or (@Days = 5)
	Begin
		SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) <= dateadd(day,' + CAST(@Days AS varchar(10)) + ', getdate())'
		SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) >= getdate()'
	End

	if @Days = 2
	Begin
		SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) = getdate()'
	End

	if @Days = 0
	Begin
		SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) >= getdate()'
	End


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END
GO

IF NOT EXISTS (SELECT * FROM AvailableActions WHERE ActionID=8)
	INSERT INTO AvailableActions VALUES(8, 'Account Reviewed', 0, 'S', 0, 1, 'SYS', 0, 0, 0, 0, 0, 'A', NULL)
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 06/24/2008 17:32:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetListByRule]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetListByRule]    Script Date: 06/24/2008 17:32:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetListByRule]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'


-- =============================================
-- Author:		LongNguyen
-- Create date: Mar 24, 2008
-- Description:	Retrieve records that match the rulecriterias of a rule
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetListByRule] 
	-- Add the parameters for the stored procedure here
	@RuleID int,
	@PageSize int = 0,
	@PageIndex int = 0,
	@ProcessedAccountIDs varchar(4000) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE RuleCriteriaCrsr CURSOR FOR
		SELECT SQLFormat, Combining
		FROM RuleCriteria
		WHERE RuleID = @RuleID

	DECLARE @SQLFormat varchar(700)
	DECLARE @Combining varchar(10)
	DECLARE @NeedCombining varchar(10)
	DECLARE @WhereClause varchar(2000)
	DECLARE @IsOpenningBracket bit
	SET @NeedCombining = ''And''
	SET @WhereClause = ''''
	SET @IsOpenningBracket = 0

	OPEN RuleCriteriaCrsr
	FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF (LOWER(@Combining) = ''or'')
			IF (@IsOpenningBracket = 0)
			BEGIN
				SET @WhereClause = @WhereClause + '' '' + @NeedCombining + '' ('' + @SQLFormat
				SET @IsOpenningBracket = 1
			END
			ELSE
				SET @WhereClause = @WhereClause + '' '' + @NeedCombining + '' '' + @SQLFormat
		ELSE
		BEGIN
			SET @WhereClause = @WhereClause + '' '' + @NeedCombining + '' '' + @SQLFormat			
			IF (@IsOpenningBracket = 1)
			BEGIN
				SET @WhereClause = @WhereClause + '') ''
				SET @IsOpenningBracket = 0
			END
		END

		SET @NeedCombining = @Combining /* remember previous value */
		FETCH NEXT FROM RuleCriteriaCrsr INTO @SQLFormat, @Combining
	END

	CLOSE RuleCriteriaCrsr
	DEALLOCATE RuleCriteriaCrsr

	--Remove the Account that was processed
	IF @ProcessedAccountIDs IS NOT NULL AND @ProcessedAccountIDs <> ''''
	BEGIN
		SELECT CAST(SplitedText AS int) AS AccountID
		INTO #ProcessedAccountIDs
		FROM CWX_FnSplitString(@ProcessedAccountIDs, ''|'')

		SET @WhereClause = @WhereClause + '' AND Account.AccountId NOT IN (SELECT AccountID FROM #ProcessedAccountIDs)''
	END

	--This is used for AllocationRule, if RuleType=1, append condition <Account.MAINTAINOFFICER = 0>
	DECLARE @RuleType tinyint
	SELECT @RuleType = RuleType FROM RuleTable WHERE ID = @RuleID
	IF @RuleType = 1
		SET @WhereClause = '' AND Account.MAINTAINOFFICER = 0'' + @WhereClause

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY PRIMARY KEY,
		AccountId int,
		DebtorId int,
		FirstName varchar(50),
		MiddleName varchar(50),
		LastName varchar(50),
		BillBalance money,
		BillAmount money,
		InvoiceNumber varchar(50)
	)

	DECLARE @Sql varchar(4000)

	SET @Sql = ''INSERT INTO #Temp''
				+ '' SELECT''
				+ '' Account.AccountId,Account.DebtorId,PersonInformation.FirstName,PersonInformation.MiddleName,PersonInformation.LastName,Account.BillBalance,Account.BillAmount,Account.InvoiceNumber''
				+ '' FROM Account''
				+ '' INNER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID''
				+ '' INNER JOIN DebtorInformation ON Account.DebtorID = DebtorInformation.DebtorID''
				+ '' INNER JOIN PersonInformation ON DebtorInformation.PersonID = PersonInformation.PersonID''
				+ '' INNER JOIN PersonAddress ON PersonAddress.PersonID = PersonInformation.PersonID''
				+ '' WHERE (PersonAddress.MailingAddress = 1)''
				+ @WhereClause
				+ '' ORDER BY Account.AccountId''

	EXEC (@Sql)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	DROP TABLE #Temp

	RETURN @RowCount
END
' 
END
GO

-- =======================================================================
-- Author:			Tuan Luong
-- Create date:		Jun 24, 2008
-- Description:		Add column 'Status' with default value 'A'
--					use this field to mark the row is active 'A' or retire 'R'
-- Effected table:	Legal_RelationshipTypes
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_RelationshipTypes' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_RelationshipTypes
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_RelationshipTypes_RowStatus] DEFAULT 'A'
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_RelationshipTypes_DeleteAll]    Script Date: 06/24/2008 10:59:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_RelationshipTypes_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_RelationshipTypes_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_RelationshipTypes_DeleteAll]    Script Date: 06/24/2008 10:59:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_RelationshipTypes_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================================
-- Author:		Tuan Luong
-- Create date: Jun 24, 2008
-- Description:	Delete all records in Legal_RelationshipTypes Table
-- Parameters: 
--	@Type: ''''S'''' - Soft delete
--		   ''''P'''' - Permanently delete
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_RelationshipTypes_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_RelationshipTypes
		SET [Status] = ''R''
		WHERE [Status] = ''A''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_RelationshipTypes
	END
END
' 
END
GO

/******  Script Closed. Go next: Step014_2  ******/