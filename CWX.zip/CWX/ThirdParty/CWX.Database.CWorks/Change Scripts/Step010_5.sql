 -- Scripts are applied on version 1.5.3 & 1.5.4
 
 /****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseStat]    Script Date: 05/07/2008 10:53:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetPromiseStat]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseStat]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetPromiseStat]    Script Date: 05/07/2008 10:53:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetPromiseStat]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get Promise Statistics
-- History:
--		2008/04/29	[Binh Truong]	Init version
--		2008/05/05	[Binh Truong]	Add criteria to exclude closed AccountStatus.
--		2008/05/07	[Binh Truong]	Add specific AccountPromise table name of a column to fix ambiguous 
--									column name ''EmployeeID''
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetPromiseStat] 	
(
	@EmployeeID int = 0,
	@From datetime = NULL,
	@To datetime = NULL
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @Statement NVARCHAR(4000)
	DECLARE @Select NVARCHAR(1000)
	DECLARE @Conditions NVARCHAR(1000)
	DECLARE @GroupBy NVARCHAR(50)
	DECLARE @OrderBy NVARCHAR(50)
	DECLARE @Parms NVARCHAR(500)
		
	SET @Select = ''	
		SELECT		AccountPromise.Status, COUNT(*) AS AccountAmount, SUM(AmountPromised) AS Promised, SUM(AmountPaid) AS Paid
		FROM        AccountPromise INNER JOIN
							Account ON AccountPromise.AccountID = Account.AccountID
		''
	SET @Conditions = '' WHERE (Account.AgencyStatusID <> 2) ''
	SET @GroupBy = '' GROUP BY AccountPromise.Status ''
	SET @OrderBy = '' ORDER BY AccountPromise.Status ''
	
	IF @EmployeeID <> 0
	BEGIN
		SET @Conditions = @Conditions +
			''
			AND AccountPromise.EmployeeID = @EmployeeID
			''
	END
	
	IF @From IS NOT NULL
	BEGIN
		SET @To = DATEADD(day, 1, @To)
		SET @Conditions = @Conditions +
			''
			AND (DatePromised >= @From AND DatePromised < @To)
			''	
	END
	
	SET @Statement = @Select + @Conditions + @GroupBy + @OrderBy
	
	SET @Parms = ''
			@EmployeeID int,
			@From datetime,
			@To datetime
			''
	
	EXEC dbo.sp_executesql @Statement, @Parms,
							@EmployeeID,
							@From,
							@To
	
END' 
END
GO



/****** Object:  StoredProcedure [dbo].[CWX_Notes_GetWithType]    Script Date: 05/07/2008 16:44:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Tai Ly
-- Create date: April 29, 1008
-- Description:	Get notes from database
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Notes_GetWithType] 	
	-- Add the parameters for the stored procedure here
	@DebtorID	int,
	@AccountID	int,
	@NoteText	varchar(256) = '',
	@NoteType	varchar(1) = ' ',	
	@Month		int = -1,
	@Day		int = -1,
	@FromDate	datetime = '1753-01-01',
	@ToDate		datetime = '9999-12-31',
	@PageSize	int = 10,
	@PageIndex	int = 0
AS
BEGIN
	Declare @IdentityTableValue int

	DECLARE @TempTableVar table(
		RowNumber		int,
		NoteDateTime	datetime,
		NoteText		varchar(700),
		NoteType		varchar(1),
		UserID			varchar(10)
	);

	Set @IdentityTableValue = (Select FieldValue from IdentityFields where TableName = 'NotesDisplayByAccount')
	IF (@IdentityTableValue <= 0 )
	BEGIN 						
			IF (@IdentityTableValue < 0)
			BEGIN
				Insert into IdentityFields values('NotesDisplayByAccount',0)
			END
			IF (@NoteType = ' ') -- all note type			
			BEGIN						
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN													
						SELECT @NoteText = '%' + @NoteText + '%';											
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate)								
										AND n.NoteText LIKE @NoteText										
					
				END
				ELSE IF @Month = -1	-- no month input
				BEGIN													
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID 
										AND n.NoteText LIKE @NoteText AND							
										(DAY(DATEADD(day, @Day, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(day, @Day, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(day, @Day, n.NoteDateTime)) = YEAR(GETDATE())												
										)											
					
				END
				ELSE	-- no day input
				BEGIN													
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar 
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID 
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(month, @Month, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(month, @Month, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(month, @Month, n.NoteDateTime)) = YEAR(GETDATE())												
										)										
					
				END
			END
			ELSE
			BEGIN	-- has note type
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) AND n.NoteText LIKE @NoteText											

				END
				ELSE IF @Month = -1		-- no month input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY e.EmployeeID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(day, @Day, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(day, @Day, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(day, @Day, n.NoteDateTime)) = YEAR(GETDATE())												
										)
							ORDER BY	n.NoteDateTime DESC, n.NoteID			
				END
				ELSE -- no day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO @TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.DebtorID = @DebtorID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)  
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(month, @Month, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(month, @Month, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(month, @Month, n.NoteDateTime)) = YEAR(GETDATE())												
										)														
				END
			END
	END	
	ELSE		
	BEGIN
			IF (@NoteType = ' ')	-- no note type			
			BEGIN
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) 
										AND n.NoteText LIKE @NoteText							

				END
				ELSE IF (@Month = -1)	-- no month input
				BEGIN
					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID 
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(day, @Day, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(day, @Day, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(day, @Day, n.NoteDateTime)) = YEAR(GETDATE())												
										)							
					
				END
				ELSE	-- no day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(month, @Month, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(month, @Month, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(month, @Month, n.NoteDateTime)) = YEAR(GETDATE())												
										)															
				END				
			END
			ELSE	-- has note type
			BEGIN
				IF @Month = -1 AND @Day = -1	-- no month and day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  AND UPPER(NoteType) = UPPER(@NoteType) 
										AND (n.NoteDateTime BETWEEN @FromDate AND @ToDate) AND n.NoteText LIKE @NoteText							
					
				END
				ELSE IF @Month = -1			-- no month input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID  AND UPPER(NoteType) = UPPER(@NoteType) 
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(day, @Day, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(day, @Day, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(day, @Day, n.NoteDateTime)) = YEAR(GETDATE())												
										)																		
				END
				ELSE						-- no day input
				BEGIN					
						SELECT @NoteText = '%' + @NoteText + '%';
						INSERT INTO	@TempTableVar
							SELECT		ROW_NUMBER() OVER (ORDER BY	n.NoteDateTime DESC, n.NoteID) AS RowNumber, n.NoteDateTime, n.NoteText, n.NoteType, e.UserID 					
							FROM		NotesCurrent n, Employee e 
							WHERE		n.BillID = @AccountID and n.EmployeeID *= e.EmployeeID AND UPPER(NoteType) = UPPER(@NoteType)
										AND n.NoteText LIKE @NoteText AND
										(DAY(DATEADD(month, @Month, n.NoteDateTime)) = DAY(GETDATE()) AND 
										 MONTH(DATEADD(month, @Month, n.NoteDateTime)) = MONTH(GETDATE()) AND
										 YEAR(DATEADD(month, @Month, n.NoteDateTime)) = YEAR(GETDATE())												
										)							

				END					
			END
	END		

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF (@PageSize <= 0)
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
	ELSE
		SELECT	NoteDateTime, NoteText, NoteType, UserID 
		FROM	@TempTableVar
		WHERE	RowNumber BETWEEN (@PageIndex * @PageSize + 1) AND ((@PageIndex + 1) * @PageSize)		

	RETURN @RowCount

END
GO

 /****** Object:  Table [dbo].[CWX_CustomDefinedFields]    Script Date: 05/06/2008 16:33:16 ******/
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = '[dbo].[CWX_CustomDefinedFields]')
	BEGIN
		DROP  Table [dbo].[CWX_CustomDefinedFields]
	END
GO

CREATE TABLE [dbo].[CWX_CustomDefinedFields](
[ID] [int] IDENTITY(1,1) NOT NULL,
[AgencyID] [int] NOT NULL CONSTRAINT [DF_CWX_CustomDefinedFields_AgencyID]  DEFAULT ((0)),
[AccountID] [int] NOT NULL CONSTRAINT [DF_CWX_CustomDefinedFields_AccountID]  DEFAULT ((0)),
[DebtorID] [int] NOT NULL CONSTRAINT [DF_CWX_CustomDefinedFields_DebtorID]  DEFAULT ((0)),
[Description] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Value] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]

CREATE NONCLUSTERED INDEX [IDX_CustomDebtorID] ON [dbo].[CWX_CustomDefinedFields] 
(
[DebtorID] ASC
) 
GO


 /****** Object:  StoredProcedure [dbo].[CWX_CustomDefinedFields_Insert]    ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CustomDefinedFields_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CustomDefinedFields_Insert]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Tai Ly
-- Create date: May-06-2005
-- Description:	Insert new tracer information
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CustomDefinedFields_Insert]
	-- Add the parameters for the stored procedure here	
	@DebtorID		int,
	@AccountID		int,
	@Description	varchar(100),
	@Value			varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SET ROWCOUNT 0;

    -- Insert statements for procedure here
	INSERT INTO [dbo].[CWX_CustomDefinedFields](AccountID, DebtorID, Description, Value) VALUES(@AccountID, @DebtorID, @Description, @Value)
	
	RETURN @@ROWCOUNT
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_LoadTransactionTypeForAccount]    Script Date: 05/07/2008 09:44:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoadTransactionTypeForAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_LoadTransactionTypeForAccount]
GO
/****** Object:  StoredProcedure [dbo].[CWX_LoadTransactionTypeForAccount]    Script Date: 05/07/2008 09:44:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LoadTransactionTypeForAccount]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		KhoaDuong
-- Create date: May 02, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LoadTransactionTypeForAccount] 
	-- Add the parameters for the stored procedure here
	@AccountID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    --Select t.* From TransactionType t, Account a Where t.ClientID  = a.ClientID And  t.ClientID = 0 and a.AccountID = @AccountID 
	Select t.* From TransactionType t, Account a Where t.ClientID  = a.ClientID And a.AccountID = @AccountID 
	
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_TransactionSummary]    Script Date: 05/07/2008 09:44:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionSummary]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TransactionSummary]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TransactionSummary]    Script Date: 05/07/2008 09:44:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionSummary]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<khoadang>
-- Create date: <may 6>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CalculateTransactionsSummary]
	@AccountID int
AS
BEGIN
	Select TransactionType, Descriptor, Sum(TransactionAmount) As Amount, Sum(ClientPart) As ClientPart, 
			Sum(AgencyPart) As AgencyPart, Sum(EmployeePart) As EmployeePart
		From Transactions Where AccountID=@AccountID and ConsiderWhenCalcBal=1
		Group By TransactionType, Descriptor
END
' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_Get]    Script Date: 05/07/2008 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CWX_TracerInformation_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_TracerInformation_Get]
GO
/****** Object:  StoredProcedure [dbo].[CWX_TracerInformation_Get]    Script Date: 05/07/2008 ******/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Tai Ly
-- Create date: May 7, 2008
-- Description:	Get items tracer information.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TracerInformation_Get]
	-- Add the parameters for the stored procedure here
	@DebtorID	int,
	@AccountID	int,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT ROW_NUMBER() OVER (ORDER BY ID) AS RowNumber, ID, Description, Value		
	INTO #Temp
	FROM CWX_CustomDefinedFields
	WHERE AgencyID = 0 AND AccountID = @AccountID AND DebtorID = @DebtorID	

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	IF @PageSize <= 0
		SELECT * FROM #Temp
	ELSE
		SELECT * FROM #Temp
		WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	RETURN @RowCount

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueByAmtRange]    Script Date: 05/07/2008 10:17:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_QueueByAmtRange]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_QueueByAmtRange]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_QueueByAmtRange]    Script Date: 05/07/2008 10:17:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_QueueByAmtRange] 
	-- Add the parameters for the stored procedure here
	@v_Range int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		[KeyField] varchar(30),
		[QueueDate] char(10),
		[Account Number] varchar(50),
		[DPD] int,
		[Bucket] char(1),
		[Cycle] smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		[Status] varchar(10),
		[Priority] int,
		[Assignment Type] char(1),
		[Name] varchar(200)
	)
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' INSERT INTO #Temp'
				+ ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate <= getDate()'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

				if ((@EmpList <> '') and (@EmpList <> 'Null'))
				Begin
					SET @cStmt=@cStmt+' AND a.EmployeeID in (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(''' + @EmpList + ''',' + '''' + ',' + '''' + '))'
				End

				if @v_Range = 1
				Begin
					SET @cStmt = @cStmt +'   AND a.BillBalance < 10000'
				End

				if @v_Range = 2
				Begin
					SET @cStmt = @cStmt +'  AND a.BillBalance >= 10000'
					SET @cStmt = @cStmt +'  AND a.BillBalance < 25000'
				End

				if @v_Range = 3
				Begin
					SET @cStmt = @cStmt +'	AND a.BillBalance >= 25000'
					SET @cStmt = @cStmt +'	AND a.BillBalance < 50000'		
				End

				if @v_Range = 4
				Begin
					SET @cStmt = @cStmt +'	AND a.BillBalance >= 50000'
					SET @cStmt = @cStmt +'	AND a.BillBalance < 150000'		
				End

				if @v_Range = 5
				Begin
					SET @cStmt = @cStmt +'	AND a.BillBalance >= 150000'
				End

				Set @cStmt = @cStmt + ' Order by a.QueueDate DESC'

				EXEC (@cStmt)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetAmountPromised]    Script Date: 05/07/2008 16:31:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetAmountPromised]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_AccountPromise_GetAmountPromised]
GO
/****** Object:  StoredProcedure [dbo].[CWX_AccountPromise_GetAmountPromised]    Script Date: 05/07/2008 16:31:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountPromise_GetAmountPromised]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get total outstanding, amount promised, amount remain money of an account.
-- History:
--		2008/05/06	[Binh Truong]	Init version.
--		2008/05/07	[Binh Truong]	Remove Amount Paid information.
-- =============================================
CREATE PROCEDURE [dbo].[CWX_AccountPromise_GetAmountPromised]
(
	@AccountID int = NULL
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @CurrentAmountPromised decimal(18,2)
	-- DECLARE @AmountPaid decimal(18,2)
	DECLARE @TotalOutstanding decimal(18,2)
		
	SELECT	@TotalOutstanding=SUM(BillBalance)
	FROM	Account
	WHERE	(ISNULL(@AccountID, 0) = 0 OR AccountID = @AccountID)
		
	SELECT	@CurrentAmountPromised=SUM(AmountPromised) - SUM(AmountPaid)
	FROM	AccountPromise
	WHERE	(ISNULL(@AccountID, 0) = 0 OR AccountID = @AccountID) AND
			Status = 0 -- Not due
	/*
	SELECT	@AmountPaid=SUM(AmountPaid)
	FROM	AccountPromise
	WHERE	(ISNULL(@AccountID, 0) = 0 OR AccountID = @AccountID) AND
			(Status = 1 OR Status = 2) -- Paid on time or paid late
	*/			
	SELECT	@TotalOutstanding as TotalOutstanding,
			@CurrentAmountPromised as CurrentAmountPromised,
			--@AmountPaid as AmountPaid,
			@TotalOutstanding - @CurrentAmountPromised as RemainingAmount
	
END' 
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_GetSettingByAccountID]    Script Date: 05/07/2008 16:31:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_GetSettingByAccountID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ProductSetting_GetSettingByAccountID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ProductSetting_GetSettingByAccountID]    Script Date: 05/07/2008 16:31:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ProductSetting_GetSettingByAccountID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Description:	Get product settings by Account ID.
-- History:
--		2008/05/08	[Binh Truong]	Init version.
-- =============================================
create PROCEDURE [dbo].[CWX_ProductSetting_GetSettingByAccountID]
(
	@AccountID int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @ProductInfo int
	DECLARE @Bucket varchar(10)
	DECLARE @ProductID int 
	
	SET @ProductInfo = 6
	
	SELECT  @Bucket=MCode, @ProductID=ClientID
	FROM Account
	WHERE AccountID = @AccountID
	
	SELECT  InformationTable.*
	FROM    InformationTable
	WHERE	(InfoID = @ProductInfo) AND 
			(InfoKey = @Bucket) AND 
			(InfoType = @ProductID)
	
END' 
END
GO

/******  Script Closed. Go next: Step010_6  ******/