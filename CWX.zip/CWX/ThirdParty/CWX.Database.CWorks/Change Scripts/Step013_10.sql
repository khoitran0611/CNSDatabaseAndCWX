-- Script is applied on version 1.9.15

-- =======================================================================
-- Author:		Binh Truong
-- Create date: Jun 14, 2008
-- Description:	Add column DateTaken, TotalOS, MinPromiseAmt, MinPromisePer, PromiseIntDays,
--				PerToKeepPromise, GraceDays, DateBroken to AccountPromise table.
-- =======================================================================
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'AccountPromise')
BEGIN
	ALTER TABLE AccountPromise
	ADD DateTaken datetime NULL
	
	ALTER TABLE AccountPromise
	ADD TotalOS decimal(18,4) NULL
	
	ALTER TABLE AccountPromise
	ADD MinPromiseAmt money NULL
	
	ALTER TABLE AccountPromise
	ADD MinPromisePer int NULL
	
	ALTER TABLE AccountPromise
	ADD PromiseIntDays int
	
	ALTER TABLE AccountPromise
	ADD PerToKeepPromise int
END
GO 

/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_GetListByAccountID]    Script Date: 06/16/2008 15:27:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_GetListByAccountID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CosigneeInformation_GetListByAccountID]
GO
/****** Object:  StoredProcedure [dbo].[CWX_CosigneeInformation_GetListByAccountID]    Script Date: 06/16/2008 15:29:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 18, 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_GetListByAccountID] 
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(c.PersonID)
	FROM CosigneeInformation c
	JOIN PersonInformation p ON c.PersonID = p.PersonID
	JOIN PersonAddress a ON a.PersonID = p.PersonID
	WHERE
		a.AddressType = 2
		AND c.Bill = @AccountID

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  (p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + p.LastName)) AS RowNumber,
			c.PersonID,
			(p.Title + ' ' + p.FirstName + ' ' + p.MiddleName + ' ' + p.LastName) AS FullName,
			c.Relationship_no,
			a.Address1,
			a.City,
			a.State,
			a.Zip,
			p.HomePhone,
			p.MobilPhone,
			p.EmploymentPhone
		FROM CosigneeInformation c
		JOIN PersonInformation p ON c.PersonID = p.PersonID
		JOIN PersonAddress a ON a.PersonID = p.PersonID
		WHERE
			a.AddressType = 2
			AND c.Bill = @AccountID
	)

	SELECT *
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

/******  Script Closed. Go next: Step013_11  ******/