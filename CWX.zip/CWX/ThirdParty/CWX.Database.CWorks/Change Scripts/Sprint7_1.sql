﻿-- =============================================
-- Author:		Hung Nguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_ClientProperties' AND COLUMN_NAME = N'UpdateDate' )
BEGIN
ALTER TABLE [dbo].[CWX_ClientProperties]
	ADD [UpdateDate] [smalldatetime] NULL CONSTRAINT [DF_CWX_ClientProperties_UpdateDate]  DEFAULT (getdate())
END


IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_ClientProperties' AND COLUMN_NAME = N'UpdateBy' )
BEGIN
ALTER TABLE [dbo].[CWX_ClientProperties]
	ADD [UpdateBy] [int] NULL
END

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_ClientProperties' AND COLUMN_NAME = N'Version' )
BEGIN
ALTER TABLE [dbo].[CWX_ClientProperties]
	ADD [Version] [int] NULL CONSTRAINT [DF_CWX_ClientProperties_Version]  DEFAULT (1)
END




IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_ClientCommModel' AND COLUMN_NAME = N'UpdateBy' )
BEGIN
ALTER TABLE [dbo].[CWX_ClientCommModel]
	ADD [UpdateBy] [int] NULL
END

GO
SET ANSI_PADDING OFF 

GO
/****** Object:  Table [dbo].[CWX_ClientPropertiesLog]    Script Date: 06/02/2009 11:33:08 ******/
IF not  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientPropertiesLog]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_ClientPropertiesLog](
		[LogID] [int] IDENTITY(1,1) NOT NULL,
		[ClientID] [int] NULL,
		[BillingPeriod] [int] NULL,
		[InvoiceType] [int] NULL,
		[BillCommissiontoDebtor] [bit] NULL,
		[AgingType] [int] NULL,
		[ChargeFeeToClient] [bit] NULL,
		[ChargeFeetoDebtor] [bit] NULL,
		[Currency] [int] NULL,
		[StatementCurrency] [int] NULL,
		[ExchangeRate] [decimal](19, 5) NULL,
		[DebtorStatementSortOrder] [bit] NULL,
		[AddCommissionToOwing] [bit] NULL,
		[ReferralRate] [decimal](19, 5) NULL,
		[TaxExempt] [bit] NULL,
		[DiscountID] [int] NULL,
		[Status] [char](1) NULL CONSTRAINT [DF_CWX_ClientPropertiesLog_Status]  DEFAULT ('A'),
		[ClientFixFee] [money] NULL,
		[DebtorFixFee] [money] NULL,
		[UpdateDate] [smalldatetime] NULL CONSTRAINT [DF_CWX_ClientPropertiesLog_UpdateDate]  DEFAULT (getdate()),
		[UpdateBy] [int] NULL,
		[Version] [int] NULL CONSTRAINT [DF_CWX_ClientPropertiesLog_Version]  DEFAULT ((1)),
	 CONSTRAINT [PK_CWX_ClientPropertiesLog_1] PRIMARY KEY CLUSTERED 
	(
		[LogID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

END

GO
SET ANSI_PADDING OFF

IF Not EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommModelLog]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_ClientCommModelLog](
		[LogID] [int] IDENTITY(1,1) NOT NULL,
		[ID] [int] NULL,
		[ClientID] [int] NOT NULL,
		[Code] [varchar](50) NOT NULL,
		[Description] [nvarchar](100) NOT NULL,
		[SetupTo] [tinyint] NOT NULL,
		[ModelType] [tinyint] NOT NULL,
		[ClientCommRateID] [int] NULL,
		[ClientCommPlanID] [int] NULL,
		[FinancialTypeID] [int] NULL,
		[SystemStatusID] [int] NULL,
		[TransactionTypeID] [int] NULL,
		[Status] [char](1) NOT NULL CONSTRAINT [DF_CWX_ClientCommModelLog_Status]  DEFAULT ('A'),
		[CreatedDate] [datetime] NULL,
		[UpdatedDate] [datetime] NULL,
		[UserID] [int] NULL,
		[IsActive] [bit] NOT NULL CONSTRAINT [DF_CWX_ClientCommModelLog_IsActive]  DEFAULT ((1)),
		[UpdateBy] [int] NULL,
	 CONSTRAINT [PK_CWX_ClientCommModelLog_1] PRIMARY KEY CLUSTERED 
	(
		[LogID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END

GO

--
if not exists( select top 1 [description]  from dbo.InformationTable where [description]='Load all Client Accounts')
begin
    INSERT INTO [dbo].[InformationTable]([InfoID], [InfoType], [InfoSubType], [InfoKey], [Description], [Value], [ValueFormat], [Status])
	VALUES(1, 18, 0, N'', N'Load all Client Accounts', N'', N'True', N'A')
end



SET ANSI_PADDING OFF
GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 06/04/2009 15:48:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_LoadXML]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_LoadXML]


GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_LoadXML]    Script Date: 06/04/2009 15:48:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description:	Load all accounts with debtorID
-- History:
--	2008/04/03	[Tai Ly]		Init version.
--	2008/06/01	[Long Nguyen]	Add and remove some fields.
--	2008/06/27	[Binh Truong]	Remove BatchNumber field.	
--	2008/08/25	[Long Nguyen]	Remove @AdditionalTag
--	2008/09/04	[Thuy Nguyen]	Remove CoSigner table reference
--	2009/03/19	[Thuy Nguyen]	Remove ClientInformation.ContactName
--  2009/04/10	[Minh Dam]		Add parameter "@EmployeeID" that is the id of current login user 
--									and filter Account by ClientID belong to this user.
--	2009/05/25	[Minh Dam]		Only filter Account by ClientID when application by client
--	2009/06/04	[Hung nguyen]	Only filter Account by ClientID when Consolidation is account or ( Consolidation is not account and Load all Client Accounts  is checked)
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_LoadXML]
	@DebtorID	int,
	@EmployeeID int
AS
BEGIN
	SET NOCOUNT ON;
	
    /* 
		Get more information for account
			- AccountID
			- Number of CoSigner: c
			- Latest Account Letter: al
			- Get first promise: p (include promise frequency: pf)
			- Get Additional Data
				+ Latest Account Action: aa
				+ Number of Promise to pay: ptp
				+ Number of kept Promise: pk
				+ Number of broken Promise: bp
				+ Number of outgoing call: oc
	*/
	/*	
	DECLARE @ApplicationBy int
	SELECT @ApplicationBy = FieldValue FROM IdentityFields WHERE TableName = 'ApplicationBy'

	IF (@ApplicationBy <> 1) -- Only filter Account by ClientID when ApplicationBy = 1 (by Client)
		SET @EmployeeID = 0
	*/

-- Relationship Collection - Consolidation    
   DECLARE @RelationshipCollection int;
   SELECT @RelationshipCollection=ValueFormat 
   FROM dbo.InformationTable
   WHERE infoid=1 and InfoType=1 and InfoSubType=0;

-- Load all Client Accounts  
   DECLARE @LoadAllClientAccounts bit;
   SELECT @LoadAllClientAccounts=ValueFormat 
   FROM dbo.InformationTable
   WHERE infoid=1 and InfoType=18 and InfoSubType=0;

-- Only filter Account by ClientID when ApplicationBy = 1 (by Client)
   IF((@RelationshipCollection<>0)AND (@LoadAllClientAccounts=0))
   BEGIN
	 SET @EmployeeID = 0 --no filter by client id
   END	
   
	--ThanhNguyen: temporary remove filterby client because encouter error
	SET @EmployeeID = 0;
	---end of ThanhNguyen
	
	WITH ClientListTable AS
	(		
		SELECT * FROM dbo.CWX_AssignedClientIDTable(@EmployeeID)
	)

	SELECT
			a.AccountID,
			ISNULL(l.LetterDesc, '') AS SENTBY, ISNULL(al.LetterStatus, '') AS LETTERSTATUS, al.LetterDate AS LETTERDATE,
			p.AmountPromised AS FirstAmountPromised, p.PromiseFrequency AS FirstPromiseFrequency, p.Term AS FirstPromiseTerm, p.DatePromised, '' AS PROMISE,
			aa.LASTCONTACTDATE, aa.LASTCONTACTBY, aa.NOACTIVITYDAYS,
			ptp.PROMISETOPAY,
			pk.PROMISEKEPT,
			bp.PROMISEBROKEN,
			oc.OUTGOINGCALL,
			lastpromise.LASTPROMISEDATE, lastpromise.LASTPROMISEAMOUNT, lastpromise.LASTPROMISESTATUS, lastpromise.LASTPROMISESTATUSDESC,
			(CASE ISNULL(lg.GroupedAccountID, 0) WHEN 0 THEN 0 ELSE 1 END) AS IsGroupedAccount
	INTO	#AccountTemp
	FROM	Account	 a
	--Get latest account letter
	LEFT JOIN AccountLetter al ON al.ID = (SELECT MAX(ID)
											FROM AccountLetter
											WHERE AccountID = a.AccountID)
	LEFT JOIN DefineLetters l ON l.LetterID = al.LetterID
	--Get first promise, left join InformationTable to get PromiseFrequency
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised, p2.PromiseFrequency, p2.DatePromised,
					  CASE p2.Term
						WHEN 'd' THEN 'day(s)'
						WHEN 'w' THEN 'week(s)'
						WHEN 'm' THEN 'month(s)'
						WHEN 'y' THEN 'year(s)'
						ELSE p2.Term
					  END AS Term
				FROM AccountPromise p2 
				WHERE p2.Status IN (0, 2)
						AND p2.PromiseID = (SELECT MIN(PromiseID) FROM AccountPromise WHERE Status IN (0, 2) AND AccountID = p2.AccountID)) p ON p.AccountID = a.AccountID
	--Get last promise
	LEFT JOIN (SELECT p2.AccountID, p2.AmountPromised AS LASTPROMISEAMOUNT,
					p2.DatePromised AS LASTPROMISEDATE,
					p2.Status AS LASTPROMISESTATUS,
					CASE p2.Status
						WHEN 0 THEN 'Not Due'
						WHEN 1 THEN 'Paid On Time'
						WHEN 2 THEN 'Paid Late'
						WHEN 3 THEN 'Broken Promise'
						WHEN 4 THEN 'Canceled'
						ELSE ''
					END AS LASTPROMISESTATUSDESC
				FROM AccountPromise p2 
				WHERE p2.PromiseID IN 
						(	SELECT TOP 1 PromiseID
							FROM (	SELECT PromiseID, DatePromised
									FROM AccountPromise 
									WHERE AccountID = p2.AccountID -- 69
							) as temp
							ORDER BY DatePromised DESC
						)) lastpromise ON lastpromise.AccountID = a.AccountID
	--Get the latest AccountAction
	LEFT JOIN (SELECT aa2.AccountID , aa2.DateCompleted AS LASTCONTACTDATE, e.EmployeeName AS LASTCONTACTBY, DATEDIFF(day, aa2.DateCompleted, GETDATE()) AS NOACTIVITYDAYS
				FROM AccountActions aa2
				LEFT JOIN Employee e ON aa2.ResponsibleParty = e.EmployeeID
				WHERE aa2.RecordID =
				(SELECT TOP 1 aa3.RecordID
				FROM AccountActions aa3
				INNER JOIN AvailableActions ac ON aa3.ActionID = ac.ActionID
				WHERE ac.Category IN (1,2) AND ac.ProductivityID IN (1,2) AND aa2.AccountID = aa3.AccountID
				ORDER BY DateCompleted DESC)) aa ON aa.AccountID = a.AccountID
	--Number of Promise to pay
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISETOPAY FROM AccountPromise GROUP BY AccountID) ptp ON ptp.AccountID = a.AccountID
	--Number of kept Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEKEPT FROM AccountPromise WHERE Status IN (1,2) GROUP BY AccountID) pk ON pk.AccountID = a.AccountID
	--Number of broken Promise
	LEFT JOIN (SELECT AccountID, COUNT(PromiseID) AS PROMISEBROKEN FROM AccountPromise WHERE Status = 3 GROUP BY AccountID) bp ON bp.AccountID = a.AccountID
	--Number of Outgoing call
	LEFT JOIN (SELECT AccountID, COUNT(RecordID) AS OUTGOINGCALL
				FROM AccountActions
				WHERE ActionID IN (SELECT ActionID FROM [dbo].[AvailableActions] WHERE Category = 2)
				GROUP BY AccountID) oc ON oc.AccountID = a.AccountID
	--Check if account is GroupAccount
	LEFT JOIN Legal_Groups lg ON lg.GroupedAccountID = a.AccountID
	WHERE DebtorID = @DebtorID
		AND (NOT EXISTS(SELECT 1 FROM ClientListTable) OR a.ClientID IN (SELECT ClientID FROM ClientListTable))

	SELECT	ACCOUNT.AccountID, DebtorID, Account.EmployeeID, a.EmployeeName, ACCOUNT.ClientID, AgencyStatusID, SystemStatusID, ActionCodeID, OfficeID, MCode, CCode, InvoiceNumber, AccountType, AccountClass, QueueDate, DateOfService, SubmissionDate, LastClientTransactionDate, RoutinePayment, PaymentPlan, PatientName, BillAmount, BillBalance, BillOtherCharges, ClientPaysLegalFees, AccountForwarded, CreditReported, CreditReportedDate, Account.ClientPercent, Account.ClientOCPercent, SplitPayment, CurrentAction, CurrentActionDate, 
			MaintainOfficer, AccountAge, LastEditDate, LastEditBy, LastVerifyDate, AllocRuleID, AutoProcRuleID, LastExtractionDate, LastAllocationDate, LastAutoProcessDate, ExtractionRuleID, AccountForwardedTo, CurrencyCode, InterestRate, ActionEmployee, b.EmployeeName as ActionEmployeeName, LastPromiseBatch, CreditReportRequested, CreditReportRequestedBy, CreditReportRequestedOn, DelqHistory, BucketMovement, DPDMovement, BrokenCount, CurrentReason, CurrentNextAction, nextAction.CodeDesc AS CurrentNextActionDesc, CurrentCallResult, CampaignId,
			cast(BillAmount as decimal) + cast(BillBalance as decimal) as BALANCE,
			CreditReportRequestStatus, WriteOffDate, LastInterestDate, TempEmployeeID, OAManaged, InterfaceID, Delq_string, CARD_FILE_NO, ARREAR_PATH, BUCKET_TYPE, OLD_BUCKET_TYPE, CARD_TYPE, BRANCH_CODE, FORMULA, BANK_CODE, PAID, OtherAccountNo, TENOR, FORMULA_FLAG, MINIMUM_DUE, CURRENT_BKT_NUM, PREV_BKT_NUM,
			Long1, Long2, Long3, Long4, Long5, Long6, Long7, Long8, Long9, Long10, Long11, Long12, Long13, Long14, Long15, Money1, Money2, Money3, Money4, Money5, Money6, Money7, Money8, Money9, Money10, Money11, Money12, Money13, Money14, Money15, Money16, Money17, Money18, Money19, Money20, String1, String2, String3, String4, String5, String6, String7, String8, String9, String10, String11, String12, String13, String14, String15, String16, String17, String18, String19, String20,  String21, String22, String23,  String24,  String25, String26, String27, String28, String29, String30, String31, String32, String33, String34, String35, String36, String37, String38, String39, String40, String41, String42, String43, String44, String45, String46, String47, String48, String49, String50, ArrearsHistory, Money21, Money22, Money23, Money24, Money25, Money26, Money27, Money28, Money29, Money30, Date1, Date2, Date3, Date4, Date5, Date6, Date7, Date8, Additional1, Additional2, Additional3, Additional4, 
			Long16, Long17, Long18, Long19, productivecount, contactcount, nocontactcount, 
			Long20, Long21, Long22, Long23, Long24, Long25, Long26, Long27, Long28, Long29, Long30, Long31, Long32, Long33, Long34, Long35, Long36, Long37, Long38, Long39, Long40, Long41, Long42, Long43, Long44, Long45, Long46, Long47, Long48, Long49, Long50, 
			Money31, Money32, Money33, Money34, Money35, Money36, Money37, Money38, Money39, Money40, Money41, Money42, Money43, Money44, Money45, Money46, Money47, Money48, Money49, Money50, 
			Date9, Date10, Date11, Date12, Date13, Date14, Date15, Date16, Date17, Date18, Date19, Date20, Date21, Date22, Date23, Date24, Date25, Date26, Date27, Date28, Date29, Date30, Date31, Date32, Date33, Date34, Date35, Date36, Date37, Date38, Date39, Date40, Date41, Date42, Date43, Date44, Date45, Date46, Date47, Date48, Date49, Date50, 
			AccountText, ClientInformation.ClientName, --ClientInformation.ContactName, 
			AccountStatus.AgencyStatus, AccountStatus.ShortDesc, AccountStatus.LongDesc, AccountStatus.SystemStatus, AccountStatus.SupReq, AccountStatus.AcceptPartPay, AccountStatus.ReportToCreditBureau, AccountStatus.PIF_Status, AccountStatus.LettersAllowed, AccountStatus.LoadInDialer, AccountStatus.PrintOnReports, AccountStatus.LoadInQueue, AccountStatus.CalcInBalance, AccountStatus.ChargeInterest, AccountStatus.OverrideDateAdvancement, AccountStatus.SpecialProcessingStatus, AccountStatus.CreditReportAction
			--Only select NoLetterBefore, NoFeeBefore that < today
			, CASE WHEN DATEDIFF(day, GETDATE(), NoLetterBefore) > 1 THEN NULL ELSE NoLetterBefore END AS NoLetterBefore
			, CASE WHEN DATEDIFF(day, GETDATE(), NoFeeBefore) > 1 THEN NULL ELSE NoFeeBefore END AS NoFeeBefore
			, #AccountTemp.SENTBY, #AccountTemp.LETTERSTATUS, #AccountTemp.LETTERDATE
			, #AccountTemp.PROMISE, #AccountTemp.DatePromised, #AccountTemp.FirstAmountPromised, #AccountTemp.FirstPromiseFrequency, #AccountTemp.FirstPromiseTerm
			, #AccountTemp.LASTPROMISEDATE, #AccountTemp.LASTPROMISEAMOUNT, #AccountTemp.LASTPROMISESTATUS, #AccountTemp.LASTPROMISESTATUSDESC
			, #AccountTemp.LASTCONTACTDATE, #AccountTemp.LASTCONTACTBY, #AccountTemp.PROMISETOPAY, #AccountTemp.PROMISEKEPT, #AccountTemp.PROMISEBROKEN, #AccountTemp.OUTGOINGCALL, #AccountTemp.NOACTIVITYDAYS
			, ISNULL(Account.IsPending, 0) AS IsPending
			, #AccountTemp.IsGroupedAccount
	FROM	(((((Account	LEFT OUTER JOIN AccountOther ON Account.AccountID = AccountOther.AccountID)
			LEFT OUTER JOIN AccountMemo ON Account.AccountID = AccountMemo.AccountID)
			LEFT OUTER JOIN ClientInformation ON Account.ClientID = ClientInformation.ClientID)
			LEFT OUTER JOIN AccountStatus on Account.AgencyStatusID = AccountStatus.AgencyStatus)
			LEFT OUTER JOIN Employee a on Account.EmployeeID = a.EmployeeID)
			LEFT OUTER JOIN Employee b on Account.ActionEmployee = b.EmployeeID
			LEFT OUTER JOIN AccountCodeMaster nextAction on Account.CurrentNextAction = nextAction.CodeID,
			#AccountTemp 
	WHERE	Account.AccountID = #AccountTemp.AccountID
	
	SET NOCOUNT OFF;
END

GO
-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByQueueSStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_SystemStatus int,
	@AccountAge int = -1,
	@MCode int = -1,
	@CCode int = -1,
--	@IsPending bit = 0,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId as varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID <> 2'
--				+ '   AND ISNULL(a.IsPending,0) = '+CAST(@IsPending AS varchar(1))

	IF @v_SystemStatus = 0 
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'

	IF ((@v_SystemStatus = 1) or (@v_SystemStatus = 5))
		SET @cStmt=@cStmt+' AND s.SystemStatus = '+CAST(@v_SystemStatus AS varchar(9))+''

	IF @v_SystemStatus = 2
	BEGIN
		SET @cStmt=@cStmt+' AND s.SystemStatus in (1,5)'
		SET @cStmt=@cStmt+' AND convert(varchar(10),a.SubmissionDate,121)=convert(varchar(10),GetDate(),121)'+''
	END

	IF @v_SystemStatus = 6 --Pending account
		SET @cStmt=@cStmt+' AND a.IsPending = 1'
	
	IF @AccountAge <> -1
		SET @cStmt=@cStmt+' AND a.AccountAge = '+CAST(@AccountAge AS varchar(9))
	IF @MCode <> -1
		SET @cStmt=@cStmt+' AND a.MCode = '+CAST(@MCode AS varchar(9))
	IF @CCode <> -1
		SET @cStmt=@cStmt+' AND a.CCode = '+CAST(@CCode AS varchar(9))

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END

GO
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByQueueAStat] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@v_AgencyStatus int,
--	@IsPending bit = 0,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND (a.EmployeeID = '+CAST(@v_employeeId AS varchar(9))+' OR a.TempEmployeeID = '+CAST(@v_employeeId as varchar(9))+')'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID = '+CAST(@v_AgencyStatus AS varchar(9))
--				+ '   AND ISNULL(a.IsPending,0) = '+CAST(@IsPending AS varchar(1))


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END

GO
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_GetTickets] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@TicketClass int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
	SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Ticket t
	INNER JOIN TicketStatus s ON s.TicketStatusID = t.TicketStatus
	INNER JOIN Employee e ON e.EmployeeID = t.Requester
	INNER JOIN Employee f ON f.EmployeeID = t.AssignedTo
	INNER JOIN Account a ON a.AccountID = t.AccountID
	WHERE
		(((@TicketClass = 1) and (t.CurrentEmployeeID = @EmployeeID)) or ((@TicketClass = 0) and (t.Requester = @EmployeeID)))
		AND t.TicketStatus <> 9

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  t.TicketID) AS RowNumber,
			CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID) + '|' + CONVERT(varchar(10), t.TicketID) AS KeyField,
			t.TicketID AS [Ticket ID],
			e.EmployeeName AS [Requester],
			f.EmployeeName AS [Assign To],
			t.CurrentStage AS [Current Stage],
			t.TotalStage AS [Total Stage],
			t.RequestDate AS [Request Date],
			t.StartDate AS [Start Date],
			t.DueDate AS [Due Date],
			s.Description AS [Ticket Status],
			CASE t.Priority
				WHEN 0 THEN 'Low'
				WHEN 1 THEN 'Mediuem'
				WHEN 2 THEN 'High'
			END AS Priority
		--INTO #Temp
		FROM Ticket t
		INNER JOIN TicketStatus s ON s.TicketStatusID = t.TicketStatus
		INNER JOIN Employee e ON e.EmployeeID = t.Requester
		INNER JOIN Employee f ON f.EmployeeID = t.AssignedTo
		INNER JOIN Account a ON a.AccountID = t.AccountID
		WHERE
			(((@TicketClass = 1) and (t.CurrentEmployeeID = @EmployeeID)) or ((@TicketClass = 0) and (t.Requester = @EmployeeID)))
			AND t.TicketStatus <> 9
	)

	SELECT
		KeyField,
		[Ticket ID],
		[Requester],
		[Assign To],
		[Current Stage],
		[Total Stage],
		[Request Date],
		[Start Date],
		[Due Date],
		[Ticket Status],
		Priority
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount

END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByAllocQueue] 
	-- Add the parameters for the stored procedure here
	@v_EmployeeId int,
	@v_AllocRule int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	WHERE
		(a.EmployeeID = @v_EmployeeId OR a.TempEmployeeID = @v_EmployeeId)
		AND a.AllocRuleID = @v_AllocRule
		AND a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.QueueDate desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		WHERE
			(a.EmployeeID = @v_EmployeeId OR a.TempEmployeeID = @v_EmployeeId)
			AND a.AllocRuleID = @v_AllocRule
			AND a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number]
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go


-- Script is applied on version 1.9.23

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_QueueFuture] 
	-- Add the parameters for the stored procedure here
	@EmployeeID int,
	@Days int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	CREATE TABLE #Temp
	(
		RowNumber int IDENTITY(1,1),
		[KeyField] varchar(30),
		[QueueDate] char(10),
		[Account Number] varchar(50),
		[DPD] int,
		[Bucket] smallint,
		[Cycle] smallint,
		[Bill Amount] money,
		[Bill Balance] money,
		[Status] varchar(10),
		[Priority] int,
		[Assignment Type] char(1),
		[Name] varchar(200)
	)
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause VARCHAR(50)
	SET @orderByClause = ' ORDER BY a.QueueDate DESC'


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.EmployeeID = ' + CAST(@EmployeeID AS varchar(10))
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

	--Today|2|GE Today|0|Tomorrow|1|3 Days|3|5 Days|5
	if (@Days = 1) or (@Days = 3) or (@Days = 5)
	Begin
		SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) <= dateadd(day,' + CAST(@Days AS varchar(10)) + ', getdate())'
		SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) >= getdate()'
	End

	if @Days = 2
	Begin
		SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) = getdate()'
	End

	if @Days = 0
	Begin
		SET @cStmt = @cStmt + ' AND Isnull(a.QueueDate,Dateadd(day,-1,getdate())) >= getdate()'
	End


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_Queue_NoActivityInXDays] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lNumberOfDays int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			e.EmployeeName As [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()))
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go



-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 03, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_Queue_NoContactInXDays] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@lNumberOfDays int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @RowCount int
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
		AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()) and ActionID in (select ActionID from AvailableActions where productivityid = 3))

	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			e.EmployeeName As [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND (ISNULL(@EmpList, '') = '' OR a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ',')))
			AND a.AccountID Not in (Select AccountID From AccountActions Where DateCompleted>=DateAdd(d,@lNumberOfDays*-1,GetDate()) and ActionID in (select ActionID from AvailableActions where productivityid = 3))
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- =============================================
-- Author:		KhoaDang
-- =============================================
ALTER PROCEDURE [dbo].[CWX_GetEmployeeNextPoolAccount] 
	@v_currentLoginEmployeeId int,
	@v_employeeId int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt =  ' SELECT a.DebtorID, a.AccountID,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN Accountother o ON o.AccountID = a.AccountID'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND a.EmployeeID = '+CAST(@v_employeeId as varchar(9))
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '	  AND a.SystemStatusID in (1,5)'
				+ '	  AND a.PoolSelected = 0'

	--Step 4: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'
	
	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	--Step 5: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT top 1 DebtorID, AccountID, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name] INTO #PoolAccount '
				   + 'FROM AccountResults '
				   + @pagingWhereClause	
				   + ' DECLARE @AccountID int '
				   + ' DECLARE @DebtorID int '
				   + ' SELECT @AccountID=AccountID, @DebtorID=DebtorID FROM #PoolAccount '
				   + ' EXEC CWX_Account_UpdatePoolStatus @AccountID, @DebtorID, ' + STR(@v_currentLoginEmployeeId)
				   + ' SELECT (CONVERT(varchar(10), DebtorID) + ''|'' + CONVERT(varchar(10), AccountID)) AS KeyField, [QueueDate], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name] '
				   + ' FROM #PoolAccount '

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)

	--Step 6: Execute the main SQL command.	
	EXEC (@finalStmt)
		
	if (@RowCount > 1)
		RETURN 2

	RETURN @RowCount
END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralItemType] 
	@v_employeeId int,
	@ItemID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.CollateralType = @ItemID

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.CollateralType = @ItemID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.CollateralType = @ItemID

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.CollateralType = @ItemID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End

END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralByEmployee] 
	@v_employeeId int,
	@cEmployeeID int,
	@EmpList varchar(3000),
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.EmployeeID = @cEmployeeID 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.EmployeeID = @cEmployeeID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.EmployeeID = @cEmployeeID 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.EmployeeID = @cEmployeeID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 21, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralStage] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@cStageID int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.CollateralStage = @cStageID 


	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.CollateralStage = @cStageID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.CollateralStage = @cStageID 


	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			--m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		--INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.CollateralStage = @cStageID
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		--[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End


END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

ALTER PROCEDURE [dbo].[CWX_Account_SearchCollateralNextAction] 
	@v_employeeId int,
	@cNextAction int,
	@EmpList varchar(3000),
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND c.NextAction = @cNextAction 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND c.NextAction = @cNextAction
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Collateral c ON c.AccountID = a.AccountID 
    INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
	INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
	INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
	INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()
		AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
		AND c.NextAction = @cNextAction 

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY  a.QueueDate DESC) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc AS [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName) As [Name],
			m1.CodeDesc as [Type],
			m2.CodeDesc as [Stage],
			m3.CodeDesc as [Next Action],
			c.NextActionDate as [NextAction Date],
			e.EmployeeName as [By Whom]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Collateral c ON c.AccountID = a.AccountID 
		INNER JOIN AccountCodeMaster m1 ON m1.CodeID = c.CollateralType
		INNER JOIN AccountCodeMaster m2 ON m2.CodeID = c.CollateralStage
		INNER JOIN AccountCodeMaster m3 ON m3.CodeID = c.NextAction
		INNER JOIN Employee e ON e.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
			AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			AND c.NextAction = @cNextAction
	)

	SELECT
		KeyField,
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Type],
		[Stage],
		[Next Action],
		[NextAction Date],
		[By Whom]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
END

GO

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
go

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 04, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByPoolPending] 
	-- Add the parameters for the stored procedure here
	@v_employeeId int,
	@PoolID int,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause varchar(750)
	DECLARE @v_SortOrder varchar(700)
	EXEC CW_SORT_ORDER @v_SortOrder OUT
    IF @v_SortOrder='' 
		   SET @v_SortOrder = ' "QueueDate" DESC'

    Set @orderByClause = 'ORDER BY ' + @v_SortOrder


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '
	

	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber AS [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   p.SocialSecurityNumber AS [ID],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate<=GetDate()'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'
				+ '   AND s.SystemStatus in (1,5)'
--				+ '   AND convert(varchar(10),a.SubmissionDate,121)=convert(varchar(10),GetDate(),121)'
				+ '   AND a.OfficeID = '+CAST(@v_employeeId as varchar(9))
				+ '   AND a.EmployeeID = '+CAST(@PoolID as varchar(9))
				+ '   AND a.IsPending = 1'
				+ '	  AND a.PoolSelected = 1'

	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [ID], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

    SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)
	
	
	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END


GO

--------------------Start of ThanhNguyen-----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_CosigneeInformation_CheckPrimaryDebtor]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_CosigneeInformation_CheckPrimaryDebtor]
GO

-- =============================================
-- Author:		ThanhNguyen
-- Create date: 02-June-2009
-- Description:	Check whether the PersonID is the primary debtor
-- =============================================
CREATE PROCEDURE [dbo].[CWX_CosigneeInformation_CheckPrimaryDebtor] 
	@AccountID int,
	@PersonIDToCheck int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @PersonID int
	SELECT @PersonID = a.PersonID
	FROM
	(
		SELECT distinct d.PersonID as PersonID
		FROM CosigneeInformation c INNER JOIN DebtorInformation d ON c.DebtorID = d.DebtorID
		WHERE c.Bill = @AccountID
	) a
	if(@PersonID = @PersonIDToCheck) RETURN 1
	RETURN 0	
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Person_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Person_GetDynamicFields]    Script Date: 06/01/2009 15:08:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Thuy Nguyen
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an person
-- History:
--	[06-Mar-2009]	Thuy Nguyen		Init version.
--	[20-Mar-2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[10-Apr-2009]	Thanh Nguyen	Add parameter "@CMSEditable"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam		Rename parameter @PageNumber to @TabID
--									Rename parameter @Client to @ClientID
--									Remove parameters @PageSize, @PageIndex
--									Change from Page view to Tab view
--  [02-June-2009]	ThanhNguyen		Remove @ClientID from parameter list. Because base on Issue 68: DebtorInformation And PersonInformation don't have ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
	@PersonID int,
	@TabID int = 1,	
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc],
			b.[DataType],
			b.[MaxLength],
			a.[Editable],
			a.[GroupID],
			a.[GroupDesc], 
			a.[DisplayOrder],			
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], CASE WHEN @CMSEditable = 1 THEN [CMSEdit] ELSE [Editable] END as [Editable],
				[GroupID], [GroupDesc], [DisplayOrder], [RangeID], [DropDown], [Mandatory]
		FROM	CWX_PersonInformation_Dict
		WHERE	Displayed = 1 AND TabID = @TabID
				AND (@CMSEditable = 0 OR (@CMSEditable = 1 AND [CMSEdit] = 1))				
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'PersonInformation' and [Type]='U')			
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'PersonID, LastName, FirstName, MiddleName, PString1'
	
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM PersonInformation WHERE PersonID = ' + Cast(@PersonID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup

END

------------------------[CWX_Collateral_Dict]------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_Dict_NEW]') AND type in (N'U'))
DROP TABLE [CWX_Collateral_Dict_NEW]
GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT

BEGIN TRANSACTION
GO
CREATE TABLE [dbo].[CWX_Collateral_Dict_NEW](
	[FieldName] [nvarchar](50) NULL,
	[FieldDesc] [nvarchar](100) NULL,
	[Displayed] [bit] NULL,
	[Editable] [bit] NULL,
	[GroupID] [int] NULL,
	[GroupDesc] [nvarchar](50) NULL,
	[TabID] [int] NULL  DEFAULT ((1)),
	[TabDesc] [nvarchar](30) NULL,
	[DisplayOrder] [int] NULL,
	[DropDown] [int] NULL DEFAULT ((0)),
	[RangeID] [tinyint] NULL DEFAULT ((0)),
	[Mandatory] [bit] NULL  DEFAULT ((0)),
	[ClientID] [int] NULL,
	[CollateralTypeID] [int] NULL
) ON [PRIMARY]

GO

INSERT INTO [dbo].[CWX_Collateral_Dict_NEW]
SELECT FieldName, FieldDesc, Displayed, Editable,GroupID, GroupDesc, TabID,
		TabDesc, DisplayOrder, [DropDown], [RangeID], [Mandatory], [ClientID], [CollateralTypeID]
FROM [dbo].[CWX_Collateral_Dict]
GO

DROP TABLE dbo.CWX_Collateral_Dict
GO

EXECUTE sp_rename N'dbo.CWX_Collateral_Dict_NEW', N'CWX_Collateral_Dict', 'OBJECT' 
GO
COMMIT
GO
--------------------------------------------[CWX_AccountInformation_Dict]---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_AccountInformation_Dict_NEW]') AND type in (N'U'))
DROP TABLE [CWX_AccountInformation_Dict_NEW]
GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT

BEGIN TRANSACTION
GO
CREATE TABLE [dbo].[CWX_AccountInformation_Dict_NEW](
	[FieldName] [nvarchar](50) NULL,
	[FieldDesc] [nvarchar](100) NULL,
	[Displayed] [bit] NULL,
	[Editable] [bit] NULL,
	[GroupID] [int] NULL,
	[GroupDesc] [nvarchar](50) NULL,
	[TabID] [int] NULL  DEFAULT ((1)),
	[TabDesc] [nvarchar](30) NULL,
	[DisplayOrder] [int] NULL,
	[DropDown] [int] NULL  DEFAULT ((0)),
	[RangeID] [tinyint] NULL DEFAULT ((0)),
	[Mandatory] [bit] NULL  DEFAULT ((0)),
	[ClientID] [int] NULL, 
	[TableID] [int] NULL,
	[CMSEdit] [bit] NULL
) ON [PRIMARY]

INSERT INTO [dbo].[CWX_AccountInformation_Dict_NEW] ([FieldName], [FieldDesc], [Displayed], Editable,GroupID, GroupDesc, TabID,
		TabDesc, DisplayOrder, [DropDown], [RangeID], [Mandatory], [ClientID], [TableID],[CMSEdit])

SELECT [FieldName], [FieldDesc], [Displayed], Editable,GroupID, GroupDesc, TabID,
		TabDesc, DisplayOrder, [DropDown], [RangeID], [Mandatory], [ClientID], [TableID],[CMSEdit]
FROM [dbo].[CWX_AccountInformation_Dict]
GO

DROP TABLE dbo.CWX_AccountInformation_Dict
GO

EXECUTE sp_rename N'dbo.CWX_AccountInformation_Dict_NEW', N'CWX_AccountInformation_Dict', 'OBJECT' 
GO
COMMIT
GO

--------------[CWX_ClientInformation_Dict]--------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientInformation_Dict_NEW]') AND type in (N'U'))
DROP TABLE [CWX_ClientInformation_Dict_NEW]
GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT

BEGIN TRANSACTION
GO
CREATE TABLE [dbo].[CWX_ClientInformation_Dict_NEW](
	[FieldName] [nvarchar](50) NULL,
	[FieldDesc] [nvarchar](100) NULL,
	[Displayed] [bit] NULL,
	[Editable] [bit] NULL,
	[GroupID] [int] NULL,
	[GroupDesc] [nvarchar](50) NULL,
	[TabID] [int] NULL DEFAULT ((1)),
	[TabDesc] [nvarchar](30) NULL,
	[DisplayOrder] [int] NULL,
	[DropDown] [int] NULL  DEFAULT ((0)),
	[RangeID] [tinyint] NULL DEFAULT ((0)),
	[Mandatory] [bit] NULL DEFAULT ((0)),
	[ClientID] [int] NULL	
) ON [PRIMARY]
GO

INSERT INTO [dbo].[CWX_ClientInformation_Dict_NEW] ([FieldName], [FieldDesc], [Displayed], Editable,GroupID, GroupDesc, TabID,
		TabDesc, DisplayOrder, [DropDown], [RangeID], [Mandatory], [ClientID])

SELECT [FieldName], [FieldDesc], [Displayed], Editable,GroupID, GroupDesc, TabID,
		TabDesc, DisplayOrder, [DropDown], [RangeID], [Mandatory], [ClientID]
FROM [dbo].[CWX_ClientInformation_Dict]
GO

DROP TABLE dbo.[CWX_ClientInformation_Dict]
GO

EXECUTE sp_rename N'dbo.CWX_ClientInformation_Dict_NEW', N'CWX_ClientInformation_Dict', 'OBJECT' 
GO
COMMIT
GO


-----------------------[CWX_PersonInformation_Dict]---------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonInformation_Dict_NEW]') AND type in (N'U'))
DROP TABLE [CWX_PersonInformation_Dict_NEW]
GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT

BEGIN TRANSACTION
GO
CREATE TABLE [dbo].[CWX_PersonInformation_Dict_NEW](
	[FieldName] [nvarchar](50) NULL,
	[FieldDesc] [nvarchar](100) NULL,
	[Displayed] [bit] NULL,
	[Editable] [bit] NULL,
	[GroupID] [int] NULL,
	[GroupDesc] [nvarchar](50) NULL,
	[TabID] [int] NULL DEFAULT ((1)),
	[TabDesc] [nvarchar](30) NULL,
	[DisplayOrder] [int] NULL,
	[DropDown] [int] NULL  DEFAULT ((0)),
	[RangeID] [tinyint] NULL DEFAULT ((0)),
	[Mandatory] [bit] NULL  DEFAULT ((0)),
	[CMSEdit] [bit] NULL
) ON [PRIMARY]
GO

INSERT INTO [dbo].[CWX_PersonInformation_Dict_NEW] ([FieldName], [FieldDesc], [Displayed], Editable,GroupID, GroupDesc, TabID,
		TabDesc, DisplayOrder, [DropDown], [RangeID], [Mandatory], [CMSEdit])

SELECT [FieldName], [FieldDesc], [Displayed], Editable,GroupID, GroupDesc, TabID,
		TabDesc, DisplayOrder, [DropDown], [RangeID], [Mandatory], [CMSEdit]
FROM [dbo].CWX_PersonInformation_Dict
GO

DROP TABLE dbo.CWX_PersonInformation_Dict
GO

EXECUTE sp_rename N'dbo.CWX_PersonInformation_Dict_NEW', N'CWX_PersonInformation_Dict', 'OBJECT' 
GO
COMMIT
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_PersonInformation_GetAllTabs]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_PersonInformation_GetAllTabs]
GO

/****** Object:  StoredProcedure [dbo].[CWX_PersonInformation_GetAllTabs]    Script Date: 06/03/2009 16:45:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
--	Author:			Minh Dam
--	Create date:	27 Apr 2009
--	Description:	Get all tabs for account information
--	[03-06-2009]	ThanhNguyen		Delete ClientID from Parameter base on issues 68
-- =============================================
CREATE PROCEDURE [dbo].[CWX_PersonInformation_GetAllTabs]
	-- Add the parameters for the stored procedure here	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @TabID int
	DECLARE curTab CURSOR FOR
		SELECT DISTINCT TabID
		FROM CWX_PersonInformation_Dict		
		ORDER BY TabID

	CREATE TABLE #temp(TabID int, TabDesc nvarchar(30))

	OPEN curTab
	FETCH NEXT FROM curTab INTO @TabID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		INSERT INTO #temp
			SELECT TOP 1 TabID, ISNULL(TabDesc,'') FROM CWX_PersonInformation_Dict WHERE TabID = @TabID
		FETCH NEXT FROM curTab INTO @TabID
	END

	CLOSE curTab
	DEALLOCATE curTab

	SELECT * FROM #temp
	DROP TABLE #temp
END
GO

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '1' AND [Description] = 'Age' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('1','Age','S')	
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '2' AND [Description] = 'List Amount' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('2','List Amount','S')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '3' AND [Description] = 'Payment Amount' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('3','Payment Amount ','S')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '4' AND [Description] = 'Paid To Date' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('4','Paid To Date','S')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '5' AND [Description] = 'Payment Days from Listing' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('5','Payment Days from Listing','S')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '6' AND [Description] = 'Payment Days from Delinquent' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('6','Payment Days from Delinquent','S')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '7' AND [Description] = 'Payment Days from Charged' AND [Type] = 'S'))
BEGIN
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('7','Payment Days from Charged','S')
END

IF(NOT EXISTS(	SELECT * FROM [CWX_ClientCommPlan]
				WHERE [Code] = '8' AND [Description] = 'Remaining Balance' AND [Type] = 'S'))
BEGIN	
	INSERT INTO [dbo].[CWX_ClientCommPlan]([Code],[Description],[Type])
	VALUES('8','Remaining Balance','S')
END

GO
--------------------End of ThanhNguyen-----------------

-------------------Phuong Le--------------------------
UPDATE QueryMaster  SET SQL2 = 'EXEC SearchAccountByInvoice %1,%2,%FilterByClient' WHERE SQL2= 'EXEC SearchAccountByInvoice %1,%2'
UPDATE QueryMaster  SET SQL2 = 'EXEC CWX_Account_QueueByAmtRange %1, %2,%FilterByClient' WHERE SQL2= 'EXEC CWX_Account_QueueByAmtRange %1, %2'
UPDATE QueryMaster  SET SQL2 = 'EXEC SearchAccountByBill  %1,%2,%FilterByClient' WHERE SQL2= 'EXEC SearchAccountByBill  %1,%2'
UPDATE QueryMaster  SET SQL2 = 'EXEC CWX_Account_SearchDebtorByName %1, %2,%FilterByClient' WHERE SQL2= 'EXEC CWX_Account_SearchDebtorByName %1, %2'
UPDATE QueryMaster  SET SQL2 = 'EXEC SearchDebtorByPhone %1,%2,%FilterByClient' WHERE SQL2= 'EXEC SearchDebtorByPhone %1,%2'
UPDATE QueryMaster  SET SQL2 = 'EXEC SearchAccountByMobile %1,%2,%FilterByClient' WHERE SQL2= 'EXEC SearchAccountByMobile %1,%2'
UPDATE QueryMaster  SET SQL2 = 'EXEC SearchByofficePhone %1,%2,%FilterByClient' WHERE SQL2= 'EXEC SearchByofficePhone %1,%2'
UPDATE QueryMaster  SET SQL2 = 'EXEC CWX_Account_SearchByEmployeeName %1, %2,%FilterByClient' WHERE SQL2= 'EXEC CWX_Account_SearchByEmployeeName %1, %2'
UPDATE QueryMaster  SET SQL2 = 'EXEC SearchByLegalGroupCode %1, %2,%FilterByClient' WHERE SQL2= 'EXEC SearchByLegalGroupCode %1, %2'
UPDATE QueryMaster  SET SQL2 = 'EXEC CWX_Account_SearchByLegalEmployee %1, %2,%FilterByClient' WHERE SQL2= 'EXEC CWX_Account_SearchByLegalEmployee %1, %2'
UPDATE QueryMaster  SET SQL2 = 'EXEC CWX_Account_SearchByLegalForward  %1, %2,%FilterByClient' WHERE SQL2= 'EXEC CWX_Account_SearchByLegalForward  %1, %2'
UPDATE QueryMaster  SET SQL2 = 'EXEC CWX_Account_SearchByLegalAgent  %1, %2,%FilterByClient' WHERE SQL2= 'EXEC CWX_Account_SearchByLegalAgent  %1, %2'


GO

ALTER   PROCEDURE [dbo].[SearchAccountByInvoice]
	@Invoice char(50),
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name],'
	SET @cStmt=@cStmt+'a.DebtorID As [DebtorID]'	
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where a.InvoiceNumber = '+''''+Cast(@Invoice As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	
	if @EmpList <> ''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex(',', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'
		end
		else
		begin
			SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
		end
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END

GO

-- =============================================
-- Author:		LongNguyen
-- Create date: Apr 09, 2008
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_QueueByAmtRange] 
	-- Add the parameters for the stored procedure here
	@v_Range int,
	@EmpList varchar(3000),	
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Step 1: Populate the ORDER BY clause.	
	DECLARE @orderByClause VARCHAR(50)
	SET @orderByClause = ' ORDER BY a.QueueDate DESC'


    --Step 2: Populate the begin and end indices.
	DECLARE @pagingWhereClause varchar(200)
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
		SET @pagingWhereClause = 'WHERE RowIndex BETWEEN ' + CAST(@BeginIndex as varchar(10)) + ' AND ' + CAST(@EndIndex as varchar(10))
	END
	ELSE
		SET @pagingWhereClause = ' '


	--Step 3: Populate the main SELECT command.
    DECLARE @cStmt varchar(8000)
	SET @cStmt = ' SELECT'
				+ '   (CONVERT(varchar(10), a.DebtorID) + ''|'' + CONVERT(varchar(10), a.AccountID)) AS KeyField,'
				+ '   a.QueueDate AS [QueueDate],'
				+ '   a.InvoiceNumber as [Account Number],'
				+ '   a.AccountAge AS [DPD],'
				+ '   a.MCode AS [Bucket],'
				+ '   a.CCode AS [Cycle],'
				+ '   a.BillAmount AS [Bill Amount],'
				+ '   a.BillBalance AS [Bill Balance],'
				+ '   s.ShortDesc AS [Status],'
				+ '   s.SortPriority AS [Priority],'
				+ '   a.AssignmentType AS [Assignment Type],'
				+ '   (rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName)) AS [Name]'
				+ ' FROM Account a'
				+ ' INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID'
				+ ' INNER JOIN PersonInformation p ON p.PersonID = d.PersonID'
				+ ' INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID'
				+ ' WHERE'
				+ '   a.QueueDate <= getDate()'
				+ '   AND a.DebtorID <> 0'
				+ '   AND a.AgencyStatusID <> 2'

	if ((@EmpList <> '') and (@EmpList <> 'Null'))
	Begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex(',', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'
		end
		else
		begin
			SET @cStmt=@cStmt+' AND a.EmployeeID in (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(''' + @EmpList + ''',' + '''' + ',' + '''' + '))'
		end				
	End

	if @v_Range = 1
	Begin
		SET @cStmt = @cStmt +'   AND a.BillBalance < 10000'
	End

	if @v_Range = 2
	Begin
		SET @cStmt = @cStmt +'  AND a.BillBalance >= 10000'
		SET @cStmt = @cStmt +'  AND a.BillBalance < 25000'
	End

	if @v_Range = 3
	Begin
		SET @cStmt = @cStmt +'	AND a.BillBalance >= 25000'
		SET @cStmt = @cStmt +'	AND a.BillBalance < 50000'		
	End

	if @v_Range = 4
	Begin
		SET @cStmt = @cStmt +'	AND a.BillBalance >= 50000'
		SET @cStmt = @cStmt +'	AND a.BillBalance < 150000'		
	End

	if @v_Range = 5
	Begin
		SET @cStmt = @cStmt +'	AND a.BillBalance >= 150000'
	End


	--Step 4: Populate the final SQL command using ROW_NUMBER in junction with CTE.
    DECLARE @finalStmt varchar(8000)
	SET @finalStmt = 'WITH AccountResults AS '
				   + '( '
				   + '  SELECT *, ROW_NUMBER() OVER (' + @orderByClause + ') as RowIndex '
				   + '  FROM ( '	
				   + '          {0}'
				   + '    ) A '
				   + ') '
				   + '   '
				   + 'SELECT KeyField, [QueueDate], [Account Number], [DPD], [Bucket], [Cycle], [Bill Amount], [Bill Balance], [Status], [Priority], [Assignment Type], [Name]'
				   + 'FROM AccountResults '
				   + @pagingWhereClause	

	SET @finalStmt = REPLACE(@finalStmt, '{0}', @cStmt)


	--Step 5: Execute the main SQL command.	
	EXEC (@finalStmt)


	--Step 6: Calculate the row count so that the client code can populate the number of pages.
	DECLARE @rowCountStmt nvarchar(4000)
	SET @rowCountStmt = 'SELECT @RowCountOut=count(*) FROM ( {0} ) A'
    SET @rowCountStmt = REPLACE(@rowCountStmt, '{0}', @cStmt)

	DECLARE @ParmDefinition NVARCHAR(50);
	SET @ParmDefinition = '@RowCountOut int OUTPUT'

	DECLARE @RowCount int
	EXEC sp_executesql @rowCountStmt, @ParmDefinition, @RowCountOut=@RowCount OUTPUT

	RETURN @RowCount
END

GO

ALTER PROCEDURE [dbo].[SearchAccountByBill]
	@AcctID INT,
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where a.AccountID = '+Cast(@AcctID As Char(9))
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	if @EmpList <> ''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex(',', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'
		end
		else
		begin
			SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
		end		
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END

GO

ALTER PROCEDURE [dbo].[CWX_Account_SearchDebtorByName] 
	@DebtorName varchar(100),
	@EmpList varchar(3000),
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

IF @PageSize > 0
BEGIN
	SET @BeginIndex = @PageIndex * @PageSize + 1
	SET @EndIndex = (@PageIndex + 1) * @PageSize
END
ELSE
BEGIN
	SET @BeginIndex = 1
	SET @EndIndex = @RowCount
END

IF LEN(ISNULL(@EmpList,'')) = 0 --search full
	Begin
		SELECT
			@RowCount = COUNT(a.AccountID)
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		WHERE
			a.DebtorID <> 0
			AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')		

		WITH Temp
		AS
		(
			SELECT
				ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
				(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
				a.QueueDate AS [QueueDate],
				a.InvoiceNumber as [Account Number],
				a.AccountAge AS [DPD],
				a.MCode AS [Bucket],
				a.CCode AS [Cycle],
				a.BillAmount AS [Bill Amount],
				a.BillBalance AS [Bill Balance],
				s.ShortDesc as [Status],
				s.SortPriority AS [Priority],
				a.AssignmentType AS [Assignment Type],
				p.SocialSecurityNumber AS [ID],
				rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
			FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			WHERE
				a.DebtorID <> 0
				AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
		)

		SELECT
			[KeyField],
			[QueueDate],
			[Account Number],
			[DPD],
			[Bucket],
			[Cycle],
			[Bill Amount],
			[Bill Balance],
			[Status],
			[Priority],
			[Assignment Type],
			[ID],
			[Name]
		FROM Temp
		WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

		RETURN @RowCount
	End
Else
	Begin
		if @FilterByClient = 1 --search by client
			Begin
				DECLARE @employeeID varchar(50)
				DECLARE @index int

				SET @index = charindex(',', @EmpList)
				SET @employeeID = substring(@EmpList, 1, @index -1)
				SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

				SELECT
					@RowCount = COUNT(a.AccountID)
				FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				WHERE
					a.DebtorID <> 0
					AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
					AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

				WITH Temp
				AS
				(
					SELECT
						ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
						(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
						a.QueueDate AS [QueueDate],
						a.InvoiceNumber as [Account Number],
						a.AccountAge AS [DPD],
						a.MCode AS [Bucket],
						a.CCode AS [Cycle],
						a.BillAmount AS [Bill Amount],
						a.BillBalance AS [Bill Balance],
						s.ShortDesc as [Status],
						s.SortPriority AS [Priority],
						a.AssignmentType AS [Assignment Type],
						p.SocialSecurityNumber AS [ID],
						rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
					FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					WHERE
						a.DebtorID <> 0
						AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
						AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
				)

				SELECT
					[KeyField],
					[QueueDate],
					[Account Number],
					[DPD],
					[Bucket],
					[Cycle],
					[Bill Amount],
					[Bill Balance],
					[Status],
					[Priority],
					[Assignment Type],
					[ID],
					[Name]
				FROM Temp
				WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

				RETURN @RowCount
			End
		Else --search by emplist
			Begin
				SELECT
					@RowCount = COUNT(a.AccountID)
				FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				WHERE
					a.DebtorID <> 0
					AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
					AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))		

				WITH Temp
				AS
				(
					SELECT
						ROW_NUMBER() OVER (ORDER BY  (RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName))) AS RowNumber,
						(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as KeyField,
						a.QueueDate AS [QueueDate],
						a.InvoiceNumber as [Account Number],
						a.AccountAge AS [DPD],
						a.MCode AS [Bucket],
						a.CCode AS [Cycle],
						a.BillAmount AS [Bill Amount],
						a.BillBalance AS [Bill Balance],
						s.ShortDesc as [Status],
						s.SortPriority AS [Priority],
						a.AssignmentType AS [Assignment Type],
						p.SocialSecurityNumber AS [ID],
						rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
					FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					WHERE
						a.DebtorID <> 0
						AND UPPER(RTRIM(p.FirstName) + ' ' + RTRIM(p.MiddleName) + ' ' + RTRIM(p.LastName)) LIKE ('%' + UPPER(@DebtorName) + '%')
						AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
				)

				SELECT
					[KeyField],
					[QueueDate],
					[Account Number],
					[DPD],
					[Bucket],
					[Cycle],
					[Bill Amount],
					[Bill Balance],
					[Status],
					[Priority],
					[Assignment Type],
					[ID],
					[Name]
				FROM Temp
				WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

				RETURN @RowCount
			End		
	End
END

GO

/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchDebtorByPhone]
	@PhoneNumber char(25),
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where p.HomePhone = '+''''+Cast(@PhoneNumber As Char(25))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'

	if @EmpList <> ''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex(',', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'
		end
		else
		begin
			SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
		end		
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END

GO

/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchAccountByMobile]
	@MobilePhone char(50),
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
SET @cStmt=@cStmt+'a.CCode as [Cycle],'
SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where p.MobilPhone = '+''''+Cast(@MobilePhone As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	if @EmpList <> ''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex(',', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'
		end
		else
		begin
			SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
		end		
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END

GO

/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchByofficePhone]
	@PhoneNumber char(50),
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s'
SET @cStmt=@cStmt+' where p.EmploymentPhone = '+''''+Cast(@PhoneNumber As Char(50))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID'
	if @EmpList <> ''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex(',', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'
		end
		else
		begin
			SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
		end		
	end
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
Exec SP_ExecuteSQL @cStmt
END

GO

-- =============================================
-- Author:		KhoaDang
ALTER PROCEDURE [dbo].[SearchByLegalGroupCode]
	@GroupCode varchar(20),
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN
DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.QueueDate as [QueueDate],'
	SET @cStmt=@cStmt+'a.InvoiceNumber as [Account Number],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'a.MCode AS [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'s.ShortDesc as [Status],'
	SET @cStmt=@cStmt+'s.SortPriority AS [Priority],'
	SET @cStmt=@cStmt+'a.AssignmentType AS [Assignment Type],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p,'
	SET @cStmt=@cStmt+'AccountStatus s,'
	SET @cStmt=@cStmt+'Legal_Groups g'
	SET @cStmt=@cStmt+' where a.AccountID = g.GroupedAccountID'
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and p.PersonID = d.PersonID'
	SET @cStmt=@cStmt+' and s.AgencyStatus = a.AgencyStatusID and g.Code=' + '''' + RTRIM(@GroupCode) + ''''
	if @EmpList <> ''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex(',', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'
		end
		else
		begin
			SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
		end		
	end
	
	SET @cStmt=@cStmt+' and a.DebtorID <> 0'
	Exec SP_ExecuteSQL @cStmt
END

GO

ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalEmployee] 
	@v_employeeId int,
	@EmpList varchar(3000),
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
	WHERE
		a.DebtorID <> 0
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()	

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
		WHERE
			a.DebtorID <> 0
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
	IF @FilterByClient = 1 --search by client
		Begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex(',', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)
			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
				INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
			WHERE
				a.DebtorID <> 0
				AND a.AgencyStatusID <> 2
				AND a.QueueDate <= GETDATE()
				AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
				FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
					INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
				WHERE
					a.DebtorID <> 0
					AND a.AgencyStatusID <> 2
					AND a.QueueDate <= GETDATE()
					AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End
	Else
		Begin
			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
				INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
			WHERE
				a.DebtorID <> 0
				AND a.AgencyStatusID <> 2
				AND a.QueueDate <= GETDATE()
				AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))	

			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
				FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
					INNER JOIN Legal_Groups lg ON lg.EmployeeID = @v_employeeId
				WHERE
					a.DebtorID <> 0
					AND a.AgencyStatusID <> 2
					AND a.QueueDate <= GETDATE()
					AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End    
End

END

GO

ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalForward] 
	@SolicitorID int,
	@EmpList varchar(3000),
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
		INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
	WHERE
		a.DebtorID <> 0
        And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()	

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
			INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
		WHERE
			a.DebtorID <> 0
			And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
	if @FilterByClient = 1 --search by client
		Begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex(',', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)
			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
				INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
				INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
			WHERE
				a.DebtorID <> 0
				And lg.GroupID = ld.GroupID
				AND a.AgencyStatusID <> 2
				AND a.QueueDate <= GETDATE()
				AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
				FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
					INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
					INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
				WHERE
					a.DebtorID <> 0
					And lg.GroupID = ld.GroupID
					AND a.AgencyStatusID <> 2
					AND a.QueueDate <= GETDATE()
					AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End
	Else
		Begin
			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
				INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
				INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
			WHERE
				a.DebtorID <> 0
				And lg.GroupID = ld.GroupID
				AND a.AgencyStatusID <> 2
				AND a.QueueDate <= GETDATE()
				AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))	

			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
				FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
					INNER JOIN Legal_Groups lg ON lg.SolicitorID = @SolicitorID
					INNER JOIN Legal_Solicitors ls ON ls.Status = 'A' and ls.SolicitorID = lg.SolicitorID
				WHERE
					a.DebtorID <> 0
					And lg.GroupID = ld.GroupID
					AND a.AgencyStatusID <> 2
					AND a.QueueDate <= GETDATE()
					AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End    
End

END

GO


-- =============================================
-- Description:	
-- History:
--	2008/04/21	[Sathya]		Init version.
--	2008/08/14	[Binh Truong]	la.Status = 'A'  >>>  la.Status <> 'R'
--	2008/09/25	[Sathya]		la.Status <> 'R'  >>>  la.Status = 'A'
--								Add criteria lg.GroupID = ld.GroupID
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Account_SearchByLegalAgent] 
	@AgentId int,
	@EmpList varchar(3000),
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int

	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
		INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
		INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
	WHERE
		a.DebtorID <> 0
		And lg.GroupID = ld.GroupID
		AND a.AgencyStatusID <> 2
		AND a.QueueDate <= GETDATE()	

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
		FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
			INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
			INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
		WHERE
			a.DebtorID <> 0
            And lg.GroupID = ld.GroupID
			AND a.AgencyStatusID <> 2
			AND a.QueueDate <= GETDATE()
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
	if @FilterByClient = 1 --search by client
		Begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex(',', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)
			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
				INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
				INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
			WHERE
				a.DebtorID <> 0
				And lg.GroupID = ld.GroupID
				AND a.AgencyStatusID <> 2
				AND a.QueueDate <= GETDATE()
				AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
			
			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
				FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
					INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
					INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
				WHERE
					a.DebtorID <> 0
					And lg.GroupID = ld.GroupID
					AND a.AgencyStatusID <> 2
					AND a.QueueDate <= GETDATE()
					AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End
	Else
		Begin
			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
				INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
				INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
			WHERE
				a.DebtorID <> 0
				And lg.GroupID = ld.GroupID
				AND a.AgencyStatusID <> 2
				AND a.QueueDate <= GETDATE()
				AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			
			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name]
				FROM Account a
					INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
					INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
					INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
					INNER JOIN Legal_GroupDebts ld ON ld.AccountID = a.AccountID
					INNER JOIN Legal_Groups lg ON lg.AgentID = @AgentId
					INNER JOIN Legal_Agents la ON la.Status = 'A' and la.AgentID = lg.AgentID
				WHERE
					a.DebtorID <> 0
					And lg.GroupID = ld.GroupID
					AND a.AgencyStatusID <> 2
					AND a.QueueDate <= GETDATE()
					AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End    
End

END
GO

ALTER PROCEDURE [dbo].[CWX_Account_SearchByEmployeeName] 
	@EmployeeName varchar(100),
	@EmpList varchar(3000),
	@FilterByClient bit,
	@PageSize int = 0,
	@PageIndex int = 0
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @RowCount int
	DECLARE @BeginIndex int
	DECLARE @EndIndex int
	
	IF @PageSize > 0
	BEGIN
		SET @BeginIndex = @PageIndex * @PageSize + 1
		SET @EndIndex = (@PageIndex + 1) * @PageSize
	END
	ELSE
	BEGIN
		SET @BeginIndex = 1
		SET @EndIndex = @RowCount
	END

IF LEN(ISNULL(@EmpList,'')) = 0
Begin
    SELECT
		@RowCount = COUNT(a.AccountID)
	FROM Account a
	INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
	INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
	INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
	INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
	INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
	WHERE
		a.QueueDate <= GETDATE()
		AND a.DebtorID <> 0
		AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')	

	WITH Temp
	AS
	(
		SELECT
			ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
			(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
			a.QueueDate AS [QueueDate],
			a.InvoiceNumber as [Account Number],
			a.AccountAge AS [DPD],
			a.MCode AS [Bucket],
			a.CCode AS [Cycle],
			a.BillAmount AS [Bill Amount],
			a.BillBalance AS [Bill Balance],
			s.ShortDesc as [Status],
			s.SortPriority AS [Priority],
			a.AssignmentType AS [Assignment Type],
			rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
			g.EmployeeName AS [Employee Name]
		FROM Account a
		INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
		INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
		INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
		INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
		INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID 
		WHERE
			a.QueueDate <= GETDATE()
			AND a.DebtorID <> 0
			AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
	)

	SELECT
		[KeyField],
		[QueueDate],
		[Account Number],
		[DPD],
		[Bucket],
		[Cycle],
		[Bill Amount],
		[Bill Balance],
		[Status],
		[Priority],
		[Assignment Type],
		[Name],
		[Employee Name]
	FROM Temp
	WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

	RETURN @RowCount
End
Else
Begin
	if @FilterByClient = 1 --search by client
		Begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex(',', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)
			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)

			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
			INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
			WHERE
				a.QueueDate <= GETDATE()
				AND a.DebtorID <> 0
				AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
				AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))

			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
					g.EmployeeName AS [Employee Name]
				FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
				INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID 
				WHERE
					a.QueueDate <= GETDATE()
					AND a.DebtorID <> 0
					AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
					AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type],
				[Name],
				[Employee Name]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End
	Else
		Begin
			SELECT
				@RowCount = COUNT(a.AccountID)
			FROM Account a
			INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
			INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
			INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
			INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
			INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID --Need to ask Sathya: should a.TempEmployeeID = a.EmployeeID
			WHERE
				a.QueueDate <= GETDATE()
				AND a.DebtorID <> 0
				AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
				AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))	

			WITH Temp
			AS
			(
				SELECT
					ROW_NUMBER() OVER (ORDER BY a.EmployeeID desc) AS RowNumber,
					(CONVERT(varchar(10), a.DebtorID) + '|' + CONVERT(varchar(10), a.AccountID)) as [KeyField],
					a.QueueDate AS [QueueDate],
					a.InvoiceNumber as [Account Number],
					a.AccountAge AS [DPD],
					a.MCode AS [Bucket],
					a.CCode AS [Cycle],
					a.BillAmount AS [Bill Amount],
					a.BillBalance AS [Bill Balance],
					s.ShortDesc as [Status],
					s.SortPriority AS [Priority],
					a.AssignmentType AS [Assignment Type],
					rtrim(p.FirstName) + rtrim(p.MiddleName) + rtrim(p.LastName) AS [Name],
					g.EmployeeName AS [Employee Name]
				FROM Account a
				INNER JOIN DebtorInformation d ON d.DebtorID = a.DebtorID
				INNER JOIN PersonInformation p ON p.PersonID = d.PersonID
				INNER JOIN AccountStatus s ON s.AgencyStatus = a.AgencyStatusID
				INNER JOIN Employee e ON e.EmployeeID = a.EmployeeId
				INNER JOIN Employee g ON g.EmployeeID = a.EmployeeID or a.TempEmployeeID = g.EmployeeID 
				WHERE
					a.QueueDate <= GETDATE()
					AND a.DebtorID <> 0
					AND UPPER(g.EmployeeName) LIKE ('%' + UPPER(@EmployeeName) + '%')
					AND a.EmployeeID IN (SELECT CAST(SplitedText AS int) AS EmployeeID FROM CWX_FnSplitString(@EmpList, ','))
			)

			SELECT
				[KeyField],
				[QueueDate],
				[Account Number],
				[DPD],
				[Bucket],
				[Cycle],
				[Bill Amount],
				[Bill Balance],
				[Status],
				[Priority],
				[Assignment Type],
				[Name],
				[Employee Name]
			FROM Temp
			WHERE RowNumber BETWEEN @BeginIndex AND @EndIndex

			RETURN @RowCount
		End    
End


END

GO

/******   Script Date: 2007/04/09,sathya  ******/
ALTER PROCEDURE [dbo].[SearchDebtorBySocial]
	@Social char(25),
	@EmpList varchar(3000),
	@FilterByClient bit
As
BEGIN

DECLARE @cStmt NVARCHAR(4000)
SET @cStmt='Select  convert(varchar(10), a.DebtorID) + ''|'' + convert(varchar(10), a.AccountID) as KeyField,'
	SET @cStmt=@cStmt+'a.DebtorID As [DebtorID],'
	SET @cStmt=@cStmt+'a.InvoiceNumber As [Account No.],'
	SET @cStmt=@cStmt+'convert(char(10), a.QueueDate, 111) as [QueueDate],'
	SET @cStmt=@cStmt+'a.AccountAge as [DPD],'
	SET @cStmt=@cStmt+'CAST(a.MCode AS CHAR(2)) as [Bucket],'
	SET @cStmt=@cStmt+'a.CCode as [Cycle],'
	SET @cStmt=@cStmt+'a.BillAmount  as [Bill Amount],'
	SET @cStmt=@cStmt+'a.BillBalance  as [Bill Balance],'
	SET @cStmt=@cStmt+'a.Minimum_due  as [Minimum Due],'
	SET @cStmt=@cStmt+'p.SocialSecurityNumber as [ID],'
	SET @cStmt=@cStmt+'rtrim(p.FirstName) +'' ''+ rtrim(p.MiddleName) +'' ''+ rtrim(p.LastName) As [ Name]'
SET @cStmt=@cStmt+' from '
	SET @cStmt=@cStmt+'Account a,'
	SET @cStmt=@cStmt+'DebtorInformation d,'
	SET @cStmt=@cStmt+'PersonInformation p'
SET @cStmt=@cStmt+' where p.SocialSecurityNumber = '+''''+Cast(@Social As Char(25))+''''
	SET @cStmt=@cStmt+' and d.DebtorID = a.DebtorID'
	SET @cStmt=@cStmt+' and d.PersonID = p.PersonID'
	SET @cStmt=@cStmt+' and a.DebtorID <> 0 and a.AgencyStatusID <> 2 and a.SystemStatusID <> 2 and a.AccountAge > 0 and a.BillBalance > 0'	

	if @EmpList <> ''
	begin
		if @FilterByClient = 1
		begin
			DECLARE @employeeID varchar(50)
			DECLARE @index int

			SET @index = charindex(',', @EmpList)
			SET @employeeID = substring(@EmpList, 1, @index -1)

			SELECT *  INTO #tblAssignedClientID FROM [dbo].CWX_AssignedClientIDTable(@employeeID)
			SET @cStmt = @cStmt + ' AND (NOT EXISTS (SELECT ClientID FROM #tblAssignedClientID)
									OR a.ClientID IN (SELECT ClientID FROM #tblAssignedClientID))'
		end
		else
		begin
			SET @cStmt=@cStmt+' and a.EmployeeID in ('+@EmpList+')'
		end		
	end

Exec SP_ExecuteSQL @cStmt
END

GO
------------------End of Phuong Le-----------------

------------Start Of ThanhNguyen------------------
/****** Object:  StoredProcedure [dbo].[CWX_Account_CalculateAccount_GroupByAccountStatus]    Script Date: 06/04/2009 15:51:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CalculateAccount_GroupByAccountStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_CalculateAccount_GroupByAccountStatus]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Account_CalculateAccount_GroupByFinancialType]    Script Date: 06/04/2009 15:51:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_CalculateAccount_GroupByFinancialType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_CalculateAccount_GroupByFinancialType]

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Views_GroupByAccountStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Views_GroupByAccountStatus]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Views_GroupByAccountStatus]    Script Date: 06/04/2009 15:52:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 26, 2009
-- Description:	Summary Account info follow format:
--	Status	Total Account		TotalListAmount		TotalBillBalance
--	Active	5					140.000				15365
--	Legal	6					150.000				165.000		
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Views_GroupByAccountStatus]
	@ClientID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	ast.ShortDesc as [Status], count(a.accountID) as TotalAccount, sum(a.BillAmount) as TotalListAmount, 
			sum(a.BillBalance) as TotalBillBalance

	FROM	Account a INNER JOIN AccountStatus ast ON a.AgencyStatusID = ast.AgencyStatus
	WHERE	(a.ClientID = @ClientID OR @ClientID = 0) AND ast.Type IN ('D','S')
	GROUP BY ast.ShortDesc			
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Views_GroupByFinancialType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Views_GroupByFinancialType]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Views_GroupByFinancialType]    Script Date: 06/04/2009 15:53:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CWX_Views_GroupByFinancialType]
	@ClientID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT	fnct.description ,sum(c.BillAmount) as TotalAmount
	FROM	account c INNER JOIN transactions t ON c.accountid = t.accountid
			INNER JOIN transactiontype tt ON t.transactiontype = tt.id
			INNER JOIN cwx_financialtype fnct ON tt.financialtypeid = fnct.financialtypeid
	WHERE	(c.clientid = @ClientID OR @ClientID = 0)
	GROUP BY fnct.Description
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetDynamicFields]
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an account
-- History:
--	[06-Mar-2009]	Minh Dam		Init version.
--	[20-Mar-2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN ... END as [MaxLength]"
--	[10-Apr-2009]	Thanh Nguyen	Add parameter "@CMSEditable"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam		Remove parameters @PageSize, @PageIndex
--									Rename parameter @PageNumber to @TabID
--									Change from Page view to Tab view
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetDynamicFields]
	@AccountID int,
	@TabID int = 1, 
	@ClientID int = 0, -- if @ClientID <= 0 then set @ClientID equals ClientID of account
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF (@AccountID > 0 AND @ClientID <= 0)
		SELECT @ClientID = ClientID
		FROM Account
		WHERE AccountID = @AccountID

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[TableID],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], CASE WHEN @CMSEditable = 1 THEN [CMSEdit] ELSE [Editable] END as [Editable], 
				[GroupID], [GroupDesc], [DisplayOrder], [RangeID], [DropDown], [TableID], [Mandatory]
		FROM CWX_AccountInformation_Dict
		WHERE Displayed = 1	AND TabID = @TabID
			AND (@CMSEditable = 0 OR (@CMSEditable = 1 AND [CMSEdit] = 1))
			AND (ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN ('nvarchar', 'nchar') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Account' AND [Type]='U')
			OR object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'AccountOther' AND [Type]='U')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList_Account varchar(4000), @FieldNameList_AccountOther varchar(4000)
	DECLARE @FieldName varchar(50), @TableID int
	SET @FieldNameList_Account = 'AccountID,InvoiceNumber,DebtorID,EmployeeID,ClientID,QueueDate,AgencyStatusID,SystemStatusID,ActionCodeID,OfficeID,MCode,CCode,BucketMovement,SubmissionDate,LastEditDate,LastEditBy,CurrencyCode,InterfaceID,CloseDate'
	SET @FieldNameList_AccountOther = 'AccountID'

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName, TableID FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF (@TableID = 1) -- Account table
			SET @FieldNameList_Account = @FieldNameList_Account + ',' + @FieldName
		ELSE IF (@TableID = 2) -- AccountOther table
			SET @FieldNameList_AccountOther = @FieldNameList_AccountOther + ',' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql1 varchar(1000), @Sql2 varchar(1000)
	SET @Sql1 = 'SELECT ' + @FieldNameList_Account + ' FROM Account WHERE AccountID = ' + Cast(@AccountID as varchar)
	SET @Sql2 = 'SELECT ' + @FieldNameList_AccountOther + ' FROM AccountOther WHERE AccountID = ' + Cast(@AccountID as varchar)
	
	EXEC (@Sql1)
	EXEC (@Sql2)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

END
GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_ClientProperties' AND COLUMN_NAME = N'CloseAccountCriteria' )
BEGIN
	ALTER TABLE [dbo].[CWX_ClientProperties]
	ADD [CloseAccountCriteria] [money] NULL
END
GO
------------End Of ThanhNguyen------------------

-----------Phuong Le------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DeleteTransaction_log]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CWX_DeleteTransaction_log](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[AccountID] [int] NULL,
	[ClientID] [int] NULL CONSTRAINT [DF_CWX_DeleteTransaction_log_ClientID]  DEFAULT ((1)),
	[EmployeeID] [int] NULL CONSTRAINT [DF_CWX_DeleteTransaction_log_EmployeeID]  DEFAULT ((1001)),
	[PaymentTypeID] [int] NULL CONSTRAINT [DF_CWX_DeleteTransaction_log_PaymentTypeID]  DEFAULT ((0)),
	[DateOfTransaction] [smalldatetime] NULL,
	[TransactionType] [int] NULL CONSTRAINT [DF_CWX_DeleteTransaction_log_TransactionType]  DEFAULT ((0)),
	[TransactionAmount] [money] NULL,
	[TransactionComment] [varchar](150) NULL,
	[DateToPost] [smalldatetime] NULL,
	[PaidWhere] [char](30) NULL CONSTRAINT [DF_CWX_DeleteTransaction_log_PaidWhere]  DEFAULT ('B'),
	[ReversedFlag] [bit] NOT NULL,
	[ImportedTransactionID] [varchar](100) NULL,
	[Descriptor] [char](1) NULL,
	[TXN_POSTED] [varchar](1) NULL CONSTRAINT [DF_CWX_DeleteTransaction_log_TXN_POSTED]  DEFAULT ('N'),
	[PART_AMOUNT] [numeric](25, 3) NULL,
	[ParentTransactionID] [int] NULL,
	[PromiseID] [int] NULL,
	[DeletedBy] [int] NULL,
	[DeletedDate] [datetime] NULL,
	 CONSTRAINT [PK_CWX_DeleteTransaction_log] PRIMARY KEY CLUSTERED 
	(
		[LogID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_DeleteTransaction]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_DeleteTransaction]
GO

-- =============================================
-- Description:	Delete transaction.
-- History:
--	2009/June/09	[Phuong Le]	Init version.
-- =============================================\
CREATE PROCEDURE [dbo].[CWX_Transaction_DeleteTransaction] 
	@AccountID int,
	@transactionID int,
	@TransactionType int, -- 1: Add Other Charge; 2: Receive Payment
	@TransactionAmount money,
	@EffectToBalance int = 0, -- 0: No effect; 1: increase balance; 2: decrease balance,
	@DeleteBy int,
	@WriteHistory bit,
	@DeleteParentTransaction bit
AS
BEGIN	
	BEGIN TRANSACTION
	
	--Write Log
	IF @WriteHistory =1
		BEGIN
			INSERT INTO dbo.CWX_DeleteTransaction_log(AccountID, ClientID, EmployeeID, PaymentTypeID, DateOfTransaction, TransactionType,
					TransactionAmount, TransactionComment, DateToPost, PaidWhere, ReversedFlag, ImportedTransactionID,
					Descriptor, TXN_POSTED, PART_AMOUNT, ParentTransactionID, PromiseID, DeletedBy, DeletedDate)
				SELECT AccountID, ClientID, EmployeeID, PaymentTypeID, DateOfTransaction, TransactionType,
					TransactionAmount, TransactionComment, DateToPost, PaidWhere, ReversedFlag, ImportedTransactionID,
					Descriptor, TXN_POSTED, PART_AMOUNT, ParentTransactionID, PromiseID, @DeleteBy, getdate()
				FROM [dbo].[transactions]
				WHERE transactionid = @transactionID or ParentTransactionID = @transactionID
		END

	IF @@ERROR <> 0
	   BEGIN
		ROLLBACK TRAN
		return 0
	   END 
	--Delete transaction
	IF @DeleteParentTransaction =1
		BEGIN
			DELETE [dbo].[transactions] WHERE transactionid = @transactionID or ParentTransactionID = @transactionID			
		END
	ELSE
		BEGIN
			DELETE [dbo].[transactions] WHERE ParentTransactionID = @transactionID
		END

	IF @@ERROR <> 0
	   BEGIN
		ROLLBACK TRAN
		return 0
	   END
	--Update amount
	EXEC [dbo].[CWX_Account_UpdateTransactionAmount] @AccountID, @TransactionType, @TransactionAmount, @EffectToBalance
	IF @@ERROR <> 0
	   BEGIN
		ROLLBACK TRAN
		return 0
	   END

	COMMIT TRANSACTION
	return 1
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transaction_GetTransactionTypeInCaseEdit]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transaction_GetTransactionTypeInCaseEdit]
GO

CREATE PROCEDURE [dbo].[CWX_Transaction_GetTransactionTypeInCaseEdit]
	@AccountID int,
	@ClientID int,
	@PaymentAllocationRuleID int = 0,
	@TransactionID int
AS
BEGIN
	SET NOCOUNT ON
	IF @PaymentAllocationRuleID = 0
	BEGIN
		SELECT     T.TransactionType, SUM(ISNULL(T.TransactionAmount, 0)) AS Amount, TT.Description, TT.TransactionCode, TT.AffectBalance
			FROM         Transactions AS T INNER JOIN
								  TransactionType AS TT ON T.TransactionType = TT.ID
			WHERE   (T.AccountID = @AccountID) AND 
					(T.ClientID = @ClientID) AND 
					--(T.TXN_POSTED = 'N') AND
					(TT.AffectBalance = 1) AND
					T.TransactionID <> @TransactionID AND
					Isnull(T.ParentTransactionID,'') <> @TransactionID
			GROUP BY T.TransactionType, TT.Description, TT.TransactionCode, TT.AffectBalance
	END
	ELSE
	BEGIN
		SELECT	T1.*,901,902,903
		FROM
				(SELECT     T.TransactionType, SUM(ISNULL(T.TransactionAmount, 0)) AS Amount, TT.Description, TT.TransactionCode, TT.AffectBalance
				FROM         Transactions AS T INNER JOIN
									  TransactionType AS TT ON T.TransactionType = TT.ID
				WHERE     (T.AccountID = @AccountID) AND 
							(T.ClientID = @ClientID) AND --AND (T.TXN_POSTED = 'N')
							T.TransactionID <> @TransactionID AND
							Isnull(T.ParentTransactionID,'') <> @TransactionID
				GROUP BY T.TransactionType, TT.Description, TT.TransactionCode, TT.AffectBalance) as T1 LEFT OUTER JOIN
					Legal_PaymentAllocationRuleItems AS LP ON T1.TransactionType = LP.TransactionTypeID
		WHERE	LP.PaymentAllocationRuleID = @PaymentAllocationRuleID AND
				T1.AffectBalance = 1		
		ORDER BY LP.Seq
	END	
END

GO

ALTER TABLE dbo.CWX_Currency
	ALTER COLUMN Symbol CHAR(3) not null

GO

IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[U_CWX_Currency_Symbol]') AND type in (N'UQ'))
BEGIN
	ALTER TABLE dbo.CWX_Currency
		ADD constraint U_CWX_Currency_Symbol Unique(Symbol)
END

GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'Transactions' AND COLUMN_NAME = N'DebtorExchangeRate' )
BEGIN
	ALTER TABLE dbo.Transactions
		ADD DebtorExchangeRate DECIMAL(18,5)
END

GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'Transactions' AND COLUMN_NAME = N'AgencyCurrency' )
BEGIN
	ALTER TABLE dbo.Transactions
		ADD AgencyCurrency CHAR(3)
END

GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'Transactions' AND COLUMN_NAME = N'AgencyExchangeRate' )
BEGIN
	ALTER TABLE dbo.Transactions
		ADD AgencyExchangeRate DECIMAL(18,5)
END

GO

IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'Transactions' AND COLUMN_NAME = N'PaidAt' )
BEGIN
	ALTER TABLE dbo.Transactions
		ADD PaidAt Bit not null default(0)
END

GO

-- =============================================
-- Description:	Get Transaction List by TransactionType with a custom column is "Transaction Code - Description"
-- History:
--	2008/08/29	[Thuy Nguyen]	Init version.
--	2008/09/29	[Binh Truong]	Select total transaction amount.
--	2008/10/29	[Binh Truong]	Add DateToPost field.
--	2008/10/30	[Binh Truong]	Exclude Transactions.Descriptor = 'A'
--  2009/04/26  [SD]			Removed the Transactions.Descriptor = 'A'
--  2009/04/28  [SD]            Add two more columns to list
--  2009/06/11	[Phuong Le]		Add column PaidAt to list
-- =============================================
ALTER PROCEDURE [dbo].[CWX_Transaction_GetTransactionPagingList] 		
	@AccountID int = 0,
	@TransactionType int = 0,
	@PaidAt int = -1,
	@PageSize int = 10,
	@PageIndex int = 0
	
AS
BEGIN
	SET NOCOUNT ON;	

	DECLARE @querystring varchar(1000);

		CREATE TABLE #Temp(
		RowNumber int,		
		TransactionID int not null,
		DateToPost smalldatetime,
		DateOfTransaction smalldatetime,
		TransactionAmount money,		
		TransactionComment nvarchar(150),
		TransactionCodeDescription nvarchar(150),
		TransactionType int,
		InterestBreakdown bit,
		ReversedFlag bit,
		ImportedTransactionID varchar(100),
		TXN_POSTED varchar(1),
		TXN_PaymentType varchar(20),
		TXN_PaymentType_Details varchar(30),
		PaidAt varchar(3)
	);


SET @querystring = 'INSERT INTO #Temp
		SELECT 
		ROW_NUMBER() OVER (ORDER BY  t.DateOfTransaction DESC,t.TransactionID DESC) AS RowNumber,
		t.TransactionID, t.DateToPost, t.DateOfTransaction, t.TransactionAmount, t.TransactionComment,
		tt.TransactionCode + '' - '' + tt.Description as TransactionCodeDescription,
		t.TransactionType, tt.InterestBreakdown, t.ReversedFlag, t.ImportedTransactionID, t.TXN_POSTED,
		case t.PaymentTypeID when 0 then ' + '''' + '-' + ''''  +
						' when 1 then' + '''' + 'Cash' + ''''  +
				    	' when 2 then' + '''' + 'Cashiers Cheque' + ''''  + 
				    	' when 3 then' + '''' + 'Cheque' + ''''  +
				    	' when 4 then' + '''' + 'Credit Card' + ''''  +
				    	' when 5 then' + '''' + 'Money Order' + ''''  + 
 					' end,' + 
		'case when t.TransactionType = 901 then t.PaidWhere else ' + '''' + '-' + '''' + 'end,' +
		'case when t.PaidAt = 1 then ''PTC'' else ''PTA'' end ' +
	' FROM Transactions t LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID
	WHERE	t.AccountID = ' + cast(@AccountID as varchar) + ' AND 
			ISNULL(t.ParentTransactionID, 0) = 0'
		
-- AND t.Descriptor <> ''A''

	IF @TransactionType<>0 SET @querystring = @querystring + ' AND t.TransactionType = ' + cast(@TransactionType as varchar);
	
	IF @PaidAt > -1 SET @querystring = @querystring + ' AND t.PaidAt = ' + cast(@PaidAt as varchar(1));
	
	EXEC (@querystring)

	DECLARE @RowCount int
	SELECT @RowCount = @@ROWCOUNT
	
	SELECT * FROM #Temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	DROP TABLE #Temp
	
	SELECT	SUM(TransactionAmount) as TotalAmount
	FROM	Transactions
	WHERE	AccountID = @AccountID AND
			(@TransactionType=0 OR TransactionType = @TransactionType) AND
			ISNULL(ParentTransactionID, 0) = 0 
			--AND Descriptor <> 'A' -- exclude additional transaction		
	RETURN @RowCount
END

GO
-----------End of Phuong Le ---------------

--------------Start of ThanhNguyen-----------------------------

IF EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_ClientProperties' AND COLUMN_NAME = N'ExchangeRate' )
BEGIN
ALTER TABLE [dbo].[CWX_ClientProperties]
	ALTER COLUMN [ExchangeRate] decimal(19,5) NULL
END
GO

IF EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_ClientProperties' AND COLUMN_NAME = N'ReferralRate' )
BEGIN
ALTER TABLE [dbo].[CWX_ClientProperties]
	ALTER COLUMN [ReferralRate] decimal(19,5) NULL
END
GO

IF EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_ClientPropertiesLog' AND COLUMN_NAME = N'ExchangeRate' )
BEGIN
ALTER TABLE [dbo].[CWX_ClientPropertiesLog]
	ALTER COLUMN ExchangeRate decimal(19,5) NULL
END
GO

IF EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_ClientPropertiesLog' AND COLUMN_NAME = N'ReferralRate' )
BEGIN
ALTER TABLE [dbo].[CWX_ClientPropertiesLog]
	ALTER COLUMN ReferralRate decimal(19,5) NULL
END
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Transactons_GetTransactionList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Transactons_GetTransactionList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_Transactons_GetTransactionList]    Script Date: 06/10/2009 16:31:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: May 26, 2009
-- Description:	Get list of payment type (PTA or PTC)
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Transactons_GetTransactionList]
	@PaymentType int,
	@ExcludeReversalTran bit,
	@ClientID int,
	@PageSize int = 10,
	@PageIndex int = 0	 	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @Rowcount int
	DECLARE @paidAt bit
			
    -- Insert statements for procedure here
	SELECT RowNumber, TransactionID, DebtorName, TransactionType, PaymentType, Amount, Description
	FROM 
	(
		SELECT	ROW_NUMBER() OVER (ORDER BY t.TransactionID DESC) AS RowNumber,
				 t.TransactionID as TransactionID, (p.FirstName + ' ' + p.LastName) as DebtorName, TT.Description as TransactionType,
				CASE 
					WHEN PaidAt = 0 THEN 'PTA' 
					WHEN PaidAt = 1 THEN 'PTC'									
				END as PaymentType,
				t.TransactionAmount as Amount, t.TransactionComment as [Description]
		FROM	Transactions t INNER JOIN Account a ON t.AccountID = a.AccountID
				INNER JOIN TransactionType tt ON t.TransactionType = tt.ID	
				INNER JOIN DebtorInformation d ON a.DebtorID = d.DebtorID
				INNER JOIN PersonInformation p ON d.PersonID = p.PersonID
		WHERE	(t.PaidAt = @PaymentType OR @PaymentType = -1) AND 
				 (t.ReversedFlag <> @ExcludeReversalTran OR @ExcludeReversalTran = 0) AND
				(t.ClientID = @ClientID OR @ClientID = -1)
	) as a
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	SELECT @Rowcount = count(*)
	FROM	Transactions t INNER JOIN Account a ON t.AccountID = a.AccountID
				INNER JOIN TransactionType tt ON t.TransactionType = tt.ID	
				INNER JOIN DebtorInformation d ON a.DebtorID = d.DebtorID
				INNER JOIN PersonInformation p ON d.PersonID = p.PersonID
	WHERE	(t.PaidAt = @PaymentType OR @PaymentType = -1) AND 
				 (t.ReversedFlag <> @ExcludeReversalTran OR @ExcludeReversalTran = 0) AND
				(t.ClientID = @ClientID OR @ClientID = -1)

	RETURN @Rowcount			
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties]') AND type in (N'U'))
BEGIN
	
	IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties]') AND name = N'PK_CWX_ClientProperties')
	ALTER TABLE [dbo].[CWX_ClientProperties] DROP CONSTRAINT [PK_CWX_ClientProperties]
	
	IF NOT EXISTS (SELECT TABLE_NAME,COLUMN_NAME
                         FROM INFORMATION_SCHEMA.COLUMNS
                         WHERE TABLE_NAME=N'CWX_ClientProperties' AND COLUMN_NAME = N'ID' )
	BEGIN
		ALTER TABLE [dbo].[CWX_ClientProperties]
		ADD ID int IDENTITY(1,1) NOT NULL 
	END
	
	

	IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties]') AND name = N'PK_CWX_ClientProperties')
	BEGIN		
		ALTER TABLE [dbo].[CWX_ClientProperties] ADD  CONSTRAINT [PK_CWX_ClientProperties] PRIMARY KEY CLUSTERED 
		(
			[ID] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	END
END
GO

IF NOT EXISTS (	SELECT TABLE_NAME,COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME=N'CWX_ClientPropertiesLog' AND COLUMN_NAME = N'ID' )
BEGIN
	ALTER TABLE [dbo].[CWX_ClientPropertiesLog]
	ADD ID int null
END

GO
IF NOT EXISTS (	SELECT TABLE_NAME,COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME=N'CWX_ClientPropertiesLog' AND COLUMN_NAME = N'CloseAccountCriteria' )
BEGIN
	ALTER TABLE [dbo].[CWX_ClientPropertiesLog]
	ADD CloseAccountCriteria money null
END
GO

IF NOT EXISTS (	SELECT TABLE_NAME,COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME=N'CWX_ClientCommModel' AND COLUMN_NAME = N'Minimum' )
BEGIN
	ALTER TABLE [dbo].[CWX_ClientCommModel]
	ADD Minimum money null
END

IF NOT EXISTS (	SELECT TABLE_NAME,COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME=N'CWX_ClientCommModel' AND COLUMN_NAME = N'Maximum' )
BEGIN
	ALTER TABLE [dbo].[CWX_ClientCommModel]
	ADD Maximum money null
END


IF NOT EXISTS (	SELECT TABLE_NAME,COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME=N'CWX_ClientCommModelLog' AND COLUMN_NAME = N'Minimum' )
BEGIN
	ALTER TABLE [dbo].[CWX_ClientCommModelLog]
	ADD Minimum money null
END

IF NOT EXISTS (	SELECT TABLE_NAME,COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME=N'CWX_ClientCommModelLog' AND COLUMN_NAME = N'Maximum' )
BEGIN
	ALTER TABLE [dbo].[CWX_ClientCommModelLog]
	ADD Maximum money null
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientProperties_GetNoPropertiesClients]    Script Date: 06/10/2009 17:30:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties_GetNoPropertiesClients]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientProperties_GetNoPropertiesClients]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientProperties_GetNoPropertiesClients]    Script Date: 06/10/2009 17:30:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: 09-June-2009
-- Description:	Get list of Clients that do not have properties
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientProperties_GetNoPropertiesClients]	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT	c.ClientID, cast(c.ClientID as nvarchar(10))+ ' - ' + ISNULL(c.ClientName,'') as ClientIDAndName
	FROM	ClientInformation c 
	WHERE c.ClientID NOT IN (SELECT ClientID FROM CWX_ClientProperties WHERE [Status] <> 'R') AND [Status] <> 'R'
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientProperties_GetClientsHaveProperties]    Script Date: 06/10/2009 17:30:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientProperties_GetClientsHaveProperties]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_ClientProperties_GetClientsHaveProperties]
GO
/****** Object:  StoredProcedure [dbo].[CWX_ClientProperties_GetClientsHaveProperties]    Script Date: 06/10/2009 17:30:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: 09-June-2009
-- Description:	Get list of Clients that have properties
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientProperties_GetClientsHaveProperties]	
	@PageSize int = 10, 
	@PageIndex int =0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT RowNumber, a.ClientID, a.ClientName, a.BillingPeriod, a.InvoiceType
	FROM 
	(
		SELECT	ROW_NUMBER() OVER (ORDER BY c.ClientID DESC) AS RowNumber,
				c.ClientID, ISNULL(c.ClientName,'') as ClientName, cps.value as BillingPeriod, cps1.value as InvoiceType
		FROM	ClientInformation c INNER JOIN CWX_ClientProperties cp ON c.ClientID = cp.ClientID
				LEFT JOIN CWX_ClientPropertySettings cps ON cp.BillingPeriod = cps.ID
				LEFT JOIN CWX_ClientPropertySettings cps1 ON cp.InvoiceType = cps1.ID				
		WHERE	c.ClientID IN (SELECT ClientID FROM CWX_ClientProperties WHERE [Status] <> 'R') AND
				cp.Status <> 'R'
			
	) as a
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize
	
	DECLARE @rowCount int
	SELECT	@rowCount  = count(*)
	FROM	ClientInformation c INNER JOIN CWX_ClientProperties cp ON c.ClientID = cp.ClientID
			LEFT JOIN CWX_ClientPropertySettings cps ON cp.BillingPeriod = cps.ID
			LEFT JOIN CWX_ClientPropertySettings cps1 ON cp.InvoiceType = cps1.ID				
	WHERE	c.ClientID IN (SELECT ClientID FROM CWX_ClientProperties WHERE [Status] <> 'R') AND
			cp.Status <> 'R'

	RETURN @rowCount
END
GO
 --------------End of ThanhNguyen-----------------------------
 
 /****** Object:  Table [dbo].[CWX_SMSNMailTemplates]    Script Date: 06/10/2009 11:45:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
/****** Object:  Table [dbo].[CWX_SMSNMailTemplates]    Script Date: 06/25/2009 11:30:03 ******/
IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMSNMailTemplates]') AND type in (N'U'))

BEGIN
CREATE TABLE [dbo].[CWX_SMSNMailTemplates](
	[Template_ID] [int] IDENTITY(1,1) NOT NULL,
	[Channel_ID] [int] NULL,
	[Message_Body] [nvarchar](2000) NULL,
	[CreateDate] [datetime] NULL,
	[UpdateDate] [datetime] NULL,
	[UserID] [int] NULL,
	[Status] [char](1) NOT NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Code] [varchar](10) NULL,
 CONSTRAINT [PK_CWX_SMSNMailTemplates] PRIMARY KEY CLUSTERED 
(
	[Template_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO



-----------------------------------------------------------------------------------------------------------------------
-- SMTP setting
------------------------------------------------------------------------------------------------------------------------------


-- Step1: Before setting up the Database Mail profile and accounts, we have to enable the Database Mail feature on the server.
master.dbo.sp_configure 'show advanced options',1
go
reconfigure with override
go
master.dbo.sp_configure 'Database Mail XPs',1
--go
--sp_configure 'SQL Mail XPs',0
go
reconfigure 
go
	
----------------------------------------------------------------------------------------------------------------------------------------------	

/****** Object:  StoredProcedure [dbo].[CWX_SMTP_SMS_Settings_Get]    Script Date: 06/15/2009 14:53:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMTP_SMS_Settings_Get]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_SMTP_SMS_Settings_Get]
GO

/****** Object:  StoredProcedure [dbo].[CWX_SMTP_SMS_Settings_Get]    Script Date: 06/15/2009 14:54:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ===================================================================================
-- Author:		Hung nguyen
-- Create date: Jun 9, 2009
-- Description:	sms mail template
-- ===================================================================================
CREATE PROC [dbo].[CWX_SMTP_SMS_Settings_Get] 
   
AS 
	SET NOCOUNT ON 
	
	--just use the first record only
	SELECT top 1 
		[SMTP_SMS_AccountID], 
		[DefaultEmailSubject], 
		[Description], 
		[DisplayName], 
		[EmailAddress], 
		[Name], 
		[Port], 
		[ReplyToAddress], 
		[ServerName], 
		[ServerType], 
		[SMS_Gateway], 		
		[SMS_Password], 
		[SMS_SendingTo], 
		[SMS_UserName], 
		[SMTP_EnableSSL], 
		[SMTP_Password], 
		[SMTP_UserName], 
		[UseDefaultCridentials] 
	FROM   [dbo].[CWX_SMTP_SMS_Settings] 
	ORDER BY SMTP_SMS_AccountID
	
GO

/****** Object:  StoredProcedure [dbo].[CWX_SMTP_SMS_SettingsUpdate]    Script Date: 06/15/2009 14:54:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMTP_SMS_SettingsUpdate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_SMTP_SMS_SettingsUpdate]

GO

/****** Object:  StoredProcedure [dbo].[CWX_SMTP_SMS_SettingsUpdate]    Script Date: 06/19/2009 18:04:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	just use the first record only
-- History:
--	2008/09/12	[hung nguyen]	Init version.
-- =============================================
CREATE PROC [dbo].[CWX_SMTP_SMS_SettingsUpdate] 
(
    @DefaultEmailSubject nvarchar(255)= null,
 --   @Description nvarchar(256) =null,
    @DisplayName nvarchar(128)= null,
    @EmailAddress nvarchar(128)= null,
 --   @Name nvarchar(256)= null,
    @Port int =null,
    @ReplyToAddress nvarchar(128)= null,
    @ServerName nvarchar(255) =null,
 --   @ServerType nvarchar(255) =null,
    @SMS_Getway nvarchar(255) =null,    
    @SMS_Password nvarchar(128) =null,
    @SMS_SendingTo int =null,
    @SMS_UserName nvarchar(128) =null,
    @SMTP_EnableSSL bit =null,
    @SMTP_Password nvarchar(128) =null,
    @SMTP_UserName nvarchar(128) =null
  --  @UseDefaultCridentials bit =null
)
AS 
	SET NOCOUNT ON 

	declare @SMTP_SMS_AccountID int;
	declare @AccountName nvarchar(100);

	set @AccountName= 'CWX_Account';
    set @SMTP_SMS_AccountID=0;

BEGIN TRAN

	if exists( select top 1 * from [dbo].[CWX_SMTP_SMS_Settings] )
		begin
			
			--just use the first record in this table only
			select top 1  @SMTP_SMS_AccountID= SMTP_SMS_AccountID 
			from [dbo].[CWX_SMTP_SMS_Settings]
			order by SMTP_SMS_AccountID;

				
				UPDATE [dbo].[CWX_SMTP_SMS_Settings]
				SET     [DefaultEmailSubject] = @DefaultEmailSubject, 
				--		[Description]     = @Description, 
						[DisplayName]     = @DisplayName, 
						[EmailAddress]    = @EmailAddress, 
				--		[Name]            = @Name, 
						[Port]            = @Port, 
				--		[ReplyToAddress]  = @ReplyToAddress, 
						[ServerName]      = @ServerName, 
				--		[ServerType]      = @ServerType, 
						[SMS_Gateway]      = @SMS_Getway, 						
				 
						[SMS_SendingTo]   = @SMS_SendingTo, 
						[SMS_UserName]    = @SMS_UserName, 
						[SMTP_EnableSSL]  = @SMTP_EnableSSL, 
				
						[SMTP_UserName]   = @SMTP_UserName 
				--		[UseDefaultCridentials] = @UseDefaultCridentials
				WHERE  [SMTP_SMS_AccountID] = @SMTP_SMS_AccountID	

				--update password if any
				IF((@SMTP_Password is not null) and (@SMTP_Password<>''))
				BEGIN
						UPDATE [dbo].[CWX_SMTP_SMS_Settings]
						SET     [SMTP_Password]   = @SMTP_Password
						WHERE  [SMTP_SMS_AccountID] = @SMTP_SMS_AccountID	
				END

				IF((@SMS_Password is not null) and (@SMS_Password<>''))
				BEGIN
						UPDATE [dbo].[CWX_SMTP_SMS_Settings]
						SET    [SMS_Password]    = @SMS_Password 
						WHERE  [SMTP_SMS_AccountID] = @SMTP_SMS_AccountID	
				END
		END
	ELSE
		BEGIN
			INSERT INTO [dbo].[CWX_SMTP_SMS_Settings] 
			(
				[DefaultEmailSubject], 
		--		[Description], 
				[DisplayName], 
				[EmailAddress], 
		--		[Name], 
				[Port], 
		--		[ReplyToAddress], 
				[ServerName], 
		--		[ServerType], 
				[SMS_Gateway], 				
				[SMS_Password], 
				[SMS_SendingTo], 
				[SMS_UserName], 
				[SMTP_EnableSSL], 
				[SMTP_Password], 
				[SMTP_UserName]
		--		[UseDefaultCridentials]
			)
			Values (
				@DefaultEmailSubject, 
		--		@Description, 
				@DisplayName, 
				@EmailAddress, 
		--		@Name, 
				@Port, 
		--		@ReplyToAddress, 
				@ServerName, 
		--		@ServerType, 
				@SMS_Getway, 				
				@SMS_Password, 
				@SMS_SendingTo, 
				@SMS_UserName, 
				@SMTP_EnableSSL, 
				@SMTP_Password, 
				@SMTP_UserName 
		--		@UseDefaultCridentials
		    )
			
		end	



--Update to system mail account

-- The Configuration Component Database account

DECLARE @account TABLE 
(
	accountID INT, 
	accountName VARCHAR(30), 
	[description] VARCHAR(80), 
	emailAddress VARCHAR(90), 
	displayName VARCHAR(90), 
	replyToAddress VARCHAR(90), 
	serverType VARCHAR(20), 
	serverName VARCHAR(90), 
	port INT, 
	userName VARCHAR(30), 
	useDefaultCredentials BIT, 
	enableSSL BIT
);

DECLARE @profileAccount TABLE 
(
		profileID INT, 
		profile_name varchar(30), 
		accountID int, 
		account_name varchar(30), 
		sequenceNumber int
); 

DECLARE @profile TABLE 
(
	profileID INT, 
	profile_name varchar(30), 
	[description] varchar(30)
); 

DECLARE @principalProfile TABLE 
(
	principleID INT, 
	principal_name varchar(30), 
	profileID int, 
	profile_name varchar(30), 
	isdefault bit
) 


INSERT INTO @account 
(
	accountID, 
	accountName, 
	[description], 
	emailAddress, 
	displayName, 
	replyToAddress, 
	serverType, 
	serverName, 
	port, 
	userName, 
	useDefaultCredentials, 
	enableSSL
)EXECUTE msdb.dbo.sysmail_help_account_sp


IF (NOT EXISTS (SELECT accountID FROM @account WHERE accountName = @AccountName)) 
BEGIN 
	EXECUTE msdb.dbo.sysmail_add_account_sp 
		@account_name    = @AccountName, 
		@description     = 'Mail account sending database notifications', 
		@email_address   = @EmailAddress, 
		@display_name    = @DisplayName, 
		--@replyto_address = 'cwx@gmail.com', 
		@mailserver_name = @ServerName,
		@port            = @Port,
		@username        = @SMTP_UserName,
		@password        = @SMTP_Password,
		@enable_ssl      = @SMTP_EnableSSL;	
END 
ELSE
BEGIN

	IF((@SMTP_Password is null) or (@SMTP_Password=''))
	BEGIN
		EXECUTE [msdb].[dbo].[sysmail_update_account_sp]
		   @account_name     = @AccountName,
		   @email_address    = @EmailAddress,
		   @display_name     = @DisplayName,
		   @mailserver_name  = @ServerName,  
		   @replyto_address  = null,
		   @port             = @Port,
		   @username         = @SMTP_UserName,
		 --  @password       = @SMTP_Password, //not update password field if it's empty
		   @enable_ssl       = @SMTP_EnableSSL
	END
	ELSE
	BEGIN
		EXECUTE [msdb].[dbo].[sysmail_update_account_sp]
		   @account_name     = @AccountName,
		   @email_address    = @EmailAddress,
		   @display_name     = @DisplayName,
		   @mailserver_name  = @ServerName,  
		   @replyto_address  = null,
		   @port             = @Port,
		   @username    = @SMTP_UserName,
		   @password    = @SMTP_Password,
		   @enable_ssl  = @SMTP_EnableSSL
	END
END

-- do profile 
INSERT INTO @profile 
(
	profileID, 
	profile_name, 
	[description]
)EXECUTE msdb.dbo.sysmail_help_profile_sp

IF (NOT EXISTS (SELECT profileID FROM @profile WHERE profile_name = 'CWX_Profile')) 
BEGIN 
	-- Create a Database Mail profile 
	EXECUTE msdb.dbo.sysmail_add_profile_sp 
		@profile_name = 'CWX_Profile', 
		@description = 'Used to send mail'; 
END 

-- do profile to account link 
INSERT INTO @profileAccount 
(
	profileID, 
	profile_name, 
	accountID, 
	account_name, 
	sequenceNumber
) EXECUTE msdb.dbo.sysmail_help_profileaccount_sp

IF (NOT EXISTS (SELECT profileID FROM @profileAccount WHERE profile_name = 'CWX_Profile')) 
BEGIN 

	-- Add the account to the profile 
	EXECUTE msdb.dbo.sysmail_add_profileaccount_sp 
		@profile_name = 'CWX_Profile', 
		@account_name = @AccountName, 
		@sequence_number =1 ; 
END 

-- make prinicple profile 
INSERT INTO @principalProfile
(
	PrincipleID, 
	principal_name, 
	profileID, 
	profile_name, 
	isdefault
)EXEC msdb.dbo.sysmail_help_principalprofile_sp

IF (NOT EXISTS (SELECT PrincipleID FROM @principalProfile WHERE profile_name = 'CWX_Profile')) 
BEGIN 
	-- Grant access to the profile 
	EXECUTE msdb.dbo.sysmail_add_principalprofile_sp 
	@profile_name = 'CWX_Profile', 
	@principal_name = 'public', 
	@is_default = true 
END 

SET NOCOUNT OFF 


-- See if there is an error
IF (@@ERROR <> 0)
  -- There's an error b/c @ERROR is not 0, rollback
  ROLLBACK

ELSE
  COMMIT   -- Success!  Commit the transaction
	
GO

---------------------------Phuong Le ------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMTP_SMS_Check_MobilePhoneExist]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_SMTP_SMS_Check_MobilePhoneExist]

GO

CREATE PROC [dbo].[CWX_SMTP_SMS_Check_MobilePhoneExist] 
	@MobilePhoneNo	varchar(15)   
AS 
	return 1
	
GO
---------------------------End Phuong Le --------------------------------------


/****** Object:  StoredProcedure [dbo].[CWX_SMSMail_History_GetPagingList]    Script Date: 06/16/2009 16:21:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_SMSMail_History_GetPagingList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_SMSMail_History_GetPagingList]
GO

/****** Object:  StoredProcedure [dbo].[CWX_SMSMail_History_GetPagingList]    Script Date: 06/16/2009 16:21:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: June-16-2009
-- Description:	Get history info of SMS And Mail
-- =============================================
CREATE PROCEDURE [dbo].[CWX_SMSMail_History_GetPagingList]
	@ChannelID int,
	@PageSize int = 10,
	@PageIndex int =  0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT a.RowNumber, a.ID, a.EmailAddress, a.PhoneNumber, a.Channel, a.SendingDate, a.TemplateDescription, a.BodyMessage
	FROM (
    -- Insert statements for procedure here
		SELECT	ROW_NUMBER() OVER (ORDER BY smsh.ID) AS RowNumber,
				smsh.ID as ID, ISNULL(smsh.MessageText, '') as BodyMessage,  
				ISNULL(smsh.EmailAddress,'') as EmailAddress, ISNULL(smsh.SMS_Number,'') as PhoneNumber, 
				CASE WHEN smsh.ChannelID = 1 THEN 'Email' ELSE 'SMS' END as Channel,
				smsh.ProcessDate as SendingDate, ISNULL(dl.LetterDesc,'') as TemplateDescription
		FROM	CWX_SMSMail_History smsh
				LEFT JOIN DefineLetters dl ON smsh.TemplateID = dl.LetterID
		WHERE	(smsh.ChannelID = @ChannelID OR @ChannelID = 0)
	) a
	WHERE (@PageSize <= 0) OR (RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize)
	
	DECLARE @rowCount int
	SELECT	@rowCount = count(*)
	FROM	CWX_SMSMail_History smsh
			LEFT JOIN DefineLetters dl ON smsh.TemplateID = dl.LetterID
	WHERE	(smsh.ChannelID = @ChannelID OR @ChannelID = 0)
	RETURN @rowCount
END
GO
	
	

	