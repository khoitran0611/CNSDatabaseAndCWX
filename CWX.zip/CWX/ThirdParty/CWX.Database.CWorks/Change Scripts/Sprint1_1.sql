﻿
-- ThuyNguyen added on 9-March-2009 --
/****** Object:  Table [dbo].[CWX_PersonInformation_Dict]    Script Date: 03/09/2009 10:46:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CWX_PersonInformation_Dict](
	[FieldName] [varchar](50) NOT NULL,
	[FieldDesc] [varchar](100) NOT NULL,
	[Displayed] [bit] NOT NULL DEFAULT ((1)),	
	[Editable] [bit] NOT NULL DEFAULT ((1)),
	[GroupID] [int] NOT NULL DEFAULT ((0)),
	[GroupDesc] [varchar](50) NULL,
	[DisplayOrder] [int] NOT NULL DEFAULT ((0)),		
	[PageNumber] [int] NOT NULL DEFAULT ((1)),
	[Client] [int] NOT NULL DEFAULT ((0))
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF 

/****** Object:  Table [dbo].[CWX_AccountInformation_Dict]    Script Date: 03/09/2009 10:49:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CWX_AccountInformation_Dict](
	[FieldName] [varchar](50) NOT NULL,
	[FieldDesc] [varchar](100) NOT NULL,
	[Displayed] [bit] NOT NULL DEFAULT ((1)),
	[Editable] [bit] NOT NULL DEFAULT ((1)),
	[GroupID] [int] NOT NULL DEFAULT ((0)),
	[GroupDesc] [varchar](50) NULL,
	[DisplayOrder] [int] NOT NULL DEFAULT ((0)),
	[TableID] [int] NOT NULL DEFAULT ((1)),
	[DropDown] [int] NOT NULL DEFAULT ((0)),
	[PageNumber] [int] NOT NULL DEFAULT ((1)),
	[Client] [int] NOT NULL DEFAULT ((0))
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

/****** Object:  StoredProcedure [dbo].[CWX_Person_GetDynamicFields]    Script Date: 03/12/2009 16:14:59 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Person_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Person_GetDynamicFields]    Script Date: 03/09/2009 11:01:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Thuy Nguyen
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an person
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
	@PersonID int,
	@PageNumber int = 1,
	@Client int = 0,
	@PageSize int = 10, -- it's only used for function parameter
	@PageIndex int = 0 -- it's only used for function parameter
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 			
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[Editable],			
			b.[DataType],
			b.[MaxLength],
			1 as [TableID],
			0 as [DropDown],
			'' as [SQLDropDown]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [GroupID], [GroupDesc], [DisplayOrder],[Editable]
		FROM CWX_PersonInformation_Dict
		WHERE Displayed = 1	and PageNumber = @PageNumber and Client = @Client) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], c.[max_length] as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'PersonInformation' and [Type]='U')			
		) b 
		ON a.[FieldName] = b.[ColumnName]
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = 'PersonID, LastName, FirstName, MiddleName, PString1'
	
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + ',' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = 'SELECT ' + @FieldNameList + ' FROM PersonInformation WHERE PersonID = ' + Cast(@PersonID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup

	DECLARE @PageCount int
	SELECT @PageCount = MAX(PageNumber) 
	FROM CWX_PersonInformation_Dict 
	WHERE Displayed = 1 AND (@Client = 0 OR ISNULL(Client, 0) = 0 OR Client = @Client)

	RETURN @PageCount
END

GO

-- End of ThuyNguyen added on 9-March-2009 --

/****** Object:  StoredProcedure [dbo].[CWX_DEBTOR_DETAILINFOAFTERSAVING]    Script Date: 03/12/2009 16:15:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_DEBTOR_DETAILINFOAFTERSAVING]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_DEBTOR_DETAILINFOAFTERSAVING]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<ThanhNguyen>
-- Create date: <March 10, 2009>
-- Description:	<Update identityfield table when add new debtorinformatio and add 9 records to PersonPhone and PersonAddress>
-- =============================================
CREATE PROCEDURE [dbo].[CWX_DEBTOR_DETAILINFOAFTERSAVING]	
	@PersonID int,
	@EmployeeID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from	
	SET NOCOUNT ON;
    
	UPDATE IdentityFields
	SET FieldValue = FieldValue + 1
	WHERE LOWER(TableName) = LOWER('PersonInformation')
	
	DECLARE @DebtorID int	
	SELECT @DebtorID = MAX(DebtorID) + 1
	FROM DebtorInformation

	UPDATE IdentityFields
	SET FieldValue = FieldValue + 1
	WHERE LOWER(TableName) = LOWER('DebtorInformation')
			
	DECLARE @index int
	DECLARE @num int
	SET @num = 9
	
	DECLARE @AddressID int
	SELECT @AddressID = MAX(AddressID)
	FROM PersonAddress

	UPDATE IdentityFields
	SET FieldValue = FieldValue + @num + 1
	WHERE LOWER(TableName) = LOWER('PersonAddress')

	DECLARE @PhoneID int
	SELECT @PhoneID = MAX(PhoneID)
	FROM PersonPhone

	UPDATE IdentityFields
	SET FieldValue = FieldValue + @num + 1
	WHERE LOWER(TableName) = LOWER('PersonPhone')
	
	SET @index = 1
	WHILE @index <= @num
	BEGIN
		INSERT INTO PersonAddress
		(
			AddressID,
			PersonID,
			AddressType,
			AddressStatus,
			EmployeeID,
			CreateDate
		)
		VALUES
		(
			@AddressID + @index,
			@PersonID,
			@index,
			0,
			@EmployeeID,
			GETDATE()
		)		

		INSERT INTO PersonPhone
		(
			PhoneID,
			PersonID,
			PhoneType,
			PhoneStatus,
			EmployeeID,
			CreateDate
		)
		VALUES
		(
			@PhoneID + @index,
			@PersonID,
			@index,
			0,
			@EmployeeID,
			GETDATE()
		)		

		SET @index = @index + 1
	END	
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Debtor_Search]    Script Date: 03/12/2009 16:09:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Debtor_Search]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Debtor_Search]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Debtor_Search]    Script Date: 03/12/2009 16:06:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 05 Mar 2009
-- Description:	Search debtor by debtor's name and group name
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Debtor_Search]
	-- Add the parameters for the stored procedure here
	@DebtorName varchar(50) = '',
	@GroupName varchar(50) = '',
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @Sql nvarchar(1000), @Params nvarchar(100)
	DECLARE @NewLine varchar(2)
	SET @NewLine = '
'

	SET @Params = '@PageSize int, @PageIndex int, @RowCount int OUTPUT'
	SET @Sql = 
'SELECT ROW_NUMBER() OVER (ORDER BY d.GroupName) as RowNumber,
		d.DebtorID, d.GroupName, 
		ISNULL(p.FirstName,'''') + '' '' + ISNULL(p.MiddleName,'''') + '' '' + ISNULL(p.LastName,'''') as FullName
INTO #temp
FROM DebtorInformation d
	INNER JOIN PersonInformation p ON d.PersonID = p.PersonID
WHERE 1=1' + @NewLine

	IF (@DebtorName <> '')
		SET @Sql = @Sql + 'AND (p.FirstName like ''@@DebtorName%'' OR p.MiddleName like ''@@DebtorName%'' OR p.LastName like ''@@DebtorName%'')' + @NewLine
	
	IF (@GroupName <> '')
		SET @Sql = @Sql + 'AND d.GroupName = ' + @GroupName + @NewLine

	SET @Sql = @Sql + 'SELECT @RowCount = COUNT(*) FROM #temp' + @NewLine
	SET @Sql = @Sql + 
'SELECT DebtorID, GroupName, FullName FROM #temp
WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize'

	SET @Sql = REPLACE(@Sql, '@@DebtorName', @DebtorName)

	DECLARE @RowCount int
	Exec sp_executesql @Sql, @Params, @PageSize, @PageIndex, @RowCount OUTPUT

	RETURN @RowCount
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDynamicFields]    Script Date: 03/12/2009 16:09:18 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetDynamicFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDynamicFields]    Script Date: 03/12/2009 16:07:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an account
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetDynamicFields]
	-- Add the parameters for the stored procedure here
	@AccountID int,
	@PageNumber int = 1,
	@ClientID int = 0,
	@PageSize int = 1, -- it's only used for function parameter
	@PageIndex int = 0 -- it's only used for function parameter
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Get the dynamic fields's info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[TableID],
			a.[DropDown],
			b.[DataType],
			b.[MaxLength],
			CASE WHEN a.[DropDown] > 0 THEN (SELECT [SQL] FROM CWX_DropDownDataDictionary WHERE ID = a.[DropDown])
				ELSE ''
			END AS SQLDropDown
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], [DisplayOrder], [DropDown], [TableID]
		FROM CWX_AccountInformation_Dict
		WHERE Displayed = 1	AND PageNumber = @PageNumber
			AND (@ClientID = 0 OR ISNULL(Client, 0) = 0 OR Client = @ClientID)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], c.[max_length] as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'Account' AND [Type]='U')
			OR object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N'AccountOther' AND [Type]='U')
		) b 
		ON a.[FieldName] = b.[ColumnName]
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList_Account varchar(4000), @FieldNameList_AccountOther varchar(4000)
	DECLARE @FieldName varchar(50), @TableID int
	SET @FieldNameList_Account = 'AccountID,InvoiceNumber,DebtorID,EmployeeID,ClientID,QueueDate,AgencyStatusID,SystemStatusID,ActionCodeID,OfficeID,MCode,CCode,BucketMovement,SubmissionDate,LastEditDate,LastEditBy,CurrencyCode,InterfaceID,CloseDate'
	SET @FieldNameList_AccountOther = 'AccountID'

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName, TableID FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF (@TableID = 1) -- Account table
			SET @FieldNameList_Account = @FieldNameList_Account + ',' + @FieldName
		ELSE IF (@TableID = 2) -- AccountOther table
			SET @FieldNameList_AccountOther = @FieldNameList_AccountOther + ',' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql1 varchar(1000), @Sql2 varchar(1000)
	SET @Sql1 = 'SELECT ' + @FieldNameList_Account + ' FROM Account WHERE AccountID = ' + Cast(@AccountID as varchar)
	SET @Sql2 = 'SELECT ' + @FieldNameList_AccountOther + ' FROM AccountOther WHERE AccountID = ' + Cast(@AccountID as varchar)
	
	EXEC (@Sql1)
	EXEC (@Sql2)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

	DECLARE @PageCount int
	SELECT @PageCount = MAX(PageNumber) 
	FROM CWX_AccountInformation_Dict 
	WHERE Displayed = 1 AND (@ClientID = 0 OR ISNULL(Client,0) = 0 OR Client = @ClientID)

	RETURN @PageCount
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_IsAccountNumberExisted]    Script Date: 03/12/2009 16:08:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_IsAccountNumberExisted]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_IsAccountNumberExisted]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_IsAccountNumberExisted]    Script Date: 03/12/2009 16:07:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 10 Mar 2009
-- Description:	Check if an account number is existed
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_IsAccountNumberExisted]
	-- Add the parameters for the stored procedure here
	@AccountNumber varchar(50) = '',
	@AccountID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS (SELECT 1 FROM Account WHERE @AccountNumber <> '' AND InvoiceNumber = @AccountNumber AND AccountID <> @AccountID)
		RETURN 1
	ELSE 
		RETURN 0
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_Account_DetailInfoAfterSaving]    Script Date: 03/12/2009 16:12:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_DetailInfoAfterSaving]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_DetailInfoAfterSaving]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_DetailInfoAfterSaving]    Script Date: 03/12/2009 16:14:04 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 11 Mar 2009
-- Description:	Update identity fields after saving account information
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_DetailInfoAfterSaving]
	-- Add the parameters for the stored procedure here
	@AccountID int	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Increase 'Account' by one
	UPDATE IdentityFields 
	SET FieldValue = FieldValue + 1 
	WHERE TableName = 'Account'

END
GO

GO
/****** Object:  Table [dbo].[CWX_DropDownDataDictionary]    Script Date: 03/13/2009 17:25:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CWX_DropDownDataDictionary](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SQL] [varchar](max) NULL,
 CONSTRAINT [PK_CWX_DropDownDataDictionary] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

------

if not exists (select * from InformationTable where Description='Show Debtor Management')
	insert into InformationTable values (1, 17, 0, '', 'Show Debtor Management', '', 'True', 'A')
	