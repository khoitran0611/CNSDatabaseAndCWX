﻿-- [10-Oct-2009] [Minh Dam] Alter SP [CWX_ClientCommModel_GetPagingList]
/****** Object:  StoredProcedure [dbo].[CWX_ClientCommModel_GetPagingList]    Script Date: 10/09/2009 09:29:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 25 May 2009
-- Description:	Get list of client commission model with paging
-- =============================================
ALTER PROCEDURE [dbo].[CWX_ClientCommModel_GetPagingList]
	-- Add the parameters for the stored procedure here
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @RowCount int

	SELECT @RowCount = Count(*)
	FROM CWX_ClientCommModel a
		INNER JOIN ClientInformation b ON a.ClientID = b.ClientID AND b.Status <> 'R'
	WHERE a.Status <> 'R'

    -- Insert statements for procedure here
	WITH temp AS
	(
		SELECT	ROW_NUMBER() OVER (ORDER BY b.ClientName) as RowNumber,
				a.ID,
				b.ClientID, 
				b.ClientName,
				c.Description as ClientType, 
				a.Code as ModelCode, 
				a.Description as ModelDescription,
				a.IsActive
		FROM CWX_ClientCommModel a
			INNER JOIN ClientInformation b ON a.ClientID = b.ClientID AND b.Status <> 'R'
			LEFT JOIN CWX_ClientType c ON b.ClientTypeID = c.ClientTypeID AND c.Status <> 'R'
		WHERE a.Status <> 'R'
	)

	SELECT ID, ClientID, ClientName, ClientType, ModelCode, ModelDescription, IsActive
	FROM temp
	WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize

	RETURN @RowCount
END
GO 