﻿/****** Object:  StoredProcedure [dbo].[CWX_Person_GetDynamicFields]    Script Date: 06/26/2009 17:01:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Person_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDynamicFields]    Script Date: 06/26/2009 17:01:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Account_GetDynamicFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 06/26/2009 17:01:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Product_GetDynamicFields]    Script Date: 06/26/2009 17:01:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetDynamicFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Product_GetDynamicFields]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Collateral_GetDynamicFields]    Script Date: 06/26/2009 17:01:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Collateral_GetDynamicFields]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'

-- =============================================
-- Author:		Minh Dam
-- Create date: 15/08/2008
-- Description:	Get dynamic fields of a collateral
-- History:
--	[06 Mar 2009]	Thuy Nguyen		Init version.
--	[20 Mar 2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN (''nvarchar'', ''nchar'') THEN ... END as [MaxLength]"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory", "RangeID", "DropDown", "SQLDropDown", "Listed" field columns into returned dynamic fields tables
--	[26-Jun-2009]	ThanhNguyen		Change default value of @TabID from 1 to -1. If @TabID = -1 then get first TabID of @CLientID
-- =============================================				
CREATE PROCEDURE [dbo].[CWX_Collateral_GetDynamicFields]
	@CollateralID int,
	@TabID int = -1,
	@ClientID int = 0,
	@CollateralTypeID int = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @CollateralID > 0 AND @CollateralTypeID IS NULL
		SELECT @CollateralTypeID = CollateralType FROM Collateral WHERE ID = @CollateralID
	
	-- Get first tabID of ClientID
	IF(@TabID = -1)
	BEGIN
		DECLARE @AllTabsTable TABLE
		(	TabID int,
			TabDesc nvarchar(1000)	
		)

		INSERT INTO @AllTabsTable
		exec CWX_Collateral_GetAllTabs  @CollateralID, @ClientID,@CollateralTypeID
		SELECT top 1 @TabID = TabID FROM @AllTabsTable 	
	END

    -- Get the dynamic fields''s info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc],
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc],
			a.[DisplayOrder],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '''') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], 
				[DisplayOrder], [DropDown], [RangeID], [Mandatory]
		FROM CWX_Collateral_Dict
		WHERE Displayed = 1 AND TabID = @TabID
			AND (@ClientID = 0 OR ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)
			AND (@CollateralTypeID = 0 OR ISNULL(CollateralTypeID, 0) = 0 OR CollateralTypeID = @CollateralTypeID)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN (''nvarchar'', ''nchar'') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N''Collateral'' and [Type]=''U'')
			AND (c.[name] LIKE ''CInt%'' OR c.[name] LIKE ''CString%'' OR c.[name] LIKE ''CDate%'' OR c.[name] LIKE ''CMoney%'')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = ''ID,AccountID,HostCollateralID,EmployeeID,NextActionDate,Image,ImageFileName,''
	SET @FieldNameList = @FieldNameList + 
		''(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralType],6) IS NOT NULL THEN CollateralType ELSE 0 END) AS CollateralType,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([CollateralStage],7) IS NOT NULL THEN CollateralStage ELSE 0 END) AS CollateralStage,
		(CASE WHEN dbo.CWX_AccountCodeMaster_GetCodeDescription([NextAction],2) IS NOT NULL THEN NextAction ELSE 0 END) AS NextAction''
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + '','' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = ''SELECT '' + @FieldNameList + '' FROM Collateral WHERE ID = '' + Cast(@CollateralID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields

	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Product_GetDynamicFields]    Script Date: 06/26/2009 17:01:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Product_GetDynamicFields]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		Minh Dam
-- Create date: 17 Mar 2009
-- Description:	Get dynamic fields and data of an client
-- History:
--	[17 Mar 2009]	Minh Dam	Init version.
--	[22-Apr-2009]	Minh Dam	Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam	Remove parameters @PageSize, @PageIndex
--								Rename parameter @PageNumber to @TabID
--								Change from Page view to Tab view
--	[26-June-2009]	ThanhNguyen	Change default value of @TabID  from 1 to -1. If @TabID = -1 then get first tabID of ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Product_GetDynamicFields]
	-- Add the parameters for the stored procedure here
	@ClientID int,
	@TabID int = -1,
	@ClientDictID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	IF(@TabID = -1)
	BEGIN
		DECLARE @AllTabsTable TABLE
		(	TabID int,
			TabDesc nvarchar(1000)	
		)

		INSERT INTO @AllTabsTable
		exec [CWX_Product_GetAllTabs] @ClientID
		SELECT top 1 @TabID = TabID FROM @AllTabsTable 	
	END
    -- Get the dynamic fields''s info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '''') as [SQLDropDown],
			ISNULL(c.[Listed], 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], [Editable], [GroupID], [GroupDesc], 
				[DisplayOrder], [DropDown], [RangeID], [Mandatory]
		FROM CWX_ClientInformation_Dict
		WHERE Displayed = 1	AND TabID = @TabID AND (ClientID = @ClientDictID OR ISNULL(ClientID,0) = 0)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN (''nvarchar'', ''nchar'') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N''ClientInformation'' AND [Type]=''U'')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000)
	DECLARE @FieldName varchar(50)
	SET @FieldNameList = ''ClientID,ClientName,Priority,AgingForReschedule,AgingForDiscount,RescheduleAllowed,DiscountAllowed,LetterheadImage,CreditorID,PaymentAllocationRuleID,AgingForApportion,ApportionAllowed'' --ClientActive

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + '','' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(1000)
	SET @Sql = ''SELECT '' + @FieldNameList + '' FROM ClientInformation WHERE ClientID = '' + Cast(@ClientID as varchar)
	
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Person_GetDynamicFields]    Script Date: 06/26/2009 17:01:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Person_GetDynamicFields]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Thuy Nguyen
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an person
-- History:
--	[06-Mar-2009]	Thuy Nguyen		Init version.
--	[20-Mar-2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN (''nvarchar'', ''nchar'') THEN ... END as [MaxLength]"
--	[10-Apr-2009]	Thanh Nguyen	Add parameter "@CMSEditable"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam		Rename parameter @PageNumber to @TabID
--									Rename parameter @Client to @ClientID
--									Remove parameters @PageSize, @PageIndex
--									Change from Page view to Tab view
--  [02-June-2009]	ThanhNguyen		Remove @ClientID from parameter list. Because base on Issue 68: DebtorInformation And PersonInformation don''t have ClientID
--  [26-June-2009]	ThanhNguyen		Change default value of @TabID  from 1 to -1. If @TabID = -1 then first tabID will be got
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Person_GetDynamicFields]
	@PersonID int,
	@TabID int = -1,	
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--In case dont pass TabID, first tab of ClientID will be selected
	IF(@TabID = -1)
	BEGIN
		DECLARE @AllTabsTable TABLE
		(	TabID int,
			TabDesc nvarchar(1000)	
		)

		INSERT INTO @AllTabsTable
		exec [CWX_PersonInformation_GetAllTabs]
		SELECT top 1 @TabID = TabID FROM @AllTabsTable 	
	END
	--
    -- Get the dynamic fields''s info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc],
			b.[DataType],
			b.[MaxLength],
			a.[Editable],
			a.[GroupID],
			a.[GroupDesc], 
			a.[DisplayOrder],			
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '''') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], CASE WHEN @CMSEditable = 1 THEN [CMSEdit] ELSE [Editable] END as [Editable],
				[GroupID], [GroupDesc], [DisplayOrder], [RangeID], [DropDown], [Mandatory]
		FROM	CWX_PersonInformation_Dict
		WHERE	Displayed = 1 AND TabID = @TabID
				AND (@CMSEditable = 0 OR (@CMSEditable = 1 AND [CMSEdit] = 1))				
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType],
				CASE WHEN t.[name] IN (''nvarchar'', ''nchar'') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N''PersonInformation'' and [Type]=''U'')			
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList varchar(4000), @FieldName varchar(50)
	SET @FieldNameList = ''PersonID, LastName, FirstName, MiddleName, PString1''
	
	DECLARE curFieldName CURSOR FOR
		SELECT FieldName FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @FieldNameList = @FieldNameList + '','' + @FieldName;
		FETCH NEXT FROM curFieldName INTO @FieldName
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql varchar(4000)
	SET @Sql = ''SELECT '' + @FieldNameList + '' FROM PersonInformation WHERE PersonID = '' + Cast(@PersonID as varchar)
	EXEC (@Sql)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup

END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[CWX_Account_GetDynamicFields]    Script Date: 06/26/2009 17:01:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Account_GetDynamicFields]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		Minh Dam
-- Create date: 06 Mar 2009
-- Description:	Get dynamic fields and data of an account
-- History:
--	[06-Mar-2009]	Minh Dam		Init version.
--	[20-Mar-2009]	Minh Dam		Insert code: "AND c.[user_type_id] = t.[user_type_id]"
--									Insert code: "CASE WHEN t.[name] IN (''nvarchar'', ''nchar'') THEN ... END as [MaxLength]"
--	[10-Apr-2009]	Thanh Nguyen	Add parameter "@CMSEditable"
--	[22-Apr-2009]	Minh Dam		Add "Mandatory" field column into returned dynamic fields tables
--	[27-Apr-2009]	Minh Dam		Remove parameters @PageSize, @PageIndex
--									Rename parameter @PageNumber to @TabID
--									Change from Page view to Tab view
--  [26-June-2009]	ThanhNguyen		Change default value of @TabID from 1 to -1. If @TabID = -1 Then get the first tab of ClientID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_Account_GetDynamicFields]
	@AccountID int,
	@TabID int = -1, 
	@ClientID int = 0, -- if @ClientID <= 0 then set @ClientID equals ClientID of account
	@CMSEditable bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF (@AccountID > 0 AND @ClientID <= 0)
		SELECT @ClientID = ClientID
		FROM Account
		WHERE AccountID = @AccountID
	--In case dont pass TabID, first tab will be selected
	IF(@TabID = -1)
	BEGIN
		DECLARE @AllTabsTable TABLE
		(	TabID int,
			TabDesc nvarchar(1000)	
		)

		INSERT INTO @AllTabsTable
		exec [CWX_AccountInformation_GetAllTabs] @ClientID		
		SELECT top 1 @TabID = TabID FROM @AllTabsTable 	
	END
	
    -- Get the dynamic fields''s info: name, desc, data type, max length, ... from Dictionary
	SELECT	a.[FieldName], 
			a.[FieldDesc], 
			b.[DataType],
			b.[MaxLength],
			a.[Editable], 
			a.[GroupID], 
			a.[GroupDesc], 
			a.[DisplayOrder],
			a.[TableID],
			a.[Mandatory],
			a.[RangeID],
			a.[DropDown],
			ISNULL(c.[SQL], '''') as [SQLDropDown],
			ISNULL(c.Listed, 0) as [Listed],
			ISNULL(c.[Lookup], 0) as [Lookup]
	INTO #DynamicFields
	FROM 
		(SELECT [FieldName], [FieldDesc], CASE WHEN @CMSEditable = 1 THEN [CMSEdit] ELSE [Editable] END as [Editable], 
				[GroupID], [GroupDesc], [DisplayOrder], [RangeID], [DropDown], [TableID], [Mandatory]
		FROM CWX_AccountInformation_Dict
		WHERE Displayed = 1	AND TabID = @TabID
			AND (@CMSEditable = 0 OR (@CMSEditable = 1 AND [CMSEdit] = 1))
			AND (ISNULL(ClientID, 0) = 0 OR ClientID = @ClientID)
		) a
		INNER JOIN
		(SELECT c.[name] as [ColumnName], t.[name] as [DataType], 
				CASE WHEN t.[name] IN (''nvarchar'', ''nchar'') THEN c.[max_length] / 2 -- nvarchar, nchar are stored 2 bytes
					ELSE c.[max_length]
				END as [MaxLength]
		FROM sys.columns c INNER JOIN sys.types t ON c.[system_type_id] = t.[system_type_id] AND c.[user_type_id] = t.[user_type_id]
		WHERE object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N''Account'' AND [Type]=''U'')
			OR object_id = (SELECT [object_id] FROM sys.objects WHERE [Name] = N''AccountOther'' AND [Type]=''U'')
		) b 
		ON a.[FieldName] = b.[ColumnName]
		LEFT JOIN CWX_DropDownDataDictionary c ON a.[DropDown] = c.ID
	ORDER BY a.[GroupID], a.[DisplayOrder]	

	-- Get the data
	DECLARE @FieldNameList_Account varchar(4000), @FieldNameList_AccountOther varchar(4000)
	DECLARE @FieldName varchar(50), @TableID int
	SET @FieldNameList_Account = ''AccountID,InvoiceNumber,DebtorID,EmployeeID,ClientID,QueueDate,AgencyStatusID,SystemStatusID,ActionCodeID,OfficeID,MCode,CCode,BucketMovement,SubmissionDate,LastEditDate,LastEditBy,CurrencyCode,InterfaceID,CloseDate''
	SET @FieldNameList_AccountOther = ''AccountID''

	DECLARE curFieldName CURSOR FOR
		SELECT FieldName, TableID FROM #DynamicFields
	OPEN curFieldName
	FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF (@TableID = 1) -- Account table
			SET @FieldNameList_Account = @FieldNameList_Account + '','' + @FieldName
		ELSE IF (@TableID = 2) -- AccountOther table
			SET @FieldNameList_AccountOther = @FieldNameList_AccountOther + '','' + @FieldName
		FETCH NEXT FROM curFieldName INTO @FieldName, @TableID
	END
	
	CLOSE curFieldName
	DEALLOCATE curFieldName
	
	DECLARE @Sql1 varchar(1000), @Sql2 varchar(1000)
	SET @Sql1 = ''SELECT '' + @FieldNameList_Account + '' FROM Account WHERE AccountID = '' + Cast(@AccountID as varchar)
	SET @Sql2 = ''SELECT '' + @FieldNameList_AccountOther + '' FROM AccountOther WHERE AccountID = '' + Cast(@AccountID as varchar)
	
	EXEC (@Sql1)
	EXEC (@Sql2)

	-- Get the dynamic field belong to group
	DECLARE @GroupID int
	DECLARE curGroup CURSOR FOR 
		SELECT DISTINCT [GroupID] FROM #DynamicFields
	OPEN curGroup
	FETCH NEXT FROM curGroup INTO @GroupID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SELECT * FROM #DynamicFields WHERE GroupID = @GroupID
		FETCH NEXT FROM curGroup INTO @GroupID
	END
	
	CLOSE curGroup
	DEALLOCATE curGroup	

END
' 
END
GO
