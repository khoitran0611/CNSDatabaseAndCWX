-- Scripts are applied on version 1.9.7

-- =======================================================================
-- Author:		Tuan Luong
-- Create date: Jun 11, 2008
-- Description:	Add column 'Status' with default value 'A'
--			    use this field to mark the row is active 'A' or retire 'R'
-- =======================================================================
IF NOT EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_CustomFieldTypes' and c.name = 'Status')
BEGIN
	ALTER TABLE Legal_CustomFieldTypes
	ADD Status char(1) NOT NULL
		CONSTRAINT [Legal_CustomFieldTypes_RowStatus] DEFAULT 'A'
END
GO

-- =======================================================================
-- Author:		Tuan Luong
-- Create date: Jun 11, 2008
-- Description:	Drop column 'Length'
-- =======================================================================
IF EXISTS (SELECT c.name FROM sys.objects o INNER JOIN sys.columns c ON o.object_id = c.object_id WHERE o.name = 'Legal_CustomFieldTypes' and c.name = 'Length')
BEGIN
	ALTER TABLE Legal_CustomFieldTypes
	DROP COLUMN Length		
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFieldTypes_DeleteAll]    Script Date: 06/11/2008 18:04:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_CustomFieldTypes_DeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_Legal_CustomFieldTypes_DeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_Legal_CustomFieldTypes_DeleteAll]    Script Date: 06/11/2008 18:04:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_Legal_CustomFieldTypes_DeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================================
-- Author:		Tuan Luong
-- Create date: Jun 11, 2008
-- Description:	Delete all records in Legal_CustomFieldTypes Table
-- Parameters: 
--	@Type: ''S'' - Soft delete
--		   ''P'' - Permanently delete
-- =============================================================
CREATE PROCEDURE [dbo].[CWX_Legal_CustomFieldTypes_DeleteAll] 	
	@Status char(1) = ''S''		
AS
BEGIN
	SET NOCOUNT ON;
	IF UPPER(@Status) = ''S''
	BEGIN
		UPDATE Legal_CustomFieldTypes
		SET [Status] = ''R''
		WHERE [Status] = ''A''
	END
	ELSE IF UPPER(@Status) = ''P''
	BEGIN    
		DELETE Legal_CustomFieldTypes
	END
END

' 
END
GO

/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_PromiseFrequency_SoftDeleteAll]    Script Date: 06/11/2008 18:05:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_PromiseFrequency_SoftDeleteAll]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_InformationTable_PromiseFrequency_SoftDeleteAll]
GO
/****** Object:  StoredProcedure [dbo].[CWX_InformationTable_PromiseFrequency_SoftDeleteAll]    Script Date: 06/11/2008 18:05:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_InformationTable_PromiseFrequency_SoftDeleteAll]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- ===================================================================================
-- Author:		Binh Truong
-- Create date: Jun 11, 2008
-- Description:	Delete all standard notes (InfoID = 4, InfoType = 1, InfoSubType = 0)
-- ===================================================================================
create PROCEDURE [dbo].[CWX_InformationTable_PromiseFrequency_SoftDeleteAll] 
	@InfoID int = 4,
	@InfoType int = 1,
	@InfoSubType int = 0	
AS
BEGIN
	UPDATE
		InformationTable
	SET
		Status = ''R''
	WHERE
			InfoID = @InfoID
			AND	InfoType = @InfoType
			AND InfoSubType = @InfoSubType
			AND Value <> ''1 d''
END
' 
END
GO
/******  Script Closed. Go next: Step013_7  ******/