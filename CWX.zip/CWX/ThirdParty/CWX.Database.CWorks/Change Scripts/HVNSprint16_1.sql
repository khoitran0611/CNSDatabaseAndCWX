﻿ 
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'TransactionType' AND COLUMN_NAME = 'IsHostPaymentType')
BEGIN
	ALTER TABLE [dbo].[TransactionType] 
		ADD [IsHostPaymentType] bit not null default 0
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionType_GetCustom]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[CWX_TransactionType_GetCustom]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Description:	Get transaction type where AffectBalance are Increase or NoEffect.
-- History:
--	2008/11/05	[Binh Truong]	Init version.
--  2009/10/28  [Phuong Le]	Only get transaction types has IsHostPaymentType = 0
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TransactionType_GetCustom]
	@financialTypeID int = 0
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @sql nvarchar(500)
	set @sql = ' SELECT *' +
			   ' FROM TransactionType' +
			   ' WHERE Status <> ''R'' AND (AffectBalance = 1 OR AffectBalance = 0) AND IsHostPaymentType = 0'
	if(@financialTypeID > 0)
	BEGIN
		set @sql = @sql + ' AND FinancialTypeID = ' + str(@financialTypeID)
	END
	set @sql = @sql + ' ORDER BY TransactionCode	'
	EXEC (@sql)		
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_TransactionType_GetByGroupStepType]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[CWX_TransactionType_GetByGroupStepType]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Minh Dam
-- Create date: 2009-07-31
-- Description:	Get all transaction types defined for a legal group step type
--  2009/10/28  [Phuong Le]	Only get transaction types has IsHostPaymentType = 0
-- =============================================
CREATE PROCEDURE [dbo].[CWX_TransactionType_GetByGroupStepType]
	@GroupStepTypeID int,
	@financialTypeID int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @sql nvarchar(1000)

	SET @sql = ' SELECT	t.ID, t.TransactionCode, f.LabelDesc ' + 'Description' +
				 ' FROM TransactionType t
					INNER JOIN CWX_LegalStepFees_Dict f on f.TransTypeID = t.ID
						Where t.IsHostPaymentType = 0 and f.Displayed = 1 and f.TransTypeID > 0	and f.GroupStepTypeID = ' +  str(@GroupStepTypeID) 


--	SET @sql = ' SELECT	ID, TransactionCode,[Description]
--				 FROM TransactionType 
--				 WHERE ID IN (	SELECT TransTypeID
--								FROM CWX_LegalStepFees_Dict
--								WHERE Displayed = 1 AND  TransTypeID > 0 AND GroupStepTypeID = ' +  str(@GroupStepTypeID) + ')'								
	
	IF(@financialTypeID > 0)
	BEGIN
		SET @sql = @sql + ' AND t.FinancialTypeID = ' + str(@financialTypeID)
	END
	SET @sql = @sql + ' ORDER BY t.TransactionCode'
    EXEC(@sql)
	
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommission_GetTransactionsWithPagingList]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[CWX_ClientCommission_GetTransactionsWithPagingList]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Phuong Le
-- Create date: 26 Oct, 2009
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommission_GetTransactionsWithPagingList]
	@ClientID int,
	@TransDateFrom datetime,
	@TransDateTo datetime,
	@GetForTransactionTypePlan bit,
	@PageSize int = 10,
	@PageIndex int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @SQLBuilder nvarchar(max)
	SET @SQLBuilder = 'SELECT ROW_NUMBER() OVER (ORDER BY t.TransactionID) as RowNumber, '
	SET @SQLBuilder = @SQLBuilder + 't.TransactionID, t.DateOfTransaction, t.TransactionAmount, '
	SET @SQLBuilder = @SQLBuilder + 't.TransactionComment, ISNULL(tt.TransactionCode + '' - '' + tt.Description, '''') as TransactionCodeDescription, '
	SET @SQLBuilder = @SQLBuilder + 'ISNULL(e.UserID,'''') as UserID, Case WHEN c.RecordID is null then ''false'' else ''true'' end as Calculated '
	SET @SQLBuilder = @SQLBuilder + 'FROM transactions t '
	SET @SQLBuilder = @SQLBuilder + 'LEFT JOIN TransactionType tt ON t.TransactionType = tt.ID '
	SET @SQLBuilder = @SQLBuilder + 'LEFT JOIN CWX_ClientCommission c ON t.TransactionID = c.TransactionID and c.[status] <> ''R'' '
	SET @SQLBuilder = @SQLBuilder + 'LEFT JOIN Employee e ON e.EmployeeID = t.EmployeeID '
	SET @SQLBuilder = @SQLBuilder + 'WHERE t.ClientID = @ClientID '
	SET @SQLBuilder = @SQLBuilder + 'AND DATEDIFF(day, @TransDateFrom, t.DateOfTransaction) >= 0 '
	SET @SQLBuilder = @SQLBuilder + 'AND DATEDIFF(day, t.DateOfTransaction, @TransDateTo) >= 0 '
	SET @SQLBuilder = @SQLBuilder + 'AND t.ReversedFlag = 0 '

	IF @GetForTransactionTypePlan = 0
	BEGIN
		SET @SQLBuilder = @SQLBuilder + 'AND ((t.TransactionType = 901 AND ISNULL(ParentTransactionID, 0) = 0) OR ISNULL(tt.IsHostPaymentType, 0) = 1) '		
	END
	ELSE
	BEGIN
		SET @SQLBuilder = @SQLBuilder + 'AND (ISNULL(ParentTransactionID, 0) > 0 OR ISNULL(tt.IsHostPaymentType,0) = 1) '
	END
	
    -- Insert statements for procedure here
	DECLARE @rowCount int		
	
	DECLARE	@Params nvarchar(2000) 
	SET @Params = '@ClientID int,
		@TransDateFrom datetime,
		@TransDateTo datetime,
		@rowCount int output'
	
	DECLARE @SQLMain nvarchar(max)	
	SET @SQLMain = 'SELECT @rowCount = count(*) FROM ( ' + @SQLBuilder + ') as result'
	exec sp_executesql	@SQLMain , @Params, @ClientID= @ClientID,
															@TransDateFrom = @TransDateFrom,
															@TransDateTo = @TransDateTo,
															@rowCount = @rowCount output
	SET @Params = '@ClientID int,
		@TransDateFrom datetime,
		@TransDateTo datetime,
		@PageIndex int,
		@PageSize int'
	
	SET @SQLMain = 'SELECT * FROM ( ' + @SQLBuilder + ') as result '
	SET @SQLMain = @SQLMain + 'WHERE RowNumber BETWEEN @PageIndex * @PageSize + 1 AND (@PageIndex + 1) * @PageSize'
	exec sp_executesql	@SQLMain , @Params, @ClientID= @ClientID,
											@TransDateFrom = @TransDateFrom,
											@TransDateTo = @TransDateTo,
											@PageIndex = @PageIndex,
											@PageSize = @PageSize

	RETURN @rowCount
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_ClientCommission_CalculateCommissionByCommRate]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionByCommRate]
GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_CalculateCommissionByCommRate]    Script Date: 10/28/2009 15:12:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 07 Oct, 2009
-- Description:	Calculate commission and tax for each client by commission rate
-- =============================================
CREATE PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionByCommRate]
	@ClientID int,
	@TransDateFrom datetime,
	@TransDateTo datetime,
	@Recalculate bit = 0,
	@CalculatedDate datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	DECLARE @result tinyint
	DECLARE @commModel_ModelType tinyint, @commModel_CommRateID int
	DECLARE @commModel_CommPlanID int, @commModel_Minimum money, @commModel_Maximum money

	-- Get commission model info. of the client
	SELECT	@commModel_ModelType = ModelType,
			@commModel_CommRateID = ClientCommRateID,
			@commModel_CommPlanID = ClientCommPlanID,
			@commModel_Minimum = Minimum,
			@commModel_Maximum = Maximum
	FROM CWX_ClientCommModel 
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'

	
	-- Get commission rate info.
	DECLARE @commRate_ID int, @commRate_StartDate datetime, @commRate_EndDate datetime
	DECLARE @commRate_RateType int, @commRate_RateAmount money	
	SELECT	@commRate_ID = ID,
			@commRate_StartDate = StartDate,
			@commRate_EndDate = EndDate,
			@commRate_RateType = RateType,
			@commRate_RateAmount = RateAmount
	FROM CWX_ClientCommRate
	WHERE ID = @commModel_CommRateID


	-- Get the client properties info
	DECLARE @properties_TaxExempt bit, @properties_AddCommissionToOwing bit		
	SELECT  @properties_TaxExempt = TaxExempt,
			@properties_AddCommissionToOwing = AddCommissionToOwing
	FROM CWX_ClientProperties
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Get the client tax info.
	DECLARE @tax_TaxType int, @tax_TaxRate decimal(19,5), @tax_CalculateTax bit, @tax_TaxTypeValue nvarchar(50)
	SELECT	@tax_TaxType = TaxType,
			@tax_TaxRate = TaxRate,
			@tax_CalculateTax = CalculateTax,
			@tax_TaxTypeValue = ISNULL(b.Value, '')
	FROM CWX_ClientTax a
		LEFT JOIN CWX_ClientPropertySettings b ON a.TaxType = b.ID
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Retrieve suitable transactions of accounts of client
	DECLARE curTrans CURSOR FOR
		SELECT	t.TransactionID, t.AccountID, t.EmployeeID, 
				t.DateOfTransaction, t.TransactionAmount
		FROM Transactions t
		LEFT JOIN TransactionType tt
			ON t.TransactionType = tt.ID
		WHERE t.ClientID = @ClientID
			AND DATEDIFF(day, @TransDateFrom, t.DateOfTransaction) >= 0
			AND DATEDIFF(day, t.DateOfTransaction, @TransDateTo) >= 0
			AND ( (t.TransactionType = 901 AND ISNULL(t.ParentTransactionID, 0) = 0) OR ISNULL(tt.IsHostPaymentType, 0) = 1)
			AND t.ReversedFlag = 0			
			AND (@Recalculate = 1 OR t.TransactionID NOT IN (SELECT TransactionID FROM CWX_ClientCommission WHERE [Status] <> 'R'))


	DECLARE @transactionID int, @accountID int, @employeeID int, @dateOfTransaction datetime, @transactionAmount money
	DECLARE @commissionAmount money, @taxAmount money
	DECLARE @commRateAmount money -- used to store rate percent or rate amount
	DECLARE @rateSlab_Minimum money, @rateSlab_Maximum money
	DECLARE @commAmountMinimum money, @commAmountMaximum money
	DECLARE @clientPart money, @agencyPart money, @collectorPart money
	
	BEGIN TRAN
	BEGIN TRY
		-- Go thru each transaction record to calculate commission and tax
		OPEN curTrans
		FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
										@dateOfTransaction, @transactionAmount
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			-- CALCULATE COMMISSION BASE ON RATE TYPE
			SET @commRateAmount = 0
			SET @commAmountMinimum = @commModel_Minimum
			SET @commAmountMaximum = @commModel_Maximum

			-- Check if the transaction date is valid for this commission rate.
			IF (DATEDIFF(day, @commRate_StartDate, @dateOfTransaction) >= 0)
				AND (@commRate_EndDate IS NULL OR DATEDIFF(day, @dateOfTransaction, @commRate_EndDate) >= 0)
			BEGIN
				IF @commRate_RateType IN (1,3) -- Flat Rate or Flat Amount
					SET @commRateAmount = @commRate_RateAmount	
				ELSE IF @commRate_RateType IN (2, 4) -- Tiered Rate or Tiered Amount
				BEGIN
					SEt @rateSlab_Minimum = NULL; SET @rateSlab_Maximum =  NULL
					SELECT TOP 1 @commRateAmount = RateAmount,
								@rateSlab_Minimum = Minimum,
								@rateSlab_Maximum = Maximum							
					FROM CWX_ClientCommRateSlab
					WHERE ClientCommRateID = @commRate_ID
						AND @transactionAmount BETWEEN FromValue AND ToValue
				END

				IF @commRate_RateType IN (1,2) -- Flat Rate or Tiered Rate					
				BEGIN
					IF (@properties_AddCommissionToOwing = 1)
						SET @commissionAmount = @transactionAmount * (@commRateAmount/100) / (1 + @commRateAmount/100)
					ELSE
						SET @commissionAmount = @transactionAmount * @commRateAmount/100
				END
				ELSE
				BEGIN
					SET @commissionAmount = @commRateAmount
				END

				-- Check the min and max for commssion amount
				IF @commRate_RateType IN (2,4)
				BEGIN
					IF @rateSlab_Minimum IS NOT NULL
						SET @commAmountMinimum = @rateSlab_Minimum

					IF @rateSlab_Maximum IS NOT NULL
						SET @commAmountMaximum = @rateSlab_Maximum
				END
				
				-- Adjust commission amount base on min and max
				IF @commissionAmount < @commAmountMinimum
					SET @commissionAmount = @commAmountMinimum

				IF @commissionAmount > @commAmountMaximum
					SET @commissionAmount = @commAmountMaximum

			END
			ELSE -- The rate is no more valid, set commision amount to minimum value of model
				SET @commissionAmount = @commModel_Minimum


			-- Calculate ClientPart, AgencyPart, CollectorPart amount
			SET @clientPart = @transactionAmount - @commissionAmount
			SET @agencyPart = @commissionAmount
			SET @collectorPart = 0


			-- CALCULATE TAX BASE ON COMMISSION
			SET @taxAmount = 0
			IF (@tax_CalculateTax = 1 AND @properties_TaxExempt = 0)
			BEGIN
				IF (@tax_TaxTypeValue LIKE '%Commission Amount%')
					SET @taxAmount = @commissionAmount * @tax_TaxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Payment Amount%')
					SET @taxAmount = @transactionAmount * @tax_TaxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Agency Part%')
					SET @taxAmount = @agencyPart * @tax_TaxRate/100
			END
		
			-- Delete children transactions of this transaction
			DELETE CWX_ClientCommission
			WHERE TransactionID IN (SELECT TransactionID FROM Transactions WHERE ParentTransactionID = @transactionID)
			
			--Mark delete current transantions were computed
			UPDATE CWX_ClientCommission SET [Status] = 'R' WHERE TransactionID = @transactionID AND [Status] <> 'R'			
			
			-- Insert or Update commission data into CWX_ClientCommission table
			IF NOT EXISTS (SELECT 1 FROM CWX_ClientCommission WHERE TransactionID = @transactionID AND [Status] <> 'R')
				INSERT INTO CWX_ClientCommission (
						TransactionID, 
						AccountID, 
						EmployeeID, 
						PaymentAmount, 
						ClientPart, 
						AgencyPart, 
						CollectorPart, 
						CommissionAmount,
						TaxAmount, 
						RatePercent,
						FixedAmount,
						MinAmount,
						MaxAmount)
				VALUES (
						@transactionID, 
						@accountID, 
						@employeeID, 
						@transactionAmount, 
						@clientPart, 
						@agencyPart, 
						@collectorPart, 
						@commissionAmount, 
						@taxAmount, 
						CASE @commRate_RateType WHEN 1 THEN @commRateAmount WHEN 2 THEN @commRateAmount ELSE NULL END,
						CASE @commRate_RateType WHEN 3 THEN @commRateAmount WHEN 4 THEN @commRateAmount ELSE NULL END,
						@commAmountMinimum,
						@commAmountMaximum)
			--ELSE
			--	UPDATE CWX_ClientCommission 
			--	SET		AccountID = @accountID, 
			--			EmployeeID = @employeeID, 
			--			PaymentAmount = @transactionAmount, 
			--			ClientPart = @clientPart, 
			--			AgencyPart = @agencyPart,
			--			CollectorPart = @collectorPart, 
			--			CommissionAmount = @commissionAmount,
			--			TaxAmount = @taxAmount, 
			--			RatePercent = CASE @commRate_RateType WHEN 1 THEN @commRateAmount WHEN 2 THEN @commRateAmount ELSE NULL END,
			--			FixedAmount = CASE @commRate_RateType WHEN 3 THEN @commRateAmount WHEN 4 THEN @commRateAmount ELSE NULL END,
			--			MinAmount = @commAmountMinimum,
			--			MaxAmount = @commAmountMaximum
			--	WHERE	TransactionID = @transactionID
			--		AND [Status] <> 'R'


			-- Retrieve next record to calculate
			FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
											@dateOfTransaction, @transactionAmount											
		END

		COMMIT TRAN
		SET @result = 1
	END TRY
	-- Catch exception
	BEGIN CATCH
		ROLLBACK TRAN
		SET @result = 0
	END CATCH

	IF (CURSOR_STATUS('global', 'curTrans') >= 0)
	BEGIN
		CLOSE curTrans		
	END
	DEALLOCATE curTrans

	RETURN @result
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_CalculateCommissionByRuleRate]    Script Date: 10/28/2009 15:17:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 20 Oct, 2009
-- Description:	Calculate commission and tax for each client 
--				by commission plan with commission plan rule rates
-- =============================================
ALTER PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionByRuleRate]
	@ClientID int,
	@TransDateFrom datetime,
	@TransDateTo datetime,
	@Recalculate bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @result tinyint
	DECLARE @commModel_ModelType tinyint, @commModel_CommRateID int
	DECLARE @commModel_CommPlanID int, @commModel_Minimum money, @commModel_Maximum money

	-- Get commission model info. of the client
	SELECT	@commModel_ModelType = ModelType,
			@commModel_CommRateID = ClientCommRateID,
			@commModel_CommPlanID = ClientCommPlanID,
			@commModel_Minimum = Minimum,
			@commModel_Maximum = Maximum
	FROM CWX_ClientCommModel 
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Get the client properties info
	DECLARE @properties_TaxExempt bit, @properties_AddCommissionToOwing bit		
	SELECT  @properties_TaxExempt = TaxExempt,
			@properties_AddCommissionToOwing = AddCommissionToOwing
	FROM CWX_ClientProperties
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Get the client tax info.
	DECLARE @tax_TaxType int, @tax_TaxRate decimal(19,5), @tax_CalculateTax bit, @tax_TaxTypeValue nvarchar(50)
	SELECT	@tax_TaxType = TaxType,
			@tax_TaxRate = TaxRate,
			@tax_CalculateTax = CalculateTax,
			@tax_TaxTypeValue = ISNULL(b.Value, '')
	FROM CWX_ClientTax a
		LEFT JOIN CWX_ClientPropertySettings b ON a.TaxType = b.ID
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Retrieve suitable transactions of accounts of client
	DECLARE curTrans CURSOR FOR
		SELECT	t.TransactionID, t.AccountID, t.EmployeeID,
				t.DateOfTransaction, ABS(t.TransactionAmount) AS TransactionAmount
		FROM Transactions t
		LEFT JOIN TransactionType tt
			ON t.TransactionType = tt.ID
		WHERE t.ClientID = @ClientID
			AND DATEDIFF(day, @TransDateFrom, t.DateOfTransaction) >= 0
			AND DATEDIFF(day, t.DateOfTransaction, @TransDateTo) >= 0
			AND ( (t.TransactionType = 901 AND ISNULL(t.ParentTransactionID, 0) = 0) OR ISNULL(tt.IsHostPaymentType, 0) = 1)
			AND t.ReversedFlag = 0			
			AND (@Recalculate = 1 OR t.TransactionID NOT IN (SELECT TransactionID FROM CWX_ClientCommission WHERE [Status] <> 'R'))
			AND t.AccountID IN (SELECT AccountID FROM Account WHERE AgencyStatusID <> 2 AND SystemStatusID <> 2) -- exclude Closed Accounts


	-- BEGIN Get account id list base on each comm plan rule
	CREATE TABLE #CommPlanRuleTemp (
		PlanRuleID int,
		AccountID int,		
		RatePercent decimal(19,5), 
		FixedAmount money, 
		Minimum money,
		Maximum money,
		[Order] int IDENTITY(1,1)
	)
	
	DECLARE @planRule_ID int, @planRule_RatePercent decimal(19,5), @planRule_FixedAmount money
	DECLARE @planRule_Minimum money, @planRule_Maximum money
	DECLARE @accountIDs varchar(max)

	DECLARE curCommPlanRule CURSOR FOR
		SELECT ID, RatePercent, FixedAmount, Minimum, Maximum
		FROM CWX_ClientCommPlanRule
		WHERE ClientCommPlanID = @commModel_CommPlanID
			--AND [Status] <> 'R'
	OPEN curCommPlanRule
	FETCH NEXT FROM curCommPlanRule INTO @planRule_ID, @planRule_RatePercent, @planRule_FixedAmount,
										 @planRule_Minimum, @planRule_Maximum
	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO #CommPlanRuleTemp(PlanRuleID, AccountID)
			EXEC [CWX_ClientCommPlanRule_GetAccountIDsByRule] @planRule_ID

		UPDATE #CommPlanRuleTemp
		SET RatePercent = @planRule_RatePercent,
			FixedAmount = @planRule_FixedAmount,
			Minimum = @planRule_Minimum,
			Maximum = @planRule_Maximum
		WHERE PlanRuleID = @planRule_ID
		
		FETCH NEXT FROM curCommPlanRule INTO @planRule_ID, @planRule_RatePercent, @planRule_FixedAmount,
											 @planRule_Minimum, @planRule_Maximum
	END

	CLOSE curCommPlanRule
	DEALLOCATE curCommPlanRule
	-- END Get account id list base on each comm plan rule


	DECLARE @transactionID int, @accountID int, @employeeID int, @dateOfTransaction datetime, @transactionAmount money
	DECLARE @commissionAmount money, @taxAmount money, @taxRate decimal(19,5)
	DECLARE @commAmountMinimum money, @commAmountMaximum money
	DECLARE @clientPart money, @agencyPart money, @collectorPart money
	
	BEGIN TRAN
	BEGIN TRY
		-- Go thru each transaction record to calculate commission and tax
		OPEN curTrans
		FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
										@dateOfTransaction, @transactionAmount

		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			SET @commissionAmount = NULL
			SET @clientPart = NULL
			SET @agencyPart = NULL
			SET @collectorPart = NULL

			SET @commAmountMinimum = @commModel_Minimum
			SET @commAmountMaximum = @commModel_Maximum
			
			SET @planRule_RatePercent = NULL 
			SET @planRule_FixedAmount = NULL
			SET @planRule_Minimum = NULL
			SET @planRule_Maximum = NULL
			
			-- Get plan rule rate info.
			SELECT	TOP 1
					@planRule_RatePercent = RatePercent,
					@planRule_FixedAmount = FixedAmount,
					@planRule_Minimum = Minimum,
					@planRule_Maximum = Maximum
			FROM #CommPlanRuleTemp
			WHERE @accountID = AccountID
			ORDER BY [Order]
			

			-- Calculate Commission Amount
			IF @planRule_RatePercent IS NOT NULL -- Rate Percent is prior than Fixed Amount
			BEGIN				
				IF (@properties_AddCommissionToOwing = 1)
					SET @commissionAmount = @transactionAmount * (@planRule_RatePercent/100) / (1 + @planRule_RatePercent/100)
				ELSE
					SET @commissionAmount = @transactionAmount * @planRule_RatePercent/100

				SET @planRule_FixedAmount = NULL
			END				
			ELSE IF @planRule_FixedAmount IS NOT NULL -- Fixed Amount
			BEGIN
				SET @commissionAmount = @planRule_FixedAmount

				SET @planRule_RatePercent = NULL				
			END
			ELSE
			BEGIN
				SET @commissionAmount = 0
			END 

			-- Check the min and max for commssion amount
			IF @planRule_Minimum IS NOT NULL
				SET @commAmountMinimum = @planRule_Minimum

			IF @planRule_Maximum IS NOT NULL
				SET @commAmountMaximum = @planRule_Maximum
			
			-- Adjust commission amount base on min and max
			IF @commissionAmount < @commAmountMinimum
				SET @commissionAmount = @commAmountMinimum

			IF @commissionAmount > @commAmountMaximum
				SET @commissionAmount = @commAmountMaximum


			-- CALCULATE ClientPart, AgencyPart, CollectorPart amount
			SET @clientPart = @transactionAmount - @commissionAmount
			SET @agencyPart = @commissionAmount
			SET @collectorPart = 0


			-- CALCULATE TAX BASE ON COMMISSION
			-- Check CalculateTax property of transaction type
			SET @taxAmount = NULL

			IF @tax_CalculateTax = 1 AND @properties_TaxExempt = 0
			BEGIN
				IF (@tax_TaxTypeValue LIKE '%Commission Amount%')
					SET @taxAmount = @commissionAmount * @tax_TaxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Payment Amount%')
					SET @taxAmount = @transactionAmount * @tax_TaxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Agency Part%')
					SET @taxAmount = @agencyPart * @tax_TaxRate/100
			END
			

			-- Delete children transactions of this transaction
			DELETE CWX_ClientCommission
			WHERE TransactionID IN (SELECT TransactionID FROM Transactions WHERE ParentTransactionID = @transactionID)

			--Mark delete current transantions were computed
			UPDATE CWX_ClientCommission SET [Status] = 'R' WHERE TransactionID = @transactionID AND [Status] <> 'R'			

			-- Insert or Update commission data into CWX_ClientCommission table
			IF NOT EXISTS (SELECT 1 FROM CWX_ClientCommission WHERE TransactionID = @transactionID AND [Status] <> 'R')
				INSERT INTO CWX_ClientCommission (
						TransactionID, 
						AccountID, 
						EmployeeID, 
						PaymentAmount, 
						ClientPart, 
						AgencyPart, 
						CollectorPart, 
						CommissionAmount,
						TaxAmount, 
						RatePercent,
						FixedAmount,
						MinAmount,
						MaxAmount)
				VALUES (
						@transactionID, 
						@accountID, 
						@employeeID, 
						@transactionAmount, 
						@clientPart, 
						@agencyPart, 
						@collectorPart, 
						@commissionAmount, 
						@taxAmount, 
						CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @planRule_RatePercent END,
						CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @planRule_FixedAmount END,
						@commAmountMinimum,
						@commAmountMaximum)
			--ELSE
			--	UPDATE CWX_ClientCommission 
			--	SET		AccountID = @accountID, 
			--			EmployeeID = @employeeID, 
			--			PaymentAmount = @transactionAmount, 
			--			ClientPart = @clientPart, 
			--			AgencyPart = @agencyPart,
			--			CollectorPart = @collectorPart, 
			--			CommissionAmount = @commissionAmount,
			--			TaxAmount = @taxAmount, 
			--			RatePercent = CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @planRule_RatePercent END,
			--			FixedAmount = CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @planRule_FixedAmount END,
			--			MinAmount = @commAmountMinimum,
			--			MaxAmount = @commAmountMaximum
			--	WHERE	TransactionID = @transactionID
			--		AND [Status] <> 'R'


			-- Retrieve next record to calculate
			FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
											@dateOfTransaction, @transactionAmount
		END

		COMMIT TRAN
		SET @result = 1
	END TRY
	-- Catch exception
	BEGIN CATCH
		ROLLBACK TRAN
		SET @result = 0
	END CATCH


	IF (CURSOR_STATUS('global', 'curTrans') >= 0)
	BEGIN
		CLOSE curTrans		
	END
	DEALLOCATE curTrans

	RETURN @result
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_CalculateCommissionBySystemStatusRate]    Script Date: 10/28/2009 15:21:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Phuong Le
-- Create date: 20 Oct, 2009
-- Description:	Calculate commission and tax for each client by system status
-- =============================================
ALTER PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionBySystemStatusRate]
	@ClientID int,
	@TransDateFrom datetime,
	@TransDateTo datetime,
	@Recalculate bit = 0	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	DECLARE @result tinyint	
	DECLARE @commModel_CommPlanID int, @commModel_Minimum money, @commModel_Maximum money
	
	-- Get commission model info. of the client
	SELECT	@commModel_CommPlanID = ClientCommPlanID,
			@commModel_Minimum = Minimum,
			@commModel_Maximum = Maximum
	FROM CWX_ClientCommModel 
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'
	
	-- Get the client properties info
	DECLARE @properties_TaxExempt bit, @properties_AddCommissionToOwing bit		
	SELECT  @properties_TaxExempt = TaxExempt,
			@properties_AddCommissionToOwing = AddCommissionToOwing
	FROM CWX_ClientProperties
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'

	-- Get the client tax info.
	DECLARE @tax_TaxType int, @tax_TaxRate decimal(19,5), @tax_CalculateTax bit, @tax_TaxTypeValue nvarchar(50)
	SELECT	@tax_TaxType = TaxType,
			@tax_TaxRate = TaxRate,
			@tax_CalculateTax = CalculateTax,
			@tax_TaxTypeValue = ISNULL(b.Value, '')
	FROM CWX_ClientTax a
		LEFT JOIN CWX_ClientPropertySettings b ON a.TaxType = b.ID
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'
	
	--Retrieve suitable transactions of accounts of client
	DECLARE curTrans CURSOR FOR
		SELECT	t.TransactionID, t.AccountID, t.EmployeeID, 
				t.DateOfTransaction, t.TransactionAmount
		FROM Transactions t
		LEFT JOIN TransactionType tt
			ON t.TransactionType = tt.ID
		WHERE t.ClientID = @ClientID
			AND DATEDIFF(day, @TransDateFrom, t.DateOfTransaction) >= 0
			AND DATEDIFF(day, t.DateOfTransaction, @TransDateTo) >= 0
			AND ( (t.TransactionType = 901 AND ISNULL(t.ParentTransactionID, 0) = 0 ) OR ISNULL(tt.IsHostPaymentType, 0) = 1)
			AND t.ReversedFlag = 0			
			AND (@Recalculate = 1 OR t.TransactionID NOT IN (SELECT TransactionID FROM CWX_ClientCommission WHERE [Status] <> 'R'))

	
	DECLARE @transactionID int, @accountID int, @employeeID int, @dateOfTransaction datetime, @transactionAmount money
	DECLARE @commissionAmount money
	DECLARE @taxAmount money
	DECLARE @StatusRate_RatePercent decimal(19,5)
	DECLARE @StatusRate_FixedAmount money
	DECLARE @StatusRate_Minimum money
	DECLARE @StatusRate_Maximum money	
	DECLARE @commAmountMinimum money, @commAmountMaximum money	
	DECLARE @clientPart money, @agencyPart money, @collectorPart money

	BEGIN TRAN

	BEGIN TRY		
		OPEN curTrans
		FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
										@dateOfTransaction, @transactionAmount
		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			SET @commissionAmount = null	
			SET @StatusRate_RatePercent =null
			SET @StatusRate_FixedAmount =null
			SET @StatusRate_Minimum =null
			SET @StatusRate_Maximum =null
			SET @commAmountMinimum = @commModel_Minimum
			SET @commAmountMaximum = @commModel_Maximum
			
			SELECT @StatusRate_RatePercent = r.RatePercent, @StatusRate_FixedAmount= r.FixedAmount,
				@StatusRate_Minimum= r.Minimum, @StatusRate_Maximum = r.Maximum
			FROM CWX_ClientSystemStatusRates r
			INNER JOIN Account a
			ON r.SystemStatusID = a.AgencyStatusID
			WHERE ClientCommPlanID = @commModel_CommPlanID
				AND a.AccountID = @accountID
				AND r.Status <> 'R'
			
			IF @StatusRate_RatePercent IS NOT NULL -- Rate Percent is prior than Fixed Amount
			BEGIN				
				IF  @properties_AddCommissionToOwing = 1
					SET @commissionAmount = @transactionAmount * (@StatusRate_RatePercent/100) / (1 + @StatusRate_RatePercent/100)
				ELSE
					SET @commissionAmount = @transactionAmount * @StatusRate_RatePercent/100

				SET @StatusRate_FixedAmount = NULL
			END				
			ELSE IF @StatusRate_FixedAmount IS NOT NULL -- Fixed Amount
			BEGIN
				SET @commissionAmount = @StatusRate_FixedAmount

				SET @StatusRate_RatePercent = NULL				
			END
			ELSE
			BEGIN
				SET @commissionAmount = 0
			END
		
			-- Check the min and max for commssion amount
			IF @StatusRate_Minimum IS NOT NULL
				SET @commAmountMinimum = @StatusRate_Minimum

			IF @StatusRate_Maximum IS NOT NULL
				SET @commAmountMaximum = @StatusRate_Maximum
			
			-- Adjust commission amount base on min and max
			IF @commissionAmount < @commAmountMinimum
				SET @commissionAmount = @commAmountMinimum

			IF @commissionAmount > @commAmountMaximum
				SET @commissionAmount = @commAmountMaximum
				
			-- CALCULATE ClientPart, AgencyPart, CollectorPart amount
			SET @clientPart = @transactionAmount - @commissionAmount
			SET @agencyPart = @commissionAmount
			SET @collectorPart = 0			
			
			-- CALCULATE TAX BASE ON COMMISSION
			SET @taxAmount = 0
			IF (@tax_CalculateTax = 1 AND @properties_TaxExempt = 0)
			BEGIN
				IF (@tax_TaxTypeValue LIKE '%Commission Amount%')
					SET @taxAmount = @commissionAmount * @tax_TaxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Payment Amount%')
					SET @taxAmount = @transactionAmount * @tax_TaxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Agency Part%')
					SET @taxAmount = @agencyPart * @tax_TaxRate/100
			END

			-- Delete children transactions of this transaction
			DELETE CWX_ClientCommission
			WHERE TransactionID IN (SELECT TransactionID FROM Transactions WHERE ParentTransactionID = @transactionID)

			--Mark delete current transantions were computed
			UPDATE CWX_ClientCommission SET [Status] = 'R' WHERE TransactionID = @transactionID AND [Status] <> 'R'			
			
			-- Insert or Update commission data into CWX_ClientCommission table
			IF NOT EXISTS (SELECT 1 FROM CWX_ClientCommission WHERE TransactionID = @transactionID AND [Status] <> 'R')
				INSERT INTO CWX_ClientCommission (
						TransactionID, 
						AccountID, 
						EmployeeID, 
						PaymentAmount, 
						ClientPart, 
						AgencyPart, 
						CollectorPart, 
						CommissionAmount,
						TaxAmount, 
						RatePercent,
						FixedAmount,
						MinAmount,
						MaxAmount)
				VALUES (
						@transactionID, 
						@accountID, 
						@employeeID, 
						@transactionAmount, 
						@clientPart, 
						@agencyPart, 
						@collectorPart, 
						@commissionAmount, 
						@taxAmount, 
						CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @StatusRate_RatePercent END,
						CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @StatusRate_FixedAmount END,
						@commAmountMinimum,
						@commAmountMaximum)
			--ELSE
			--	UPDATE CWX_ClientCommission 
			--	SET		AccountID = @accountID, 
			--			EmployeeID = @employeeID, 
			--			PaymentAmount = @transactionAmount, 
			--			ClientPart = @clientPart, 
			--			AgencyPart = @agencyPart,
			--			CollectorPart = @collectorPart, 
			--			CommissionAmount = @commissionAmount,
			--			TaxAmount = @taxAmount, 
			--			RatePercent = CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @StatusRate_RatePercent END,
			--			FixedAmount = CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @StatusRate_FixedAmount END,
			--			MinAmount = @commAmountMinimum,
			--			MaxAmount = @commAmountMaximum
			--	WHERE	TransactionID = @transactionID
			--		AND [Status] <> 'R'

			FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
										@dateOfTransaction, @transactionAmount
		END

		COMMIT TRAN
		SET @result = 1
	END TRY
	BEGIN CATCH
		ROLLBACK TRAN
		SET @result = 0
	END CATCH
	

	
	IF (CURSOR_STATUS('global', 'curTrans') >= 0)
	BEGIN		
		CLOSE curTrans		
	END

	DEALLOCATE curTrans

	RETURN @result
END

GO

/****** Object:  StoredProcedure [dbo].[CWX_ClientCommission_CalculateCommissionByTransactionTypeRate]    Script Date: 10/28/2009 15:27:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Minh Dam
-- Create date: 19 Oct, 2009
-- Description:	Calculate commission and tax for each client 
--				by commission plan with transaction type rates
-- =============================================
ALTER PROCEDURE [dbo].[CWX_ClientCommission_CalculateCommissionByTransactionTypeRate]
	@ClientID int,
	@TransDateFrom datetime,
	@TransDateTo datetime,
	@Recalculate bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @result tinyint
	DECLARE @commModel_ModelType tinyint, @commModel_CommRateID int
	DECLARE @commModel_CommPlanID int, @commModel_Minimum money, @commModel_Maximum money

	-- Get commission model info. of the client
	SELECT	@commModel_ModelType = ModelType,
			@commModel_CommRateID = ClientCommRateID,
			@commModel_CommPlanID = ClientCommPlanID,
			@commModel_Minimum = Minimum,
			@commModel_Maximum = Maximum
	FROM CWX_ClientCommModel 
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Get the client properties info
	DECLARE @properties_TaxExempt bit, @properties_AddCommissionToOwing bit		
	SELECT  @properties_TaxExempt = TaxExempt,
			@properties_AddCommissionToOwing = AddCommissionToOwing
	FROM CWX_ClientProperties
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Get the client tax info.
	DECLARE @tax_TaxType int, @tax_TaxRate decimal(19,5), @tax_CalculateTax bit, @tax_TaxTypeValue nvarchar(50)
	SELECT	@tax_TaxType = TaxType,
			@tax_TaxRate = TaxRate,
			@tax_CalculateTax = CalculateTax,
			@tax_TaxTypeValue = ISNULL(b.Value, '')
	FROM CWX_ClientTax a
		LEFT JOIN CWX_ClientPropertySettings b ON a.TaxType = b.ID
	WHERE ClientID = @ClientID
		AND [Status] <> 'R'


	-- Retrieve suitable transactions of accounts of client
	DECLARE curTrans CURSOR FOR
		SELECT	t.TransactionID, t.AccountID, t.EmployeeID,
				t.DateOfTransaction, ABS(t.TransactionAmount) AS TransactionAmount, 
				t.TransactionType, t.ParentTransactionID
		FROM Transactions t
		LEFT JOIN TransactionType tt
			ON t.TransactionType = tt.ID
		WHERE t.ClientID = @ClientID
			AND DATEDIFF(day, @TransDateFrom, t.DateOfTransaction) >= 0
			AND DATEDIFF(day, t.DateOfTransaction, @TransDateTo) >= 0
			--AND TransactionType = 901 -- Receive Payment
			AND t.ReversedFlag = 0
			AND (ISNULL(t.ParentTransactionID, 0) > 0 OR ISNULL(tt.IsHostPaymentType, 0) = 1 )
			AND (@Recalculate = 1 OR t.TransactionID NOT IN (SELECT TransactionID FROM CWX_ClientCommission WHERE [Status] <> 'R'))


	DECLARE @transactionID int, @accountID int, @employeeID int, @dateOfTransaction datetime, @transactionAmount money
	DECLARE @transactionType int, @parentTransactionID int

	DECLARE @commissionAmount money, @taxAmount money, @taxRate decimal(19,5)
	DECLARE @commAmountMinimum money, @commAmountMaximum money
	DECLARE @clientPart money, @agencyPart money, @collectorPart money
	
	DECLARE @transTypeRate_RatePercent decimal(19,5), @transTypeRate_FixedAmount money
	DECLARE @transTypeRate_Minimum money, @transTypeRate_Maximum money
	
	DECLARE @transTypeProp_CalculateComm bit, @transTypeProp_CalculateTax bit, @transTypeProp_AddToOwing bit

	DECLARE @tranTypeTax_TaxRate decimal(19,5)

	BEGIN TRAN
	BEGIN TRY
		-- Go thru each transaction record to calculate commission and tax
		OPEN curTrans
		FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
										@dateOfTransaction, @transactionAmount, 
										@transactionType, @parentTransactionID

		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			SET @commissionAmount = NULL
			SET @clientPart = NULL
			SET @agencyPart = NULL
			SET @collectorPart = NULL
			SET @transTypeProp_CalculateComm = NULL
			SET @transTypeProp_CalculateTax = NULL
			SET @transTypeProp_AddToOwing = NULL

			-- Get transaction type property info.
			SELECT	@transTypeProp_CalculateComm = CalculateComm,
					@transTypeProp_CalculateTax = CalculateTax,
					@transTypeProp_AddToOwing = AddToOwing
			FROM CWX_ClientTranTypeProperties
			WHERE ClientID = @ClientID
				AND TransactionTypeID = @transactionType
				AND [Status] <> 'R'

			-- Check CalculateComm property of transaction type
			IF 	@transTypeProp_CalculateComm IS NULL OR @transTypeProp_CalculateComm = 1
			BEGIN
				SET @commAmountMinimum = @commModel_Minimum
				SET @commAmountMaximum = @commModel_Maximum
				
				SET @transTypeRate_RatePercent = NULL
				SET @transTypeRate_FixedAmount = NULL
				SET @transTypeRate_Minimum = NULL
				SET @transTypeRate_Maximum = NULL
				
				-- Get transaction type rate info. base on Transaction Type
				SELECT	@transTypeRate_RatePercent = RatePercent,
						@transTypeRate_FixedAmount = FixedAmount,
						@transTypeRate_Minimum = Minimum,
						@transTypeRate_Maximum = Maximum
				FROM CWX_ClientTransactionTypeRates
				WHERE ClientCommPlanID = @commModel_CommPlanID
					AND [Status] <> 'R'
					AND TransactionTypeID = @transactionType

				-- Get transaction type rate info. base on Financial Type
				IF @@ROWCOUNT = 0
					SELECT	@transTypeRate_RatePercent = RatePercent,
							@transTypeRate_FixedAmount = FixedAmount,
							@transTypeRate_Minimum = Minimum,
							@transTypeRate_Maximum = Maximum
					FROM CWX_ClientTransactionTypeRates
					WHERE ClientCommPlanID = @commModel_CommPlanID
						AND [Status] <> 'R'
						AND ISNULL(TransactionTypeID, 0) = 0 
						AND FinancialTypeID IN (SELECT FinancialTypeID 
												FROM TransactionType 
												WHERE ID = @transactionType AND [Status] <> 'R')

				-- Calculate Commission Amount
				IF @transTypeRate_RatePercent IS NOT NULL -- Rate Percent is prior than Fixed Amount
				BEGIN				
					IF (@transTypeProp_AddToOwing IS NULL AND @properties_AddCommissionToOwing = 1)
						OR @transTypeProp_AddToOwing = 1
						SET @commissionAmount = @transactionAmount * (@transTypeRate_RatePercent/100) / (1 + @transTypeRate_RatePercent/100)
					ELSE
						SET @commissionAmount = @transactionAmount * @transTypeRate_RatePercent/100

					SET @transTypeRate_FixedAmount = NULL
				END				
				ELSE IF @transTypeRate_FixedAmount IS NOT NULL -- Fixed Amount
				BEGIN
					SET @commissionAmount = @transTypeRate_FixedAmount

					SET @transTypeRate_RatePercent = NULL				
				END
				ELSE
				BEGIN
					SET @commissionAmount = 0
				END

				-- Check the min and max for commssion amount
				IF @transTypeRate_Minimum IS NOT NULL
					SET @commAmountMinimum = @transTypeRate_Minimum

				IF @transTypeRate_Maximum IS NOT NULL
					SET @commAmountMaximum = @transTypeRate_Maximum
				
				-- Adjust commission amount base on min and max
				IF @commissionAmount < @commAmountMinimum
					SET @commissionAmount = @commAmountMinimum

				IF @commissionAmount > @commAmountMaximum
					SET @commissionAmount = @commAmountMaximum

	
				-- CALCULATE ClientPart, AgencyPart, CollectorPart amount
				SET @clientPart = @transactionAmount - @commissionAmount
				SET @agencyPart = @commissionAmount
				SET @collectorPart = 0

			END


			-- CALCULATE TAX BASE ON COMMISSION
			-- Check CalculateTax property of transaction type
			SET @taxAmount = NULL
			SET @taxRate = @tax_TaxRate

			IF ((@transTypeProp_CalculateTax IS NULL AND @tax_CalculateTax = 1) OR @transTypeProp_CalculateTax = 1)
				AND @properties_TaxExempt = 0
			BEGIN
				-- Get tax rate base on Transaction Type
				SELECT @taxRate = TaxRate
				FROM CWX_ClientTaxTranType
				WHERE ClientID = @ClientID
					AND [Status] <> 'R'
					AND TransactionTypeID = @transactionType

				-- Get tax rate base on Financial Type
				IF @@ROWCOUNT = 0				
					SELECT @taxRate = TaxRate
					FROM CWX_ClientTaxTranType
					WHERE ClientID = @ClientID
						AND [Status] <> 'R'
						AND ISNULL(TransactionTypeID, 0) = 0 
						AND FinancialTypeID IN (SELECT FinancialTypeID 
												FROM TransactionType 
												WHERE ID = @transactionType AND [Status] <> 'R')

				IF (@tax_TaxTypeValue LIKE '%Commission Amount%')
					SET @taxAmount = @commissionAmount * @taxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Payment Amount%')
					SET @taxAmount = @transactionAmount * @taxRate/100
				ELSE IF (@tax_TaxTypeValue LIKE '%Agency Part%')
					SET @taxAmount = @agencyPart * @taxRate/100
			END
			

			-- Delete parent transaction of this transaction
			DELETE CWX_ClientCommission
			WHERE TransactionID = @parentTransactionID

			--Mark delete current transantions were computed
			UPDATE CWX_ClientCommission SET [Status] = 'R' WHERE TransactionID = @transactionID AND [Status] <> 'R'			
			
			-- Insert or Update commission data into CWX_ClientCommission table
			IF NOT EXISTS (SELECT 1 FROM CWX_ClientCommission WHERE TransactionID = @transactionID AND [Status] <> 'R')
				INSERT INTO CWX_ClientCommission (
						TransactionID, 
						AccountID, 
						EmployeeID, 
						PaymentAmount, 
						ClientPart, 
						AgencyPart, 
						CollectorPart, 
						CommissionAmount,
						TaxAmount, 
						RatePercent,
						FixedAmount,
						MinAmount,
						MaxAmount)
				VALUES (
						@transactionID, 
						@accountID, 
						@employeeID, 
						@transactionAmount, 
						@clientPart, 
						@agencyPart, 
						@collectorPart, 
						@commissionAmount, 
						@taxAmount, 
						CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @transTypeRate_RatePercent END,
						CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @transTypeRate_FixedAmount END,
						@commAmountMinimum,
						@commAmountMaximum)
			--ELSE
			--	UPDATE CWX_ClientCommission 
			--	SET		AccountID = @accountID, 
			--			EmployeeID = @employeeID, 
			--			PaymentAmount = @transactionAmount, 
			--			ClientPart = @clientPart, 
			--			AgencyPart = @agencyPart,
			--			CollectorPart = @collectorPart, 
			--			CommissionAmount = @commissionAmount,
			--			TaxAmount = @taxAmount, 
			--			RatePercent = CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @transTypeRate_RatePercent END,
			--			FixedAmount = CASE ISNULL(@commissionAmount,-1) WHEN -1 THEN NULL ELSE @transTypeRate_FixedAmount END,
			--			MinAmount = @commAmountMinimum,
			--			MaxAmount = @commAmountMaximum
			--	WHERE	TransactionID = @transactionID
			--		AND [Status] <> 'R'


			-- Retrieve next record to calculate
			FETCH NEXT FROM curTrans INTO	@transactionID, @accountID, @employeeID, 
											@dateOfTransaction, @transactionAmount, 
											@transactionType, @parentTransactionID
		END

		COMMIT TRAN
		SET @result = 1
	END TRY
	-- Catch exception
	BEGIN CATCH
		print ERROR_MESSAGE()
		ROLLBACK TRAN
		SET @result = 0
	END CATCH

	IF (CURSOR_STATUS('global', 'curTrans') >= 0)
	BEGIN
		CLOSE curTrans		
	END
	DEALLOCATE curTrans

	RETURN @result

END
GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_GetInformationForRecordPaging]    Script Date: 10/28/2009 16:09:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_GetInformationForRecordPaging]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleTable_GetInformationForRecordPaging]
GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_GetInformationForRecordPaging]    Script Date: 10/28/2009 16:10:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: 26-October-2009
-- Description:	Get row order of a RuleID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleTable_GetInformationForRecordPaging]
	-- Add the parameters for the stored procedure here	
	@RuleTye int,
	@FilterByClientID int = 0,
	@FilterByRuleID int = 0,
	@FilterByDescription varchar(200) = '',
	@RuleIDToSearch int,
	@TotalRecords int output,
	@RowNumber int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;    	
	SELECT @TotalRecords = count(*)
	FROM RuleTable
	WHERE	RuleType = @RuleTye AND 
			(ClientID = @FilterByClientID OR @FilterByClientID = 0) AND
			(ID = @FilterByRuleID OR @FilterByRuleID = 0)	AND
			([Description] LIKE ('%' + @FilterByDescription + '%'))
	
	SELECT @RowNumber =  a.RowNumber
	FROM ( SELECT ROW_NUMBER() OVER (ORDER BY Description) as RowNumber, * FROM	RuleTable WHERE RuleType = @RuleTye AND 
																		(ClientID = @FilterByClientID OR @FilterByClientID = 0) AND 
																		(ID = @FilterByRuleID OR @FilterByRuleID = 0)	AND
																		([Description] LIKE ('%' + @FilterByDescription + '%'))
																		) a
	WHERE a.ID = @RuleIDToSearch	

	RETURN @TotalRecords
END
GO


/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_GetRuleBySequenceOrder]    Script Date: 10/28/2009 16:10:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleTable_GetRuleBySequenceOrder]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CWX_RuleTable_GetRuleBySequenceOrder]
GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleTable_GetRuleBySequenceOrder]    Script Date: 10/28/2009 16:10:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ThanhNguyen
-- Create date: 26-October-2009
-- Description:	Get Rule Table by sequence order
-- =============================================
CREATE PROCEDURE [dbo].[CWX_RuleTable_GetRuleBySequenceOrder]
	-- Add the parameters for the stored procedure here	
	@RuleTyeID int,
	@FilterByClientID int = 0,
	@FilterByRuleID int = 0,
	@FilterByDescription varchar(200)= '',
	@SequenceOrder int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	WITH Temp AS
	(
		SELECT ROW_NUMBER() OVER (ORDER BY Description) as RowNumber,
				*
		FROM	RuleTable
		WHERE	RuleType = @RuleTyeID AND 
				(ClientID = @FilterByClientID OR @FilterByClientID = 0) AND
				(ID = @FilterByRuleID OR @FilterByRuleID = 0)	AND
				([Description] LIKE ('%' + @FilterByDescription + '%'))
	)

	SELECT *
	FROM Temp
	WHERE RowNumber = @SequenceOrder
	ORDER BY Description
END
Go

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]
GO

/****** Object:  StoredProcedure [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]    Script Date: 10/30/2009 10:14:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CWX_RuleCriteria_GetCriteriaByRuleType]
	@RuleType int		
AS
BEGIN
	SET NOCOUNT ON;

	CREATE TABLE #TempTableInfoList
	(
		TableID int,
		TableName varchar(125)
	)
	DECLARE @InterfaceDBName varchar(125)
	SET @InterfaceDBName = ''	

	IF (@RuleType = 1 or @RuleType = 4) -- Allocation Rule or Temporary Rule
	BEGIN
		DECLARE @AllocationTables VARCHAR(2000)		
		SET @AllocationTables = 'Account,AccountOther,DebtorInformation,PersonInformation,PersonAddress'
		
		INSERT #TempTableInfoList
		SELECT object_id, SplitedText		
		FROM CWX_FnSplitString (@AllocationTables,',')
		INNER JOIN sys.objects
		ON name = SplitedText

	END
	ELSE IF (@RuleType = 2) -- Extraction Rule
	BEGIN	
		DECLARE @AccountTableName varchar(125)		
		SELECT TOP 1 @InterfaceDBName = InterfaceDBName, @AccountTableName = AccountTable
		FROM Interface WHERE AccountTable is not NULL or AccountTable <> ''
		ORDER BY InterfaceID

		SET @InterfaceDBName = @InterfaceDBName + '.'
		SET @AccountTableName = @AccountTableName + ','

		DECLARE @SelectTableInfoStatement varchar(2000)
		SET @SelectTableInfoStatement = 'INSERT #TempTableInfoList SELECT object_id, SplitedText FROM CWX_FnSplitString (''' + @AccountTableName + ''','','')  
										INNER JOIN ' + @InterfaceDBName + 'sys.objects o 
										ON o.name = SplitedText'
		EXEC(@SelectTableInfoStatement)
	END
	ELSE IF (@RuleType = 5) -- Leter Strategies
	BEGIN
		INSERT #TempTableInfoList
		SELECT object_id, Name as SplitedText
		FROM sys.objects
		WHERE NAME in ('AccountLetter') 
	END

	DECLARE @SelectDescriptionStatement varchar(2000)
	SET @SelectDescriptionStatement = 'SELECT [COLUMN_NAME] = o.name + ''.'' + ltrim(rtrim(c.name)),		  
		[DESCRIPTION] = dbo.CWX_RuleCriteria_FnProcessDescription (ltrim(rtrim(convert(varchar(125), ex.value)))),  
		[DATA_TYPE] = upper(ty.name), c.max_length, c.precision, 
		[DATABASE] = '''

	IF @InterfaceDBName <> ''	
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + SUBSTRING(@InterfaceDBName, 1, DATALENGTH(@InterfaceDBName) - 1) + ''''
	ELSE
		SET @SelectDescriptionStatement = @SelectDescriptionStatement + ''''	
	  
	SET @SelectDescriptionStatement = @SelectDescriptionStatement + ' FROM ' +
		@InterfaceDBName + 'sys.objects o 
	INNER JOIN ' +  
		@InterfaceDBName + 'sys.columns c 
	ON 
		o.object_id = c.object_id  
	LEFT OUTER JOIN ' +
		@InterfaceDBName + 'sys.extended_properties ex  
	ON  
		ex.major_id = c.object_id  
		AND ex.minor_id = c.column_id  
		AND ex.name = ''MS_Description''  
	LEFT OUTER JOIN ' + 
		@InterfaceDBName + 'sys.types ty  
	ON  
		ty.system_type_id = c.system_type_id  
	WHERE  
		c.object_id in (SELECT TableID FROM #TempTableInfoList)
		AND ex.value is not NULL AND ex.value <> ''''
	ORDER  
		BY [DESCRIPTION]'
	
	EXEC (@SelectDescriptionStatement)
	DROP TABLE #TempTableInfoList
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CWX_LetterRule_GetListByRuleLetterID]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].[CWX_LetterRule_GetListByRuleLetterID]
GO

-- =============================================
-- Author:		Phuong Le
-- Create date: 30 Oct 2009
-- Description:	Gets a list of letter Rule Criteria by RuleLetterID
-- =============================================
CREATE PROCEDURE [dbo].[CWX_LetterRule_GetListByRuleLetterID]
	-- Add the parameters for the stored procedure here
	@RuleLetterID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @Temp table
	(
		COLUMN_NAME varchar(50),
		DESCRIPTION varchar(50),
		DATA_TYPE varchar(25),
		max_length int,
		[precision] int,
		[DATABASE] varchar(50)
	)

	INSERT INTO @Temp
	EXEC CWX_RuleCriteria_GetCriteriaByRuleType 5 -- Letter Rule

	SELECT
		c.ID, c.RuleLetterID, c.Criteria, c.Operator, c.MatchingCriteria, c.SQLFormat,
		CASE c.ID
			WHEN (SELECT MAX(ID) FROM RuleCriteria WHERE RuleLetterID = c.RuleLetterID) THEN ''
			ELSE c.Combining
		END AS Combining,
		t.DESCRIPTION AS DESCRIPTION,
		t.DATA_TYPE AS DataType
	FROM CWX_LetterRuleCriteria c
	LEFT JOIN @Temp t ON t.COLUMN_NAME = c.Criteria
	WHERE c.RuleLetterID = @RuleLetterID
	ORDER BY c.ID
END