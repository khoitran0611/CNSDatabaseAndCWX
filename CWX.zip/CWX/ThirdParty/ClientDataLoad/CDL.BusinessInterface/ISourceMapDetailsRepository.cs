﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CWX.Core.Common.Data;
using System.Collections.ObjectModel;
using CDL.Common;

namespace CDL.BusinessInterface
{
	public interface ISourceMapDetailsRepository : IRepository<SourceMapDetails>
	{
		Collection<SourceMapDetails> GetListByTemplateID(int templateID);

		Collection<SourceMapDetails> GetListByTemplateID(int templateID, bool excludeDerivedColumn);

        Collection<SourceMapDetails> GetListByTemplateID(int templateID, bool excludeDerivedColumn, string orderBy);

		Collection<SourceMapDetails> GetPagingListByTemplateID(int templateID, int pageSize, int pageIndex, out int rowCount);

		int GetNumberOfSourceMapDetails(int templateID);

		SourceMapDetails GetBySourceColumn(int templateID, string sourceColumn);

		SourceMapDetails GetByDestField(int templateID, string destField);

		SourceMapDetails GetBySequenceOrder(int templateID, int sequenceOrder);

		/// <summary>
		/// Removes/Marks as deleted all SourceMapDetails in database.
		/// </summary>
		/// <param name="isSoftDelete">if true this function will mark all SourceMapDetails as deleted, otherwise removes all permanently.</param>
		/// <returns>Returns true if remove successfully, otherwise returns false.</returns>
		bool RemoveAll(int templateID, bool isSoftDelete);

		bool GenerateMappingColumns(int templateID, int numberOfColumns, int createdBy, DateTime creteadDate);

		int GetMinimumStartPositionByID(int templateID, int mapDetailID);

		bool UpdateMappingKeyColumn(DestinationDatabase destDatabase, string destTable, int templateID, int sourceKeyColumnID);

		SourceMapDetails GetKeyColumn(int templateID);
	}
}
