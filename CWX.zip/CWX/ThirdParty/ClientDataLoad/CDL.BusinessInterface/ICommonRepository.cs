﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using CWX.Core.Common.Data;

namespace CDL.BusinessInterface
{
	public interface ICommonRepository : IRepository<object>
	{
		DataSet GetAllColumnsDefinitions(string databaseName, string tableName);                

        string GetFieldNameFromDestinationDB(int destinationDBID, string destinationTableID, string sourceDBFieldName);
    }
}
