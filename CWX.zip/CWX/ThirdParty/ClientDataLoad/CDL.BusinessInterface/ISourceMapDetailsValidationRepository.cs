﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CWX.Core.Common.Data;
using CDL.BusinessObject;
using System.Collections.ObjectModel;

namespace CDL.BusinessInterface
{
	public interface ISourceMapDetailsValidationRepository : IRepository<SourceMapDetailsValidation>
	{
		Collection<SourceMapDetailsValidation> GetListByMapDetailID(int mapDetailID);
	}
}
