﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using CWX.Core.Common.Data;
using CDL.BusinessObject;
using CDL.Common;

namespace CDL.BusinessInterface
{
	public interface IImportDestTableRepository : IRepository<ImportDestTable>
	{
		Collection<ImportDestTable> GetListByDestDatabase(DestinationDatabase destDatabase);

        int GetImportDestinationID(int databaseID, string tableName);
    }
}
