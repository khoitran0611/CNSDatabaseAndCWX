﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CWX.Core.Common.Data;
using CDL.BusinessObject;
using System.Collections.ObjectModel;
using System.Data;

namespace CDL.BusinessInterface
{
	public interface IImportSourceRepository : IRepository<ImportSource>
	{
		ImportSource GetImportSourceByName(string name, int clientID);

		DataSet FillDataSet(int clientID);

		Collection<ImportSource> FillListByClientID(int clientID);

		/// <summary>
		/// Removes/Marks as deleted all ImportSources in database.
		/// </summary>
		/// <param name="isSoftDelete">if true this function will mark all ImportSources as deleted, otherwise removes all permanently.</param>
		/// <returns>Returns true if remove successfully, otherwise returns false.</returns>
		bool RemoveAll(int clientID, bool isSoftDelete);

		/// <summary>
		/// Checks if the ImportSource has any templates created.
		/// </summary>
		/// <param name="sourceID"></param>
		/// <returns>Return true if the ImportSource do not have any templates created; otherwise return false.</returns>
		bool CheckNoTemplateCreated(int sourceID);
	}
}
