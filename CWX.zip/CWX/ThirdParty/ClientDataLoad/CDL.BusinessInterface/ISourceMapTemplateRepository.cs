﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections.ObjectModel;

using CDL.BusinessObject;
using CWX.Core.Common.Data;
using CDL.Common;

namespace CDL.BusinessInterface
{
	public interface ISourceMapTemplateRepository : IRepository<SourceMapTemplate>
	{
		DataSet FillDataSet(int clientID, int sourceID, bool onlyActive);

		Collection<SourceMapTemplate> GetListBySourceID(int sourceID);

		Collection<SourceMapTemplate> GetListBySourceID(int sourceID, bool onlyActive);
		
		void UpdateActiveStatus(int templateID);

		/// <summary>
		/// Removes/Marks as deleted all SourceMapTemplates in database.
		/// </summary>
		/// <param name="isSoftDelete">if true this function will mark all SourceMapTemplates as deleted, otherwise removes all permanently.</param>
		/// <returns>Returns true if remove successfully, otherwise returns false.</returns>
		bool RemoveAll(int sourceID, bool isActive, bool isSoftDelete);

		bool CopySourceMapTemplate(int copyTemplateID, int createdBy, DateTime createdDate, out int newTemplateID);		

		bool ExistAtLeastOneMapping(int templateID);		

		/// <summary>
		/// Checks if a template has assigned key column
		/// </summary>
		/// <param name="templateID"></param>
		/// <returns></returns>
		bool HasMappingKeyColumn(int templateID);

		void UpdateKeyColumn(int templateID, int keyColumnID);
	}
}
