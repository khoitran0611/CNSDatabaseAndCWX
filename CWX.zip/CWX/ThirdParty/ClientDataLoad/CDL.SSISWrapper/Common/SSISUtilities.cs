﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.SSISWrapper.Mapping;
using System.Collections.ObjectModel;
using CWX.Core.Common;
using CWX.Core.Common.Data;
using CDL.Common;
using w = Microsoft.SqlServer.Dts.Runtime.Wrapper;
using CWX.Core.Common.Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Specialized;

namespace CDL.SSISWrapper.Common
{
    internal class SSISUtilities
    {

        private const int DEFAULT_NUMERICNUMBER = 0;
        private const string DEFAULT_DATE = "01/01/1900";
        private const int DEFAULT_BOOLEAN = 0;
        private static object _lockObject = new object();

        public static int GetTableRows(string databaseElementName, string tableName, string whereClause)
        {
            int numberofRows = 0;
            if (IsTableExisting(databaseElementName, tableName))
            {
                StringBuilder sql = new StringBuilder();
                sql.AppendFormat("SELECT count(*) as NumberOfRow FROM [{0}] WHERE 1=1 {1} ", tableName, string.IsNullOrEmpty(whereClause)?"":" AND " + whereClause);
                using (IDataExecutionContext dataContext = new DataProviderFactory().Create(databaseElementName).BeginExecution())
                {
                    dataContext.SetCommandText(sql.ToString(), CommandType.Text);
                    dataContext.RunReader(CommandBehavior.CloseConnection);

                    using (IDataReader reader = dataContext.RunReader())
                    {
                        if (reader.Read())
                        {
                            numberofRows = reader.GetInt32(reader.GetOrdinal("NumberOfRow"));
                        }
                    }
                }
            }
            return numberofRows;
        }

        
        public static bool CopyData(string databaseElementName, string sourceTable, string destinationTable, 
            string keyField,DestinationDatabase dbType, bool allowDuplicate)
        {
            bool success = true;
            
            if (string.IsNullOrEmpty(destinationTable))
                throw new CWXException("Invalid Destination Table");

            string sqlRecordsNotDuplicate =string.Format(@" SELECT [{0}] FROM [{1}] 
                                                            WHERE [{0}] NOT IN (SELECT [{0}] FROM [{2}])
                                                            GROUP BY [{0}] 
                                                            HAVING Count(*) = 1 ", keyField, sourceTable, destinationTable);

            string sqlRecordsDuplicate = string.Format(@" SELECT min(__ROW_NUMBER__) as __ROW_NUMBER__ FROM [{0}] 
                                                            WHERE [{1}] NOT IN (SELECT [{1}] FROM [{2}])
                                                            GROUP BY [{1}] 
                                                            HAVING Count(*) > 1 ", sourceTable,keyField, destinationTable);

            StringBuilder sqlBuilder = new StringBuilder();
            sqlBuilder.Append(" BEGIN TRAN");
            if (allowDuplicate)
            {
                sqlBuilder.AppendFormat(" UPDATE [{0}] SET __COLUMN_STATUS__ = 1 ", sourceTable);
            }
            else
            {
                //records not duplicate
                sqlBuilder.AppendFormat(" UPDATE [{0}] SET __COLUMN_STATUS__ = 1 WHERE [{1}] IN ({2}) ", sourceTable, keyField, sqlRecordsNotDuplicate);
                //records duplicate
                sqlBuilder.AppendFormat(" UPDATE [{0}] SET __COLUMN_STATUS__ = 1 WHERE __ROW_NUMBER__ IN ({1}) ", sourceTable, sqlRecordsDuplicate);
            }
            //insert to destination table
            string connectionString = CDLUtilities.GetOLDBConnectionString(dbType);
            string serverName = CDLUtilities.GetConnectionStringInfo(connectionString, DatabaseConnectionStringInfo.ServerName);
            string databaseName = CDLUtilities.GetConnectionStringInfo(connectionString, DatabaseConnectionStringInfo.DatabaseName);
            string userName = CDLUtilities.GetConnectionStringInfo(connectionString, DatabaseConnectionStringInfo.UserName);
            string password = CDLUtilities.GetConnectionStringInfo(connectionString, DatabaseConnectionStringInfo.Password);

            Microsoft.SqlServer.Management.Common.ServerConnection connection = new Microsoft.SqlServer.Management.Common.ServerConnection(serverName, userName, password);
            Microsoft.SqlServer.Management.Smo.Server server = new Microsoft.SqlServer.Management.Smo.Server(connection);
            Microsoft.SqlServer.Management.Smo.Database db = server.Databases[databaseName];
            Microsoft.SqlServer.Management.Smo.Table table = db.Tables[destinationTable];

            sqlBuilder.AppendFormat(" INSERT INTO [{0}] SELECT ",destinationTable);
            for (int i = 0; i < table.Columns.Count; i++)
            {
                sqlBuilder.AppendFormat(" {0} ", table.Columns[i].Name);
                if (i < table.Columns.Count - 1)
                {
                    sqlBuilder.Append(",");
                }
            }
            sqlBuilder.AppendFormat(" FROM [{0}] WHERE __COLUMN_STATUS__ =1 ", sourceTable);            
            sqlBuilder.Append(" IF @@Error != 0 BEGIN ROLLBACK END ELSE BEGIN COMMIT END");
            
            try
            {
                using (IDataExecutionContext dataContext = new DataProviderFactory().Create(databaseElementName).BeginExecution())
                {
                    dataContext.SetCommandText(sqlBuilder.ToString(), System.Data.CommandType.Text);
                    dataContext.RunNonQuery();
                }
            }
            catch (DataException ex)
            {
                success = false;
                throw new CWXException("Error while import data", ex);
            }
            return success;
        }
        
        public static bool ValidateSQLSyntax(Collection<SSISMapping> mappingFields, string databaseElementName, string sourceTable, string destTable)
        {
            if (mappingFields == null)
                throw new CWXException("Invalid Mapping Fields");

            bool isValid = true;
            if (mappingFields.Count > 0)
            {
                string selectStatement = BuildSelectStatementFromMappingFields(mappingFields, databaseElementName, sourceTable);
                try
                {
                    using (IDataExecutionContext dataContext = new DataProviderFactory().Create(databaseElementName).BeginExecution())
                    {
                        dataContext.SetCommandText(selectStatement, CommandType.Text);
                        dataContext.RunNonQuery();
                    }
                }
                catch (DataException ex)
                {
                    isValid = false;
                    throw new CWXException("Invalid Source Columns", ex);
                }

                string insertStatement = BuildInsertSQLStatement(mappingFields, sourceTable, destTable);
                try
                {
                    using (IDataExecutionContext dataContext = new DataProviderFactory().Create(databaseElementName).BeginExecution())
                    {
                        dataContext.SetCommandText(insertStatement, CommandType.Text);
                        dataContext.RunNonQuery();
                    }
                }
                catch (DataException ex)
                {
                    isValid = false;
                    throw new CWXException("Invalid destination columns", ex);
                }
            }
            return isValid;
        }

        public static bool IsTableExisting(string databaseElementName, string tableName)
        {
            bool existing = false;
            using (IDataExecutionContext dataContext = new DataProviderFactory().Create(databaseElementName).BeginExecution())
            {
                StringBuilder sql = new StringBuilder();
                sql.AppendFormat("IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[{0}]') AND type in (N'U'))", tableName);
                sql.AppendFormat(" BEGIN SELECT 1 AS RESULT END");
                sql.AppendFormat(" ELSE  BEGIN SELECT 0 AS RESULT END");
                dataContext.SetCommandText(sql.ToString(), CommandType.Text);                
                dataContext.RunReader(CommandBehavior.CloseConnection);

                using (IDataReader reader = dataContext.RunReader())
                {
                    if (reader.Read())
                    {
                        existing = reader.GetInt32(reader.GetOrdinal("RESULT")) > 0;
                    }
                }               
            }
            return existing;
        }

        public static string CreateTempTable(Collection<SSISMapping> mappingFields, string databaseElementName, bool isUnicodeTemplate, string tableName)
        {
            if (mappingFields == null)
                throw new CWXException("Invalid Mapping Fields");

            if(string.IsNullOrEmpty(tableName))
                throw new CWXException("TableName should not be empty");

            bool result = false;            
            if (mappingFields.Count > 0)
            {
                result = CreateTable(mappingFields, databaseElementName, isUnicodeTemplate, false, tableName);
            }
            return (result ? tableName : string.Empty);
        }

        public static string CreateTempTable(Collection<SSISMapping> mappingFields, string databaseElementName, bool isUnicodeTemplate)
        {
            string tableName = CWXGuidGenerator.GenerateNewGuid().ToString();
            return CreateTempTable(mappingFields, databaseElementName, isUnicodeTemplate, tableName);
        }

        public static void CreateDestinationTableFromMappingFields(Collection<SSISMapping> mappingFields, string databaseElementName, bool isUnicodeTemplate, string tableName)
        {
            if (mappingFields == null)
                throw new CWXException("Invalid Mapping Fields");
            if (mappingFields.Count > 0)
                CreateTable(mappingFields, databaseElementName, isUnicodeTemplate, true,  tableName, false);
        }

        public static void CreateTempDestinationTable(string databaseElementName, string tableName,
            string tempDestinationTableName, DestinationDatabase dbType, bool isUnicode, Collection<SSISMapping> mappingFields)
        {
            string connectionString = CDLUtilities.GetOLDBConnectionString(dbType);
            string serverName = CDLUtilities.GetConnectionStringInfo(connectionString, DatabaseConnectionStringInfo.ServerName);
            string databaseName = CDLUtilities.GetConnectionStringInfo(connectionString, DatabaseConnectionStringInfo.DatabaseName);
            string userName = CDLUtilities.GetConnectionStringInfo(connectionString, DatabaseConnectionStringInfo.UserName);
            string password = CDLUtilities.GetConnectionStringInfo(connectionString, DatabaseConnectionStringInfo.Password);

            Microsoft.SqlServer.Management.Common.ServerConnection connection = new Microsoft.SqlServer.Management.Common.ServerConnection(serverName,userName,password);
            Microsoft.SqlServer.Management.Smo.Server server = new Microsoft.SqlServer.Management.Smo.Server(connection);
            Microsoft.SqlServer.Management.Smo.Database db = server.Databases[databaseName];
            Microsoft.SqlServer.Management.Smo.Table table = db.Tables[tableName];                        

            StringCollection script = table.Script();
            
            string tableStructrue = script[2].Replace("[dbo].[" + tableName+"]","[" + tempDestinationTableName + "]");

            if (isUnicode)
            {
                tableStructrue = tableStructrue.Replace(" [varchar](", " [nvarchar](").Replace(" [char](", " [nchar](").Replace(" [text](", " [ntext](").Replace(" [nvarchar](8000)", " [nvarchar](4000)").Replace(" [nchar](8000)", " [nchar](4000)"); 
            }
            else
            {
                tableStructrue = tableStructrue.Replace(" [nvarchar](", " [varchar](").Replace(" [nchar](", " [char](").Replace(" [ntext](", " [text]("); 
            }

            tableStructrue += " ALTER TABLE [" + tempDestinationTableName + "] ADD __COLUMN_STATUS__ bit DEFAULT 0,";
            tableStructrue += " __ROW_NUMBER__ int IDENTITY(1,1) ";

            //add more column in case column is not mapped
            string customTableStructure = string.Empty;
            for (int i = 0; i < mappingFields.Count; i++ )
            {
                if (string.IsNullOrEmpty(mappingFields[i].DestField))
                {
                    string dataType = isUnicode ? " nvarchar(max)" : " varchar(max)";
                    customTableStructure += (i== 0 ? " " : "," ) +  "__" + mappingFields[i].SourceCol + "__" + (isUnicode ? " nvarchar(max)" : " varchar(max)");  //(isUnicode ? " nvarchar(max)" : " varchar(max)");
                    //if (i < mappingFields.Count-1)
                    //{
                    //    customTableStructure += ",";
                    //}
                }
            }
            if (!string.IsNullOrEmpty(customTableStructure))
            {
                tableStructrue += "," + customTableStructure;
            }

            using (IDataExecutionContext dataContext = new DataProviderFactory().Create(databaseElementName).BeginExecution())
            {

                dataContext.SetCommandText(tableStructrue);
                dataContext.RunNonQuery();
            }            
        }

        public static void CreateErrorTable(Collection<SSISMapping> mappingFields, string databaseElementName, string tableName, DataSourceType sourceType, bool isUnicode)
        {
            if (string.IsNullOrEmpty(tableName))
                throw new CWXException("TableName for error table should not be null");
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("CREATE TABLE [{0}] ", tableName);
            string columns = string.Empty;
            switch (sourceType)
            {
                case DataSourceType.CSVFile:
                case DataSourceType.TextFile:
                    sql.AppendFormat(" ( [Flat File Source Error Output Column] {1}(max), [ErrorCode] INTEGER, [ErrorColumn] INTEGER )", tableName,isUnicode?"nvarchar":"varchar");
                    break;
                case DataSourceType.ExcelFile:
                case DataSourceType.Database:
                    string columnList = string.Empty;
                    string columnName = string.Empty;
                    int idx = 0;
                    foreach (SSISMapping mappingField in mappingFields)
                    {
                        columnName = string.Empty;
                        if (!string.IsNullOrEmpty(mappingField.SourceCol))
                        {
                            if(isUnicode)
                                columnName = mappingField.SourceCol + string.Format(" nvarchar(max)");
                            else
                                columnName = mappingField.SourceCol + string.Format(" varchar(max)");
                        }
                        if (!string.IsNullOrEmpty(columnName))
                        {
                            columnList += (idx==0) ? columnName : ", " + columnName ;
                        }
                        idx++;
                    }
                    //string columnList = BuildFieldList(mappingFields, true, isUnicode, true);
                    sql.AppendFormat(" ({0}, [ErrorCode] INTEGER, [ErrorColumn] INTEGER)", columnList);
                    break;
            }

            if (!IsTableExisting(databaseElementName, tableName))
            {
                using (IDataExecutionContext dataContext = new DataProviderFactory().Create(databaseElementName).BeginExecution())
                {
                    dataContext.SetCommandText(sql.ToString(), System.Data.CommandType.Text);
                    dataContext.RunNonQuery();
                }
            }

        }

        public static bool CreateTable(Collection<SSISMapping> mappingFields, string databaseElementName, bool isUnicodeTemplate, bool doCreateDeriveField, string tableName)
        {
            return CreateTable(mappingFields, databaseElementName, isUnicodeTemplate, doCreateDeriveField, tableName, true);
        }

        public static bool CreateTable(Collection<SSISMapping> mappingFields, string databaseElementName, bool isUnicodeTemplate, bool doCreateDeriveField, string tableName, bool isFromSource)
        {
            bool result = false;
            if (!IsTableExisting(databaseElementName, tableName))
            {
                lock (_lockObject)
                {

                    using (IDataExecutionContext dataContext = new DataProviderFactory().Create(databaseElementName).BeginExecution())
                    {
                        string tableStructure = CreateTableStructure(mappingFields, tableName, isUnicodeTemplate, doCreateDeriveField,isFromSource);
                        dataContext.SetCommandText(tableStructure, System.Data.CommandType.Text);
                        dataContext.RunNonQuery();
                        result = true;
                    }
                }
            }
            return result;
        }

        public static void DropTable(string databaseElementName, string tableName)
        {
            if (IsTableExisting(databaseElementName, tableName))
            {
                using (IDataExecutionContext dataContext = new DataProviderFactory().Create(databaseElementName).BeginExecution())
                {
                    StringBuilder sql = new StringBuilder();
                    sql.AppendFormat("DROP TABLE [dbo].[{0}]", tableName);
                    dataContext.SetCommandText(sql.ToString(), System.Data.CommandType.Text);
                    dataContext.RunNonQuery();
                }
            }
        }

        public static void DropTables(string databaseElementName, string[] tableNames)
        {
            foreach (string tableName in tableNames)
            {
                DropTable(databaseElementName, tableName);
            }
        }

        private static string CreateTableStructure(Collection<SSISMapping> mappingFields, string tableName, bool isUnicodeTemplate, bool doCreateDeriveField, bool isColumnFromSource)
        {
            string tableStructure = string.Format("CREATE TABLE [dbo].[{0}](", tableName);
            string endTable = ")";            

            tableStructure += BuildFieldList(mappingFields, doCreateDeriveField, isUnicodeTemplate, isColumnFromSource);

            return tableStructure + endTable;
        }

        private static string BuildColumnFromMappingField(SSISMapping mappingField, bool isUnicodeTemplate, bool isColumnFromSource)
        {
            string columnName = string.Empty;
            if (isColumnFromSource)
            {
                if (!string.IsNullOrEmpty(mappingField.SourceCol))
                    columnName = mappingField.SourceCol;
            }
            else
                if (!string.IsNullOrEmpty(mappingField.DestField))
                    columnName = mappingField.DestField;

            if (!string.IsNullOrEmpty(columnName))
            {
                switch (mappingField.FieldType)
                {
                    case CDL.Common.DataType.Boolean:
                        columnName = columnName + string.Format(" bit NULL DEFAULT(({0}))", DEFAULT_BOOLEAN);
                        break;
                    case CDL.Common.DataType.Date:
                        columnName = columnName + string.Format(" Datetime NULL DEFAULT('{0}')", DEFAULT_DATE);
                        break;
                    case CDL.Common.DataType.Integer:
                        columnName = columnName + string.Format(" int NULL DEFAULT(({0}))", DEFAULT_NUMERICNUMBER);
                        break;
                    case CDL.Common.DataType.Currency:
                        columnName = columnName + string.Format(" Money NULL DEFAULT(({0}))", DEFAULT_NUMERICNUMBER);
                        break;
                    case CDL.Common.DataType.Real:
                        columnName = columnName + string.Format(" real NULL DEFAULT(({0}))", DEFAULT_NUMERICNUMBER);
                        break;
                    case CDL.Common.DataType.String:
                        if (isUnicodeTemplate)
                        {
                            if (mappingField.FieldLength == null)
                                columnName = columnName + " nvarchar(4000) NULL DEFAULT('')";
                            else
                                columnName = columnName + string.Format(" nvarchar({0}) NULL DEFAULT('')", mappingField.FieldLength);
                        }
                        else
                        {
                            if (mappingField.FieldLength == null)
                                columnName = columnName + " varchar(8000) NULL DEFAULT('')";
                            else
                                columnName = columnName + string.Format(" varchar({0}) DEFAULT('')", mappingField.FieldLength);
                        }
                        break;
                }
            }
            return columnName;
        }

        private static string BuildInsertSQLStatement(Collection<SSISMapping> mappingFields, string sourceTable, string destinationTable)
        {
            string sql = string.Empty;
            string sqlSelectStatement = string.Empty;
            string insertFields = string.Empty;
            string selectFields = string.Empty;

            if (mappingFields.Count > 0)
            {
                sql = "INSERT INTO [dbo].[{0}] ({1}) {2}";
                sqlSelectStatement = "SELECT {0} FROM dbo.[{1}]";
                int idx = 0;
                foreach (SSISMapping mappingField in mappingFields)
                {
                    if (!string.IsNullOrEmpty(mappingField.DestField))
                    {
                        insertFields += (idx == 0 ? mappingField.DestField : "," + mappingField.DestField);
                        if (!mappingField.IsDerivedField)
                        {
                            if(mappingField.FieldType == DataType.String)
                                selectFields += (idx == 0 ? string.Format("ltrim(rtrim({0})) as {0}",mappingField.SourceCol) : string.Format(",ltrim(rtrim({0})) as {0}", mappingField.SourceCol));
                            else    
                                selectFields += (idx == 0 ? mappingField.SourceCol : "," + mappingField.SourceCol);
                        }
                        else
                        {
                            selectFields += (idx == 0 ? mappingField.DerivedFrom : "," + mappingField.DerivedFrom);
                        }

                    }
                    idx++;
                }

                sqlSelectStatement = string.Format(sqlSelectStatement, selectFields, sourceTable);
                sql = string.Format(sql, destinationTable, insertFields, sqlSelectStatement);
            }

            return sql;
        }

        private static string BuildFieldList(Collection<SSISMapping> mappingFields, bool doCreateDeriveField, bool isUnicodeTemplate, bool isColumnFromSource)
        {
            string fieldList = string.Empty;
            string columnDefinition = string.Empty;
            for (int i = 0; i < mappingFields.Count; i++)
            {
                columnDefinition = string.Empty;
                SSISMapping mapplingField = mappingFields[i];
                if (doCreateDeriveField)
                    columnDefinition = BuildColumnFromMappingField(mapplingField, isUnicodeTemplate, isColumnFromSource);
                else
                    if (!mapplingField.IsDerivedField)
                        columnDefinition = BuildColumnFromMappingField(mapplingField, isUnicodeTemplate, isColumnFromSource);

                if (!string.IsNullOrEmpty(columnDefinition))
                    fieldList += (string.IsNullOrEmpty(fieldList) ? columnDefinition : "," + columnDefinition);
            }
            return fieldList;
        }

        private static string BuildSelectStatementFromMappingFields(Collection<SSISMapping> mappingFields, string databaseElementName, string table)
        {
            if (mappingFields == null)
                throw new CWXException("Invalid Mapping Fields");

            string sqlSelectStatement = string.Empty;
            if (mappingFields.Count > 0)
            {
                sqlSelectStatement = "SELECT top 0 {0} FROM dbo.[{1}]";

                string selectFields = string.Empty;
                int idx = 0;
                foreach (SSISMapping mappingField in mappingFields)
                {
                    if (!mappingField.IsDerivedField)
                        selectFields += (idx == 0 ? mappingField.SourceCol : "," + mappingField.SourceCol);
                    else
                        selectFields += (idx == 0 ? mappingField.DerivedFrom : "," + mappingField.DerivedFrom);
                    idx++;
                }
                sqlSelectStatement = string.Format(sqlSelectStatement, selectFields, table);
            }

            return sqlSelectStatement;
        }

        internal static SSISColumnProperty BuildSSISColumnProperty(SSISMapping mappingField, bool useUnicode, bool forceConvert2String)
        {
            if (!forceConvert2String)
            {
                return BuildSSISColumnProperty(mappingField, useUnicode);
            }
            else
            {
                SSISColumnProperty columnProperty = new SSISColumnProperty();
                switch (mappingField.FieldType)
                {
                    case DataType.Boolean:                        
                    case DataType.Date:                        
                    case DataType.Integer:                        
                    case DataType.Currency:                        
                    case DataType.Real:
                        if (useUnicode)
                        {
                            columnProperty.DataType = w.DataType.DT_WSTR;
                        }
                        else
                        {
                            columnProperty.DataType = w.DataType.DT_STR;
                        }
                        columnProperty.Length = 50;
                        break;
                    case DataType.String:
                        if (useUnicode)
                        {
                            columnProperty.DataType = w.DataType.DT_WSTR;
                            columnProperty.Length = mappingField.FieldLength.HasValue ? mappingField.FieldLength.Value : 4000;
                        }
                        else
                        {
                            columnProperty.DataType = w.DataType.DT_STR;
                            columnProperty.Length = mappingField.FieldLength.HasValue ? mappingField.FieldLength.Value : 8000;
                        }
                        break;
                    default:
                        break;
                }
                return columnProperty;
            }
        }

        internal static SSISColumnProperty BuildSSISColumnProperty(SSISMapping mappingField, bool useUnicode)
        {
            SSISColumnProperty columnProperty = new SSISColumnProperty();
            switch (mappingField.FieldType)
            {
                case DataType.Boolean:
                    columnProperty.DataType = w.DataType.DT_BOOL;
                    break;
                case DataType.Date:
                    columnProperty.DataType = w.DataType.DT_DATE;
                    break;
                case DataType.Integer:
                    columnProperty.DataType = w.DataType.DT_I4;
                    break;
                case DataType.Currency:
                    columnProperty.DataType = w.DataType.DT_CY;
                    //columnProperty.Precision = 19;
                    //columnProperty.Scale = 4;
                    break;
                case DataType.Real:
                    columnProperty.DataType = w.DataType.DT_R8;
                    break;
                case DataType.String:
                    if (useUnicode)
                    {
                        columnProperty.DataType = w.DataType.DT_WSTR;
                        columnProperty.Length = mappingField.FieldLength.HasValue?mappingField.FieldLength.Value:4000;
                    }
                    else
                    {
                        columnProperty.DataType = w.DataType.DT_STR;
                        columnProperty.Length = mappingField.FieldLength.HasValue?mappingField.FieldLength.Value:8000;
                    }
                    break;
                default:
                    break;
            }
            return columnProperty;
        }
    }
}

