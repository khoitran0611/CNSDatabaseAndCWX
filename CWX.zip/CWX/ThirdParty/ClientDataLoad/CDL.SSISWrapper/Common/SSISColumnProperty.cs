﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SqlServer.Dts.Runtime.Wrapper;

namespace CDL.SSISWrapper.Common
{
    internal class SSISColumnProperty
    {
        private DataType dataType = DataType.DT_NULL;
        private int length = 0;        
        private int precision = 0;
        private int scale = 0;

        public int Scale
        {
            get { return scale; }
            set { scale = value; }
        }

        public int Precision
        {
            get { return precision; }
            set { precision = value; }
        }        

        public int Length
        {
            get { return length; }
            set { length = value; }
        }

        public DataType DataType
        {
            get { return dataType; }
            set { dataType = value; }
        }   
    }
}
