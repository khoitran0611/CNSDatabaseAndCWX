﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.Common;

namespace CDL.SSISWrapper.Mapping
{
	internal class SSISMapping
	{
		#region Properties
		
        public string SourceCol
        {
            get;
            set;
        }

        public string DestField
        {
            get;
            set;
        }

        public int ColumnWidth
        {
            get;
            set;
        }

        public DataType FieldType
        {
            get;
            set;
        }

        public int? FieldLength
        {
            get;
            set;
        }

        public string Validation
        {
            get;
            set;
        }

        public Boolean IsDerivedField
        {
            get;
            set;
        }

        public string DerivedFrom
        {
            get;
            set;
        }

        public string ColCollation
        {
            get;
            set;
        }

        public string DefaultValue
        {
            get;
            set;
        }
		#endregion
	}
}
