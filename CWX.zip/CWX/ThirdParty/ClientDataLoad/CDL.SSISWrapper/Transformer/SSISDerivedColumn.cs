﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using w = Microsoft.SqlServer.Dts.Runtime.Wrapper;
using System.Collections.ObjectModel;
using CDL.SSISWrapper.Mapping;
using CDL.SSISWrapper.Common;
using System.Text.RegularExpressions;
using System.Collections;

namespace CDL.SSISWrapper.Transformer
{
    internal class SSISDerivedColumn
    {
        public IDTSComponentMetaData90 BuildDerivedColumnComponent(Package p, MainPipe pipe,
           IDTSComponentMetaData90 sourceComponent, int inputID, Collection<SSISMapping> mappings, bool useUnicode, int locale,
           Hashtable dataConversionlineageIDsList, out int outputID, out int errorOutputID)
        {
            IDTSComponentMetaData90 derivedColumn = pipe.ComponentMetaDataCollection.New();
            derivedColumn.ComponentClassID = "{9CF90BF0-5BCC-4C63-B91D-1F322DC12C26}";

            if (locale > 0)
            {
                derivedColumn.LocaleID = locale;
            }

            IDTSDesigntimeComponent90 derivedColumnInstance = derivedColumn.Instantiate();            
            derivedColumnInstance.ProvideComponentProperties();           

            derivedColumn.Name = "Derived column " + Guid.NewGuid().ToString();
            derivedColumn.InputCollection[0].ExternalMetadataColumnCollection.IsUsed = false;
            derivedColumn.InputCollection[0].HasSideEffects = false;

            if (inputID > -1)
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(sourceComponent.OutputCollection.FindObjectByID(inputID), derivedColumn.InputCollection[0]);
            }
            else
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(sourceComponent.OutputCollection[0], derivedColumn.InputCollection[0]);
            }

            derivedColumnInstance.AcquireConnections(null);

            IDTSVirtualInput90 vInput = derivedColumn.InputCollection[0].GetVirtualInput();

            foreach (IDTSVirtualInputColumn90 evc in vInput.VirtualInputColumnCollection)
            {
                if (dataConversionlineageIDsList == null || (dataConversionlineageIDsList != null && dataConversionlineageIDsList.ContainsKey(evc.LineageID)))
                {
                    switch (evc.DataType)
                    {
                        case w.DataType.DT_DATE:
                        case w.DataType.DT_DBDATE:
                            derivedColumnInstance.SetUsageType(derivedColumn.InputCollection[0].ID, vInput, evc.LineageID, DTSUsageType.UT_READWRITE);
                            break;
                        default:
                            derivedColumnInstance.SetUsageType(derivedColumn.InputCollection[0].ID, vInput, evc.LineageID, DTSUsageType.UT_READONLY);
                            break;
                    }
                }
            }

            foreach (IDTSInputColumn90 inputColumn in derivedColumn.InputCollection[0].InputColumnCollection)
            {
                switch (inputColumn.DataType)
                {
                    case w.DataType.DT_DBDATE:
                    case w.DataType.DT_DATE:
                        string frindlyExpression = string.Format("({0}<(DT_DATE)(\"{1}\"))?(DT_DATE)(\"{1}\"):{0}", inputColumn.Name, "1/1/1900");
                        string expression = string.Format("(#{0}<(DT_DATE)(\"{1}\"))?(DT_DATE)(\"{1}\"):#{0}", inputColumn.LineageID, "1/1/1900");

                        inputColumn.CustomPropertyCollection.RemoveAll();
                        IDTSCustomProperty90 property = inputColumn.CustomPropertyCollection.New();
                        property.Name = "Expression";
                        property.Value = expression;
                        property = inputColumn.CustomPropertyCollection.New();
                        property.Name = "FriendlyExpression";
                        property.Value = frindlyExpression;
                        break;
                    default:
                        break;
                }
            }

            derivedColumn.OutputCollection[0].ErrorRowDisposition = DTSRowDisposition.RD_NotUsed;
            derivedColumn.OutputCollection[0].TruncationRowDisposition = DTSRowDisposition.RD_NotUsed;

            foreach (SSISMapping itemMapping in mappings)
            {
                if (itemMapping.IsDerivedField)
                {
                    IDTSOutputColumn90 outputColumn = derivedColumn.OutputCollection[0].OutputColumnCollection.New();
                    outputColumn.Name = itemMapping.SourceCol;

                    SSISColumnProperty columnProperty = SSISUtilities.BuildSSISColumnProperty(itemMapping, useUnicode);
                                        
                    if(itemMapping.FieldType == CDL.Common.DataType.String)
                        outputColumn.SetDataTypeProperties(columnProperty.DataType, columnProperty.Length, columnProperty.Precision, columnProperty.Scale,useUnicode ? 0: 1252);
                    else
                        outputColumn.SetDataTypeProperties(columnProperty.DataType, columnProperty.Length, columnProperty.Precision, columnProperty.Scale,  0);

                    outputColumn.ExternalMetadataColumnID = 0;
                    outputColumn.ErrorRowDisposition = DTSRowDisposition.RD_RedirectRow;
                    outputColumn.TruncationRowDisposition = DTSRowDisposition.RD_RedirectRow;

                    string friendlyExp = itemMapping.DerivedFrom;
                    string expression = string.Empty;

                    Regex regex = new Regex(@"\b([a-z0-9_-]+)",RegexOptions.IgnoreCase);
                    string[] expItemsList = regex.Split(friendlyExp.Replace("[","").Replace("]",""));
                    friendlyExp = string.Empty;
                    foreach (string item in expItemsList)
                    {                               
                        try
                        {
                            IDTSVirtualInputColumn90 vc = vInput.VirtualInputColumnCollection.GetVirtualInputColumnByName(sourceComponent.Name, item);
                            expression += "#" + vc.LineageID;

                            if (dataConversionlineageIDsList != null)
                            {
                                friendlyExp += "[" + sourceComponent.Name + "]." + item;
                            }
                            else
                            {
                                friendlyExp += item;
                            }                                                        
                        }
                        catch
                        {
                            expression += item;
                            friendlyExp += item;
                        }                                                
                    }                    

                    IDTSCustomProperty90 property = outputColumn.CustomPropertyCollection.New();
                    property.Name = "Expression";
                    property.Value = expression;
                    property = outputColumn.CustomPropertyCollection.New();
                    property.Name = "FriendlyExpression";
                    property.Value = friendlyExp;

                    if (dataConversionlineageIDsList != null)
                    {
                        dataConversionlineageIDsList.Add(outputColumn.LineageID, outputColumn.Name);
                    }
                }                
            }            

            outputID = derivedColumn.OutputCollection[0].ID;
            errorOutputID = derivedColumn.OutputCollection[1].ID;

            derivedColumnInstance.ReinitializeMetaData();
            derivedColumnInstance.ReleaseConnections();

            return derivedColumn;
        }

        public IDTSComponentMetaData90 BuildTrimDataComponent(Package p, MainPipe pipe,
           IDTSComponentMetaData90 sourceComponent, int inputID,Hashtable dataConversionlineageIDsList,
            bool useUnicode, int locale, out int outputID, out int errorOutputID)
        {
            IDTSComponentMetaData90 trimDataComponent = pipe.ComponentMetaDataCollection.New();
            trimDataComponent.ComponentClassID = "{9CF90BF0-5BCC-4C63-B91D-1F322DC12C26}";

            if (locale > 0)
            {
                trimDataComponent.LocaleID = locale;
            }

            IDTSDesigntimeComponent90 trimDataComponentInstance = trimDataComponent.Instantiate();
            trimDataComponentInstance.ProvideComponentProperties();            

            trimDataComponent.Name = "Trim data component " + Guid.NewGuid().ToString();

            trimDataComponent.InputCollection[0].ExternalMetadataColumnCollection.IsUsed = false;
            trimDataComponent.InputCollection[0].HasSideEffects = false;

            if (inputID > -1)
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(sourceComponent.OutputCollection.FindObjectByID(inputID), trimDataComponent.InputCollection[0]);
            }
            else
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(sourceComponent.OutputCollection[0], trimDataComponent.InputCollection[0]);
            }

            trimDataComponentInstance.AcquireConnections(null);            

            IDTSVirtualInput90 vInput = trimDataComponent.InputCollection[0].GetVirtualInput();

            foreach (IDTSVirtualInputColumn90 evc in vInput.VirtualInputColumnCollection)
            {
                if (dataConversionlineageIDsList == null || (dataConversionlineageIDsList != null && dataConversionlineageIDsList.ContainsKey(evc.LineageID)))
                {
                    trimDataComponentInstance.SetUsageType(trimDataComponent.InputCollection[0].ID, vInput, evc.LineageID, DTSUsageType.UT_READWRITE);
                }
            }

            foreach (IDTSInputColumn90 inputColumn in trimDataComponent.InputCollection[0].InputColumnCollection)
            {                                
                string frindlyExpression = string.Empty;
                string expression = string.Empty;                
                switch (inputColumn.DataType)
                {
                    case Microsoft.SqlServer.Dts.Runtime.Wrapper.DataType.DT_STR:
                    case Microsoft.SqlServer.Dts.Runtime.Wrapper.DataType.DT_WSTR:
                        frindlyExpression = string.Format("TRIM({0})", inputColumn.Name);
                        expression = string.Format("TRIM(#{0})", inputColumn.LineageID);
                        break;
                    default:
                        frindlyExpression = string.Format("TRIM((DT_STR, 50, 1252){0})", inputColumn.Name);
                        expression = string.Format("TRIM((DT_STR, 50, 1252)#{0})", inputColumn.LineageID);
                        break;
                }

                inputColumn.ErrorRowDisposition = DTSRowDisposition.RD_RedirectRow;
                inputColumn.TruncationRowDisposition = DTSRowDisposition.RD_RedirectRow;

                inputColumn.CustomPropertyCollection.RemoveAll();
                IDTSCustomProperty90 property = inputColumn.CustomPropertyCollection.New();
                property.Name = "Expression";
                property.Value = expression;
                property = inputColumn.CustomPropertyCollection.New();
                property.Name = "FriendlyExpression";
                property.Value = frindlyExpression;
            }

            outputID = trimDataComponent.OutputCollection[0].ID;
            errorOutputID = trimDataComponent.OutputCollection[1].ID;

            trimDataComponentInstance.ReinitializeMetaData();
            trimDataComponentInstance.ReleaseConnections();

            return trimDataComponent;
        }

        public IDTSComponentMetaData90 BuildDefaultValueComponent(Package p, MainPipe pipe,
           IDTSComponentMetaData90 sourceComponent, int inputID, Collection<SSISMapping> mappings,
            bool useUnicode, int locale, Hashtable dataConversionlineageIDsList, out int outputID, out int errorOutputID)
        {
            IDTSComponentMetaData90 replaceColumn = pipe.ComponentMetaDataCollection.New();
            replaceColumn.ComponentClassID = "{9CF90BF0-5BCC-4C63-B91D-1F322DC12C26}";

            if (locale > 0)
            {
                replaceColumn.LocaleID = locale;
            }

            IDTSDesigntimeComponent90 replaceColumnInstance = replaceColumn.Instantiate();            
            replaceColumnInstance.ProvideComponentProperties();            

            replaceColumn.Name = "Derived column " + Guid.NewGuid().ToString();

            replaceColumn.InputCollection[0].ExternalMetadataColumnCollection.IsUsed = false;
            replaceColumn.InputCollection[0].HasSideEffects = false;

            if (inputID > -1)
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(sourceComponent.OutputCollection.FindObjectByID(inputID), replaceColumn.InputCollection[0]);
            }
            else
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(sourceComponent.OutputCollection[0], replaceColumn.InputCollection[0]);
            }

            replaceColumnInstance.AcquireConnections(null);

            Hashtable defaultValueList = new Hashtable();
            foreach (SSISMapping mapping in mappings)
            {
                defaultValueList.Add(mapping.SourceCol, mapping);
            }

            IDTSVirtualInput90 vInput = replaceColumn.InputCollection[0].GetVirtualInput();

            foreach (IDTSVirtualInputColumn90 evc in vInput.VirtualInputColumnCollection)
            {
                if (!defaultValueList.ContainsKey(evc.Name))
                {
                    break;
                }
                if (dataConversionlineageIDsList == null || (dataConversionlineageIDsList != null && dataConversionlineageIDsList.ContainsKey(evc.LineageID)))
                {
                    replaceColumnInstance.SetUsageType(replaceColumn.InputCollection[0].ID, vInput, evc.LineageID, DTSUsageType.UT_READWRITE);
                }
            }           

            foreach (IDTSInputColumn90 inputColumn in replaceColumn.InputCollection[0].InputColumnCollection)
            {
                if (!defaultValueList.ContainsKey(inputColumn.Name))
                {
                    break;
                }

                inputColumn.ErrorRowDisposition = DTSRowDisposition.RD_RedirectRow;
                inputColumn.TruncationRowDisposition = DTSRowDisposition.RD_RedirectRow;

                SSISMapping mapping = defaultValueList[inputColumn.Name] as SSISMapping;

                string frindlyExpression = string.Format("(ISNULL({0}) || LEN(TRIM({0})) == 0) ? \"{1}\" : {0}", inputColumn.Name, mapping.DefaultValue);
                string expression = string.Format("(ISNULL(#{0}) || LEN(TRIM(#{0})) == 0) ? \"{1}\" : #{0}", inputColumn.LineageID, mapping.DefaultValue);

                inputColumn.CustomPropertyCollection.RemoveAll();
                IDTSCustomProperty90 property = inputColumn.CustomPropertyCollection.New();
                property.Name = "Expression";
                property.Value = expression;
                property = inputColumn.CustomPropertyCollection.New();
                property.Name = "FriendlyExpression";
                property.Value = frindlyExpression;   
            }                        

            outputID = replaceColumn.OutputCollection[0].ID;
            errorOutputID = replaceColumn.OutputCollection[1].ID;

            replaceColumnInstance.ReinitializeMetaData();
            replaceColumnInstance.ReleaseConnections();

            return replaceColumn;
        }
    }
}
