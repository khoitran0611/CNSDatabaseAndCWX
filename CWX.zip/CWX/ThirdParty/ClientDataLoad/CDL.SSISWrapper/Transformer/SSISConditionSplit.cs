﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using w = Microsoft.SqlServer.Dts.Runtime.Wrapper;
using System.Collections;
using CDL.Common;

namespace CDL.SSISWrapper.Transformer
{
    public class SSISConditionSplit
    {
        public IDTSComponentMetaData90 BuildConditionSplitComponent(Package p, MainPipe pipe,
            IDTSComponentMetaData90 sourceComponent, int inputID, int locale,
            List<string> conditionList , out List<int> outputIDList)
        {
            IDTSComponentMetaData90 dataTransformer = pipe.ComponentMetaDataCollection.New();
            dataTransformer.ComponentClassID = "{53A228EE-EBFA-48D6-A1AC-5269E5824A2C}";

            if (locale > 0)
            {
                dataTransformer.LocaleID = locale;
            }

            IDTSDesigntimeComponent90 compDataSplit = dataTransformer.Instantiate();
            compDataSplit.ProvideComponentProperties();            

            pipe.PathCollection.New().AttachPathAndPropagateNotifications(
                            sourceComponent.OutputCollection.FindObjectByID(inputID), dataTransformer.InputCollection[0]);

            compDataSplit.AcquireConnections(null);

            outputIDList = new List<int>();

            int evaluationOrder = 0;
            for (int i = 0; i < conditionList.Count; i++)
            {
                if (conditionList[i] == CDLConstants.CONDITION_DEFAULT)
                {
                    outputIDList.Add(dataTransformer.OutputCollection[0].ID);
                    continue;
                }

                IDTSOutput90 dummyOut = dataTransformer.OutputCollection.New();
                dummyOut.Name = "Case " + dummyOut.ID;                
                dummyOut.SynchronousInputID = dataTransformer.InputCollection[0].ID;
                dummyOut.ExclusionGroup = 1;
                dummyOut.ErrorOrTruncationOperation = "Computation";
                dummyOut.TruncationRowDisposition = DTSRowDisposition.RD_FailComponent;
                dummyOut.ErrorRowDisposition = DTSRowDisposition.RD_FailComponent;                

                IDTSVirtualInput90 dtInput = dataTransformer.InputCollection[0].GetVirtualInput();
                dtInput = dataTransformer.InputCollection[0].GetVirtualInput();

                string friendlyExp = conditionList[i];
                string expression = friendlyExp;
                foreach (IDTSVirtualInputColumn90 vc in dtInput.VirtualInputColumnCollection)
                {
                    expression = expression.Replace("#" + vc.Name + "#", "#" + vc.LineageID.ToString());
                    friendlyExp = friendlyExp.Replace("#" + vc.Name + "#", vc.Name);
                    compDataSplit.SetUsageType(dataTransformer.InputCollection[0].ID, dtInput, vc.LineageID, DTSUsageType.UT_READONLY);
                }

                IDTSCustomProperty90 cp = dummyOut.CustomPropertyCollection.New();
                cp.Name = "Expression";
                cp.Value = expression;
                cp.ContainsID = true;
                cp = dummyOut.CustomPropertyCollection.New();
                cp.Name = "FriendlyExpression";
                cp.Value = friendlyExp;
                cp.ContainsID = true;
                cp.ExpressionType = DTSCustomPropertyExpressionType.CPET_NOTIFY;
                cp = dummyOut.CustomPropertyCollection.New();
                cp.Name = "EvaluationOrder";
                cp.Value = evaluationOrder;

                outputIDList.Add(dummyOut.ID);

                evaluationOrder++;
            }
            
            compDataSplit.ReinitializeMetaData();
            compDataSplit.ReleaseConnections();
            
            return dataTransformer;
        }
    }
}
