﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using w = Microsoft.SqlServer.Dts.Runtime.Wrapper;

namespace CDL.SSISWrapper.Transformer
{
    public class SSISLookUp
    {
        public IDTSComponentMetaData90 BuildLookupComponent(Package p, MainPipe pipe,
            IDTSComponentMetaData90 sourceComponent, int inputID,string sourceColName, 
            string destinationDBKeyField, string destinationTableName, string connectionString,
            out int outputID, out int errorOutputID)
        {
            ConnectionManager cm = p.Connections.Add("OLEDB");
            cm.ConnectionString = connectionString;
            string id = Guid.NewGuid().ToString();
            cm.Name = id;

            IDTSComponentMetaData90 lookup = pipe.ComponentMetaDataCollection.New();
            lookup.ComponentClassID = "{0FB4AABB-C027-4440-809A-1198049BF117}";

            IDTSDesigntimeComponent90 lookupInstance = lookup.Instantiate();
            lookupInstance.ProvideComponentProperties();

            lookup.RuntimeConnectionCollection[0].ConnectionManagerID = cm.ID;
            lookup.RuntimeConnectionCollection[0].ConnectionManager = DtsConvert.ToConnectionManager90(cm);
            lookup.Name = "Lookup" + Guid.NewGuid().ToString();

            lookupInstance.SetComponentProperty("SqlCommand", "SELECT " + destinationDBKeyField + " FROM " + destinationTableName);            
            lookupInstance.SetComponentProperty("DefaultCodePage", 1252);

            if (inputID > -1)
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(sourceComponent.OutputCollection.FindObjectByID(inputID), lookup.InputCollection[0]);
            }
            else
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(sourceComponent.OutputCollection[0], lookup.InputCollection[0]);
            }

            lookupInstance.AcquireConnections(null);

            lookup.OutputCollection[0].ErrorRowDisposition = DTSRowDisposition.RD_RedirectRow;
            lookup.OutputCollection[1].ErrorRowDisposition = DTSRowDisposition.RD_RedirectRow;

            IDTSVirtualInput90 vInput = lookup.InputCollection[0].GetVirtualInput();
            IDTSInputColumn90 lookupInputColumn = null;
            foreach (IDTSVirtualInputColumn90 evc in vInput.VirtualInputColumnCollection)
            {
                if (string.Compare(evc.Name, sourceColName, true) == 0)
                {
                    lookupInputColumn = lookupInstance.SetUsageType(lookup.InputCollection[0].ID, vInput, evc.LineageID, DTSUsageType.UT_READONLY);
                }
            }

            lookupInstance.SetInputColumnProperty(lookup.InputCollection[0].ID, lookupInputColumn.ID, "JoinToReferenceColumn", destinationDBKeyField);            

            outputID = lookup.OutputCollection[0].ID;
            errorOutputID = lookup.OutputCollection[1].ID;

            lookupInstance.ReinitializeMetaData();
            lookupInstance.ReleaseConnections();

            return lookup;
        }
    }
}
