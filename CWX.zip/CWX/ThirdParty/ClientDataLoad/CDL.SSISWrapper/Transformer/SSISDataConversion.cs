﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using w = Microsoft.SqlServer.Dts.Runtime.Wrapper;
using System.Collections.ObjectModel;
using CDL.SSISWrapper.Common;
using CDL.SSISWrapper.Mapping;
using System.Collections;

namespace CDL.SSISWrapper.Transformer
{
    internal class SSISDataConversion
    {
        public IDTSComponentMetaData90 BuildDataConversionComponent(Package p, MainPipe pipe,
           IDTSComponentMetaData90 sourceComponent, int inputID, Collection<SSISMapping> mappings,Hashtable lineageIDsList,
           bool useUnicode, int locale, out int outputID, out int errorOutputID, out Hashtable dataConversionlineageIDsList)
        {
            IDTSComponentMetaData90 dataConversion = pipe.ComponentMetaDataCollection.New();
            dataConversion.ComponentClassID = "{C3BF62C8-7C5C-4F85-83C3-E0B6F6BE267C}";

            if (locale > 0)
            {
                dataConversion.LocaleID = locale;
            }

            IDTSDesigntimeComponent90 dataConversionInstance = dataConversion.Instantiate();
            dataConversionInstance.ProvideComponentProperties();            

            dataConversion.Name = "Data Conversion " + Guid.NewGuid().ToString();
            dataConversion.InputCollection[0].ExternalMetadataColumnCollection.IsUsed = false;
            dataConversion.InputCollection[0].HasSideEffects = false;

            if (inputID > -1)
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(sourceComponent.OutputCollection.FindObjectByID(inputID), dataConversion.InputCollection[0]);
            }
            else
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(sourceComponent.OutputCollection[0], dataConversion.InputCollection[0]);
            }

            dataConversionInstance.AcquireConnections(null);

            IDTSVirtualInput90 vInput = dataConversion.InputCollection[0].GetVirtualInput();
            foreach (IDTSVirtualInputColumn90 vColumn in vInput.VirtualInputColumnCollection)
            {
                dataConversionInstance.SetUsageType(dataConversion.InputCollection[0].ID, vInput, vColumn.LineageID,DTSUsageType.UT_READONLY);
            }

            // putting the truncation row disposition
            dataConversion.OutputCollection[0].TruncationRowDisposition =DTSRowDisposition.RD_NotUsed;
            // putting the error row disposition
            dataConversion.OutputCollection[0].ErrorRowDisposition =DTSRowDisposition.RD_NotUsed;
            // get the output column collection reference
            IDTSOutput90 output = dataConversion.OutputCollection[0];

            dataConversionlineageIDsList = new Hashtable();
            foreach (SSISMapping mapping in mappings)
            {
                if (mapping.IsDerivedField)
                {
                    continue;
                }
                SSISColumnProperty columnProperty = SSISUtilities.BuildSSISColumnProperty(mapping, useUnicode);

                IDTSOutputColumn90 outputColumn = dataConversion.OutputCollection[0].OutputColumnCollection.New();
                outputColumn.Name = mapping.SourceCol;

                int codePage = 0;
                if (!useUnicode && mapping.FieldType == CDL.Common.DataType.String)
                {
                    codePage = 1252;
                }
                outputColumn.SetDataTypeProperties(columnProperty.DataType,columnProperty.Length,columnProperty.Precision,
                    columnProperty.Scale, codePage);

                // putting the external metadata column id to zero
                outputColumn.ExternalMetadataColumnID = 0;
                outputColumn.ErrorRowDisposition = DTSRowDisposition.RD_RedirectRow;
                outputColumn.TruncationRowDisposition = DTSRowDisposition.RD_RedirectRow;

                IDTSCustomProperty90 property = outputColumn.CustomPropertyCollection.New();
                property.Name = "SourceInputColumnLineageID";
                property.Value = lineageIDsList[mapping.SourceCol];
                property = outputColumn.CustomPropertyCollection.New();
                property.Name = "FastParse";
                property.Value = false;

                dataConversionlineageIDsList.Add(outputColumn.LineageID, outputColumn.Name);
            }

            outputID = dataConversion.OutputCollection[0].ID;
            errorOutputID = dataConversion.OutputCollection[1].ID;

            dataConversionInstance.ReinitializeMetaData();
            dataConversionInstance.ReleaseConnections();

            return dataConversion;
        }
    }
}
