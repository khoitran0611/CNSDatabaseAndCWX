﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.SSISWrapper.SourceWrapper;
using CDL.BusinessObject;
using System.Collections.ObjectModel;
using Microsoft.SqlServer.Dts.Runtime;
using CWX.Core.Common.Security;
using System.Threading;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using CDL.SSISWrapper.DestinationWrapper;
using CDL.SSISWrapper.Common;
using CWX.Core.Common.Exceptions;
using CDL.Common;
using System.Xml;
using System.Data.SqlClient;
using CDL.SSISWrapper.Transformer;
using CWX.Core.Common;
using System.Data;
using System.Collections;
using System.IO;
using CDL.SSISWrapper.Mapping;
using CWX.Core.Common.Data;
using System.Text.RegularExpressions;

namespace CDL.SSISWrapper.PackageWrapper
{
	public class SSISPackage
	{
        const string ALL_FIELD_NULL = "ALLFIELDSNULL";
        const string UN_SATISFY_FILTER_CONDITION = "UNSATISFYFILTERCONDITION";
        const string ERROR = "ERROR";
        const string DERIVED_ERROR = "DERIVEDERROR";

        #region Properties        

        private ImportSource _ImportSource;

        private Collection<SourceMapDetails> _Mappings;

        private SourceMapTemplate _SourceMapTemplate;

        private SSISSourceBase _SsisSource;

        private string _KeyField;

		#endregion

		#region Constructors

		public SSISPackage(ImportSource importSource, SourceMapTemplate sourceMapTemplate, Collection<SourceMapDetails> mappings)
		{
			_ImportSource = importSource;
			_Mappings = mappings;
			_SourceMapTemplate = sourceMapTemplate;
            if (_SourceMapTemplate.KeyColumn != null)
            {
                foreach (SourceMapDetails item in mappings)
                {
                    //primary key
                    if (item.ID == _SourceMapTemplate.KeyColumn.ID)
                    {
                        _KeyField = item.DestField;
                        item.AllowsNull = false;
                    }
                    else
                    {
                        item.AllowsNull = true;
                    }
                }
            }

			_SsisSource = SSISSourceWrapperFactory.CreateSSISSource(_ImportSource, _Mappings, _SourceMapTemplate, string.Empty, null);

		}

		#endregion

        #region Import methods

        public ImportResult ImportFlatFile2DB(string flatFileImport, string errorFilePath)
        {
            string tableName = _SourceMapTemplate.DestTable;
            string random = Guid.NewGuid().ToString();
            string tempDestinationTableName = string.Format("{0}_{1}",tableName,random);
            string unSatisfyDataTableName = string.Format("{0}_{1}_{2}", UN_SATISFY_FILTER_CONDITION, tableName, random);
            string allFieldsNullDataTableName = string.Format("{0}_{1}_{2}", ALL_FIELD_NULL, tableName, random);
            string errorDataTableName = string.Format("{0}_{1}_{2}", ERROR, tableName, random);
            string derivedColumnErrorDataTableName = string.Format("{0}_{1}_{2}", DERIVED_ERROR, tableName, random);

            string databaseElementName = CDLUtilities.GetDatabaseElementName(_SourceMapTemplate.DestDatabase);

            ImportResult result = null;
            string[] tableNames = new string[] { unSatisfyDataTableName, allFieldsNullDataTableName, errorDataTableName, derivedColumnErrorDataTableName,tempDestinationTableName };
            try
            {
                SSISUtilities.CreateDestinationTableFromMappingFields(_SsisSource.Mappings, databaseElementName, _SourceMapTemplate.Unicode, _SourceMapTemplate.DestTable);
                DataTable table = new DataTable();
                DataSet ds1 = new DataSet();
                
                //Prepare OLEDB Connection string for DB Destination
                _SsisSource.ConnectionString = flatFileImport;
                string oledbConnectionString = CDLUtilities.GetOLDBConnectionString(_SourceMapTemplate.DestDatabase);                                
                
                //Create Package.
                Package package = CreatePackage("CWX import data", "Import flat file to SQL server");
                MainPipe pipe = CreateMainPipe(package, "Import task");

                //Build Source Component
                int sourceOutputID = -1;
                int sourceErrorOutputID = -1;
                IDTSComponentMetaData90 ssisSourceComponent = _SsisSource.BuildSourceComponent(package, pipe, out sourceOutputID,out sourceErrorOutputID);
                Hashtable lineageIDsList = new Hashtable();
                foreach (IDTSOutputColumn90 outputColumn in ssisSourceComponent.OutputCollection[0].OutputColumnCollection)
                {   // create the MAP                
                    lineageIDsList.Add(outputColumn.Name, outputColumn.ID);
                }
                //Build error for source component. This table contain Error data. 
                SetUpDBDestinationForFlatFileError(errorDataTableName, databaseElementName, oledbConnectionString, package, pipe, sourceErrorOutputID, ssisSourceComponent);

                //Build trim component
                int trimComponentOutputID = -1;
                int trimComponentErrorOutputID = -1;
                IDTSComponentMetaData90 ssisTrimComponent = new SSISDerivedColumn().BuildTrimDataComponent(package, pipe, ssisSourceComponent, sourceOutputID,null,
                    _SourceMapTemplate.Unicode,_SourceMapTemplate.LocaleID, out trimComponentOutputID, out trimComponentErrorOutputID);

                //Build error for trim component. 
                SetUpDBDestinationForError(derivedColumnErrorDataTableName, databaseElementName, oledbConnectionString,
                    package, pipe, trimComponentErrorOutputID, ssisTrimComponent,null);

                //Build filter
                List<string> conditionList;
                List<SSISDatabaseDestination> ssisDestinationList;
                SetUpConditions2Filter(tempDestinationTableName, unSatisfyDataTableName, allFieldsNullDataTableName,
                    oledbConnectionString, out conditionList, out ssisDestinationList);

                //Build condition split, filter all record null on all column
                SSISConditionSplit ssisConditionSplit = new SSISConditionSplit();
                List<int> conditionSplitOutputIDList = new List<int>();
                IDTSComponentMetaData90 ssisConditionSplitComponent = ssisConditionSplit.BuildConditionSplitComponent(package, pipe,
                    ssisTrimComponent, trimComponentOutputID,_SourceMapTemplate.LocaleID, conditionList, out conditionSplitOutputIDList);

                int splitDataOutputIndex = -1;

                for (int i = 0; i < conditionList.Count; i++)
                {
                    if (!SSISUtilities.IsTableExisting(databaseElementName, ssisDestinationList[i].TableName))
                    {
                        if (ssisDestinationList[i].DBDestinationType == DatabaseDestinationType.Error)
                        {
                            SSISUtilities.CreateErrorTable(_SsisSource.Mappings, databaseElementName, ssisDestinationList[i].TableName,DataSourceType.Database, _SourceMapTemplate.Unicode);
                        }
                        else
                        {
                            SSISUtilities.CreateTempDestinationTable(databaseElementName, tableName, tempDestinationTableName, _SourceMapTemplate.DestDatabase, _SourceMapTemplate.Unicode, this._SsisSource.Mappings);
                        }
                    }

                    if (ssisDestinationList[i].DBDestinationType == DatabaseDestinationType.Data)
                    {
                        splitDataOutputIndex = i;                        
                    }
                    else
                    {
                        ssisDestinationList[i].BuildDestinationComponent(package, pipe, ssisConditionSplitComponent, conditionSplitOutputIDList[i], this._SsisSource.Mappings,null);
                    }
                }

                //Build defaul value component
                int defaultValueOutputID = -1;
                int defaultValueErrorOutputID = -1;
                IDTSComponentMetaData90 ssisDefaultValueComponent = new SSISDerivedColumn().BuildDefaultValueComponent(package, pipe,
                    ssisConditionSplitComponent, conditionSplitOutputIDList[splitDataOutputIndex], _SsisSource.Mappings, _SourceMapTemplate.Unicode, _SourceMapTemplate.LocaleID, 
                    null, out defaultValueOutputID, out defaultValueErrorOutputID);
                //Build error for default value component. 
                SetUpDBDestinationForError(derivedColumnErrorDataTableName, databaseElementName, oledbConnectionString,
                    package, pipe, defaultValueErrorOutputID, ssisDefaultValueComponent,null);

                //Build data conversion component
                int dataConversionOutputID = -1;
                int dataConversionErrorOutputID = -1;
                Hashtable dataConversionlineageIDsList = new Hashtable();
                IDTSComponentMetaData90 ssisDataConversionComponent = new SSISDataConversion().BuildDataConversionComponent(package, pipe,
                    ssisDefaultValueComponent, defaultValueOutputID, _SsisSource.Mappings,lineageIDsList, _SourceMapTemplate.Unicode,_SourceMapTemplate.LocaleID,
                    out dataConversionOutputID, out dataConversionErrorOutputID, out dataConversionlineageIDsList);
                //Build error for data conversion component. 
                SetUpDBDestinationForError(derivedColumnErrorDataTableName, databaseElementName, oledbConnectionString,
                    package, pipe, dataConversionErrorOutputID, ssisDataConversionComponent,null);

                //Build derived column
                int derivedColumnOutputID = -1;
                int derivedColumnErrorOutputID = -1;
                IDTSComponentMetaData90 ssisDerivedColumnComponent = new SSISDerivedColumn().BuildDerivedColumnComponent(package, pipe, ssisDataConversionComponent, dataConversionOutputID,
                    _SsisSource.Mappings, _SourceMapTemplate.Unicode, _SourceMapTemplate.LocaleID, dataConversionlineageIDsList, out derivedColumnOutputID, out derivedColumnErrorOutputID);
                //Build error for derived component. 
                SetUpDBDestinationForError(derivedColumnErrorDataTableName, databaseElementName, oledbConnectionString,
                    package, pipe, derivedColumnErrorOutputID, ssisDerivedColumnComponent, dataConversionlineageIDsList);

                ssisDestinationList[splitDataOutputIndex].BuildDestinationComponent(package, pipe, ssisDerivedColumnComponent, derivedColumnOutputID, this._SsisSource.Mappings, dataConversionlineageIDsList);

                //Validate Package
                ValidatePackage(package);

                //string a;
                //package.SaveToXML(out a, null);

                //Execute package
                DTSExecResult dtsResult = ExecutePackage(package);
                if (dtsResult == DTSExecResult.Success)
                {
                    if (SSISUtilities.CopyData(databaseElementName, tempDestinationTableName, tableName, _KeyField, _SourceMapTemplate.DestDatabase,_SourceMapTemplate.AllowDuplicateKey))
                    {
                        result = GetImportResult(package,tempDestinationTableName, unSatisfyDataTableName, allFieldsNullDataTableName, errorDataTableName, derivedColumnErrorDataTableName,databaseElementName);
                        result.DestinationTable = tableName;
                        result.ImportFile = flatFileImport;
                        result.SourceType = DataSourceType.TextFile;
                        //generate duplicate report                        
                        GenerateRejectedRecordsReport(tableNames, errorFilePath);
                    }
                }
            }
            finally
            {                
                SSISUtilities.DropTables(databaseElementName, tableNames);    
            }
            return result;
        }

        public ImportResult ImportExcelFile2DB(string excelFileImport, string sheetName, string errorFilePath)
        {
            //we need parse excel to csv to import
            string csvFilePath = CDLUtilities.ParseExcel2CVS(excelFileImport, sheetName);
            _ImportSource.Type = DataSourceType.CSVFile;
            _ImportSource.RecordDelimiter = CDLConstants.Delimiter.CRLF;
            _SourceMapTemplate.Unicode = true;
            _SsisSource = SSISSourceWrapperFactory.CreateSSISSource(_ImportSource, _Mappings, _SourceMapTemplate, string.Empty,"\"");
            return ImportFlatFile2DB(csvFilePath, errorFilePath);
        }

        public bool ValidatePackage(string dbElement,string destableName)
        {
            bool isValid = true;
            string tableName = SSISUtilities.CreateTempTable(_SsisSource.Mappings, dbElement, true);
            SSISUtilities.CreateDestinationTableFromMappingFields(_SsisSource.Mappings, dbElement, true, destableName);
            SSISUtilities.ValidateSQLSyntax(_SsisSource.Mappings, dbElement, tableName, destableName);
            return isValid;
        }

        #endregion

        #region helper methods

        internal Package CreatePackage(string name, string description)
        {
            Package package = new Package();
            package.PackageType = DTSPackageType.DTSDesigner90;
            package.Name = name;
            package.Description = description;
            package.CreatorComputerName = System.Environment.MachineName;
            package.CreatorName = ((CWXIdentity)Thread.CurrentPrincipal.Identity).UserID.ToString();
            return package;
        }

        internal MainPipe CreateMainPipe(Package package, string name)
        {
            TaskHost th = package.Executables.Add("DTS.Pipeline.1") as TaskHost;
            th.Name = name;
            th.Description = "";
            MainPipe pipe = th.InnerObject as MainPipe;
            return pipe;
        }

        internal void ValidatePackage(Package package)
        {
            // Validate the layout of the package.
            DTSExecResult status = package.Validate(null, null, null, null);
            if (status != DTSExecResult.Success)
            {
                StringBuilder errorBuilder = BuildErrorMessage(package, "Validate package fail!");
                throw new CWXException(errorBuilder.ToString());
            }
        }

        internal DTSExecResult ExecutePackage(Package package)
        {
            // Execute the package
            DTSExecResult status = package.Execute(null, null, null, null, null);

            if (status != DTSExecResult.Success)
            {
                StringBuilder errorBuilder = BuildErrorMessage(package, "Execute package fail!");
                throw new CWXException(errorBuilder.ToString());
            }
            return status;
        }

        private StringBuilder BuildErrorMessage(Package package, string title)
        {
            StringBuilder errorBuilder = new StringBuilder();
            errorBuilder.AppendLine(title);
            foreach (DtsError dtsError in package.Errors)
            {
                errorBuilder.AppendLine(dtsError.Description);
            }
            return errorBuilder;
        }

        private ImportResult GetImportResult(Package package, string tempDestinationTable,string unSatisfyDataTableName, string allFieldsNullDataTableName, string errorDataTableName,string deriveColumnErrorTableName,string databaseElementName)
        {
            ImportResult result = new ImportResult();
            result.StartTime = package.StartTime;
            result.EndTime = package.StopTime;
            result.NumberofImportedRows = SSISUtilities.GetTableRows(databaseElementName, tempDestinationTable, " __COLUMN_STATUS__ = 1 ");
            result.NumberofDuplicatedRows = SSISUtilities.GetTableRows(databaseElementName, tempDestinationTable, " __COLUMN_STATUS__ = 0 ");
            result.NumberofAllFieldNullRows = SSISUtilities.GetTableRows(databaseElementName, allFieldsNullDataTableName,"");
            result.NumberofUnsatisfyConditionRows = SSISUtilities.GetTableRows(databaseElementName, unSatisfyDataTableName,"");
            result.NumberOfSkippedRows = SSISUtilities.GetTableRows(databaseElementName, errorDataTableName,"");
            result.NumberOfSkippedRows += SSISUtilities.GetTableRows(databaseElementName, deriveColumnErrorTableName,"");
            
            return result;
        }

        private void SetUpConditions2Filter(string tempDestinationTableName, string unSatisfyDataTableName, string allFieldsNullDataTableName,
            string oledbConnectionString, out List<string> conditionList, out List<SSISDatabaseDestination> ssisDestinationList)
        {
            //Build conditions list to filter
            conditionList = new List<string>();
            ssisDestinationList = new List<SSISDatabaseDestination>();

            conditionList.Add(CDLConstants.CONDITION_DEFAULT);
            //Table contain data that does not satisfy condition filter and all fields null
            //if conditionFilter= null or empty then this table will contain final data (data will be copy to destination table)
            SSISDatabaseDestination unSatisfySSISDBDestination = SSISDestinationWrapperFactory.CreateSSISDestination(CDL.Common.DataSourceType.Database, oledbConnectionString) as SSISDatabaseDestination;
            if (string.IsNullOrEmpty(_SsisSource.Condition2Validation))
            {
                //unSatisfySSISDBDestination.TableName = tableName;
                unSatisfySSISDBDestination.TableName = tempDestinationTableName;
                unSatisfySSISDBDestination.DBDestinationType = DatabaseDestinationType.Data;
            }
            else
            {
                unSatisfySSISDBDestination.TableName = unSatisfyDataTableName;
                unSatisfySSISDBDestination.DBDestinationType = DatabaseDestinationType.Error;
            }

            ssisDestinationList.Add(unSatisfySSISDBDestination);

            //Table contain data that have all field null or empty. 
            conditionList.Add(_SsisSource.Condition2FilterRecordsNull);
            SSISDatabaseDestination ssisDBAllFieldNullDestination = SSISDestinationWrapperFactory.CreateSSISDestination(CDL.Common.DataSourceType.Database, oledbConnectionString) as SSISDatabaseDestination;
            ssisDBAllFieldNullDestination.TableName = allFieldsNullDataTableName;
            ssisDBAllFieldNullDestination.DBDestinationType = DatabaseDestinationType.Error;
            ssisDestinationList.Add(ssisDBAllFieldNullDestination);

            //Table contain satisfy data. Data from this table will be copy to destination table. 
            if (!string.IsNullOrEmpty(_SsisSource.Condition2Validation))
            {
                conditionList.Add(_SsisSource.Condition2Validation);
                SSISDatabaseDestination satisfyDataSSISDBDestination = SSISDestinationWrapperFactory.CreateSSISDestination(CDL.Common.DataSourceType.Database, oledbConnectionString) as SSISDatabaseDestination;
                //satisfyDataSSISDBDestination.TableName = tableName;
                satisfyDataSSISDBDestination.TableName = tempDestinationTableName;
                satisfyDataSSISDBDestination.DBDestinationType = DatabaseDestinationType.Data;
                ssisDestinationList.Add(satisfyDataSSISDBDestination);
            }
        }

        private void SetUpDBDestinationForFlatFileError(string tableName, string databaseElementName, string oledbConnectionString,
            Package package, MainPipe pipe, int sourceErrorOutputID, IDTSComponentMetaData90 ssisSourceComponent)
        {
            SSISDatabaseDestination ssisDestination = SSISDestinationWrapperFactory.CreateSSISDestination(CDL.Common.DataSourceType.Database, oledbConnectionString) as SSISDatabaseDestination;
            ssisDestination.TableName = tableName;
            ssisDestination.DBDestinationType = DatabaseDestinationType.Error;
            SSISUtilities.CreateErrorTable(_SsisSource.Mappings, databaseElementName, ssisDestination.TableName, DataSourceType.TextFile, _SourceMapTemplate.Unicode);
            ssisDestination.BuildDestinationComponent(package, pipe, ssisSourceComponent, sourceErrorOutputID, null,null);
        }

        private void SetUpDBDestinationForError(string tableName, string databaseElementName, string oledbConnectionString,
            Package package, MainPipe pipe, int sourceErrorOutputID, IDTSComponentMetaData90 ssisSourceComponent, Hashtable dataConversionlineageIDsList)
        {
            SSISDatabaseDestination ssisDestination = SSISDestinationWrapperFactory.CreateSSISDestination(CDL.Common.DataSourceType.Database, oledbConnectionString) as SSISDatabaseDestination;
            ssisDestination.TableName = tableName;
            ssisDestination.DBDestinationType = DatabaseDestinationType.Error;
            SSISUtilities.CreateErrorTable(_SsisSource.Mappings, databaseElementName, ssisDestination.TableName, DataSourceType.Database, _SourceMapTemplate.Unicode);
            ssisDestination.BuildDestinationComponent(package, pipe, ssisSourceComponent, sourceErrorOutputID, null, dataConversionlineageIDsList);
        }

        private void GenerateRejectedRecordsReport(string[] tableNames, string errorFilePath)
        {
            StringBuilder errorContain = new StringBuilder();
            string databaseElementName = CDLUtilities.GetDatabaseElementName(_SourceMapTemplate.DestDatabase);
            foreach (string tableName in tableNames)
            {
                StringBuilder sqlQueryBuilder = new StringBuilder();
                Regex reg = new Regex("^" + ERROR);
                if (reg.IsMatch(tableName))
                {
                    sqlQueryBuilder.AppendFormat("SELECT [Flat File Source Error Output Column] FROM [{0}] ",tableName);
                }
                else
                {
                    sqlQueryBuilder.Append("SELECT ");
                    for(int i =0; i<_SsisSource.Mappings.Count;i++)
                    {
                        if (_SsisSource.Mappings[i].IsDerivedField)
                        {
                            continue;
                        }
                        reg=new Regex("^" + _SourceMapTemplate.DestTable);
                        if (reg.IsMatch(tableName))
                        {
                            sqlQueryBuilder.AppendFormat(" [{0}] ,", string.IsNullOrEmpty(_SsisSource.Mappings[i].DestField)?"__" + _SsisSource.Mappings[i].SourceCol + "__":_SsisSource.Mappings[i].DestField);
                        }
                        else
                        {
                            sqlQueryBuilder.AppendFormat(" [{0}] ,", _SsisSource.Mappings[i].SourceCol);
                        }
                    }

                    sqlQueryBuilder = sqlQueryBuilder.Remove(sqlQueryBuilder.Length - 1, 1);
                    sqlQueryBuilder.AppendFormat(" FROM [{0}]", tableName);
                }
                using (IDataExecutionContext dataContext = new DataProviderFactory().Create(databaseElementName).BeginExecution())
                {
                    dataContext.SetCommandText(sqlQueryBuilder.ToString(), CommandType.Text);                                        
                    using (IDataReader reader = dataContext.RunReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            reg = new Regex("^" + ERROR);
                            if (reg.IsMatch(tableName))
                            {
                                errorContain.Append(reader.GetValue(0));
                                errorContain.AppendLine();
                            }
                            else
                            {
                                reg = new Regex("^" + _SourceMapTemplate.DestTable);
                                bool baseOnSourceCol =true;
                                if(reg.IsMatch(tableName))
                                    baseOnSourceCol=false;
                                if (_ImportSource.Fixed)
                                {
                                    BuildRejectedRecordsFixWidthFormat(reader, errorContain, baseOnSourceCol);
                                }
                                else
                                {
                                    BuildRejectedRecordsDelimiterFormat(reader, errorContain, baseOnSourceCol);
                                }
                            }
                        }
                    }
                }
            }
            if (!string.IsNullOrEmpty(errorContain.ToString()))
            {
                using (FileStream fstr = new FileStream(errorFilePath, FileMode.Create, FileAccess.ReadWrite))
                {
                    using (StreamWriter sw = new StreamWriter(fstr))
                    {
                        sw.BaseStream.Seek(0, SeekOrigin.End);
                        sw.WriteLine(errorContain.ToString());
                        sw.Flush();
                    }
                }
            }
        }

        private void BuildRejectedRecordsFixWidthFormat(IDataReader reader, StringBuilder errorContain,bool baseOnSourceCol)
        {
            foreach (SSISMapping mapping in _SsisSource.Mappings)
            {
                if (mapping.IsDerivedField)
                {
                    continue;
                }
                int index = -1;
                if(baseOnSourceCol)
                    index= reader.GetOrdinal(mapping.SourceCol);                
                else
                    index = reader.GetOrdinal(string.IsNullOrEmpty(mapping.DestField)?"__" + mapping.SourceCol + "__":mapping.DestField);                

                errorContain.AppendFormat("{" + string.Format("{0},{1}", 0, mapping.ColumnWidth) + "}", reader.GetValue(index));                                
            }
            errorContain.AppendLine();
        }

        private void BuildRejectedRecordsDelimiterFormat(IDataReader reader, StringBuilder errorContain, bool baseOnSourceCol)
        {
            foreach (SSISMapping mapping in _SsisSource.Mappings)
            {
                if (mapping.IsDerivedField)
                {
                    continue;
                }
                int index = -1;
                if (baseOnSourceCol)
                    index = reader.GetOrdinal(mapping.SourceCol);
                else
                    index = reader.GetOrdinal(string.IsNullOrEmpty(mapping.DestField) ? "__" + mapping.SourceCol + "__" : mapping.DestField);

                string fieldDelimiter = string.IsNullOrEmpty(_ImportSource.FieldDelimiter) ? "," : _ImportSource.FieldDelimiter;
                string value = reader.GetValue(index).ToString().Replace(fieldDelimiter, @"\" + _ImportSource.FieldDelimiter);
                errorContain.AppendFormat("{0}{1}", value, _SsisSource.Mappings.IndexOf(mapping) == _SsisSource.Mappings.Count - 1 ? "" : fieldDelimiter);
            }
            errorContain.AppendLine();
        }

        #endregion
    }
}
