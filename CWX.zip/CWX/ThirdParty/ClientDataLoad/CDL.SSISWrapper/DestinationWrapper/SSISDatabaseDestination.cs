﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using System.Collections.ObjectModel;
using CDL.SSISWrapper.Mapping;
using CDL.Common;
using System.Collections;


namespace CDL.SSISWrapper.DestinationWrapper
{
    internal class SSISDatabaseDestination : SSISDestinationBase
	{
        public string TableName { get; set; }

        public DatabaseDestinationType DBDestinationType
        {
            get;
            set;
        }

        public override void BuildDestinationComponent(Package p, MainPipe pipe,
            IDTSComponentMetaData90 dataTransformer, int outputID, Collection<SSISMapping> mappings, Hashtable dataConversionlineageIDsList)
        {
            ConnectionManager cm = p.Connections.Add("OLEDB");            
            cm.ConnectionString = ConnectionString;
            string id = Guid.NewGuid().ToString();
            cm.Name = id;

            IDTSComponentMetaData90 databaseDestination = pipe.ComponentMetaDataCollection.New();
            databaseDestination.ComponentClassID = "DTSAdapter.OLEDBDestination";            

            CManagedComponentWrapper databaseDestinationInstance = databaseDestination.Instantiate();
            databaseDestinationInstance.ProvideComponentProperties();
            databaseDestination.RuntimeConnectionCollection[0].ConnectionManagerID = cm.ID;
            databaseDestination.RuntimeConnectionCollection[0].ConnectionManager = DtsConvert.ToConnectionManager90(cm);
            databaseDestination.Name = "DatabaseDesination" + Guid.NewGuid().ToString();
            databaseDestination.Description = "Destination data in the dataFlow";

            databaseDestinationInstance.SetComponentProperty("OpenRowset", "[dbo].[" + TableName + "]");
            databaseDestinationInstance.SetComponentProperty("AccessMode", 3);
            databaseDestinationInstance.SetComponentProperty("CommandTimeout", 0);
            databaseDestinationInstance.SetComponentProperty("FastLoadMaxInsertCommitSize", 0);
            databaseDestinationInstance.SetComponentProperty("FastLoadOptions", "TABLOCK");
            databaseDestinationInstance.SetComponentProperty("FastLoadKeepNulls", false);
            databaseDestinationInstance.SetComponentProperty("FastLoadKeepIdentity", false);
            databaseDestinationInstance.SetComponentProperty("AlwaysUseDefaultCodePage", false);
            databaseDestinationInstance.SetComponentProperty("DefaultCodePage", 1252);

            if (outputID > -1)
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(dataTransformer.OutputCollection.FindObjectByID(outputID), databaseDestination.InputCollection[0]);
            }
            else
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(dataTransformer.OutputCollection[0], databaseDestination.InputCollection[0]);
            }

            databaseDestinationInstance.AcquireConnections(null);
            databaseDestinationInstance.ReinitializeMetaData();

            IDTSVirtualInput90 vInput = databaseDestination.InputCollection[0].GetVirtualInput();

            foreach (IDTSVirtualInputColumn90 evc in vInput.VirtualInputColumnCollection)
            {
                if (dataConversionlineageIDsList == null ||(dataConversionlineageIDsList != null && dataConversionlineageIDsList.ContainsKey(evc.LineageID)))
                {
                    databaseDestinationInstance.SetUsageType(databaseDestination.InputCollection[0].ID, vInput, evc.LineageID, DTSUsageType.UT_READONLY);
                }
            }

            if (this.DBDestinationType == DatabaseDestinationType.Data)
            {
                //Find input field 
                List<int> invalidInputFields = new List<int>();
                foreach (IDTSInputColumn90 eic in databaseDestination.InputCollection[0].InputColumnCollection)
                {
                    try
                    {
                        bool invalidField = false;
                        foreach (SSISMapping itemMapping in mappings)
                        {                            
                            if (itemMapping.SourceCol == eic.Name)
                            {
                                IDTSExternalMetadataColumn90 emc;
                                if (!string.IsNullOrEmpty(itemMapping.DestField))
                                {
                                    emc = databaseDestination.InputCollection[0].ExternalMetadataColumnCollection[itemMapping.DestField];
                                }
                                else
                                {
                                    emc = databaseDestination.InputCollection[0].ExternalMetadataColumnCollection["__" + itemMapping.SourceCol + "__"];
                                }
                                invalidField = true;
                                break;
                            }
                        }
                        if (!invalidField)
                        {
                            invalidInputFields.Add(eic.ID);
                        }
                    }
                    catch
                    {
                        invalidInputFields.Add(eic.ID);
                    }
                }

                foreach (int invalidInput in invalidInputFields)
                {
                    databaseDestination.InputCollection[0].InputColumnCollection.RemoveObjectByID(invalidInput);
                }
            }

            foreach (IDTSInputColumn90 eic in databaseDestination.InputCollection[0].InputColumnCollection)
            {                
                if (this.DBDestinationType == DatabaseDestinationType.Data)
                {                    
                    foreach (SSISMapping itemMapping in mappings)
                    {
                        if (itemMapping.SourceCol == eic.Name)
                        {
                            IDTSExternalMetadataColumn90 emc;
                            if (!string.IsNullOrEmpty(itemMapping.DestField))
                            {
                                emc = databaseDestination.InputCollection[0].ExternalMetadataColumnCollection[itemMapping.DestField];
                            }
                            else
                            {
                                emc = databaseDestination.InputCollection[0].ExternalMetadataColumnCollection["__" + itemMapping.SourceCol + "__"];
                            }
                            databaseDestinationInstance.MapInputColumn(databaseDestination.InputCollection[0].ID, eic.ID, emc.ID);
                            break;
                        }
                    }                    
                }
                else
                {
                    IDTSExternalMetadataColumn90 emc = databaseDestination.InputCollection[0].ExternalMetadataColumnCollection[eic.Name];
                    databaseDestinationInstance.MapInputColumn(databaseDestination.InputCollection[0].ID, eic.ID, emc.ID);
                }
            }
            
            databaseDestinationInstance.ReleaseConnections();
        }
    }
}
