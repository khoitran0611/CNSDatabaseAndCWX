﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using Microsoft.SqlServer.Dts.Runtime;
using System.Collections.ObjectModel;
using CDL.SSISWrapper.Mapping;
using System.Collections;

namespace CDL.SSISWrapper.DestinationWrapper
{
	internal abstract class SSISDestinationBase
    {
        #region Properties

        /// <summary>
        /// connection string to source.        
        /// </summary>
        public string ConnectionString
        {
            get;
            set;
        }

        #endregion

        #region Abstract methods

        public abstract void BuildDestinationComponent(Package p, MainPipe pipe, IDTSComponentMetaData90 dataTransformer, int outputID, Collection<SSISMapping> mappings, Hashtable dataConversionlineageIDsList);

        #endregion
    }
}
