﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using w = Microsoft.SqlServer.Dts.Runtime.Wrapper;
using CDL.Common;
using System.Collections.ObjectModel;
using CDL.SSISWrapper.Mapping;
using System.Collections;

namespace CDL.SSISWrapper.DestinationWrapper
{
    internal class SSISFlatFileDestination : SSISDestinationBase
	{
        #region Properties
        private string _recordDelimiter = CDLConstants.Delimiter.CRLF;
        public string RecordDelimiter
        {
            get { return _recordDelimiter; }
            set { _recordDelimiter = value; }
        }

        private string _fieldDelimiter = CDLConstants.Delimiter.Comma;
        public string FieldDelimiter
        {
            get { return _fieldDelimiter; }
            set { _fieldDelimiter = value; }
        }

        private bool _firstLineContainsHeaders = false;
        public bool FirstLineContainsHeaders
        {
            get { return _firstLineContainsHeaders; }
            set { _firstLineContainsHeaders = value; }
        }

        public int Locale
        {
            get;
            set;
        }

        public bool UseUnicode
        {
            get;
            set;
        }

        #endregion

        public override void BuildDestinationComponent(Package package, MainPipe pipe,
            IDTSComponentMetaData90 dataTransformer, int outputID, Collection<SSISMapping> mappings, Hashtable dataConversionlineageIDsList)
        {
            this.RecordDelimiter = "\r\n";

            ConnectionManager cmFF = package.Connections.Add("FLATFILE");
            cmFF.ConnectionString = this.ConnectionString;
            string id = Guid.NewGuid().ToString();
            cmFF.Name = id;
            cmFF.Properties["Format"].SetValue(cmFF, "Delimited");
            cmFF.Properties["DataRowsToSkip"].SetValue(cmFF, 0);
            cmFF.Properties["ColumnNamesInFirstDataRow"].SetValue(cmFF, this.FirstLineContainsHeaders);
            cmFF.Properties["HeaderRowDelimiter"].SetValue(cmFF, this.RecordDelimiter);
            cmFF.Properties["HeaderRowsToSkip"].SetValue(cmFF, 0);
            cmFF.Properties["RowDelimiter"].SetValue(cmFF, this.RecordDelimiter);
            if (UseUnicode)
            {
                cmFF.Properties["Unicode"].SetValue(cmFF, true);
            }
            if (Locale > 0)
            {
                cmFF.Properties["LocaleID"].SetValue(cmFF, Locale);
            }

            IDTSComponentMetaData90 fileDestination = pipe.ComponentMetaDataCollection.New();
            fileDestination.ComponentClassID = "DTSAdapter.FlatFileDestination.1";
            fileDestination.Name = "FlatFileDestination" + Guid.NewGuid().ToString();
            fileDestination.Description = "Flat file destination";
            fileDestination.ValidateExternalMetadata = true;

            CManagedComponentWrapper fileDestinationInstance = fileDestination.Instantiate();
            fileDestinationInstance.ProvideComponentProperties();
            fileDestinationInstance.SetComponentProperty("Overwrite", true);

            fileDestination.RuntimeConnectionCollection[0].ConnectionManagerID = cmFF.ID;
            fileDestination.RuntimeConnectionCollection[0].ConnectionManager = DtsConvert.ToConnectionManager90(cmFF);

            if (outputID > -1)
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(dataTransformer.OutputCollection.FindObjectByID(outputID), fileDestination.InputCollection[0]);
            }
            else
            {
                pipe.PathCollection.New().AttachPathAndPropagateNotifications(dataTransformer.OutputCollection[0], fileDestination.InputCollection[0]);
            }

            w.IDTSConnectionManagerFlatFile90 ffConn = package.Connections[id].InnerObject as w.IDTSConnectionManagerFlatFile90;
            DtsConvert.ToConnectionManager90(package.Connections[id]);

            if (ffConn != null)
            {
                IDTSVirtualInputColumnCollection90 vColumns = fileDestination.InputCollection[0].GetVirtualInput().VirtualInputColumnCollection;


                for (int cols = 0; cols < vColumns.Count; cols++)
                {

                    w.IDTSConnectionManagerFlatFileColumn90 vCol = ffConn.Columns.Add();
                    if (cols == vColumns.Count - 1)
                        vCol.ColumnDelimiter = this.RecordDelimiter;
                    else
                        vCol.ColumnDelimiter = this.FieldDelimiter;

                    vCol.ColumnType = "Delimited";
                    vCol.DataType = vColumns[cols].DataType;
                    vCol.DataPrecision = vColumns[cols].Precision;
                    vCol.DataScale = vColumns[cols].Scale;
                    vCol.MaximumWidth = vColumns[cols].Length;

                    w.IDTSName90 vColName = vCol as w.IDTSName90;
                    string ln = vColumns[cols].Name.ToLowerInvariant();

                    vColName.Name = vColumns[cols].Name;
                }

                fileDestinationInstance.AcquireConnections(null);
                fileDestinationInstance.ReinitializeMetaData();

                IDTSInput90 input = fileDestination.InputCollection[0];
                input.InputColumnCollection.RemoveAll();
                int inputID = input.ID;

                IDTSVirtualInput90 vInput = input.GetVirtualInput();
                foreach (IDTSVirtualInputColumn90 vic in vInput.VirtualInputColumnCollection)
                {

                    fileDestinationInstance.SetUsageType(inputID, vInput, vic.LineageID, DTSUsageType.UT_READONLY);
                }

                int idx = 0;
                foreach (IDTSInputColumn90 iCol in fileDestination.InputCollection[0].InputColumnCollection)
                {                    
                    IDTSExternalMetadataColumn90 eCol = input.ExternalMetadataColumnCollection[idx];
                    fileDestinationInstance.MapInputColumn(inputID, iCol.ID, eCol.ID);
                    idx++;
                }


                fileDestinationInstance.ReleaseConnections();
            }
        }
    }
}
