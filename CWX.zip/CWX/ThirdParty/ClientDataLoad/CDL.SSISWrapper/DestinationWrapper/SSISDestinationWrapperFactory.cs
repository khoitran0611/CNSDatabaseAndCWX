﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.Common;
using CDL.BusinessObject;

namespace CDL.SSISWrapper.DestinationWrapper
{
    internal class SSISDestinationWrapperFactory
    {
        internal static SSISDestinationBase CreateSSISDestination(DataSourceType outputType, string connectionString)
        {
            SSISDestinationBase ssisDestination = null;
            switch (outputType)
            {
                case DataSourceType.TextFile:
                    ssisDestination = new SSISFlatFileDestination() { ConnectionString=connectionString};
                    break;
                case DataSourceType.Database:
                    ssisDestination = new SSISDatabaseDestination() {
                        ConnectionString = connectionString                        
                    };
                    break;
            }

            return ssisDestination;
        }
    }
}
