﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.SSISWrapper.Mapping;
using System.Collections.ObjectModel;
using CWX.Core.Common;

namespace CDL.SSISWrapper.Common
{
    public class SSISUtilities
    {
        public static string CreateTempDestinationTable(Collection<SSISMapping> mappingFields, bool isUnicodeTemplate,string connectionString)
        {
            string tableName = CWXGuidGenerator.GenerateNewGuid().ToString();            
            string tableStructure = string.Format("CREATE TABLE [dbo].[{0}](", tableName);
            string endTable = ")";

            string columnDefinition;
            for(int i =0;i< mappingFields.Count;i++)
            {
                SSISMapping mapplingField = mappingFields[i];
                columnDefinition = BuildColumnFromMappingField(mapplingField, isUnicodeTemplate);
            }

            return tableStructure + endTable;
        }                

        private static string BuildColumnFromMappingField(SSISMapping mappingField, bool isUnicodeTemplate)
        {
            string columnName = mappingField.SourceCol;
            switch (mappingField.FieldType)
            { 
                case CDL.Common.DataType.Boolean:
                    columnName = columnName + " bit ";
                    break;
                case CDL.Common.DataType.DateTime:
                    break;
                case CDL.Common.DataType.Integer:
                    break;
                case CDL.Common.DataType.Money:
                    break;
                case CDL.Common.DataType.Real:
                    break;
                case CDL.Common.DataType.String:
                    break;
            }
            return string.Empty;
        }
    }
}
