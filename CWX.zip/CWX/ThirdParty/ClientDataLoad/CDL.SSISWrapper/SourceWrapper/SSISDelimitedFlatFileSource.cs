﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using Microsoft.SqlServer.Dts.Runtime;
using w = Microsoft.SqlServer.Dts.Runtime.Wrapper;

using CDL.BusinessObject;
using CDL.SSISWrapper.Mapping;
using CDL.SSISWrapper.Common;
using CDL.Common;

namespace CDL.SSISWrapper.SourceWrapper
{
    internal class SSISDelimitedFlatFileSource : SSISFlatFileSourceBase
	{
		#region Properties
        private string _fieldDelimiter = CDLConstants.Delimiter.Comma;
		public string FieldDelimiter
		{
			get { return _fieldDelimiter; }
            set { _fieldDelimiter = value.Replace("\\r", "\r").Replace("\\n", "\n").Replace("\\t", "\t");  }
		}
		#endregion

		#region Constructors
        public SSISDelimitedFlatFileSource(Collection<SourceMapDetails> mappings)
            : base(mappings)
        {            
        }
		#endregion

        public override IDTSComponentMetaData90 BuildSourceComponent(Package p, MainPipe pipe, out int outputID, out int errorOutputID)
        {            
            ConnectionManager cmFF = p.Connections.Add("FLATFILE");

            cmFF.ConnectionString = this.ConnectionString;
            cmFF.Name = "InputFile" + Guid.NewGuid().ToString();
            cmFF.Properties["Format"].SetValue(cmFF, "Delimited");
            cmFF.Properties["DataRowsToSkip"].SetValue(cmFF, 0);
            cmFF.Properties["ColumnNamesInFirstDataRow"].SetValue(cmFF, this.FirstLineContainsHeaders);
            cmFF.Properties["HeaderRowDelimiter"].SetValue(cmFF, this.RecordDelimiter);
            cmFF.Properties["HeaderRowsToSkip"].SetValue(cmFF, 0);
            cmFF.Properties["RowDelimiter"].SetValue(cmFF, this.RecordDelimiter);
            cmFF.Properties["TextQualifier"].SetValue(cmFF, string.IsNullOrEmpty(this.TextQualifier) ? null : this.TextQualifier);

            if (UseUnicode)
            {
                cmFF.Properties["Unicode"].SetValue(cmFF, true);
            }

            if (Locale > 0)
            {
                cmFF.Properties["LocaleID"].SetValue(cmFF, Locale);
            }

            IDTSComponentMetaData90 flatFileDataSource = pipe.ComponentMetaDataCollection.New();
            flatFileDataSource.ComponentClassID = "DTSAdapter.FlatFileSource";
            flatFileDataSource.Name = "FlatFileSource" + Guid.NewGuid().ToString();
            flatFileDataSource.Description = "Flat file source";
            flatFileDataSource.ValidateExternalMetadata = true;

            // Create an instance of the component
            CManagedComponentWrapper flatFileInst = flatFileDataSource.Instantiate();
            flatFileInst.ProvideComponentProperties();
            flatFileInst.SetComponentProperty("RetainNulls", true);

            // Associate the runtime ConnectionManager with the component
            flatFileDataSource.RuntimeConnectionCollection[0].ConnectionManagerID = cmFF.ID;
            flatFileDataSource.RuntimeConnectionCollection[0].ConnectionManager = DtsConvert.ToConnectionManager90(cmFF);
            
            w.IDTSConnectionManagerFlatFile90 ff = p.Connections[cmFF.Name].InnerObject as w.IDTSConnectionManagerFlatFile90;

            int columnIndex = 0;
            foreach (SSISMapping ssisMapping in Mappings)
            {
                ++columnIndex;

                if (ssisMapping.IsDerivedField)
                {
                    continue;
                }

                w.IDTSConnectionManagerFlatFileColumn90 col = ff.Columns.Add();
                if (columnIndex == Mappings.Count)
                    col.ColumnDelimiter = this.RecordDelimiter.ToString();
                else
                    col.ColumnDelimiter = this.FieldDelimiter;
                col.ColumnType = "Delimited";

                SSISColumnProperty columnProperty = SSISUtilities.BuildSSISColumnProperty(ssisMapping, UseUnicode,true);

                col.DataType = columnProperty.DataType;
                col.DataScale = columnProperty.Scale;
                col.DataPrecision = columnProperty.Precision;
                col.MaximumWidth = columnProperty.Length;                
                col.TextQualified = true;

                w.IDTSName90 name = col as w.IDTSName90;
                name.Name = ssisMapping.SourceCol;                
            }

            // Acquire the connection, reinitialize the metadata, 
            // map the columns, then release the connection.
            flatFileInst.AcquireConnections(null);
            flatFileInst.ReinitializeMetaData();

            IDTSOutput90 output = flatFileDataSource.OutputCollection[0];
            IDTSOutputColumnCollection90 outputColumns = output.OutputColumnCollection;
            IDTSExternalMetadataColumnCollection90 externalColumns = output.ExternalMetadataColumnCollection;
            outputColumns.RemoveAll();

            int ix = 0;
            foreach (IDTSExternalMetadataColumn90 externalColumn in externalColumns)
            {                
                // Insert the output column. Assuming to insert at the index 0. 
                IDTSOutputColumn90 outputColumn = flatFileInst.InsertOutputColumnAt(output.ID, ix++, externalColumn.Name, "");
                flatFileInst.SetOutputColumnDataTypeProperties(output.ID, outputColumn.ID, externalColumn.DataType, externalColumn.Length, externalColumn.Precision, externalColumn.Scale, externalColumn.CodePage);

                flatFileInst.MapOutputColumn(output.ID, outputColumn.ID, externalColumn.ID, true);
                
                outputColumn.ErrorOrTruncationOperation = "Conversion";
                outputColumn.ErrorRowDisposition = DTSRowDisposition.RD_RedirectRow;                
                outputColumn.TruncationRowDisposition = DTSRowDisposition.RD_RedirectRow;
            }

            flatFileInst.ReleaseConnections();

            outputID = flatFileDataSource.OutputCollection[0].ID;
            errorOutputID = flatFileDataSource.OutputCollection[1].ID;

            return flatFileDataSource; 
        }
    }
}
