﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using System.Collections.ObjectModel;

using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using Microsoft.SqlServer.Dts.Runtime;
using w = Microsoft.SqlServer.Dts.Runtime.Wrapper;
using CDL.Common;
using System.Data;
using System.Globalization;
using CWX.Core.Common.Exceptions;
using CDL.SSISWrapper.Common;
using CDL.SSISWrapper.Mapping;
using System.Collections;

namespace CDL.SSISWrapper.SourceWrapper
{
    internal class SSISExcelSource : SSISSourceBase
	{        
		#region Properties

        public bool FirstLineContainsHeaders
        {
            get;
            set;
        }

        public int Locale
        {
            get;
            set;
        }        

        public ExcelVersion Version
        {
            get;
            set;
        }

        public string SheetName
        {
            get;
            set;
        }        

		#endregion

		#region Constructors

		public SSISExcelSource(Collection<SourceMapDetails> mappings) : base(mappings)
		{
            if (!this.FirstLineContainsHeaders)
            {
                foreach (SSISMapping mapItem in base.Mappings)
                {
                    mapItem.SourceCol = mapItem.SourceCol.Replace("Col", "F");                    
                }
            }
		}

		#endregion

        public override IDTSComponentMetaData90 BuildSourceComponent(Package package, MainPipe pipe, out int outputID, out int errorOutputID)
        {
            string oledbConnString = CDLUtilities.ExcelBuildConnectionString(this.ConnectionString, Version,this.FirstLineContainsHeaders);

            if (!CDLUtilities.ExcelCheckSheetExist(SheetName,oledbConnString))
            {
                throw new CWXException(string.Format("The Microsoft Jet database engine could not find the object '{0}'", SheetName));
            }            

            ConnectionManager connectionManager = package.Connections.Add("OLEDB");
            connectionManager.ConnectionString = oledbConnString;
            connectionManager.Name = Guid.NewGuid().ToString();

            IDTSComponentMetaData90 source = pipe.ComponentMetaDataCollection.New();
            source.ComponentClassID = "DTSAdapter.OLEDBSource";
            source.Description = "Excel OLEDB Source";
            source.ValidateExternalMetadata = true;
            source.Name = "OLEDB Source " + SheetName + Guid.NewGuid().ToString();
            source.UsesDispositions = true;

            CManagedComponentWrapper instance = source.Instantiate();
            instance.ProvideComponentProperties();

            instance.SetComponentProperty("AccessMode", 0);
            instance.SetComponentProperty("CommandTimeout", 0);
            instance.SetComponentProperty("OpenRowset", SheetName);

            source.RuntimeConnectionCollection[0].ConnectionManagerID = connectionManager.ID;
            source.RuntimeConnectionCollection[0].ConnectionManager = DtsConvert.ToConnectionManager90(connectionManager);

            instance.AcquireConnections(null);
            instance.ReinitializeMetaData(); //currently let the component create output columns itseft, should change if doesn't work            

            instance.ReleaseConnections();

            source.OutputCollection[0].ExternalMetadataColumnCollection.IsUsed = false;
            source.OutputCollection[0].HasSideEffects = false;            

            if (this.Locale > 0)
            {
                source.LocaleID = this.Locale;
            }

            IDTSOutputColumnCollection90 outputColumnCollection = source.OutputCollection[0].OutputColumnCollection;

            Hashtable columnNames = new Hashtable();
            foreach (IDTSOutputColumn90 col in outputColumnCollection)
            {
                columnNames.Add(col.Name, col.ID);
            }

            StringBuilder errorBuilder = new StringBuilder();
            foreach (SSISMapping ssisMapping in Mappings)
            {                
                string columnName = ssisMapping.SourceCol;                

                if (!columnNames.ContainsKey(columnName))
                {
                    errorBuilder.AppendLine(string.Format("The Microsoft Jet database engine could not find the column '{0}'", ssisMapping.SourceCol));
                }
                else
                {
                    int columnID = (int)columnNames[columnName];
                    if (ssisMapping.IsDerivedField)
                    {
                        outputColumnCollection.RemoveObjectByID(columnID);
                        continue;
                    }
                    SSISColumnProperty columnProperty = SSISUtilities.BuildSSISColumnProperty(ssisMapping, true,true);

                    IDTSOutputColumn90 outputColumn90 = outputColumnCollection.GetObjectByID(columnID);                    
                        
                    outputColumn90.ErrorOrTruncationOperation = "Conversion";
                    outputColumn90.ErrorRowDisposition = DTSRowDisposition.RD_RedirectRow;
                    outputColumn90.TruncationRowDisposition = DTSRowDisposition.RD_RedirectRow;

                    outputColumn90.SetDataTypeProperties(columnProperty.DataType, columnProperty.Length,
                        columnProperty.Precision, columnProperty.Scale, 0);
                }
            }          

            outputID = source.OutputCollection[0].ID;
            errorOutputID = source.OutputCollection[1].ID;

            return source;
        }

        #region methods helper
                      
        #endregion
    }
}
