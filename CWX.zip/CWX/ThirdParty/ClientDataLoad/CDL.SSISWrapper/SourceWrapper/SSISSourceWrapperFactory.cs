﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.Common;
using System.Collections.ObjectModel;

namespace CDL.SSISWrapper.SourceWrapper
{
	internal class SSISSourceWrapperFactory
	{
		internal static SSISSourceBase CreateSSISSource(ImportSource importSource, Collection<SourceMapDetails> mappings,
            SourceMapTemplate sourceMapTemplate, string connectionString, string textQualifier)
		{
			SSISSourceBase ssisSource = null;
			if (importSource != null)
			{
				switch (importSource.Type)
				{
					case DataSourceType.TextFile:
						if (importSource.Fixed)
                            ssisSource = new SSISFixedWidthFlatFileSource(mappings)
                            {
                                ConnectionString=connectionString,
                                RecordDelimiter = importSource.RecordDelimiter,
                                FirstLineContainsHeaders = importSource.FirstLineContainsLabels,
                                Locale = sourceMapTemplate.LocaleID,
                                UseUnicode = sourceMapTemplate.Unicode,
                                TextQualifier = textQualifier
                            };
						else
                            ssisSource = new SSISDelimitedFlatFileSource(mappings) 
                            {
                                ConnectionString = connectionString,
                                FieldDelimiter = importSource.FieldDelimiter,
                                RecordDelimiter = importSource.RecordDelimiter,
                                FirstLineContainsHeaders = importSource.FirstLineContainsLabels,
                                Locale = sourceMapTemplate.LocaleID, 
                                UseUnicode = sourceMapTemplate.Unicode,
                                TextQualifier = textQualifier
                            };
						break;

					case DataSourceType.CSVFile:
                        ssisSource = new SSISDelimitedFlatFileSource(mappings)
                        {
                            ConnectionString = connectionString,
                            FirstLineContainsHeaders = importSource.FirstLineContainsLabels,
                            Locale = sourceMapTemplate.LocaleID,
                            UseUnicode = sourceMapTemplate.Unicode,
                            FieldDelimiter=CDLConstants.Delimiter.Comma,
                            TextQualifier = textQualifier
                        };
						break;

					case DataSourceType.ExcelFile:
                        ssisSource = new SSISExcelSource(mappings)
                        {
                            ConnectionString = connectionString,
                            FirstLineContainsHeaders = importSource.FirstLineContainsLabels,
                            Locale = sourceMapTemplate.LocaleID,                            
                            Version=ExcelVersion.MsExcel2003
                        };
						break;

					case DataSourceType.Database:
                        ssisSource = new SSISDataReaderSource(mappings)
                        {
                            ConnectionString = connectionString,
                        };
						break;					
				}
			}
            
			return ssisSource;
		}
	}
}
