﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using System.Collections.ObjectModel;

namespace CDL.SSISWrapper.SourceWrapper
{
    internal class SSISDataReaderSource : SSISSourceBase
	{
		#region Properties
		
		#endregion

		#region Constructors
		public SSISDataReaderSource(Collection<SourceMapDetails> mappings)
			: base(mappings)
		{			
		}
		#endregion

        public override Microsoft.SqlServer.Dts.Pipeline.Wrapper.IDTSComponentMetaData90 BuildSourceComponent(Microsoft.SqlServer.Dts.Runtime.Package p, Microsoft.SqlServer.Dts.Pipeline.Wrapper.MainPipe pipe, out int outputID, out int errorOutputID)
        {
            throw new NotImplementedException();
        }
    }
}
