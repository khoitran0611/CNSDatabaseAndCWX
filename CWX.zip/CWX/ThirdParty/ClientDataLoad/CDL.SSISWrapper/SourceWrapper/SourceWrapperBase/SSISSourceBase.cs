﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using CDL.SSISWrapper.Mapping;
using CDL.BusinessObject;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using Microsoft.SqlServer.Dts.Runtime;
using CDL.Common;

namespace CDL.SSISWrapper.SourceWrapper
{
    internal abstract class SSISSourceBase
	{
		#region Properties
		private Collection<SSISMapping> _mappings;

		/// <summary>
		/// Gets or set a collection of column mappings for this source
		/// </summary>
		public Collection<SSISMapping> Mappings
		{
			get { return _mappings; }
		}

        /// <summary>
        /// connection string to source.        
        /// </summary>
        public string ConnectionString
        {
            get;
            set;
        }

        public string Condition2FilterRecordsNull
        {
            get
            {                
                string condition1 = string.Empty;
                string condition2 = string.Empty;                
                foreach (SSISMapping item in Mappings)
                {
                    if (item.IsDerivedField)
                    {
                        continue;
                    }

                    string customSourceCol = "#" + item.SourceCol + "#";
                    if (string.IsNullOrEmpty(condition1))
                    {
                        condition1 = string.Format(" ISNULL({0}) ", customSourceCol);
                        if (item.FieldType == CDL.Common.DataType.String)
                            condition2 = string.Format(" LEN(TRIM({0})) == 0 ", customSourceCol);
                        else
                            condition2 = string.Format(" ISNULL({0}) ", customSourceCol);
                    }
                    else
                    {
                        condition1 += string.Format(" && ISNULL({0}) ", customSourceCol);

                        if(item.FieldType == CDL.Common.DataType.String)
                            condition2 += string.Format(" && LEN(TRIM({0})) == 0 ", customSourceCol);
                        else
                            condition2 += string.Format(" && LEN(TRIM({0})) == 0 ", customSourceCol);
                    }
                }
                return string.Format(" ({0}) || ({1}) ", condition1, condition2);
            }
        }

        private string _condition2Validation;
        public string Condition2Validation
        {
            get { return _condition2Validation; }
        }

		#endregion

		#region Constructors
		protected SSISSourceBase(Collection<SourceMapDetails> mappings)
		{
			_mappings = new Collection<SSISMapping>();
            _condition2Validation = string.Empty;
			foreach (SourceMapDetails mapping in mappings)
			{
				SSISMapping ssisMapping = new SSISMapping();
				ssisMapping.SourceCol = mapping.SourceCol;
				ssisMapping.DestField = mapping.DestField;
                ssisMapping.ColumnWidth = mapping.ColumnWidth;				
				ssisMapping.FieldType = mapping.FieldType;
                ssisMapping.FieldLength = mapping.Length;
				ssisMapping.Validation = mapping.ValidationString;
				ssisMapping.DerivedFrom = mapping.DerivedFrom;
                ssisMapping.IsDerivedField = mapping.IsDerived;
				ssisMapping.ColCollation = mapping.ColCollation;
                
                switch (ssisMapping.FieldType)
                {
                    case DataType.Boolean:
                        ssisMapping.DefaultValue = string.IsNullOrEmpty(mapping.DefaultValue) ? "FALSE" : mapping.DefaultValue;            
                        break;
                    case DataType.String:
                        ssisMapping.DefaultValue = string.IsNullOrEmpty(mapping.DefaultValue) ? string.Empty : mapping.DefaultValue;            
                        
                        break;
                    case DataType.Date:
                        ssisMapping.DefaultValue = string.IsNullOrEmpty(mapping.DefaultValue) ? "01/01/1900" : mapping.DefaultValue;            
                        
                        break;
                    case DataType.Currency:
                    case DataType.Integer:
                    case DataType.Real:
                        ssisMapping.DefaultValue = string.IsNullOrEmpty(mapping.DefaultValue) ? "0" : mapping.DefaultValue;            
                        break;
                }            
                    
				_mappings.Add(ssisMapping);

                if (!string.IsNullOrEmpty(mapping.ValidationString))
                {
                    _condition2Validation += String.Format("({0}) {1} ", mapping.ValidationString, CDLConstants.Operators.AND);
                }
			}
            if (!string.IsNullOrEmpty(_condition2Validation))
            {
                _condition2Validation += string.Format("(1 {0} 1)", CDLConstants.Operators.EQUAL_TO);
            }
		}
		#endregion		

        #region Abstract methods

        public abstract IDTSComponentMetaData90 BuildSourceComponent(Package p, MainPipe pipe, out int outputID, out int errorOutputID);

        #endregion
	}
}
