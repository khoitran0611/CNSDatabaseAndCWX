﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using System.Collections.ObjectModel;
using CDL.Common;

namespace CDL.SSISWrapper.SourceWrapper
{
	internal abstract class SSISFlatFileSourceBase : SSISSourceBase
	{
		#region Properties
        private string _recordDelimiter = CDLConstants.Delimiter.CRLF;
		public string RecordDelimiter
		{
			get { return _recordDelimiter; }
            set 
            {_recordDelimiter = value.Replace("\\r", "\r").Replace("\\n", "\n").Replace("\\t", "\t"); }
		}

		private bool _firstLineContainsHeaders = false;
		public bool FirstLineContainsHeaders
		{
			get { return _firstLineContainsHeaders; }
			set { _firstLineContainsHeaders = value; }
		}

        public int Locale
        {
            get;
            set;
        }

        public bool UseUnicode
        {
            get;
            set;
        }

        public string TextQualifier
        {
            get;
            set;
        }

		#endregion

		#region Constructors
        public SSISFlatFileSourceBase(Collection<SourceMapDetails> mappings)
            : base(mappings)
        {            
        }
		#endregion
	}
}
