﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.Common;

namespace CDL.BusinessObject
{
	[Serializable()]
	public class SourceMapDetailsValidation
	{
		#region Properties
		public int ID { get; set; }
		public int MapDetailID { get; set; }
		public string Operator { get; set; }
		public string MatchingValue { get; set; }
		public string Combining { get; set; }
		public DataType Type { get; set; }

		public Guid GUID { get; set; }
		#endregion

		#region Constructors
		public SourceMapDetailsValidation()
		{
		}

		public SourceMapDetailsValidation(Guid guid)
		{
			GUID = guid;
		}
		#endregion

		#region Override Methods
		public override string ToString()
		{
			if (Type == DataType.String)
				return String.Format("{0} \"{1}\"", Operator, MatchingValue);
			else if (Type == DataType.Date)
				return String.Format("{0} (DT_DBTIMESTAMP)\"{1}\"", Operator, MatchingValue);
			else
				return String.Format("{0} {1}", Operator, MatchingValue);
		}
		#endregion
	}
}