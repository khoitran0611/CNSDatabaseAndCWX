﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CDL.BusinessObject
{
	[Serializable]
	public class ImportDataInfo
	{
		/// <summary>
		/// Gets or set the file name that points to the source file stored in server after uploading from client.
		/// </summary>
		public string SourceFileName { get; set; }

		/// <summary>
		/// Gets or sets the selected client.
		/// </summary>
		public int ClientID { get; set; }

		/// <summary>
		/// Gets or sets the selected source definition.
		/// </summary>
		public int SourceID { get; set; }

		/// <summary>
		/// Gets or sets the selected source map template.
		/// </summary>
		public int TemplateID { get; set; }

		/// <summary>
		/// Gets or set the selected excel sheet name, only used for Excel file template.
		/// </summary>
		public string ExcelSheetName { get; set; }

		/// <summary>
		/// Gets or set the file name that points to the log file after importing.
		/// </summary>
		public string LogFileName { get; set; }

		/// <summary>
		/// Gets or sets the fully qualified name of the file on the client.
		/// </summary>		
		public string PostedFileName { get; set; }
	}
}
