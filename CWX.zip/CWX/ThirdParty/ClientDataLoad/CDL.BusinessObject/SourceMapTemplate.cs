﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.Common;

namespace CDL.BusinessObject
{
	public class SourceMapTemplate
	{
		#region Properties
		private int _templateID;
		public int TemplateID
		{
			get { return _templateID; }
			set { _templateID = value; }
		}

		private int _sourceID;
		public int SourceID
		{
			get { return _sourceID; }
			set { _sourceID = value; }
		}

		//private string _name;
		//public string Name
		//{
		//    get { return _name; }
		//    set { _name = value; }
		//}

		private string _description;
		public string Description
		{
			get { return _description; }
			set { _description = value; }
		}

		public DestinationDatabase DestDatabase { get; set; }

		private string _destTable;
		public string DestTable
		{
			get { return _destTable; }
			set { _destTable = value; }
		}

		private bool _active;
		public bool Active
		{
			get { return _active; }
			set { _active = value; }
		}

		private bool _unicode;
		public bool Unicode
		{
			get { return _unicode; }
			set { _unicode = value; }
		}

		public int LocaleID { get; set; }

		public int CodeBaseID { get; set; }

		public int CreatedBy { get; set; }

		public DateTime CreatedDate { get; set; }

		public int? UpdatedBy { get; set; }

		public DateTime? UpdatedDate { get; set; }

		public string DestDBAndTable
		{
			get { return String.Format("{0}.{1}", DestDatabase.ToString(), DestTable); }
		}

		//public int KeyColumnID { get; set; }

		public SourceMapDetails KeyColumn { get; set; }

		public string TemplateIDAndName
		{
			get { return String.Format("{0} - {1}", TemplateID, Description); }
		}

        public bool AllowDuplicateKey
        {
            get;
            set;
        }

		#endregion
	}
}
