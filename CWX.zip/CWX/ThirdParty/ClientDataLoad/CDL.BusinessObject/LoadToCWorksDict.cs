﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CDL.BusinessObject
{
	public class LoadToCWorksDict
	{
		#region Properties
		public int RowID { get; set; }
		public int DestTableID { get; set; }
		public string Load1Field { get; set; }
		public string CWorksField { get; set; }
		#endregion
	}
}
