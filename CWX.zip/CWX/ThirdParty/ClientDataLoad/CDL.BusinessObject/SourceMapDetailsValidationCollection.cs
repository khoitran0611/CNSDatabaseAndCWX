﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace CDL.BusinessObject
{
	[Serializable()]
	public class SourceMapDetailsValidationCollection
	{
		#region Properties
		private Collection<SourceMapDetailsValidation> _sourceMapDetailsValidationList;
		public Collection<SourceMapDetailsValidation> SourceMapDetailsValidationList
		{
			get { return _sourceMapDetailsValidationList; }
			set { _sourceMapDetailsValidationList = value; }
		}
		#endregion

		#region Constructors
		public SourceMapDetailsValidationCollection()
		{
			SourceMapDetailsValidationList = new Collection<SourceMapDetailsValidation>();
		}

		public SourceMapDetailsValidationCollection(Collection<SourceMapDetailsValidation> validations)
		{
			SourceMapDetailsValidationList = validations;
		}
		#endregion

		#region Public Methods
		public SourceMapDetailsValidation this[int index]
		{
			get { return SourceMapDetailsValidationList[index]; }
			set { SourceMapDetailsValidationList[index] = value; }
		}

		public bool IsEmpty
		{
			get
			{
				return SourceMapDetailsValidationList == null || SourceMapDetailsValidationList.Count <= 0;
			}
		}

		public int Count
		{
			get { return SourceMapDetailsValidationList.Count; }
		}

		public void Add(SourceMapDetailsValidation item)
		{
			SourceMapDetailsValidationList.Add(item);
		}

		public SourceMapDetailsValidation Remove(SourceMapDetailsValidation item)
		{
			SourceMapDetailsValidation deletedValidation = null;
			for (int i = 0; i < SourceMapDetailsValidationList.Count; i++)
			{
				if (SourceMapDetailsValidationList[i].GUID.Equals(item.GUID))
				{
					deletedValidation = SourceMapDetailsValidationList[i];
					SourceMapDetailsValidationList.RemoveAt(i);
					break;
				}
			}
			return deletedValidation;
		}

		public void Update(SourceMapDetailsValidation item)
		{
			for (int i = 0; i < SourceMapDetailsValidationList.Count; i++)
			{
				if (SourceMapDetailsValidationList[i].GUID.Equals(item.GUID))
				{
					SourceMapDetailsValidationList[i] = item;
					break;
				}
			}
		}

		public SourceMapDetailsValidation Find(Guid guid)
		{
			foreach (SourceMapDetailsValidation validation in SourceMapDetailsValidationList)
			{
				if (validation.GUID == guid)
					return validation;
			}

			return null;
		}
		#endregion
	}
}
