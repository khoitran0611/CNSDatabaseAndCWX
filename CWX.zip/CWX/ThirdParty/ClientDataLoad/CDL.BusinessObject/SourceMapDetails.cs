﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.Common;

namespace CDL.BusinessObject
{
	public class SourceMapDetails
	{
		#region Properties		
        public int ID
        {
            get;
            set;
        }

        public int TemplateID
        {
            get;
            set;
        }

        public string SourceCol
        {
            get;
            set;
        }

        public string DestField
        {
            get;
            set;
        }

        public int? StartPosition
        {
            get;
            set;
        }

        public int? EndPosition
        {
            get;
            set;
        }

        public DataType FieldType
        {
            get;
            set;
        }

		public int? Length { get; set; }

		public string ValidationString
		{
			get
			{                
				StringBuilder validationString = new StringBuilder();
				//validationString.Append("(");

                string customSourceCol = "#" + SourceCol + "#";
				if (!AllowsNull)
				{
					validationString.Append(String.Format("!ISNULL({0})", customSourceCol));
                    validationString.Append(String.Format(" {0} LEN(TRIM({1})) > 0 ", CDLConstants.Operators.AND, customSourceCol));

					if (ValidationCollection.Count > 0)
						validationString.Append(String.Format(" {0} (", CDLConstants.Operators.AND));
				}				

				SourceMapDetailsValidation validation = null;				
				for (int i = 0; i < ValidationCollection.Count - 1; i++)
				{
					validation = ValidationCollection[i];
                    validationString.Append(String.Format("{0} {1} {2} ", customSourceCol, validation.ToString(), validation.Combining));
				}

				if (ValidationCollection.Count > 0)
				{
					validation = ValidationCollection[ValidationCollection.Count - 1];
                    validationString.Append(String.Format("{0} {1}", customSourceCol, validation.ToString()));
					if (!AllowsNull)
						validationString.Append(")");
				}

				//validationString.Append(")");
				return validationString.ToString();
			}
		}

		public SourceMapDetailsValidationCollection ValidationCollection { get; set; }			

		public bool IsDerived { get; set; }

		private string _derivedFrom;
		public string DerivedFrom
		{
			get { return _derivedFrom; }
			set { _derivedFrom = value; }
		}

		private string _dateFormat;
		public string DateFormat
		{
			get { return _dateFormat; }
			set { _dateFormat = value; }
		}

		private string _colCollation;
		public string ColCollation
		{
			get { return _colCollation; }
			set { _colCollation = value; }
		}

		public bool AllowsNull { get; set; }

		public bool IsSystemDefined { get; set; }

		public int CreatedBy { get; set; }

		public DateTime CreatedDate { get; set; }

		public int? UpdatedBy { get; set; }

		public DateTime? UpdatedDate { get; set; }

		public int ColumnWidth { get; set; }

        public string DefaultValue { get; set; }

        public string HostFieldName { get; set; }

        public string HostFieldDescription { get; set; }
                
		#endregion
	}
}
