﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.BusinessInterface;
using CWX.Core.Common;
using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;
using CDL.Business.Repository;
using CWX.Core.Common.Data;
using System.Collections.ObjectModel;

namespace CDL.Business
{
	public class SSISFunctionsService : BusinessService<SSISFunctions, ISSISFunctionsRepository>
    {
        #region Constructors
        public SSISFunctionsService()
        {
            Repository = PolicyInjection.Create<SSISFunctionsRepository>();
        }

		internal SSISFunctionsService(ISSISFunctionsRepository repository)
        {
            Repository = repository;
        }

        #endregion

        #region Properties
        private ISSISFunctionsRepository Repository
        {
            get { return (ISSISFunctionsRepository)_repository; }
            set { _repository = (IRepository<SSISFunctions>)value; }
        }
        #endregion

		#region Public Methods
		public Collection<SSISFunctions> GetListByFunctionType(int functionTypeCode)
		{
			return Repository.GetListByFunctionType(functionTypeCode);
		}
		#endregion
	}
}
