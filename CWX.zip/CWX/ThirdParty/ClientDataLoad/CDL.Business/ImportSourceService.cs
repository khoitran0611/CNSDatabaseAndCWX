﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.BusinessInterface;
using CWX.Core.Common;
using CDL.Business.Repository;
using CWX.Core.Common.Data;
using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;
using System.Data;
using System.Collections.ObjectModel;

namespace CDL.Business
{
	public class ImportSourceService : BusinessService<ImportSource, IImportSourceRepository>
    {
        #region Constructors
        public ImportSourceService()
        {
            Repository = PolicyInjection.Create<ImportSourceRepository>();
        }

		internal ImportSourceService(IImportSourceRepository repository)
        {
            Repository = repository;
        }

        #endregion

        #region Properties
        private IImportSourceRepository Repository
        {
            get { return (IImportSourceRepository)_repository; }
            set { _repository = (IRepository<ImportSource>)value; }
        }
        #endregion

		#region Public Methods
		public ImportSource GetImportSourceByName(string name, int clientID)
		{
			return Repository.GetImportSourceByName(name, clientID);
		}

		public DataSet FillDataSet(int clientID)
		{
			return Repository.FillDataSet(clientID);
		}

		public Collection<ImportSource> FillListByClientID(int clientID)
		{
			return Repository.FillListByClientID(clientID);
		}

		/// <summary>
		/// Removes/Marks as deleted all ImportSources in database.
		/// </summary>
		/// <param name="isSoftDelete">if true this function will mark all ImportSources as deleted, otherwise removes all permanently.</param>
		/// <returns>Returns true if remove successfully, otherwise returns false.</returns>
		public bool RemoveAll(int clientID, bool isSoftDelete)
		{
			return Repository.RemoveAll(clientID, isSoftDelete);
		}

		/// <summary>
		/// Checks if the ImportSource has any templates created.
		/// </summary>
		/// <param name="sourceID"></param>
		/// <returns>Return true if the ImportSource do not have any templates created; otherwise return false.</returns>
		public bool CheckNoTemplateCreated(int sourceID)
		{
			return Repository.CheckNoTemplateCreated(sourceID);
		}
		#endregion
	}
}
