﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.BusinessInterface;
using CWX.Core.Common;
using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;
using CDL.Business.Repository;
using CWX.Core.Common.Data;
using System.Collections.ObjectModel;
using CDL.Common;

namespace CDL.Business
{
	public class SourceMapDetailsService : BusinessService<SourceMapDetails, ISourceMapDetailsRepository>
    {
        #region Constructors
        public SourceMapDetailsService()
        {
            Repository = PolicyInjection.Create<SourceMapDetailsRepository>();
        }

		internal SourceMapDetailsService(ISourceMapDetailsRepository repository)
        {
            Repository = repository;
        }

        #endregion

        #region Properties
        private ISourceMapDetailsRepository Repository
        {
            get { return (ISourceMapDetailsRepository)_repository; }
            set { _repository = (IRepository<SourceMapDetails>)value; }
        }
        #endregion

		#region Public Methods
		public Collection<SourceMapDetails> GetListByTemplateID(int templateID)
		{
			return Repository.GetListByTemplateID(templateID);
		}

		public Collection<SourceMapDetails> GetListByTemplateID(int templateID, bool excludeDerivedColumn)
		{
			return Repository.GetListByTemplateID(templateID, excludeDerivedColumn);
		}

        public Collection<SourceMapDetails> GetListByTemplateID(int templateID, bool excludeDerivedColumn, string orderBy)
        {
            return Repository.GetListByTemplateID(templateID, excludeDerivedColumn, orderBy);
        }

		public Collection<SourceMapDetails> GetPagingListByTemplateID(int templateID, int pageSize, int pageIndex, out int rowCount)
		{
			return Repository.GetPagingListByTemplateID(templateID, pageSize, pageIndex, out rowCount);
		}

		public int GetNumberOfSourceMapDetails(int templateID)
		{
			return Repository.GetNumberOfSourceMapDetails(templateID);
		}

		public SourceMapDetails GetBySourceColumn(int templateID, string sourceCol)
		{
			return Repository.GetBySourceColumn(templateID, sourceCol);
		}

		public SourceMapDetails GetByDestField(int templateID, string destField)
		{
			return Repository.GetByDestField(templateID, destField);
		}

		public SourceMapDetails GetBySequenceOrder(int templateID, int sequenceOrder)
		{
			return Repository.GetBySequenceOrder(templateID, sequenceOrder);
		}

		/// <summary>
		/// Removes/Marks as deleted all SourceMapDetails in database.
		/// </summary>
		/// <param name="isSoftDelete">if true this function will mark all SourceMapDetails as deleted, otherwise removes all permanently.</param>
		/// <returns>Returns true if remove successfully, otherwise returns false.</returns>
		public bool RemoveAll(int templateID, bool isSoftDelete)
		{
			return Repository.RemoveAll(templateID, isSoftDelete);
		}

		public bool GenerateMappingColumns(int templateID, int numberOfColumns, int createdBy, DateTime creteadDate)
		{
			return Repository.GenerateMappingColumns(templateID, numberOfColumns, createdBy, creteadDate);
		}

		public int GetMinimumStartPositionByID(int templateID, int mapDetailID)
		{
			return Repository.GetMinimumStartPositionByID(templateID, mapDetailID);
		}

		public bool UpdateMappingKeyColumn(DestinationDatabase destDatabase, string destTable, int templateID, int sourceKeyColumnID)
		{
			return Repository.UpdateMappingKeyColumn(destDatabase, destTable, templateID, sourceKeyColumnID);
		}

		public SourceMapDetails GetKeyColumn(int templateID)
		{
			return Repository.GetKeyColumn(templateID);
		}
		#endregion
	}
}
