﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.BusinessInterface;
using CWX.Core.Common;
using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;
using CDL.Business.Repository;
using CWX.Core.Common.Data;
using System.Data;
using System.Collections.ObjectModel;
using CDL.Common;

namespace CDL.Business
{
	public class SourceMapTemplateService : BusinessService<SourceMapTemplate, ISourceMapTemplateRepository>
    {
        #region Constructors
        public SourceMapTemplateService()
        {
            Repository = PolicyInjection.Create<SourceMapTemplateRepository>();
        }

		internal SourceMapTemplateService(ISourceMapTemplateRepository repository)
        {
            Repository = repository;
        }

        #endregion

        #region Properties
        private ISourceMapTemplateRepository Repository
        {
            get { return (ISourceMapTemplateRepository)_repository; }
            set { _repository = (IRepository<SourceMapTemplate>)value; }
        }
        #endregion

		#region Public Methods
		public DataSet FillDataSet(int clientID, int sourceID, bool onlyActive)
		{
			return Repository.FillDataSet(clientID, sourceID, onlyActive);
		}

		public Collection<SourceMapTemplate> GetListBySourceID(int sourceID)
		{
			return Repository.GetListBySourceID(sourceID);
		}

		public Collection<SourceMapTemplate> GetListBySourceID(int sourceID, bool onlyActive)
		{
			return Repository.GetListBySourceID(sourceID, onlyActive);
		}

		public void UpdateActiveStatus(int templateID)
		{
			Repository.UpdateActiveStatus(templateID);
		}

		/// <summary>
		/// Removes/Marks as deleted all SourceMapTemplates in database.
		/// </summary>
		/// <param name="isSoftDelete">if true this function will mark all SourceMapTemplates as deleted, otherwise removes all permanently.</param>
		/// <returns>Returns true if remove successfully, otherwise returns false.</returns>
		public bool RemoveAll(int sourceID, bool isActive, bool isSoftDelete)
		{
			return Repository.RemoveAll(sourceID, isActive, isSoftDelete);
		}

		/// <summary>
		/// Copies a SourceMapTemplate and its mapping details
		/// </summary>
		/// <param name="copyTemplateID">The template ID to copy</param>
		/// <param name="createdBy"></param>
		/// <param name="createdDate"></param>
		/// <returns>true if copying successfull, otherwise false.</returns>
		public bool CopySourceMapTemplate(int copyTemplateID, int createdBy, DateTime createdDate, out int newTemplateID)
		{
			return Repository.CopySourceMapTemplate(copyTemplateID, createdBy, createdDate, out newTemplateID);
		}

		/// <summary>
		/// Checks if a Source Map Template has at least one mapping to destination field.
		/// </summary>
		/// <param name="templateID"></param>
		/// <returns></returns>
		public bool ExistAtLeastOneMapping(int templateID)
		{
			return Repository.ExistAtLeastOneMapping(templateID);
		}

		/// <summary>
		/// Checks if a template has assigned key column
		/// </summary>
		/// <param name="templateID"></param>
		/// <returns></returns>
		public bool HasMappingKeyColumn(int templateID)
		{
			return Repository.HasMappingKeyColumn(templateID);
		}

		public void UpdateKeyColumn(int templateID, int keyColumnID)
		{
			Repository.UpdateKeyColumn(templateID, keyColumnID);
		}
		#endregion
	}
}
