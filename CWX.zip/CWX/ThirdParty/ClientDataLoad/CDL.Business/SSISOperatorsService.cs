﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.BusinessInterface;
using CWX.Core.Common;
using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;
using CDL.Business.Repository;
using CWX.Core.Common.Data;

namespace CDL.Business
{
	public class SSISOperatorsService : BusinessService<SSISOperators, ISSISOperatorsRepository>
    {
        #region Constructors
        public SSISOperatorsService()
        {
            Repository = PolicyInjection.Create<SSISOperatorsRepository>();
        }

		internal SSISOperatorsService(ISSISOperatorsRepository repository)
        {
            Repository = repository;
        }

        #endregion

        #region Properties
        private ISSISOperatorsRepository Repository
        {
            get { return (ISSISOperatorsRepository)_repository; }
            set { _repository = (IRepository<SSISOperators>)value; }
        }
        #endregion
	}
}
