﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.BusinessInterface;
using CWX.Core.Common;
using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;
using CDL.Business.Repository;
using CWX.Core.Common.Data;
using System.Collections.ObjectModel;

namespace CDL.Business
{
	public class SourceMapDetailsValidationService : BusinessService<SourceMapDetailsValidation, ISourceMapDetailsValidationRepository>
    {
        #region Constructors
        public SourceMapDetailsValidationService()
        {
			Repository = PolicyInjection.Create<SourceMapDetailsValidationRepository>();
        }

		internal SourceMapDetailsValidationService(ISourceMapDetailsValidationRepository repository)
        {
            Repository = repository;
        }

        #endregion

        #region Properties
		private ISourceMapDetailsValidationRepository Repository
        {
			get { return (ISourceMapDetailsValidationRepository)_repository; }
			set { _repository = (IRepository<SourceMapDetailsValidation>)value; }
        }
        #endregion

		#region Public Methods
		public Collection<SourceMapDetailsValidation> GetListByMapDetailID(int mapDetailID)
		{
			return Repository.GetListByMapDetailID(mapDetailID);
		}
		#endregion
	}
}
