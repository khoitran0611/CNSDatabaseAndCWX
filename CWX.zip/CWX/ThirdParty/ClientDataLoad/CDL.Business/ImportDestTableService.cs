﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.BusinessInterface;
using CWX.Core.Common;
using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;
using CDL.Business.Repository;
using CWX.Core.Common.Data;
using System.Collections.ObjectModel;
using CDL.Common;

namespace CDL.Business
{
	public class ImportDestTableService : BusinessService<ImportDestTable, IImportDestTableRepository>
    {
        #region Constructors
        public ImportDestTableService()
        {
            Repository = PolicyInjection.Create<ImportDestTableRepository>();
        }

		internal ImportDestTableService(IImportDestTableRepository repository)
        {
            Repository = repository;
        }

        #endregion

        #region Properties
        private IImportDestTableRepository Repository
        {
            get { return (IImportDestTableRepository)_repository; }
            set { _repository = (IRepository<ImportDestTable>)value; }
        }
        #endregion

		#region Public Methods
		public Collection<ImportDestTable> GetListByDestDatabase(DestinationDatabase destDatabase)
		{
			return Repository.GetListByDestDatabase(destDatabase);
		}

        public int GetImportDestinationID(int databaseID, string tableName)
        {
            return Repository.GetImportDestinationID(databaseID, tableName);
        }
		#endregion
	}
}
