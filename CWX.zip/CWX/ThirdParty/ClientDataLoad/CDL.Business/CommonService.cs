﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;

using CDL.BusinessInterface;
using CDL.Business.Repository;
using CWX.Core.Common.Data;
using CWX.Core.Common;

namespace CDL.Business
{
	public class CommonService : BusinessService<object, ICommonRepository>
    {
        #region Constructors
        public CommonService()
        {
            Repository = PolicyInjection.Create<CommonRepository>();
        }

		internal CommonService(ICommonRepository repository)
        {
            Repository = repository;
        }

        #endregion

        #region Properties
        private ICommonRepository Repository
        {
            get { return (ICommonRepository)_repository; }
            set { _repository = (IRepository<object>)value; }
        }
        #endregion

		#region Public Methods
		public DataSet GetAllColumnsDefinitions(string databaseName, string tableName)
		{
			return Repository.GetAllColumnsDefinitions(databaseName, tableName);
		}

        public string GetFieldNameFromDestinationDB(int destinationDBID, string destinationTableID, string sourceDBFieldName)
        {
            return Repository.GetFieldNameFromDestinationDB(destinationDBID,destinationTableID, sourceDBFieldName);

        }
		#endregion
	}
}
