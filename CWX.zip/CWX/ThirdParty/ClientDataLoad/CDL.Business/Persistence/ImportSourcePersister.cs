﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CWX.Core.Common.Data;
using CDL.BusinessObject;
using System.Data;

namespace CDL.Business.Persistence
{
	internal class ImportSourcePersister : PersisterBase<ImportSource>
	{
		#region Constructors
        public ImportSourcePersister()
            : base()
        {
        }

		public ImportSourcePersister(string connectionStringName)
            : base(connectionStringName)
        {
        }
        #endregion

		#region Public Methods
		public DataSet FillDataSet(int clientID)
		{
			string[] parameterNames = new string[] { "ClientID" };
			object[] parameterValues = new object[] { clientID };
			return base.ExecuteDataSet("CWX_CDL_ImportSource_GetList", parameterNames, parameterValues);
		}

		/// <summary>
		/// Removes/Marks as deleted all ImportSources in database.
		/// </summary>
		/// <param name="isSoftDelete">if true this function will mark all ImportSources as deleted, otherwise removes all permanently.</param>
		/// <returns>Returns true if remove successfully, otherwise returns false.</returns>
		public bool RemoveAll(int clientID, bool isSoftDelete)
		{
			string deleteStatement = string.Empty;
			if (isSoftDelete)
			{
				deleteStatement = "UPDATE CWX_CDL_ImportSource SET Status = 'R' WHERE Status <> 'R'";
			}
			else
			{
				deleteStatement = "DELETE CWX_CDL_ImportSource WHERE Status <> 'R'";
			}

			if (clientID > 0)
				deleteStatement += String.Format(" AND ClientID = {0}", clientID);

			base.ExecuteNonQuery(deleteStatement, CommandType.Text);
			return true;
		}

		/// <summary>
		/// Checks if the ImportSource has any templates created.
		/// </summary>
		/// <param name="sourceID"></param>
		/// <returns>Return true if the ImportSource do not have any templates created; otherwise return false.</returns>
		public bool CheckNoTemplateCreated(int sourceID)
		{
			string query = String.Format("IF EXISTS (SELECT 1 FROM CWX_CDL_SourceMapTemplate WHERE SourceID = {0} AND Status <> 'R') SELECT 1 ELSE SELECT 0", sourceID);
			int result = (int)base.ExecuteScalar(query, CommandType.Text);
			return result == 0;
		}
		#endregion
	}
}
