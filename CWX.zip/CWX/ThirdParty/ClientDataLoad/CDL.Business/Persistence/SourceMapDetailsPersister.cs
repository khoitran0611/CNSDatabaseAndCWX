﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CWX.Core.Common.Data;
using System.Data;
using System.Collections.ObjectModel;
using CDL.Common;

namespace CDL.Business.Persistence
{
	internal class SourceMapDetailsPersister : PersisterBase<SourceMapDetails>
	{
		#region Constructors
        public SourceMapDetailsPersister()
            : base()
        {
        }

		public SourceMapDetailsPersister(string connectionStringName)
            : base(connectionStringName)
        {
        }
        #endregion

		#region Public Methods
		public int GetNumberOfSourceMapDetails(int templateID)
		{
			string[] parameterNames = new string[] { "TemplateID" };
			object[] parameterValues = new object[] { templateID };
			return Convert.ToInt32(base.ExecuteScalar(parameterValues, "CWX_CDL_GetNumberOfSourceMapDetails"));			
		}

		public SourceMapDetails GetBySequenceOrder(int templateID, int sequenceOrder)
		{
			string[] parameterNames = new string[] { "TemplateID", "SequenceOrder" };
			object[] parameterValues = new object[] { templateID, sequenceOrder };
			Collection<SourceMapDetails> sourceMapDetailsList = base.FillListByStoreProcedure("CWX_CDL_SourceMapDetails_GetBySequenceOrder", parameterNames, parameterValues);
			if (sourceMapDetailsList.Count > 0)
				return sourceMapDetailsList[0];
			else
				return null;

		}

		/// <summary>
		/// Removes/Marks as deleted all SourceMapDetails in database.
		/// </summary>
		/// <param name="isSoftDelete">if true this function will mark all SourceMapDetails as deleted, otherwise removes all permanently.</param>
		/// <returns>Returns true if remove successfully, otherwise returns false.</returns>
		public bool RemoveAll(int templateID, bool isSoftDelete)
		{
			string deleteStatement = string.Empty;
			if (isSoftDelete)
			{
				deleteStatement = "UPDATE CWX_CDL_SourceMapDetails SET Status = 'R' WHERE Status <> 'R'";
			}
			else
			{
				deleteStatement = "DELETE CWX_CDL_SourceMapDetails WHERE Status <> 'R'";
			}

			if (templateID > 0)
				deleteStatement += String.Format(" AND TemplateID = {0}", templateID);

			base.ExecuteNonQuery(deleteStatement, CommandType.Text);
			return true;
		}

		public bool GenerateMappingColumns(int templateID, int numberOfColumns, int createdBy, DateTime creteadDate)
		{
			string[] parameterNames = new string[] { "TemplateID", "NumberOfColumns", "CreatedBy", "CreatedDate" };
			object[] parameterValues = new object[] { templateID, numberOfColumns, createdBy, creteadDate };
			int result;
			base.ExecuteNonQuery("CWX_CDL_SourceMapDetails_GenerateMappingColumns", parameterNames, parameterValues, out result);
			return result > 0;
		}

		public int GetMinimumStartPositionByID(int templateID, int mapDetailID)
		{
			object[] parameterValues = new object[] { templateID, mapDetailID };
			return (int)base.ExecuteScalar(parameterValues, "CWX_CDL_SourceMapDetails_GetMinimumStartPositionByID");
		}

		public bool UpdateMappingKeyColumn(DestinationDatabase destDatabase, string destTable, int templateID, int sourceKeyColumnID)
		{
			string[] parameterNames = new string[] { "DestDatabase", "DestTable", "TemplateID", "SourceKeyColumnID" };
			object[] parameterValues = new object[] { destDatabase, destTable, templateID, sourceKeyColumnID };
			return base.ExecuteNonQuery("CWX_CDL_SourceMapDetails_UpdateMappingKeyColumn", parameterNames, parameterValues) > 0;
		}

		public SourceMapDetails GetKeyColumn(int templateID)
		{
			string[] parameterNames = new string[] { "TemplateID" };
			object[] parameterValues = new object[] { templateID };
			Collection<SourceMapDetails> result = base.FillListByStoreProcedure("CWX_CDL_SourceMapDetails_GetKeyColumn", parameterNames, parameterValues);
			if (result != null && result.Count > 0)
				return result[0];
			else
				return null;
		}
		#endregion
	}
}
