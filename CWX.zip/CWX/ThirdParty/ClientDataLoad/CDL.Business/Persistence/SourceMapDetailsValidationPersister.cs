﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

using CDL.BusinessObject;
using CWX.Core.Common.Data;
using CWX.Core.Common;

namespace CDL.Business.Persistence
{
	internal class SourceMapDetailsValidationPersister : PersisterBase<SourceMapDetailsValidation>
	{
		#region Constructors
        public SourceMapDetailsValidationPersister()
            : base()
        {
        }

		public SourceMapDetailsValidationPersister(string connectionStringName)
            : base(connectionStringName)
        {
        }
        #endregion

		#region Public Methods
		public Collection<SourceMapDetailsValidation> GetListByMapDetailID(int mapDetailID)
		{
			string whereClause = string.Format("MapDetailID = {0}", mapDetailID);
			Collection <SourceMapDetailsValidation> validationList = base.FillList("ID", whereClause);
			foreach (SourceMapDetailsValidation validation in validationList)
			{
				validation.GUID = CWXGuidGenerator.GenerateNewGuid();
			}
			return validationList;
		}
		#endregion
	}
}
