﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CWX.Core.Common.Data;
using CDL.BusinessObject;
using System.Collections.ObjectModel;

namespace CDL.Business.Persistence
{
	internal class SSISFunctionsPersister : PersisterBase<SSISFunctions>
	{
		#region Constructors
        public SSISFunctionsPersister()
            : base()
        {
        }

		public SSISFunctionsPersister(string connectionStringName)
            : base(connectionStringName)
        {
        }
        #endregion

		#region Public Methods
		public Collection<SSISFunctions> GetListByFunctionType(int functionTypeCode)
		{
			if (functionTypeCode > 0)
			{
				string whereClause = String.Format("Type = {0} AND Displayed = 1", functionTypeCode);
				return base.FillList("ID", whereClause);
			}
			else
				return null;
		}
		#endregion
	}
}
