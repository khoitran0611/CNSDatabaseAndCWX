﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CWX.Core.Common.Data;
using CDL.BusinessObject;
using System.Data;
using CDL.Common;

namespace CDL.Business.Persistence
{
	internal class SourceMapTemplatePersister : PersisterBase<SourceMapTemplate>
	{
		#region Constructors
        public SourceMapTemplatePersister()
            : base()
        {
        }

		public SourceMapTemplatePersister(string connectionStringName)
            : base(connectionStringName)
        {
        }
        #endregion

		#region Public Methods
		public DataSet FillDataSet(int clientID, int sourceID, bool onlyActive)
		{
			string[] parameterNames = new string[] { "ClientID", "SourceID", "OnlyActive" };
			object[] parameterValues = new object[] { clientID, sourceID, onlyActive };
			return base.ExecuteDataSet("CWX_CDL_SourceMapTemplate_GetList", parameterNames, parameterValues);
		}

		public void UpdateActiveStatus(int templateID)
		{
			string[] parameterNames = new string[] { "TemplateID" };
			object[] parameterValues = new object[] { templateID };
			base.ExecuteNonQuery("CWX_CDL_SourceMapTemplate_UpdateActiveStatus", parameterNames, parameterValues);
		}

		/// <summary>
		/// Removes/Marks as deleted all SourceMapTemplates in database.
		/// </summary>
		/// <param name="isSoftDelete">if true this function will mark all SourceMapTemplates as deleted, otherwise removes all permanently.</param>
		/// <returns>Returns true if remove successfully, otherwise returns false.</returns>
		public bool RemoveAll(int sourceID, bool isActive, bool isSoftDelete)
		{
			string deleteStatement = string.Empty;
			if (isSoftDelete)
			{
				deleteStatement = "UPDATE CWX_CDL_SourceMapTemplate SET Status = 'R' WHERE Status <> 'R'";
			}
			else
			{
				deleteStatement = "DELETE CWX_CDL_SourceMapTemplate WHERE Status <> 'R'";
			}

			if (sourceID > 0)
				deleteStatement += String.Format(" AND SourceID = {0}", sourceID);

			if (isActive)
				deleteStatement += " AND Active = 1";

			base.ExecuteNonQuery(deleteStatement, CommandType.Text);
			return true;
		}

		/// <summary>
		/// Copies a SourceMapTemplate and its mapping details
		/// </summary>
		/// <param name="copyTemplateID">The template ID to copy</param>
		/// <param name="createdBy"></param>
		/// <param name="createdDate"></param>
		/// <returns>true if copying successfull, otherwise false.</returns>
		public bool CopySourceMapTemplate(int copyTemplateID, int createdBy, DateTime createdDate, out int newTemplateID)
		{
			string[] parameterNames = new string[] { "CopyTemplateID", "CreatedBy", "CreatedDate" };
			object[] parameterValues = new object[] { copyTemplateID, createdBy, createdDate };
			base.ExecuteNonQuery("CWX_CDL_SourceMapTemplate_Copy", parameterNames, parameterValues, out newTemplateID);
			return newTemplateID > 0;
		}

		/// <summary>
		/// Checks if a Source Map Template has at least one column that maps to destination field.
		/// </summary>
		/// <param name="templateID"></param>
		/// <returns></returns>
		public bool ExistAtLeastOneMapping(int templateID)
		{
			object[] parameterValues = new object[] { templateID };
			int result = (int)base.ExecuteScalar(parameterValues, "CWX_CDL_SourceMapTemplate_ExistAtLeastOneMapping");
			return result > 0;
		}		

		/// <summary>
		/// Checks if a template has assigned key column
		/// </summary>
		/// <param name="templateID"></param>
		/// <returns></returns>
		public bool HasMappingKeyColumn(int templateID)
		{
			return true;			
		}

		public void UpdateKeyColumn(int templateID, int keyColumnID)
		{
			string query = String.Format("UPDATE CWX_CDL_SourceMapTemplate SET KeyColumnID = {0} WHERE TemplateID = {1}", keyColumnID, templateID);
			base.ExecuteNonQuery(query, CommandType.Text);
		}

        public bool CheckAllowDuplicateKey(int templateID)
        {
            object[] parameterValues = new object[] { templateID };
            return (bool)base.ExecuteScalar(parameterValues, "CWX_CDL_SourceMapTemplate_CheckAllowDuplicateKey");
        }

		#endregion
	}
}
