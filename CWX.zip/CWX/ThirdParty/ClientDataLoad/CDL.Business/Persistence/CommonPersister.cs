﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using CWX.Core.Common.Data;

namespace CDL.Business.Persistence
{
	public class CommonPersister : PersisterBase<object>
	{
		#region Constructors
        public CommonPersister()
            : base()
        {
        }

		public CommonPersister(string connectionStringName)
            : base(connectionStringName)
        {
        }
        #endregion

		#region Public Methods
		public DataSet GetAllColumnsDefinitions(string databaseName, string tableName)
		{
			string[] parameterNames = new string[] { "DatabaseName", "TableName" };
			object[] parameterValues = new object[] { databaseName, tableName };
			return base.ExecuteDataSet("CWX_CDL_GetAllColumnsDefinitions", parameterNames, parameterValues);
		}

        internal string GetFieldNameFromDestinationDB(int destinationDBID, string destinationTableID, string sourceDBFieldName)
        {
            string[] parameterNames = new string[] { "@DatabaseID", "@TableName", "@Load1Field" };
            object[] parameterValues = new object[] { destinationDBID,destinationTableID, sourceDBFieldName };
            string destinationDBFieldName = string.Empty;
            using (IDataReader reader = base.ExecuteReader("CWX_CDL_LoadToCWorks_Dict_CWorksField", parameterNames, parameterValues))
            {
                if (reader.Read())
                {
                    destinationDBFieldName = reader.GetString(reader.GetOrdinal("CWorksField"));
                }
            }
            return destinationDBFieldName;            
        }
		#endregion           
    }
}
