﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.BusinessInterface;
using CDL.Business.Persistence;
using CWX.Core.Common.Data;
using CWX.Core.Common;
using System.Collections.ObjectModel;

namespace CDL.Business.Repository
{
	internal class SourceMapDetailsValidationRepository : RepositoryBase<SourceMapDetailsValidation, SourceMapDetailsValidationPersister>, ISourceMapDetailsValidationRepository
    {
		#region Constructors
        public SourceMapDetailsValidationRepository()
        {
			Persister = new SourceMapDetailsValidationPersister(ConnectionManager.CWXDatabaseName);
        }

		public SourceMapDetailsValidationRepository(SourceMapDetailsValidationPersister persister)
            : base(persister)
        {
		}
		#endregion

		#region Public Methods
		public Collection<SourceMapDetailsValidation> GetListByMapDetailID(int mapDetailID)
		{
			return Persister.GetListByMapDetailID(mapDetailID);
		}
		#endregion
	}
}
