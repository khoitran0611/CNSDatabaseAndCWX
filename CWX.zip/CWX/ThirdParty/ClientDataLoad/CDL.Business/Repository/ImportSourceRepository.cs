﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CWX.Core.Common.Data;
using CDL.BusinessObject;
using CDL.Business.Persistence;
using CDL.BusinessInterface;
using CWX.Core.Common;
using System.Data;
using System.Collections.ObjectModel;

namespace CDL.Business.Repository
{
	internal class ImportSourceRepository : RepositoryBase<ImportSource, ImportSourcePersister>, IImportSourceRepository
    {
		#region Constructors
        public ImportSourceRepository()
        {
            Persister = new ImportSourcePersister(ConnectionManager.CWXDatabaseName);
        }

		public ImportSourceRepository(ImportSourcePersister persister)
            : base(persister)
        {
		}
		#endregion

		#region Public Methods
		public ImportSource GetImportSourceByName(string name, int clientID)
		{
			return base.FindOne(new string[] { "Name", "ClientID" }, new object[] { name, clientID });
		}

		public DataSet FillDataSet(int clientID)
		{
			return Persister.FillDataSet(clientID);
		}

		public Collection<ImportSource> FillListByClientID(int clientID)
		{
			string whereClause = "";
			if (clientID > 0)
				whereClause = String.Format("ClientID = {0}", clientID);
			return base.FillList("Name", whereClause);
		}

		/// <summary>
		/// Removes/Marks as deleted all ImportSources in database.
		/// </summary>
		/// <param name="isSoftDelete">if true this function will mark all ImportSources as deleted, otherwise removes all permanently.</param>
		/// <returns>Returns true if remove successfully, otherwise returns false.</returns>
		public bool RemoveAll(int clientID, bool isSoftDelete)
		{
			return Persister.RemoveAll(clientID, isSoftDelete);
		}

		/// <summary>
		/// Checks if the ImportSource has any templates created.
		/// </summary>
		/// <param name="sourceID"></param>
		/// <returns>Return true if the ImportSource do not have any templates created; otherwise return false.</returns>
		public bool CheckNoTemplateCreated(int sourceID)
		{
			return Persister.CheckNoTemplateCreated(sourceID);
		}
		#endregion
	}
}
