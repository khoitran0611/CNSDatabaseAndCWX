﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using CDL.Business.Persistence;
using CWX.Core.Common.Data;
using CDL.BusinessInterface;
using CWX.Core.Common;

namespace CDL.Business.Repository
{
	public class CommonRepository : RepositoryBase<object, CommonPersister>, ICommonRepository
	{
		#region Constructors
        public CommonRepository()
        {
            Persister = new CommonPersister(ConnectionManager.CWXDatabaseName);
        }

		public CommonRepository(CommonPersister persister)
            : base(persister)
        {
		}
		#endregion

		#region Public Methods
		public DataSet GetAllColumnsDefinitions(string databaseName, string tableName)
		{
			return Persister.GetAllColumnsDefinitions(databaseName, tableName);
		}

        public string GetFieldNameFromDestinationDB(int destinationDBID, string destinationTableID, string sourceDBFieldName)
        {
            return Persister.GetFieldNameFromDestinationDB(destinationDBID,destinationTableID, sourceDBFieldName);
        }
		#endregion

    }
}
