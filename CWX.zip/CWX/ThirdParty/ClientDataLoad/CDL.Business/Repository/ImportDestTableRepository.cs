﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.BusinessInterface;
using CDL.Business.Persistence;
using CWX.Core.Common.Data;
using CWX.Core.Common;
using System.Collections.ObjectModel;
using CDL.Common;

namespace CDL.Business.Repository
{
	internal class ImportDestTableRepository : RepositoryBase<ImportDestTable, ImportDestTablePersister>, IImportDestTableRepository
    {
		#region Constructors
        public ImportDestTableRepository()
        {
            Persister = new ImportDestTablePersister(ConnectionManager.CWXDatabaseName);
        }

		public ImportDestTableRepository(ImportDestTablePersister persister)
            : base(persister)
        {
		}
		#endregion

		#region Public Methods
		public Collection<ImportDestTable> GetListByDestDatabase(DestinationDatabase destDatabase)
		{
			string whereClause = String.Format("DatabaseID = {0}", destDatabase.GetHashCode());
			return base.FillList("TableName", whereClause);
		}

        public int GetImportDestinationID(int databaseID, string tableName)
        {
            int id = 0;
            string whereClause = string.Format("DatabaseID = {0} AND TableName = '{1}'", databaseID, tableName);
            Collection<ImportDestTable> result = base.FillList("TableName", whereClause);
            if(result != null && result.Count > 0)
                id = result[0].ID;
            return id;
        }

		#endregion        
    }
}
