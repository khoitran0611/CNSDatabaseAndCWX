﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections.ObjectModel;

using CWX.Core.Common;
using CDL.BusinessObject;
using CDL.BusinessInterface;
using CWX.Core.Common.Data;
using CDL.Business.Persistence;
using CDL.Common;

namespace CDL.Business.Repository
{
	internal class SourceMapTemplateRepository : RepositoryBase<SourceMapTemplate, SourceMapTemplatePersister>, ISourceMapTemplateRepository
	{		
		#region Constructors
		public SourceMapTemplateRepository()
        {
            Persister = new SourceMapTemplatePersister(ConnectionManager.CWXDatabaseName);
        }

		public SourceMapTemplateRepository(SourceMapTemplatePersister persister)
            : base(persister)
        {
		}
		#endregion

		#region Public Methods
		public override SourceMapTemplate FindOne<TIdentity>(TIdentity identity)
		{
			SourceMapTemplate sourceMapTemplate = base.FindOne<TIdentity>(identity);
			if (sourceMapTemplate != null)
			{
				sourceMapTemplate.KeyColumn = new SourceMapDetailsService().GetKeyColumn(sourceMapTemplate.TemplateID);
			}
            sourceMapTemplate.AllowDuplicateKey = Persister.CheckAllowDuplicateKey(sourceMapTemplate.TemplateID);
			return sourceMapTemplate;
		}

		public DataSet FillDataSet(int clientID, int sourceID, bool onlyActive)
		{
			return Persister.FillDataSet(clientID, sourceID, onlyActive);
		}

		public Collection<SourceMapTemplate> GetListBySourceID(int sourceID)
		{
			return GetListBySourceID(sourceID, false);	
		}

		public Collection<SourceMapTemplate> GetListBySourceID(int sourceID, bool onlyActive)
		{
			if (sourceID > 0)
			{
				string whereClause = String.Format("SourceID = {0}", sourceID);
				if (onlyActive)
					whereClause += " AND Active = 1";
				return base.FillList("TemplateID", whereClause);
			}
			else
			{
				return null;
			}
		}

		public void UpdateActiveStatus(int templateID)
		{
			Persister.UpdateActiveStatus(templateID);
		}

		/// <summary>
		/// Removes/Marks as deleted all SourceMapTemplates in database.
		/// </summary>
		/// <param name="isSoftDelete">if true this function will mark all SourceMapTemplates as deleted, otherwise removes all permanently.</param>
		/// <returns>Returns true if remove successfully, otherwise returns false.</returns>
		public bool RemoveAll(int sourceID, bool isActive, bool isSoftDelete)
		{
			return Persister.RemoveAll(sourceID, isActive, isSoftDelete);
		}

		/// <summary>
		/// Copies a SourceMapTemplate and its mapping details
		/// </summary>
		/// <param name="copyTemplateID">The template ID to copy</param>
		/// <param name="createdBy"></param>
		/// <param name="createdDate"></param>
		/// <returns>true if copying successfull, otherwise false.</returns>
		public bool CopySourceMapTemplate(int copyTemplateID, int createdBy, DateTime createdDate, out int newTemplateID)
		{
			return Persister.CopySourceMapTemplate(copyTemplateID, createdBy, createdDate, out newTemplateID);
		}

		/// <summary>
		/// Checks if a Source Map Template has at least one mapping to destination field.
		/// </summary>
		/// <param name="templateID"></param>
		/// <returns></returns>
		public bool ExistAtLeastOneMapping(int templateID)
		{
			return Persister.ExistAtLeastOneMapping(templateID);
		}

		/// <summary>
		/// Checks if a template has assigned key column
		/// </summary>
		/// <param name="templateID"></param>
		/// <returns></returns>
		public bool HasMappingKeyColumn(int templateID)
		{
			return Persister.HasMappingKeyColumn(templateID);
		}

		public void UpdateKeyColumn(int templateID, int keyColumnID)
		{
			Persister.UpdateKeyColumn(templateID, keyColumnID);
		}
		#endregion
	}
}
