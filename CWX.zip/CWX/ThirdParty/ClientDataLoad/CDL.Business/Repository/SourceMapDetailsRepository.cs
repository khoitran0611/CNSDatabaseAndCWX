﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.BusinessInterface;
using CDL.Business.Persistence;
using CWX.Core.Common.Data;
using CWX.Core.Common;
using System.Collections.ObjectModel;
using CDL.Common;

namespace CDL.Business.Repository
{
	internal class SourceMapDetailsRepository : RepositoryBase<SourceMapDetails, SourceMapDetailsPersister>, ISourceMapDetailsRepository
	{
		#region Services
		private SourceMapDetailsValidationService _sourceMapDetailsValidationService;
		protected SourceMapDetailsValidationService SourceMapDetailsValidationServiceInstance
		{
			get
			{
				if (_sourceMapDetailsValidationService == null)
					_sourceMapDetailsValidationService = new SourceMapDetailsValidationService();
				return _sourceMapDetailsValidationService;
			}
		}
		#endregion

		#region Constructors
		public SourceMapDetailsRepository()
        {
            Persister = new SourceMapDetailsPersister(ConnectionManager.CWXDatabaseName);
        }

		public SourceMapDetailsRepository(SourceMapDetailsPersister persister)
            : base(persister)
        {
		}
		#endregion

		#region Public Methods
		public override SourceMapDetails FindOne<TIdentity>(TIdentity identity)
		{
			SourceMapDetails sourceMapDetails = base.FindOne<TIdentity>(identity);
			if (sourceMapDetails != null)
			{				
				int startPosition = GetMinimumStartPositionByID(sourceMapDetails.TemplateID, sourceMapDetails.ID);
				CalculateStartEndPosition(sourceMapDetails, startPosition);

				GetValidationCollection(sourceMapDetails);
			}
			
			return sourceMapDetails;
		}

		public override SourceMapDetails FindOne(string[] identityFields, object[] identityValues)
		{
			SourceMapDetails sourceMapDetails = base.FindOne(identityFields, identityValues);
			if (sourceMapDetails != null)
			{
				int startPosition = GetMinimumStartPositionByID(sourceMapDetails.TemplateID, sourceMapDetails.ID);
				CalculateStartEndPosition(sourceMapDetails, startPosition);

				GetValidationCollection(sourceMapDetails);
			}

			return sourceMapDetails;
		}
		
		public Collection<SourceMapDetails> GetListByTemplateID(int templateID)
		{
			return GetListByTemplateID(templateID, false);
		}

        public Collection<SourceMapDetails> GetListByTemplateID(int templateID, bool excludeDerivedColumn)
        {
            return GetListByTemplateID(templateID, excludeDerivedColumn, "ID");
        }

        public Collection<SourceMapDetails> GetListByTemplateID(int templateID, bool excludeDerivedColumn, string orderBy)
        {
            if (templateID > 0)
            {
                string whereClause = String.Format("TemplateID = {0}", templateID);
                if (excludeDerivedColumn)
                    whereClause += " AND IsDerived = 0";

                Collection<SourceMapDetails> sourceMapDetailsList = base.FillList(orderBy, whereClause);
				int startPosition = 1;
                foreach (SourceMapDetails sourceMapDetails in sourceMapDetailsList)
                {
					startPosition = CalculateStartEndPosition(sourceMapDetails, startPosition);
					GetValidationCollection(sourceMapDetails);                    
                }
                return sourceMapDetailsList;
            }
            else
                return null;
            
        }

		public Collection<SourceMapDetails> GetPagingListByTemplateID(int templateID, int pageSize, int pageIndex, out int rowCount)
		{
			if (templateID > 0)
			{
				string whereClause = String.Format("TemplateID = {0}", templateID);
				Collection<SourceMapDetails> sourceMapDetailsList = base.FillPagingList(pageSize, pageIndex, "ID", whereClause, out rowCount);
				if (sourceMapDetailsList.Count > 0)
				{
					int startPosition = GetMinimumStartPositionByID(sourceMapDetailsList[0].TemplateID, sourceMapDetailsList[0].ID);
					foreach (SourceMapDetails sourceMapDetails in sourceMapDetailsList)
					{
						startPosition = CalculateStartEndPosition(sourceMapDetails, startPosition);
						GetValidationCollection(sourceMapDetails);
					}
				}
				return sourceMapDetailsList;
			}
			else
			{
				rowCount = 0;
				return null;
			}
		}

		public int GetNumberOfSourceMapDetails(int templateID)
		{
			return Persister.GetNumberOfSourceMapDetails(templateID);
		}

		public SourceMapDetails GetBySourceColumn(int templateID, string sourceColumn)
		{
			if (templateID > 0)
			{
				string[] identityFields = new string[] { "TemplateID", "SourceCol" };
				object[] identityValues = new object[] { templateID, sourceColumn };
				return FindOne(identityFields, identityValues);
			}
			else
			{
				return null;
			}
		}

		public SourceMapDetails GetByDestField(int templateID, string destField)
		{
			if (templateID > 0)
			{
				string[] identityFields = new string[] { "TemplateID", "DestField" };
				object[] identityValues = new object[] { templateID, destField };
				return FindOne(identityFields, identityValues);
			}
			else
			{
				return null;
			}
		}

		public SourceMapDetails GetBySequenceOrder(int templateID, int sequenceOrder)
		{
			if (templateID > 0)
			{
				SourceMapDetails sourceMapDetails = Persister.GetBySequenceOrder(templateID, sequenceOrder);
				if (sourceMapDetails != null)
				{
					int startPosition = GetMinimumStartPositionByID(sourceMapDetails.TemplateID, sourceMapDetails.ID);
					CalculateStartEndPosition(sourceMapDetails, startPosition);

					GetValidationCollection(sourceMapDetails);
				}

				return sourceMapDetails;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// Removes/Marks as deleted all SourceMapDetails in database.
		/// </summary>
		/// <param name="isSoftDelete">if true this function will mark all SourceMapDetails as deleted, otherwise removes all permanently.</param>
		/// <returns>Returns true if remove successfully, otherwise returns false.</returns>
		public bool RemoveAll(int templateID, bool isSoftDelete)
		{
			return Persister.RemoveAll(templateID, isSoftDelete);
		}

		public bool GenerateMappingColumns(int templateID, int numberOfColumns, int createdBy, DateTime creteadDate)
		{
			return Persister.GenerateMappingColumns(templateID, numberOfColumns, createdBy, creteadDate);
		}

		public int GetMinimumStartPositionByID(int templateID, int mapDetailID)
		{
			return Persister.GetMinimumStartPositionByID(templateID, mapDetailID);
		}

		public bool UpdateMappingKeyColumn(DestinationDatabase destDatabase, string destTable, int templateID, int sourceKeyColumnID)
		{
			return Persister.UpdateMappingKeyColumn(destDatabase, destTable, templateID, sourceKeyColumnID);
		}

		public SourceMapDetails GetKeyColumn(int templateID)
		{
			return Persister.GetKeyColumn(templateID);
		}
		#endregion

		#region Private Methods
		private void GetValidationCollection(SourceMapDetails sourceMapDetails)
		{
			if (sourceMapDetails != null)
			{
				Collection<SourceMapDetailsValidation> validationCollection = SourceMapDetailsValidationServiceInstance.GetListByMapDetailID(sourceMapDetails.ID);
				sourceMapDetails.ValidationCollection = new SourceMapDetailsValidationCollection(validationCollection);
			}
		}

		/// <summary>
		/// Calculate the start position and end position of a SourceMapDetails, and return the start postion of the next column.
		/// </summary>
		/// <param name="sourceMapDetails"></param>
		/// <param name="startPosition"></param>
		/// <returns>An System.Int32 value that represents the start postion of the next column.</returns>
		private int CalculateStartEndPosition(SourceMapDetails sourceMapDetails, int startPosition)
		{
			// Calculate the start and end positions
			sourceMapDetails.StartPosition = startPosition;
			sourceMapDetails.EndPosition = startPosition + sourceMapDetails.ColumnWidth - 1;

			startPosition += sourceMapDetails.ColumnWidth;

			return startPosition;
		}
		#endregion
	}
}
