﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.Business.Persistence;
using CDL.BusinessInterface;
using CWX.Core.Common.Data;
using CWX.Core.Common;
using System.Collections.ObjectModel;

namespace CDL.Business.Repository
{
	internal class SSISFunctionsRepository : RepositoryBase<SSISFunctions, SSISFunctionsPersister>, ISSISFunctionsRepository
    {
		#region Constructors
        public SSISFunctionsRepository()
        {
            Persister = new SSISFunctionsPersister(ConnectionManager.CWXDatabaseName);
        }

		public SSISFunctionsRepository(SSISFunctionsPersister persister)
            : base(persister)
        {
		}
		#endregion

		#region Public Methods
		public Collection<SSISFunctions> GetListByFunctionType(int functionTypeCode)
		{
			return Persister.GetListByFunctionType(functionTypeCode);
		}
		#endregion
	}
}
