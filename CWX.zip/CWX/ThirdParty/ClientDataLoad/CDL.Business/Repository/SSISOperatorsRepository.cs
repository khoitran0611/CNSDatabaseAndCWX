﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CDL.BusinessObject;
using CDL.Business.Persistence;
using CWX.Core.Common.Data;
using CDL.BusinessInterface;
using CWX.Core.Common;

namespace CDL.Business.Repository
{
	internal class SSISOperatorsRepository : RepositoryBase<SSISOperators, SSISOperatorsPersister>, ISSISOperatorsRepository
    {
		#region Constructors
        public SSISOperatorsRepository()
        {
            Persister = new SSISOperatorsPersister(ConnectionManager.CWXDatabaseName);
        }

		public SSISOperatorsRepository(SSISOperatorsPersister persister)
            : base(persister)
        {
		}
		#endregion
	}
}
