﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CDL.Common
{
	public class ImportResult
	{
        private string _importFile;
        public string ImportFile 
        {
            get { return _importFile; }
            set { _importFile = value; }
        }
        private string _destinationTable;
        public string DestinationTable 
        { 
                get { return _destinationTable; }
                set { _destinationTable = value; } 
        }

        public DataSourceType SourceType { get; set; }        
        public int NumberofImportedRows { get; set; }
        public int NumberofDuplicatedRows { get; set; }
        public int NumberofAllFieldNullRows { get; set; }
        public int NumberofUnsatisfyConditionRows { get; set; }
        public int NumberOfSkippedRows { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
	}
}
