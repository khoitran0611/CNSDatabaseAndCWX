﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CDL.Common
{
	public interface IImportDataWizard
	{
		void InitControl();
		bool Submit();
	}
}
