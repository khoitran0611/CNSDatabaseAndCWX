﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CDL.Common
{
	public enum DataSourceType
	{		
		TextFile = 1,
		ExcelFile = 2,
		CSVFile = 3,
		Database = 4
	}

	public enum FlatFileFormat
	{
		Delimited = 1,
		FixedWidth = 2
	}

	public enum DataType
	{
		Integer = 1,
		Real = 2,
		Date = 3,
		String = 4,
		Boolean = 5,
		Currency = 6
	}

	public enum DestinationDatabase
	{
		Load1 = 1, 
		CWorks = 2
	}

    public enum ExcelVersion
    {
        MsExcel2003 = 1,
        MsExcel2007 = 2
    }

    public enum DatabaseDestinationType
    {
        Data =1,
        Error=2
    }

    public enum DatabaseConnectionStringInfo
    { 
        DatabaseName,
        ServerName,
        UserName,
        Password
    }

	public enum EnumSSISFunctionType
	{
		Mathematical = 1,
		String = 2,
		DateTime = 3,
		//NULL = 4,
		TypeCast = 5
	}
}
