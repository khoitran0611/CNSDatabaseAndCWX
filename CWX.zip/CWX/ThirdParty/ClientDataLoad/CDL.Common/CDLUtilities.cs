﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Runtime.InteropServices;
using CWX.Core.Common;
using System.Data.OleDb;
using System.Data;
using System.Text.RegularExpressions;
using CWX.Core.Common.Data;
using System.IO;
using CWX.Core.Common.Exceptions;
using CWX.Core.Common.Resource;
using System.Data.Common;

namespace CDL.Common
{
	public class CDLUtilities
	{
                
        public static string GetConnectionStringInfo(string connectionString, DatabaseConnectionStringInfo infoTypeToGet)
        {
            object resultInfo = null;   
            DbConnectionStringBuilder connectionStringBuilder = new DbConnectionStringBuilder();
            connectionStringBuilder.ConnectionString = connectionString;
            switch (infoTypeToGet)
            { 
                case DatabaseConnectionStringInfo.DatabaseName:
                    if (!connectionStringBuilder.TryGetValue("initial catalog", out resultInfo))
                        connectionStringBuilder.TryGetValue("database", out resultInfo);
                                        
                    break;
                case DatabaseConnectionStringInfo.Password:
                    if (!connectionStringBuilder.TryGetValue("password", out resultInfo))
                        connectionStringBuilder.TryGetValue("pwd", out resultInfo);
                    
                    break;
                case DatabaseConnectionStringInfo.ServerName:
                    if (!connectionStringBuilder.TryGetValue("data source", out resultInfo))
                        connectionStringBuilder.TryGetValue("Server", out resultInfo);

                    
                    break;
                case DatabaseConnectionStringInfo.UserName:

                    if (!connectionStringBuilder.TryGetValue("user id", out resultInfo))
                        connectionStringBuilder.TryGetValue("uid", out resultInfo);
                    
                    break;
            }
            return resultInfo.ToString();
        }

        public static SortedDictionary<string, int> GetLocalesFromCultureInfos()
        {
            CultureInfo[] infos = CultureInfo.GetCultures(CultureTypes.SpecificCultures);
            if (infos == null || infos.Length == 0)
                return null;

            SortedDictionary<string, int> result = new SortedDictionary<string, int>();
            foreach (CultureInfo i in infos)
                result.Add(i.EnglishName, i.LCID);

            return result;
        }

		//public static SortedDictionary<string, int> GetCodePages()
		//{
		//    CharSet[] charsets = new InternalLanguageFacade().GetCharSets();
		//    if (charsets == null || charsets.Length == 0)
		//        return null;

		//    SortedDictionary<string, int> result = new SortedDictionary<string, int>();
		//    foreach (CharSet c in charsets)
		//        result.Add(c.Codepage.ToString(CultureInfo.InvariantCulture) + " - " + c.Name, c.Codepage);

		//    return result;
		//}

        public static string GetDatabaseElementName(DestinationDatabase destinationDB)
        {
            string dbElementName = string.Empty;
            switch (destinationDB)
            { 
                case DestinationDatabase.CWorks:
                    dbElementName = ConnectionManager.OLEDBCWorksDatabaseName;
                    break;
                case DestinationDatabase.Load1:
                    dbElementName = ConnectionManager.OLEDBLoad1DatabaseName;
                    break;
            }
            return dbElementName;
        }

        public static string GetOLDBConnectionString(DestinationDatabase destinationDB)
        {
            string connectionString = string.Empty;
            switch (destinationDB)
            { 
                case DestinationDatabase.CWorks:
                    connectionString = ConnectionManager.OLEDBCWorksConnectionString;
                    break;
                case DestinationDatabase.Load1:
                    connectionString = ConnectionManager.OLEDBLoad1ConnectionString;
                    break;
            }
            return connectionString;
        }

		public static string GetDatabaseName(string connectionString)
		{
			Regex parseDatabase = new Regex (@"(?i:((Initial\sCatalog)|(Database))=(?<database>[^;]+))", 
											RegexOptions.Compiled);
			string databaseName = parseDatabase.Match(connectionString).Groups["database"].Value;
			return databaseName;
		}

		public static string ProcessingSpecialDelimiterSymbols(string delimiter)
		{
			return delimiter.Replace("\\r", "\r").Replace("\\n", "\n").Replace("\\t", "\t").Replace("{t}", "\t");
		}

		public static string ProcessingSpecialDelimiterSymbolsForUI(string delimiter)
		{
			return delimiter.Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t");
            
		}

		public static bool IsTableExisting(string databaseElementName, string tableName)
		{
			bool existing = false;
			using (IDataExecutionContext dataContext = new DataProviderFactory().Create(databaseElementName).BeginExecution())
			{
				StringBuilder sql = new StringBuilder();
				sql.AppendFormat("IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[{0}]') AND type in (N'U'))", tableName);
				sql.AppendFormat(" BEGIN SELECT 1 AS RESULT END");
				sql.AppendFormat(" ELSE  BEGIN SELECT 0 AS RESULT END");
				dataContext.SetCommandText(sql.ToString(), CommandType.Text);
				dataContext.RunReader(CommandBehavior.CloseConnection);

				using (IDataReader reader = dataContext.RunReader())
				{
					if (reader.Read())
					{
						existing = reader.GetInt32(reader.GetOrdinal("RESULT")) > 0;
					}
				}
			}
			return existing;
		}

        #region Excel Helper

        public static string ExcelBuildConnectionString(string excelFilePath, ExcelVersion Version, bool firstLineIsHeader)
        {
            string connectionProvider = string.Empty;
            if (Version == ExcelVersion.MsExcel2007)
                connectionProvider=  "Microsoft.ACE.OLEDB.12.0";
            else
                connectionProvider= "Microsoft.Jet.OLEDB.4.0";

            string extendedProperties = string.Empty;
            if (Version == ExcelVersion.MsExcel2007)
                extendedProperties = string.Format("\"Excel 12.0 Xml;HDR={0};IMEX=1\"", firstLineIsHeader?"YES":"NO");
            else
                extendedProperties = string.Format("\"Excel 8.0;HDR={0};IMEX=1\"", firstLineIsHeader ? "YES" : "NO");

            return string.Format("Provider={0};Data Source={1};Extended Properties={2};",
                                                        connectionProvider, excelFilePath, extendedProperties);
        }

        public static bool ExcelCheckSheetExist(string sheetName, string connectionString)
        {
            using (OleDbConnection oleDbConnection = new OleDbConnection(connectionString))
            {
                oleDbConnection.Open();
                string sqlStatement = string.Format("Select 1 from [{0}]", sheetName);
                try
                {
                    OleDbCommand command = new OleDbCommand(sqlStatement, oleDbConnection);
                    command.ExecuteScalar();                    
                }
                catch (OleDbException e)
                {
                    if (!string.IsNullOrEmpty(e.Message) && e.Message.Contains(string.Format("The Microsoft Jet database engine could not find the object '{0}'", sheetName)))
                        return false;
                    else
                        throw;
                }
                return true;
            }
        }

        public static List<string> ExcelGetSheetNames(string connectionString)
        {
            List<string> excelSheets = new List<string>();
            using (OleDbConnection oleDbConnection = new OleDbConnection(connectionString))
            {
                oleDbConnection.Open();
                DataTable dataTable = oleDbConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                if (dataTable != null)
                {
                    foreach (DataRow row in dataTable.Rows)
                    {
                        string sheetName = row["TABLE_NAME"].ToString();

						// REMOVE SINGLE QUOTES IN TABLE NAME USED WHEN NUMBERS PRESENT
						if (sheetName.EndsWith("'"))
						{
							sheetName = sheetName.Remove(0, 1);
							sheetName = sheetName.Remove(sheetName.Length - 1, 1);
						}

						// ADD SHEET NAMES ONLY (ends with $) TO THE LIST
						if (sheetName.EndsWith("$"))
							excelSheets.Add(sheetName);
                    }
                }
            }
            return excelSheets;
        }

        public static string ParseExcel2CVS(string fileName, string workSheetName)
        {
            string targetPath = string.Empty;

            if (File.Exists(fileName))
            {
                string excelConnectionString = CDLUtilities.ExcelBuildConnectionString(fileName, ExcelVersion.MsExcel2003, false);
                DataTable tableExcel = new DataTable();
                using (OleDbConnection oleDbConnection = new OleDbConnection(excelConnectionString))
                {
                    oleDbConnection.Open();
                    string selectCommandText = String.Format("SELECT * FROM [{0}]", workSheetName);
                    OleDbDataAdapter oleDbAdapter = new OleDbDataAdapter(selectCommandText, oleDbConnection);
                    oleDbAdapter.Fill(tableExcel);
                }
                if (tableExcel != null)
                {
                    string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(fileName);
                    targetPath = String.Format("{0}_{1}.{2}", fileNameWithoutExtension, CWXGuidGenerator.GenerateNewGuid(), "csv");
                    string uploadFileDirectory = Directory.GetParent(fileName).ToString();
                    targetPath = uploadFileDirectory + @"\" + targetPath;
                    StreamWriter writer = new StreamWriter(targetPath,false,UnicodeEncoding.Unicode);                    
                    try
                    {
                        for (int i = 0; i < tableExcel.Rows.Count; i++)
                        {
                            StringBuilder csvBuilder = new StringBuilder();

                            for (int j = 0; j < tableExcel.Columns.Count; j++)
                            {
                                csvBuilder.AppendFormat("\"{0}\"", tableExcel.Rows[i][j]);
                                if (j < tableExcel.Columns.Count - 1)
                                {
                                    csvBuilder.Append(",");
                                }
                            }
                            writer.WriteLine(csvBuilder.ToString());
                        }
                    }
                    finally
                    {
                        writer.Close();
                    }
                }
            }
            else
            {
                throw new CWXException(String.Format(CWXResourceManager.GetString(ResourceCategory.Errors_CDL, "WebCommon_FileNotFound"), fileName));
            }

            return targetPath;
        }

        #endregion
    }
}
