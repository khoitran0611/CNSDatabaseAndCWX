using System;
using System.Collections.Generic;
using System.Text;
using CWX.Core.Common.Data;
using System.Collections.ObjectModel;
using System.Xml;
using System.Data;

namespace CWX.Core.Providers.Data.Mapping
{
    public class XmlMappingAdapter
    {
        public TableMappingInfo Read(XmlDocument xmlDoc)
        {
            string tableName = xmlDoc.DocumentElement.Attributes["tableName"].Value;
            string objectType = xmlDoc.DocumentElement.Attributes["objectType"].Value;
            bool softDeletable = (xmlDoc.DocumentElement.Attributes["softDeletable"] == null) ? false : bool.Parse(xmlDoc.DocumentElement.Attributes["softDeletable"].Value);
            string recordStatusField = (xmlDoc.DocumentElement.Attributes["recordStatusField"] == null) ? string.Empty : xmlDoc.DocumentElement.Attributes["recordStatusField"].Value;
            bool forceAudit = (xmlDoc.DocumentElement.Attributes["forceAudit"] == null) ? false : bool.Parse(xmlDoc.DocumentElement.Attributes["forceAudit"].Value);
            bool auditOnActionAdd = (xmlDoc.DocumentElement.Attributes["auditOnActionAdd"] == null) ? true : bool.Parse(xmlDoc.DocumentElement.Attributes["auditOnActionAdd"].Value);
            bool auditOnActionEdit = (xmlDoc.DocumentElement.Attributes["auditOnActionEdit"] == null) ? true : bool.Parse(xmlDoc.DocumentElement.Attributes["auditOnActionEdit"].Value);
            bool auditOnActionDelete = (xmlDoc.DocumentElement.Attributes["auditOnActionDelete"] == null) ? true : bool.Parse(xmlDoc.DocumentElement.Attributes["auditOnActionDelete"].Value);

            TableMappingInfo tableInfo = new TableMappingInfo();
            tableInfo.DBTableName = tableName;
            tableInfo.ObjectType = Type.GetType(objectType);
            tableInfo.SoftDeletable = softDeletable;
            tableInfo.RecordStatusField = recordStatusField;
            tableInfo.ForceAudit = forceAudit;
            tableInfo.AuditOnActionAdd = auditOnActionAdd;
            tableInfo.AuditOnActionEdit = auditOnActionEdit;
            tableInfo.AuditOnActionDelete = auditOnActionDelete;
            tableInfo.FieldMappings = new Collection<FieldMappingInfo>();

            XmlNodeList fieldNodeList = xmlDoc.SelectNodes("table/fields/field");
            foreach (XmlNode fieldNode in fieldNodeList)
            {
                FieldMappingInfo fieldInfo = new FieldMappingInfo();
                fieldInfo.DBFieldName = fieldNode.Attributes["field"].Value;
                fieldInfo.ObjectFieldName = fieldNode.Attributes["property"].Value;
                fieldInfo.IsPrimaryKey = bool.Parse(fieldNode.Attributes["isPrimaryKey"].Value);
                if (fieldNode.Attributes["automatedIncrease"] != null)
                    fieldInfo.AutomatedIncrease = bool.Parse(fieldNode.Attributes["automatedIncrease"].Value);
                else
                    fieldInfo.AutomatedIncrease = false;

                fieldInfo.DBType = fieldNode.Attributes["dbType"].Value.Trim();
                if (fieldNode.Attributes["length"] == null)
                    fieldInfo.Length = 0;
                else
                    fieldInfo.Length = int.Parse(fieldNode.Attributes["length"].Value);

                if (fieldNode.Attributes["precision"] == null)
                    fieldInfo.Precision = 0;
                else
                    fieldInfo.Precision = int.Parse(fieldNode.Attributes["precision"].Value);

                if (fieldNode.Attributes["scale"] == null)
                    fieldInfo.Scale = 0;
                else
                    fieldInfo.Scale = int.Parse(fieldNode.Attributes["scale"].Value);

                if (fieldNode.Attributes["readonly"] == null)
                    fieldInfo.ReadOnly = false;
                else
                    fieldInfo.ReadOnly = bool.Parse(fieldNode.Attributes["readonly"].Value);

                tableInfo.FieldMappings.Add(fieldInfo);
            }

            return tableInfo;
        }
    }
}
