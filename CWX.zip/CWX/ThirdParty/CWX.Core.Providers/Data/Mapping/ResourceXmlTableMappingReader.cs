using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Reflection;
using System.Collections.ObjectModel;

using CWX.Core.Common.Data;
using CWX.Core.Common.Resource;

namespace CWX.Core.Providers.Data.Mapping
{
    public class ResourceXmlTableMappingReader : IXmlMappingReader
    {
        #region IXmlMappingReader Members

        public XmlDocument GetXmlMapping(Type objectType)
        {
            Assembly asm = objectType.Assembly;
            string resourceName = objectType.Namespace + "." + objectType.Name + ".xml";
            return ResourceUtil.GetXmlDocumentFromAssembly(asm, resourceName);
        }

        #endregion
    }
}
