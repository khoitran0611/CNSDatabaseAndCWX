using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using CWX.Core.Common.Data;

namespace CWX.Core.Providers.Data.Mapping
{
    public interface IXmlMappingReader
    {
        XmlDocument GetXmlMapping(Type objectType);
    }
}
