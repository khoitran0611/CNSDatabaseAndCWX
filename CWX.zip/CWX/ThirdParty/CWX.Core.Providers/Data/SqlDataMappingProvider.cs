using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Reflection;

using CWX.Core.Common.Data;

namespace CWX.Core.Providers.Data
{
    using Mapping;

    public class SqlDataMappingProvider: IDataMappingProvider
    {
        private IXmlMappingReader _mappingReader;
        public IXmlMappingReader MappingReader
        {
            get { return _mappingReader; }
            set { _mappingReader = value; }
        }

        public SqlDataMappingProvider() : this(new ResourceXmlTableMappingReader())
        {
        }

        public SqlDataMappingProvider(IXmlMappingReader mappingReader)
        {
            _mappingReader = mappingReader;
        }

        #region IDataMappingProvider Members
        public TableMappingInfo GetTableMappingInfo(Type objectType)
        {
            XmlDocument xmlTableMappingInfo = MappingReader.GetXmlMapping(objectType);
            return new XmlMappingAdapter().Read(xmlTableMappingInfo);
        }

        #endregion
    }
}
