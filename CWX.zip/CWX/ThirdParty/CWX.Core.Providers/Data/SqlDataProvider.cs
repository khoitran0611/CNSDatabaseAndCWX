using System;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Reflection;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Threading;

using Microsoft.Practices.EnterpriseLibrary.Data;

using CWX.Core.Common.Data;
using CWX.Core.Common.Data.Query;
using CWX.Core.Common.Data.DataConverter;
using CWX.Core.Providers.Data.Query;
using CWX.Core.Common.Audit;
using CWX.Core.Common.DomainObject;
using CWX.Core.Common.Security;


namespace CWX.Core.Providers.Data
{
    public class SqlDataProvider : DataProviderBase
    {
        #region Private Properties
        private string _databaseName;
        private Database _database;
        private Database Db
        {
            get
            {
                if (_database == null)
                {
                    if (string.IsNullOrEmpty(_databaseName))
                        _database = DatabaseFactory.CreateDatabase();
                    else
                        _database = DatabaseFactory.CreateDatabase(_databaseName);
                }
                return _database;
            }
        }

        private IDataMappingProvider _mappingProvider;
        public IDataMappingProvider MappingProvider
        {
            get
            {
                if (_mappingProvider == null)
                    _mappingProvider = new DataMappingProviderFactory().Create();
                return _mappingProvider;
            }
            set
            {
                _mappingProvider = value;
            }
        }

        #endregion

        #region Constructors
        public SqlDataProvider()
            : this(string.Empty)
        {
        }

        public SqlDataProvider(string databaseName)
        {
            _databaseName = databaseName;
        }

        public SqlDataProvider(Database dataBase, IDataMappingProvider mappingProvider)
        {
            _database = dataBase;
            _mappingProvider = mappingProvider;
        }
        #endregion

        #region IDataProvider Members

        #region CRUD Action Methods
        /// <summary>
        /// Inserts an object into database and returns true if inserts successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Returns true if inserts successfully, otherwise returns false.</returns>
        public override bool Insert<TDomainObject>(TDomainObject domainObject)
        {
            ValidateParameters<TDomainObject>(domainObject);

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlInsertQueryBuilder queryBuilder = new SqlInsertQueryBuilder(tableInfo.DBTableName);
            if (tableInfo.SoftDeletable)
                queryBuilder.AddInsertColumn(tableInfo.RecordStatusField, RecordStatusConstant.ACTIVE);

            string identityPropertyName = string.Empty;

            foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
            {
                if (fieldInfo.IsPrimaryKey)
                    identityPropertyName = fieldInfo.ObjectFieldName;

                if (!fieldInfo.AutomatedIncrease && !fieldInfo.ReadOnly)
                {
                    PropertyInfo propertyInfo = typeof(TDomainObject).GetProperty(fieldInfo.ObjectFieldName);

                    IDataConverter converter = DataConverterFactory.Create(propertyInfo);
                    object propertyValue = propertyInfo.GetValue(domainObject, null);

                    object dataValue = converter.ConvertFrom(propertyValue, DbType.String, propertyInfo.PropertyType);

                    queryBuilder.AddInsertColumn(fieldInfo.DBFieldName, dataValue);
                }
                else if (fieldInfo.AutomatedIncrease)
                    queryBuilder.ReturnIdentity = true;
            }

            DbCommand insertCommand = CreateCommand(queryBuilder);
            bool isSuccess = true;
            if (!queryBuilder.ReturnIdentity)
                isSuccess = Db.ExecuteNonQuery(insertCommand) > 0;
            else
            {
                object returnIdentity = Db.ExecuteScalar(insertCommand);
                isSuccess = (returnIdentity!=null && returnIdentity != DBNull.Value);
                if (isSuccess)
                    SetObjectPropertyValue(domainObject, identityPropertyName, returnIdentity);
            }

            if (isSuccess)
                CWXAuditManager.AuditObject(domainObject as IDomainObject, CWXAuditAction.Add, tableInfo);

            return isSuccess;
        }

        /// <summary>
        /// Inserts an object into database and returns true if inserts successfully, otherwise returns false.
        /// Then output new ID.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Returns true if inserts successfully, otherwise returns false.</returns>
        public override bool Insert<TDomainObject>(TDomainObject domainObject, out int newID)
        {
            newID = 0;
            if (Insert<TDomainObject>(domainObject))
            {
                newID = GetMaxIdentity<TDomainObject>();                
                return true;
            }

            return false;
        }

        /// <summary>
        /// Deletes a record with the given array of identity fields that have identity values 
        /// and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="identityFields">An array of identity fields.</param>
        /// <param name="identityValues">An array of identity values.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        public override bool Delete<TDomainObject>(string[] identityFields, object[] identityValues)
        {
            ValidateParameters(identityFields, identityValues);

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlDeleteQueryBuilder queryBuilder = new SqlDeleteQueryBuilder(tableInfo.DBTableName);

            for (int i = 0; i < identityFields.Length; i++)
            {
                queryBuilder.AddIdentity(identityFields[i], identityValues[i]);
            }

            DbCommand deleteCommand = CreateCommand(queryBuilder);

            int affectedCount = Db.ExecuteNonQuery(deleteCommand);
            bool isSuccess = affectedCount > 0;
            if (isSuccess)
                AuditChange(identityFields, identityValues, tableInfo, CWXAuditAction.Delete);

            return isSuccess;

        }

        /// <summary>
        /// Deletes a record where its identity value is equal to the identity value of the given object
        /// and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        public override bool Delete<TDomainObject>(TDomainObject domainObject)
        {
            ValidateParameters<TDomainObject>(domainObject);

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlDeleteQueryBuilder queryBuilder = new SqlDeleteQueryBuilder(tableInfo.DBTableName);

            foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
            {
                PropertyInfo propertyInfo = typeof(TDomainObject).GetProperty(fieldInfo.ObjectFieldName);
                object propertyValue = propertyInfo.GetValue(domainObject, null);
                if (fieldInfo.IsPrimaryKey)
                {
                    queryBuilder.AddIdentity(fieldInfo.DBFieldName, propertyValue);
                }
            }

            DbCommand deleteCommand = CreateCommand(queryBuilder);

            int affectedCount = Db.ExecuteNonQuery(deleteCommand);
            bool isSuccess = affectedCount > 0;
            if (isSuccess)
                CWXAuditManager.AuditObject(domainObject as IDomainObject, CWXAuditAction.Delete, tableInfo);

            return isSuccess;
        }

        /// <summary>
        /// Deletes a record with the given identityValue and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <typeparam name="TIdentity">The type of the given identityValue.</typeparam>
        /// <param name="identityValue">The value of identity.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        public override bool Delete<TDomainObject, TIdentity>(TIdentity identityValue)
        {
            if (identityValue == null)
                throw new ArgumentNullException("identityValue");

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlDeleteQueryBuilder queryBuilder = new SqlDeleteQueryBuilder(tableInfo.DBTableName);

            bool isObjectHaveOneIdentity = false;
            string identityField = string.Empty;
            foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
            {
                if (fieldInfo.IsPrimaryKey)
                {
                    if (!isObjectHaveOneIdentity)
                    {
                        identityField = fieldInfo.DBFieldName;
                        queryBuilder.AddIdentity(fieldInfo.DBFieldName, identityValue);
                        isObjectHaveOneIdentity = true;
                    }
                    else
                    {
                        isObjectHaveOneIdentity = false;
                        break;
                    }
                }
            }

            if (!isObjectHaveOneIdentity)
                throw new Exception("This method's only used for object that has one identity.");

            DbCommand deleteCommand = CreateCommand(queryBuilder);

            int affectedCount = Db.ExecuteNonQuery(deleteCommand);
            bool isSuccess = affectedCount > 0;
            if (isSuccess)
            {
                CWXIdentity identity = Thread.CurrentPrincipal.Identity as CWXIdentity;
                int? employeeID = null;
                if (identity != null)
                    employeeID = identity.UserID;

                CWXAuditTrail trail = new CWXAuditTrail();
                if (employeeID.HasValue)
                    trail.EmployeeID = employeeID.Value;
                trail.ChangedTable = tableInfo.DBTableName;
                trail.RowID = identityValue.ToString();
                trail.ChangedField = identityField;
                trail.ChangedData = Convert.ToString(identityValue);
                trail.Action = CWXAuditAction.Delete;
                CWXAuditManager.AuditObject(trail, tableInfo.DBTableName);                
            }
            return isSuccess;
        }

        /// <summary>
        /// Marks deleted a record with the given array of identity fields that have identity values 
        /// and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="identityFields">An array of identity fields.</param>
        /// <param name="identityValues">An array of identity values.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        public override bool SoftDelete<TDomainObject>(string[] identityFields, object[] identityValues)
        {
            ValidateParameters(identityFields, identityValues);

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            if (tableInfo.SoftDeletable)
            {
                SqlSoftDeleteQueryBuilder queryBuilder = new SqlSoftDeleteQueryBuilder(tableInfo.DBTableName);

                queryBuilder.SetRecordStatusField(tableInfo.RecordStatusField);
                for (int i = 0; i < identityFields.Length; i++)
                {
                    queryBuilder.AddIdentity(identityFields[i], identityValues[i]);
                }

                DbCommand deleteCommand = CreateCommand(queryBuilder);

                int affectedCount = Db.ExecuteNonQuery(deleteCommand);
                bool isSuccess = affectedCount > 0;
                if (isSuccess)
                    AuditChange(identityFields, identityValues, tableInfo, CWXAuditAction.Delete);

                return isSuccess;
            }

            return false;
        }

        /// <summary>
        /// Marks deleted a record where its identity value is equal to the identity value of the given object
        /// and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        public override bool SoftDelete<TDomainObject>(TDomainObject domainObject)
        {
            //ValidateParameters<TDomainObject>(domainObject);
            if (domainObject == null)
                return false;

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            if (tableInfo.SoftDeletable)
            {
                SqlSoftDeleteQueryBuilder queryBuilder = new SqlSoftDeleteQueryBuilder(tableInfo.DBTableName);

                queryBuilder.SetRecordStatusField(tableInfo.RecordStatusField);
                foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
                {
                    PropertyInfo propertyInfo = typeof(TDomainObject).GetProperty(fieldInfo.ObjectFieldName);
                    object propertyValue = propertyInfo.GetValue(domainObject, null);
                    if (fieldInfo.IsPrimaryKey)
                    {
                        queryBuilder.AddIdentity(fieldInfo.DBFieldName, propertyValue);
                    }
                }

                DbCommand deleteCommand = CreateCommand(queryBuilder);

                int affectedCount = Db.ExecuteNonQuery(deleteCommand);
                bool isSuccess = affectedCount > 0;
                if (isSuccess)
                    CWXAuditManager.AuditObject(domainObject as IDomainObject, CWXAuditAction.Delete, tableInfo);

                return isSuccess;
            }

            return false;
        }

        /// <summary>
        /// Marks deleted a record with the given identityValue and returns true if deletes successfully, otherwise returns false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <typeparam name="TIdentity">The type of the given identityValue.</typeparam>
        /// <param name="identityValue">The value of identity.</param>
        /// <returns>Returns true if deletes successfully, otherwise returns false.</returns>
        public override bool SoftDelete<TDomainObject, TIdentity>(TIdentity identityValue)
        {
            if (identityValue == null)
                throw new ArgumentNullException("identityValue");

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            if (tableInfo.SoftDeletable)
            {
                SqlSoftDeleteQueryBuilder queryBuilder = new SqlSoftDeleteQueryBuilder(tableInfo.DBTableName);

                queryBuilder.SetRecordStatusField(tableInfo.RecordStatusField);

                bool isObjectHaveOneIdentity = false;
                string identityField = string.Empty;
                foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
                {
                    if (fieldInfo.IsPrimaryKey)
                    {
                        if (!isObjectHaveOneIdentity)
                        {
                            identityField = fieldInfo.DBFieldName;
                            queryBuilder.AddIdentity(fieldInfo.DBFieldName, identityValue);
                            isObjectHaveOneIdentity = true;
                        }
                        else
                        {
                            isObjectHaveOneIdentity = false;
                            break;
                        }
                    }
                }

                if (!isObjectHaveOneIdentity)
                    throw new Exception("This method's only used for object that has one identity.");

                DbCommand deleteCommand = CreateCommand(queryBuilder);

                int affectedCount = Db.ExecuteNonQuery(deleteCommand);
                bool isSuccess = affectedCount > 0;
                if (isSuccess)
                {
                    CWXIdentity identity = Thread.CurrentPrincipal.Identity as CWXIdentity;
                    int? employeeID = null;
                    if (identity != null)
                        employeeID = identity.UserID;

                    CWXAuditTrail trail = new CWXAuditTrail();
                    if (employeeID.HasValue)
                        trail.EmployeeID = employeeID.Value;
                    trail.ChangedTable = tableInfo.DBTableName;
                    trail.RowID = identityValue.ToString();
                    trail.ChangedField = identityField;
                    trail.ChangedData = Convert.ToString(identityValue);
                    trail.Action = CWXAuditAction.Delete;
                    CWXAuditManager.AddTrail(trail);
                }
                return isSuccess;
            }

            return false;
        }

        /// <summary>
        /// Updates a record where its identity value is equal to the identity value of the given object
        /// and return true if updates successfully, otherwise return false.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Return true if updates successfully, otherwise return false</returns>
        public override bool Update<TDomainObject>(TDomainObject domainObject)
        {
            ValidateParameters<TDomainObject>(domainObject);

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlUpdateQueryBuilder queryBuilder = new SqlUpdateQueryBuilder(tableInfo.DBTableName);

            foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
            {
                PropertyInfo propertyInfo = typeof(TDomainObject).GetProperty(fieldInfo.ObjectFieldName);
                object propertyValue = propertyInfo.GetValue(domainObject, null);

                IDataConverter converter = DataConverterFactory.Create(propertyInfo);
                object dataValue = converter.ConvertFrom(propertyValue, DbType.String, propertyInfo.PropertyType);

                if (fieldInfo.IsPrimaryKey)
                    queryBuilder.AddIdentity(fieldInfo.DBFieldName, dataValue);
                else if (!fieldInfo.ReadOnly)
                    queryBuilder.AddUpdateColumn(fieldInfo.DBFieldName, dataValue);
            }

            DbCommand updateCommand = CreateCommand(queryBuilder);

            int affectedCount = Db.ExecuteNonQuery(updateCommand);
            bool isSuccess = affectedCount > 0;
            if (isSuccess)
                CWXAuditManager.AuditObject(domainObject as IDomainObject, CWXAuditAction.Edit, tableInfo);

            return isSuccess;
        }

        /// <summary>
        /// Convert multiple rows in DataTable to objects and update all records to database which return true if updates successfully, 
        /// otherwise returns false
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of DataTable object.</param>
        /// <returns>Returns true if updates successfully, otherwise returns false.</returns>
        public override bool Update<TDomainObject>(DataTable dataTable)
        {
            int updatedCount = 0;
            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            FieldMappingInfo primaryFieldInfo = tableInfo.GetPrimaryFieldInfo();

            foreach (DataRow row in dataTable.Rows)
            {
                TDomainObject updateObject = Fill<TDomainObject>(new string[] { primaryFieldInfo.DBFieldName },
                                                                 new object[] { row[primaryFieldInfo.DBFieldName] });
                foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
                {
					if (fieldInfo.IsPrimaryKey) // ignore value of primary key
						continue;

                    DataColumn dataColumn = dataTable.Columns[fieldInfo.DBFieldName];
                    if (dataColumn != null)
                    {
                        PropertyInfo propertyInfo = updateObject.GetType().GetProperty(fieldInfo.ObjectFieldName);
                        IDataConverter converter = DataConverterFactory.Create(propertyInfo);
                        object dataValue = converter.ConvertFrom(row[dataColumn], DbType.String, propertyInfo.PropertyType);

                        if (dataValue == DBNull.Value)
                            dataValue = null;
                        propertyInfo.SetValue(updateObject, dataValue, null);
                    }
                }

                if (Update<TDomainObject>(updateObject))
                    updatedCount++;
            }

            return updatedCount == dataTable.Rows.Count;
        }

		/// <summary>
		/// Convert multiple rows in DataTable to objects and insert all records to database which return true if inserts successfully, 
		/// otherwise returns false
		/// </summary>
		/// <typeparam name="TDomainObject">The type of domain object.</typeparam>
		/// <param name="domainObject">An instant of DataTable object.</param>
		/// <returns>Returns true if inserts successfully, otherwise returns false.</returns>
		public override bool Insert<TDomainObject>(DataTable dataTable)
		{
			int insertCount = 0;
			TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
			FieldMappingInfo primaryFieldInfo = tableInfo.GetPrimaryFieldInfo();

			foreach (DataRow row in dataTable.Rows)
			{
				TDomainObject insertObject = new TDomainObject();// Fill<TDomainObject>(new string[] { primaryFieldInfo.DBFieldName },
																  //new object[] { row[primaryFieldInfo.DBFieldName] });
				foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
				{
					if (fieldInfo.IsPrimaryKey && fieldInfo.AutomatedIncrease) // ignore value of primary key
						continue;

					DataColumn dataColumn = dataTable.Columns[fieldInfo.DBFieldName];
					if (dataColumn != null)
					{
						PropertyInfo propertyInfo = insertObject.GetType().GetProperty(fieldInfo.ObjectFieldName);
						IDataConverter converter = DataConverterFactory.Create(propertyInfo);
						object dataValue = converter.ConvertFrom(row[dataColumn], DbType.String, propertyInfo.PropertyType);

						propertyInfo.SetValue(insertObject, dataValue, null);
					}
				}

                int newID;
                if (Insert<TDomainObject>(insertObject, out newID))
                {
                    row[tableInfo.GetPrimaryFieldInfo().DBFieldName] = newID;
                    insertCount++;
                }
			}

			return insertCount == dataTable.Rows.Count;
		}

        /// <summary>
        /// Selects a record with the given array of identity fields that have identity values
        /// and returns an object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="identityFields">An array of identity fields.</param>
        /// <param name="identityValues">An array of identity values.</param>
        /// <returns>Returns an object.</returns>
        /// <history>
        ///     2008/08/13  [Binh Truong]   Change RecordStatusField=Active to RecordStatusField!=Retired .
        /// </history>
        public override TDomainObject Fill<TDomainObject>(string[] identityFields, object[] identityValues)
        {
            ValidateParameters(identityFields, identityValues);

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlFillOneQueryBuilder queryBuilder = new SqlFillOneQueryBuilder(tableInfo.DBTableName);
            if (tableInfo.SoftDeletable)
                queryBuilder.AppendWhereClause(string.Format("{0} <> '{1}'", tableInfo.RecordStatusField, RecordStatusConstant.RETIRED)); //queryBuilder.AddIdentity(tableInfo.RecordStatusField, RecordStatusConstant.ACTIVE);

            for (int i = 0; i < identityFields.Length; i++)
                queryBuilder.AddIdentity(identityFields[i], identityValues[i]);

            TDomainObject returnObject = null;
            DbCommand selectCommand = CreateCommand(queryBuilder);
            using (IDataReader dataReader = Db.ExecuteReader(selectCommand))
                returnObject = FillFromReader<TDomainObject>(dataReader);

            return returnObject;
        }

        /// <summary>
        /// Selects a record with the given fill fields and the given array of identity fields that have identity values
        /// then returns an object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="identityFields">An array of identity fields.</param>
        /// <param name="identityValues">An array of identity values.</param>
        /// <param name="fillFields">An array of fill fields.</param>
        /// <returns>Returns an object.</returns>
        /// <history>
        ///     2008/08/13  [Binh Truong]   Change RecordStatusField=Active to RecordStatusField!=Retired .
        /// </history>
        public override TDomainObject Fill<TDomainObject>(string[] identityFields, object[] identityValues, string[] fillFields)
        {
            ValidateParameters(identityFields, identityValues, fillFields);

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlFillOneQueryBuilder queryBuilder = new SqlFillOneQueryBuilder(tableInfo.DBTableName);
            if (tableInfo.SoftDeletable)
                queryBuilder.AppendWhereClause(string.Format("{0} <> '{1}'", tableInfo.RecordStatusField, RecordStatusConstant.RETIRED)); 

            for (int i = 0; i < fillFields.Length; i++)
                queryBuilder.AddSelectColumn(fillFields[i]);

            for (int j = 0; j < identityFields.Length; j++)
                queryBuilder.AddIdentity(identityFields[j], identityValues[j]);

            DbCommand selectCommand = CreateCommand(queryBuilder);
            TDomainObject returnObject = null;
            using (IDataReader dataReader = Db.ExecuteReader(selectCommand))
                returnObject = FillFromReader<TDomainObject>(dataReader, fillFields);

            return returnObject;
        }

        /// <summary>
        /// Selects a record where its identity value is equal to the identity value of the given object
        /// and returns an object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="domainObject">An instant of domain object.</param>
        /// <returns>Returns an object.</returns>
        /// <history>
        ///     2008/08/13  [Binh Truong]   Change RecordStatusField=Active to RecordStatusField!=Retired .
        /// </history>
        public override TDomainObject Fill<TDomainObject>(TDomainObject domainObject)
        {
            ValidateParameters<TDomainObject>(domainObject);

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlFillOneQueryBuilder queryBuilder = new SqlFillOneQueryBuilder(tableInfo.DBTableName);
            if (tableInfo.SoftDeletable)
                queryBuilder.AppendWhereClause(string.Format("{0} <> '{1}'", tableInfo.RecordStatusField, RecordStatusConstant.RETIRED));

            foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
            {
                PropertyInfo propertyInfo = typeof(TDomainObject).GetProperty(fieldInfo.ObjectFieldName);
                object propertyValue = propertyInfo.GetValue(domainObject, null);
                if (propertyValue is Enum)
                    propertyValue = propertyValue.GetHashCode();
                if (fieldInfo.IsPrimaryKey)
                    queryBuilder.AddIdentity(fieldInfo.DBFieldName, propertyValue);
                if (!fieldInfo.ReadOnly)
                    queryBuilder.AddSelectColumn(fieldInfo.DBFieldName);
            }

            DbCommand selectCommand = CreateCommand(queryBuilder);

            TDomainObject returnObject = null;
            using (IDataReader dataReader = Db.ExecuteReader(selectCommand))
                returnObject = FillFromReader<TDomainObject>(dataReader);

            return returnObject;
        }

        /// <summary>
        /// Selects a record where its identity value is equal to the given identity value
        /// and returns an object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <typeparam name="TIdentity">The type of the given identityValue</typeparam>
        /// <param name="identityValue">Value of identity.</param>
        /// <returns>Returns an object.</returns>
        public override TDomainObject Fill<TDomainObject, TIdentity>(TIdentity identityValue)
        {
            if (identityValue == null)
                throw new ArgumentNullException("identityValue");

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlFillOneQueryBuilder queryBuilder = new SqlFillOneQueryBuilder(tableInfo.DBTableName);
            if (tableInfo.SoftDeletable)
                queryBuilder.AppendWhereClause(string.Format("{0} <> '{1}'", tableInfo.RecordStatusField, RecordStatusConstant.RETIRED));

            bool isObjectHaveOneIdentity = false;

            foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
            {
                if (fieldInfo.IsPrimaryKey)
                {
                    if (!isObjectHaveOneIdentity)
                    {
                        queryBuilder.AddIdentity(fieldInfo.DBFieldName, identityValue);
                        isObjectHaveOneIdentity = true;
                    }
                    else
                    {
                        isObjectHaveOneIdentity = false;
                        break;
                    }
                }
                if (!fieldInfo.ReadOnly)
                    queryBuilder.AddSelectColumn(fieldInfo.DBFieldName);
            }

            if (!isObjectHaveOneIdentity)
                throw new Exception("This method's only used for object that has one identity.");

            DbCommand selectCommand = CreateCommand(queryBuilder);

            TDomainObject returnObject = null;
            using (IDataReader dataReader = Db.ExecuteReader(selectCommand))
                returnObject = FillFromReader<TDomainObject>(dataReader);

            return returnObject;
        }

        /// <summary>
        /// Selects a record from the given reader and returns an object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="reader">System.Data.IDataReader.</param>
        /// <returns>Returns an object.</returns>
        public override TDomainObject FillFromReader<TDomainObject>(IDataReader reader)
        {
            if (reader == null)
                throw new ArgumentNullException("reader");

            TDomainObject domainObject = FillFromReaderWithoutClosingReader<TDomainObject>(reader);

            reader.Close();

            return domainObject;
        }

        /// <summary>
        /// Selects a record from the given reader with the given selected fields and returns an object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="reader">System.Data.IDataReader.</param>
        /// <param name="selectedFields">An array of the selected fields.</param>
        /// <returns>Returns an object.</returns>
        public override TDomainObject FillFromReader<TDomainObject>(IDataReader reader, string[] selectedFields)
        {
            if (reader == null)
                throw new ArgumentNullException("reader");
            if (selectedFields == null)
                throw new ArgumentNullException("selectedFields");
            if (selectedFields.Length == 0)
                throw new ArgumentException("SelectedFields must have at least one field.", "selectedFields");

            TDomainObject domainObject = FillFromReaderWithoutClosingReader<TDomainObject>(reader, selectedFields);

            reader.Close();

            return domainObject;
        }

        /// <summary>
        /// Selects a record from the given reader then processes the result before returning a final object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="reader">System.Data.IDataReader.</param>
        /// <param name="postProcess">Name of an delegate.</param>
        /// <returns>Returns an object.</returns>
        public override TDomainObject FillFromReader<TDomainObject>(IDataReader reader, ProcessReader<TDomainObject> postProcess)
        {
            if (reader == null)
                throw new ArgumentNullException("reader");
            if (postProcess == null)
                throw new ArgumentNullException("postProcess");

            TDomainObject domainObject = FillFromReaderWithoutClosingReader<TDomainObject>(reader);
            postProcess(reader, ref domainObject);

            reader.Close();

            return domainObject;
        }

        /// <summary>
        /// Selects a record from the given reader with the given selected fields then processes the result before returning a final object.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="reader">System.Data.IDataReader.</param>
        /// <param name="selectedFields">An array of selected fields.</param>
        /// <param name="postProcess">Name of an delegate.</param>
        /// <returns>Returns an ojbects.</returns>
        public override TDomainObject FillFromReader<TDomainObject>(IDataReader reader, string[] selectedFields, ProcessReader<TDomainObject> postProcess)
        {
            if (reader == null)
                throw new ArgumentNullException("reader");
            if (selectedFields == null)
                throw new ArgumentNullException("selectedFields");
            if (selectedFields.Length == 0)
                throw new ArgumentException("SelectedFields must have at least one field.", "selectedFields");
            if (postProcess == null)
                throw new ArgumentNullException("postProcess");

            TDomainObject domainObject = FillFromReaderWithoutClosingReader<TDomainObject>(reader, selectedFields);
            postProcess(reader, ref domainObject);

            reader.Close();

            return domainObject;
        }

        /// <summary>
        /// Selects record(s) then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <returns>Returns a collection of objects.</returns>
        public override Collection<TDomainObject> FillList<TDomainObject>()
        {
            return FillList<TDomainObject>(string.Empty, string.Empty);
        }

        /// <summary>
        /// Selects record(s) with the given oderByClause then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="orderByClause">Expression of orderByClause including order direction. Ex: "[FieldName] ASC" or "[FieldName] DESC".</param>
        /// <returns>Returns a collection of objects.</returns>
        public override Collection<TDomainObject> FillList<TDomainObject>(string orderByClause)
        {
            return FillList<TDomainObject>(orderByClause, string.Empty);
        }

        /// <summary>
        /// Selects record(s) with the given whereClause and oderByClause then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="orderByClause">Expression of orderByClause including order direction. Ex: "[FieldName] ASC" or "[FieldName] DESC".</param>
        /// <param name="whereClause">Expression of whereClause. Ex: "[FieldName] = value" or "[FieldName] like '%value%'".</param>
        /// <returns>Returns a collection of objects.</returns>
        public override Collection<TDomainObject> FillList<TDomainObject>(string orderByClause, string whereClause)
        {
            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlFillListQueryBuilder queryBuilder = new SqlFillListQueryBuilder(tableInfo.DBTableName);
            if (tableInfo.SoftDeletable)
            {
                if (string.IsNullOrEmpty(whereClause))
                    whereClause = string.Format("{0} <> '{1}'", tableInfo.RecordStatusField, RecordStatusConstant.RETIRED);
                else
                    whereClause += string.Format(" AND {0} <> '{1}'", tableInfo.RecordStatusField, RecordStatusConstant.RETIRED);
            }

            if (!string.IsNullOrEmpty(orderByClause))
                queryBuilder.AppendOrderByClause(orderByClause);

            if (!string.IsNullOrEmpty(whereClause))
                queryBuilder.AppendWhereClause(whereClause);

            Collection<TDomainObject> fillList = new Collection<TDomainObject>();
            DbCommand selectCommand = CreateCommand(queryBuilder);
            using (IDataReader dataReader = Db.ExecuteReader(selectCommand))
            {
                while (dataReader.Read())
                {
                    TDomainObject domainObject = ParseObject<TDomainObject>(dataReader, tableInfo);
                    fillList.Add(domainObject);
                }
            }
            return fillList;
        }

        /// <summary>
        /// Selects record(s) with the given storeprocedure then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="orderByClause">storeprocedure name.</param>
        /// <returns>Returns a collection of objects.</returns>
        public override Collection<TDomainObject> FillListByStoreProcedure<TDomainObject>(string storeProcedure)
        {
            return FillListByStoreProcedure<TDomainObject>(storeProcedure, null, null);
        }

        /// <summary>
        /// Selects record(s) with the given storeprocedure, parameterNames and parameterValues then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject"></typeparam>
        /// <param name="storeProcedure">storeprocedure name</param>
        /// <param name="parameterNames">parameter names</param>
        /// <param name="parameterValues">parameter values</param>
        /// <returns>Returns a collection of objects.</returns>
        public override Collection<TDomainObject> FillListByStoreProcedure<TDomainObject>(string storeProcedure, string[] parameterNames, object[] parameterValues)
        {
            if (String.IsNullOrEmpty(storeProcedure))
                throw new ArgumentNullException("storeProcedure");
            
            SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder(storeProcedure);

            if (parameterNames != null && parameterValues != null && parameterNames.Length == parameterValues.Length)
            {
                for (int i = 0; i < parameterNames.Length; i++)
                    queryBuilder.AddParameter(parameterNames[i], parameterValues[i]);
            }

            Collection<TDomainObject> fillList = new Collection<TDomainObject>();
            DbCommand cmd = CreateCommand(queryBuilder);
            using (IDataReader dataReader = Db.ExecuteReader(cmd))
            {
                TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
                while (dataReader.Read())
                {
                    TDomainObject domainObject = ParseObject<TDomainObject>(dataReader, tableInfo);
                    fillList.Add(domainObject);
                }
            }

            return fillList;
        }

        /// <summary>
        /// Selects record(s) with the given pageSize, pageIndex, orderByColumnName and orderDirection then returns an collection of objects
        /// and supplies the number of found records through output param rowCount.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="orderByColumnName">The name of the column that is used to order found records.</param>
        /// <param name="orderDirection">Type of orderDirection</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        public override Collection<TDomainObject> FillPagingList<TDomainObject>(int pageSize, int pageIndex, string orderByColumnName, OrderByDirection orderDirection, out int rowCount)
        {
            if (String.IsNullOrEmpty(orderByColumnName))
                throw new ArgumentNullException("orderByColumnName");

            string rowCountParameterName = FormatParameterName("RowCount");

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlFillListQueryBuilder queryBuilder = new SqlFillListQueryBuilder(tableInfo.DBTableName, this);
            if (tableInfo.SoftDeletable)
                queryBuilder.AppendWhereClause(string.Format("{0} <> '{1}'", tableInfo.RecordStatusField, RecordStatusConstant.RETIRED));

            queryBuilder.AddOrderBy(orderByColumnName, orderDirection);
            queryBuilder.RowCountParameterName = rowCountParameterName;
            queryBuilder.PageIndex = pageIndex;
            queryBuilder.PageSize = pageSize;

            Collection<TDomainObject> fillList = new Collection<TDomainObject>();

            DbCommand selectCommand = queryBuilder.BuildCommand();
            using (IDataReader dataReader = Db.ExecuteReader(selectCommand))
            {
                while (dataReader.Read())
                {
                    TDomainObject domainObject = ParseObject<TDomainObject>(dataReader, tableInfo);
                    fillList.Add(domainObject);
                }
                dataReader.Close();
                rowCount = int.Parse(selectCommand.Parameters[rowCountParameterName].Value.ToString());
            }
            return fillList;
        }

        /// <summary>
        /// Selects record(s) with the given pageSize, pageIndex, orderByColumnName and orderDirection then returns an collection of objects
        /// and supplies the number of found records through output param rowCount.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="orderByClause">Expression of orderByClause including order direction. Ex: "[FieldName] ASC" or "[FieldName] DESC".</param>
        /// <param name="whereClause">Expression of whereClause. Ex: "[FieldName] = value" or "[FieldName] like '%value%'".</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        public override Collection<TDomainObject> FillPagingList<TDomainObject>(int pageSize, int pageIndex, string orderByClause, string whereClause, out int rowCount)
        {
            string rowCountParameterName = FormatParameterName("RowCount");

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlFillListQueryBuilder queryBuilder = new SqlFillListQueryBuilder(tableInfo.DBTableName, this);
            if (tableInfo.SoftDeletable)
            {
                if (string.IsNullOrEmpty(whereClause))
                    whereClause = string.Format("{0} <> '{1}'", tableInfo.RecordStatusField, RecordStatusConstant.RETIRED);
                else
                    whereClause += string.Format(" AND {0} <> '{1}'", tableInfo.RecordStatusField, RecordStatusConstant.RETIRED);
            }

            queryBuilder.AppendOrderByClause(orderByClause);
            queryBuilder.AppendWhereClause(whereClause);
            queryBuilder.RowCountParameterName = rowCountParameterName;
            queryBuilder.PageIndex = pageIndex;
            queryBuilder.PageSize = pageSize;

            Collection<TDomainObject> fillList = new Collection<TDomainObject>();

            DbCommand selectCommand = queryBuilder.BuildCommand();
            using (IDataReader dataReader = Db.ExecuteReader(selectCommand))
            {
                while (dataReader.Read())
                {
                    TDomainObject domainObject = ParseObject<TDomainObject>(dataReader, tableInfo);
                    fillList.Add(domainObject);
                }
                dataReader.Close();
                rowCount = int.Parse(selectCommand.Parameters[rowCountParameterName].Value.ToString());
            }
            return fillList;
        }

        /// <summary>
        /// Selects record(s) with the given storeprocedure then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="storeProcedure">storeprocedure name.</param>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        public override Collection<TDomainObject> FillPagingList<TDomainObject>(string storeProcedure, int pageSize, int pageIndex, out int rowCount)
        {
            return FillPagingList<TDomainObject>(storeProcedure, null, null, pageSize, pageIndex, out rowCount);
        }

        /// <summary>
        /// Selects record(s) with the given storeprocedure, parameterNames and parameterValues then returns an collection of objects.
        /// </summary>
        /// <typeparam name="TDomainObject"></typeparam>
        /// <param name="storeProcedure">storeprocedure name</param>
        /// <param name="parameterNames">parameter names</param>
        /// <param name="parameterValues">parameter values</param>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        public override Collection<TDomainObject> FillPagingList<TDomainObject>(string storeProcedure, string[] parameterNames, object[] parameterValues, int pageSize, int pageIndex, out int rowCount)
        {
            if (String.IsNullOrEmpty(storeProcedure))
                throw new ArgumentNullException("storeProcedure");

            SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder(storeProcedure);
            if (parameterNames != null && parameterValues != null && parameterNames.Length == parameterValues.Length)
            {
                for (int i = 0; i < parameterNames.Length; i++)
                    queryBuilder.AddParameter(parameterNames[i], parameterValues[i]);
            }
            queryBuilder.AddParameter("PageSize", pageSize);
            queryBuilder.AddParameter("PageIndex", pageIndex);
            queryBuilder.AppendReturnParameter("RowCount");
            
            Collection<TDomainObject> fillList = new Collection<TDomainObject>();
            DbCommand cmd = CreateCommand(queryBuilder);
            using (IDataReader dataReader = Db.ExecuteReader(cmd))
            {
                TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
                while (dataReader.Read())
                {
                    TDomainObject domainObject = ParseObject<TDomainObject>(dataReader, tableInfo);
                    fillList.Add(domainObject);
                }
            }
            rowCount = int.Parse(cmd.Parameters["@RowCount"].Value.ToString());

            return fillList;
        }

        /// <summary>
        /// Selects record(s) with the given pageSize, pageIndex, orderByColumnName and orderDirection then returns an collection of objects
        /// and supplies the number of found records through output param rowCount.
        /// </summary>
        /// <typeparam name="TDomainObject">The type of domain object.</typeparam>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="orderByColumnName">The name of the column that is used to order found records.</param>
        /// <param name="orderDirection">Type of orderDirection</param>
        /// <param name="whereClause">Expression of whereClause. Ex: "[FieldName] = value" or "[FieldName] like '%value%'".</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>Returns a collection of objects.</returns>
        public override Collection<TDomainObject> FillPagingList<TDomainObject>(int pageSize, int pageIndex, string orderByColumnName, OrderByDirection orderDirection, string whereClause, out int rowCount)
        {
            if (String.IsNullOrEmpty(orderByColumnName))
                throw new ArgumentNullException("orderByColumnName");

            string rowCountParameterName = FormatParameterName("RowCount");

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlFillListQueryBuilder queryBuilder = new SqlFillListQueryBuilder(tableInfo.DBTableName, this);
            if (tableInfo.SoftDeletable)
            {
                if (string.IsNullOrEmpty(whereClause))
                    whereClause = string.Format("{0} <> '{1}'", tableInfo.RecordStatusField, RecordStatusConstant.RETIRED);
                else
                    whereClause += string.Format(" AND {0} <> '{1}'", tableInfo.RecordStatusField, RecordStatusConstant.RETIRED);
            }

            queryBuilder.AddOrderBy(orderByColumnName, orderDirection);
            queryBuilder.AppendWhereClause(whereClause);
            queryBuilder.RowCountParameterName = rowCountParameterName;
            queryBuilder.PageIndex = pageIndex;
            queryBuilder.PageSize = pageSize;

            Collection<TDomainObject> fillList = new Collection<TDomainObject>();

            DbCommand selectCommand = queryBuilder.BuildCommand();
            using (IDataReader dataReader = Db.ExecuteReader(selectCommand))
            {
                while (dataReader.Read())
                {
                    TDomainObject domainObject = ParseObject<TDomainObject>(dataReader, tableInfo);
                    fillList.Add(domainObject);
                }
                dataReader.Close();
                rowCount = int.Parse(selectCommand.Parameters[rowCountParameterName].Value.ToString());
            }
            return fillList;
        }

        /// <summary>
        /// Get the max identity of the TDomainObject from the datasource.
        /// </summary>
        /// <returns>The max identity of the TDomainObject.</returns>
        public override int GetMaxIdentity<TDomainObject>()
        {
            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(tableInfo.DBTableName, this);

            bool isObjectHaveOneIdentity = false;

            foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
            {
                if (fieldInfo.IsPrimaryKey && (fieldInfo.DBType == "int" || fieldInfo.DBType == "smallint" || fieldInfo.DBType == "bigint"))
                {
                    if (!isObjectHaveOneIdentity)
                    {
                        querryBuilder.AddSelectColumn(string.Format("MAX({0}) AS NewID", fieldInfo.DBFieldName));
                        isObjectHaveOneIdentity = true;
                    }
                    else
                    {
                        isObjectHaveOneIdentity = false;
                        break;
                    }
                }
            }

            if (!isObjectHaveOneIdentity)
                throw new Exception("This method's only used for object that has one identity.");

            DbCommand cmd = querryBuilder.BuildCommand();
            using (IDataReader dataReader = Db.ExecuteReader(cmd))
            {
                if (dataReader != null && dataReader.Read())
                {
                    int maxID = 0;
                    string stringMaxID = !dataReader.IsDBNull(dataReader.GetOrdinal("NewID")) ? dataReader.GetValue(dataReader.GetOrdinal("NewID")).ToString() : "0";
                    int.TryParse(stringMaxID, out maxID);
                    return maxID;
                }
            }
            return 0;
        }

        /// <summary>
        /// Get the max identity of the TDomainObject from the datasource.
        /// </summary>
        /// <returns>The max identity of the TDomainObject.</returns>
        public override int GetMaxIdentity<TDomainObject>(string identityFieldName)
        {
            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(tableInfo.DBTableName, this);
            querryBuilder.AddSelectColumn(string.Format("MAX(CAST({0} AS int)) AS NewID", identityFieldName));

            DbCommand cmd = querryBuilder.BuildCommand();
            using (IDataReader dataReader = Db.ExecuteReader(cmd))
            {
                if (dataReader != null && dataReader.Read())
                {
                    int maxID = 0;
                    string stringMaxID = !dataReader.IsDBNull(dataReader.GetOrdinal("NewID")) ? dataReader.GetValue(dataReader.GetOrdinal("NewID")).ToString() : "0";
                    int.TryParse(stringMaxID, out maxID);
                    return maxID;
                }
            }
            return 0;
        }

        /// <summary>
        /// Get the max identity of the TDomainObject from the datasource.
        /// </summary>
        /// <returns>The max identity of the TDomainObject.</returns>
        public override int GetMaxIdentity<TDomainObject>(string identityFieldName, string whereClause)
        {
            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            SqlFillOneQueryBuilder querryBuilder = new SqlFillOneQueryBuilder(tableInfo.DBTableName, this);
            querryBuilder.AddSelectColumn(string.Format("MAX(CAST({0} AS int)) AS NewID", identityFieldName));
            querryBuilder.AppendWhereClause(whereClause);

            DbCommand cmd = querryBuilder.BuildCommand();
            using (IDataReader dataReader = Db.ExecuteReader(cmd))
            {
                if (dataReader != null && dataReader.Read())
                {
                    int maxID = 0;
                    string stringMaxID = !dataReader.IsDBNull(dataReader.GetOrdinal("NewID")) ? dataReader.GetValue(dataReader.GetOrdinal("NewID")).ToString() : "0";
                    int.TryParse(stringMaxID, out maxID);
                    return maxID;
                }
            }
            return 0;
        }


        #endregion

        #region Common Data Manipulation Methods

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType and
        ///     returns the number of rows affected.
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <returns>The number of rows affected.</returns>
        public override int ExecuteNonQuery(string cmdText, CommandType cmdType)
        {
            return Db.ExecuteNonQuery(cmdType, cmdText);
        }

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType as part
        ///     of the given transaction and returns the number of rows affected. 
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>The number of rows affected.</returns>
        public override int ExecuteNonQuery(string cmdText, CommandType cmdType, DbTransaction transaction)
        {
            return Db.ExecuteNonQuery(transaction, cmdType, cmdText);
        }

        /// <summary>
        ///     Executes the command and returns the number of rows affected.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <returns>The number of rows affected.</returns>
        public override int ExecuteNonQuery(DbCommand command)
        {
            return Db.ExecuteNonQuery(command);
        }

        /// <summary>
        ///     Executes the command within the given transaction, and returns the number
        ///     of rows affected.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>The number of rows affected.</returns>
        public override int ExecuteNonQuery(DbCommand command, DbTransaction transaction)
        {
            return Db.ExecuteNonQuery(command, transaction);
        }

        /// <summary>
        /// Excutes a store procedure with the give storedProcedureName, parameterNames, parameterValues.
        /// </summary>
        /// <param name="storedProcedureName">Name of the store procedure.</param>
        /// <param name="parameterNames">An array of param names.</param>
        /// <param name="paremeterValues">An array of param values.</param>
        /// <returns>The number of rows affected.</returns>
        public override int ExecuteNonQuery(string storedProcedureName, string[] parameterNames, object[] parameterValues)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
                throw new ArgumentException("StoreProcedureName cannot be empty.");

            ValidateParameters(parameterNames, parameterValues);

            SqlStoreProcedureQuerryBuilder querryBuilder = new SqlStoreProcedureQuerryBuilder(storedProcedureName);

            if (parameterNames != null && parameterValues != null && parameterNames.Length == parameterValues.Length)
            {
                for (int i = 0; i < parameterNames.Length; i++)
                    querryBuilder.AddParameter(parameterNames[i], parameterValues[i]);
            }

            DbCommand cmd = CreateCommand(querryBuilder);
            return Db.ExecuteNonQuery(cmd);
        }



        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="parameters">>Array of parameter</param>
        /// <returns>System.Int32</returns>
        public override int ExecuteNonQuery(string storedProcedureName, Dictionary<string, object> parameters)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
                throw new ArgumentException("StoreProcedureName cannot be empty.");

            SqlStoreProcedureQuerryBuilder querryBuilder = new SqlStoreProcedureQuerryBuilder(storedProcedureName);

            if ((parameters != null)) 
            {
                foreach (KeyValuePair<string, object> parameter in parameters) 
                {
                    if ((!string.IsNullOrEmpty(parameter.Key)) && (null != parameter.Value)) 
                    {
                        querryBuilder.AddParameter(parameter.Key, parameter.Value);     
                    }
                }
            
            }
            DbCommand cmd = CreateCommand(querryBuilder);
            return Db.ExecuteNonQuery(cmd);
        }



        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="returnedValue">System.Int32</param>
        /// <returns>The number of rows affected.</returns>
        public override int ExecuteNonQuery(string storedProcedureName, out int returnedValue)
        {
            return ExecuteNonQuery(storedProcedureName, null, null, out returnedValue);
        }

        /// <summary>
        /// Executes a store proceduce with the given storeProcedureName without parameters, then returns a value.
        /// </summary>
        /// <param name="storedProcedureName">Name of store procedure.</param>
        /// <param name="parameterNames">Array of parameter names.</param>
        /// <param name="parameterValues">Array of parameter values.</param>
        /// <param name="returnedValue">System.Int32</param>
        /// <returns></returns>
        public override int ExecuteNonQuery(string storedProcedureName, string[] parameterNames, object[] parameterValues, out int returnedValue)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
                throw new ArgumentException("StoreProcedureName cannot be empty.");

            SqlStoreProcedureQuerryBuilder querryBuilder = new SqlStoreProcedureQuerryBuilder(storedProcedureName);
            if (parameterNames != null && parameterValues != null & parameterNames.Length == parameterValues.Length)
            {
                for (int i = 0; i < parameterNames.Length; i++)
                    querryBuilder.AddParameter(parameterNames[i], parameterValues[i]);
            }
            querryBuilder.AppendReturnParameter("ReturnedValue");

            DbCommand cmd = CreateCommand(querryBuilder);
            int result = Db.ExecuteNonQuery(cmd);

            returnedValue = int.Parse(cmd.Parameters["@ReturnedValue"].Value.ToString());

            return result;
        }

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType and
        ///     returns an System.Data.IDataReader through which the result can be read.
        ///     It is the responsibility of the caller to close the connection and reader
        ///     when finished.
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <returns>An System.Data.IDataReader object.</returns>
        public override IDataReader ExecuteReader(string cmdText, CommandType cmdType)
        {
            return Db.ExecuteReader(cmdType, cmdText);
        }

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType as part
        ///     of the given transaction and returns the number of rows affected.
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns></returns>
        public override IDataReader ExecuteReader(string cmdText, CommandType cmdType, DbTransaction transaction)
        {
            return Db.ExecuteReader(transaction, cmdType, cmdText);
        }

        /// <summary>
        ///     Executes the storedProcedureName with the given parameterValues and returns
        ///     an System.Data.IDataReader through which the result can be read.  It is the
        ///     responsibility of the caller to close the connection and reader when finished.
        /// </summary>
        /// <param name="paramValues">An array of paramters to pass to the stored procedure. The parameter values
        ///    must be in call order as they appear in the stored procedure.</param>
        /// <param name="storedProcedureName">The name of the stored procedure to execute.</param>
        /// <returns>An System.Data.IDataReader object.</returns>
        public override IDataReader ExecuteReader(object[] paramValues, string storedProcedureName)
        {
            return Db.ExecuteReader(storedProcedureName, paramValues);
        }

        /// <summary>
        ///     Executes the storedProcedureName with the given parameterValues within the
        ///     given transaction and returns an System.Data.IDataReader through which the
        ///     result can be read.  It is the responsibility of the caller to close the
        ///     connection and reader when finished.
        /// </summary>
        /// <param name="paramValues">An array of paramters to pass to the stored procedure. The parameter values
        ///     must be in call order as they appear in the stored procedure.</param>
        /// <param name="storedProcedureName">The command that contains the query to execute.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>An System.Data.IDataReader object.</returns>
        public override IDataReader ExecuteReader(object[] paramValues, string storedProcedureName, DbTransaction transaction)
        {
            return Db.ExecuteReader(transaction, storedProcedureName, paramValues);
        }

        /// <summary>
        ///     Executes the command and returns an System.Data.IDataReader through which
        ///     the result can be read.  It is the responsibility of the caller to close
        ///     the connection and reader when finished.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <returns>An System.Data.IDataReader object.</returns>
        public override IDataReader ExecuteReader(DbCommand command)
        {
            return Db.ExecuteReader(command);
        }

        /// <summary>
        ///     Executes the command within a transaction and returns an System.Data.IDataReader
        ///     through which the result can be read.  It is the responsibility of the caller
        ///     to close the connection and reader when finished.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>An System.Data.IDataReader object.</returns>
        public override IDataReader ExecuteReader(DbCommand command, DbTransaction transaction)
        {
            return Db.ExecuteReader(command, transaction);
        }

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType and
        ///     returns the first column of the first row in the result set returned by the
        ///    query. Extra columns or rows are ignored.
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <returns>The first column of the first row in the result set.</returns>
        public override object ExecuteScalar(string cmdText, CommandType cmdType)
        {
            return Db.ExecuteScalar(cmdType, cmdText);
        }

        /// <summary>
        ///     Executes the commandText interpreted as specified by the commandType within
        ///     the given transaction and returns the first column of the first row in the
        ///     result set returned by the query. Extra columns or rows are ignored.
        /// </summary>
        /// <param name="cmdText">The command text to execute.</param>
        /// <param name="cmdType">One of the System.Data.CommandType values.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>The first column of the first row in the result set.</returns>
        public override object ExecuteScalar(string cmdText, CommandType cmdType, DbTransaction transaction)
        {
            return Db.ExecuteScalar(transaction, cmdType, cmdText);
        }

        /// <summary>
        ///     Executes the storedProcedureName with the given parameterValues and returns
        ///     the first column of the first row in the result set returned by the query.
        ///     Extra columns or rows are ignored.
        /// </summary>
        /// <param name="paramValues">An array of paramters to pass to the stored procedure. The parameter values
        ///     must be in call order as they appear in the stored procedure.</param>
        /// <param name="storedProcedureName">The stored procedure to execute.</param>
        /// <returns>The first column of the first row in the result set.</returns>
        public override object ExecuteScalar(object[] paramValues, string storedProcedureName)
        {
            return Db.ExecuteScalar(storedProcedureName, paramValues);
        }

        /// <summary>
        ///     Executes the storedProcedureName with the given parameterValues within a
        ///     transaction and returns the first column of the first row in the result set
        ///     returned by the query. Extra columns or rows are ignored.
        /// </summary>
        /// <param name="paramValues">An array of paramters to pass to the stored procedure. The parameter values
        ///     must be in call order as they appear in the stored procedure.</param>
        /// <param name="storedProcedureName">The stored procedure to execute.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns></returns>
        public override object ExecuteScalar(object[] paramValues, string storedProcedureName, DbTransaction transaction)
        {
            return Db.ExecuteScalar(transaction, storedProcedureName, paramValues);
        }

        /// <summary>
        ///     Executes the command and returns the first column of the first row in the
        ///     result set returned by the query. Extra columns or rows are ignored.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <returns>The first column of the first row in the result set.</returns>
        public override object ExecuteScalar(DbCommand command)
        {
            return Db.ExecuteScalar(command);
        }

        /// <summary>
        ///     Executes the command within a transaction, and returns the first column of
        ///     the first row in the result set returned by the query. Extra columns or rows
        ///     are ignored.
        /// </summary>
        /// <param name="command">The command that contains the query to execute.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>The first column of the first row in the result set.</returns>
        public override object ExecuteScalar(DbCommand command, DbTransaction transaction)
        {
            return Db.ExecuteScalar(command, transaction);
        }

        /// <summary>
        /// Executes the command and returns the results in a new System.Data.DataSet.
        /// </summary>
        /// <param name="command">The System.Data.Common.DbCommand to execute.</param>
        /// <returns>A System.Data.DataSet with the results of the command.</returns>
        public override DataSet ExecuteDataSet(DbCommand command)
        {
            return Db.ExecuteDataSet(command);
        }

        /// <summary>
        /// Executes the commandText interpreted as specified by the commandType and
        ///  returns the results in a new System.Data.DataSet.
        /// </summary>
        /// <param name="commandType">One of the System.Data.CommandType values.</param>
        /// <param name="commandText">The command text to execute.</param>
        /// <returns>A System.Data.DataSet with the results of the commandText.</returns>
        public override DataSet ExecuteDataSet(CommandType commandType, string commandText)
        {
            return Db.ExecuteDataSet(commandType, commandText);
        }

        /// <summary>
        /// Executes the command as part of the transaction and returns the results in
        ///  a new System.Data.DataSet.
        /// </summary>
        /// <param name="command">The System.Data.Common.DbCommand to execute.</param>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <returns>A System.Data.DataSet with the results of the command.</returns>
        public override DataSet ExecuteDataSet(DbCommand command, DbTransaction transaction)
        {
            return Db.ExecuteDataSet(command, transaction);
        }

        /// <summary>
        /// Executes the storedProcedureName with parameterValues and returns the results
        ///  in a new System.Data.DataSet.
        /// </summary>
        /// <param name="storedProcedureName">The stored procedure to execute.</param>
        /// <returns>A System.Data.DataSet with the results of the storedProcedureName.</returns>
        public override DataSet ExecuteDataSet(string storedProcedureName)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
                throw new ArgumentException("StoreProcedureName cannot be empty.");

            SqlStoreProcedureQuerryBuilder querryBuilder = new SqlStoreProcedureQuerryBuilder(storedProcedureName);

            DbCommand cmd = CreateCommand(querryBuilder);
            return Db.ExecuteDataSet(cmd);
        }

        /// <summary>
        /// Executes the storedProcedureName with parameterValues and returns the results
        ///  in a new System.Data.DataSet.
        /// </summary>
        /// <param name="storedProcedureName">The stored procedure to execute.</param>
        /// <param name="parameterValues">An array of parameters to pass to the stored procedure. The parameter values must be in call order as they appear in the stored procedure.</param>
        /// <returns>A System.Data.DataSet with the results of the storedProcedureName.</returns>
        public override DataSet ExecuteDataSet(string storedProcedureName, params object[] parameterValues)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
                throw new ArgumentException("StoreProcedureName cannot be empty.");

            return Db.ExecuteDataSet(storedProcedureName, parameterValues);
        }

        /// <summary>
        /// Executes the commandText as part of the given transaction and returns the
        ///  results in a new System.Data.DataSet.
        /// </summary>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <param name="commandType">One of the System.Data.CommandType values.</param>
        /// <param name="commandText">The command text to execute.</param>
        /// <returns>A System.Data.DataSet with the results of the commandText.</returns>
        public override DataSet ExecuteDataSet(DbTransaction transaction, CommandType commandType, string commandText)
        {
            return Db.ExecuteDataSet(transaction, commandType, commandText);
        }

        /// <summary>
        /// Executes the storedProcedureName with parameterValues as part of the transaction
        ///  and returns the results in a new System.Data.DataSet within a transaction.
        /// </summary>
        /// <param name="transaction">The System.Data.IDbTransaction to execute the command within.</param>
        /// <param name="storedProcedureName">The stored procedure to execute.</param>
        /// <param name="parameterValues">An array of paramters to pass to the stored procedure. The parameter values must be in call order as they appear in the stored procedure.</param>
        /// <returns>A System.Data.DataSet with the results of the storedProcedureName.</returns>
        public override DataSet ExecuteDataSet(DbTransaction transaction, string storedProcedureName, params object[] parameterValues)
        {
            return Db.ExecuteDataSet(transaction, storedProcedureName, parameterValues);
        }

        /// <summary>
        /// Excutes a store procedure with the give storedProcedureName, parameterNames, parameterValues
        /// and returns a System.Data.DataSet as the result.
        /// </summary>
        /// <param name="storedProcedureName">Name of the store procedure.</param>
        /// <param name="parameterNames">An array of param names.</param>
        /// <param name="paremeterValues">An array of param values.</param>
        /// <returns>System.Data.DataSet</returns>
        public override DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] parameterValues)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
                throw new ArgumentException("StoreProcedureName cannot be empty.");

            ValidateParameters(parameterNames, parameterValues);

            SqlStoreProcedureQuerryBuilder querryBuilder = new SqlStoreProcedureQuerryBuilder(storedProcedureName);
            for (int i = 0; i < parameterNames.Length; i++)
                querryBuilder.AddParameter(parameterNames[i], parameterValues[i]);

            DbCommand cmd = CreateCommand(querryBuilder);
            return Db.ExecuteDataSet(cmd);
        }

        /// <summary>
        /// Excutes a store procedure with the give storedProcedureName
        /// and returns a System.Data.DataSet as the result.
        /// </summary>
        /// <param name="storedProcedureName">Name of the store procedure.</param>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>System.Data.DataSet</returns>
        public override DataSet ExecuteDataSet(string storedProcedureName, int pageSize, int pageIndex, out int rowCount)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
                throw new ArgumentException("StoreProcedureName cannot be empty.");


            SqlStoreProcedureQuerryBuilder querryBuilder = new SqlStoreProcedureQuerryBuilder(storedProcedureName);
            querryBuilder.AddParameter("PageSize", pageSize);
            querryBuilder.AddParameter("PageIndex", pageIndex);
            querryBuilder.AppendReturnParameter("RowCount");

            DbCommand cmd = CreateCommand(querryBuilder);
            DataSet resultDataSet = Db.ExecuteDataSet(cmd);

            rowCount = int.Parse(cmd.Parameters["@RowCount"].Value.ToString());

            return resultDataSet;
        }

        /// <summary>
        /// Excutes a store procedure with the give storedProcedureName, parameterNames, parameterValues
        /// and returns a System.Data.DataSet as the result.
        /// </summary>
        /// <param name="storedProcedureName">Name of the store procedure.</param>
        /// <param name="parameterNames">An array of param names.</param>
        /// <param name="paremeterValues">An array of param values.</param>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>System.Data.DataSet</returns>
        public override DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues, int pageSize, int pageIndex, out int rowCount)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
                throw new ArgumentException("StoreProcedureName cannot be empty.");

            ValidateParameters(parameterNames, paremeterValues);

            SqlStoreProcedureQuerryBuilder querryBuilder = new SqlStoreProcedureQuerryBuilder(storedProcedureName);
            for (int i = 0; i < parameterNames.Length; i++)
                querryBuilder.AddParameter(parameterNames[i], paremeterValues[i]);
            querryBuilder.AddParameter("PageSize", pageSize);
            querryBuilder.AddParameter("PageIndex", pageIndex);
            querryBuilder.AppendReturnParameter("RowCount");

            DbCommand cmd = CreateCommand(querryBuilder);
            DataSet resultDataSet = Db.ExecuteDataSet(cmd);

            rowCount = int.Parse(cmd.Parameters["@RowCount"].Value.ToString());

            return resultDataSet;
        }

        /// <summary>
        /// Excutes a store procedure with the give storedProcedureName, parameterNames, parameterValues
        /// and returns a System.Data.DataSet as the result.
        /// </summary>
        /// <param name="storedProcedureName">Name of the store procedure.</param>
        /// <param name="parameterNames">An array of param names.</param>
        /// <param name="paremeterValues">An array of param values.</param>
        /// <param name="orderByClause">
        /// Order by clause to sort the list. This parametter is required.
        /// Ex: "EmployeeName DESC, Salary ASC"
        /// </param>
        /// <param name="pageSize">The quanlity of records on one page.</param>
        /// <param name="pageIndex">The index of page.</param>
        /// <param name="rowCount">Output param that supplies the number of found records.</param>
        /// <returns>System.Data.DataSet</returns>
        public override DataSet ExecuteDataSet(string storedProcedureName, string[] parameterNames, object[] paremeterValues, string orderByClause, int pageSize, int pageIndex, out int rowCount)
        {
            if (string.IsNullOrEmpty(storedProcedureName))
                throw new ArgumentException("StoreProcedureName cannot be empty.");

            ValidateParameters(parameterNames, paremeterValues);

            SqlStoreProcedureQuerryBuilder querryBuilder = new SqlStoreProcedureQuerryBuilder(storedProcedureName);
            for (int i = 0; i < parameterNames.Length; i++)
                querryBuilder.AddParameter(parameterNames[i], paremeterValues[i]);
            querryBuilder.AddParameter("OrderByClause", orderByClause);
            querryBuilder.AddParameter("PageSize", pageSize);
            querryBuilder.AddParameter("PageIndex", pageIndex);
            querryBuilder.AppendReturnParameter("RowCount");

            DbCommand cmd = CreateCommand(querryBuilder);
            DataSet resultDataSet = Db.ExecuteDataSet(cmd);

            rowCount = int.Parse(cmd.Parameters["@RowCount"].Value.ToString());

            return resultDataSet;
        }

        /// <summary>
        /// Create the DbConnection object in the database
        /// </summary>
        /// <returns></returns>
        public override DbConnection CreateConnection()
        {
            return Db.CreateConnection();
        }

        /// <summary>
        /// Create the DbCommand base on the QueryBuilderBase
        /// </summary>
        /// <param name="queryBuilder"></param>
        /// <returns></returns>
        public override DbCommand CreateCommand(QueryBuilderBase queryBuilder)
        {
            queryBuilder.DataProvider = this;
            return queryBuilder.BuildCommand();
        }

        public override DbCommand CreateCommand(CommandType commandType)
        {
            if (commandType == CommandType.TableDirect)
                throw new NotSupportedException("Not support CommandType.TableDirect kind");
            SqlCommand createdCommand = new SqlCommand();
            createdCommand.CommandType = commandType;

            return createdCommand;
        }

        /// <summary>
        /// Create an Generic DbCommand
        /// </summary>
        /// <param name="commandText"></param>
        /// <returns></returns>
        public override DbCommand CreateTextCommand(string commandText)
        {
            return Db.GetSqlStringCommand(commandText);
        }

        public override DbCommand CreateStoreProcedureCommand(string storeProcedureName)
        {
            return Db.GetStoredProcCommand(storeProcedureName);
        }

        public override string FormatParameterName(string parameterName)
        {
            string formattedName = parameterName.Trim();
            if (formattedName[0] != '@')
                formattedName = "@" + formattedName;
            return formattedName;
        }

        /// <summary>
        /// Create a DataAdapter object from the particular database.
        /// </summary>
        /// <param name="selectCommand"></param>
        /// <returns></returns>
        public override IDataAdapter CreateDataAdapter(DbCommand selectCommand)
        {
            return new SqlDataAdapter(selectCommand as SqlCommand);
        }
        #endregion

        #endregion

        #region Private Methods
        /// <summary>
        /// Finds an FieldMappingInfo which its dbFieldName exists in the given tableInfo and returns an instant of FieldMappingInfo
        /// </summary>
        /// <param name="dbFieldName">Field Name in DataBase</param>
        /// <param name="tableInfo">TableMappingInfo</param>
        /// <returns>An instant of FieldMappingInfo</returns>
        private FieldMappingInfo GetFieldMappingInfoByDBFieldName(string dbFieldName, TableMappingInfo tableInfo)
        {
            FieldMappingInfo returnedFieldInfo = null;
            foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
            {
                if (fieldInfo.DBFieldName == dbFieldName)
                {
                    returnedFieldInfo = fieldInfo;
                    break;
                }
            }
            return returnedFieldInfo;
        }

        /// <summary>
        /// Fills data from the given reader into an instant of TDomainObject which is returned.
        /// Note: this function does NOT close the given reader after filling data.
        /// </summary>
        /// <typeparam name="TDomainObject"></typeparam>
        /// <param name="reader">System.Data.IDataReader</param>
        /// <returns>Instant of type of TDomainObject</returns>
        private TDomainObject FillFromReaderWithoutClosingReader<TDomainObject>(IDataReader reader) where TDomainObject : class, new()
        {
            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));

            if (reader.Read())
                return ParseObject<TDomainObject>(reader, tableInfo);

            return null;
        }

        /// <summary>
        /// Fills the selected fields from the given reader into an instant of TDomainObject which is returned.
        /// Note: this function does NOT close the given reader after filling data.
        /// </summary>
        /// <typeparam name="TDomainObject"></typeparam>
        /// <param name="reader">System.Data.IDataReader</param>
        /// <param name="selectedFields">An array of selected fields</param>
        /// <returns>Instant of type of TDomainObject</returns>
        private TDomainObject FillFromReaderWithoutClosingReader<TDomainObject>(IDataReader reader, string[] selectedFields) where TDomainObject : class, new()
        {
            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));

            if (reader.Read())
                return ParseObject<TDomainObject>(reader, tableInfo, selectedFields);

            return null;
        }

        private void ValidateParameters<TDomainObject>(TDomainObject domainObject)
        {
            if (domainObject == null)
                throw new ArgumentNullException("domainObject");
        }

        private void ValidateParameters(string[] identityFields, object[] identityValues)
        {
            if (identityFields == null)
                throw new ArgumentNullException("identityFields");
            if (identityFields.Length == 0)
                throw new ArgumentException("IdentityFields must have at least one field.", "identityFields");
            if (identityValues == null)
                throw new ArgumentNullException("identityValues");
            if (identityValues.Length == 0)
                throw new ArgumentException("IdentityValues must have at least one value", "identityValues");
            if (identityFields.Length != identityValues.Length)
                throw new ArgumentException("IdentityFields's length must be equal to IdentityValues's length.");
        }

        private void ValidateParameters(string[] identityFields, object[] identityValues, string[] fillFields)
        {
            ValidateParameters(identityFields, identityValues);
            if (fillFields == null)
                throw new ArgumentNullException("fillFields");
            if (fillFields.Length == 0)
                throw new ArgumentException("FillFields must have at least one field.", "FillFields");
        }

        private void SetObjectPropertyValue<TDomainObject>(TDomainObject domainObject, string propertyName, object value)
        {
            PropertyInfo propertyInfo = typeof(TDomainObject).GetProperty(propertyName);
            IDataConverter converter = DataConverterFactory.Create(propertyInfo);
            value = converter.ConvertTo(value, DbType.String, propertyInfo.PropertyType);
            propertyInfo.SetValue(domainObject, value, null);
        }

        /// <summary>
        /// Audit data change.
        /// </summary>
        private void AuditChange(string[] identityFields, object[] identityValues, TableMappingInfo tableInfo, CWXAuditAction action)
        {
            FieldMappingInfo primaryFieldInfo = tableInfo.GetPrimaryFieldInfo();
            if (primaryFieldInfo == null)
                throw new InvalidOperationException("The primary key of Xml Mapping Object is missing.");

            string rowID = string.Empty;
            for (int i = 0; i < identityFields.Length; i++)
            {
                if (string.Compare(identityFields[i], primaryFieldInfo.ObjectFieldName, true) == 0)
                    rowID = identityValues[i].ToString();
            }

            CWXIdentity identity = Thread.CurrentPrincipal.Identity as CWXIdentity;
            int? employeeID = null;
            if (identity != null)
                employeeID = identity.UserID;

            CWXAuditTrail trail = new CWXAuditTrail();
            if (employeeID.HasValue)
                trail.EmployeeID = employeeID.Value;
            trail.Action = action;
            trail.ChangedTable = tableInfo.DBTableName;
            trail.RowID = rowID;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < identityFields.Length - 1; i++)
                sb.AppendFormat("{0} = {1} | ", identityFields[i], identityValues[i]);
            sb.AppendFormat("{0} = {1}", identityFields[identityFields.Length - 1], identityValues[identityFields.Length - 1]);
            trail.ChangedData = sb.ToString();
            CWXAuditManager.AddTrail(trail);
        }

        private int GetDBFieldOrdinal(IDataReader reader, string fieldName)
        {
            try
            {
                return reader.GetOrdinal(fieldName);
            }
            catch
            {
                return -1;
            }
        }

        private void SetValueToObjectProperty<TDomainObject>(IDataReader dataReader, TDomainObject domainObject, FieldMappingInfo fieldInfo)
        {
            int ordinal = GetDBFieldOrdinal(dataReader, fieldInfo.DBFieldName);

            if (ordinal >= 0)
            {
                object dataValue = dataReader.GetValue(ordinal);
                PropertyInfo propertyInfo = typeof(TDomainObject).GetProperty(fieldInfo.ObjectFieldName);
                IDataConverter converter = DataConverterFactory.Create(propertyInfo);
                object propertyValue = converter.ConvertTo(dataValue, DbType.String, propertyInfo.PropertyType);
                propertyInfo.SetValue(domainObject, propertyValue, null);
            }
        }

        private TDomainObject ParseObject<TDomainObject>(IDataReader dataReader, TableMappingInfo tableInfo)
            where TDomainObject : class, new()
        {
            TDomainObject domainObject = new TDomainObject();
            DomainObjectBase domainObjectBase = domainObject as DomainObjectBase;
            if (domainObjectBase != null)
                domainObjectBase.BeginLoading();

            foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
                SetValueToObjectProperty<TDomainObject>(dataReader, domainObject, fieldInfo);

            if (domainObjectBase != null)
                domainObjectBase.EndLoading();

            return domainObject;
        }

        private TDomainObject ParseObject<TDomainObject>(IDataReader dataReader, TableMappingInfo tableInfo, string[] selectedFields)
            where TDomainObject : class, new()
        {
            TDomainObject domainObject = new TDomainObject();
            DomainObjectBase domainObjectBase = domainObject as DomainObjectBase;
            if (domainObjectBase != null)
                domainObjectBase.BeginLoading();

            foreach (string selectedField in selectedFields)
            {
                FieldMappingInfo fieldInfo = GetFieldMappingInfoByDBFieldName(selectedField, tableInfo);
                object propertyValue = dataReader.GetValue(dataReader.GetOrdinal(fieldInfo.DBFieldName));
                PropertyInfo propertyInfo = typeof(TDomainObject).GetProperty(fieldInfo.ObjectFieldName);
                propertyInfo.SetValue(domainObject, propertyValue, null);
            }

            if (domainObjectBase != null)
                domainObjectBase.EndLoading();

            return domainObject;
        }

        #endregion

        #region IDisposable Members

        public override void Dispose()
        {

        }

        #endregion
    }
}
