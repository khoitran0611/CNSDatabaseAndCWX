using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Data.SqlClient;

using CWX.Core.Common.Data.Query;
using CWX.Core.Common.Data;

namespace CWX.Core.Providers.Data.Query
{
    public class SqlDeleteQueryBuilder : DeleteQueryBuilderBase
    {
        #region Constructors

        public SqlDeleteQueryBuilder(string tableName)
            : base(tableName)
        {
        }
        public SqlDeleteQueryBuilder(string tableName, SqlDataProvider provider)
            : base(tableName, provider)
        {
        }

        #endregion

        #region IQueryBuilder Members

        /// <summary>
        /// Build a Delete DBCommand.
        /// </summary>
        /// <returns>A DbCommand to delete an object.</returns>
        public override DbCommand BuildCommand()
        {
            ValidateQuery();

            string commandText = BuildCommandText();
            DbCommand cmd = DataProvider.CreateTextCommand(commandText);
            foreach (KeyValuePair<string, object> parameter in Identities)
            {
                DbParameter idParam = cmd.CreateParameter();
                idParam.ParameterName = "@" + parameter.Key;
                idParam.Value = parameter.Value;
                cmd.Parameters.Add(idParam);
            }

            return cmd;
        }

        #endregion

        #region Private Methods

        private void ValidateQuery()
        {
            if (string.IsNullOrEmpty(TableName))
                throw new ArgumentException("TableName cannot be empty.");
            if (Identities == null || Identities.Count <= 0)
                throw new ArgumentException("There must be at least one identity.");
        }

        private string BuildCommandText()
        {
            string identityFilterStatement = QueryBuilderUtility.BuildFormatString(Identities.Keys, "{0} = @{0}", "AND");

            if (string.IsNullOrEmpty(WhereClause))
                return string.Format("DELETE {0} WHERE {1}", TableName, identityFilterStatement);
            return string.Format("DELETE {0} WHERE {1} AND {2}", TableName, identityFilterStatement, WhereClause);
        }

        #endregion
    }
}
