using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Data.SqlClient;
using System.Collections.ObjectModel;

using CWX.Core.Common.Data.Query;
using CWX.Core.Common.Data;

namespace CWX.Core.Providers.Data.Query
{
    public class SqlFillOneQueryBuilder : FillOneQueryBuilder
    {
        #region Constructors

        public SqlFillOneQueryBuilder(string tableName)
            : base(tableName)
        {
        }

        public SqlFillOneQueryBuilder(string tableName, SqlDataProvider provider)
            : base(tableName, provider)
        {
        }

        #endregion

        #region Public Methods

        ///// <summary>
        ///// Build a paging DBCommand. DBCommand must has out parameter.
        ///// </summary>
        ///// <param name="pageSize"></param>
        ///// <param name="pageIndex">pageIndex starts with 0</param>
        ///// <returns></returns>
        //public override DbCommand BuildCommand(int pageSize, int pageIndex)
        //{
        //    ValidateQuery();

        //    if (string.IsNullOrEmpty(OutParameterName))
        //        throw new ArgumentException("Out Parameter cannot be empty.");

        //    string commandText = BuildCommandText(pageSize, pageIndex);
        //    DbCommand cmd = DataProvider.CreateTextCommand(commandText);

        //    foreach (KeyValuePair<string, object> identity in Identities)
        //    {
        //        DbParameter idParam = cmd.CreateParameter();
        //        idParam.ParameterName = "@" + identity.Key;
        //        idParam.Value = identity.Value;
        //        cmd.Parameters.Add(idParam);
        //    }

        //    //Add out parameter
        //    DbParameter outParameter = cmd.CreateParameter();
        //    outParameter.Direction = System.Data.ParameterDirection.Output;
        //    outParameter.ParameterName = "@" + OutParameterName;
        //    outParameter.DbType = System.Data.DbType.Int32;
        //    cmd.Parameters.Add(outParameter);

        //    return cmd;
        //}

        #region IQueryBuilder Members

        /// <summary>
        /// Build a Select DBCommand.
        /// </summary>
        /// <returns>A DbCommand to select values.</returns>
        public override DbCommand BuildCommand()
        {
            ValidateQuery();

            string commandText = BuildCommandText();

            DbCommand cmd = DataProvider.CreateTextCommand(commandText);

            foreach (KeyValuePair<string, object> identity in Identities)
            {
                DbParameter idParam = cmd.CreateParameter();
                idParam.ParameterName = DataProvider.FormatParameterName(identity.Key);
                idParam.Value = identity.Value;
                cmd.Parameters.Add(idParam);
            }
            return cmd;
        }

        #endregion

        #endregion

        #region Private Methods

        private void ValidateQuery()
        {
            if (string.IsNullOrEmpty(TableName))
                throw new ArgumentException("TableName cannot be empty.");
            //if (Identities == null || Identities.Count == 0)
            //    throw new ArgumentException("Identities must be defined");
        }

        private string BuildCommandText()
        {
            string orderByClause = BuildOrderByClause(OrderBys, OrderByClause);

            return BuildCommandText(orderByClause);
        }

        private string BuildCommandText(string orderBy)
        {
            string columnClause = QueryBuilderUtility.BuildFormatString(Columns, "{0}", ",");
            if (string.IsNullOrEmpty(columnClause))
                columnClause = "*";

            string identityFilterStatement = QueryBuilderUtility.BuildFormatString(Identities.Keys, "{0} = @{0}", "AND");

            if (string.IsNullOrEmpty(WhereClause) && string.IsNullOrEmpty(identityFilterStatement))
                return string.Format("SELECT TOP 1 {0} FROM {1} {2}", columnClause, TableName, orderBy);
            if (string.IsNullOrEmpty(WhereClause))
                return string.Format("SELECT {0} FROM {1} WHERE {2} {3}", columnClause, TableName, identityFilterStatement, orderBy);
            if (string.IsNullOrEmpty(identityFilterStatement))
                return string.Format("SELECT {0} FROM {1} WHERE {2} {3}", columnClause, TableName, WhereClause, orderBy);
            return string.Format("SELECT {0} FROM {1} WHERE {2} AND {3} {4}", columnClause, TableName, identityFilterStatement, WhereClause, orderBy);
        }

        

        private string BuildOrderByClause(Dictionary<string, OrderByDirection> orderBys, string orderByClause)
        {
            return BuildOrderByClause(orderBys, orderByClause, false);
        }

        private string BuildOrderByClause(Dictionary<string, OrderByDirection> orderBys, string orderByClause, bool isReverse)
        {
            if ((orderBys == null || orderBys.Count <= 0) && string.IsNullOrEmpty(orderByClause))
                return string.Empty;

            bool isFirst = true;
            StringBuilder orderByClauseBuilder = new StringBuilder("ORDER BY ");
            if (!string.IsNullOrEmpty(orderByClause))
            {
                orderByClauseBuilder.Append(orderByClause);
                isFirst = false;
            }

            foreach (KeyValuePair<string, OrderByDirection> item in orderBys)
            {
                string direction;
                if (isReverse)
                    direction = (item.Value == OrderByDirection.Ascending) ? " DESC" : " ASC";
                else
                    direction = (item.Value == OrderByDirection.Ascending) ? " ASC" : " DESC";

                if (isFirst)
                {
                    orderByClauseBuilder.Append(item.Key + direction);

                    isFirst = false;
                }
                else
                {
                    orderByClauseBuilder.Append(", " + item.Key + direction);
                }
            }

            return orderByClauseBuilder.ToString();
        }

        #endregion
    }
}
