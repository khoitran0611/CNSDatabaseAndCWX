using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Globalization;

using CWX.Core.Common.Data;
using CWX.Core.Common.Data.Query;

namespace CWX.Core.Providers.Data.Query
{
    public class SqlFillListQueryBuilder : FillListQueryBuilder
    {
        #region Constructors

        public SqlFillListQueryBuilder(string tableName)
            : base(tableName)
        {
        }

        public SqlFillListQueryBuilder(string tableName, SqlDataProvider provider)
            : base(tableName, provider)
        {
        }

        #endregion

        #region Override Method
        /// <summary>
        /// Build a paging DBCommand. DBCommand must has out parameter.
        /// </summary>
        /// <returns></returns>
        public override DbCommand BuildCommand()
        {
            ValidateQueryBuilder();
            
            string commandText = BuildCommandText();

            DbCommand cmd = DataProvider.CreateStoreProcedureCommand("sp_executesql");

            DbParameter queryTextParam = cmd.CreateParameter();
            queryTextParam.ParameterName = DataProvider.FormatParameterName("stmt");
            queryTextParam.DbType = System.Data.DbType.String;
            queryTextParam.Value = commandText;
            cmd.Parameters.Add(queryTextParam);

            DbParameter paramDefParam = cmd.CreateParameter();
            paramDefParam.ParameterName = DataProvider.FormatParameterName("params");
            paramDefParam.Value = BuildParameterDefinitions();
            paramDefParam.DbType = System.Data.DbType.String;
            cmd.Parameters.Add(paramDefParam);

            foreach (ParameterInfo paramInfo in Parameters)
            {
                DbParameter param = cmd.CreateParameter();
                param.ParameterName = DataProvider.FormatParameterName(paramInfo.ParameterName);
                param.Direction = paramInfo.Direction;
                param.Value = paramInfo.Value;
                cmd.Parameters.Add(param);
            }

            //Add RowCount parameter
            if (!string.IsNullOrEmpty(RowCountParameterName))
            {
                DbParameter outParameter = cmd.CreateParameter();
                outParameter.Direction = System.Data.ParameterDirection.Output;
                outParameter.ParameterName = DataProvider.FormatParameterName(RowCountParameterName);
                outParameter.DbType = System.Data.DbType.Int32;
                cmd.Parameters.Add(outParameter);
            }

            return cmd;
        }

        #endregion

        #region Private Methods

        private string BuildParameterDefinitions()
        {
            bool first = true;
            StringBuilder paramDef = new StringBuilder();
            if (PageSize > 0)
            {
                first = false;
                paramDef.AppendFormat("{0} AS Int OUTPUT", DataProvider.FormatParameterName(RowCountParameterName));
            }

            foreach (ParameterInfo paramInfo in Parameters)
            {
                if (first)
                    first = false;
                else
                    paramDef.Append(",");

                paramDef.AppendFormat("{0} AS ",DataProvider.FormatParameterName(paramInfo.ParameterName));
                switch (paramInfo.DbType.ToUpperInvariant())
                {
                    case "NVARCHAR":
                    case "VARBINARY":
                        paramDef.AppendFormat("{0}({1})", paramInfo.DbType, paramInfo.Length == 0 ? "MAX" : paramInfo.Length.ToString(CultureInfo.InvariantCulture));
                        break;
                    case "CHAR":
                    case "NCHAR":
                    case "BINARY":
                        paramDef.AppendFormat("{0}({1})", paramInfo.DbType, paramInfo.Length);
                        break;
                    case "DECIMAL":
                    case "NUMERIC":
                        paramDef.AppendFormat("{0}({1},{2})", paramInfo.DbType, paramInfo.Precision, paramInfo.Scale);
                        break;
                    default:
                        paramDef.Append(paramInfo.DbType);
                        break;
                }

                if (paramInfo.Direction == System.Data.ParameterDirection.Output)
                    paramDef.Append(" OUTPUT");
            }
            return paramDef.ToString();
        }

        private void ValidateQueryBuilder()
        {
            if (PageSize > 0 && string.IsNullOrEmpty(RowCountParameterName))
                throw new ArgumentException("RowCountParameterName cannot be empty.");
        }

        private string BuildCommandText()
        {
            if (PageSize > 0)
            {
                string paggingQueryTemplate =
                    "SELECT {0}=COUNT(*)" +
                    " FROM {1} {2};" +
                    " WITH Temp AS" +
                    " (SELECT {3}, ROW_NUMBER() OVER ({4}) AS RowNumber" +
                    " FROM {1} {2})" +
                    " SELECT * FROM Temp WHERE (({6} <= 0) OR (RowNumber BETWEEN {5} * {6} + 1 AND ({5} + 1) * {6}))";

                string columnClause = QueryBuilderUtility.BuildFormatString(Columns, "{0}", ",");
                if (string.IsNullOrEmpty(columnClause))
                    columnClause = "*";
                string orderByClause = BuildOrderByClause(OrderBys, OrderByClause);

                return string.Format(paggingQueryTemplate,
                    DataProvider.FormatParameterName(RowCountParameterName),
                    TableName,
                    string.IsNullOrEmpty(WhereClause) ? string.Empty : "WHERE " + WhereClause,
                    columnClause,
                    orderByClause,
                    PageIndex,
                    PageSize);
            }
            else
            {
                string orderByClause = BuildOrderByClause(OrderBys, OrderByClause);
                return BuildCommandText(orderByClause);
            }
        }

        private string BuildCommandText(string orderBy)
        {
            string columnClause = QueryBuilderUtility.BuildFormatString(Columns, "{0}", ",");
            if (string.IsNullOrEmpty(columnClause))
                columnClause = "*";

            if (string.IsNullOrEmpty(WhereClause))
                return string.Format("SELECT {0} FROM {1} {2}", columnClause, TableName, orderBy);
            return string.Format("SELECT {0} FROM {1} WHERE {2} {3}", columnClause, TableName, WhereClause, orderBy);
        }



        private string BuildOrderByClause(Dictionary<string, OrderByDirection> orderBys, string orderByClause)
        {
            return BuildOrderByClause(orderBys, orderByClause, false);
        }

        private string BuildOrderByClause(Dictionary<string, OrderByDirection> orderBys, string orderByClause, bool isReverse)
        {
            if ((orderBys == null || orderBys.Count <= 0) && string.IsNullOrEmpty(orderByClause))
                return string.Empty;

            bool isFirst = true;
            StringBuilder orderByClauseBuilder = new StringBuilder("ORDER BY ");
            if (!string.IsNullOrEmpty(orderByClause))
            {
                orderByClauseBuilder.Append(orderByClause);
                isFirst = false;
            }

            foreach (KeyValuePair<string, OrderByDirection> item in orderBys)
            {
                string direction;
                if (isReverse)
                    direction = (item.Value == OrderByDirection.Ascending) ? " DESC" : " ASC";
                else
                    direction = (item.Value == OrderByDirection.Ascending) ? " ASC" : " DESC";

                if (isFirst)
                {
                    orderByClauseBuilder.Append(item.Key + direction);

                    isFirst = false;
                }
                else
                {
                    orderByClauseBuilder.Append(", " + item.Key + direction);
                }
            }

            return orderByClauseBuilder.ToString();
        }
        #endregion
    }
}
