using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Data.SqlClient;

using CWX.Core.Common.Data.Query;

namespace CWX.Core.Providers.Data.Query
{
    public class SqlUpdateQueryBuilder : UpdateQueryBuilderBase
    {
        #region Constructors

        public SqlUpdateQueryBuilder(string tableName)
            : base(tableName)
        {
        }

        public SqlUpdateQueryBuilder(string tableName, SqlDataProvider provider)
            : base(tableName, provider)
        {
        }

        #endregion

        #region IQueryBuilder Members

        /// <summary>
        /// Build an Update DBCommand.
        /// </summary>
        /// <returns>A DbCommand to update an object.</returns>
        public override DbCommand BuildCommand()
        {
            ValidateQuery();

            string commandText = BuildCommandText();

            DbCommand cmd = DataProvider.CreateTextCommand(commandText);

            foreach (KeyValuePair<string, object> column in Columns)
            {
                DbParameter columnParam = cmd.CreateParameter();
                columnParam.ParameterName = DataProvider.FormatParameterName(column.Key);

                if (column.Value == null || column.Value == DBNull.Value)
                    columnParam.DbType = System.Data.DbType.AnsiString;

                columnParam.Value = column.Value;
                cmd.Parameters.Add(columnParam);
            }
            foreach (KeyValuePair<string, object> parameter in Identities)
            {
                DbParameter idParam = cmd.CreateParameter();
                idParam.ParameterName =  DataProvider.FormatParameterName(parameter.Key);
                idParam.Value = parameter.Value;
                cmd.Parameters.Add(idParam);
            }

            return cmd;
        }

        #endregion

        #region Private Method

        /// <summary>
        /// Validate query.
        /// </summary>
        private void ValidateQuery()
        {
            if (string.IsNullOrEmpty(TableName))
                throw new ArgumentException("TableName cannot be empty");
            if (Columns == null || Columns.Count <= 0)
                throw new ArgumentException("There must be at least one column");

            if (Identities == null || Identities.Count <= 0)
                throw new ArgumentException("There must be at least one identity.");
        }

        private string BuildCommandText()
        {
            string updateColumnValueList = QueryBuilderUtility.BuildFormatString(Columns.Keys, "{0} = @{0}", ",");
            string identityFilterStatement = QueryBuilderUtility.BuildFormatString(Identities.Keys, "{0} = @{0}", "AND");

            if (string.IsNullOrEmpty(WhereClause))
                return string.Format("UPDATE {0} SET {1} WHERE {2}", TableName, updateColumnValueList, identityFilterStatement);
            return string.Format("UPDATE {0} SET {1} WHERE {2} AND {3}", TableName, updateColumnValueList, identityFilterStatement, WhereClause);
        }

        #endregion
    }
}
