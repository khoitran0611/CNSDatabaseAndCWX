using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Data.SqlClient;

using CWX.Core.Providers.Data;
using CWX.Core.Common.Data.Query;

namespace CWX.Core.Providers.Data.Query
{
    public class SqlInsertQueryBuilder : InsertQueryBuilderBase
    {
        #region Constructors

        public SqlInsertQueryBuilder(string tableName)
            : base(tableName)
        {
        }

        public SqlInsertQueryBuilder(string tableName, SqlDataProvider provider)
            : base(tableName, provider)
        {
        }

        #endregion

        #region IQueryBuilder Members

        /// <summary>
        /// Build a Insert DBCommand.
        /// </summary>
        /// <returns>A DbCommand to insert an object.</returns>
        public override DbCommand BuildCommand()
        {
            ValidateQuery();

            string commandText = BuildCommandText();
            DbCommand cmd = DataProvider.CreateTextCommand(commandText);
            foreach (KeyValuePair<string, object> column in Columns)
            {
                DbParameter columnParam = cmd.CreateParameter();
                columnParam.ParameterName = DataProvider.FormatParameterName(column.Key);
                columnParam.Value = column.Value;
                cmd.Parameters.Add(columnParam);
            }

            return cmd;
        }

        #endregion

        #region Private Method

        private void ValidateQuery()
        {
            if (string.IsNullOrEmpty(TableName))
                throw new ArgumentException("TableName cannot be empty");
            if (Columns == null || Columns.Count <= 0)
                throw new ArgumentException("There must be at least one column");
        }

        private string BuildCommandText()
        {
            string insertColumnList = QueryBuilderUtility.BuildFormatString(Columns.Keys, "{0}", ",");
            string insertValueList = QueryBuilderUtility.BuildFormatString(Columns.Keys, "@{0}", ",");

            string insertQuery = string.Format("INSERT INTO {0}({1}) VALUES({2});", TableName, insertColumnList, insertValueList);
            if (ReturnIdentity)
                insertQuery += "SELECT SCOPE_IDENTITY();";

            return insertQuery;
        }

        #endregion
    }
}
