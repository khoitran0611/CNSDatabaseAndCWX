using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using CWX.Core.Common.Data.Query;

namespace CWX.Core.Providers.Data.Query
{
    public class SqlStoreProcedureQuerryBuilder : StoreProcedureQueryBuilderBase
    {
        #region Constructors

        public SqlStoreProcedureQuerryBuilder(string storeProcedureName)
            : base(storeProcedureName)
        {
        }
        public SqlStoreProcedureQuerryBuilder(string storeProcedureName, SqlDataProvider provider)
            : base(storeProcedureName, provider)
        {
        }

        #endregion

        #region IQueryBuilder Members

        /// <summary>
        /// Build storeprocedure DBCommand.
        /// </summary>
        /// <returns>DbCommand</returns>
        public override DbCommand BuildCommand()
        {
            ValidateQuery();

            DbCommand cmd = DataProvider.CreateStoreProcedureCommand(StoreProcedureName);

            foreach (KeyValuePair<string, object> parameter in Parameters)
            {
                DbParameter inputParam = cmd.CreateParameter();
                inputParam.ParameterName = DataProvider.FormatParameterName(parameter.Key);
                inputParam.Value = parameter.Value;
                cmd.Parameters.Add(inputParam);
            }

            if (!string.IsNullOrEmpty(ReturnParameterName))
            {
                DbParameter returnParameter = cmd.CreateParameter();
                returnParameter.ParameterName = DataProvider.FormatParameterName(ReturnParameterName);
                returnParameter.DbType = DbType.Int32;
                returnParameter.Direction = ParameterDirection.ReturnValue;
                cmd.Parameters.Add(returnParameter);
            }

            return cmd;
        }

        #endregion

        private void ValidateQuery()
        {
            if (string.IsNullOrEmpty(StoreProcedureName))
                throw new ArgumentException("StoreProcedureName cannot be empty.");
        }
    }
}
