using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Data.SqlClient;

using CWX.Core.Common.Data.Query;
using CWX.Core.Common.Data;

namespace CWX.Core.Providers.Data.Query
{
    public class SqlSoftDeleteQueryBuilder : SoftDeleteQueryBuilderBase
    {
        #region Constructors

        public SqlSoftDeleteQueryBuilder(string tableName)
            : base(tableName)
        {
        }
        public SqlSoftDeleteQueryBuilder(string tableName, SqlDataProvider provider)
            : base(tableName, provider)
        {
        }

        #endregion

        #region IQueryBuilder Members

        /// <summary>
        /// Build a SoftDelete DBCommand.
        /// </summary>
        /// <returns>A DbCommand to SoftDelete an object.</returns>
        public override DbCommand BuildCommand()
        {
            ValidateQuery();

            string commandText = BuildCommandText();
            DbCommand cmd = DataProvider.CreateTextCommand(commandText);

            DbParameter recordStatusParam = cmd.CreateParameter();
            recordStatusParam.ParameterName = DataProvider.FormatParameterName(RecordStatusFieldName);
            recordStatusParam.Value = RecordStatusConstant.RETIRED;
            cmd.Parameters.Add(recordStatusParam);

            foreach (KeyValuePair<string, object> parameter in Identities)
            {
                DbParameter idParam = cmd.CreateParameter();
                idParam.ParameterName = "@" + parameter.Key;
                idParam.Value = parameter.Value;
                cmd.Parameters.Add(idParam);
            }

            return cmd;
        }

        #endregion

        #region Private Methods

        private void ValidateQuery()
        {
            if (string.IsNullOrEmpty(TableName))
                throw new ArgumentException("TableName cannot be empty.");
            if (Identities == null || Identities.Count <= 0)
                throw new ArgumentException("There must be at least one identity.");
        }

        private string BuildCommandText()
        {
            string identityFilterStatement = QueryBuilderUtility.BuildFormatString(Identities.Keys, "{0} = @{0}", "AND");

            if (string.IsNullOrEmpty(WhereClause))
                return string.Format("UPDATE {0} SET {1} = @{1} WHERE {2}", TableName, RecordStatusFieldName, identityFilterStatement);
            return string.Format("UPDATE {0} SET {1} = @{1} WHERE {2} AND {3}", TableName, RecordStatusFieldName, identityFilterStatement, WhereClause);
        }

        #endregion
    }
}
