using System;
using System.Web.Compilation;
using System.Resources;
using System.Reflection;
using System.Globalization;
using System.Threading;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using CWX.Core.Common.Resource;
using System.Collections.Specialized;
using System.Collections.Generic;

namespace CWX.Core.Providers.Resource
{

    /// <summary>
    /// Resource provider for accessing external resources. 
    /// </summary>
    public class AnalyticsXmlResourceProvider : CWXResourceProviderBase
    {

        private static Assembly _resourceAsm;
        private static string _resourceAsmName;
        private static string _resourceNamespace;
        private static Dictionary<ResourceCategory, ResourceManager> _resource = new Dictionary<ResourceCategory, ResourceManager>();
        private static object _lockObject = new object();

        #region CWXResourceProviderBase Members

        private string _classKey;
        /// <summary>
        /// Get or set class key of resource file.
        /// </summary>
        public override string ClassKey
        {
            get { return _classKey; }
            set { _classKey = value; }
        }

        /// <summary>
        /// Retrieves object resource.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <returns>The resource value if found.</returns>
        public override object GetObjectResource(ResourceCategory resCategory, string resourceKey)
        {
            return GetObjectResource(resCategory, resourceKey, null);
        }

        /// <summary>
        /// Retrieves object resource.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <param name="culture">The culture to find.</param>
        /// <returns>The resource value if found.</returns>
        public override object GetObjectResource(ResourceCategory resCategory, string resourceKey, CultureInfo culture)
        {
            EnsureResourceAssembly();

            if (object.ReferenceEquals(culture, null))
                culture = CultureInfo.CurrentUICulture;

            ResourceManager resource = null;
            if (_resource.TryGetValue(resCategory, out resource) == false || resource == null)
                resource = _resource[resCategory] = InitializeResourceManager(resCategory);

            return resource.GetObject(resourceKey, culture);
        }

        /// <summary>
        /// Retrieves string resource.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <returns>The resource value if found.</returns>
        public override string GetStringResource(ResourceCategory resCategory, string resourceKey)
        {
            return GetStringResource(resCategory, resourceKey, null);
        }

        /// <summary>
        /// Retrieves string resource.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <param name="culture">The culture to find.</param>
        /// <returns>The resource value if found.</returns>
        public override string GetStringResource(ResourceCategory resCategory, string resourceKey, CultureInfo culture)
        {
            if (culture == null)
                culture = CultureInfo.CurrentUICulture;

            return GetObjectResource(resCategory, resourceKey, culture) as string;
        }

        /// <summary>
        /// Retrieves string resource.
        /// </summary>
        /// <param name="resourceKey">A string representing a System.Web.Compilation.ResourceExpressionFields.ResourceKey</param>
        /// <param name="resCategory">Resource category.</param>
        /// <param name="culture">The culture to find.</param>
        /// <param name="stringParams">A string array containing zero or more strings to format.</param>
        /// <returns>The resource value if found.</returns>
        public override string GetStringResource(ResourceCategory resCategory, string resourceKey, CultureInfo culture, params object[] objParams)
        {
            if (culture == null)
                culture = CultureInfo.CurrentUICulture;

            if (objParams == null)
                return GetStringResource(resCategory, resourceKey, culture);

            return string.Format(culture, GetStringResource(resCategory, resourceKey, culture), objParams);
        }

        #endregion

        #region ProviderBase Members

        private string _name;
        public override string Name
        {
            get { return _name; }
        }
        private string _description;
        public override string Description
        {
            get { return _description; }
        }

        /// <summary>
        /// Initializes the provider.
        /// </summary>
        /// <param name="name">The friendly name of the provider.</param>
        /// <param name="config">
        /// A collection of the name/value pairs representing the provider-specific attributes
        /// specified in the configuration for this provider.
        /// </param>
        public override void Initialize(string name, NameValueCollection config)
        {
            _resourceNamespace = config.Get("resourceNamespace");
            _resourceAsmName = config.Get("resourceAssembly");
            _name = name;
            _description = config.Get("description");
        }

        #endregion

        #region IResourceProvider Members

        /// <summary>
        /// Returns a resource object for the key and culture.
        /// </summary>
        /// <param name="resourceKey">The key identifying a particular resource.</param>
        /// <param name="culture">The culture identifying a localized value for the resource.</param>
        /// <returns>
        /// An System.Object that contains the resource value for the resourceKey and culture.
        /// </returns>
        public override object GetObject(string resourceKey, CultureInfo culture)
        {
            return GetObjectResource(
                (ResourceCategory)Enum.Parse(typeof(ResourceCategory), ClassKey),
                resourceKey,
                culture);
        }


        #endregion

        #region Private Methods

        private static void EnsureResourceAssembly()
        {
            if (object.ReferenceEquals(_resourceAsm, null))
            {
                lock (_lockObject)
                {
                    _resourceAsm = Assembly.Load(_resourceAsmName);
                }
            }
        }

        /// <summary>
        /// Initialize <see cref="ResourceManager"/> for specified <see cref="ResourceCategory"/>.
        /// </summary>
        /// <param name="resCategory">ResourceCategory of resource.</param>
        /// <returns></returns>
        private static ResourceManager InitializeResourceManager(ResourceCategory resCategory)
        {
            lock (_lockObject)
            {
                return new ResourceManager(
                    string.Format("{0}.{1}", _resourceNamespace, resCategory.ToString()),
                    _resourceAsm);
            }
        }


        #endregion

    }
}