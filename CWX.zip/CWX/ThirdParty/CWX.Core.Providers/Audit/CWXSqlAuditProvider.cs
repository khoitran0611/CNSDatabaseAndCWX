using System;
using System.Configuration;
using System.Configuration.Provider;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Reflection;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;

using Microsoft.Practices.EnterpriseLibrary.Data;

using CWX.Core.Common;
using CWX.Core.Common.Data;
using CWX.Core.Common.Data.Query;
using CWX.Core.Common.Data.DataConverter;
using CWX.Core.Common.Audit;
using CWX.Core.Common.DomainObject;
using CWX.Core.Common.Security;
using CWX.Core.Providers.Data.Query;
using CWX.Core.Providers.Data;
using System.Web;
using System.Text;
using System.ComponentModel;

namespace CWX.Core.Providers.Audit
{
    public class CWXSqlAuditProvider : CWXAuditProvider
    {
        private IDataMappingProvider _mappingProvider;
        private string _databaseName;

        #region Properties

        public IDataMappingProvider MappingProvider
        {
            get
            {
                if (_mappingProvider == null)
                    _mappingProvider = new DataMappingProviderFactory().Create();
                return _mappingProvider;
            }
            set
            {
                _mappingProvider = value;
            }
        }

        private IDataProvider _dataProvider;

        public IDataProvider DataProvider
        {
            get
            {
                if (_dataProvider == null)
                    _dataProvider = new DataProviderFactory().Create(_databaseName);
                return _dataProvider;
            }
            set { _dataProvider = value; }
        }

        #endregion

        /// <summary>
        /// Initialize the provider.
        /// </summary>
        /// <param name="name">Name of the provider.</param>
        /// <param name="config">Configuration settings.</param>
        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            if ((config == null) || (config.Count == 0))
                throw new ArgumentNullException("You must supply a valid configuration dictionary.");

            if (string.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "Put a localized description here.");
            }

            //Let ProviderBase perform the basic initialization
            base.Initialize(name, config);

            //Perform feature-specific provider initialization here

            //Get the connection string
            string connectionStringName = config["connectionStringName"];
            if (String.IsNullOrEmpty(connectionStringName))
                throw new ProviderException("You must specify a connectionStringName attribute.");

            _databaseName = connectionStringName;
            config.Remove("connectionStringName");


            //Check to see if unexpected attributes were set in configuration
            if (config.Count > 0)
            {
                string extraAttribute = config.GetKey(0);
                if (!String.IsNullOrEmpty(extraAttribute))
                    throw new ProviderException("The following unrecognized attribute was found in " + Name + "'s configuration: '" +
                                                extraAttribute + "'");
                else
                    throw new ProviderException("An unrecognized attribute was found in the provider's configuration.");
            }
        }

        #region Implemented Abstract Methods

        #region AuditTrail
        
        /// <summary>
        /// Search AuditTrail.
        /// </summary>
        /// <param name="fromDate">Get trail "From Date".</param>
        /// <param name="toDate">Get trail "To Date".</param>
        /// <param name="pageSize">Number record per page.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="totalRow">Total search result.</param>
        [Obsolete("Unused method")]
        public override DataSet SearchTrail(Nullable<int> trailId, Nullable<int> employeeId,
           Nullable<int> actionId, string changeTable, string changeField, Nullable<DateTime> fromDate, Nullable<DateTime> toDate,
            int pageSize, int pageIndex, out int totalRow)
        {
            string[] parameterNames = { "TrailID", "EmployeeID", "ActionID", "ChangeTable", "ChangeField", "AuditFrom", "AuditTo" };
            object[] parameterValues = { trailId, employeeId, actionId, changeTable, changeField, fromDate, toDate };

            SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder("CWX_AuditTrail_Search");
            for (int i = 0; i < parameterNames.Length; i++)
                queryBuilder.AddParameter(parameterNames[i], parameterValues[i]);
            queryBuilder.AddParameter("PageSize", pageSize);
            queryBuilder.AddParameter("PageIndex", pageSize);
            queryBuilder.AppendReturnParameter("RowCount");

            DataSet resultDataSet = null;
            using (IDataExecutionContext dataExecutionContext = DataProvider.BeginExecution(queryBuilder))
            {
                resultDataSet = dataExecutionContext.RunDataSet();
                totalRow = dataExecutionContext.GetParameterOutPutIntegerValue("RowCount");
            }

            return resultDataSet;
        }

        /// <summary>
        /// Get AuditTrail object.
        /// </summary>
        /// <param name="trailId">Trail ID.</param>
        public override CWXAuditTrail GetTrail(int trailId)
        {
            SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder("CWX_AuditTrail_SelectByID");
            queryBuilder.AddParameter("AuditID", trailId);
            CWXAuditTrail trail = null;
            using (IDataExecutionContext dataExecutionContext = DataProvider.BeginExecution(queryBuilder))
            {
                IDataReader dataReader = dataExecutionContext.RunReader(CommandBehavior.SingleRow);
                trail = FillFromReader<CWXAuditTrail>(dataReader);
            }
            return trail;
        }

        /// <summary>
        /// Add a trail to database.
        /// </summary>
        /// <param name="trail">Object CWXAuditTrail to add.</param>
        /// <returns>Successful state.</returns>
        /// <history>
        ///     2008/08/26  [Binh Truong]   Add AuditDateTime parameter.
        ///     2009/09/09  [Long Nguyen]   Move to Add a collection of Trail.
        /// </history>
        public override bool AddTrail(CWXAuditTrail trail)
        {
            if (trail == null)
                return false;

            Collection<CWXAuditTrail> trails = new Collection<CWXAuditTrail>();
            trails.Add(trail);
            return AddTrail(trails);
        }

        /// <summary>
        /// Add a collection of trails to database
        /// </summary>
        /// <param name="trails">A collection of trails to add</param>
        /// <returns></returns>
        /// <history>
        ///     2008/09/08  [Long Nguyen]   Initialize.
        /// </history>
        public override bool AddTrail(Collection<CWXAuditTrail> trails)
        {
            if (trails == null || trails.Count <= 0)
                return false;

            string insertSqlTemplate = "INSERT INTO CWX_AuditTrail(EmployeeID, ActionID, DBConnectionName, ChangeTable, RowID, ChangeField, OriginalData, ChangeData, AuditDateTime)"
                                        + " VALUES(@EmployeeID{0},@ActionID{0},@DBConnectionName{0},@ChangeTable{0},@RowID{0},@ChangeField{0},@OriginalData{0},@ChangeData{0},@AuditDateTime{0});";

            using (IDataExecutionContext dataExecutionContext = DataProvider.BeginExecution())
            {
                StringBuilder commandText = new StringBuilder();
                for (int i = 0; i < trails.Count; i++)
                {
                    commandText.Append(string.Format(insertSqlTemplate, i));

                    if (string.IsNullOrEmpty(trails[i].ChangedDatabase))
                        trails[i].ChangedDatabase = GetCurrentWorkDBName();
                    dataExecutionContext.AddParameter("EmployeeID" + i, trails[i].EmployeeID);
                    dataExecutionContext.AddParameter("ActionID" + i, trails[i].Action);
                    dataExecutionContext.AddParameter("DBConnectionName" + i, trails[i].ChangedDatabase);
                    dataExecutionContext.AddParameter("ChangeTable" + i, trails[i].ChangedTable);
                    dataExecutionContext.AddParameter("RowID" + i, trails[i].RowID);
                    dataExecutionContext.AddParameter("ChangeField" + i, trails[i].ChangedField);
                    dataExecutionContext.AddParameter("OriginalData" + i, trails[i].OriginalData);
                    dataExecutionContext.AddParameter("ChangeData" + i, (trails[i].ChangedData == null) ? DBNull.Value : (object)trails[i].ChangedData);
                    dataExecutionContext.AddParameter("AuditDateTime" + i, DateTime.Now);
                }

                dataExecutionContext.SetCommandText(commandText.ToString());

                return dataExecutionContext.RunNonQuery() > 0;
            }
        }

        /// <summary>
        /// Update a trail.
        /// </summary>
        /// <param name="trail">Trail to update.</param>
        /// <returns>Successful state.</returns>
        [Obsolete("Unused method")]
        public override bool UpdateTrail(CWXAuditTrail trail)
        {
            throw new NotSupportedException("Update trail is not supported.");
        }

        /// <summary>
        /// Delete a trail.
        /// </summary>
        /// <param name="trail">Trail to delete</param>
        /// <returns>Successful state.</returns>
        [Obsolete("Unused method")]
        public override bool DeleteTrail(int trailId)
        {
            throw new NotSupportedException("Delete trail is not supported.");
        }

        #endregion

        #region AuditTable


        /// <summary>
        /// Search AuditTable.
        /// </summary>
        /// <param name="id">Identity.</param>
        /// <param name="className">Auditing class name.</param>
        /// <param name="audited">Is auditing.</param>
        /// <param name="allowed">Is allow to audit.</param>
        public override DataSet SearchAuditTable(Nullable<int> id, string className, Nullable<bool> audited, int pageSize, int pageIndex, out int totalRow)
        {
            string[] parameterNames = { "ID", "ClassName", "Audited" };
            object[] parameterValues = { id, className, audited };

            SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder("CWX_AuditTable_Search");
            for (int i = 0; i < parameterNames.Length; i++)
                queryBuilder.AddParameter(parameterNames[i], parameterValues[i]);
            queryBuilder.AddParameter("PageSize", pageSize);
            queryBuilder.AddParameter("PageIndex", pageIndex);
            queryBuilder.AppendReturnParameter("RowCount");

            DataSet resultDataSet = null;
            using (IDataExecutionContext dataExecutionContext = DataProvider.BeginExecution(queryBuilder))
            {
                resultDataSet = dataExecutionContext.RunDataSet();
                totalRow = dataExecutionContext.GetParameterOutPutIntegerValue("RowCount");
            }

            return resultDataSet;
        }

        /// <summary>
        /// Get AuditTable object.
        /// </summary>
        /// <param name="id">ID.</param>
        public override CWXAuditTable GetAuditTable(int id)
        {
            SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder("CWX_AuditTable_SelectByID");
            queryBuilder.AddParameter("ID", id);
            CWXAuditTable auditTable = null;
            using (IDataExecutionContext dataExecutionContext = DataProvider.BeginExecution(queryBuilder))
            {
                IDataReader dataReader = dataExecutionContext.RunReader(CommandBehavior.SingleRow);
                auditTable = FillFromReader<CWXAuditTable>(dataReader);
            }
            return auditTable;
        }

        /// <summary>
        /// Get AuditTable object.
        /// </summary>
        /// <param name="className">Auditing class name.</param>
        public override CWXAuditTable GetAuditTable(string className)
        {
            SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder("CWX_AuditTable_SelectByClassName");
            queryBuilder.AddParameter("ClassName", className);
            CWXAuditTable auditTable = null;
            using (IDataExecutionContext dataExecutionContext = DataProvider.BeginExecution(queryBuilder))
            {
                IDataReader dataReader = dataExecutionContext.RunReader(CommandBehavior.SingleRow);
                auditTable = FillFromReader<CWXAuditTable>(dataReader);
            }
            return auditTable;
        }

        /// <summary>
        /// Add class name to audit.
        /// </summary>
        /// <param name="auditTable">AuditTable object</param>
        public override bool AddAuditTable(CWXAuditTable auditTable)
        {
            SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder("CWX_AuditTable_Insert");
            queryBuilder.AddParameter("ClassName", auditTable.ClassName);
            queryBuilder.AddParameter("Description", auditTable.Description);
            queryBuilder.AddParameter("Audited", auditTable.Audited);

            int affectedCount = 0;
            using (IDataExecutionContext dataExecutionContext = DataProvider.BeginExecution(queryBuilder))
            {
                affectedCount = dataExecutionContext.RunNonQuery();
            }
            return affectedCount > 0;
        }

        /// <summary>
        /// Update AuditTable.
        /// </summary>
        /// <param name="auditTable">AuditTable object to update.</param>
        public override bool UpdateAuditTable(CWXAuditTable auditTable)
        {
            SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder("CWX_AuditTable_Update");
            queryBuilder.AddParameter("ID", auditTable.ID);
            queryBuilder.AddParameter("ClassName", auditTable.ClassName);
            queryBuilder.AddParameter("Description", auditTable.Description);
            queryBuilder.AddParameter("Audited", auditTable.Audited);

            int affectedCount = 0;
            using (IDataExecutionContext dataExecutionContext = DataProvider.BeginExecution(queryBuilder))
            {
                affectedCount = dataExecutionContext.RunNonQuery();
            }
            return affectedCount > 0;
        } 
        #endregion                

        /// <summary>
        /// Audit domain object values.
        /// </summary>
        /// <param name="domainObject">domain object to audit.</param>
        /// <param name="action">Audit action.</param>
        /// <param name="tableInfo"><see cref="TableMappingInfo"/> which relate to this domain object.</param>
        public override void AuditObject(IDomainObject domainObject, CWXAuditAction action, TableMappingInfo tableInfo)
        {
            if (!tableInfo.ForceAudit && ( domainObject == null || !CanAudit(tableInfo.DBTableName)))
                return;

            if ((action == CWXAuditAction.Add && !tableInfo.AuditOnActionAdd) ||
                (action==CWXAuditAction.Edit && !tableInfo.AuditOnActionEdit) ||
                (action==CWXAuditAction.Delete && !tableInfo.AuditOnActionDelete))
            {
                return;
            }

            FieldMappingInfo primaryFieldInfo = tableInfo.GetPrimaryFieldInfo();
            if (primaryFieldInfo == null)
                throw new InvalidOperationException("The primary key of Xml Mapping Object is missing.");

            PropertyInfo primaryProperty = domainObject.GetType().GetProperty(primaryFieldInfo.ObjectFieldName);
            if (primaryProperty == null)
                throw new InvalidOperationException("The primary key of Mapping Object is missing.");

            CWXIdentity identity = Thread.CurrentPrincipal.Identity as CWXIdentity;
            int? employeeID = null;
            if (identity != null)
                employeeID = identity.UserID;

            if (action == CWXAuditAction.Delete)
            {
                CWXAuditTrail trail = new CWXAuditTrail();
                trail.RowID = primaryProperty.GetValue(domainObject, null).ToString();

                if (employeeID.HasValue)
                    trail.EmployeeID = employeeID.Value;

                trail.ChangedTable = tableInfo.DBTableName;
                if (tableInfo.SoftDeletable) // softdelete field
                {
                    trail.Action = CWXAuditAction.Edit;
                    trail.ChangedField = tableInfo.RecordStatusField;
                    trail.OriginalData = "A";
                    trail.ChangedData = "R";
                }
                else
                {
                    trail.Action = CWXAuditAction.Delete;
                    trail.ChangedField = primaryFieldInfo.DBFieldName;
                    object primaryFieldValue = primaryProperty.GetValue(domainObject, null);
                    if (primaryFieldValue == null)
                        throw new InvalidOperationException("Missing ID which require to delete.");
                    else
                        trail.ChangedData = Convert.ToString(primaryFieldValue);
                }

                AddTrail(trail);
            }
            else
            {
                Collection<CWXAuditTrail> trails = new Collection<CWXAuditTrail>();
                foreach (KeyValuePair<string, object[]> propertyValue in domainObject.ChangedPropertyValues)
                {
                    CWXAuditTrail trail = new CWXAuditTrail();
                    if (employeeID.HasValue)
                        trail.EmployeeID = employeeID.Value;

                    trail.Action = action;
                    trail.ChangedTable = tableInfo.DBTableName;
                    trail.RowID = primaryProperty.GetValue(domainObject, null).ToString();
                    trail.ChangedField = propertyValue.Key;
                    trail.OriginalData = propertyValue.Value[0] == null ? string.Empty : propertyValue.Value[0].ToString();
                    trail.ChangedData = propertyValue.Value[1] == null ? null : propertyValue.Value[1].ToString();

                    trails.Add(trail);
                }
                AddTrail(trails);
            }
        }

        /// <summary>
        /// Audit domain object values.
        /// </summary>
        /// <param name="domainObject">domain object to audit.</param>
        /// <param name="action">Audit action.</param>
        /// <param name="tableInfo"><see cref="TableMappingInfo"/> which relate to this domain object.</param>
        /// <remarks>
        /// Should use AuditObject(IDomainObject domainObject, CWXAuditAction action, TableMappingInfo tableInfo) 
        /// if possible to increase performance.
        /// </remarks>
        public override void AuditObject(IDomainObject domainObject, CWXAuditAction action)
        {
            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(domainObject.GetType());
            AuditObject(domainObject, action, tableInfo);
        }

        /// <summary>
        /// Add a trail to database. 
        /// </summary>
        /// <param name="tableName">Determine the table name need to audit or not.</param>
        public override void AuditObject(CWXAuditTrail trail, string tableName)
        {
            if (!CanAudit(tableName))
                return;

            AddTrail(trail);
        }

        /// <summary>
        /// Audit custom domain object values which has no table mapping info.
        /// </summary>
        /// <param name="domainObject">domain object to audit.</param>
        /// <param name="action">Audit action.</param>
        /// <param name="tableInfo"><see cref="TableMappingInfo"/> which relate to this domain object.</param>
        public override void AuditEditCustomObject(IDomainObject domainObject, string auditObjectName)
        {
            if (domainObject == null || !CanAudit(auditObjectName))
                return;

            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(domainObject.GetType());
            FieldMappingInfo primaryFieldInfo = tableInfo.GetPrimaryFieldInfo();
            if (primaryFieldInfo == null)
                throw new InvalidOperationException("The primary key of Xml Mapping Object is missing.");

            PropertyInfo primaryProperty = domainObject.GetType().GetProperty(primaryFieldInfo.ObjectFieldName);
            if (primaryProperty == null)
                throw new InvalidOperationException("The primary key of Mapping Object is missing.");

            CWXIdentity identity = Thread.CurrentPrincipal.Identity as CWXIdentity;
            string databaseName = identity.DbConnectionName;
            int? employeeID = null;
            if (identity != null)
                employeeID = identity.UserID;

            Collection<CWXAuditTrail> trails = new Collection<CWXAuditTrail>();
            foreach (KeyValuePair<string, object[]> propertyValue in domainObject.ChangedPropertyValues)
            {
                CWXAuditTrail trail = new CWXAuditTrail();
                if (employeeID.HasValue)
                    trail.EmployeeID = employeeID.Value;

                trail.ChangedTable = auditObjectName;
                trail.RowID = primaryProperty.GetValue(domainObject, null).ToString();
                trail.ChangedField = propertyValue.Key;
                trail.OriginalData = propertyValue.Value[0] == null ? null : propertyValue.Value[0].ToString();
                trail.ChangedData = propertyValue.Value[1] == null ? null : propertyValue.Value[1].ToString();
                trail.Action = CWXAuditAction.Edit;

                trails.Add(trail);
            }
            AddTrail(trails);
        }

        public override Collection<string> GetChangeTableList()
        {
            using (IDataExecutionContext dataContext = DataProvider.BeginExecution())
            {
                dataContext.SetCommandText("SELECT DISTINCT ChangeTable FROM CWX_AuditTrail ORDER BY ChangeTable");
                IDataReader reader = dataContext.RunReader(CommandBehavior.CloseConnection);
                Collection<string> tableList = new Collection<string>();
                while (reader.Read())
                    tableList.Add(reader.GetString(0));

                return tableList;
            }
        }

        public override DataSet GetList(int employeeID, string changeTable, DateTime? fromDate, DateTime? toDate, int actionID, string rowID, int pageSize, int pageIndex, out int rowCount)
        {
            string[] parameterNames = { "EmployeeID", "ChangeTable", "FromDate", "ToDate", "ActionID", "RowID", "DBConnectionName" };
            object[] parameterValues = { employeeID, changeTable, fromDate, toDate, actionID, rowID, ConnectionManager.CWXDatabaseName };
            return DataProvider.ExecuteDataSet("CWX_AuditTrail_GetList", parameterNames, parameterValues, pageSize, pageIndex, out rowCount);
        }

		public override int GetLastAgencyStatusFromAuditTrail(int accountId, string dbConnectionName)
		{
			object[] parameterValues = { accountId, dbConnectionName };
			object lastAgencyStatus = DataProvider.ExecuteScalar(parameterValues, "CWX_AuditTrail_GetLastAgencyStatus");
			return lastAgencyStatus != null ? Convert.ToInt32(lastAgencyStatus) : 0;
		}
        #endregion

        #region Write Audit Trail On Store Procedures

        private object _beforeObj, _afterObj;
        private string[] _propertyNames;
        private CWXAuditAction _action;

        IDataProvider _sqlProvider;
        private IDataProvider SqlProvider
        {
            get
            {
                if (_sqlProvider == null)
                    _sqlProvider = new DataProviderFactory().Create();
                return _sqlProvider;
            }
        }

        /// <summary>
        /// Validate parameters.
        /// </summary>
        /// <history>
        ///     2008/06/30  [Khoa Dang] Init version.
        /// </history>
        private void CheckParameters(string[] propertyNames, object[] values)
        {
            if (propertyNames == null || values == null) // none of checked for null values
                return;

            if (propertyNames.Length != values.Length)
                throw new ArgumentException("The length of [propertyNames] and [values] variables are not equally.");
        }

        /// <summary>
        /// Audit trail on single row
        /// Purpose: it will comparing the values of before and after updated and only effected on single row
        /// Note: Call EndAudit method to completed
        /// </summary>
        /// <history>
        ///     2008/06/30  [Khoa Dang] Init version.
        /// </history>
        public override void BeginAudit<TDomainObject, KType>(KType key, string[] propertyNames, CWXAuditAction action)
        {
            _beforeObj = SqlProvider.Fill<TDomainObject, KType>(key);
            _propertyNames = propertyNames;
            _action = action;
        }

        /// <summary>
        /// Audit trail on single row
        /// </summary>
        /// <history>
        ///     2008/06/30  [Khoa Dang] Init version.
        /// </history>
        public override void EndAudit<TDomainObject, KType>(KType key)
        {
            _afterObj = SqlProvider.Fill<TDomainObject, KType>(key);
            for (int i = 0; i < _propertyNames.Length; i++)
            {
                string propertyName = _propertyNames[i];
                Type beforeObjType = _beforeObj.GetType();
                Type afterObjType = _afterObj.GetType();

                PropertyInfo beforeObjPropertyInfo = beforeObjType.GetProperty(propertyName, BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public);
                PropertyInfo afterObjPropertyInfo = afterObjType.GetProperty(propertyName, BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public);

                beforeObjPropertyInfo.SetValue(_beforeObj, afterObjPropertyInfo.GetValue(_afterObj, null), null);
            }
            AuditObject(_beforeObj as IDomainObject, _action);
        }

        /// <summary>
        /// Audit trail on multiple rows
        /// </summary>
        /// <param name="propertyNames">Property names of TDomainObject which want to audit.</param>
        /// <param name="values">Changed valued of propertyNames parameter.</param>
        /// <param name="action">Change action.</param>
        /// <param name="whereClause">Where clause with search criteria to select data to audit.</param>
        /// <history>
        ///     2008/06/30  [Khoa Dang]     Init version.
        ///     2008/08/11  [Binh Truong]   Add parameter comments.
        /// </history>
        public override void WriteAudit<TDomainObject>(string[] propertyNames, object[] values, CWXAuditAction action, string whereClause)
        {
            CheckParameters(propertyNames, values);

            Collection<TDomainObject> list = SqlProvider.FillList<TDomainObject>("", whereClause);
            foreach (TDomainObject obj in list)
            {
                WriteAudit(obj, propertyNames, values, action);
            }
        }

        /// <summary>
        /// Audit trail on single row
        /// </summary>
        /// <param name="domainBusinessObject">Domain business object to audit.</param>
        /// <param name="propertyNames">Property names of domainBusinessObject which want to audit.</param>
        /// <param name="values">Changed valued of propertyNames parameter.</param>
        /// <param name="action">Change action.</param>
        /// <history>
        ///     2008/06/30  [Khoa Dang]     Init version.
        ///     2008/08/11  [Binh Truong]   Add parameter comments.
        /// </history>
        public override void WriteAudit(object domainBusinessObject, string[] propertyNames, object[] values, CWXAuditAction action)
        {
            CheckParameters(propertyNames, values);

            Type type = domainBusinessObject.GetType();
            if (propertyNames != null && values != null)
            {
                for (int i = 0; i < propertyNames.Length; i++)
                {
                    string propertyName = propertyNames[i];
                    PropertyInfo propertyInfo = type.GetProperty(propertyName, BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public);
					if (propertyInfo != null)
					{
						//[2009-12-03] [Minh Dam]: Convert data from type of changed value to type of property
						TypeConverter converter = TypeDescriptor.GetConverter(propertyInfo.PropertyType);
						object result = null;						
						try
						{
							if (values[i] != null)
								result = converter.ConvertFrom(values[i].ToString());
							else if (!(converter is NullableConverter))
							{
								result = CWXUtilities.GetDefaultValue(propertyInfo.PropertyType);
							}
						}
						catch
						{
							result = CWXUtilities.GetDefaultValue(propertyInfo.PropertyType);
						}

						try
						{
							propertyInfo.SetValue(domainBusinessObject, result, null);
						}
						catch //in case result is null and set to a property must not nullable, it will throw exception
						{
						}

						//propertyInfo.SetValue(domainBusinessObject, values[i], null);
					}
                }
            }
            AuditObject(domainBusinessObject as IDomainObject, action);
        }

        /// <summary>
        /// Audit Trail on single column and multiple rows.
        /// Purpose: it only used with SoftDelete data
        /// </summary>
        /// <param name="tableName">Changed table name.</param>
        /// <param name="primaryFieldName">Field which have primary key.</param>
        /// <param name="fieldName">Changed field name.</param>
        /// <param name="value">Changed data value of fieldName (parameter).</param>
        /// <param name="whereClause">Where clause with search criteria to select data to audit.</param>
        /// <history>
        ///     2008/06/30  [Khoa Dang]     Init version.
        ///     2008/08/11  [Binh Truong]   Add parameter comments.
        /// </history>
        public override void WriteAudit<TDomainObject>(string tableName, string primaryFieldName, string fieldName, string value, string whereClause)
        {
            string sql = string.Format("select {0},{1} from {2} where {3}", primaryFieldName, fieldName, tableName, whereClause);
            DataTable dt = SqlProvider.ExecuteDataSet(System.Data.CommandType.Text, sql).Tables[0];            
            CWXIdentity identity = Thread.CurrentPrincipal.Identity as CWXIdentity;
            string databaseName = GetCurrentWorkDBName();

            Collection<CWXAuditTrail> trails = new Collection<CWXAuditTrail>();
            foreach (DataRow row in dt.Rows)
            {
                CWXAuditTrail trail = new CWXAuditTrail();
                trail.Action = CWXAuditAction.Edit;
                trail.EmployeeID = identity == null ? 0 : identity.UserID;
                trail.ChangedTable = tableName;
                trail.RowID = row[primaryFieldName].ToString();
                trail.ChangedField = fieldName;
                trail.OriginalData = row[fieldName] is DBNull ? string.Empty : row[fieldName].ToString();
                trail.ChangedData = value;

                if (string.Compare(trail.OriginalData, trail.ChangedData, true) != 0)
                    trails.Add(trail);
            }
            AddTrail(trails);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Fills data from the given reader into an instant of TDomainObject which is returned.
        /// </summary>
        /// <typeparam name="TDomainObject"></typeparam>
        /// <param name="reader">System.Data.IDataReader</param>
        /// <returns>Instant of type of TDomainObject</returns>
        private TDomainObject FillFromReader<TDomainObject>(IDataReader reader) where TDomainObject : class, new()
        {
            TableMappingInfo tableInfo = MappingProvider.GetTableMappingInfo(typeof(TDomainObject));
            TDomainObject domainObject = new TDomainObject();
            if (reader.Read())
            {
                foreach (FieldMappingInfo fieldInfo in tableInfo.FieldMappings)
                {
                    object propertyValue = reader.GetValue(reader.GetOrdinal(fieldInfo.DBFieldName));
                    PropertyInfo propertyInfo = typeof(TDomainObject).GetProperty(fieldInfo.ObjectFieldName);
                    propertyInfo.SetValue(domainObject, propertyValue, null);
                }
            }
            reader.Close();

            return domainObject;
        }

        /// <summary>
        /// Get current working database name.
        /// </summary>
        /// <history>
        ///     2008/07/30  [Binh Truong]   Init version.
        /// </history>
        private string GetCurrentWorkDBName()
        {
            string databaseName = string.Empty;
            CWXIdentity identity = Thread.CurrentPrincipal.Identity as CWXIdentity;
            if (identity != null)
                databaseName = identity.DbConnectionName;

            return databaseName;
        }

        private bool CanAudit(string tableName)
        {
            object retValue = DataProvider.ExecuteScalar(new object[] { tableName }, "CWX_CanAudit");
            if (retValue == null)
                return false;

            return Convert.ToBoolean(retValue);
        }
                
        #endregion
    }
}
