using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Collections.Specialized;

using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Logging;
using Microsoft.Practices.EnterpriseLibrary.Logging.Filters;
using Microsoft.Practices.EnterpriseLibrary.Logging.Configuration;

using CWX.Core.Common.Logging;

namespace CWX.Core.Providers.Logging
{
    public class CWXELLogProvider: CWXLogProvider
    {
        #region Fields

        private string _applicationName;

        #endregion

        #region Properties

        public override string ApplicationName
        {
            get
            {
                return _applicationName;
            }
            set
            {
                _applicationName = value;
            }
        }

        #endregion

        #region Constructor
        public CWXELLogProvider()
        {            
        }
        #endregion

        #region Initialize

        public override void Initialize(string name, NameValueCollection config)
        {
            if (config == null)
                throw new ArgumentNullException("config");

            if (string.IsNullOrEmpty(name))
                name = "CwxLogProvider";

            if (string.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "CWX Log Provider.");
            }

            base.Initialize(name, config);

            if (config["applicationName"] == null || config["applicationName"].Trim() == "")
            {
                _applicationName = System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath;
            }
            else
            {
                _applicationName = config["applicationName"];
            }            
        }

        #endregion

        #region Log-related Properties or Methods
        public override LogWriter Writer
        {
            get 
            {
                return Logger.Writer;
            }
        }

        public override void FlushContextItems()
        {
            Logger.FlushContextItems();
        }

        public override ILogFilter GetFilter(string name)
        {
            return Logger.GetFilter(name);
        }

        public override bool IsLoggingEnabled()
        {
            return Logger.IsLoggingEnabled();
        }

        public override void SetContextItem(object key, object value)
        {
            Logger.SetContextItem(key, value);
        }

        public override bool ShouldLog(LogEntry log)
        {
            return Logger.ShouldLog(log);
        }

        public override void Write(LogEntry log)
        {
            Logger.Write(log);            
        }
        //
        // Summary:
        //     Write a new log entry to the default category.
        //
        // Parameters:
        //   message:
        //     Message body to log. Value from ToString() method from message object.
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public override void Write(object message)
        {
            Logger.Write(message);
        }

        public override void Write(object message, ICollection<string> categories)
        {
            Logger.Write(message, categories);
        }

        public override void Write(object message, IDictionary<string, object> properties)
        {
            Logger.Write(message, properties);
        }

        public override void Write(object message, string category)
        {
            Logger.Write(message, category);
        }

        public override void Write(object message, ICollection<string> categories, IDictionary<string, object> properties)
        {
            Logger.Write(message, categories, properties);
        }

        public override void Write(object message, ICollection<string> categories, int priority)
        {
            Logger.Write(message, categories, priority);
        }

        public override void Write(object message, string category, IDictionary<string, object> properties)
        {
            Logger.Write(message, category, properties);
        }

        public override void Write(object message, string category, int priority)
        {
            Logger.Write(message, category, priority);
        }

        public override void Write(object message, ICollection<string> categories, int priority, IDictionary<string, object> properties)
        {
            Logger.Write(message, categories, priority, properties);
        }

        public override void Write(object message, ICollection<string> categories, int priority, int eventId)
        {
            Logger.Write(message, categories, priority, eventId);
        }

        public override void Write(object message, string category, int priority, IDictionary<string, object> properties)
        {
            Logger.Write(message, category, priority, properties);
        }

        public override void Write(object message, string category, int priority, int eventId)
        {
            Logger.Write(message, category, priority, eventId);
        }

        public override void Write(object message, ICollection<string> categories, int priority, int eventId, TraceEventType severity)
        {
            Logger.Write(message, categories, priority, eventId, severity);
        }

        public override void Write(object message, string category, int priority, int eventId, TraceEventType severity)
        {
            Logger.Write(message, category, priority, eventId, severity);
        }

        public override void Write(object message, ICollection<string> categories, int priority, int eventId, TraceEventType severity, string title)
        {
            Logger.Write(message, categories, priority, eventId, severity, title);
        }

        public override void Write(object message, string category, int priority, int eventId, TraceEventType severity, string title)
        {
            Logger.Write(message, category, priority, eventId, severity, title);
        }

        public override void Write(object message, ICollection<string> categories, int priority, int eventId, TraceEventType severity, string title, IDictionary<string, object> properties)
        {
            Logger.Write(message, categories, priority, eventId, severity, title,properties);
        }

        public override void Write(object message, string category, int priority, int eventId, TraceEventType severity, string title, IDictionary<string, object> properties)
        {
            Logger.Write(message, category, priority, eventId, severity, title, properties);
        }
        #endregion
    }
}
