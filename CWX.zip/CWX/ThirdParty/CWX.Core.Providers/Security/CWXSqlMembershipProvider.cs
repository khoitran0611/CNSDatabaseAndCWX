using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Data.Common;
using System.Web.Security;

using CWX.Core.Common;
using CWX.Core.Common.Data;
using CWX.Core.Common.Data.Query;
using CWX.Core.Common.Security;
using CWX.Core.Common.Exceptions;
using System.Text;
using System.Security.Cryptography;
using System.Web.Configuration;
using CWX.Core.Common.Resource;
using System.Collections.ObjectModel;

namespace CWX.Core.Providers.Security
{
    public class CWXSqlMembershipProvider : CWXMembershipProvider
    {
        #region Fields

        private string _applicationName;
        private DataProviderFactory _dataProviderFactory;
        private string _encryptionMethod;
        #endregion

        #region Properties

        public DataProviderFactory DataProviderFactory
        {
            get
            {
                if (_dataProviderFactory == null)
                    _dataProviderFactory = new DataProviderFactory();
                return _dataProviderFactory;
            }
        }

        public override string ApplicationName
        {
            get
            {
                throw new NotSupportedException();
            }
            set
            {
                throw new NotSupportedException();
            }
        }

        public override int MaxInvalidPasswordAttempts
        {
            get { throw new NotSupportedException(); }
        }

        public override int MinRequiredNonAlphanumericCharacters
        {
            get { return 0; }
        }

        public override int MinRequiredPasswordLength
        {
            get { return 0; }
        }

        public override int PasswordAttemptWindow
        {
            get { throw new NotSupportedException(); }
        }

        public override MembershipPasswordFormat PasswordFormat
        {
            get
            {
                throw new NotSupportedException();
            }
        }

        public override string PasswordStrengthRegularExpression
        {
            get
            {
                throw new NotSupportedException();
            }
        }

        public override bool RequiresQuestionAndAnswer
        {
            get { throw new NotSupportedException(); }
        }

        public override bool RequiresUniqueEmail
        {
            get { throw new NotSupportedException(); }
        }

        public override bool EnablePasswordReset
        {
            get { throw new NotSupportedException(); }
        }

        public override bool EnablePasswordRetrieval
        {
            get { throw new NotSupportedException(); }
        }

        #endregion

        #region Initialize

        public CWXSqlMembershipProvider()
        {
        }

        public override void Initialize(string name, NameValueCollection config)
        {
            if (config == null)
                throw new ArgumentNullException("config");

            if (String.IsNullOrEmpty(name))
                name = "CwxSqlMemberShipProvider";

            if (string.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "CWX Sql Membership Provider.");
            }

            base.Initialize(name, config);

            if (config["applicationName"] == null || config["applicationName"].Trim() == "")
            {
                _applicationName = System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath;
            }
            else
            {
                _applicationName = config["applicationName"];
            }

            if (!string.IsNullOrEmpty(config["encryptionMethod"].ToString()))
            {
                _encryptionMethod = config["encryptionMethod"];
            }
        }

        #endregion
        
        #region Override Methods

        #region Password's Methods

        public override bool ChangePassword(string username, string oldPassword, string newPassword)
        {
            if (!ValidateUser(username, oldPassword))
                return false;
            return ChangePassword(username, newPassword);
        }

        public override bool ChangePassword(int userID, string newPassword)
        {
            if (string.IsNullOrEmpty(newPassword))
                return false;

            CWXPasswordPolicy passwordPolicy = CWXPasswordPolicyManager.ValidatePasswordSettingsAndReturnViolatedPolicy(newPassword, userID);
            if (passwordPolicy != null)
                throw new CWXPasswordPolicyException(passwordPolicy);

            string salt = GetSalt(userID).Trim();
            newPassword = EncryptPassword(newPassword, salt, 1);

            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                int updateByUserID = userID;
                if (System.Threading.Thread.CurrentPrincipal != null
                    && System.Threading.Thread.CurrentPrincipal.Identity != null
                    && System.Threading.Thread.CurrentPrincipal.Identity.IsAuthenticated)
                    updateByUserID = (System.Threading.Thread.CurrentPrincipal.Identity as CWXIdentity).UserID;

                context.SetCommandText("CWX_User_ChangePassword", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userID);
                context.AddParameter("@NewPassword", newPassword);
                context.AddParameter("@ChangePwdDate", DateTime.Now.ToUniversalTime());
                context.AddParameter("@UpdateByUserID", updateByUserID);

                return (context.RunNonQuery() > 0);
            }
        }

        public override bool ChangePassword(string username, string newPassword)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(newPassword))
                return false;

            int userID = GetIdentity(username);
            if (userID == 0)
                return false;
            return ChangePassword(userID, newPassword);           
        }

        /// <summary>
        /// Processes a request to reset the password of the given userID and newPassword 
        /// then resets ChangedPasswordDate and ChangePasswordCount for a membership user.
        /// </summary>
        /// <param name="userID">The userID to update the password for.</param>
        /// <param name="newPassword">The new password for the specified user.</param>
        /// <returns>true if the password was updated successfully; otherwise, false.</returns>
        public override bool CWXResetPassword(int userID, string newPassword)
        {
            if (string.IsNullOrEmpty(newPassword))
                return false;

            CWXPasswordPolicy passwordPolicy = CWXPasswordPolicyManager.ValidatePasswordSettingsAndReturnViolatedPolicy(newPassword, userID);
            if (passwordPolicy != null && passwordPolicy.Type != CWXPasswordPolicyConstant.FORCE_CHANGE_PASSWORD_ONLY_TWICE_IN_A_DAY)
                throw new CWXPasswordPolicyException(passwordPolicy);

            string salt = GetSalt(userID).Trim();
            newPassword = EncryptPassword(newPassword, salt, 1);

            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                int updateByUserID = userID;
                if (System.Threading.Thread.CurrentPrincipal != null
                    && System.Threading.Thread.CurrentPrincipal.Identity != null
                    && System.Threading.Thread.CurrentPrincipal.Identity.IsAuthenticated)
                    updateByUserID = (System.Threading.Thread.CurrentPrincipal.Identity as CWXIdentity).UserID;

                context.SetCommandText("CWX_User_ResetPassword", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userID);
                context.AddParameter("@NewPassword", newPassword);
                context.AddParameter("@UpdateByUserID", updateByUserID);

                return (context.RunNonQuery() > 0);
            }
        }
       
        /// <summary>
        /// Processes a request to reset the password of the given username and newPassword 
        /// then resets ChangedPasswordDate and ChangePasswordCount for a membership user.
        /// </summary>
        /// <param name="username">The user to update the password for.</param>
        /// <param name="newPassword">The new password for the specified user.</param>
        /// <returns>true if the password was updated successfully; otherwise, false.</returns>
        public override bool CWXResetPassword(string username, string newPassword)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(newPassword))
                return false;

            int userID = GetIdentity(username);
            if (userID == 0)
                return false;

            return CWXResetPassword(userID, newPassword);
        }

        /// <summary>
        /// Password encrypt algorithm of CWX version 6 and below.
        /// </summary>
        /// <param name="pass">Raw password string.</param>
        /// <param name="userID">UserID.</param>
        /// <returns>Encrypt password string.</returns>
        [Obsolete("This password encrypt algorithm is obsolete. Use the overload method 'string EncryptPassword(string pass, string salt, int passwordFormat)' instead.", false)]
        public override string EncryptPassword(string pass, int userID)
        {
            int dl, w;
            string cKey = " " + userID;
            string a = string.Empty;

            dl = 0;
            for (int i = 0; i < pass.Length; i++)
            {
                w = (int)pass[i] + (int)cKey.ToString()[dl];
                if (w > 126)
                    w -= 91;
                a += (char)w;

                dl++;
                if (dl >= cKey.ToString().Length)
                    dl = 0;
            }            
            return a;
            
        }

        public override string EncryptPassword(string pass, string salt, int passwordFormat)
        {
            if (passwordFormat == 0)
            {
                return pass;
            }
            byte[] bytes = Encoding.Unicode.GetBytes(pass);
            byte[] src = Convert.FromBase64String(salt);
            byte[] dst = new byte[src.Length + bytes.Length];
            byte[] inArray = null;
            Buffer.BlockCopy(src, 0, dst, 0, src.Length);
            Buffer.BlockCopy(bytes, 0, dst, src.Length, bytes.Length);
            if (passwordFormat == 1)
            {
                HashAlgorithm algorithm = HashAlgorithm.Create(_encryptionMethod);
                
                if ((algorithm == null))
                {
                    //RuntimeConfig.GetAppConfig().Membership.ThrowHashAlgorithmException();
                    throw new CWXException(CWXResourceManager.GetString(ResourceCategory.Errors, "User_WithoutEncryptionMethod"));                    
                }
                inArray = algorithm.ComputeHash(dst);
            }
            else
            {
                inArray = this.EncryptPassword(dst);
            }
            return Convert.ToBase64String(inArray);
            
        }

        #endregion

        #region MembershipUser

        public override bool ValidateUser(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                return false;

            MembershipUser user = GetUser(username, password);
            if (user != null)
                return true;

            return false;
        }

        public override MembershipUser GetUser(string username, string password)
        {            
            string salt = GetSalt(username).Trim();
            if (!string.IsNullOrEmpty(salt))
            {                
                string encryptedPassword = EncryptPassword(password, salt, 1);

                IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

                using (IDataExecutionContext context = dataProvider.BeginExecution())
                {
                    context.SetCommandText("CWX_User_SelectByUserNameAndPassword", CommandType.StoredProcedure);
                    context.AddParameter("@UserName", username);
                    context.AddParameter("@Password", encryptedPassword);

                    IDataReader reader = context.RunReader();
                    if (reader.Read())
                        return ProcessReader(reader);
                }
            }
            return null;
        }

        public override MembershipUser GetUser(string username, bool userIsOnline)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_SelectByUserName", CommandType.StoredProcedure);
                context.AddParameter("@UserName", username);

                IDataReader reader = context.RunReader();
                if (reader.Read())
                    return ProcessReader(reader);
            }
            return null;
        }

        public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_SelectByUserID", CommandType.StoredProcedure);
                context.AddParameter("@UserID", providerUserKey);

                IDataReader reader = context.RunReader();
                if (reader.Read())
                    return ProcessReader(reader);
            }
            return null;
        }

        public override string GetUserNameByEmail(string email)
        {
            throw new NotSupportedException();
        }

        public override MembershipUserCollection FindUsersByRole(int roleID)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_SelectByRole", CommandType.StoredProcedure);
                context.AddParameter("RoleID", roleID);

                IDataReader reader = context.RunReader();
                MembershipUserCollection userCollection = new MembershipUserCollection();
                while (reader.Read())
                {
                    MembershipUser user = ProcessReader(reader);
                    userCollection.Add(user);
                }
                return userCollection;
            }
        }

        public override MembershipUser CreateUser(string username, string password, string fullName, string email, string comment, int roleID,string salt)
        {
            int userID = GenerateNewUserID();

            password = EncryptPassword(password, salt, 1);
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_Insert", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userID);
                context.AddParameter("@UserName", username);
                context.AddParameter("@Password", password);
                context.AddParameter("@FullName", fullName);
                context.AddParameter("@Email", email);
                context.AddParameter("@Comment", comment);
                context.AddParameter("@RoleID", roleID);
                context.AddParameter("@Salt", salt);
                context.AddParameter("@CreatedDate", DateTime.Now);

                if (context.RunNonQuery() > 0)
                    return new MembershipUser(
                        this.Name,
                        username,
                        userID,
                        email,
                        string.Empty,
                        comment,
                        true,
                        false,
                        DateTime.MinValue,
                        DateTime.MinValue,
                        DateTime.MinValue,
                        DateTime.MinValue,
                        DateTime.MinValue
                        );
                return null;
            }
        }

        public override bool DeleteUser(string username, bool deleteAllRelatedData)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_DeleteByUserName", CommandType.StoredProcedure);
                context.AddParameter("@UserName", username);

                return (context.RunNonQuery() > 0);
            }
        }

        public override bool DeleteUser(int userID)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_DeleteByUserID", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userID);

                return (context.RunNonQuery() > 0);
            }
        }

        /// <summary>
        /// Deactive user by user ID.
        /// </summary>
        /// <history>
        ///     2008/08/15  [Binh Truong]   Init version.
        /// </history>
        public override bool DeactiveUser(int userID)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_DeactiveByUserID", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userID);

                return (context.RunNonQuery() > 0);
            }
        }

        /// <summary>
        /// Active user by user ID.
        /// </summary>
        /// <history>
        ///     2008/08/19  [Binh Truong]   Init version.
        /// </history>
        public override bool ActiveUser(int userID)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_ActiveByUserID", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userID);

                return (context.RunNonQuery() > 0);
            }
        }

        /// <summary>
        /// Active all users.
        /// </summary>
        /// <history>
        ///     2008/08/19  [Binh Truong]   Init version.
        /// </history>
        public override bool ActiveAll()
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_ActiveAll", CommandType.StoredProcedure);

                return (context.RunNonQuery() > 0);
            }
        }

        public override bool UnlockAll()
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_UnlockAll", CommandType.StoredProcedure);

                return (context.RunNonQuery() > 0);
            }
        }

        public override bool UnlockUser(string userName)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_UnlockByUserName", CommandType.StoredProcedure);
                context.AddParameter("@UserName", userName);

                return (context.RunNonQuery() > 0);
            }
        }

        public override bool UnlockUser(int userID)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_UnlockByUserID", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userID);

                return (context.RunNonQuery() > 0);
            }
        }

        public override bool LockUser(string userName)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_LockByUserName", CommandType.StoredProcedure);
                context.AddParameter("@UserName", userName);

                return (context.RunNonQuery() > 0);
            }
        }

        public override bool LockUser(int userID)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_LockByUserID", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userID);

                return (context.RunNonQuery() > 0);
            }
        }

        public override void UpdateUser(int userID, string username, string fullName, string email, string comment, int roleID)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_Update", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userID);
                context.AddParameter("@UserName", username);
                context.AddParameter("@FullName", fullName);
                context.AddParameter("@Email", email);
                context.AddParameter("@Comment", comment);
                context.AddParameter("@RoleID", roleID);

                context.RunNonQuery();
            }
        }

        public override void UpdateUser(MembershipUser user)
        {
            throw new NotSupportedException();
        }

        public override int GetUserID(string userName)
        {
            return GetIdentity(userName);
        }

        public override int GetUserRoleID(int userID)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_GetRoleID", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userID);

                IDataReader reader = context.RunReader();
                if (reader.Read())
                    return reader.GetInt32(reader.GetOrdinal("RoleID"));
                return 0;
            }
        }

        public override DataSet GetLockedUserDataSet(int pageIndex, int pageSize, out int rowCount)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            return dataProvider.ExecuteDataSet("CWX_User_GetLockedUserList", pageSize, pageIndex, out rowCount);
        }

        #endregion

        #region CWXMembershipProvider

        /// <summary>
        /// Get user by permission.
        /// </summary>
        /// <param name="permission"></param>
        /// <returns>DataTable with fields: UserID, Fullname</returns>
        public override DataTable GetUserByPermission(CWXPermissionConstant permission)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_SelectByPermission", CommandType.StoredProcedure);
                context.AddParameter("@PermissionID", permission.GetHashCode());

                DataSet ds = context.RunDataSet();
                return ds.Tables[0];
            }
        }

        /// <summary>
        /// Update user last activity time.
        /// </summary>
        /// <remarks>
        /// The LastActivity will be updated repeatedly while user is working.
        /// </remarks>
        /// <history>
        ///     2008/07/11  [Binh Truong]   Init version.
		///		2008/11/21	[Minh Dam]		Add parameter 'Today'
        /// </history>
        public override void UpdateLastActivity(string username)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_Profiles_UpdateLastActivity", CommandType.StoredProcedure);
                context.AddParameter("Username", username);
                context.AddParameter("ApplicationName", "CWX");
				context.AddParameter("Today", DateTime.Now);

                context.RunNonQuery();
            }
        }

        /// <summary>
        /// Update user online status.
        /// </summary>
        /// <param name="userIsOnlineTimeWindow">
        /// The number of minutes after the last-activity date/time stamp for a user during 
        /// which the user is considered online.
        /// </param>
        /// <history>
        ///     2008/07/11  [Binh Truong]   Init version.
		///		2008/11/21	[Minh Dam]		Add parameter 'today'
        /// </history>
        public override void UpdateUserOnlineStatus(string username, int userIsOnlineTimeWindow)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_UpdateUserOnlineStatus", CommandType.StoredProcedure);
                context.AddParameter("username", username);
                context.AddParameter("userIsOnlineTimeWindow", userIsOnlineTimeWindow);
				context.AddParameter("today", DateTime.Now);

                context.RunNonQuery();
            }
        }

        /// <summary>
        /// Sets user online status.
        /// </summary>
        /// <history>
        ///     2008/07/14  [Binh Truong]   Init version.
		///		2008/11/21	[Minh Dam]		Add parameter 'Today'
        /// </history>
        public override void SetUserOnlineStatus(string username, bool isOnline)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_UpdateUserOnlineStatus", CommandType.StoredProcedure);
                context.AddParameter("Username", username);
                context.AddParameter("IsForceSetStatus", 1);
                context.AddParameter("IsSignOn", isOnline ? 1 : 0);
				context.AddParameter("Today", DateTime.Now);

                context.RunNonQuery();
            }
        }

        #region LoginLog

        /// <summary>
        /// Get LoginLogInfo.
        /// </summary>
        /// <history>
        ///     2008/08/12  [Binh Truong]   Init version.
        /// </history>
        public override LoginLogInfo GetLoginLogInfo(int userID, string dbConnectionName)
        {
            LoginLogInfo loginLogInfo = null;
            IDataProvider dataProvider = DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                string commandText = "CWX_LoginLog_Get";
                context.SetCommandText(commandText, CommandType.StoredProcedure);
                context.AddParameter("UserID", userID);
                context.AddParameter("DbConnectionName", dbConnectionName);
                IDataReader reader = context.RunReader(CommandBehavior.CloseConnection);
                if (reader.Read())
                    loginLogInfo = CreateLoginLogInfoFromReader(reader);
            }
            return loginLogInfo;
        }
        /// <summary>
        /// Get GetLoggedInUser.
        /// </summary>
        /// <history>
        ///     2008/09/06  [Thuy Nguyen]   Init version.
        /// </history>
        public override DataTable GetLoggedInUser(string employeeIDString, bool isGetBySupervisor, string dbConnectionName)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);
            
            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_GetLoggedInUser", CommandType.StoredProcedure);
                context.AddParameter("@EmployeeIDString", employeeIDString);
                context.AddParameter("@IsGetBySupervisor", isGetBySupervisor);
                context.AddParameter("@DBConnectionName", dbConnectionName);

                DataSet ds = context.RunDataSet();
                return ds.Tables[0];
            }           
        }

        /// <summary>
        /// Fill list LoginLogInfo.
        /// </summary>
        /// <history>
        ///     2008/08/26  [Binh Truong]   Init version.
        /// </history>
        public override Collection<LoginLogInfo> FillListLoginLogInfo(string dbConnectionName, int pageSize, int pageIndex, out int rowCount)
        {
            rowCount = 0;
            Collection<LoginLogInfo> loginLogInfoList = null;
            IDataProvider dataProvider = DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                string commandText = "CWX_LoginLog_GetListSignOn";
                context.SetCommandText(commandText, CommandType.StoredProcedure);
                context.AddParameter("DbConnectionName", dbConnectionName);
                context.AddParameter("Now", DateTime.Now);
                context.AddParameter("PageSize", pageSize);
                context.AddParameter("PageIndex", pageIndex);
                context.AddParameter("RowCount", rowCount, ParameterDirection.ReturnValue);
                IDataReader reader = context.RunReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    LoginLogInfo loginLogInfo = CreateLoginLogInfoFromReader(reader);
                    loginLogInfoList.Add(loginLogInfo);
                }
            }
            return loginLogInfoList;
        }

        /// <summary>
        /// Log login and working time information
        /// </summary>
        public override void LoginLog(int userID, DateTime loginDate, DateTime logoutDate, int minutesLoggedIn, string dbConnectionName)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_LoginLog_Insert", CommandType.StoredProcedure);
                context.AddParameter("UserID", userID);
                context.AddParameter("LoginTime", loginDate);
                context.AddParameter("LogoutTime", logoutDate);
                context.AddParameter("MinutesLoggedIn", minutesLoggedIn);
                context.AddParameter("DbConnectionName", dbConnectionName);

                context.RunNonQuery();
            }
        }

        public override void UpdateLoginLog(int userID, DateTime loginDate, DateTime logoutDate, int minutesLoggedIn, string dbConnectionName)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_LoginLog_Update", CommandType.StoredProcedure);
                context.AddParameter("UserID", userID);
                context.AddParameter("LoginTime", loginDate);
                context.AddParameter("LogoutTime", logoutDate);
                context.AddParameter("MinutesLoggedIn", minutesLoggedIn);
                context.AddParameter("DbConnectionName", dbConnectionName);

                context.RunNonQuery();
            }
        }

        public override void LoginAttemptsLog(string loginUser, DateTime loginDate, string ipAddress, string loginStatus, string reason)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_LoginAttemptsLog_Insert", CommandType.StoredProcedure);
                context.AddParameter("LoginUser", loginUser);
                context.AddParameter("LoginDateTime", loginDate);
                context.AddParameter("IPAddress", ipAddress);
                context.AddParameter("LoginStatus", loginStatus);
                context.AddParameter("Reason", reason);

                context.RunNonQuery();
            }
        }

        #endregion

        #endregion

        public override bool AssignCMS(string userIDs, string cmsID)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_ProfileData_AssignCMS", CommandType.StoredProcedure);
                context.AddParameter("UserIDs", userIDs);
                context.AddParameter("CmsID", cmsID);

                context.RunNonQuery();
            }

            return true;
        }


        #endregion

        #region Private Methods

        /// <summary>
        /// Get UserID by Username.
        /// </summary>
        /// <returns>
        /// Returns UserID (aka EmployeeID) if found, otherwise return 0.
        /// </returns>
        private int GetIdentity(string username)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_GetUserID", CommandType.StoredProcedure);
                context.AddParameter("@UserName", username);

                IDataReader reader = context.RunReader();
                if (reader.Read())
                    return reader.GetInt32(0);
                return 0;
            }
        }

        /// <summary>
        /// Get password salt by username.
        /// </summary>
        /// <returns>Returns password salt if found, otherwise, return string.Empty</returns>
        private string GetSalt(string username)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_GetSalt", CommandType.StoredProcedure);
                context.AddParameter("@UserName", username);

                IDataReader reader = context.RunReader();
                if (reader.Read())
                    return reader.GetString(0);
                return string.Empty;
            }
        }

        /// <summary>
        /// Get password salt by user ID.
        /// </summary>
        /// <returns>Returns password salt if found, otherwise, return string.Empty</returns>
        private string GetSalt(int userID)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_GetSalt_By_UserID", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userID.ToString());

                IDataReader reader = context.RunReader();
                if (reader.Read())
                    return reader.GetString(0);
                return string.Empty;
            }
        }

        /// <summary>
        /// Mapping data to MembershipUser object.
        /// </summary>
        /// <history>
        ///     2008/05/24  [Binh Truong]   Change instance of MembershipUser to CWXUser,  which is inherited from MembershipUser.
        ///                                 Add fullname data.
        /// </history>
        private MembershipUser ProcessReader(IDataReader reader)
        {
            string userName = reader.GetString(reader.GetOrdinal("UserName"));
            int userID = reader.GetInt32(reader.GetOrdinal("UserID"));
            string fullName = reader.GetString(reader.GetOrdinal("FullName"));
            string email = reader.IsDBNull(reader.GetOrdinal("Email")) ? string.Empty : reader.GetString(reader.GetOrdinal("Email"));
            string comment = reader.IsDBNull(reader.GetOrdinal("Comment")) ? string.Empty : reader.GetString(reader.GetOrdinal("Comment"));
            bool isLockedOut = reader.IsDBNull(reader.GetOrdinal("IsLockedOut")) ? false : reader.GetBoolean(reader.GetOrdinal("IsLockedOut"));
            bool signOn = reader.IsDBNull(reader.GetOrdinal("SignOn")) ? false : reader.GetBoolean(reader.GetOrdinal("SignOn"));
            DateTime lastPasswordChangedDate = reader.IsDBNull(reader.GetOrdinal("ChangePwdDate")) ? DateTime.MinValue : reader.GetDateTime(reader.GetOrdinal("ChangePwdDate"));
            DateTime createdDate = reader.IsDBNull(reader.GetOrdinal("CreatedDate")) ? DateTime.MinValue : reader.GetDateTime(reader.GetOrdinal("CreatedDate"));
            DateTime lastActivity = reader.IsDBNull(reader.GetOrdinal("LastActivity")) ? DateTime.MinValue : reader.GetDateTime(reader.GetOrdinal("LastActivity"));

            CWXUser user = new CWXUser(
                this.Name,      //Provider name
                userName,       //User name
                userID,         //Provider user identity                                        
                fullName,       //Fullname
                email,          //Email
                string.Empty,   //Password question
                comment,        //Comment
                true,           //Is Approved
                isLockedOut,    //Is user locked out
                createdDate, //Creation date
                DateTime.MinValue, //Last log in date
                lastActivity, //Last activity date
                lastPasswordChangedDate, //Last password changed date 
                DateTime.MinValue // Last lockout date
                );
            user.IsOnline = signOn;
            user.UserStatus = reader.GetString(reader.GetOrdinal("UserStatus"));
            user.ChangePwdOnLogon = reader.GetBoolean(reader.GetOrdinal("ChangePwdOnLogon"));
            return (MembershipUser)user;
        }

        private int GenerateNewUserID()
        {
            int newUserID = 0;

            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("SELECT MAX(UserID) FROM CWX_User");
                object result = context.RunScalar();
                if (result != null && result != DBNull.Value)
                    int.TryParse(result.ToString(), out newUserID);
            }
            newUserID++;

            return newUserID;
        }

        /// <summary>
        /// Create LoginLogInfo object from reader.
        /// </summary>
        /// <history>
        ///     2008/08/12  [Binh Truong]   Init version.
        /// </history>
        private LoginLogInfo CreateLoginLogInfoFromReader(IDataReader reader)
        {
            LoginLogInfo loginLogInfo = new LoginLogInfo();
            loginLogInfo.UserID = reader.GetInt32(reader.GetOrdinal("UserID"));
            loginLogInfo.LoginTime = reader.GetDateTime(reader.GetOrdinal("LoginTime"));
            loginLogInfo.LogoutTime = reader.GetDateTime(reader.GetOrdinal("LogoutTime"));
            loginLogInfo.MinutesLoggedIn = reader.GetInt32(reader.GetOrdinal("MinutesLoggedIn"));
            loginLogInfo.DBConnectionName = reader["DBConnectionName"].ToString();
            loginLogInfo.SignOn = reader.GetBoolean(reader.GetOrdinal("SignOn"));
            return loginLogInfo;
        }

        #endregion
    }
}
