using System;
using System.Text;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Security.Principal;

using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Security;
using Microsoft.Practices.EnterpriseLibrary.Security.Configuration;

using CWX.Core.Common.Security;

namespace CWX.Core.Providers.Security
{
    [ConfigurationElementType(typeof(CustomAuthorizationProviderData))]
    public class CWXSqlAuthorizationProvider : AuthorizationProvider
    {
        public CWXSqlAuthorizationProvider(NameValueCollection configurationItems)
        {
        }

        public override bool Authorize(IPrincipal principal, string context)
        {
            if (principal is CWXPrincipal)
                return ((CWXPrincipal)principal).Authorize((CWXPermissionConstant)Enum.Parse(typeof(CWXPermissionConstant), context)); ;
            return false;
        }
    }
}
