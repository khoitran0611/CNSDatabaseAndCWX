using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;

using CWX.Core.Common;
using CWX.Core.Common.Data;
using CWX.Core.Common.Data.Query;
using CWX.Core.Common.Security;
using CWX.Core.Providers.Data.Query;

namespace CWX.Core.Providers.Security
{
    public sealed class CWXSqlRoleProvider : CWXRoleProvider
    {
        #region Fields

        private string _applicationName;
        private readonly string _roleTableName = "CWX_Role";
        private DataProviderFactory _dataProviderFactory;

        #endregion

        #region Properties

        public override string ApplicationName
        {
            get
            {
                return _applicationName;
            }
            set
            {
                _applicationName = value;
            }
        }

        public DataProviderFactory DataProviderFactory
        {
            get
            {
                if (_dataProviderFactory == null)
                    _dataProviderFactory = new DataProviderFactory();
                return _dataProviderFactory;
            }
        }

        #endregion

        #region Constructor

        public CWXSqlRoleProvider()
        {
        }

        #endregion

        #region Public Methods

        #region Initialize

        public override void Initialize(string name, NameValueCollection config)
        {
            if (config == null)
                throw new ArgumentNullException("config");

            if (string.IsNullOrEmpty(name))
                name = "CwxSqlRoleProvider";

            if (string.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "CWX Sql Role provider.");
            }

            base.Initialize(name, config);

            if (config["applicationName"] == null || config["applicationName"].Trim() == "")
            {
                _applicationName = System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath;
            }
            else
            {
                _applicationName = config["applicationName"];
            }
        }

        #endregion

        #region Role's related methods

        public override CWXRole GetRole(int roleID)
        {
            CWXRole role = null;
            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlFillOneQueryBuilder queryBuilder = new SqlFillOneQueryBuilder(_roleTableName);
                queryBuilder.AddIdentity("RoleID", roleID);
                queryBuilder.AppendWhereClause("Status <> 'R'");

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                using (IDataReader reader = dataProvider.ExecuteReader(cmd))
                {

                    if (reader.Read())
                        role = ProcessReader(reader);
                }
            }
            
            return role;
        }

        public override CWXRole GetRole(string roleName)
        {
            CWXRole role = null;
            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlFillOneQueryBuilder queryBuilder = new SqlFillOneQueryBuilder(_roleTableName);
                queryBuilder.AddIdentity("RoleName", roleName);
                queryBuilder.AppendWhereClause("Status <> 'R'");

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                using (IDataReader reader = dataProvider.ExecuteReader(cmd))
                {

                    if (reader.Read())
                        role = ProcessReader(reader);
                }
            }
            return role;
        }

        public override List<CWXRole> GetRoles()
        {
            List<CWXRole> roles = null;

            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlFillListQueryBuilder queryBuilder = new SqlFillListQueryBuilder(_roleTableName);
                queryBuilder.AppendOrderByClause("RoleOrder");
                queryBuilder.AppendWhereClause("Status <> 'R'");

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                using (IDataReader reader = dataProvider.ExecuteReader(cmd))
                {

                    roles = new List<CWXRole>();
                    while (reader.Read())
                    {
                        CWXRole role = ProcessReader(reader);
                        if (role != null)
                            roles.Add(role);
                    }
                }
            }
            return roles;
        }

        public override List<CWXRole> GetRoles(int pageSize, int pageIndex, out int rowCount)
        {
            List<CWXRole> roles = null;

            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                string returnParameterName = "@RowCount";
                SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder("CWX_Role_GetList");
                queryBuilder.AddParameter("PageSize", pageSize);
                queryBuilder.AddParameter("PageIndex", pageIndex);
                queryBuilder.AppendReturnParameter(returnParameterName);

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                using (IDataReader reader = dataProvider.ExecuteReader(cmd))
                {
                    roles = new List<CWXRole>();
                    while (reader.Read())
                    {
                        CWXRole role = ProcessReader(reader);
                        if (role != null)
                            roles.Add(role);
                    }
                    reader.Close();
                    rowCount = int.Parse(cmd.Parameters[returnParameterName].Value.ToString());
                }
            }
            return roles;
        }

        public override void CreateRole(string roleName)
        {
            int roleOrder = GenerateNewRoleOrder();
            CreateRole(roleName, null);
        }

        public override void CreateRole(CWXRole role)
        {
            if (role != null)
                CreateRole(role.RoleName, role.Permissions);
        }

        public override void CreateRole(string roleName, Collection<CWXPermission> permissions)
        {
            if (RoleExists(roleName))
            {
                throw new Exception("Role name already exists.");
            }

            int roleID = GenerateNewRoleID();
            int roleOrder = GenerateNewRoleOrder();

            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlInsertQueryBuilder queryBuilder = new SqlInsertQueryBuilder(_roleTableName);
                queryBuilder.AddInsertColumn("RoleID", roleID);
                queryBuilder.AddInsertColumn("RoleName", roleName);
                queryBuilder.AddInsertColumn("RoleOrder", roleOrder);
                //queryBuilder.AddInsertColumn("RolePermissions", rolePermissions);

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                dataProvider.ExecuteNonQuery(cmd);
            }
            // TODO: need to check transaction
            if (permissions != null)
                foreach (CWXPermission permisson in permissions)
                    CWXPermissionManager.AddRolePermissions(roleID, permisson.PermissionType);
        }

        public override void UpdateRole(CWXRole role)
        {
            if (role == null)
                return;
            UpdateRole(role.RoleID, role.RoleName, role.RoleOrder, role.Permissions);
        }

        public override void UpdateRole(int roleID, string roleName, int roleOrder, Collection<CWXPermission> permissions)
        {
            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlUpdateQueryBuilder queryBuilder = new SqlUpdateQueryBuilder(_roleTableName);
                queryBuilder.AddIdentity("RoleID", roleID);
                queryBuilder.AddUpdateColumn("RoleName", roleName);
                queryBuilder.AddUpdateColumn("RoleOrder", roleOrder);
                //queryBuilder.AddUpdateColumn("RolePermissions", rolePermissions);

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                dataProvider.ExecuteNonQuery(cmd);
            }

            CWXPermissionManager.RemoveAllRolePermissions(roleID);
            // TODO: need to check transaction
            if (permissions != null)
                foreach (CWXPermission permisson in permissions)
                    CWXPermissionManager.AddRolePermissions(roleID, permisson.PermissionType);
        }

        public override void MoveUp(int roleID)
        {
            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder("CWX_Role_MoveUp");
                queryBuilder.AddParameter("@RoleID", roleID);

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                dataProvider.ExecuteNonQuery(cmd);
            }
        }

        public override void MoveDown(int roleID)
        {
            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder("CWX_Role_MoveDown");
                queryBuilder.AddParameter("@RoleID", roleID);

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                dataProvider.ExecuteNonQuery(cmd);
            }
        }

        public override void DeleteRole(CWXRole role)
        {
            if (role == null)
                return;
            DeleteRole(role.RoleID);
        }

        public override void DeleteRole(int roleID)
        {
            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlDeleteQueryBuilder queryBuilder = new SqlDeleteQueryBuilder(_roleTableName);
                queryBuilder.AddIdentity("RoleID", roleID);

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                dataProvider.ExecuteNonQuery(cmd);
            }
        }

        public override void SoftDeleteRole(CWXRole role)
        {
            if (role == null)
                return;
            SoftDeleteRole(role.RoleID);
        }

        public override void SoftDeleteRole(int roleID)
        {
            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlUpdateQueryBuilder queryBuilder = new SqlUpdateQueryBuilder(_roleTableName);
                queryBuilder.AddIdentity("RoleID", roleID);
                queryBuilder.AddUpdateColumn("Status", "R");

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                dataProvider.ExecuteNonQuery(cmd);
            }
        }

        /// <summary>
        /// Soft delete all roles.
        /// </summary>
        public override void SoftDeleteAll()
        {
            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlStoreProcedureQuerryBuilder queryBuilder = new SqlStoreProcedureQuerryBuilder("CWX_Role_SoftDeleteAll");
                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                dataProvider.ExecuteNonQuery(cmd);
            }
        }

        public override bool RoleExists(string roleName)
        {
            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlFillOneQueryBuilder queryBuilder = new SqlFillOneQueryBuilder(_roleTableName);
                queryBuilder.AddIdentity("RoleName", roleName);
                queryBuilder.AddSelectColumn("RoleID");

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                using (IDataReader reader = dataProvider.ExecuteReader(cmd))
                {
                    if (reader.Read() && !reader.IsDBNull(0))
                        return true;
                }
                return false;
            }
        }

        public override bool ApplyNewRolePermissions(int roleID)
        {
            IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = dataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_Role_ApplyNewRolePermissions", CommandType.StoredProcedure);
                context.AddParameter("@RoleID", roleID);
                context.AddParameter("@ReturnValue", null, ParameterDirection.ReturnValue);

                context.RunNonQuery();
                return context.GetParameterOutPutBooleanValue("@ReturnValue");
            }
        }

        #endregion

        #endregion

        #region Private Methods

        private int GenerateNewRoleID()
        {
            int newRoleId = 0;

            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlFillOneQueryBuilder queryBuilder = new SqlFillOneQueryBuilder(_roleTableName);
                queryBuilder.AddSelectColumn("MAX(RoleId) AS MaxID");

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                using (IDataReader reader = dataProvider.ExecuteReader(cmd))
                {
                    if (reader.Read() && !reader.IsDBNull(0))
                        newRoleId = reader.GetInt32(0);
                }
                return newRoleId + 1;
            }
        }

        private int GenerateNewRoleOrder()
        {
            int newRoleOrder = 0;

            using (IDataProvider dataProvider = this.DataProviderFactory.Create(ConnectionManager.CoreDatabaseElementName))
            {
                SqlFillOneQueryBuilder queryBuilder = new SqlFillOneQueryBuilder(_roleTableName);
                queryBuilder.AddSelectColumn("MAX(RoleOrder) AS MaxOrder");

                DbCommand cmd = dataProvider.CreateCommand(queryBuilder);
                using (IDataReader reader = dataProvider.ExecuteReader(cmd))
                {
                    if (reader.Read() && !reader.IsDBNull(0))
                        newRoleOrder = reader.GetInt32(0);
                }
                return newRoleOrder + 1;
            }
        }

        private CWXRole ProcessReader(IDataReader reader)
        {
            if (reader == null || reader.IsClosed)
                return null;

            CWXRole role = new CWXRole();
            role.RoleID = reader.GetInt32(reader.GetOrdinal("RoleID"));
            role.RoleName = reader.GetString(reader.GetOrdinal("RoleName"));
            role.RoleOrder = reader.GetInt32(reader.GetOrdinal("RoleOrder"));
            //if(!reader.IsDBNull(reader.GetOrdinal("RolePermissions")))
            //    role.RolePermissions = reader.GetString(reader.GetOrdinal("RolePermissions"));

            return role;
        }
        #endregion
    }
}
