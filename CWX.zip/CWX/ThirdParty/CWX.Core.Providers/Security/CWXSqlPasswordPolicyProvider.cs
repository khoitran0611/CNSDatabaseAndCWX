using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.Specialized;

using System.Text;
using System.Text.RegularExpressions;
using System.Web.Security;

using CWX.Core.Common;
using CWX.Core.Common.Data;
using CWX.Core.Common.Security;

namespace CWX.Core.Providers.Security
{
    public sealed class CWXSqlPasswordPolicyProvider : CWXPasswordPolicyProvider
    {
        #region Fields

        //private string _connectionString;
        private string _applicationName;

        #endregion

        #region Properties

        public override string ApplicationName
        {
            get
            {
                return _applicationName;
            }
            set
            {
                _applicationName = value;
            }
        }

        private IDataProvider _dataProvider;

        public IDataProvider DataProvider
        {   
            get 
            {
                if (_dataProvider == null)
                {
                    DataProviderFactory factory = new DataProviderFactory();
                    _dataProvider = factory.Create(ConnectionManager.CoreDatabaseElementName);
                }
                return _dataProvider; 
            }
            set 
            { 
                _dataProvider = value; 
            }
        }

        #endregion

        #region Constructor

        public CWXSqlPasswordPolicyProvider()
        {
        }

        #endregion

        #region Public Methods

        #region Initialize

        public override void Initialize(string name, NameValueCollection config)
        {
            if (config == null)
                throw new ArgumentNullException("config");

            if (string.IsNullOrEmpty(name))
                name = "CwxSqlPasswordPolicyProvider";

            if (string.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "CWX Sql Password Policy provider.");
            }

            base.Initialize(name, config);

            if (config["applicationName"] == null || config["applicationName"].Trim() == "")
            {
                _applicationName = System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath;
            }
            else
            {
                _applicationName = config["applicationName"];
            }


            //_connectionString = ConfigurationManager.ConnectionStrings[config["connectionStringName"]].ConnectionString;

            //if (string.IsNullOrEmpty(_connectionString))
            //{
            //    throw new Exception("Connection string cannot be blank.");
            //}
        }

        #endregion

        #region PasswordPolicy's related methods
        /// <summary>
        /// Validate the given rawPassword with the available password settings.
        /// </summary>
        /// <param name="rawPassword">An instant of System.String contains a raw password.</param>
        /// <param name="userId">Indentity of user whose password is validating.</param>
        /// <returns>Listlt;CWXPasswordPolicygt; that are violated by the validating password, otherwise null.</returns>
        public override List<CWXPasswordPolicy> ValidatePasswordSettingsAndReturnViolatedPolicyList(string rawPassword, object userId)
        {
            rawPassword = rawPassword.Trim();
            List<CWXPasswordPolicy> violatedPasswordPolicies = new List<CWXPasswordPolicy>();
            bool hasViolation = false;
            List<CWXPasswordPolicy> passwordPolicies = GetPasswordPolicies();
            foreach (CWXPasswordPolicy passwordPolicy in passwordPolicies)
            {
                hasViolation = !CheckMinimumPwdLength(rawPassword, passwordPolicy);
                hasViolation = hasViolation ? true : !CheckAtLeastOneNumeric(rawPassword, passwordPolicy);
                hasViolation = hasViolation ? true : !CheckAtLeastOneAlphabet(rawPassword, passwordPolicy);
                hasViolation = hasViolation ? true : !CheckAtLeastLowerUpperCase(rawPassword, passwordPolicy);
                hasViolation = hasViolation ? true : !CheckAtLeast4DifChars(rawPassword, passwordPolicy);
                hasViolation = hasViolation ? true : !CheckChangePwdOnlyTwiceADay(passwordPolicy, userId);                
                if (hasViolation)
                    violatedPasswordPolicies.Add(passwordPolicy);
            }
            return (violatedPasswordPolicies.Count > 0) ? violatedPasswordPolicies : null;            
        }
        /// <summary>
        /// Validate the given rawPassword whether it is a valid form of the available password settings.
        /// </summary>
        /// <param name="rawPassword">An instant of System.String contains a raw password.</param>
        /// <param name="userId">Indentity of user whose password is validating.</param>
        /// <returns>An instant of CWXPasswordPolicy that are violated by the validating password, otherwise null.</returns>
        public override CWXPasswordPolicy ValidatePasswordSettingsAndReturnViolatedPolicy(string rawPassword, object userId)
        {
            rawPassword = rawPassword.Trim();
            List<CWXPasswordPolicy> violatedPasswordPolicies = new List<CWXPasswordPolicy>();
            List<CWXPasswordPolicy> passwordPolicies = GetPasswordPolicies();
            foreach (CWXPasswordPolicy passwordPolicy in passwordPolicies)
            {
                if (!CheckMinimumPwdLength(rawPassword, passwordPolicy))
                    return passwordPolicy;
                if (!CheckAtLeastOneNumeric(rawPassword, passwordPolicy))
                    return passwordPolicy;
                if (!CheckAtLeastOneAlphabet(rawPassword, passwordPolicy))
                    return passwordPolicy;
                if (!CheckAtLeastLowerUpperCase(rawPassword, passwordPolicy))
                    return passwordPolicy;
                if (!CheckAtLeast4DifChars(rawPassword, passwordPolicy))
                    return passwordPolicy;
                if (!CheckChangePwdOnlyTwiceADay(passwordPolicy, userId))
                    return passwordPolicy;
            }
            return null;
        }
        /// <summary>
        /// Validate the given raw password whether its value and the previous passwords are same or not.
        /// </summary>
        /// <param name="newPassword">An instant of System.String contains a raw password.</param>
        /// <param name="userId">Indentity of user whose password is validating.</param>
        /// <param name="times">Times to get the previous password.</param>
        /// <returns>return true if the validating password and the previous passwords are same, otherwise return false.</returns>
        public override bool ValidatePreviousPasswordsAreSame(string newPassword, object userId, int times)
        {
            int id = 0;
            int.TryParse(userId.ToString(), out id);
            newPassword = newPassword.Trim();
            int result = 0;
            string salt = GetSalt(id).Trim();
            //string encryptedNewPassword = CWXMembershipManager.EncryptPassword(newPassword, Convert.ToInt32(id));
            string encryptedNewPassword = CWXMembershipManager.EncryptPassword(newPassword, salt,1);
            using (IDataExecutionContext context = DataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_PasswordPolicy_ValidatePreviousPasswordsAreSame", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userId);                
                context.AddParameter("@NewEncriptedPassword", encryptedNewPassword);
                context.AddParameter("@Times", times);                

                IDataReader reader = context.RunReader();                
                if(reader.Read())
                {
                    result = !reader.IsDBNull(reader.GetOrdinal("Result")) ? reader.GetInt32(reader.GetOrdinal("Result")) : 0;
                }
            }
            return (result == 1);
        }
        
        public override void UpdatePasswordPolicy(CWXPasswordPolicy passwordPolicy)
        {
            throw new Exception("The method or operation is not implemented.");
        }
        /// <summary>
        /// Update a selected passwordPolicy with the given passwordPolicyName and passwordPolicyValue.
        /// </summary>
        /// <param name="passwordPolicyType">Type of password policy.</param>
        /// <param name="passwordPolicyValue">Value of password policy.</param>
        /// <returns>Returns effected row(s)</returns>
        public override int UpdatePasswordPolicy(CWXPasswordPolicyConstant passwordPolicyType, string passwordPolicyValue)
        {
            int effectedRows = 0;
            using (IDataExecutionContext context = DataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_PasswordPolicy_UpdateValueByType", CommandType.StoredProcedure);
                context.AddParameter("@PasswordPolicyType", passwordPolicyType.GetHashCode());
                context.AddParameter("@PasswordPolicyValue", passwordPolicyValue);
                effectedRows = context.RunNonQuery();                
            }
            return effectedRows;
        }
        /// <summary>
        /// Get an instant of CWXPasswordPolicy that is available in the password setting module by the given passwordPolicyType.
        /// </summary>
        /// <param name="passwordPolicyType">CWXPasswordPolicyConstant</param>
        /// <returns>Returns an instant of CWXPasswordPolicy if it's available, otherwise returns null.</returns>
        public override CWXPasswordPolicy GetAvailPasswordPolicy(CWXPasswordPolicyConstant passwordPolicyType)
        {
            CWXPasswordPolicy passwordPolicy = null;
            using (IDataExecutionContext context = DataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_PasswordPolicy_SelectAvailPolicyByType", CommandType.StoredProcedure);
                context.AddParameter("@PasswordPolicyType", passwordPolicyType.GetHashCode());
                IDataReader reader = context.RunReader();
                if (reader.Read())
                {
                    passwordPolicy = ProcessReader(reader);
                }
            }
            return passwordPolicy;
        }

        public override List<CWXPasswordPolicy> GetPasswordPolicies()
        {
            List<CWXPasswordPolicy> passwordPolicies = new List<CWXPasswordPolicy>();
            using (IDataExecutionContext context = DataProvider.BeginExecution())
            {
                context.SetCommandText("SELECT * FROM CWX_PasswordPolicy", CommandType.Text);
                IDataReader reader = context.RunReader();
                while (reader.Read())
                {
                    CWXPasswordPolicy passwordPolicy = ProcessReader(reader);
                    if (passwordPolicy != null)
                        passwordPolicies.Add(passwordPolicy);
                }
            }
            return passwordPolicies;            
        }

        public override bool ValidateUserNotInUse(string userName, int availableDays)
        {

            int result = (int)DataProvider.ExecuteScalar(new object[] { userName, availableDays}, "CWX_UserNotInUse");
            
            return (result == 0);
        }

        public override bool NeedChangePassword(string userName, int availableDays)
        {

            int result = (int)DataProvider.ExecuteScalar(new object[] { userName, availableDays }, "CWX_NeedChangePassword");

            return (result == 1);
        }

		/// <summary>
		/// Checks the password expiry policy.
		/// </summary>
		/// <param name="lastPasswordChangedDate">The date that the password last to be changed.</param>
		/// <param name="renewPasswordDays">The number of days for renewing password.</param>
		/// <param name="forceChangePasswordDays">The number of days for forcing change password.</param>
		/// <returns>Returns a CWXForcePasswordExpiryConstant value</returns>
		public override CWXForcePasswordExpiryConstant CheckPasswordExpiry(DateTime lastPasswordChangedDate, int renewPasswordDays, int forceChangePasswordDays)
		{
			int pswExpiredRemainDays = GetPasswordExpiredRemainDays(lastPasswordChangedDate);
			if (pswExpiredRemainDays <= 0) // Force to change password
				return CWXForcePasswordExpiryConstant.FORCE_TO_CHANGE_PASSWORD;
			else if (pswExpiredRemainDays > 0 && pswExpiredRemainDays <= forceChangePasswordDays)
			{
				if (pswExpiredRemainDays == 1) // Your password expires today.
					return CWXForcePasswordExpiryConstant.PASSWORD_EXPIRES_TODAY;
				else // Your password will expire in ...
					return CWXForcePasswordExpiryConstant.PASSWORD_WILL_EXPIRE_IN;
			}
			else
				return CWXForcePasswordExpiryConstant.NO_NEED_TO_CHANGE_PASSWORD;
		}

		/// <summary>
		/// Gets the number of remain days that the password will expire.
		/// </summary>
		/// <param name="userName">The user name.</param>
		/// <returns></returns>
		public override int GetPasswordExpiredRemainDays(DateTime lastPasswordChangedDate)
		{
			CWXPasswordPolicy renewPasswordEvery = CWXPasswordPolicyManager.GetAvailPasswordPolicy(CWXPasswordPolicyConstant.RENEW_PASSWORD_EVERY);
			int pswExpiredRemainDays = 0;
			if (renewPasswordEvery != null)
			{
				int renewPasswordDays;
				if (int.TryParse(renewPasswordEvery.Value, out renewPasswordDays))
				{
					TimeSpan dayDiffFromChangePswDay = DateTime.Now.Subtract(lastPasswordChangedDate);
					pswExpiredRemainDays = renewPasswordDays - dayDiffFromChangePswDay.Days;
				}
			}

			return pswExpiredRemainDays;
		}
        public override int GetBeforePasswordExpiryDays()
        {
            int warningDays = 0;
            CWXPasswordPolicy beforePasswordExpiry = CWXPasswordPolicyManager.GetAvailPasswordPolicy(CWXPasswordPolicyConstant.BEFORE_PASSWORD_EXPIRY_WARNING);

            if (beforePasswordExpiry.Value != null)
                warningDays = Convert.ToInt32(beforePasswordExpiry.Value);

           return warningDays;

        }
        #endregion

        #endregion

        #region Private Methods
        private CWXPasswordPolicy ProcessReader(IDataReader reader)
        {
            if (reader == null || reader.IsClosed)
                return null;

            CWXPasswordPolicy PasswordPolicy = new CWXPasswordPolicy();
            PasswordPolicy.Name = reader.GetString(reader.GetOrdinal("PasswordPolicyName"));
            PasswordPolicy.Value = reader.GetString(reader.GetOrdinal("PasswordPolicyValue"));
            PasswordPolicy.Type = (CWXPasswordPolicyConstant)Enum.Parse(typeof(CWXPasswordPolicyConstant), reader.GetInt32(reader.GetOrdinal("PasswordPolicyType")).ToString());             
            return PasswordPolicy;
        }

        private void GetBriefUser(object userId, out DateTime changedPwdDate, out int changedPwdCount)
        {
            using (IDataExecutionContext context = DataProvider.BeginExecution())
            {
                context.SetCommandText("SELECT ChangePwdDate, ChangePwdCount FROM CWX_User WHERE UserID = @UserID", CommandType.Text);
                context.AddParameter("@UserID", userId);
                
                changedPwdDate = DateTime.Now;
                changedPwdCount = 0;

                IDataReader reader = context.RunReader();
                if (reader.Read())
                {
                    changedPwdDate = (reader["ChangePwdDate"] != DBNull.Value) ? reader.GetDateTime(reader.GetOrdinal("ChangePwdDate")) : DateTime.Now;
                    changedPwdCount = (reader["ChangePwdCount"] != DBNull.Value) ? reader.GetInt32(reader.GetOrdinal("ChangePwdCount")) : 0;
                }
            }
        }

        private bool CheckAtLeastLowerUpperCase(string password, CWXPasswordPolicy passwordPolicy)
        {
            if (passwordPolicy.Type == CWXPasswordPolicyConstant.FORCE_AT_LEAST_ONE_LOWER_AND_ONE_UPPER_CASE_ALPHA
                && passwordPolicy.Value.Equals("1"))
            {
                if ((Regex.IsMatch(password, @"[a-z]") && !Regex.IsMatch(password, @"[A-Z]"))
                    || (!Regex.IsMatch(password, @"[a-z]") && Regex.IsMatch(password, @"[A-Z]")))
                {
                    passwordPolicy.IsViolated = true;
                }
            }
            return !passwordPolicy.IsViolated;
        }

        private bool CheckAtLeastOneAlphabet(string password, CWXPasswordPolicy passwordPolicy)
        {
            if (passwordPolicy.Type == CWXPasswordPolicyConstant.FORCE_AT_LEAST_ONE_ALPHABET
                && passwordPolicy.Value.Equals("1"))
            {
                if (!Regex.IsMatch(password, @"[a-z,A-Z]"))
                {
                    passwordPolicy.IsViolated = true;
                }
            }
            return !passwordPolicy.IsViolated;
        }

        private bool CheckAtLeastOneNumeric(string password, CWXPasswordPolicy passwordPolicy)
        {
            if (passwordPolicy.Type == CWXPasswordPolicyConstant.FORCE_AT_LEAST_ONE_NUMERIC
                && passwordPolicy.Value.Equals("1"))
            {
                if (!Regex.IsMatch(password, @"[0-9]"))
                {
                    passwordPolicy.IsViolated = true;
                }
            }
            return !passwordPolicy.IsViolated;
        }

        private bool CheckMinimumPwdLength(string password, CWXPasswordPolicy passwordPolicy)
        {
            if (passwordPolicy.Type == CWXPasswordPolicyConstant.MINIMUM_PASSWORD_LENGTH)
            {
                if (password.Length < Convert.ToInt32(passwordPolicy.Value))
                {
                    passwordPolicy.IsViolated = true;
                }
            }
            return !passwordPolicy.IsViolated;
        }

        private bool CheckAtLeast4DifChars(string password, CWXPasswordPolicy passwordPolicy)
        {
            if (passwordPolicy.Type == CWXPasswordPolicyConstant.FORCE_AT_LEAST_4_DIFFERENT_CHARACTERS
                && passwordPolicy.Value.Equals("1"))
            {
                int counter = 0;
                string difChars = password;

                for (int i = 0; i < password.Length - 1; i++)
                {
                    string character = password.Substring(i, 1);
                    if (difChars.IndexOf(character) >= 0)
                    {
                        ++counter;
                        difChars = difChars.Replace(character, string.Empty);
                    }
                }
                if (counter < 4)
                    passwordPolicy.IsViolated = true;
            }
            return !passwordPolicy.IsViolated;
        }

        private bool CheckChangePwdOnlyTwiceADay(CWXPasswordPolicy passwordPolicy, object userId)
        {
            if (passwordPolicy.Type == CWXPasswordPolicyConstant.FORCE_CHANGE_PASSWORD_ONLY_TWICE_IN_A_DAY
                && passwordPolicy.Value.Equals("1"))
            {
                DateTime changedPwdDate;
                int changedPwdCount;
                GetBriefUser(userId, out changedPwdDate, out changedPwdCount);

                if (changedPwdDate.ToShortDateString().Equals(DateTime.Today.ToShortDateString()) && changedPwdCount >= 2)
                {
                    passwordPolicy.IsViolated = true;
                }
            }
            return !passwordPolicy.IsViolated;
        }
        private string GetSalt(string username)
        {           
            using (IDataExecutionContext context = DataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_GetSalt", CommandType.StoredProcedure);
                context.AddParameter("@UserName", username);

                IDataReader reader = context.RunReader();
                if (reader.Read())
                    return reader.GetString(0);
                return string.Empty;
            }
        }
        private string GetSalt(int userid)
        {
            using (IDataExecutionContext context = DataProvider.BeginExecution())
            {
                context.SetCommandText("CWX_User_GetSalt_By_UserID", CommandType.StoredProcedure);
                context.AddParameter("@UserID", userid);

                IDataReader reader = context.RunReader();
                if (reader.Read())
                    return reader.GetString(0);
                return string.Empty;
            }
        }
        #endregion

        
    }
}
