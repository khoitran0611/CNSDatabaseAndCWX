using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Specialized;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

using CWX.Core.Common.Security;
using CWX.Core.Common.Data;
using CWX.Core.Common;

namespace CWX.Core.Providers.Security
{
    public class CWXSqlPermissionProvider : CWXPermissionProvider
    {
        //private string _connectionString;

        public override void Initialize(string name, NameValueCollection config)
        {
            if (config == null)
                throw new ArgumentNullException("config");
            if (string.IsNullOrEmpty(name))
                name = "CWXSqlPermissionProvider";

            base.Initialize(name, config);

            //_connectionString = ConfigurationManager.ConnectionStrings[config["connectionStringName"]].ConnectionString;

            //if (string.IsNullOrEmpty(_connectionString))
            //{
            //    throw new Exception("Connection string cannot be empty.");
            //}
        }

        #region Permission Group

        public override CWXPermissionGroupConstant[] GetPermissionGroupContants()
        {
            List<CWXPermissionGroupConstant> permGroupList = new List<CWXPermissionGroupConstant>();
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_PermissionGroup_SelectAllId", CommandType.StoredProcedure);
                using (IDataReader reader = dataExeContext.RunReader())
                {
                    int permGroupID;
                    while (reader.Read())
                    {
                        permGroupID = reader.GetInt32(0);
                        permGroupList.Add((CWXPermissionGroupConstant)permGroupID);
                    }
                }
            }
            CWXPermissionGroupConstant[] permGroups = new CWXPermissionGroupConstant[permGroupList.Count];
            permGroupList.CopyTo(permGroups);

            return permGroups;
        }

        public override CWXPermissionGroup[] GetPermissionGroups()
        {
            List<CWXPermissionGroup> permGroupList = new List<CWXPermissionGroup>();
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_PermissionGroup_SelectAll", CommandType.StoredProcedure);
                using (IDataReader reader = dataExeContext.RunReader())
                {
                    int permGroupTypeID;
                    string permGroupName;
                    while (reader.Read())
                    {
                        permGroupTypeID = reader.GetInt32(reader.GetOrdinal("GroupID"));
                        permGroupName = reader.GetString(reader.GetOrdinal("GroupName"));
                        permGroupList.Add(new CWXPermissionGroup((CWXPermissionGroupConstant)permGroupTypeID, permGroupName));
                    }
                }
            }
            CWXPermissionGroup[] permGroups = new CWXPermissionGroup[permGroupList.Count];
            permGroupList.CopyTo(permGroups);

            return permGroups;
        }

        #endregion

        #region User Permission

        public override CWXPermission[] GetAllUserPermissions()
        {
            List<CWXPermission> permList = new List<CWXPermission>();
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_UserPermission_SelectAllPermissions", CommandType.StoredProcedure);                
                using (IDataReader reader = dataExeContext.RunReader())
                {
                    int permTypeID;
                    string permName;
                    while (reader.Read())
                    {
                        permTypeID = reader.GetInt32(reader.GetOrdinal("PermissionID"));
                        permName = reader.GetString(reader.GetOrdinal("PermissionDescription"));
                        permList.Add(new CWXPermission((CWXPermissionConstant)permTypeID, permName));
                    }
                }
            }
            CWXPermission[] availPermissions = new CWXPermission[permList.Count];
            permList.CopyTo(availPermissions);

            return availPermissions;
        }

        public override CWXPermission[] GetAvailUserPermissionsByPermissionGroup(int userID, CWXPermissionGroupConstant permissionGroupConstant)
        {
            List<CWXPermission> permList = new List<CWXPermission>();
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_UserPermission_SelectAvailPermissionsByGroup", CommandType.StoredProcedure);
                dataExeContext.AddParameter("@UserID", userID);
                dataExeContext.AddParameter("@PermissionGroupID", permissionGroupConstant.GetHashCode());
                using (IDataReader reader = dataExeContext.RunReader())
                {
                    int permTypeID;
                    string permName;
                    while (reader.Read())
                    {
                        permTypeID = reader.GetInt32(reader.GetOrdinal("PermissionID"));
                        permName = reader.GetString(reader.GetOrdinal("PermissionDescription"));
                        permList.Add(new CWXPermission((CWXPermissionConstant)permTypeID, permName));
                    }
                }
            }
            CWXPermission[] availPermissions = new CWXPermission[permList.Count];
            permList.CopyTo(availPermissions);

            return availPermissions;
        }

        public override CWXPermission[] GetGrantedUserPermissionsByPermissionGroup(int userID, CWXPermissionGroupConstant permissionGroupConstant)
        {
            List<CWXPermission> permList = new List<CWXPermission>();
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_UserPermission_SelectGrantedPermissionsByGroup", CommandType.StoredProcedure);
                dataExeContext.AddParameter("@UserID", userID);
                dataExeContext.AddParameter("@PermissionGroupID", permissionGroupConstant.GetHashCode());
                using (IDataReader reader = dataExeContext.RunReader())
                {
                    int permTypeID;
                    string permName;
                    while (reader.Read())
                    {
                        permTypeID = reader.GetInt32(reader.GetOrdinal("PermissionID"));
                        permName = reader.GetString(reader.GetOrdinal("PermissionDescription"));
                        permList.Add(new CWXPermission((CWXPermissionConstant)permTypeID, permName));
                    }
                }
            }
            CWXPermission[] grantedPermissions = new CWXPermission[permList.Count];
            permList.CopyTo(grantedPermissions);

            return grantedPermissions;
        }
        
        /// <summary>
        /// Get all user's permission
        /// </summary>
        /// <param name="userID">The user identity</param>
        /// <returns></returns>
        public override CWXPermissionConstant[] GetUserPermissions(int userID)
        {
            List<CWXPermissionConstant> permList = new List<CWXPermissionConstant>();

            //Add default permission to access the CWX system.
            permList.Add(CWXPermissionConstant.ACCESS_CWX_SYSTEM);

            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = provider.BeginExecution())
            {
                context.SetCommandText("SELECT [PermissionID] FROM [CWX_UserPermission] WHERE [UserID] = @UserID");
                context.AddParameter("@UserID", userID);

                using (IDataReader reader = context.RunReader())
                {
                    while (reader.Read())
                    {
                        int permissionID = reader.GetInt32(0);
                        permList.Add((CWXPermissionConstant)permissionID);
                    }
                }
            }

            CWXPermissionConstant[] permissions = new CWXPermissionConstant[permList.Count];
            permList.CopyTo(permissions);

            return permissions;
        }

        public override string[] GetAvailUserPermissionsString(int userID)
        {
            string[] availPermissions = new string[4] { "", "", "", "" };
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_UserPermission_SelectAvailPermissions", CommandType.StoredProcedure);
                dataExeContext.AddParameter("@UserID", userID);                
                using (IDataReader reader = dataExeContext.RunReader())
                {
                    int permID;
                    int permGroupID;
                    while (reader.Read())
                    {
                        //TODO: check DBNull                        
                        permID = reader.GetInt32(reader.GetOrdinal("PermissionID"));
                        permGroupID = reader.GetInt32(reader.GetOrdinal("GroupID"));
                        availPermissions[permGroupID - 1] += permID.ToString() + ",";
                    }
                    for (int i = 0; i < availPermissions.Length; i++)
                    {
                        if (availPermissions[i].LastIndexOf(",", availPermissions[i].Length - 1) > -1)
                        {
                            availPermissions[i] = availPermissions[i].Remove(availPermissions[i].Length - 1);
                        }
                    }
                }
                return availPermissions;
            }
        }

        public override string[] GetGrantedUserPermissionsString(int userID)
        {
            string[] grantedPermissions = new string[4] { "", "", "", "" };
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_UserPermission_SelectGrantedPermissions", CommandType.StoredProcedure);
                dataExeContext.AddParameter("@UserID", userID);
                using (IDataReader reader = dataExeContext.RunReader())
                {
                    int permID;
                    int permGroupID;
                    while (reader.Read())
                    {
                        //TODO: check DBNull                        
                        permID = reader.GetInt32(reader.GetOrdinal("PermissionID"));
                        permGroupID = reader.GetInt32(reader.GetOrdinal("GroupID"));
                        grantedPermissions[permGroupID - 1] += permID.ToString() + ",";
                    }
                    for (int i = 0; i < grantedPermissions.Length; i++)
                    {
                        if (grantedPermissions[i].LastIndexOf(",", grantedPermissions[i].Length - 1) > -1)
                        {
                            grantedPermissions[i] = grantedPermissions[i].Remove(grantedPermissions[i].Length - 1, 1);
                        }
                    }
                }
                return grantedPermissions;
            }
        }

        /// <summary>
        /// Assign a permission to a user.
        /// </summary>
        /// <param name="userID">The user identity who is assigned the permission</param>
        /// <param name="permission">The assigned permission</param>
        public override void AddUserPermissions(int userID, CWXPermissionConstant permission)
        {
            if (permission != CWXPermissionConstant.ACCESS_CWX_SYSTEM)
            {
                IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);

                using (IDataExecutionContext context = provider.BeginExecution())
                {
                    StringBuilder queryBuilder = new StringBuilder();
                    queryBuilder.Append("INSERT INTO [CWX_UserPermission]([UserID],[PermissionID]) ");
                    queryBuilder.Append("VALUES(@UserID, @PermissionID)");

                    context.SetCommandText(queryBuilder.ToString());
                    context.AddParameter("@UserID", userID);
                    context.AddParameter("@PermissionID", (int)permission);

                    context.RunNonQuery();
                }
            }
        }

        /// <summary>
        /// Remove a permission of user
        /// </summary>
        /// <param name="userID">The user identity whose permission is removed</param>
        /// <param name="permission">The removed permission</param>
        public override void RemoveUserPermissions(int userID, CWXPermissionConstant permission)
        {
            if (permission != CWXPermissionConstant.ACCESS_CWX_SYSTEM)
            {
                IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);

                using (IDataExecutionContext context = provider.BeginExecution())
                {
                    StringBuilder queryBuilder = new StringBuilder();
                    queryBuilder.Append("DELETE FROM [CWX_UserPermission] ");
                    queryBuilder.Append("WHERE [UserID] = @UserID AND [PermissionID] = @PermissionID");

                    context.SetCommandText(queryBuilder.ToString());
                    context.AddParameter("@UserID", userID);
                    context.AddParameter("@PermissionID", (int)permission);
                    context.RunNonQuery();
                }
            }
        }

        public override void RemoveAllUserPermissions(int userID)
        {            
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = provider.BeginExecution())
            {
                StringBuilder queryBuilder = new StringBuilder();
                queryBuilder.Append("DELETE FROM [CWX_UserPermission] ");
                queryBuilder.Append("WHERE [UserID] = @UserID");

                context.SetCommandText(queryBuilder.ToString());
                context.AddParameter("@UserID", userID);                    
                context.RunNonQuery();
            }
        }

        #endregion

        #region Role Permission

        public override CWXPermission[] GetAllPermissions()
        {
            return GetAllUserPermissions();
        }

        public override CWXPermission[] GetAvailRolePermissionsByPermissionGroup(int roleID, CWXPermissionGroupConstant permissionGroupConstant)
        {
            List<CWXPermission> permList = new List<CWXPermission>();
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_RolePermission_SelectAvailPermissionsByGroup", CommandType.StoredProcedure);
                dataExeContext.AddParameter("@RoleID", roleID);
                dataExeContext.AddParameter("@PermissionGroupID", permissionGroupConstant.GetHashCode());
                using (IDataReader reader = dataExeContext.RunReader())
                {
                    int permTypeID;
                    string permName;
                    while (reader.Read())
                    {
                        permTypeID = reader.GetInt32(reader.GetOrdinal("PermissionID"));
                        permName = reader.GetString(reader.GetOrdinal("PermissionDescription"));
                        permList.Add(new CWXPermission((CWXPermissionConstant)permTypeID, permName));
                    }
                }
            }
            CWXPermission[] availPermissions = new CWXPermission[permList.Count];
            permList.CopyTo(availPermissions);

            return availPermissions;
        }

        public override CWXPermission[] GetGrantedRolePermissionsByPermissionGroup(int roleID, CWXPermissionGroupConstant permissionGroupConstant)
        {
            List<CWXPermission> permList = new List<CWXPermission>();
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_RolePermission_SelectGrantedPermissionsByGroup", CommandType.StoredProcedure);
                dataExeContext.AddParameter("@RoleID", roleID);
                dataExeContext.AddParameter("@PermissionGroupID", permissionGroupConstant.GetHashCode());
                using (IDataReader reader = dataExeContext.RunReader())
                {
                    int permTypeID;
                    string permName;
                    while (reader.Read())
                    {
                        permTypeID = reader.GetInt32(reader.GetOrdinal("PermissionID"));
                        permName = reader.GetString(reader.GetOrdinal("PermissionDescription"));
                        permList.Add(new CWXPermission((CWXPermissionConstant)permTypeID, permName));
                    }
                }
            }
            CWXPermission[] grantedPermissions = new CWXPermission[permList.Count];
            permList.CopyTo(grantedPermissions);

            return grantedPermissions;
        }

        /// <summary>
        /// Get all role's permission
        /// </summary>
        /// <param name="roleID">The role identity</param>
        /// <returns></returns>
        public override CWXPermissionConstant[] GetRolePermissions(int roleID)
        {
            List<CWXPermissionConstant> permList = new List<CWXPermissionConstant>();

            //Add default permission to access the CWX system.
            permList.Add(CWXPermissionConstant.ACCESS_CWX_SYSTEM);

            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = provider.BeginExecution())
            {
                context.SetCommandText("SELECT [PermissionID] FROM [CWX_RolePermission] WHERE [RoleID] = @RoleID");
                context.AddParameter("@RoleID", roleID);

                using (IDataReader reader = context.RunReader())
                {
                    while (reader.Read())
                    {
                        int permissionID = reader.GetInt32(0);
                        permList.Add((CWXPermissionConstant)permissionID);
                    }
                }
            }

            CWXPermissionConstant[] permissions = new CWXPermissionConstant[permList.Count];
            permList.CopyTo(permissions);

            return permissions;
        }

        public override string[] GetAvailRolePermissionsString(int roleID)
        {
            string[] availPermissions = new string[4] { "", "", "" , "" };
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_RolePermission_SelectAvailPermissions", CommandType.StoredProcedure);
                dataExeContext.AddParameter("@RoleID", roleID);
                using (IDataReader reader = dataExeContext.RunReader())
                {
                    int permID;
                    int permGroupID;
                    while (reader.Read())
                    {
                        //TODO: check DBNull                        
                        permID = reader.GetInt32(reader.GetOrdinal("PermissionID"));
                        permGroupID = reader.GetInt32(reader.GetOrdinal("GroupID"));
                        availPermissions[permGroupID - 1] += permID.ToString() + ",";
                    }
                    for (int i = 0; i < availPermissions.Length; i++)
                    {
                        if (availPermissions[i].LastIndexOf(",", availPermissions[i].Length - 1) > -1)
                        {
                            availPermissions[i] = availPermissions[i].Remove(availPermissions[i].Length - 1);
                        }
                    }
                }
                return availPermissions;
            }
        }

        public override string[] GetGrantedRolePermissionsString(int roleID)
        {
            string[] grantedPermissions = new string[4] { "", "", "", "" };
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_RolePermission_SelectGrantedPermissions", CommandType.StoredProcedure);
                dataExeContext.AddParameter("@RoleID", roleID);
                using (IDataReader reader = dataExeContext.RunReader())
                {
                    int permID;
                    int permGroupID;
                    while (reader.Read())
                    {
                        //TODO: check DBNull                        
                        permID = reader.GetInt32(reader.GetOrdinal("PermissionID"));
                        permGroupID = reader.GetInt32(reader.GetOrdinal("GroupID"));
                        grantedPermissions[permGroupID - 1] += permID.ToString() + ",";
                    }
                    for (int i = 0; i < grantedPermissions.Length; i++)
                    {
                        if (grantedPermissions[i].LastIndexOf(",", grantedPermissions[i].Length - 1) > -1)
                        {
                            grantedPermissions[i] = grantedPermissions[i].Remove(grantedPermissions[i].Length - 1, 1);
                        }
                    }
                }
                return grantedPermissions;
            }
        }

        /// <summary>
        /// Assign a permission to a role.
        /// </summary>
        /// <param name="roleID">The role identity who is assigned the permission</param>
        /// <param name="permission">The assigned permission</param>
        public override void AddRolePermissions(int roleID, CWXPermissionConstant permission)
        {
            if (permission != CWXPermissionConstant.ACCESS_CWX_SYSTEM)
            {
                IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);

                using (IDataExecutionContext context = provider.BeginExecution())
                {
                    StringBuilder queryBuilder = new StringBuilder();
                    queryBuilder.Append("INSERT INTO [CWX_RolePermission]([RoleID],[PermissionID]) ");
                    queryBuilder.Append("VALUES(@RoleID, @PermissionID)");

                    context.SetCommandText(queryBuilder.ToString());
                    context.AddParameter("@RoleID", roleID);
                    context.AddParameter("@PermissionID", (int)permission);

                    context.RunNonQuery();
                }
            }
        }

        /// <summary>
        /// Remove a permission of role
        /// </summary>
        /// <param name="roleID">The role identity whose permission is removed</param>
        /// <param name="permission">The removed permission</param>
        public override void RemoveRolePermissions(int roleID, CWXPermissionConstant permission)
        {
            if (permission != CWXPermissionConstant.ACCESS_CWX_SYSTEM)
            {
                IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);

                using (IDataExecutionContext context = provider.BeginExecution())
                {
                    StringBuilder queryBuilder = new StringBuilder();
                    queryBuilder.Append("DELETE FROM [CWX_RolePermission] ");
                    queryBuilder.Append("WHERE [RoleID] = @RoleID AND [PermissionID] = @PermissionID");

                    context.SetCommandText(queryBuilder.ToString());
                    context.AddParameter("@RoleID", roleID);
                    context.AddParameter("@PermissionID", (int)permission);
                    context.RunNonQuery();
                }
            }
        }

        public override void RemoveAllRolePermissions(int roleID)
        {
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);

            using (IDataExecutionContext context = provider.BeginExecution())
            {
                StringBuilder queryBuilder = new StringBuilder();
                queryBuilder.Append("DELETE FROM [CWX_RolePermission] ");
                queryBuilder.Append("WHERE [RoleID] = @RoleID");

                context.SetCommandText(queryBuilder.ToString());
                context.AddParameter("@RoleID", roleID);
                context.RunNonQuery();
            }
        }

        #endregion
    }
}
