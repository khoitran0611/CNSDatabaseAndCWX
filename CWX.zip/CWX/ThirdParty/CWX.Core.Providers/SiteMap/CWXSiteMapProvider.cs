using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration.Provider;
using System.Web;

using CWX.Core.Common;
using CWX.Core.Common.UI.SiteMap;

namespace CWX.Core.Providers.SiteMap
{
    /// <summary>
    /// Implements a <see cref="SiteMapProvider"/> that build the <see cref="SiteMap"/> based on
    /// the nodes published by the modules using the <see cref="ISiteMapBuilderService"/>.
    /// </summary>
    public class CWXSiteMapProvider : StaticSiteMapProvider
    {
        private ISiteMapBuilderService _siteMapBuilder;
        private SiteMapNode _rootNode;
        private object _lockObject = new object();
        private bool _isInitialized = false;

        /// <summary>
        /// Gets or sets the <see cref="ISiteMapBuilderService"/> to use when building the <see cref="SiteMap"/>.
        /// </summary>
        public ISiteMapBuilderService SiteMapBuilder
        {
            get
            {
                if (_siteMapBuilder == null)
                    _siteMapBuilder = new SiteMapBuilderService();

                return _siteMapBuilder;
            }
            set
            {
                _siteMapBuilder = value;
            }
        }

        /// <summary>
        /// Builds the <see cref="SiteMap"/> managed by the provider.
        /// </summary>
        /// <returns>The root <see cref="SiteMapNode"/> for the provider.</returns>
        public override SiteMapNode BuildSiteMap()
        {
            if (!_isInitialized)
            {
                lock (_lockObject)
                {
                    if (!_isInitialized)
                    {
                        SiteMapNodeInfo rootNodeInfo = SiteMapBuilder.RootNode;
                        _rootNode = CreateSiteMapNode(rootNodeInfo);
                        AddChildNodes(_rootNode, SiteMapBuilder.GetChildren(rootNodeInfo.Key));

                        _isInitialized = true;
                    }
                }
            }
            return _rootNode;
        }

        private void AddChildNodes(SiteMapNode parent, ReadOnlyCollection<SiteMapNodeInfo> children)
        {
            if (children.Count > 0)
            {
                foreach (SiteMapNodeInfo child in children)
                {
                    SiteMapNode childNode = CreateSiteMapNode(child);
                    AddNode(childNode, parent);
                    AddChildNodes(childNode, SiteMapBuilder.GetChildren(child.Key));
                }
            }
        }

        private SiteMapNode CreateSiteMapNode(SiteMapNodeInfo nodeInfo)
        {
            return new SiteMapNode(this,
                nodeInfo.Key,
                nodeInfo.Url,
                nodeInfo.Title,
                nodeInfo.Description,
                nodeInfo.Roles,
                nodeInfo.Attributes,
                nodeInfo.ExplicitResourcesKey,
                nodeInfo.ImplicitResourceKey);
        }

        /// <summary>
        /// Retrieves the root node of all the nodes that are currently managed by the provider.
        /// </summary>
        /// <returns></returns>
        protected override SiteMapNode GetRootNodeCore()
        {
            return BuildSiteMap();
        }

        /// <summary>
        /// Determines whether the specified  <see cref="SiteMapNode"/> object can be 
        /// viewed by the user in the specified context.
        /// </summary>
        /// <param name="context">The <see cref="HttpContext"/> that contains user information.</param>
        /// <param name="node">The <see cref="SiteMapNode"/> that is requested by the user.</param>
        /// <returns><see langword="true"/>	if the node can be viewed by the user; otherwise, <see langword="false"/>.</returns>
        /// <remarks>This function does not support. So, always return true.</remarks>
        public override bool IsAccessibleToUser(HttpContext context, SiteMapNode node)
        {
            return true;
        }

    }
}
