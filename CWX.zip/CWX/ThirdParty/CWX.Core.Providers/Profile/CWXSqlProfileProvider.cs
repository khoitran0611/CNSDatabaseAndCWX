using System;
using System.Web.Profile;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using CWX.Core.Common.Data;
using CWX.Core.Common;


namespace CWX.Core.Providers.Profile
{
    public class CWXSqlProfileProvider : ProfileProvider
    {
        #region Properties

        private string applicationName;
        /// <summary>
        /// Name of the application.
        /// </summary>
        /// <returns>String</returns>
        public override string ApplicationName
        {
            get
            {
                return applicationName;
            }

            set
            {
                applicationName = value;
            }
        }
        #endregion

        #region Implemented Abstract Methods from ProfileProvider
        /// <summary>
        /// Initialize the provider.
        /// </summary>
        /// <param name="name">Name of the provider.</param>
        /// <param name="config">Configuration settings.</param>
        /// <remarks></remarks>
        public override void Initialize(
         string name,
         System.Collections.Specialized.NameValueCollection config
        )
        {

            // Initialize values from web.config.
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            if ((name == null) || (name.Length == 0))
            {
                name = "CWXSqlProfileProvider";
            }

            if (String.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "Custom Profile provider");
            }

            // Initialize the abstract base class.
            base.Initialize(name, config);

            if ((config["applicationName"] == null) || String.IsNullOrEmpty(config["applicationName"]))
            {
                applicationName = System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath;
            }
            else
            {
                applicationName = config["applicationName"];
            }
        }

        /// <summary>
        /// Get the property values for the user profile.
        /// </summary>
        /// <param name="context">Application context.</param>
        /// <param name="settingsProperties">Profile property settings.</param>
        /// <returns>Property setting values.</returns>
        /// <history>
        ///     2008/11/17  [Binh Truong]   Add property "CmsID".
        /// </history>
        public override SettingsPropertyValueCollection GetPropertyValues(SettingsContext context, SettingsPropertyCollection collection)
        {
            string userName = context["UserName"].ToString();
            bool isAuthenticated = Convert.ToBoolean(context["IsAuthenticated"]);

            SettingsPropertyValueCollection settingsValues = new SettingsPropertyValueCollection();

            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_ProfileData_Select", CommandType.StoredProcedure);
                dataExeContext.AddParameter("@UserName", userName);
                dataExeContext.AddParameter("@ApplicationName", applicationName);
                dataExeContext.AddParameter("@IsAnonymous", !isAuthenticated);

                using (IDataReader reader = dataExeContext.RunReader(CommandBehavior.SingleRow))
                {
                    if (reader.Read())
                    {
                        foreach (SettingsProperty property in collection)
                        {
                            SettingsPropertyValue settingsPropertyValue = new SettingsPropertyValue(property);

                            switch (property.Name)
                            {
                                case "Culture":
                                    settingsPropertyValue.PropertyValue = reader.GetValue(reader.GetOrdinal("Culture"));
                                    break;

                                case "DbConnectionName":
                                    settingsPropertyValue.PropertyValue = reader.GetValue(reader.GetOrdinal("DbConnectionName"));
                                    break;

                                case "CmsID":
                                    settingsPropertyValue.PropertyValue = reader.GetValue(reader.GetOrdinal("CmsID"));
                                    if (settingsPropertyValue.PropertyValue is System.DBNull)
                                        settingsPropertyValue.PropertyValue = string.Empty;
                                    break;

                                default:
                                    throw new Exception("Unsupported property.");
                            }

                            settingsValues.Add(settingsPropertyValue);
                        }
                    }
                    else
                    {
                        // Get default value properties
                        foreach (SettingsProperty property in collection)
                        {
                            SettingsPropertyValue settingsPropertyValue = new SettingsPropertyValue(property);

                            switch (property.Name)
                            {
                                case "Culture":

                                case "DbConnectionName":

                                case "CmsID":
                                    settingsPropertyValue.PropertyValue = property.DefaultValue;
                                    break;
                                default:
                                    throw new Exception("Unsupported property.");
                            }

                            settingsValues.Add(settingsPropertyValue);
                        }
                    }
                }
            }

            return settingsValues;
        }

        /// <summary>
        /// Set/store the property values for the user profile.
        /// </summary>
        /// <param name="context">Application context.</param>
        /// <param name="settingsPropertyValues">Profile property value settings.</param>
        /// <history>
        ///     2008/11/17  [Binh Truong]   Add property "CmsID".
        /// </history>
        public override void SetPropertyValues(SettingsContext context, SettingsPropertyValueCollection collection)
        {

            string userName = context["UserName"].ToString();
            bool isAuthenticated = Convert.ToBoolean(context["IsAuthenticated"]);

            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_ProfileData_Update", CommandType.StoredProcedure);
                dataExeContext.AddParameter("UserName", userName);
                dataExeContext.AddParameter("ApplicationName", applicationName);
                dataExeContext.AddParameter("IsAnonymous", !isAuthenticated);

                foreach (SettingsPropertyValue settingsPropertyValue in collection)
                {
                    switch (settingsPropertyValue.Property.Name)
                    {
                        case "Culture":
                            dataExeContext.AddParameter(settingsPropertyValue.Property.Name, settingsPropertyValue.PropertyValue);
                            break;
                        case "DbConnectionName":
                            dataExeContext.AddParameter(settingsPropertyValue.Property.Name, settingsPropertyValue.PropertyValue);
                            break;
                        case "CmsID":
                            dataExeContext.AddParameter(settingsPropertyValue.Property.Name, settingsPropertyValue.PropertyValue);
                            break;
                        default:
                            throw new Exception("Unsupported property.");
                    }
                }
                dataExeContext.RunNonQuery();
            }
        }

        /// <summary>
        /// Deletes profiles that have been inactive since the specified date.
        /// </summary>
        /// <param name="authenticationOption">Current authentication option setting.</param>
        /// <param name="userInactiveSinceDate">Inactivity date for deletion.</param>
        /// <returns>Number of records deleted.</returns>
        public override int DeleteInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate)
        {
            int deletedProfiles = 0;
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_Profiles_Inactive_Delete", CommandType.StoredProcedure);
                dataExeContext.AddParameter("Deleted", 0, ParameterDirection.Output);
                dataExeContext.AddParameter("InactivityDate", userInactiveSinceDate);
                dataExeContext.AddParameter("IsAnonymous", (authenticationOption == ProfileAuthenticationOption.Anonymous) ? 1 : 0);
                dataExeContext.RunNonQuery();

                deletedProfiles = dataExeContext.GetParameterOutPutIntegerValue("Deleted");
            }

            return deletedProfiles;

        }

        /// <summary>
        /// Delete profiles for an array of user names.
        /// </summary>
        /// <param name="userNames">Array of user names.</param>
        /// <returns>Number of profiles deleted.</returns>
        public override int DeleteProfiles(string[] usernames)
        {
            int deleted = 0;
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext context = provider.BeginExecution(true))
            {
                try
                {
                    foreach (string username in usernames)
                    {
                        context.SetCommandText("CWX_Profiles_Delete", CommandType.StoredProcedure);
                        context.AddParameter("userName", username);

                        deleted += context.RunNonQuery();

                        context.Clear();
                    }
                }
                catch
                {
                    context.Rollback();
                    throw;
                }
            }

            return deleted;
        }

        /// <summary>
        /// Delete profiles based upon the user names in the collection of profiles.
        /// </summary>
        /// <param name="profiles">Collection of profiles.</param>
        /// <returns>Number of profiles deleted.</returns>
        public override int DeleteProfiles(ProfileInfoCollection profiles)
        {
            string[] userNames = new string[profiles.Count];

            int index = 0;
            foreach (ProfileInfo profileInfo in profiles)
            {
                userNames[index] = profileInfo.UserName;
                index += 1;
            }

            return DeleteProfiles(userNames);

        }

        /// <summary>
        /// Get a collection of profiles based upon a user name matching string and inactivity date.
        /// </summary>
        /// <param name="authenticationOption">Current authentication option setting.</param>
        /// <param name="userNameToMatch">Characters representing user name to match (L to R).</param>
        /// <param name="userInactiveSinceDate">Inactivity date for deletion.</param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalRecords">Total records found (output).</param>
        /// <returns>Collection of profiles.</returns>
        public override ProfileInfoCollection FindInactiveProfilesByUserName(ProfileAuthenticationOption authenticationOption, string usernameToMatch, DateTime userInactiveSinceDate, int pageIndex, int pageSize, out int totalRecords)
        {

            CheckParameters(pageIndex, pageSize);

            return GetProfileInfo(
            authenticationOption,
            usernameToMatch,
            userInactiveSinceDate,
            pageIndex,
            pageSize,
            out totalRecords
            );

        }

        /// <summary>
        /// Get a collection of profiles based upon a user name matching string.
        /// </summary>
        /// <param name="authenticationOption">Current authentication option setting.</param>
        /// <param name="userNameToMatch">Characters representing user name to match (L to R).</param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalRecords">Total records found (output).</param>
        /// <returns>Collection of profiles.</returns>
        public override ProfileInfoCollection FindProfilesByUserName(ProfileAuthenticationOption authenticationOption, string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
        {

            CheckParameters(pageIndex, pageSize);

            return GetProfileInfo(
            authenticationOption,
            usernameToMatch,
            null,
            pageIndex,
            pageSize,
            out totalRecords
            );

        }

        /// <summary>
        /// Get a collection of profiles based upon an inactivity date.
        /// </summary>
        /// <param name="authenticationOption">Current authentication option setting.</param>
        /// <param name="userInactiveSinceDate">Inactivity date for deletion.</param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalRecords">Total records found (output).</param>
        /// <returns>Collection of profiles.</returns>
        public override ProfileInfoCollection GetAllInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate, int pageIndex, int pageSize, out int totalRecords)
        {



            CheckParameters(pageIndex, pageSize);

            return GetProfileInfo(
            authenticationOption,
            null,
            userInactiveSinceDate,
            pageIndex,
            pageSize,
            out totalRecords
            );

        }

        /// <summary>
        /// Get a collection of profiles.
        /// </summary>
        /// <param name="authenticationOption">Current authentication option setting.</param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalRecords">Total records found (output).</param>
        /// <returns>Collection of profiles.</returns>
        public override ProfileInfoCollection GetAllProfiles(ProfileAuthenticationOption authenticationOption, int pageIndex, int pageSize, out int totalRecords)
        {


            CheckParameters(pageIndex, pageSize);

            return GetProfileInfo(
            authenticationOption,
            null,
            null,
            pageIndex,
            pageSize,
            out totalRecords
            );

        }

        /// <summary>
        /// Get the number of inactive profiles based upon an inactivity date.
        /// </summary>
        /// <param name="authenticationOption">Current authentication option setting.</param>
        /// <param name="userInarctiveSinceDate">Inactivity date for deletion.</param>
        /// <returns>Number of pofiles.</returns>
        public override int GetNumberOfInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate)
        {

            int inactiveProfiles = 0;

            GetProfileInfo(authenticationOption, null, userInactiveSinceDate, 0, 0, out inactiveProfiles);

            return inactiveProfiles;

        }

        #endregion

        #region Methods

        /// <summary>
        /// Verifies input parameters for page size and page index. 
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <remarks></remarks>
        private void CheckParameters(int pageIndex, int pageSize)
        {
            if (pageIndex < 0)
            {
                throw new ArgumentException("Page index must 0 or greater.");
            }
            if (pageSize < 1)
            {
                throw new ArgumentException("Page size must be greater than 0.");
            }
        }

        /// <summary>
        /// Get a collection of profiles based upon a user name matching string and inactivity date.
        /// </summary>
        /// <param name="authenticationOption">Current authentication option setting.</param>
        /// <param name="userNameToMatch">Characters representing user name to match (L to R).</param>
        /// <param name="userInactiveSinceDate">Inactivity date for deletion.</param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalRecords">Total records found (output).</param>
        /// <returns>Collection of profiles.</returns>
        private ProfileInfoCollection GetProfileInfo(
            ProfileAuthenticationOption authenticationOption,
            string usernameToMatch,
            object userInactiveSinceDate,
            int pageIndex,
            int pageSize,
            out int totalRecords
            )
        {
            ProfileInfoCollection profiles = new ProfileInfoCollection();
            IDataProvider provider = new DataProviderFactory().Create(ConnectionManager.CoreDatabaseElementName);
            using (IDataExecutionContext dataExeContext = provider.BeginExecution())
            {
                dataExeContext.SetCommandText("CWX_Profiles_Select", CommandType.StoredProcedure);
                // if searching for a user name to match add the command text and parameters.
                if (String.IsNullOrEmpty(usernameToMatch))
                {
                    dataExeContext.AddParameter("userName", usernameToMatch);
                }

                //if searching for inactive profiles add the command text and parameters.
                if (userInactiveSinceDate != null)
                {
                    dataExeContext.AddParameter("inactivityDate", Convert.ToDateTime(userInactiveSinceDate));
                }

                // If searching for a anonymous or authenticated profiles, add the command text 
                // and parameters.
                if (authenticationOption == ProfileAuthenticationOption.Anonymous)
                {
                    dataExeContext.AddParameter("isAnonymous", 1);
                }
                else
                {
                    dataExeContext.AddParameter("isAnonymous", 0);
                }

                // Count profiles only.
                if (pageSize == 0)
                {
                    totalRecords = 0;
                    return profiles;
                }

                int counter = 0;
                IDataReader reader = dataExeContext.RunReader(CommandBehavior.CloseConnection);
                int startIndex = pageSize * (pageIndex - 1);
                int endIndex = startIndex + pageSize - 1;
                bool isContinue = true;

                while (isContinue && reader.Read())
                {
                    if (counter >= startIndex)
                    {
                        ProfileInfo profileInfo = new ProfileInfo(
                                (reader["UserName"].ToString()),
                                Convert.ToBoolean(reader["IsAnonymous"]),
                                Convert.ToDateTime(reader["LastActivity"]),
                                Convert.ToDateTime(reader["LastUpdated"]),
                                0
                                );

                        profiles.Add(profileInfo);
                    }

                    if (counter >= endIndex)
                    {
                        isContinue = false;
                        reader.Close();
                    }

                    counter++;
                }

                totalRecords = counter;
            }
            return profiles;
        }

        #endregion
    }
}
